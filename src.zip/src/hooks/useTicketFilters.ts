import { useState, useMemo, useEffect } from 'react';
import type {
  Ticket,
  User,
  TicketStage,
  TicketStatus,
  UserRole,
  TicketPriority,
  TicketChannel
} from '../types';
import { getAllHashtags } from '../lib/hashtagUtils';
import { db } from '../lib/mockDb/client';

// ✅ Utility type for filter states
type FilterAll<T extends string> = T | 'all';

interface UseTicketFiltersProps {
  tickets: Ticket[];
  user: User | null;
  activeRole: UserRole | null;
  currentPath: string;
  initialSearchQuery?: string;
  isStaffView?: boolean;
}

// ===== HELPER FUNCTIONS =====

/**
 * Normalize path by removing query strings and trailing slashes
 */
function normalizePath(path: string): string {
  const noQuery = path.split('?')[0].split('#')[0];
  if (noQuery.length > 1 && noQuery.endsWith('/')) {
    return noQuery.slice(0, -1);
  }
  return noQuery;
}

/**
 * Get target tier from user role
 */
function getTargetTier(role?: UserRole | null): TicketStage | null {
  if (role === 'tier1') return 'tier1';
  if (role === 'tier2') return 'tier2';
  if (role === 'tier3') return 'tier3';
  return null;
}

/**
 * ⭐ Main hook for filtering tickets based on role and menu context
 * ตาม TICKET_FILTERING_LOGIC_FINAL.md
 */
export function useTicketFilters({
  tickets,
  user,
  activeRole,
  currentPath,
  initialSearchQuery = '',
  isStaffView = false
}: UseTicketFiltersProps) {
  // ===== STATE MANAGEMENT =====
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [statusFilter, setStatusFilter] = useState<FilterAll<TicketStatus>>('all');
  const [tierFilter, setTierFilter] = useState<FilterAll<TicketStage>>('all');
  const [priorityFilter, setPriorityFilter] = useState<FilterAll<TicketPriority>>('all');
  const [channelFilter, setChannelFilter] = useState<FilterAll<TicketChannel>>('all');
  const [productFilter, setProductFilter] = useState('all');
  const [organizationFilter, setOrganizationFilter] = useState('all');
  const [projectCodeFilter, setProjectCodeFilter] = useState('all');
  const [hashtagFilters, setHashtagFilters] = useState<string[]>([]);
  const [hashtagSearch, setHashtagSearch] = useState('');

  // ===== EFFECTS =====

  // Sync search query with prop changes
  useEffect(() => {
    setSearchQuery(initialSearchQuery);
  }, [initialSearchQuery]);

  // Reset all filters when path changes
  useEffect(() => {
    setStatusFilter('all');
    setTierFilter('all');
    setPriorityFilter('all');
    setChannelFilter('all');
    setProductFilter('all');
    setOrganizationFilter('all');
    setProjectCodeFilter('all');
    setHashtagFilters([]);
    setSearchQuery('');
  }, [currentPath]);

  // ===== HASHTAG FILTERING =====

  const allHashtags = useMemo(() => getAllHashtags(tickets), [tickets]);

  const filteredHashtags = useMemo(() => {
    if (!hashtagSearch.trim()) return allHashtags;
    const search = hashtagSearch.toLowerCase();
    return allHashtags.filter(tag => tag.toLowerCase().includes(search));
  }, [allHashtags, hashtagSearch]);

  // ===== MAIN FILTERING LOGIC =====

  const filteredTickets = useMemo(() => {
    const path = normalizePath(currentPath);

    // ✅ บังคับ "context การทำงาน" เป็น tier เสมอถ้ามี tier role (admin เป็นแค่ permission/menu)
    const tierContextRole =
      (['tier1', 'tier2', 'tier3'] as const).find(r => (user as any)?.roles?.includes(r));

    // รองรับทั้ง user.role (legacy) และ user.primaryRole (ใหม่)
    const effectiveRole: UserRole | undefined =
      (tierContextRole ?? activeRole ?? (user as any)?.role ?? (user as any)?.primaryRole) ?? undefined;

    // ===== TICKET HELPERS =====

    /**
     * Check if ticket is accepted by assignee
     * (ยังคง legacy field accepted)
     */
    const isAccepted = (t: Ticket): boolean => {
      return (t as any).accepted === true;
    };

    /**
     * Check if ticket is assigned to current user
     */
    const isAssignedToMe = (t: Ticket): boolean => {
      return Boolean(user?.id && t.assignedTo === user.id);
    };

    /**
     * ✅ Get ticket stage (tier1/tier2/tier3)
     * - New: t.stage
     * - Legacy: t.legacyStatusTier
     * - Legacy old mock: t.status was tier1/tier2/tier3
     */
    const getStage = (t: Ticket): TicketStage => {
      const s1 = (t as any).stage;
      if (s1 === 'tier1' || s1 === 'tier2' || s1 === 'tier3') return s1;

      const s2 = (t as any).legacyStatusTier;
      if (s2 === 'tier1' || s2 === 'tier2' || s2 === 'tier3') return s2;

      const legacyStatus = (t as any).status;
      if (legacyStatus === 'tier1' || legacyStatus === 'tier2' || legacyStatus === 'tier3') {
        return legacyStatus;
      }

      return 'tier1';
    };

    /**
     * ✅ Get ticket status (new/in_progress/waiting/resolved/closed/...)
     * รองรับ legacy mapping:
     * - 'on_hold' -> 'waiting' (ถ้าเคยใช้คำนี้)
     * - status เป็น tier -> 'in_progress'
     */
    const getStatus = (t: Ticket): TicketStatus => {
      const s = (t as any).status;

      // New/Expected statuses (คุณสามารถลด/เพิ่มได้ตาม type จริงของคุณ)
      const validStatuses: TicketStatus[] = [
        'new',
        'in_progress',
        'waiting',
        'resolved',
        'closed',
        'cancelled',
        'rejected',
        'duplicate'
      ];

      if (validStatuses.includes(s)) return s;

      // Legacy: old word on_hold -> waiting
      if (s === 'on_hold') return 'waiting';

      // Legacy: tier stored in status -> treat as in_progress
      if (s === 'tier1' || s === 'tier2' || s === 'tier3') return 'in_progress';

      // Legacy: 'waiting' sometimes mapped to on_hold previously; now keep as waiting
      if (s === 'waiting') return 'waiting';

      return 'in_progress';
    };

    /**
     * Check if ticket was escalated (from -> to) by current user
     * ⭐ ใช้ chain.from และ chain.to
     */
    const wasSentByMe = (
      ticket: Ticket,
      fromTier: TicketStage,
      toTier: TicketStage
    ): boolean => {
      return db.escalations.getByTicketId(ticket.id).some(chain =>
        chain.from === fromTier &&
        chain.to === toTier &&
        chain.escalatedBy === user?.id
      );
    };

    // ===== FILTERING LOGIC =====

    return tickets
      .filter(ticket => {
        // ===== STAFF VIEW FILTER =====
        // ตาม rule: staff เห็นเฉพาะที่ตัวเองสร้าง
        if (isStaffView && (user as any)?.role === 'staff') {
          if (ticket.createdBy !== user.id) return false;
        }

        const ticketStage = getStage(ticket);
        const ticketStatus = getStatus(ticket);

        // ===== TIER1 LOGIC =====
        if (effectiveRole === 'tier1') {
          if (path === '/admin/tickets') {
            // เคสทั้งหมด: เห็นทุก status (no role filtering here)
          }

          if (path === '/admin/pending') {
            // รอดำเนินการ:
            // 1) new (assignedTo = null)
            // 2) stage=tier1 + assignedTo=me + not accepted
            const isNewTicket = ticketStatus === 'new' && ticket.assignedTo == null;
            const isTier1Pending =
              ticketStage === 'tier1' && isAssignedToMe(ticket) && !isAccepted(ticket);

            if (!isNewTicket && !isTier1Pending) return false;
          }

          if (path === '/admin/my-tickets') {
            // งานของฉัน: assignedTo=me, accepted=true, status=in_progress เท่านั้น
            if (!isAssignedToMe(ticket)) return false;
            if (!isAccepted(ticket)) return false;
            if (ticketStatus !== 'in_progress') return false; // ⭐ เพิ่มเงื่อนไขนี้
          }

          if (path === '/admin/resolved') {
            // แก้ไขแล้ว: resolved/closed ที่ตัวเองทำ
            if (!['resolved', 'closed'].includes(ticketStatus)) return false;

            const isResolvedByMe = (ticket as any).resolvedBy === user?.id;
            const isClosedByMe = (ticket as any).closedBy === user?.id;

            if (!isResolvedByMe && !isClosedByMe) return false;
          }

          if (path === '/admin/escalated') {
            // เคสที่ฉันส่งต่อ (tier1 -> tier2/tier3 หรือส่งกลับแบบ lateral)
            // สำหรับ tier1: แค่เช็ค escalations ว่ามี escalatedBy = me ก็พอ
            const hasMyEscalation = db.escalations
              .getByTicketId(ticket.id)
              .some(e => e.escalatedBy === user?.id);

            if (!hasMyEscalation) return false;
          }
        }

        // ===== TIER2 LOGIC =====
        if (effectiveRole === 'tier2') {
          if (path === '/admin/tickets') {
            // เคสทั้งหมด: เห็น tier2 + tier3
            if (!['tier2', 'tier3'].includes(ticketStage)) return false;
          }

          if (path === '/admin/pending') {
            // รอดำเนินการ: stage=tier2, assignedTo=me, accepted=false
            if (ticketStage !== 'tier2') return false;
            if (!isAssignedToMe(ticket)) return false;
            if (isAccepted(ticket)) return false;
          }

          if (path === '/admin/my-tickets') {
            // งานของฉัน: assignedTo=me, accepted=true, status=in_progress เท่านั้น
            if (!isAssignedToMe(ticket)) return false;
            if (!isAccepted(ticket)) return false;
            if (ticketStatus !== 'in_progress') return false; // ⭐ เพิ่มเงื่อนไขนี้
          }

          if (path === '/admin/resolved') {
            // แก้ไขแล้ว: ส่งกลับ T1 เพื่อปิด (stage=tier1, status=resolved)
            if (ticketStage !== 'tier1') return false;
            if (ticketStatus !== 'resolved') return false;

            if (!wasSentByMe(ticket, 'tier2', 'tier1')) return false;
          }

          if (path === '/admin/escalated') {
            // เคสที่ฉันส่งต่อ: ส่งให้ T3 หรือส่งกลับ T1 เพื่อแก้ต่อ
            const sentToT3 = wasSentByMe(ticket, 'tier2', 'tier3');
            const sentBackToT1 = db.escalations.getByTicketId(ticket.id).some(chain =>
              chain.from === 'tier2' &&
              chain.to === 'tier1' &&
              chain.escalatedBy === user?.id &&
              chain.escalationType === 'for_continuation'
            );

            if (!sentToT3 && !sentBackToT1) return false;
          }
        }

        // ===== TIER3 LOGIC =====
        if (effectiveRole === 'tier3') {
          if (path === '/admin/tickets') {
            // เคสทั้งหมด: เห็น tier3 เท่านั้น
            if (ticketStage !== 'tier3') return false;
          }

          if (path === '/admin/pending') {
            // รอดำเนินการ: stage=tier3, assignedTo=me, accepted=false
            if (ticketStage !== 'tier3') return false;
            if (!isAssignedToMe(ticket)) return false;
            if (isAccepted(ticket)) return false;
          }

          if (path === '/admin/my-tickets') {
            // งานของฉัน: assignedTo=me, accepted=true, status=in_progress เท่านั้น
            if (!isAssignedToMe(ticket)) return false;
            if (!isAccepted(ticket)) return false;
            if (ticketStatus !== 'in_progress') return false; // ⭐ เพิ่มเงื่อนไขนี้
          }

          if (path === '/admin/resolved') {
            // แก้ไขแล้ว: ส่งกลับ T1 เพื่อปิด (stage=tier1, status=resolved)
            if (ticketStage !== 'tier1') return false;
            if (ticketStatus !== 'resolved') return false;

            if (!wasSentByMe(ticket, 'tier3', 'tier1')) return false;
          }

          if (path === '/admin/escalated') {
            // เคสที่ฉันส่งต่อ: ส่งกลับ T2 หรือส่งกลับ T1 เพื่อแก้ต่อ
            const sentToT2 = wasSentByMe(ticket, 'tier3', 'tier2');
            const sentBackToT1 = db.escalations.getByTicketId(ticket.id).some(chain =>
              chain.from === 'tier3' &&
              chain.to === 'tier1' &&
              chain.escalatedBy === user?.id &&
              chain.escalationType === 'for_continuation'
            );

            if (!sentToT2 && !sentBackToT1) return false;
          }
        }

        // ===== ADMIN LOGIC =====
        if (effectiveRole === 'admin') {
          if (path === '/admin/pending') {
            // รอดำเนินการ: new + ทุก tier ที่ accepted=false และยังไม่ปิด
            const isNew = ticketStatus === 'new' && ticket.assignedTo == null;
            const isPending =
              ticket.assignedTo != null &&
              !isAccepted(ticket) &&
              ['tier1', 'tier2', 'tier3'].includes(ticketStage) &&
              !['resolved', 'closed'].includes(ticketStatus);

            if (!isNew && !isPending) return false;
          }

          if (path === '/admin/resolved') {
            // แก้ไขแล้ว: resolved + closed ทั้งหมด
            if (!['resolved', 'closed'].includes(ticketStatus)) return false;
          }
        }

        // ===== COMMON FILTERS =====

        // Search query (title, ticket number, customer name)
        if (searchQuery) {
          const searchLower = searchQuery.toLowerCase();
          const matchTitle = ticket.title.toLowerCase().includes(searchLower);
          const matchNumber = ticket.ticketNumber.toLowerCase().includes(searchLower);
          const matchCustomer = (ticket as any).customerName?.toLowerCase().includes(searchLower);

          if (!matchTitle && !matchNumber && !matchCustomer) return false;
        }

        // Status filter (สถานะงาน)
        if (statusFilter !== 'all' && ticketStatus !== statusFilter) return false;

        // Tier/Stage filter (tier)
        if (tierFilter !== 'all' && ticketStage !== tierFilter) return false;

        // Priority filter
        if (priorityFilter !== 'all' && ticket.priority !== priorityFilter) return false;

        // Channel filter
        if (channelFilter !== 'all' && ticket.channel !== channelFilter) return false;

        // Product filter
        // Product filter — hydrated ticket has products: Product[]
        if (productFilter !== 'all') {
          const ticketProds = (ticket as any).products as Array<{productCode: string}> | undefined;
          const hasProduct = ticketProds?.some(p => p.productCode === productFilter);
          if (!hasProduct) return false;
        }

        // ⭐ Organization filter - lookup from projectCode (legacy)
        const projectCode = (ticket as any).projectCode as string | undefined;
        if (organizationFilter !== 'all') {
          if (projectCode) {
            const allProjects = db.projects.getAll();
            const project = allProjects.find(p => p.code === projectCode);

            if (!project || project.organizationId !== organizationFilter) return false;
          } else {
            return false;
          }
        }

        // Project code filter
        if (projectCodeFilter !== 'all' && projectCodeFilter.trim()) {
          if (!projectCode?.toLowerCase().includes(projectCodeFilter.toLowerCase())) return false;
        }

        // Hashtag filters
        if (hashtagFilters.length > 0) {
          // Extract hashtags from description (supports Thai characters)
          const tags = (ticket.description.match(/#[\wก-๙]+/g) || []).map(t => t.toLowerCase());

          // All selected hashtags must be present
          if (!hashtagFilters.every(tag => tags.includes(tag.toLowerCase()))) return false;
        }

        return true;
      })
      // Sort by creation date (newest first)
      .sort((a, b) => new Date((b as any).createdAt).getTime() - new Date((a as any).createdAt).getTime());

  }, [
    tickets,
    user,
    activeRole,
    currentPath,
    isStaffView,
    searchQuery,
    statusFilter,
    tierFilter,
    priorityFilter,
    channelFilter,
    productFilter,
    organizationFilter,
    projectCodeFilter,
    hashtagFilters,
    hashtagSearch,
    allHashtags
  ]);

  // ===== RETURN API =====
  return {
    // Filtered data
    filteredTickets,
    allHashtags,
    filteredHashtags,

    // Search
    searchQuery,
    setSearchQuery,

    // Status filters
    statusFilter,
    setStatusFilter,

    // Tier filters
    tierFilter,
    setTierFilter,

    // Priority filters
    priorityFilter,
    setPriorityFilter,

    // Channel filters
    channelFilter,
    setChannelFilter,

    // Product filters
    productFilter,
    setProductFilter,

    // Organization filters
    organizationFilter,
    setOrganizationFilter,

    // Project filters
    projectCodeFilter,
    setProjectCodeFilter,

    // Hashtag filters
    hashtagFilters,
    setHashtagFilters,
    hashtagSearch,
    setHashtagSearch
  };
}
