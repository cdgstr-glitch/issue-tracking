import svgPaths from "./svg-j1y8ehi5c1";
import imgImage4 from "../assets/e6673285d07284ae5db1591edc6cbb88211b3d47.png";
import imgImage5 from "../assets/78ed83eba43431c0c08c68662a3249b4695d24ea.png";
import imgImageCdgsLogo from "../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png";

function Group() {
  return (
    <div className="absolute h-[746px] left-[calc(50%-13px)] top-1/2 translate-x-[-50%] translate-y-[-50%] w-[772px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 772 746">
        <g id="Group 1">
          <circle cx="399" cy="373" id="Ellipse 2" r="371.5" stroke="var(--stroke-0, #DFE3FC)" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="32.5" cy="406.5" id="Ellipse 3" r="31" stroke="var(--stroke-0, #DFE3FC)" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="619.5" cy="72.5" id="Ellipse 4" r="31" stroke="var(--stroke-0, #DFE3FC)" strokeOpacity="0.8" strokeWidth="3" />
        </g>
      </svg>
    </div>
  );
}

function Image() {
  return (
    <div className="absolute bg-white bottom-0 h-[1080px] left-0 overflow-clip w-[960px]" data-name="Image">
      <div className="absolute h-[1080px] left-0 top-0 w-[960px]" data-name="image 3" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 960 1080\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(2.9392e-15 54 -48 3.3065e-15 480 540)\\\'><stop stop-color=\\\'rgba(72,21,236,1)\\\' offset=\\\'0.26442\\\'/><stop stop-color=\\\'rgba(59,16,198,1)\\\' offset=\\\'0.44832\\\'/><stop stop-color=\\\'rgba(46,11,159,1)\\\' offset=\\\'0.63221\\\'/><stop stop-color=\\\'rgba(32,5,120,1)\\\' offset=\\\'0.81611\\\'/><stop stop-color=\\\'rgba(19,0,81,1)\\\' offset=\\\'1\\\'/></radialGradient></defs></svg>')" }} />
      <div className="absolute flex h-[796.566px] items-center justify-center left-1/2 top-[calc(50%+0.5px)] translate-x-[-50%] translate-y-[-50%] w-[797.402px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[81.215deg]">
          <div className="h-[699px] relative w-[698px]" data-name="image 4">
            <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover opacity-[0.73] pointer-events-none size-full" src={imgImage4} />
          </div>
        </div>
      </div>
      <Group />
      <div className="absolute h-[695px] left-[calc(50%+0.5px)] top-[calc(50%+0.5px)] translate-x-[-50%] translate-y-[-50%] w-[767px]" data-name="image 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage5} />
      </div>
    </div>
  );
}

function ImageCdgsLogo() {
  return (
    <div className="relative shrink-0 size-[116px]" data-name="Image (CDGS Logo)">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgImageCdgsLogo} />
    </div>
  );
}

function CardTitle() {
  return (
    <div className="[grid-area:1_/_1] h-[24px] justify-self-stretch relative shrink-0" data-name="CardTitle">
      <p className="absolute font-['Prompt:Regular',sans-serif] leading-[normal] left-0 not-italic text-[16px] text-neutral-950 text-nowrap top-[0.5px] whitespace-pre">เข้าสู่ระบบ</p>
    </div>
  );
}

function CardDescription() {
  return (
    <div className="[grid-area:2_/_1] h-[27.195px] justify-self-stretch relative shrink-0" data-name="CardDescription">
      <p className="absolute font-['Prompt:Regular',sans-serif] leading-[normal] left-0 not-italic text-[16px] text-neutral-500 text-nowrap top-0 whitespace-pre">กรุณาป้อนชื่อผู้ใช้และรหัสผ่านของคุณ</p>
    </div>
  );
}

function CardHeader() {
  return (
    <div className="relative shrink-0 w-[446px]" data-name="CardHeader">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid gap-[6px] grid grid-cols-[repeat(1,_minmax(0px,_1fr))] grid-rows-[repeat(2,_fit-content(100%))] pb-[16px] pt-0 px-[24px] relative w-full">
        <CardTitle />
        <CardDescription />
      </div>
    </div>
  );
}

function PrimitiveLabel() {
  return (
    <div className="content-stretch flex h-[14px] items-center relative shrink-0 w-full" data-name="Primitive.label">
      <p className="font-['Prompt:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[14px] text-neutral-950 text-nowrap whitespace-pre">ชื่อผู้ใช้</p>
    </div>
  );
}

function Input() {
  return (
    <div className="bg-[rgba(229,229,229,0.3)] h-[36px] relative rounded-[6.8px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[12px] py-[4px] relative size-full">
          <p className="font-['Prompt:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-neutral-950 text-nowrap whitespace-pre">กรอกชื่อผู้ใช้</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-neutral-200 border-solid inset-0 pointer-events-none rounded-[6.8px]" />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[58px] items-start relative shrink-0 w-full" data-name="Container">
      <PrimitiveLabel />
      <Input />
    </div>
  );
}

function PrimitiveLabel1() {
  return (
    <div className="content-stretch flex h-[14px] items-center relative shrink-0 w-full" data-name="Primitive.label">
      <p className="font-['Prompt:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[14px] text-neutral-950 text-nowrap whitespace-pre">รหัสผ่าน</p>
    </div>
  );
}

function Input1() {
  return (
    <div className="absolute bg-[rgba(229,229,229,0.3)] h-[36px] left-0 rounded-[6.8px] top-0 w-[398px]" data-name="Input">
      <div className="content-stretch flex items-center overflow-clip pl-[12px] pr-[40px] py-[4px] relative rounded-[inherit] size-full">
        <p className="font-['Prompt:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-neutral-950 text-nowrap whitespace-pre">กรอกรหัสผ่าน</p>
      </div>
      <div aria-hidden="true" className="absolute border border-neutral-200 border-solid inset-0 pointer-events-none rounded-[6.8px]" />
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #6A7282)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #6A7282)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[370px] size-[16px] top-[10px]" data-name="Button">
      <Icon />
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Container">
      <Input1 />
      <Button />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[58px] items-start relative shrink-0 w-full" data-name="Container">
      <PrimitiveLabel1 />
      <Container1 />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-neutral-900 h-[36px] relative rounded-[6.8px] shrink-0 w-full" data-name="Button">
      <p className="absolute font-['Prompt:Medium',sans-serif] leading-[normal] left-[199.41px] not-italic text-[14px] text-center text-neutral-50 text-nowrap top-[7.5px] translate-x-[-50%] whitespace-pre">เข้าสู่ระบบ</p>
    </div>
  );
}

function LoginPage() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[184px] items-start relative shrink-0 w-full" data-name="LoginPage">
      <Container />
      <Container2 />
      <Button1 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[143.12px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_113_65)" id="Icon">
          <path d={svgPaths.p39ee6532} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1c3b9980} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 11.3333H8.00667" id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_113_65">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[rgba(229,229,229,0.3)] h-[36px] relative rounded-[6.8px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border border-neutral-200 border-solid inset-0 pointer-events-none rounded-[6.8px]" />
      <Icon1 />
      <p className="absolute font-['Prompt:Medium',sans-serif] leading-[normal] left-[215.62px] not-italic text-[14px] text-center text-neutral-950 text-nowrap top-[7.5px] translate-x-[-50%] whitespace-pre">ดูบัญชีทดสอบ</p>
    </div>
  );
}

function LoginPage1() {
  return (
    <div className="content-stretch flex flex-col h-[61px] items-start pb-0 pt-[25px] px-0 relative shrink-0 w-full" data-name="LoginPage">
      <div aria-hidden="true" className="absolute border-[1px_0px_0px] border-gray-200 border-solid inset-0 pointer-events-none" />
      <Button2 />
    </div>
  );
}

function CardContent() {
  return (
    <div className="relative shrink-0 w-[446px]" data-name="CardContent">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-start px-[24px] py-0 relative w-full">
        <LoginPage />
        <LoginPage1 />
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[24px] items-start px-[21px] py-[41px] relative rounded-[16.4px] shrink-0" data-name="Card">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[16.4px]" />
      <CardHeader />
      <CardContent />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[23.797px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Prompt:Regular',sans-serif] leading-[normal] left-[224.05px] not-italic text-[#6a7282] text-[14px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">© 2025 CDGS. All rights reserved.</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[23.797px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Prompt:Regular',sans-serif] leading-[normal] left-[223.97px] not-italic text-[#6a7282] text-[14px] text-center text-nowrap top-[-0.5px] translate-x-[-50%] whitespace-pre">{`Enterprise Issue Tracking & Support System`}</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[63.594px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph />
      <Paragraph1 />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[32px] items-center left-[1103px] px-[105px] py-0 top-[127px]" data-name="Container">
      <ImageCdgsLogo />
      <p className="font-['Prompt:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#101828] text-[32px] text-center text-nowrap whitespace-pre">CDGS Issue Tracking Platform</p>
      <p className="font-['Prompt:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#4a5565] text-[16px] text-center text-nowrap whitespace-pre">ระบบบริหารจัดการเคสและการสนับสนุนลูกค้า</p>
      <Card />
      <Container3 />
    </div>
  );
}

export default function CdgsHelpDeskPlatformUiUxDesign() {
  return (
    <div className="bg-[#fafbff] relative size-full" data-name="CDGS HelpDesk Platform UI_UX Design">
      <Image />
      <Container4 />
    </div>
  );
}