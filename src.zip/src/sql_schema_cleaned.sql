-- ====================================
-- CDGS Issue Tracking Platform
-- Cleaned Database Schema (Unified)
-- Version: 2.0 (Organization-Project Split)
-- Date: 2026-01-26
-- ====================================

-- ตั้งค่าการรองรับภาษาไทย
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
SET collation_connection = 'utf8mb4_unicode_ci';

-- สร้าง Database
CREATE DATABASE IF NOT EXISTS cdgs_issue_tracking
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE cdgs_issue_tracking;

-- ====================================
-- 1. ORGANIZATION & PROJECT (Structure Layer)
-- ====================================

-- 1.1 ตารางหน่วยงาน/องค์กร (แยกออกมาใหม่)
CREATE TABLE organizations (
  id VARCHAR(36) PRIMARY KEY COMMENT 'Organization UUID',
  code VARCHAR(50) UNIQUE NOT NULL COMMENT 'รหัสหน่วยงาน (ORG-NNN)',
  name VARCHAR(255) NOT NULL COMMENT 'ชื่อหน่วยงาน/องค์กร',
  short_name VARCHAR(100) NOT NULL COMMENT 'ชื่อย่อ (เช่น VRU, MRTA)',
  type ENUM('university', 'government', 'enterprise', 'public_sector', 'private_sector') NOT NULL DEFAULT 'government',
  department VARCHAR(255) COMMENT 'สังกัด (เช่น กระทรวง, ทบวง)',
  contact_person VARCHAR(255) COMMENT 'ผู้ติดต่อหลัก',
  contact_email VARCHAR(255) COMMENT 'อีเมลผู้ติดต่อ',
  description TEXT COMMENT 'คำอธิบายเพิ่มเติม',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  INDEX idx_org_code (code),
  INDEX idx_org_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='หน่วยงานและองค์กรลูกค้า';

-- 1.2 ตารางโครงการ (Project)
CREATE TABLE projects (
  id VARCHAR(36) PRIMARY KEY COMMENT 'Project UUID',
  organization_id VARCHAR(36) NOT NULL COMMENT 'อ้างอิง organizations.id',
  code VARCHAR(50) UNIQUE NOT NULL COMMENT 'รหัสโครงการ (D{YY}-{XXXX})',
  name VARCHAR(500) NOT NULL COMMENT 'ชื่อโครงการ',
  status ENUM('active', 'completed', 'cancelled', 'on_hold') DEFAULT 'active' COMMENT 'สถานะโครงการ',
  start_date DATE COMMENT 'วันเริ่มโครงการ',
  end_date DATE COMMENT 'วันสิ้นสุดโครงการ',
  budget DECIMAL(15, 2) COMMENT 'งบประมาณ',
  purchased_products JSON COMMENT 'รายชื่อผลิตภัณฑ์ที่ซื้อ (Array of Strings)',
  description TEXT COMMENT 'รายละเอียดโครงการ',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
  INDEX idx_project_code (code),
  INDEX idx_project_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='โครงการภายใต้หน่วยงาน';

-- ====================================
-- 2. USER MANAGEMENT (Identity Layer)
-- ====================================

-- 2.1 ตารางผู้ใช้งาน
CREATE TABLE users (
  id VARCHAR(36) PRIMARY KEY COMMENT 'User UUID',
  username VARCHAR(100) UNIQUE NOT NULL COMMENT 'Username',
  password_hash VARCHAR(255) COMMENT 'Password (Nullable for Customer/SSO)',
  email VARCHAR(255) UNIQUE NOT NULL COMMENT 'Email',
  full_name VARCHAR(255) NOT NULL COMMENT 'ชื่อ-นามสกุล',
  phone VARCHAR(20) COMMENT 'เบอร์โทรศัพท์',
  
  -- Role System
  primary_role ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL COMMENT 'บทบาทหลัก',
  tier TINYINT COMMENT 'ระดับ Tier (1,2,3) สำหรับ จนท.',
  
  -- Hierarchy (Chain of Command)
  manager_id VARCHAR(36) COMMENT 'หัวหน้างาน (Level 1)',
  senior_manager_id VARCHAR(36) COMMENT 'หัวหน้างานระดับสูง (Level 2)',
  
  -- Customer Specific
  magic_link_token VARCHAR(255) COMMENT 'Token สำหรับ Login แบบไม่ต้องใช้รหัสผ่าน',
  magic_link_expiry TIMESTAMP NULL COMMENT 'วันหมดอายุ Token',
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (senior_manager_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_username (username),
  INDEX idx_email (email),
  INDEX idx_role (primary_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ผู้ใช้งานระบบ';

-- 2.2 ตาราง User Roles (สำหรับผู้ที่มีหลายบทบาท)
CREATE TABLE user_roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  role ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_role (user_id, role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='บทบาทเสริมของผู้ใช้';

-- 2.3 ตาราง User Projects (สิทธิ์เข้าถึงโครงการ)
CREATE TABLE user_projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  project_id VARCHAR(36) NOT NULL,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_project (user_id, project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='สิทธิ์ดูแลโครงการ';

-- ====================================
-- 3. TICKET MANAGEMENT (Core Business)
-- ====================================

-- 3.1 ตารางเคส (Tickets) - เปลี่ยน Terminology งาน->เคส, หัวข้อ->หัวเรื่อง
CREATE TABLE tickets (
  id VARCHAR(36) PRIMARY KEY COMMENT 'Ticket UUID',
  ticket_number VARCHAR(50) UNIQUE NOT NULL COMMENT 'เลขที่เคส (Running Number)',
  
  -- เนื้อหาเคส
  title VARCHAR(500) NOT NULL COMMENT 'หัวเรื่อง (Subject)',
  description TEXT NOT NULL COMMENT 'รายละเอียดปัญหา',
  status ENUM('new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed') NOT NULL COMMENT 'สถานะเคส',
  type ENUM('incident', 'service_request', 'security_incident') NOT NULL COMMENT 'ประเภทเคส',
  channel ENUM('web', 'email', 'line', 'phone') NOT NULL COMMENT 'ช่องทางที่รับเรื่อง',
  priority ENUM('low', 'medium', 'high', 'critical') NOT NULL COMMENT 'ความสำคัญ',
  category VARCHAR(100) NOT NULL COMMENT 'หมวดหมู่ปัญหา',
  product VARCHAR(255) COMMENT 'ผลิตภัณฑ์ที่เกี่ยวข้อง',
  
  -- ความสัมพันธ์กับโครงการ (Project Link & Snapshot)
  project_id VARCHAR(36) COMMENT 'อ้างอิง projects.id',
  organization_name VARCHAR(255) COMMENT 'ชื่อหน่วยงาน (Snapshot)',
  organization_short_name VARCHAR(100) COMMENT 'ชื่อย่อหน่วยงาน (Snapshot)',
  project_code VARCHAR(50) COMMENT 'รหัสโครงการ (Snapshot)',
  project_name VARCHAR(500) COMMENT 'ชื่อโครงการ (Snapshot)',
  
  -- ผู้แจ้งเคส (Customer)
  customer_name VARCHAR(255) NOT NULL COMMENT 'ชื่อลูกค้า',
  customer_email VARCHAR(255) NOT NULL COMMENT 'อีเมลลูกค้า',
  customer_phone VARCHAR(50) COMMENT 'เบอร์โทรลูกค้า',
  department VARCHAR(255) COMMENT 'แผนก/หน่วยงานของลูกค้า (User Input)',
  
  -- การมอบหมาย (Assignment)
  assigned_to VARCHAR(36) COMMENT 'ผู้รับผิดชอบปัจจุบัน (user_id)',
  assigned_by VARCHAR(36) COMMENT 'ผู้มอบหมายล่าสุด',
  assigned_at TIMESTAMP NULL COMMENT 'เวลามอบหมาย',
  previous_assignee VARCHAR(36) COMMENT 'ผู้รับผิดชอบคนก่อนหน้า',
  
  -- ข้อมูลการสร้าง (Creation)
  created_by VARCHAR(36) COMMENT 'User ID ผู้สร้าง (อาจเป็น Staff หรือ Customer เอง)',
  created_by_name VARCHAR(255) COMMENT 'ชื่อผู้สร้าง',
  created_by_type ENUM('customer_self', 'staff_on_behalf') NOT NULL COMMENT 'รูปแบบการสร้าง',
  created_by_staff_name VARCHAR(255) COMMENT 'ชื่อ Staff (กรณีสร้างแทน)',
  
  -- SLA & Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  due_date TIMESTAMP NULL COMMENT 'กำหนดเสร็จตาม SLA',
  resolved_at TIMESTAMP NULL COMMENT 'เวลาที่แก้ปัญหาเสร็จ',
  resolved_by VARCHAR(36) COMMENT 'ผู้แก้ไขปัญหา',
  closed_at TIMESTAMP NULL COMMENT 'เวลาที่ปิดเคส (เฉพาะ Tier 1)',
  closed_by VARCHAR(36) COMMENT 'ผู้ปิดเคส (Tier 1)',
  
  -- รายละเอียดการปิดงาน
  solution TEXT COMMENT 'วิธีการแก้ไข',
  closure_notes TEXT COMMENT 'บันทึกการปิดเคส',

  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  
  INDEX idx_ticket_number (ticket_number),
  INDEX idx_status (status),
  INDEX idx_project_id (project_id),
  FULLTEXT INDEX ft_search (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ตารางเก็บข้อมูลเคส';

-- 3.2 Timeline (ประวัติการดำเนินการ)
CREATE TABLE ticket_timeline (
  id VARCHAR(36) PRIMARY KEY,
  ticket_id VARCHAR(36) NOT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  event_type ENUM('status_change', 'comment', 'escalation', 'assignment', 'attachment', 'created', 'resolved', 'closed') NOT NULL,
  action VARCHAR(100) COMMENT 'ชื่อ Action ทางเทคนิค',
  description TEXT NOT NULL COMMENT 'คำอธิบายเหตุการณ์',
  
  -- Actor Info
  user_id VARCHAR(36) COMMENT 'ผู้กระทำ',
  user_name VARCHAR(255) COMMENT 'ชื่อผู้กระทำ (Snapshot)',
  
  -- Target Info (ถ้ามี)
  assigned_to_user_id VARCHAR(36) COMMENT 'ผู้ถูกมอบหมาย/ส่งต่อ',
  
  is_internal BOOLEAN DEFAULT FALSE COMMENT 'เป็นบันทึกภายในหรือไม่',
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  INDEX idx_ticket_timeline (ticket_id, timestamp DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='เส้นเวลาประวัติของเคส';

-- 3.3 Comments (ความคิดเห็น)
CREATE TABLE ticket_comments (
  id VARCHAR(36) PRIMARY KEY,
  ticket_id VARCHAR(36) NOT NULL,
  author_id VARCHAR(36) NOT NULL,
  author_name VARCHAR(255) NOT NULL,
  author_role VARCHAR(50) NOT NULL,
  content TEXT NOT NULL,
  is_internal BOOLEAN DEFAULT FALSE COMMENT 'คอมเมนต์ภายใน (ลูกค้าไม่เห็น)',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ระบบความคิดเห็นในเคส';

-- 3.4 Attachments (ไฟล์แนบ)
CREATE TABLE ticket_attachments (
  id VARCHAR(36) PRIMARY KEY,
  ticket_id VARCHAR(36) COMMENT 'แนบที่ระดับเคส',
  comment_id VARCHAR(36) COMMENT 'แนบในคอมเมนต์',
  filename VARCHAR(255) NOT NULL,
  file_size BIGINT NOT NULL,
  file_type VARCHAR(100) NOT NULL,
  file_url VARCHAR(500) NOT NULL,
  uploaded_by VARCHAR(36) NOT NULL,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (comment_id) REFERENCES ticket_comments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ไฟล์แนบต่างๆ';

-- ====================================
-- 4. WORKFLOW & VISIBILITY (Logic Layer)
-- ====================================

-- 4.1 Escalation Chain (ประวัติการส่งต่อ 3 ระดับ)
CREATE TABLE escalation_chain (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id VARCHAR(36) NOT NULL,
  from_tier ENUM('tier1', 'tier2', 'tier3') NOT NULL,
  to_tier ENUM('tier1', 'tier2', 'tier3') NOT NULL,
  escalated_by VARCHAR(36) NOT NULL,
  escalated_by_name VARCHAR(255) NOT NULL,
  reason TEXT,
  escalated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ประวัติการส่งต่อเคสระหว่าง Tier';

-- 4.2 Ticket Viewers (Inverted Visibility Model)
-- ใช้เก็บว่าใครกำลังดูเคสนี้อยู่ หรือใครมีสิทธิ์ดูเป็นพิเศษ
CREATE TABLE ticket_viewers (
  ticket_id VARCHAR(36) NOT NULL,
  user_id VARCHAR(36) NOT NULL,
  role VARCHAR(50),
  viewing_since TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (ticket_id, user_id),
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ผู้ที่กำลังดูเคส (Read-only)';

-- 4.3 Stakeholders (ผู้เกี่ยวข้อง)
-- ใช้ระบุคนที่มีส่วนร่วมกับเคส (Creator, Escalator, Owner) เพื่อการแจ้งเตือน
CREATE TABLE ticket_stakeholders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id VARCHAR(36) NOT NULL,
  user_id VARCHAR(36) NOT NULL,
  type ENUM('creator', 'escalator', 'current_owner') NOT NULL,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_stakeholder (ticket_id, user_id, type),
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ผู้มีส่วนได้ส่วนเสียในเคส';

-- ====================================
-- 5. FEATURES (Reports & Notifications)
-- ====================================

-- 5.1 Reports (ระบบรายงาน)
CREATE TABLE reports (
  id VARCHAR(36) PRIMARY KEY,
  report_type VARCHAR(50) NOT NULL COMMENT 'ticket_summary, performance, etc.',
  name VARCHAR(255) NOT NULL,
  parameters JSON COMMENT 'Filter settings',
  schedule_type ENUM('once', 'daily', 'weekly', 'monthly') DEFAULT 'once',
  created_by VARCHAR(36) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='การตั้งค่ารายงาน';

-- 5.2 Notifications (การแจ้งเตือน)
CREATE TABLE notifications (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  type VARCHAR(100) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  related_entity_type VARCHAR(50) COMMENT 'ticket, comment',
  related_entity_id VARCHAR(36),
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notify_user (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='การแจ้งเตือนผู้ใช้';

-- ====================================
-- END OF SCHEMA
-- ====================================
