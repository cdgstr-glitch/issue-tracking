#!/bin/bash
# Script to fix incorrect names in mockData.ts

echo "🔧 Fixing names in mockData.ts..."

cd "$(dirname "$0")/.."

# Backup first
cp lib/mockData.ts lib/mockData.ts.backup

# Fix names using sed
if [[ "$OSTYPE" == "darwin"* ]]; then
  # macOS
  sed -i '' 's/ธีรพร รุ่งวิรัติกุล/ธิราภรณ์ รุ่งวิรัตน์กุล/g' lib/mockData.ts
  sed -i '' 's/ธัญพร ทองแก้ว/ธัญญาพร ทองแก้ว/g' lib/mockData.ts
  sed -i '' 's/ประกาศิต ประกอบเพชร/ประกาศิต ประคองเพ็ชร/g' lib/mockData.ts
else
  # Linux
  sed -i 's/ธีรพร รุ่งวิรัติกุล/ธิราภรณ์ รุ่งวิรัตน์กุล/g' lib/mockData.ts
  sed -i 's/ธัญพร ทองแก้ว/ธัญญาพร ทองแก้ว/g' lib/mockData.ts
  sed -i 's/ประกาศิต ประกอบเพชร/ประกาศิต ประคองเพ็ชร/g' lib/mockData.ts
fi

echo "✅ Done! Backup saved as lib/mockData.ts.backup"
echo ""
echo "Verifying..."
echo "ธีรพร รุ่งวิรัติกุล remaining:" $(grep -c "ธีรพร รุ่งวิรัติกุล" lib/mockData.ts || echo "0")
echo "ธัญพร ทองแก้ว remaining:" $(grep -c "ธัญพร ทองแก้ว" lib/mockData.ts || echo "0")
echo "ประกาศิต ประกอบเพชร remaining:" $(grep -c "ประกาศิต ประกอบเพชร" lib/mockData.ts || echo "0")
