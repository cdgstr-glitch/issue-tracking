#!/usr/bin/env python3
"""
Script to fix short names to full names in mockDataCSVTicketsPart2.ts
"""

import re

# Read the file
with open('lib/mockDataCSVTicketsPart2.ts', 'r', encoding='utf-8') as f:
    content = f.read()

# Define replacements (from TEAM_MEMBERS.md)
replacements = {
    "assignedName: 'ธิราภรณ์',": "assignedName: 'ธิราภรณ์ รุ่งวิรัตน์กุล',",
    "assignedName: 'สาริน',": "assignedName: 'สาริน ช่อพะยอม',",
    "assignedName: 'วรรณภา',": "assignedName: 'วรรณภา แซ่ด่าง',",
    "assignedName: 'ธัญญาพร',": "assignedName: 'ธัญญาพร ทองแก้ว',",
    "assignedName: 'เขมิกา',": "assignedName: 'เขมิกา แซ่ตั้ง',",
}

# Apply replacements
for old, new in replacements.items():
    count = content.count(old)
    if count > 0:
        print(f"Replacing {count} occurrences of: {old}")
        content = content.replace(old, new)

# Write back
with open('lib/mockDataCSVTicketsPart2.ts', 'w', encoding='utf-8') as f:
    f.write(content)

print("\n✅ Successfully fixed all short names to full names!")
print("\nFixed names:")
print("- ธิราภรณ์ → ธิราภรณ์ รุ่งวิรัตน์กุล")
print("- สาริน → สาริน ช่อพะยอม")
print("- วรรณภา → วรรณภา แซ่ด่าง")
print("- ธัญญาพร → ธัญญาพร ทองแก้ว")
print("- เขมิกา → เขมิกา แซ่ตั้ง")
