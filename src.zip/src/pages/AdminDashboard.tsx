import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { StatsCard } from '../components/StatsCard';
import { Inbox, Clock, CheckCircle, TrendingUp, AlertTriangle, Users, Star } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { TicketCard } from '../components/TicketCard';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { useAuth } from '../contexts/AuthContext';
import { useEffect, useMemo, useState } from 'react';

interface AdminDashboardProps {
  onNavigate: (path: string, ticketId?: string) => void;
  searchQuery?: string;
}
export default function AdminDashboard({ onNavigate, searchQuery = '' }: AdminDashboardProps) {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState('today'); // Default to 'today' as requested
  
  // ✅ Fetch tickets from DB
  const tickets = db.tickets.getAll();
  const surveys = db.satisfactionSurveys.getAll();

  // ✅ Calculate Stats Dynamically
  const stats = useMemo(() => {
    const now = new Date();
    
    // Filter tickets by selected time range
    const filteredTickets = tickets.filter(t => {
      const createdAt = new Date(t.createdAt);
      if (timeRange === 'today') {
        return createdAt.getDate() === now.getDate() &&
               createdAt.getMonth() === now.getMonth() &&
               createdAt.getFullYear() === now.getFullYear();
      } else if (timeRange === 'week') {
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return createdAt >= oneWeekAgo;
      } else if (timeRange === 'month') {
        return createdAt.getMonth() === now.getMonth() &&
               createdAt.getFullYear() === now.getFullYear();
      } else if (timeRange === 'year') {
        return createdAt.getFullYear() === now.getFullYear();
      }
      return true;
    });

    // Filter surveys by selected time range
    const filteredSurveys = surveys.filter(s => {
      const createdAt = new Date(s.createdAt);
      if (timeRange === 'today') {
        return createdAt.getDate() === now.getDate() &&
               createdAt.getMonth() === now.getMonth() &&
               createdAt.getFullYear() === now.getFullYear();
      } else if (timeRange === 'week') {
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return createdAt >= oneWeekAgo;
      } else if (timeRange === 'month') {
        return createdAt.getMonth() === now.getMonth() &&
               createdAt.getFullYear() === now.getFullYear();
      } else if (timeRange === 'year') {
        return createdAt.getFullYear() === now.getFullYear();
      }
      return true;
    });

    const avgSatisfaction = filteredSurveys.length > 0
      ? filteredSurveys.reduce((acc, s) => acc + s.rating, 0) / filteredSurveys.length
      : 0; // Default 0 if no surveys

    // Previous period for trend calculation
    const previousTickets = tickets.filter(t => {
      const createdAt = new Date(t.createdAt);
      if (timeRange === 'today') {
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        return createdAt.getDate() === yesterday.getDate() &&
               createdAt.getMonth() === yesterday.getMonth() &&
               createdAt.getFullYear() === yesterday.getFullYear();
      } else if (timeRange === 'week') {
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const twoWeeksAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
        return createdAt >= twoWeeksAgo && createdAt < oneWeekAgo;
      } else if (timeRange === 'month') {
        const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
        return createdAt >= lastMonth && createdAt <= endOfLastMonth;
      } else if (timeRange === 'year') {
        const lastYear = now.getFullYear() - 1;
        return createdAt.getFullYear() === lastYear;
      }
      return false;
    });

    const total = filteredTickets.length;
    const previousTotal = previousTickets.length;
    
    const newTickets = filteredTickets.filter(t => t.status === 'new').length;
    const previousNewTickets = previousTickets.filter(t => t.status === 'new').length;
    
    const inProgress = filteredTickets.filter(t => t.status === 'in_progress' || t.status === 'on_hold' || t.status === 'pending').length;
    
    const resolved = filteredTickets.filter(t => t.status === 'resolved' || t.status === 'closed').length;
    const previousResolved = previousTickets.filter(t => t.status === 'resolved' || t.status === 'closed').length;
    
    // Trend Calculations
    const trendValue = previousTotal > 0 
      ? Math.round(((total - previousTotal) / previousTotal) * 100)
      : total > 0 ? 100 : 0;
      
    const newTrendValue = previousNewTickets > 0
      ? Math.round(((newTickets - previousNewTickets) / previousNewTickets) * 100)
      : newTickets > 0 ? 100 : 0;
      
    const resolvedTrendValue = previousResolved > 0
      ? Math.round(((resolved - previousResolved) / previousResolved) * 100)
      : resolved > 0 ? 100 : 0;

    // SLA Compliance
    const resolvedTickets = filteredTickets.filter(t => 
      (t.status === 'resolved' || t.status === 'closed') && 
      t.resolvedAt && 
      !isNaN(new Date(t.resolvedAt).getTime())
    );
    
    const slaCompliantCount = resolvedTickets.filter(t => {
      if (!t.dueDate || isNaN(new Date(t.dueDate).getTime())) return true; 
      return new Date(t.resolvedAt!) <= new Date(t.dueDate);
    }).length;
    
    const slaCompliance = resolvedTickets.length > 0 
      ? Math.round((slaCompliantCount / resolvedTickets.length) * 100) 
      : 100;

    // Avg Resolution Time (hours)
    const totalResolutionTime = resolvedTickets.reduce((acc, t) => {
      const created = new Date(t.createdAt).getTime();
      const resolved = new Date(t.resolvedAt!).getTime();
      return acc + (resolved - created);
    }, 0);
    const avgResolutionHours = resolvedTickets.length > 0
      ? Math.round((totalResolutionTime / resolvedTickets.length) / (1000 * 60 * 60) * 10) / 10
      : 0;

    // Channel Stats
    const ticketsByChannel = filteredTickets.reduce((acc, t) => {
      acc[t.channel] = (acc[t.channel] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Priority Stats
    const ticketsByPriority = filteredTickets.reduce((acc, t) => {
      acc[t.priority] = (acc[t.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Type Stats
    const ticketsByType = filteredTickets.reduce((acc, t) => {
      acc[t.type] = (acc[t.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalTickets: total,
      newTickets,
      inProgress,
      resolved,
      slaCompliance,
      ticketsByChannel,
      ticketsByPriority,
      ticketsByType,
      avgResolutionTime: avgResolutionHours,
      avgSatisfaction: avgSatisfaction.toFixed(1), // Format to 1 decimal place
      trends: {
        total: { value: trendValue, isPositive: trendValue >= 0 },
        new: { value: newTrendValue, isPositive: newTrendValue <= 0 }, // Fewer new tickets is better (green if negative)
        resolved: { value: resolvedTrendValue, isPositive: resolvedTrendValue >= 0 }
      }
    };
  }, [tickets, timeRange]);
  
  // ✅ Auto-redirect to tickets page when searching from dashboard
  useEffect(() => {
    if (searchQuery && searchQuery.trim() !== '') {
      console.log('🔍 Dashboard search detected, redirecting to tickets page with query:', searchQuery);
      onNavigate('/admin/tickets');
    }
  }, [searchQuery, onNavigate]);
  
  // ✅ Check if Pure Admin (admin without tier roles)
  const hasTierRole = user?.roles?.some(role => ['tier1', 'tier2', 'tier3'].includes(role)) || false;
  const isPureAdmin = user?.role === 'admin' && !hasTierRole;
  
  // ✅ Determine dashboard title based on role
  let dashboardTitle = '📊 แดชบอร์ด';
  let dashboardSubtitle = 'ยินดีต้อนรับ! นี่คือสิ่งที่เกิดขึ้นวันนี้';
  
  if (isPureAdmin) {
    dashboardTitle = '📊 Admin - แดชบอร์ดระบบ';
    dashboardSubtitle = 'ภาพรวมและสถิติระบบทั้งหมด (Monitoring Mode)';
  } else if (user?.roles?.includes('tier1')) {
    dashboardTitle = '📊 Tier 1 - แดชบอร์ดทีมตอบสนองลำดับแรก';
    dashboardSubtitle = 'ยินดีต้อนรับ! นี่คือสิ่งที่เกิดขึ้นวันนี้';
  } else if (user?.roles?.includes('tier2')) {
    dashboardTitle = '📊 Tier 2 - แดชบอร์ดทีมเทคนิคขั้นสูง';
    dashboardSubtitle = 'ยินดีต้อนรับ! นี่คือสิ่งที่เกิดขึ้นวันนี้';
  } else if (user?.roles?.includes('tier3')) {
    dashboardTitle = '📊 Tier 3 - แดชบอร์ดทีมผู้เชี่ยวชาญ';
    dashboardSubtitle = 'ยินดีต้อนรับ! นี่คือสิ่งที่เกิดขึ้นวันนี้';
  }
  
  // Get recent tickets sorted by creation date (newest first) and limit to 6 for better grid layout
  const recentTickets = [...tickets]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 6);

  // ✅ Filter recent tickets by search query
  const filteredRecentTickets = searchQuery
    ? recentTickets.filter(ticket =>
        ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.id.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : recentTickets;

  // ✅ Get recent surveys with details
  const recentSurveys = useMemo(() => {
    return [...surveys]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5)
      .map(survey => {
        const user = db.users.getById(survey.userId);
        const ticket = db.tickets.getHydratedById(survey.ticketId);
        return {
          ...survey,
          customerName: user?.fullName || 'Unknown',
          ticketNumber: ticket?.ticketNumber || 'Unknown'
        };
      });
  }, [surveys]);

  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      {/* Header */}
      <div className="rounded-lg bg-gradient-to-r from-blue-500 to-blue-600 p-6 text-white">
        <h1 className="mb-2 text-white">{dashboardTitle}</h1>
        <p className="text-blue-50">{dashboardSubtitle}</p>
      </div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-2">
          <Select defaultValue="today" onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">วันนี้</SelectItem>
              <SelectItem value="week">สัปดาห์นี้</SelectItem>
              <SelectItem value="month">เดือนนี้</SelectItem>
              <SelectItem value="year">ปีนี้</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="เคสทั้งหมด"
          value={stats.totalTickets}
          icon={Inbox}
          color="blue"
          trend={stats.trends.total}
        />
        <StatsCard
          title="เคสใหม่"
          value={stats.newTickets}
          icon={AlertTriangle}
          color="orange"
          trend={stats.trends.new}
        />
        <StatsCard
          title="กำลังดำเนินการ"
          value={stats.inProgress}
          icon={Clock}
          color="blue"
        />
        <StatsCard
          title="แก้ไขแล้ว"
          value={stats.resolved}
          icon={CheckCircle}
          color="green"
          trend={stats.trends.resolved}
        />
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* SLA Compliance */}
        <Card>
          <CardHeader>
            <CardTitle>การปฏิบัติตาม SLA</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8">
              <div className="relative">
                <svg className="h-40 w-40 -rotate-90 transform">
                  <circle
                    cx="80"
                    cy="80"
                    r="70"
                    stroke="#e5e7eb"
                    strokeWidth="12"
                    fill="none"
                  />
                  <circle
                    cx="80"
                    cy="80"
                    r="70"
                    stroke="#10b981"
                    strokeWidth="12"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 70}`}
                    strokeDashoffset={`${2 * Math.PI * 70 * (1 - stats.slaCompliance / 100)}`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl">{stats.slaCompliance}%</span>
                </div>
              </div>
              <p className="mt-4 text-sm text-gray-600">
                {stats.slaCompliance >= 90 ? 'ผลการปฏิบัติงานยอดเยี่ยม' : 'ต้องปรับปรุง'}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Tickets by Channel */}
        <Card>
          <CardHeader>
            <CardTitle>เคสตามช่องทาง</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(stats.ticketsByChannel)
                .sort(([, a], [, b]) => b - a) // Sort by count descending
                .map(([channel, count]) => {
                const percentage = (count / stats.totalTickets) * 100;
                const channelNames: Record<string, string> = {
                  web: 'เว็บไซต์',
                  email: 'อีเมล',
                  line: 'Line',
                  phone: 'โทรศัพท์',
                  portal: 'เว็บไซต์',
                  facebook: 'Facebook',
                  instagram: 'Instagram',
                  other: 'อื่นๆ'
                };
                return (
                  <div key={channel}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>{channelNames[channel.toLowerCase()] || channel}</span>
                      <span>{count}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-gray-200">
                      <div
                        className="h-full rounded-full bg-blue-600"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Priority Distribution & Type */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>เคสตามความสำคัญ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(stats.ticketsByPriority).map(([priority, count]) => {
                // Handle missing or invalid priority
                const safePriority = priority && priority !== 'undefined' ? priority : 'unknown';
                
                const colors: Record<string, string> = {
                  low: 'bg-gray-100 text-gray-700',
                  medium: 'bg-blue-100 text-blue-700',
                  high: 'bg-orange-100 text-orange-700',
                  critical: 'bg-red-100 text-red-700',
                  unknown: 'bg-slate-50 text-slate-500 border border-slate-200'
                };
                
                const labels: Record<string, string> = {
                  low: 'น้อย',
                  medium: 'ปานกลาง',
                  high: 'สูง',
                  critical: 'วิกฤติ',
                  unknown: 'ไม่ระบุ'
                };
                
                return (
                  <div key={priority} className={`rounded-lg p-4 ${colors[safePriority] || colors.unknown}`}>
                    <p className="text-2xl font-bold">{count}</p>
                    <p className="text-sm">{labels[safePriority] || priority}</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>เคสตามประเภท</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(stats.ticketsByType).map(([type, count]) => {
                 // Handle missing or invalid type
                const safeType = type && type !== 'undefined' ? type : 'unknown';

                const labels: Record<string, string> = {
                  incident: 'เหตุการณ์',
                  service_request: 'คำขอบริการ',
                  question: 'สอบถาม',
                  security_incident: 'ความปลอดภัย',
                  bug: 'ข้อผิดพลาด (Bug)',
                  feature: 'ขอฟีเจอร์ใหม่',
                  support: 'สนับสนุนทั่วไป',
                  unknown: 'ไม่ระบุ'
                };
                
                return (
                  <div key={type} className="rounded-lg bg-gray-50 p-4 border border-gray-100">
                    <p className="text-2xl font-bold">{count}</p>
                    <p className="text-sm text-gray-600">{labels[safeType] || type.replace(/_/g, ' ')}</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Tickets */}
      <Card className="border-blue-200">
        <CardHeader className="bg-blue-50">
          <div className="flex items-center justify-between">
            <CardTitle className="text-blue-900">
              {searchQuery ? `ผลการค้นหา: "${searchQuery}"` : 'เคสล่าสุด'}
            </CardTitle>
            <Button variant="outline" onClick={() => onNavigate('/admin/tickets')}>
              ดูทั้งหมด
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {searchQuery && filteredRecentTickets.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-gray-500">ไม่พบเคสที่ตรงกับการค้นหา "{searchQuery}"</p>
              <Button 
                variant="link" 
                className="mt-2"
                onClick={() => onNavigate('/admin/tickets')}
              >
                ค้นหาในเคสทั้งหมด →
              </Button>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredRecentTickets.map((ticket) => (
                <TicketCard
                  key={ticket.id}
                  ticket={ticket}
                  onClick={() => onNavigate('/admin/ticket', ticket.id)}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Performance Metrics */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm text-gray-600">เวลาเฉลี่ยในการแก้ไข</p>
              <p className="mt-1 text-2xl">{stats.avgResolutionTime} ชม.</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-600" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm text-gray-600">เจ้าหน้าที่ออนไลน์</p>
              <p className="mt-1 text-2xl">12</p>
            </div>
            <Users className="h-8 w-8 text-blue-600" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm text-gray-600">ความพึงพอใจลูกค้า</p>
              <p className="mt-1 text-2xl">{stats.avgSatisfaction}/5</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </CardContent>
        </Card>
      </div>

      {/* Recent Satisfaction Reviews */}
      <Card>
        <CardHeader>
          <CardTitle>ความคิดเห็นและความพึงพอใจล่าสุด</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {recentSurveys.length === 0 ? (
              <p className="text-center text-gray-500 py-4">ยังไม่มีการประเมินความพึงพอใจ</p>
            ) : (
              recentSurveys.map((survey) => (
                <div key={survey.id} className="flex flex-col gap-2 border-b border-gray-100 pb-4 last:border-0 last:pb-0 sm:flex-row sm:items-start sm:justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900">{survey.customerName}</span>
                      <span className="text-sm text-gray-500">สำหรับเคส {survey.ticketNumber}</span>
                    </div>
                    <p className="text-sm text-gray-600">"{survey.comment || 'ไม่มีความคิดเห็นเพิ่มเติม'}"</p>
                    <p className="text-xs text-gray-400">
                      {new Date(survey.createdAt).toLocaleDateString('th-TH', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                  <div className="flex shrink-0">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-4 w-4 ${
                          star <= survey.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}