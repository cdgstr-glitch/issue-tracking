import { ArrowLeft, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { useState, useEffect } from 'react';
import { db } from '../lib/mockDb/client';
import type { HydratedTicket } from '../lib/mockDb/client';
import { RetroactiveClosedTicketDetailAdmin } from '../components/tickets-staff/RetroactiveClosedTicketDetailAdmin';
import { RetroactiveClosedTicketDetailStaff } from '../components/tickets-staff/RetroactiveClosedTicketDetailStaff';

interface RetroactiveClosedTicketDetailPageProps {
  ticketId: string;
  onNavigate: (path: string, ticketId?: string) => void;
  isAdminContext?: boolean;
}
export default function RetroactiveClosedTicketDetailPage({ ticketId, onNavigate, isAdminContext = false }: RetroactiveClosedTicketDetailPageProps) {
  const { user } = useAuth();
  const [ticket, setTicket] = useState<HydratedTicket | null>(null);

  useEffect(() => {
    if (ticketId) {
      const foundTicket = db.tickets.getHydratedById(ticketId);
      setTicket(foundTicket);
    }
  }, [ticketId]);

  if (!ticket) {
    return (
      <div className="container mx-auto max-w-7xl p-4 sm:p-6 lg:p-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">ไม่พบเคส</h3>
            <p className="text-gray-600 mb-6">ไม่พบเคสที่คุณกำลังค้นหา</p>
            <Button onClick={() => onNavigate(-1)} variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              กลับ
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isAdminContext) {
    return (
      <RetroactiveClosedTicketDetailAdmin 
        ticket={ticket} 
        user={user} 
        onNavigate={onNavigate} 
      />
    );
  }

  return (
    <RetroactiveClosedTicketDetailStaff 
      ticket={ticket} 
      user={user} 
      onNavigate={onNavigate} 
    />
  );
}
