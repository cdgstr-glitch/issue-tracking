import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { Search, Mail, Phone, Clock, CheckCircle, TrendingUp, Users, Lock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface TeamManagementPageProps {
  onNavigate: (path: string) => void;
}
export default function TeamManagementPage({ onNavigate }: TeamManagementPageProps) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [tierFilter, setTierFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedTab, setSelectedTab] = useState('all');

  // ✅ Check if user can manage team (Admin only)
  const canManageTeam = user?.role === 'admin';

  // ✅ Fetch data from DB
  const users = db.users.getAll();
  const tickets = db.tickets.getAll();

  // ✅ Generate Team Members with stats
  const teamMembers = useMemo(() => {
    return users.filter(u => ['tier1', 'tier2', 'tier3', 'admin'].includes(u.role)).map(u => {
      const userTickets = tickets.filter(t => t.assignedTo === u.id);
      const activeTickets = userTickets.filter(t => t.status !== 'closed' && t.status !== 'resolved').length;
      const resolvedTickets = userTickets.filter(t => t.status === 'resolved' || t.status === 'closed').length;
      
      // Mock status
      const statuses = ['online', 'offline', 'busy'];
      const status = statuses[Math.floor(Math.random() * statuses.length)] as 'online' | 'offline' | 'busy';

      return {
        id: u.id,
        name: u.fullName,
        email: u.email,
        role: u.role,
        tier: u.tier,
        phone: u.phone,
        activeTickets,
        resolvedTickets,
        avgResolutionTime: (Math.random() * 5 + 1).toFixed(1), // Mock avg time
        status,
        specialty: u.role === 'tier3' ? ['Network', 'Security'] : [] // Mock specialty
      };
    });
  }, [users, tickets]);

  // Filter team members
  const filteredMembers = useMemo(() => {
    return teamMembers.filter(member => {
      // Tab filter
      if (selectedTab !== 'all') {
        const tabTier = parseInt(selectedTab.replace('tier', ''));
        if (member.tier !== tabTier) return false;
      }

      // Search filter
      if (searchQuery) {
        const search = searchQuery.toLowerCase();
        if (!member.name.toLowerCase().includes(search) &&
            !member.email.toLowerCase().includes(search)) {
          return false;
        }
      }

      // Tier filter
      if (tierFilter !== 'all' && member.tier?.toString() !== tierFilter) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'all' && member.status !== statusFilter) {
        return false;
      }

      return true;
    });
  }, [teamMembers, searchQuery, tierFilter, statusFilter, selectedTab]);

  // Calculate stats by tier
  const tierStats = useMemo(() => {
    return [1, 2, 3].map(tier => {
      const tierMembers = teamMembers.filter(m => m.tier === tier);
      const onlineCount = tierMembers.filter(m => m.status === 'online').length;
      const totalActive = tierMembers.reduce((sum, m) => sum + m.activeTickets, 0);
      const totalResolved = tierMembers.reduce((sum, m) => sum + m.resolvedTickets, 0);
      const avgTime = tierMembers.length > 0 
        ? tierMembers.reduce((sum, m) => sum + parseFloat(m.avgResolutionTime as string), 0) / tierMembers.length
        : 0;

      return {
        tier,
        total: tierMembers.length,
        online: onlineCount,
        activeTickets: totalActive,
        resolvedTickets: totalResolved,
        avgResolutionTime: avgTime.toFixed(1)
      };
    });
  }, [teamMembers]);

  // Status badge
  const StatusIndicator = ({ status }: { status: 'online' | 'offline' | 'busy' }) => {
    const colors = {
      online: 'bg-green-500',
      offline: 'bg-gray-400',
      busy: 'bg-amber-500'
    };

    const labels = {
      online: 'ออนไลน์',
      offline: 'ออฟไลน์',
      busy: 'ไม่ว่าง'
    };

    return (
      <div className="flex items-center gap-2">
        <div className={`h-2 w-2 rounded-full ${colors[status]}`} />
        <span className="text-sm text-gray-600">{labels[status]}</span>
      </div>
    );
  };

  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="mb-1">ทีม</h1>
          <p className="text-gray-600">
            {canManageTeam 
              ? 'จัดการและติดตามประสิทธิภาพของทีม' 
              : 'ดูสมาชิกในทีมและข้อมูลติดต่อ'}
          </p>
        </div>
        {canManageTeam && (
          <Button>
            <Users className="mr-2 h-4 w-4" />
            เพิ่มสมาชิกทีม
          </Button>
        )}
      </div>

      {/* Read-only Notice */}
      {!canManageTeam && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="flex items-start gap-3 p-4">
            <Lock className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-600" />
            <div>
              <p className="text-sm text-amber-900">
                <strong>โหมดดูอย่างเดียว:</strong> คุณสามารถดูข้อมูลสมาชิกและติดต่อเพื่อนร่วมทีมได้ 
                แต่ไม่สามารถแก้ไข เพิ่ม หรือลบสมาชิกได้
              </p>
              <p className="mt-1 text-xs text-amber-700">
                การจัดการสมาชิกต้องมีสิทธิ์ Admin เท่านั้น
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        {tierStats.map(stat => (
          <Card key={stat.tier}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Tier {stat.tier}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">สมาชิก</span>
                <span className="font-medium">{stat.online}/{stat.total} ออนไลน์</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">เคสที่กำลังดำเนินการ</span>
                <span className="font-medium">{stat.activeTickets}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">เคสที่แก้ไขแล้ว</span>
                <span className="font-medium">{stat.resolvedTickets}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">เวลาเฉลี่ย</span>
                <span className="font-medium">{stat.avgResolutionTime} ชม.</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">ทั้งหมด ({teamMembers.length})</TabsTrigger>
          <TabsTrigger value="tier1">Tier 1 ({tierStats[0].total})</TabsTrigger>
          <TabsTrigger value="tier2">Tier 2 ({tierStats[1].total})</TabsTrigger>
          <TabsTrigger value="tier3">Tier 3 ({tierStats[2].total})</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedTab} className="mt-6 space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="grid gap-4 md:grid-cols-4">
                <div className="md:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="ค้นหาชื่อหรืออีเมล..."
                      className="pl-9"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Select value={tierFilter} onValueChange={setTierFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="ทุก Tier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุก Tier</SelectItem>
                    <SelectItem value="1">Tier 1</SelectItem>
                    <SelectItem value="2">Tier 2</SelectItem>
                    <SelectItem value="3">Tier 3</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="สถานะทั้งหมด" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">สถานะทั้งหมด</SelectItem>
                    <SelectItem value="online">ออนไลน์</SelectItem>
                    <SelectItem value="busy">ไม่ว่าง</SelectItem>
                    <SelectItem value="offline">ออฟไลน์</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Team Members Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredMembers.map(member => (
              <Card key={member.id} className="overflow-hidden">
                <CardContent className="p-5">
                  {/* Header */}
                  <div className="mb-4 flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="mb-1">{member.name}</h3>
                      <Badge variant="secondary" className="mb-2">
                        {member.role === 'tier1' && 'Tier 1'}
                        {member.role === 'tier2' && 'Tier 2 (SA)'}
                        {member.role === 'tier3' && 'Tier 3 (Specialist)'}
                        {member.role === 'admin' && 'Admin'}
                      </Badge>
                    </div>
                    <StatusIndicator status={member.status} />
                  </div>

                  {/* Contact Info */}
                  <div className="mb-4 space-y-2 border-b pb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="h-4 w-4" />
                      <span className="truncate">{member.email}</span>
                    </div>
                    {member.phone && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Phone className="h-4 w-4" />
                        <span>{member.phone}</span>
                      </div>
                    )}
                  </div>

                  {/* Stats */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>กำลังดำเนินการ</span>
                      </div>
                      <span className="font-medium">{member.activeTickets} เคส</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <CheckCircle className="h-4 w-4" />
                        <span>แก้ไขแล้ว</span>
                      </div>
                      <span className="font-medium">{member.resolvedTickets} เคส</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <TrendingUp className="h-4 w-4" />
                        <span>เวลาเฉลี่ย</span>
                      </div>
                      <span className="font-medium">{member.avgResolutionTime} ชม.</span>
                    </div>
                  </div>

                  {/* Specialty */}
                  {member.specialty && member.specialty.length > 0 && (
                    <div className="mt-4 border-t pt-4">
                      <p className="mb-2 text-xs text-gray-600">ความเชี่ยวชาญ</p>
                      <div className="flex flex-wrap gap-1">
                        {member.specialty.map((spec, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Empty State */}
          {filteredMembers.length === 0 && (
            <Card>
              <CardContent className="py-16 text-center">
                <Users className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                <h3 className="mb-2 text-gray-900">ไม่พบสมาชิกทีม</h3>
                <p className="text-gray-600">
                  ไม่มีสมาชิกทีมที่ตรงกับตัวกรองที่เลือก
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}