import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';
import { ArrowLeft, Search, FolderOpen, Save, X } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { products as ALL_PRODUCTS } from '../lib/mockDb/data/products';
import { toast } from 'sonner@2.0.3';
import { StandardPagination } from '../components/StandardPagination';

interface ProjectSettingsPageProps {
  onNavigate: (path: string) => void;
}
export default function ProjectSettingsPage({ onNavigate }: ProjectSettingsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // ✅ Fetch data from DB
  const projects = db.projects.getAll();
  const organizations = db.organizations.getAll();

  // Filter projects
  const filteredProjects = projects.filter(project => {
    const org = organizations.find(o => o.id === project.organizationId);
    const searchLower = searchQuery.toLowerCase();
    
    return (
      project.name.toLowerCase().includes(searchLower) ||
      project.code.toLowerCase().includes(searchLower) ||
      org?.name.toLowerCase().includes(searchLower) ||
      org?.shortName.toLowerCase().includes(searchLower)
    );
  });

  // Pagination
  const totalPages = Math.ceil(filteredProjects.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedProjects = filteredProjects.slice(startIndex, startIndex + itemsPerPage);

  // Get selected project
  const selectedProject = projects.find(p => p.id === selectedProjectId);
  const selectedOrganization = selectedProject 
    ? organizations.find(o => o.id === selectedProject.organizationId)
    : null;

  // Handle project selection
  const handleProjectSelect = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    setSelectedProjectId(projectId);
    setSelectedProducts(project?.purchasedProducts || []);
    setHasChanges(false);
  };

  // Handle product toggle
  const handleProductToggle = (productValue: string) => {
    setSelectedProducts(prev => {
      const newProducts = prev.includes(productValue)
        ? prev.filter(p => p !== productValue)
        : [...prev, productValue];
      
      setHasChanges(true);
      return newProducts;
    });
  };

  // Handle save
  const handleSave = () => {
    // TODO: Save to database
    // For now, just show toast
    toast.success(`บันทึกผลิตภัณฑ์สำหรับโครงการ "${selectedProject?.code}" เรียบร้อย`);
    setHasChanges(false);
    
    // In real app, you would update the database here
    // For demo, we'll just update the mock data in memory
    if (selectedProject) {
      // ✅ Update DB (mock update in-memory object reference since getAll returns references in simple mock DB)
      // In a real DB, we would call db.projects.update(selectedProject.id, { purchasedProducts: selectedProducts });
      selectedProject.purchasedProducts = selectedProducts;
    }
  };

  // Handle clear selection
  const handleClearProject = () => {
    setSelectedProjectId(null);
    setSelectedProducts([]);
    setHasChanges(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto max-w-7xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <Button
              variant="ghost"
              onClick={() => onNavigate('/admin/settings')}
              className="gap-2 mb-4"
            >
              <ArrowLeft className="h-4 w-4" />
              กลับไปหน้าตั้งค่า
            </Button>
            <h1 className="text-3xl mb-2">จัดการผลิตภัณฑ์โครงการ</h1>
            <p className="text-gray-600">
              เลือกว่าแต่ละโครงการซื้อผลิตภัณฑ์ใดของเราบ้าง
            </p>
          </div>
          {selectedProjectId && (
            <Button 
              onClick={handleSave} 
              className="gap-2"
              disabled={!hasChanges}
            >
              <Save className="h-4 w-4" />
              บันทึกการเปลี่ยนแปลง
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Project List */}
          <Card>
            <CardHeader>
              <CardTitle>รายการโครงการทั้งหมด</CardTitle>
              <CardDescription>
                เลือกโครงการเพื่อจัดการผลิตภัณฑ์
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="ค้นหาโครงการ..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pl-10"
                />
              </div>

              {/* Project List */}
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {paginatedProjects.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    ไม่พบโครงการที่ค้นหา
                  </div>
                ) : (
                  paginatedProjects.map((project) => {
                    const org = organizations.find(o => o.id === project.organizationId);
                    const isSelected = selectedProjectId === project.id;
                    const productCount = project.purchasedProducts?.length || 0;
                    
                    return (
                      <div
                        key={project.id}
                        onClick={() => handleProjectSelect(project.id)}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          isSelected
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-blue-300 hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {org?.shortName}
                            </Badge>
                            <span className="text-xs text-gray-500">{project.code}</span>
                          </div>
                          {productCount > 0 ? (
                            <Badge className="bg-green-100 text-green-700 text-xs">
                              {productCount} ผลิตภัณฑ์
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-xs text-gray-500">
                              ยังไม่ตั้งค่า
                            </Badge>
                          )}
                        </div>
                        <p className="font-medium text-sm line-clamp-2">{project.name}</p>
                        {org && (
                          <p className="text-xs text-gray-500 mt-1">{org.name}</p>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="pt-4 border-t">
                  <StandardPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                  />
                </div>
              )}

              <div className="text-xs text-gray-500 text-center pt-2">
                แสดง {paginatedProjects.length} จาก {filteredProjects.length} โครงการ
              </div>
            </CardContent>
          </Card>

          {/* Right: Product Selection */}
          <Card>
            {!selectedProjectId ? (
              // Empty State
              <CardContent className="flex flex-col items-center justify-center py-20">
                <FolderOpen className="h-16 w-16 text-gray-300 mb-4" />
                <p className="text-gray-500 text-center">
                  เลือกโครงการจากรายการทางซ้าย<br />
                  เพื่อจัดการผลิตภัณฑ์
                </p>
              </CardContent>
            ) : (
              <>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>ผลิตภัณฑ์ที่โครงการซื้อ</CardTitle>
                      <CardDescription className="mt-2">
                        เลือกผลิตภัณฑ์ที่โครงการนี้ซื้อไว้
                      </CardDescription>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearProject}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Project Info */}
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="bg-white">
                        {selectedOrganization?.shortName}
                      </Badge>
                      <span className="text-sm text-gray-600">{selectedProject?.code}</span>
                    </div>
                    <p className="font-medium text-sm">{selectedProject?.name}</p>
                    <p className="text-xs text-gray-600 mt-1">{selectedOrganization?.name}</p>
                  </div>

                  {/* Product Checkboxes */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-base font-semibold">
                        เลือกผลิตภัณฑ์ ({selectedProducts.length}/{ALL_PRODUCTS.length})
                      </Label>
                      {selectedProducts.length > 0 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedProducts([]);
                            setHasChanges(true);
                          }}
                        >
                          ล้างทั้งหมด
                        </Button>
                      )}
                    </div>

                    <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                      {ALL_PRODUCTS.map((product) => {
                        const isChecked = selectedProducts.includes(product.value);
                        
                        return (
                          <div
                            key={product.value}
                            className={`flex items-start space-x-3 p-3 border rounded-lg transition-colors ${
                              isChecked
                                ? 'border-blue-300 bg-blue-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <Checkbox
                              id={product.value}
                              checked={isChecked}
                              onCheckedChange={() => handleProductToggle(product.value)}
                              className="mt-1"
                            />
                            <div className="flex-1">
                              <Label
                                htmlFor={product.value}
                                className="cursor-pointer font-medium"
                              >
                                {product.label}
                              </Label>
                              <p className="text-xs text-gray-600 mt-0.5">
                                {product.description}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Info Message */}
                  {selectedProducts.length === 0 && (
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        ⚠️ <strong>คำเตือน:</strong> ยังไม่ได้เลือกผลิตภัณฑ์ใดๆ<br />
                        Staff จะเห็นผลิตภัณฑ์ทั้งหมด 9 ตัวในหน้าแจ้งเคส
                      </p>
                    </div>
                  )}

                  {selectedProducts.length === 1 && (
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800">
                        ℹ️ <strong>หมายเหตุ:</strong> เลือกไว้ 1 ผลิตภัณฑ์<br />
                        ระบบจะเลือกอัตโนมัติและ disable dropdown ให้
                      </p>
                    </div>
                  )}

                  {selectedProducts.length > 1 && (
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-sm text-green-800">
                        ✅ <strong>ดีมาก!</strong> เลือกไว้ {selectedProducts.length} ผลิตภัณฑ์<br />
                        Staff จะเห็นเฉพาะผลิตภัณฑ์ที่เลือกไว้เท่านั้น
                      </p>
                    </div>
                  )}
                </CardContent>
              </>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
