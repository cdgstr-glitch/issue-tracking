import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { StatsCard } from '../components/StatsCard';
import { Shield, AlertCircle, Server, Cloud } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { TicketCard } from '../components/TicketCard';
import { Button } from '../components/ui/button';
import { useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

interface SpecialistDashboardProps {
  onNavigate: (path: string, ticketId?: string) => void;
  searchQuery?: string;
}
export default function SpecialistDashboard({ onNavigate, searchQuery = '' }: SpecialistDashboardProps) {
  
  // ✅ Auto-redirect to tickets page when searching from dashboard
  useEffect(() => {
    if (searchQuery && searchQuery.trim() !== '') {
      console.log('🔍 Specialist Dashboard search detected, redirecting to tickets page with query:', searchQuery);
      onNavigate('/admin/tickets');
    }
  }, [searchQuery, onNavigate]);
  
  // ✅ Fetch tickets from DB
  const tickets = db.tickets.getAll();
  const tier3Tickets = tickets.filter(t => t.stage === 'tier3');

  // ✅ Dynamic Calculations
  const securityIssues = tickets.filter(t => t.category === 'Security').length;
  // Vendor Escalations: Mock logic - check if description mentions "vendor" or "provider"
  const vendorEscalations = tickets.filter(t => 
    t.description.toLowerCase().includes('vendor') || 
    t.description.toLowerCase().includes('provider') ||
    t.description.toLowerCase().includes('aws') ||
    t.description.toLowerCase().includes('azure')
  ).length;

  // ✅ Filter tier3 tickets by search query
  const filteredTier3Tickets = searchQuery
    ? tier3Tickets.filter(ticket =>
        ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.id.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : tier3Tickets;

  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      {/* Header */}
      <div>
        <h1 className="mb-1">Tier 3 - Specialist Dashboard</h1>
        <p className="text-gray-600">Critical incidents and infrastructure-level support</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Critical Incidents"
          value={filteredTier3Tickets.length}
          icon={AlertCircle}
          color="red"
        />
        <StatsCard
          title="Security Issues"
          value={securityIssues}
          icon={Shield}
          color="orange"
        />
        <StatsCard
          title="Infrastructure"
          value={filteredTier3Tickets.length}
          icon={Server}
          color="blue"
        />
        <StatsCard
          title="Vendor Escalations"
          value={vendorEscalations}
          icon={Cloud}
          color="gray"
        />
      </div>

      {/* Critical Tickets */}
      <Card className="border-red-200 bg-red-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <CardTitle className="text-red-900">Critical Incidents</CardTitle>
            </div>
            <span className="rounded-full bg-red-600 px-3 py-1 text-sm text-white">
              {filteredTier3Tickets.filter(t => t.priority === 'critical').length} Active
            </span>
          </div>
        </CardHeader>
        <CardContent>
          {filteredTier3Tickets.filter(t => t.priority === 'critical').length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2">
              {filteredTier3Tickets.filter(t => t.priority === 'critical').map((ticket) => (
                <TicketCard
                  key={ticket.id}
                  ticket={ticket}
                  onClick={() => onNavigate('/admin/ticket', ticket.id)}
                />
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-red-700">
              <Shield className="mx-auto mb-3 h-12 w-12 text-red-400" />
              <p>No critical incidents at the moment</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* All Tier 3 Tickets */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>All Tier 3 Tickets</CardTitle>
            <Button variant="outline" onClick={() => onNavigate('/admin/tickets')}>
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {filteredTier3Tickets.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredTier3Tickets.map((ticket) => (
                <TicketCard
                  key={ticket.id}
                  ticket={ticket}
                  onClick={() => onNavigate('/admin/ticket', ticket.id)}
                />
              ))}
            </div>
          ) : (
            <div className="py-12 text-center text-gray-500">
              <Server className="mx-auto mb-3 h-12 w-12 text-gray-400" />
              <p>No Tier 3 tickets assigned at the moment</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Vendor Handoff */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Cloud Provider Contacts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p>AWS Support</p>
                <p className="text-xs text-gray-600">Premium Support</p>
              </div>
              <Button variant="outline" size="sm">
                Contact
              </Button>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p>Azure Support</p>
                <p className="text-xs text-gray-600">Enterprise Plan</p>
              </div>
              <Button variant="outline" size="sm">
                Contact
              </Button>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p>Google Cloud</p>
                <p className="text-xs text-gray-600">Standard Support</p>
              </div>
              <Button variant="outline" size="sm">
                Contact
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Specialist Tools</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start">
              <Server className="mr-2 h-4 w-4" />
              Infrastructure Dashboard
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Shield className="mr-2 h-4 w-4" />
              Security Console
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Cloud className="mr-2 h-4 w-4" />
              Cloud Management
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <AlertCircle className="mr-2 h-4 w-4" />
              Incident Response Plan
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Incident Types */}
      <Card>
        <CardHeader>
          <CardTitle>Incident Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="rounded-lg bg-red-100 p-4 text-center">
              <Server className="mx-auto mb-2 h-8 w-8 text-red-600" />
              <p className="text-2xl text-red-900">
                {tickets.filter(t => t.category === 'Hardware' || t.category === 'Network').length}
              </p>
              <p className="text-sm text-red-700">Infrastructure</p>
            </div>
            <div className="rounded-lg bg-orange-100 p-4 text-center">
              <Shield className="mx-auto mb-2 h-8 w-8 text-orange-600" />
              <p className="text-2xl text-orange-900">
                {securityIssues}
              </p>
              <p className="text-sm text-orange-700">Security</p>
            </div>
            <div className="rounded-lg bg-blue-100 p-4 text-center">
              <Cloud className="mx-auto mb-2 h-8 w-8 text-blue-600" />
              <p className="text-2xl text-blue-900">
                {tickets.filter(t => t.category === 'Cloud' || t.description.toLowerCase().includes('cloud')).length}
              </p>
              <p className="text-sm text-blue-700">Cloud Issues</p>
            </div>
            <div className="rounded-lg bg-gray-100 p-4 text-center">
              <AlertCircle className="mx-auto mb-2 h-8 w-8 text-gray-600" />
              <p className="text-2xl text-gray-900">
                {tickets.filter(t => t.category !== 'Hardware' && t.category !== 'Network' && t.category !== 'Security' && t.category !== 'Cloud').length}
              </p>
              <p className="text-sm text-gray-700">Other</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}