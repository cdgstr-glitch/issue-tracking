import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { BarChart3, Building2, MessageSquare, Users, Clock, Download } from 'lucide-react';
import { Button } from '../components/ui/button';
import { ExportReportModal } from '../components/ExportReportModal';
import DashboardReport from '../components/reports/DashboardReport';
import OrganizationReport from '../components/reports/OrganizationReport';
import ChannelReport from '../components/reports/ChannelReport';
import StaffReport from '../components/reports/StaffReport';
import SLAReport from '../components/reports/SLAReport';

type ReportTab = 'dashboard' | 'organization' | 'channel' | 'staff' | 'sla';

export default function ReportsPage() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<ReportTab>('dashboard');
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Permission check: Only admin sees all reports, staff/tier see limited data
  const canViewAllReports = currentUser?.role === 'admin';
  const canViewStaffReport = currentUser?.role && ['admin', 'tier1', 'tier2', 'tier3', 'staff'].includes(currentUser.role);

  const tabs = [
    {
      id: 'dashboard' as ReportTab,
      label: 'ภาพรวม',
      icon: BarChart3,
      visible: true,
    },
    {
      id: 'organization' as ReportTab,
      label: 'ตามหน่วยงาน',
      icon: Building2,
      visible: canViewAllReports,
    },
    {
      id: 'channel' as ReportTab,
      label: 'ตามช่องทาง',
      icon: MessageSquare,
      visible: canViewAllReports,
    },
    {
      id: 'staff' as ReportTab,
      label: 'ตามเจ้าหน้าที่',
      icon: Users,
      visible: canViewStaffReport,
    },
    {
      id: 'sla' as ReportTab,
      label: 'SLA Performance',
      icon: Clock,
      visible: canViewAllReports,
    },
  ];

  const visibleTabs = tabs.filter(tab => tab.visible);

  const handleExport = () => {
    setIsExportModalOpen(true);
  };

  const getCurrentReportLabel = () => {
    const currentTab = tabs.find(tab => tab.id === activeTab);
    return currentTab?.label || 'รายงาน';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-semibold mb-2">รายงานและสถิติ</h1>
            <p className="text-sm text-gray-600">
              วิเคราะห์ข้อมูลและประสิทธิภาพการทำงานของระบบ
            </p>
          </div>
          <Button onClick={handleExport} className="gap-2">
            <Download className="h-4 w-4" />
            ส่งออกรายงาน
          </Button>
        </div>

        {/* Tab Navigation */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8" aria-label="Tabs">
            {visibleTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    flex items-center gap-2 py-4 px-1 border-b-2 font-medium text-sm
                    ${isActive
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }
                  `}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="min-h-[600px]">
          {activeTab === 'dashboard' && <DashboardReport />}
          {activeTab === 'organization' && canViewAllReports && <OrganizationReport />}
          {activeTab === 'channel' && canViewAllReports && <ChannelReport />}
          {activeTab === 'staff' && canViewStaffReport && <StaffReport />}
          {activeTab === 'sla' && canViewAllReports && <SLAReport />}
        </div>
      </div>
      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        reportType={getCurrentReportLabel()}
      />
    </div>
  );
}