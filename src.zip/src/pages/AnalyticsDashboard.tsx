import { useState, useMemo } from 'react';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { db } from '../lib/mockDb/client';
import { useAuth } from '../contexts/AuthContext';
import { can, CAPABILITIES } from '../lib/permissions';
import { 
  ArrowLeft, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  BarChart3,
  Download,
  Target,
  Activity
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface AnalyticsDashboardProps {
  onNavigate: (path: string) => void;
}

// Helper function to calculate time difference in hours
const getHoursDifference = (start: Date, end: Date): number => {
  return Math.abs(end.getTime() - start.getTime()) / (1000 * 60 * 60);
};

// Helper function to format hours to readable string
const formatHours = (hours: number): string => {
  if (hours < 1) return `${Math.round(hours * 60)} นาที`;
  if (hours < 24) return `${hours.toFixed(1)} ชั่วโมง`;
  const days = Math.floor(hours / 24);
  const remainingHours = Math.round(hours % 24);
  return `${days} วัน ${remainingHours} ชั่วโมง`;
};
export default function AnalyticsDashboard({ onNavigate }: AnalyticsDashboardProps) {
  const { user, activeRole } = useAuth(); // ✅ Get current user
  const [selectedProject, setSelectedProject] = useState<string>('all');
  const [dateRange, setDateRange] = useState<string>('30days');

  const tickets = db.tickets.getAll();
  const allProjects = db.projects.getAll();
  const organizations = db.organizations.getAll();

  // ✅ Determine if User is Admin
  const isAdmin = activeRole === 'admin' || can(user, CAPABILITIES.MANAGE_SETTINGS);

  // ✅ 1. Filter Projects for Dropdown based on User's Responsibility (projectIds)
  const availableProjects = useMemo(() => {
    // If Admin, show all projects
    if (isAdmin) return allProjects;
    
    // If User has specific projectIds (defined in mock DB for Staff/Tier1-3), filter by them
    if (user?.projectIds && user.projectIds.length > 0) {
      return allProjects.filter(p => user.projectIds!.includes(p.id));
    }
    
    // Fallback: If no projectIds but has "My Cases", maybe show projects from those cases?
    // For now, return empty or all? 
    // Let's assume strict project responsibility. If no projectIds, return empty.
    return []; 
  }, [isAdmin, user, allProjects]);

  // Filter tickets based on Role and Selections
  const filteredTickets = useMemo(() => {
    let filtered = tickets.filter(t => t.status !== 'new');
    
    // 1. Role-based Scope Filter
    if (!isAdmin) {
        // A. Filter by Available Projects
        // Only show tickets belonging to projects the user is responsible for
        const allowedProjectIds = availableProjects.map(p => p.id);
        filtered = filtered.filter(t => t.projectId && allowedProjectIds.includes(t.projectId));

        // B. Filter by "My Cases" (Performance View)
        // User explicitly asked for "See graph of my own cases"
        if (user) {
            filtered = filtered.filter(t => {
                const isAssignee = t.assignedTo === user.id;
                const isResolver = t.resolvedBy === user.id;
                const isInTimeline = db.timeline.getByTicketId(t.id).some(e => e.userId === user.id);
                return isAssignee || isResolver || isInTimeline;
            });
        }
    }

    // 2. Project Selection Filter (Dropdown)
    if (selectedProject !== 'all') {
      filtered = filtered.filter(t => t.projectId === selectedProject);
    }

    // 3. Date Range Filter
    const now = new Date();
    const daysAgo = dateRange === '7days' ? 7 : dateRange === '30days' ? 30 : 90;
    const startDate = new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000);
    filtered = filtered.filter(t => new Date(t.createdAt) >= startDate);

    return filtered;
  }, [selectedProject, dateRange, tickets, isAdmin, user, availableProjects]);

  // Calculate analytics
  const analytics = useMemo(() => {
    // Initialize counters
    let tier1ToTier2Times: number[] = [];
    let tier2ToTier3Times: number[] = [];
    let tier3ToClosedTimes: number[] = [];
    let totalResolutionTimes: number[] = [];
    let slaBreached = 0;
    let slaCompliant = 0;

    filteredTickets.forEach(ticket => {
      const timeline = db.timeline.getByTicketId(ticket.id);
      
      // Find tier transitions
      const tier1Event = timeline.find(e => e.status === 'tier1');
      const tier2Event = timeline.find(e => e.status === 'tier2');
      const tier3Event = timeline.find(e => e.status === 'tier3');
      const resolvedEvent = timeline.find(e => e.status === 'resolved');
      const closedEvent = timeline.find(e => e.status === 'closed');

      // Calculate T1 → T2 time
      if (tier1Event && tier2Event) {
        const hours = getHoursDifference(new Date(tier1Event.timestamp), new Date(tier2Event.timestamp));
        tier1ToTier2Times.push(hours);
      }

      // Calculate T2 → T3 time
      if (tier2Event && tier3Event) {
        const hours = getHoursDifference(new Date(tier2Event.timestamp), new Date(tier3Event.timestamp));
        tier2ToTier3Times.push(hours);
      }

      // Calculate T3 → T1 time (for closing)
      if (tier3Event) {
        const tier3Index = timeline.findIndex(e => e.status === 'tier3');
        const tier1AfterTier3Event = timeline.slice(tier3Index + 1).find(e => e.status === 'tier1');
        
        if (tier1AfterTier3Event && (resolvedEvent || closedEvent)) {
          const endEvent = closedEvent || resolvedEvent;
          if (endEvent) {
             const hours = getHoursDifference(new Date(tier1AfterTier3Event.timestamp), new Date(endEvent.timestamp));
             tier3ToClosedTimes.push(hours);
          }
        }
      }

      // Calculate total resolution time
      if (ticket.resolvedAt || ticket.closedAt) {
        const endDate = ticket.closedAt || ticket.resolvedAt;
        if (endDate) {
            const hours = getHoursDifference(new Date(ticket.createdAt), new Date(endDate));
            totalResolutionTimes.push(hours);
        }
      }

      // Check SLA compliance
      if (ticket.status === 'resolved' || ticket.status === 'closed') {
        const endDate = ticket.closedAt || ticket.resolvedAt || new Date();
        const isBreached = new Date(endDate) > new Date(ticket.dueDate);
        if (isBreached) {
          slaBreached++;
        } else {
          slaCompliant++;
        }
      }
    });

    const avg = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

    return {
      avgTier1ToTier2: avg(tier1ToTier2Times),
      avgTier2ToTier3: avg(tier2ToTier3Times),
      avgTier3ToClosed: avg(tier3ToClosedTimes),
      avgTotalResolution: avg(totalResolutionTimes),
      slaCompliance: slaCompliant + slaBreached > 0 
        ? (slaCompliant / (slaCompliant + slaBreached)) * 100 
        : 0,
      totalCases: filteredTickets.length,
      resolvedCases: filteredTickets.filter(t => t.status === 'resolved' || t.status === 'closed').length,
      slaBreached,
      slaCompliant
    };
  }, [filteredTickets]);

  // Prepare chart data for resolution time by priority
  const resolutionByPriority = useMemo(() => {
    const groups: Record<string, number[]> = {
      critical: [],
      high: [],
      medium: [],
      low: [],
      normal: [] 
    };

    filteredTickets.forEach(ticket => {
      if (ticket.resolvedAt || ticket.closedAt) {
        const endDate = ticket.closedAt || ticket.resolvedAt;
        if (endDate) {
            const hours = getHoursDifference(new Date(ticket.createdAt), new Date(endDate));
            const priorityKey = groups[ticket.priority] !== undefined ? ticket.priority : 'medium';
            groups[priorityKey].push(hours);
        }
      }
    });

    return [
      { priority: 'Critical', avgTime: groups.critical.length > 0 ? groups.critical.reduce((a, b) => a + b, 0) / groups.critical.length : 0, color: '#dc3545' },
      { priority: 'High', avgTime: groups.high.length > 0 ? groups.high.reduce((a, b) => a + b, 0) / groups.high.length : 0, color: '#ff8c00' },
      { priority: 'Medium', avgTime: groups.medium.length > 0 ? groups.medium.reduce((a, b) => a + b, 0) / groups.medium.length : 0, color: '#0066cc' },
      { priority: 'Low', avgTime: groups.low.length > 0 ? groups.low.reduce((a, b) => a + b, 0) / groups.low.length : 0, color: '#6c757d' },
    ];
  }, [filteredTickets]);

  // Prepare chart data for tier flow
  const tierFlowData = [
    { tier: 'T1 → T2', avgTime: analytics.avgTier1ToTier2, color: '#0066cc' },
    { tier: 'T2 → T3', avgTime: analytics.avgTier2ToTier3, color: '#ff8c00' },
    { tier: 'T3 → T1 เพื่อปิด', avgTime: analytics.avgTier3ToClosed, color: '#28a745' },
  ];

  // SLA pie chart data
  const slaData = [
    { name: 'ตรงเวลา', value: analytics.slaCompliant, color: '#28a745' },
    { name: 'เกินเวลา', value: analytics.slaBreached, color: '#dc3545' },
  ];

  const handleExport = () => {
    alert('ฟีเจอร์ส่งออกรายงานจะพร้อมใช้งานในเร็วๆ นี้');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => onNavigate(isAdmin ? '/admin' : '/admin/tickets')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              กลับ
            </Button>
            <div>
              <h1 className="text-3xl mb-2 flex items-center gap-2">
                <BarChart3 className="h-8 w-8" />
                {isAdmin ? 'รายงานวิเคราะห์ภาพรวม' : 'วิเคราะห์ผลการดำเนินงานของฉัน'}
              </h1>
              <p className="text-gray-600">
                {isAdmin 
                  ? 'วิเคราะห์เวลาดำเนินการและประสิทธิภาพการทำงานทั้งระบบ' 
                  : 'วิเคราะห์สถิติจากเคสที่คุณมีส่วนร่วมรับผิดชอบ'}
              </p>
            </div>
          </div>
          <Button onClick={handleExport} className="gap-2">
            <Download className="h-4 w-4" />
            ส่งออกรายงานวิเคราะห์
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>ตัวกรอง</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">โครงการ</label>
                <Select value={selectedProject} onValueChange={setSelectedProject}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทั้งหมด</SelectItem>
                    {/* ✅ Use availableProjects for the Dropdown Options */}
                    {availableProjects.map(project => {
                      const organization = organizations.find(o => o.id === project.organizationId);
                      return (
                        <SelectItem key={project.id} value={project.id}>
                          {organization?.organizationShortName || ''} - {project.projectCode}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">ช่วงเวลา</label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">7 วันที่ผ่านมา</SelectItem>
                    <SelectItem value="30days">30 วันที่ผ่านมา</SelectItem>
                    <SelectItem value="90days">90 วันที่ผ่านมา</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">เคสที่เกี่ยวข้อง</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl">{analytics.totalCases}</div>
                <Activity className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">เคสที่แก้ไขแล้ว</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl">{analytics.resolvedCases}</div>
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">เวลาแก้ไขเฉลี่ย</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl">{formatHours(analytics.avgTotalResolution)}</div>
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">SLA Compliance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl">{analytics.slaCompliance.toFixed(1)}%</div>
                <Target className={`h-8 w-8 ${analytics.slaCompliance >= 80 ? 'text-green-500' : 'text-red-500'}`} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Tier Flow Chart */}
          <Card>
            <CardHeader>
              <CardTitle>เวลาเฉลี่ยการส่งต่อระหว่าง Tier</CardTitle>
              <CardDescription>แสดงเวลาเฉลี่ยที่ใช้ในการส่งต่อระหว่างแต่ละ Tier</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={tierFlowData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="tier" />
                  <YAxis label={{ value: 'ชั่วโมง', angle: -90, position: 'insideLeft' }} />
                  <Tooltip 
                    formatter={(value: number) => formatHours(value)}
                    labelStyle={{ color: '#000' }}
                  />
                  <Bar dataKey="avgTime" fill="#0066cc">
                    {tierFlowData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Resolution Time by Priority */}
          <Card>
            <CardHeader>
              <CardTitle>เวลาแก้ไขเฉลี่ยตาม Priority</CardTitle>
              <CardDescription>เปรียบเทียบเวลาแก้ไขเฉลี่ยในแต่ละระดับความสำคัญ</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={resolutionByPriority}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="priority" />
                  <YAxis label={{ value: 'ชั่วโมง', angle: -90, position: 'insideLeft' }} />
                  <Tooltip 
                    formatter={(value: number) => formatHours(value)}
                    labelStyle={{ color: '#000' }}
                  />
                  <Bar dataKey="avgTime" fill="#ff8c00">
                    {resolutionByPriority.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* SLA Compliance Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle>SLA Compliance</CardTitle>
              <CardDescription>สัดส่วนเคสที่ปิดตรงเวลาและเกินเวลา</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={slaData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {slaData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Summary Stats */}
          <Card>
            <CardHeader>
              <CardTitle>สรุปข้อมูล</CardTitle>
              <CardDescription>รายละเอียดเวลาเฉลี่ยในแต่ละขั้นตอน</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="text-sm font-medium">T1 → T2</span>
                  <span className="text-lg">{formatHours(analytics.avgTier1ToTier2)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span className="text-sm font-medium">T2 → T3</span>
                  <span className="text-lg">{formatHours(analytics.avgTier2ToTier3)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="text-sm font-medium">T3 → T1 เพื่อปิด</span>
                  <span className="text-lg">{formatHours(analytics.avgTier3ToClosed)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-100 rounded-lg border-2 border-gray-300">
                  <span className="font-medium">รวมเวลาเฉลี่ย</span>
                  <span className="text-xl">{formatHours(analytics.avgTotalResolution)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Info Box */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900">
                <p className="font-medium mb-1">หมายเหตุ:</p>
                <ul className="list-disc list-inside space-y-1 text-blue-800">
                  <li>ข้อมูลคำนวณจากเคสที่ดำเนินการแล้วเท่านั้น (ไม่รวมเคสสถานะ 'new')</li>
                  <li>เวลาเฉลี่ยคำนวณจาก Timeline Events ของแต่ละเคส</li>
                  <li>SLA Compliance คำนวณจากเคสที่ปิดแล้วเทียบกับ Due Date</li>
                  <li>{isAdmin ? 'แสดงข้อมูลภาพรวมทั้งระบบ' : 'แสดงเฉพาะข้อมูลเคสที่คุณมีส่วนเกี่ยวข้อง ในโครงการที่คุณรับผิดชอบ'}</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}