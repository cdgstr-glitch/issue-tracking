/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import { Label } from '../components/ui/label';
import { db } from '../lib/mockDb/client';
import { PriorityBadge } from '../components/PriorityBadge';
import { ChannelBadge } from '../components/ChannelBadge';
import { SLAIndicator } from '../components/SLAIndicator';
import { AssignedBadge } from '../components/AssignedBadge';
import { formatRelativeTime, formatDate } from '../lib/utils';
import { can, CAPABILITIES, isTier1, isPureStaff } from '../lib/permissions';
import { Search, Filter, Download, Hash } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Ticket } from '../types';
import { Pagination } from '../components/Pagination';

type Props = {
  // ✅ ให้ตรงกับ App.tsx navigate signature (ใช้แค่ 3 params แรก)
  onNavigate: (path: string, ticketId?: string, sourcePath?: string) => void;

  // ✅ App.tsx ส่งมา
  currentPath?: string; // เช่น "/admin/tickets" "/admin/pending"
  searchQuery?: string;
  onSearchChange?: (value: string) => void;
};

export function TicketListPage({
  onNavigate,
  currentPath = '/admin/tickets',
  searchQuery = '',
  onSearchChange,
}: Props) {
  const { user, activeRole } = useAuth(); // ✅ ใช้ activeRole ตาม pattern ของ Sidebar.tsx

  // ✅ detail path ตาม role — staff ใช้ /staff-ticket-detail, tier/admin ใช้ /admin/ticket
  const detailPath = isPureStaff(user) ? '/staff-ticket-detail' : '/admin/ticket';

  // ✅ ใช้ search จาก Header ถ้ามี onSearchChange / searchQuery ส่งมา
  const [localSearchTerm, setLocalSearchTerm] = useState('');
  const effectiveSearch = onSearchChange ? searchQuery : localSearchTerm;

  const setSearch = (v: string) => {
    if (onSearchChange) onSearchChange(v);
    else setLocalSearchTerm(v);
  };

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [organizationFilter, setOrganizationFilter] = useState<string>('all');
  const [assignedFilter, setAssignedFilter] = useState<string>('all');

  const [sortBy, setSortBy] = useState<'updatedAt' | 'createdAt' | 'priority' | 'sla'>('updatedAt');
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 20;
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  // Data
  const tickets = useMemo(() => db.tickets.getAll(), []);

  const allProjects = useMemo(
    () =>
      db.projects.getAll().map((p) => ({
        value: p.id,
        label: p.projectName, // ✅ ตรงกับ Project type
        organizationId: p.organizationId,
      })),
    []
  );

  const allOrganizations = useMemo(
    () =>
      db.organizations.getAll().map((o) => ({
        value: o.id,
        label: o.organizationName, // ✅ ตรงกับ Organization type
        shortName: o.organizationShortName, // ✅ ตรงกับ Organization type
      })),
    []
  );

  // Derived options based on selection
  const filteredProjectsByOrg = useMemo(() => {
    if (organizationFilter === 'all') return allProjects;
    return allProjects.filter((p) => p.organizationId === organizationFilter);
  }, [allProjects, organizationFilter]);

  // =========================
  // ✅ SSoT: TICKET_FILTERING_LOGIC_FINAL.md
  // Filtering ตาม currentPath + activeRole (ตาม pattern ของ Sidebar.tsx)
  // =========================
  const pathFilteredTickets: Ticket[] = useMemo(() => {
    let result = [...tickets];

    // ✅ SSoT: Staff มี CAPABILITY.VIEW_OWN_CREATED_TICKETS เท่านั้น
    // filter ให้เห็นเฉพาะเคสที่ตัวเองสร้าง (createdByUserId === user.id)
    if (user && isPureStaff(user)) {
      result = result.filter((t) => (t as any).createdByUserId === user.id);
      return result; // Staff ไม่มี menu filtering เพิ่มเติม
    }

    // =========================
    // ✅ Menu-based filtering (ใช้ activeRole ตาม Sidebar.tsx pattern)
    // ตาม TICKET_FILTERING_LOGIC_FINAL.md
    // =========================

    if (currentPath === '/admin/pending') {
      // ===== เมนู: รอดำเนินการ =====
      if (activeRole === 'tier1' || activeRole === 'supervisor') {
        // Tier1: เห็น status 'new' + 'pending' ที่ stage = tier1
        // และ (assignedTo = null หรือ assignedTo = ตัวเอง)
        result = result.filter((t) => {
          const ticket = t as any;
          const isStageT1 = ticket.stage === 'tier1';
          const isNewOrPending = ['new', 'pending'].includes(ticket.status);
          const isUnassigned = ticket.assignedTo === null || ticket.assignedTo === undefined;
          const isAssignedToMe = ticket.assignedTo === user?.id;
          return isStageT1 && isNewOrPending && (isUnassigned || isAssignedToMe);
        });
      } else if (activeRole === 'tier2') {
        // Tier2: เห็น status 'pending' ที่ stage = tier2 และ assignedTo = ตัวเอง
        result = result.filter((t) => {
          const ticket = t as any;
          return (
            ticket.stage === 'tier2' &&
            ticket.status === 'pending' &&
            ticket.assignedTo === user?.id
          );
        });
      } else if (activeRole === 'tier3') {
        // Tier3: เห็น status 'pending' ที่ stage = tier3 และ assignedTo = ตัวเอง
        result = result.filter((t) => {
          const ticket = t as any;
          return (
            ticket.stage === 'tier3' &&
            ticket.status === 'pending' &&
            ticket.assignedTo === user?.id
          );
        });
      } else if (activeRole === 'admin') {
        // Admin: เห็น 'new' + 'pending' ทุก Tier
        result = result.filter((t) => {
          const ticket = t as any;
          return ['new', 'pending'].includes(ticket.status);
        });
      }
    } else if (currentPath === '/admin/my-tickets') {
      // ===== เมนู: งานของฉัน =====
      // ทุก role: assignedTo = ตัวเอง และ status = 'in_progress'
      if (user) {
        result = result.filter((t) => {
          const ticket = t as any;
          return ticket.assignedTo === user.id && ticket.status === 'in_progress';
        });
      }
    } else if (currentPath === '/admin/resolved') {
      // ===== เมนู: แก้ไขแล้ว =====
      if (activeRole === 'tier1' || activeRole === 'supervisor') {
        // Tier1: เห็น resolved + closed ที่ resolvedBy หรือ closedBy = ตัวเอง
        result = result.filter((t) => {
          const ticket = t as any;
          const isResolvedOrClosed = ['resolved', 'closed'].includes(ticket.status);
          const isMyResolution = ticket.resolvedBy === user?.id || ticket.closedBy === user?.id;
          return isResolvedOrClosed && isMyResolution;
        });
      } else if (activeRole === 'tier2') {
        // Tier2: เห็นเคสที่ส่งกลับ T1 เพื่อปิด (escalationType = 'for_closure')
        result = result.filter((t) => {
          const ticket = t as any;
          // ต้อง stage = tier1 และ status = resolved
          if (ticket.stage !== 'tier1' || ticket.status !== 'resolved') return false;

          // หา escalation ที่ from = tier2, to = tier1, escalatedBy = user.id, escalationType = for_closure
          const ticketEscalations = db.escalations.getByTicketId(ticket.id);
          return ticketEscalations.some(
            (esc: any) =>
              esc.fromTier === 'tier2' &&
              esc.toTier === 'tier1' &&
              esc.escalatedBy === user?.id &&
              esc.escalationType === 'for_closure'
          );
        });
      } else if (activeRole === 'tier3') {
        // Tier3: เห็นเคสที่ส่งกลับ T1 เพื่อปิด (escalationType = 'for_closure')
        result = result.filter((t) => {
          const ticket = t as any;
          if (ticket.stage !== 'tier1' || ticket.status !== 'resolved') return false;

          const ticketEscalations = db.escalations.getByTicketId(ticket.id);
          return ticketEscalations.some(
            (esc: any) =>
              esc.fromTier === 'tier3' &&
              esc.toTier === 'tier1' &&
              esc.escalatedBy === user?.id &&
              esc.escalationType === 'for_closure'
          );
        });
      } else if (activeRole === 'admin') {
        // Admin: เห็น resolved + closed ทั้งหมด
        result = result.filter((t) => {
          const ticket = t as any;
          return ['resolved', 'closed'].includes(ticket.status);
        });
      }
    } else if (currentPath === '/admin/tickets') {
      // ===== เมนู: เคสทั้งหมด =====
      if (activeRole === 'tier1' || activeRole === 'supervisor') {
        // Tier1: เห็นทุก stage (ไม่ filter เพิ่ม)
      } else if (activeRole === 'tier2') {
        // Tier2: เห็น tier2 + tier3
        result = result.filter((t) => {
          const ticket = t as any;
          return ['tier2', 'tier3'].includes(ticket.stage);
        });
      } else if (activeRole === 'tier3') {
        // Tier3: เห็นเฉพาะ tier3
        result = result.filter((t) => {
          const ticket = t as any;
          return ticket.stage === 'tier3';
        });
      } else if (activeRole === 'admin') {
        // Admin: เห็นทั้งหมด (ไม่ filter เพิ่ม)
      }
    }

    return result;
  }, [tickets, currentPath, user, activeRole]);

  // =========================
  // ✅ Additional filters (Search + dropdown filters)
  // =========================
  const filteredTickets: Ticket[] = useMemo(() => {
    let result = [...pathFilteredTickets];

    // Search
    if (effectiveSearch.trim()) {
      const q = effectiveSearch.trim().toLowerCase();
      result = result.filter((t) => {
        const haystack = [
          (t as any).ticketNumber,
          (t as any).title,
          (t as any).description,
          (t as any).customerName,
          (t as any).customerEmail,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        return haystack.includes(q);
      });
    }

    // Status / Stage / Priority / Channel
    if (statusFilter !== 'all') result = result.filter((t) => (t as any).status === statusFilter);
    if (stageFilter !== 'all') result = result.filter((t) => (t as any).stage === stageFilter);
    if (priorityFilter !== 'all') result = result.filter((t) => (t as any).priority === priorityFilter);
    if (channelFilter !== 'all') result = result.filter((t) => (t as any).channel === channelFilter);

    // Project
    if (projectFilter !== 'all') result = result.filter((t) => (t as any).projectId === projectFilter);

    // Organization (ผ่าน project.organizationId) — relational-first
    if (organizationFilter !== 'all') {
      result = result.filter((t) => {
        const proj = db.projects.getById((t as any).projectId);
        return proj?.organizationId === organizationFilter;
      });
    }

    // Assigned
    if (assignedFilter !== 'all') {
      if (assignedFilter === 'assigned') result = result.filter((t) => Boolean((t as any).assignedTo));
      if (assignedFilter === 'unassigned') result = result.filter((t) => !(t as any).assignedTo);
      if (assignedFilter === 'me') result = result.filter((t) => (t as any).assignedTo === user?.id);
    }

    // Sorting
    const priorityRank: Record<string, number> = { low: 1, medium: 2, high: 3, critical: 4 };
    result.sort((a, b) => {
      let va: any;
      let vb: any;

      if (sortBy === 'updatedAt') {
        va = new Date((a as any).updatedAt).getTime();
        vb = new Date((b as any).updatedAt).getTime();
      } else if (sortBy === 'createdAt') {
        va = new Date((a as any).createdAt).getTime();
        vb = new Date((b as any).createdAt).getTime();
      } else if (sortBy === 'priority') {
        va = priorityRank[(a as any).priority] ?? 0;
        vb = priorityRank[(b as any).priority] ?? 0;
      } else {
        va = (a as any).slaDueAt ? new Date((a as any).slaDueAt).getTime() : Number.POSITIVE_INFINITY;
        vb = (b as any).slaDueAt ? new Date((b as any).slaDueAt).getTime() : Number.POSITIVE_INFINITY;
      }

      if (va === vb) return 0;
      const cmp = va > vb ? 1 : -1;
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [
    pathFilteredTickets,
    effectiveSearch,
    statusFilter,
    stageFilter,
    priorityFilter,
    channelFilter,
    projectFilter,
    organizationFilter,
    assignedFilter,
    sortBy,
    sortDir,
    user?.id,
  ]);

  // Reset page to 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [
    effectiveSearch,
    statusFilter,
    stageFilter,
    priorityFilter,
    channelFilter,
    projectFilter,
    organizationFilter,
    assignedFilter,
    sortBy,
    sortDir,
    currentPath, // ✅ reset page เมื่อเปลี่ยนเมนู
  ]);

  // Reset project filter if not in org after org change
  useEffect(() => {
    if (projectFilter === 'all') return;
    const stillValid = filteredProjectsByOrg.some((p) => p.value === projectFilter);
    if (!stillValid) setProjectFilter('all');
  }, [filteredProjectsByOrg, projectFilter]);

  // Pagination slice
  const totalPages = Math.max(1, Math.ceil(filteredTickets.length / ITEMS_PER_PAGE));
  const paginatedTickets = filteredTickets.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const canExport = user ? can(user, CAPABILITIES.MANAGE_SETTINGS) : false; // ✅ ใช้ MANAGE_SETTINGS แทน
  const canViewAll = user ? can(user, CAPABILITIES.VIEW_ALL_TICKETS) : false;
  const canViewQueue = user ? can(user, CAPABILITIES.ACCEPT_TICKET) : false; // ✅ ใช้ ACCEPT_TICKET แทน

  // =========================
  // ✅ Dynamic page title based on currentPath
  // =========================
  const getPageTitle = () => {
    switch (currentPath) {
      case '/admin/pending':
        return 'รอดำเนินการ';
      case '/admin/my-tickets':
        return 'งานของฉัน';
      case '/admin/resolved':
        return 'แก้ไขแล้ว';
      case '/admin/tickets':
      default:
        return 'เคสทั้งหมด';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="text-xl">{getPageTitle()}</CardTitle>
            <div className="text-sm text-muted-foreground">
              {canViewAll ? 'มุมมองทั้งหมด' : canViewQueue ? 'มุมมองคิวงาน' : 'มุมมองของคุณ'} • {filteredTickets.length} รายการ
            </div>
          </div>

          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Hash className="w-4 h-4" />
                  Sort
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuItem onClick={() => setSortBy('updatedAt')}>Updated</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('createdAt')}>Created</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('priority')}>Priority</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('sla')}>SLA</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))}>
                  Direction: {sortDir.toUpperCase()}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="outline"
              className="gap-2"
              disabled={!canExport}
              onClick={() => {
                const payload = filteredTickets.map((t) => ({
                  id: (t as any).id,
                  ticketNumber: (t as any).ticketNumber,
                  title: (t as any).title,
                  status: (t as any).status,
                  stage: (t as any).stage,
                  priority: (t as any).priority,
                  updatedAt: (t as any).updatedAt,
                }));
                console.log('[export tickets]', payload);
                alert('Export (stub) — ดูข้อมูลใน console');
              }}
            >
              <Download className="w-4 h-4" />
              Export
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Search + Filters */}
          <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div className="flex-1 space-y-2">
              <Label>ค้นหา</Label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  className="pl-9"
                  placeholder="ค้นหาจากเลขเคส / หัวข้อ / รายละเอียด / ลูกค้า..."
                  value={effectiveSearch}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  Filters
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-[380px]">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>สถานะ</Label>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือกสถานะ" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          <SelectItem value="new">ใหม่</SelectItem>
                          <SelectItem value="pending">รอดำเนินการ</SelectItem>
                          <SelectItem value="in_progress">กำลังดำเนินการ</SelectItem>
                          <SelectItem value="on_hold">รอลูกค้า/รอข้อมูล</SelectItem>
                          <SelectItem value="resolved">แก้ไขแล้ว</SelectItem>
                          <SelectItem value="closed">ปิดงาน</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Stage</Label>
                      <Select value={stageFilter} onValueChange={setStageFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือก stage" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          <SelectItem value="tier1">Tier1</SelectItem>
                          <SelectItem value="tier2">Tier2</SelectItem>
                          <SelectItem value="tier3">Tier3</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือก priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Channel</Label>
                      <Select value={channelFilter} onValueChange={setChannelFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือกช่องทาง" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          <SelectItem value="web">Web</SelectItem>
                          <SelectItem value="email">Email</SelectItem>
                          <SelectItem value="phone">Phone</SelectItem>
                          <SelectItem value="line">LINE</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>องค์กร</Label>
                      <Select value={organizationFilter} onValueChange={setOrganizationFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือกองค์กร" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          {allOrganizations.map((org) => (
                            <SelectItem key={org.value} value={org.value}>
                              {org.shortName || org.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>โครงการ</Label>
                      <Select value={projectFilter} onValueChange={setProjectFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือกโครงการ" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          {filteredProjectsByOrg.map((p) => (
                            <SelectItem key={p.value} value={p.value}>
                              {p.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 col-span-2">
                      <Label>Assigned</Label>
                      <Select value={assignedFilter} onValueChange={setAssignedFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="เลือกการมอบหมาย" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ทั้งหมด</SelectItem>
                          <SelectItem value="assigned">Assigned</SelectItem>
                          <SelectItem value="unassigned">Unassigned</SelectItem>
                          <SelectItem value="me">Assigned to me</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSearch('');
                        setStatusFilter('all');
                        setStageFilter('all');
                        setPriorityFilter('all');
                        setChannelFilter('all');
                        setOrganizationFilter('all');
                        setProjectFilter('all');
                        setAssignedFilter('all');
                        setSortBy('updatedAt');
                        setSortDir('desc');
                      }}
                    >
                      Reset
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Table */}
          <div className="overflow-auto border rounded-lg">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr className="text-left">
                  <th className="px-3 py-2 w-[160px]">เลขเคส</th>
                  <th className="px-3 py-2">รายละเอียด</th>
                  <th className="px-3 py-2 w-[140px]">Project</th>
                  <th className="px-3 py-2 w-[110px]">Priority</th>
                  <th className="px-3 py-2 w-[110px]">Channel</th>
                  <th className="px-3 py-2 w-[140px]">Assigned</th>
                  <th className="px-3 py-2 w-[160px]">Updated</th>
                </tr>
              </thead>

              <tbody>
                {paginatedTickets.map((t) => {
                  // ✅ SSoT (relational-first):
                  // getAll() returns HydratedTicket — ใช้ FK field โดยตรงผ่าน db client
                  // ไม่ re-lookup ผ่าน nested object เพื่อรักษา single source of truth

                  // project: nullable FK — lookup ด้วย projectId โดยตรง
                  const project = (t as any).projectId
                    ? db.projects.getById((t as any).projectId)
                    : undefined;

                  // organization: lookup จาก ticket.organizationId โดยตรง (ไม่ผ่าน project)
                  // เพราะ ticket.organizationId คือ FK หลัก — มีแม้ projectId จะ null
                  const org = (t as any).organizationId
                    ? db.organizations.getById((t as any).organizationId)
                    : undefined;

                  // products: lookup จาก pivot table ticket_products (SSoT)
                  // HydratedTicket.products มีอยู่แล้วจาก hydrateTicketRow
                  const ticketProducts: any[] = (t as any).products ?? [];

                  return (
                    <tr
                      key={(t as any).id}
                      className="border-t hover:bg-muted/30 cursor-pointer"
                      onClick={() => onNavigate(detailPath, (t as any).id, currentPath)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onNavigate(detailPath, (t as any).id, currentPath);
                        }
                      }}
                    >
                      <td className="px-3 py-2 font-medium">
                        <div className="flex items-center gap-2">
                          <span>{(t as any).ticketNumber}</span>
                          <SLAIndicator ticket={t as any} compact />
                        </div>
                        <div className="text-xs text-muted-foreground">{formatDate((t as any).createdAt)}</div>
                      </td>

                      <td className="px-3 py-2">
                        <div className="font-medium line-clamp-1">{(t as any).title}</div>
                        <div className="text-xs text-muted-foreground line-clamp-1">{(t as any).description}</div>
                        {/* ✅ ลบ ViewerBadge ออก: ไม่มีข้อมูล real-time viewers ใน mock layer */}
                        <div className="mt-1 flex flex-wrap gap-2">
                          <AssignedBadge ticket={t as any} />
                        </div>
                      </td>

                      <td className="px-3 py-2">
                        {/* ✅ SSoT: แสดง org จาก ticket.organizationId โดยตรง, project เป็น optional */}
                        <div className="flex flex-col gap-1">
                          {org && (
                            <span className="inline-flex items-center rounded-md border border-gray-200 bg-white px-2 py-0.5 text-xs font-semibold text-gray-900 shadow-sm w-fit">
                              {org.organizationShortName || org.organizationName}
                            </span>
                          )}
                          {project ? (
                            <span className="text-sm font-medium text-gray-600">
                              {project.projectCode}
                            </span>
                          ) : (
                            !org && <span className="text-muted-foreground">-</span>
                          )}
                          {ticketProducts.length > 0 && (
                            <span className="text-xs text-muted-foreground">
                              {ticketProducts.map((p: any) => p.productName || p.label).join(', ')}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-3 py-2">
                        <PriorityBadge priority={(t as any).priority} />
                      </td>

                      <td className="px-3 py-2">
                        <ChannelBadge channel={(t as any).channel} />
                      </td>

                      {/* ✅ SSoT: AssignedBadge รับ ticket แล้ว lookup user เองผ่าน db.users.getById */}
                      <td className="px-3 py-2">
                        <AssignedBadge ticket={t as any} size="md" />
                      </td>

                      <td className="px-3 py-2">
                        <div className="text-xs">{formatDate((t as any).updatedAt)}</div>
                        <div className="text-xs text-muted-foreground">{formatRelativeTime((t as any).updatedAt)}</div>
                      </td>
                    </tr>
                  );
                })}

                {filteredTickets.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-3 py-8 text-center text-muted-foreground">
                      ไม่พบรายการ
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            totalItems={filteredTickets.length}
            itemsPerPage={ITEMS_PER_PAGE}
          />

          {user && isTier1(user) && <div className="text-xs text-muted-foreground">คุณกำลังดูในบทบาท Tier1</div>}
        </CardContent>
      </Card>
    </div>
  );
}

export default TicketListPage;
