import { AssignmentInfoCard } from '../components/AssignmentInfoCard';
import { db } from '../lib/mockDb/client';
import { getAssigneeDisplayName } from '../lib/ticketUtils';
import { useState, useEffect } from 'react';
import type { HydratedTicket } from '../lib/mockDb/client';
import { TimelineEvent, TicketStatus } from '../types';
import { formatDate } from '../lib/utils';
import { can, CAPABILITIES, isTier1, isPureStaff, isCustomer, isOperator } from '../lib/permissions';
import { extractHashtags, removeHashtags } from '../lib/hashtagUtils';
import { toast } from 'sonner@2.0.3';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { StatusBadge } from '../components/StatusBadge';
import { PriorityBadge } from '../components/PriorityBadge';
import { ChannelBadge } from '../components/ChannelBadge';
import { SLAIndicator } from '../components/SLAIndicator';
import { CommentSection } from '../components/comments/CommentSection';
import { TicketTimeline } from '../components/TicketTimeline';
import { AttachmentGallery } from '../components/AttachmentGallery';
import { TicketActions } from '../components/TicketActions';
import { TicketStatusAlert } from '../components/TicketStatusAlert';
import { ReadOnlyModeBanner } from '../components/ReadOnlyModeBanner';
import { TakeoverConfirmationModal } from '../components/TakeoverConfirmationModal';
import { 
  ArrowLeft, 
  User, 
  Mail, 
  Phone, 
  Calendar,
  Clock,
  Tag,
  ArrowUpCircle,
  CheckCircle,
  MessageSquare,
  Paperclip,
  AlertCircle,
  UserCheck,
  PauseCircle,
  PlayCircle,
  XCircle,
  Info,
  Bell,
  Undo2,
  AlertTriangle,
  UserX,
  Briefcase
} from 'lucide-react';
import { ProjectBadge } from '../components/ProjectBadge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { useAuth } from '../contexts/AuthContext';
import { SatisfactionSurvey } from '../components/SatisfactionSurvey';

interface TicketDetailPageProps {
  ticketId: string;
  onNavigate: (path: string, ticketId?: string) => void;
  sourcePath?: string; // ✅ เพิ่ม sourcePath
}
export default function TicketDetailPage({ ticketId, onNavigate, sourcePath }: TicketDetailPageProps) {
  const { user } = useAuth();
  
  // ✅ Initial load from DB
  const [ticket, setTicket] = useState<HydratedTicket | null>(() => db.tickets.getHydratedById(ticketId));
  
  // ✅ Refresh ticket data when ticketId changes
  useEffect(() => {
    const latestTicket = db.tickets.getHydratedById(ticketId);
    if (latestTicket) {
      console.log('�� [TicketDetailPage] Refreshing ticket data:', {
        ticketId,
        oldStatus: ticket?.status,
        newStatus: latestTicket.status,
      });
      setTicket(latestTicket);
    }
  }, [ticketId]); 
  
  const [showEscalateDialog, setShowEscalateDialog] = useState(false);
  const [showResolveDialog, setShowResolveDialog] = useState(false);
  const [showHoldDialog, setShowHoldDialog] = useState(false);
  const [comment, setComment] = useState('');
  const [isInternal, setIsInternal] = useState(false); // ✅ เพิ่ม state สำหรับเลือกประเภท comment
  const [escalateNote, setEscalateNote] = useState('');
  const [escalateTier, setEscalateTier] = useState('');
  const [resolveNote, setResolveNote] = useState('');
  const [holdReason, setHoldReason] = useState('');
  
  const [showProjectModal, setShowProjectModal] = useState(false); // 🆕 Modal สำหรับเลือกโครงการ
  
  if (!ticket) {
    return <div>Ticket not found</div>;
  }

  // ✅ SSoT: HydratedTicket มี flat fields จาก hydrateTicketRow แล้ว
  // ไม่ต้อง re-lookup — organizationShortName, projectName, projectCode มาจาก client.ts
  // organization ผ่าน ticket.organizationId (FK หลัก) ซึ่ง hydrateTicketRow map ให้แล้ว
  
  // ✅ SSoT: products จาก pivot ticket_products ผ่าน HydratedTicket.products[]
  // ไม่มี ticket.product field ใน Ticket schema
  const ticketProducts: any[] = (ticket as any).products ?? [];
  
  // Takeover banner state
  const [showTakeoverBanner, setShowTakeoverBanner] = useState(false);
  const [takeoverInfo, setTakeoverInfo] = useState<{
    ticketNumber: string;
    previousViewer: string;
    currentStatus: TicketStatus; // ✅ เพิ่ม status ของเคส
    isAlreadyInProgress: boolean; // ✅ บอกว่าเคสรับแล้วหรือยัง
  } | null>(null);

  // ✅ Read-only mode และ Takeover modal state
  const [showTakeoverModal, setShowTakeoverModal] = useState(false);
  
  // ✅ ตรวจสอบว่าเป็น Read-only mode หรือไม่
  // Read-only เมื่อ: user เป็น tier/admin/staff และเคสไม่ใช่ของตัวเอง
  // แต่ไม่แสดง Takeover card ถ้า user เป็นผู้ส่งต่อเอง (เพราะมีปุ่มยกเลิกการส่งต่ออยู่แล้ว)
  const isReadOnly = 
    user?.id && 
    ticket.assignedTo && 
    ticket.assignedTo !== user.id && 
    ticket.assignedBy !== user.id && // ✅ ไม่แสดงถ้าฉันเป็นผู้ส่งต่อ
    !isCustomer(user); // ✅ รองรับ multi-role

  // Check for takeover flag on mount
  useEffect(() => {
    const takeoverData = localStorage.getItem('takeoverTicket');
    if (takeoverData) {
      try {
        const data = JSON.parse(takeoverData);
        if (data.ticketId === ticketId) {
          setTakeoverInfo({
            ticketNumber: data.ticketNumber,
            previousViewer: data.previousViewer,
            currentStatus: data.currentStatus, // ✅ เก็บ status ไว้
            isAlreadyInProgress: data.isAlreadyInProgress // ✅ เก็บสถานะรับเคสไว้
          });
          setShowTakeoverBanner(true);
        }
      } catch (error) {
        console.error('Failed to parse takeover data:', error);
      }
    }
  }, [ticketId]);

  // Clear takeover banner
  const handleDismissTakeoverBanner = () => {
    setShowTakeoverBanner(false);
    localStorage.removeItem('takeoverTicket');
  };
  
  // Determine back path based on user role
  const getBackPath = () => {
    // ✅ 1. ใช้ sourcePath ที่ส่งมาจาก props ก่อน (Priority สูงสุด)
    if (sourcePath) {
      return sourcePath;
    }
    
    // ✅ 2. ตรวจสอบว่ามาจากหน้าไหน โดยดูจาก localStorage
    const previousPath = localStorage.getItem('ticketListPath');
    
    if (user?.role === 'customer') {
      return '/tickets';  // Customer Portal
    }
    if (user?.role === 'staff') {
      return '/track';    // Staff Journey - รายการเคสที่ลูกค้าแจ้
    }
    
    // ✅ 3. ถ้ามี previousPath ที่เก็บไว้ ให้กลับไปที่นั่น
    if (previousPath && previousPath.startsWith('/admin/')) {
      return previousPath;
    }
    
    return '/admin/tickets';  // Default fallback
  };
  
  // ✅ รับเคสจาก Takeover Banner (Simplified - no project selection needed)
  const handleAcceptFromTakeoverBanner = () => {
    // ✅ Staff เลือกโครงการไว้แล้ว ดังนั้น Tier1 รับเคสได้เลย
    console.log('Accepting ticket from takeover banner');
    const updatedTicket = { 
      ...ticket, 
      status: 'in_progress' as TicketStatus, 
      assignedTo: user?.id || ticket.assignedTo 
    };
    setTicket(updatedTicket);
    
    // TODO: Update DB logic would go here
    
    toast.success('รับเคสสำเร็จ - คุณสามารถเริ่มดำเนินการได้แล้ว');
    handleDismissTakeoverBanner();
  };
  
  // รับเคส (Assign to Self)
  const handleAssignToSelf = () => {
    console.log('Assigning ticket to self');
    setTicket({ ...ticket, status: 'in_progress', assignedTo: user?.fullName || 'คุณ' } as any); 
  };

  // ส่งต่อไปยัง Tier 2/3
  const handleEscalate = () => {
    if (!escalateTier) return;
    console.log('Escalating to', escalateTier, 'with note:', escalateNote);
    setTicket({ ...ticket, status: 'in_progress', stage: (escalateTier === 'tier2' ? 'tier2' : 'tier3') } as any);
    setShowEscalateDialog(false);
    setEscalateNote('');
    setEscalateTier('');
  };

  // แก้ไขเคสสำเร็จ
  const handleResolve = () => {
    console.log('Resolving ticket with note:', resolveNote);
    setTicket({ ...ticket, status: 'resolved' });
    setShowResolveDialog(false);
    setResolveNote('');
  };

  // ระงับเคส (Hold)
  const handleHold = () => {
    console.log('Holding ticket with reason:', holdReason);
    setTicket({ ...ticket, status: 'on_hold' });
    setShowHoldDialog(false);
    setHoldReason('');
  };

  // ดำเนินการต่อ (Resume from Waiting)
  const handleResume = () => {
    console.log('Resuming ticket');
    setTicket({ ...ticket, status: 'in_progress' });
  };

  // ปิดเคส
  const handleClose = () => {
    console.log('Closing ticket');
    setTicket({ ...ticket, status: 'closed' });
  };

  // ✅ Takeover เคส
  const handleTakeover = (reason?: string) => {
    if (!user?.id || !user?.fullName) return; // ✅ เปลี่ยนจาก user?.name เป็น user?.fullName

    const previousOwner = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;

    console.log('Taking over ticket from', previousOwner?.fullName, 'with reason:', reason);

    // อัพเดตคส
    const updatedTicket = {
      ...ticket,
      assignedTo: user.id,
      previousAssignee: ticket.assignedTo,
      assignedBy: user.id,
      assignedAt: new Date(),
      updatedAt: new Date().toISOString(),
    };

    // Add timeline event via db
    db.timeline.add({
      id: `timeline-${Date.now()}-takeover`,
      ticketId: ticket.id,
      timestamp: new Date(),
      type: 'assignment' as const,
      description: `🔄 Takeover โดย ${user.fullName}${previousOwner ? ` จาก ${previousOwner.fullName}` : ''}${reason ? ` - ${reason}` : ''}`,
      userId: user.id,
      user: user.fullName,
      isInternal: true
    });

    setTicket(updatedTicket);

    // TODO: Update DB logic would go here

    // แสดง toast
    toast.success(
      `Takeover เคสสำเร็จ - คุณได้รับเคส ${ticket.ticketNumber} ${previousOwner ? `จาก ${previousOwner.fullName}` : ''}`,
      {
        description: previousOwner?.email ? `ระบบได้ส่งอีเมลแจ้งเตือนไปที่ ${previousOwner.email} แล้ว` : undefined,
        duration: 5000
      }
    );

    setShowTakeoverModal(false);
  };

  const handleAddComment = () => {
    if (!comment.trim()) return; // ✅ ป้องกันส่ง comment ว่าง

    // ✅ สร้าง comment object ใหม่
    const newComment = {
      id: `comment-${Date.now()}`,
      ticketId: ticket.id,
      author: user?.fullName || 'Unknown',
      authorRole: user?.role || 'staff',
      content: comment.trim(),
      isInternal: isInternal, // ✅ ใช้ค่าจาก state
      attachments: [], 
      createdAt: new Date()
    };

      // ✅ Persist to relational table (Source of Truth)
      db.comments.add(newComment as any);

      // ✅ Re-hydrate ticket (Read Model) like Laravel API Resource
      const refreshed = db.tickets.getHydratedById(ticket.id);
      if (refreshed) {
        setTicket(refreshed as any);
      } else {
        // fallback: keep current ticket but update timestamp
        setTicket({ ...ticket, updatedAt: new Date().toISOString() } as any);
      }

    // ✅ แสดง toast แจ้เตือน
    toast.success(
      isInternal 
        ? 'เพิ่มหมายเหตุภายในเรียบร้อย' 
        : 'เพิ่มความคิดเห็นเรียบร้อย'
    );

    // ✅ Clear form
    setComment('');
    setIsInternal(false); // Reset กลับไปเป็น public
  };

  // Handle ticket updates from TicketActions
  const handleTicketUpdate = (updates: Partial<Ticket>) => {
    setTicket((prev) => {
      if (!prev) return prev;
      const newTicket = { ...prev, ...updates };
      
      // สร้าง timeline event ตามการเปลี่ยนแปลง
      const newTimelineEvents: TimelineEvent[] = [];
      const timestamp = new Date();
      const userName = user?.fullName || 'Unknown';
      
      // 1. Status changed
      if (updates.status && updates.status !== prev.status) {
        const statusDescriptions: Record<TicketStatus, string> = {
          'new': 'เคสใหม่ถูกสร้าง',
          'tier1': 'ส่งต่อไปยัง Tier 1',
          'tier2': 'ส่งต่อไปยัง Tier 2',
          'tier3': 'ส่งต่อไปยัง Tier 3',
          'in_progress': 'เริ่มดำเนินการ',
          'on_hold': 'พักชั่วคราว',
          'resolved': 'แก้ไขเสร็จสิ้น',
          'closed': 'ปิดเคสแล้ว'
        };
        
        newTimelineEvents.push({
          id: `timeline-${Date.now()}-status`,
          timestamp,
          type: 'status_change',
          description: statusDescriptions[updates.status as TicketStatus] || `สถานะเปลี่ยนเป็น ${updates.status}`,
          user: userName,
          status: updates.status
        });
      }
      
      // 2. Assignment changed
      if (updates.assignedTo && updates.assignedTo !== prev.assignedTo) {
        const assignedUser = db.users.getById(updates.assignedTo!);
        newTimelineEvents.push({
          id: `timeline-${Date.now()}-assignment`,
          timestamp,
          type: 'assignment',
          description: `มอบหมายให้ ${assignedUser?.fullName || 'Unknown'}`,
          user: userName
        });
      }
      
      // 3. Project assigned (for Tier1 accepting new case)
      if (updates.projectId && updates.projectId !== prev.projectId) {
        const project = db.projects.getById(updates.projectId!);
        if (project) {
          const organization = db.organizations.getById(project.organizationId);
          newTimelineEvents.push({
            id: `timeline-${Date.now()}-project`,
            timestamp,
            type: 'assignment',
            description: `กำหนดโครงการ: ${organization?.organizationShortName || ''} - ${project.projectCode}`,
            user: userName
          });
        }
      }
      
      // บันทึก timeline events ใหม่ลง db
      if (newTimelineEvents.length > 0) {
        newTimelineEvents.forEach(evt => {
          db.timeline.add({ ...evt, ticketId: prev.id, userId: user?.id });
        });
      }
      
      return newTicket;
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 py-3 md:py-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {/* Left: Back button + Ticket Info */}
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <Button variant="ghost" size="sm" onClick={() => onNavigate(getBackPath())} className="shrink-0">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2 flex-wrap min-w-0">
                <h1 className="ticket-detail-01 m-0 inline-flex items-center mr-2">{ticket.ticketNumber}</h1>
                <div className="mr-3">
                  <ProjectBadge 
                    organizationShortName={ticket.organizationShortName}
                    projectCode={ticket.projectCode}
                  />
                </div>
                <StatusBadge status={ticket.status} />
              </div>
            </div>

            {/* Right: Action Buttons */}
            <div className="flex flex-wrap gap-2 sm:shrink-0">
              {/* Show TicketActions for tier users (tier1, tier2, tier3, admin) */}
              {/* ✅ เปลี่ยนจาก user.name เป็น user.fullName */}
              {user?.role && isOperator(user) && user.fullName && (
                <TicketActions
                  ticket={ticket}
                  userRole={user.role as 'tier1' | 'tier2' | 'tier3' | 'admin'}
                  userId={user.id}
                  onUpdate={handleTicketUpdate}
                />
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 lg:px-8 py-6">
        {/* Status Alert Banner - Show when ticket is escalated and waiting acceptance */}
        <TicketStatusAlert 
          ticket={ticket} 
          currentUserId={user?.id}
          onUpdate={handleTicketUpdate}
        />

        {/* ✅ Read-Only Mode Banner - แสดงเมื่อเปิดเคสของคนอื่น */}
        {isReadOnly && ticket.assignedTo && user?.id && (
          <ReadOnlyModeBanner 
            ticketAssignedTo={ticket.assignedTo}
            currentUserId={user.id}
            ticketStatus={ticket.status}
            onTakeover={() => setShowTakeoverModal(true)}
          />
        )}

        {/* Takeover Banner - Show when ticket is taken over */}
        {showTakeoverBanner && takeoverInfo && (
          <>
            {/* Banner สำหรับเคสที่ยังไม่รับ (new/tier2/tier3) */}
            {!takeoverInfo.isAlreadyInProgress && (
              <div className="bg-amber-50 border-l-4 border-amber-500 p-4 mb-6 rounded-r-lg shadow-sm">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500 text-white shrink-0 animate-pulse">
                    <AlertTriangle className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-sm font-semibold text-amber-900 m-0">⚠️ คุณ Takeover เคสนี้มาแล้ว แต่ยังไม่ได้รับเ���ส!</h3>
                    </div>
                    <p className="text-sm text-amber-800 mb-3">
                      คุณได้รับเคส <strong>{takeoverInfo.ticketNumber}</strong> จาก <strong>{takeoverInfo.previousViewer}</strong>
                      <br />
                      กรุณากดปุ่มด้านล่างเพื่อรับเคสและเริ่มดำเนินการ
                    </p>
                    
                    {/* ปุ่มรับเคส - มี animation */}
                    <Button 
                      onClick={handleAcceptFromTakeoverBanner}
                      className="bg-blue-600 hover:bg-blue-700 text-white animate-pulse"
                      size="lg"
                    >
                      <UserCheck className="mr-2 h-5 w-5" />
                      รับเคสนี้
                    </Button>
                    
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-3">
                      <div className="flex items-start gap-2">
                        <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                        <p className="text-sm text-blue-900 m-0">
                          <strong>💡 คำแนะนำ:</strong> ควรอ่านรายละเอียดเคสและไทม์ไลน์ให้ละ���อียดก่อนกดรับเคส เพื่อความเข้าใจในบริบทของัญหา
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="shrink-0 hover:bg-amber-100"
                    onClick={handleDismissTakeoverBanner}
                  >
                    <XCircle className="h-4 w-4 text-amber-600" />
                  </Button>
                </div>
              </div>
            )}
            
            {/* Banner สำหรับเคสที่รับแล้ว (in_progress) */}
            {takeoverInfo.isAlreadyInProgress && takeoverInfo.currentStatus === 'in_progress' && (
              <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded-r-lg shadow-sm">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500 text-white shrink-0">
                    <CheckCircle className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-sm font-semibold text-green-900 m-0">✅ Takeover เคสสำเร็จ</h3>
                    </div>
                    <p className="text-sm text-green-800 mb-2">
                      คุณได้รับเคส <strong>{takeoverInfo.ticketNumber}</strong> จาก <strong>{takeoverInfo.previousViewer}</strong>
                      <br />
                      คุณสามารถดำเนินการต่อได้ทันที
                    </p>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-3">
                      <div className="flex items-start gap-2">
                        <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                        <p className="text-sm text-blue-900 m-0">
                          💡 ระบบได้แจ้งเตือนผู้ดูเดิมแล้ว
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="shrink-0 hover:bg-green-100"
                    onClick={handleDismissTakeoverBanner}
                  >
                    <XCircle className="h-4 w-4 text-green-600" />
                  </Button>
                </div>
              </div>
            )}
            
            {/* Banner สำหรับเคสที่หยุดชั่วคราว (on_hold) */}
            {takeoverInfo.isAlreadyInProgress && takeoverInfo.currentStatus === 'on_hold' && (
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded-r-lg shadow-sm">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-500 text-white shrink-0">
                    <PauseCircle className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-sm font-semibold text-blue-900 m-0">⏸️ คุณ Takeover เคสที่หยุดชั่วคราวมาแล้ว</h3>
                    </div>
                    <p className="text-sm text-blue-800 mb-3">
                      คุณได้รับเคส <strong>{takeoverInfo.ticketNumber}</strong> จาก <strong>{takeoverInfo.previousViewer}</strong>
                      <br />
                      เคสนี้อยู่ในสถานะ "หยุดชั่วคราว"
                    </p>
                    
                    {/* ปุ่มดำเนินการต่อ */}
                    <Button 
                      onClick={handleResume}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      size="lg"
                    >
                      <PlayCircle className="mr-2 h-5 w-5" />
                      ดำเนินการต่อ
                    </Button>
                    
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-3">
                      <div className="flex items-start gap-2">
                        <Info className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                        <p className="text-sm text-amber-900 m-0">
                          💡 เมื่อกดปุ่ม "ดำเนินการต่อ" เคสจะเปลี่ยนสถานะเป็น "กำลังดำเนินการ"
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="shrink-0 hover:bg-blue-100"
                    onClick={handleDismissTakeoverBanner}
                  >
                    <XCircle className="h-4 w-4 text-blue-600" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}

        {/* Title and Hashtags Section */}
        <div className="mb-6">
          <div className="flex items-baseline gap-2 flex-wrap">
            <span className="text-gray-600">หัวเรื่อง</span>
            <p className="text-gray-600 m-0">{removeHashtags(ticket.title)}</p>
            {/* Display hashtags as badges - inline with title */}
            {extractHashtags(ticket.title).map((hashtag, idx) => (
              <span
                key={idx}
                className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700"
              >
                {hashtag}
              </span>
            ))}
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="space-y-6 lg:col-span-2">
            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>รายละเอียด</CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className="rich-text-display text-gray-700" 
                  dangerouslySetInnerHTML={{ __html: ticket.description }}
                />
              </CardContent>
            </Card>

            {/* Attachments */}
            {ticket.attachments && ticket.attachments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Paperclip className="h-5 w-5" />
                    ไฟล์แนบ ({ticket.attachments.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <AttachmentGallery attachments={ticket.attachments} />
                </CardContent>
              </Card>
            )}

              {/* Satisfaction Survey - Show when Resolved or Closed */}
              {(ticket.status === 'resolved' || ticket.status === 'closed') && (
                <SatisfactionSurvey ticketId={ticket.id} />
              )}

              {/* Comments */}
              <CommentSection
                comments={ticket.comments}
                onAddComment={(commentText, isInternal, attachments) => {
                  const newComment = {
                    id: `comment-${Date.now()}`,
                    ticketId: ticket.id,
                    author: user?.fullName || 'Unknown',
                    authorRole: user?.role || 'staff',
                    content: commentText,
                    isInternal,
                    attachments: attachments || [],
                    createdAt: new Date()
                  };

                  // ✅ Persist to relational table (Source of Truth)
                  db.comments.add(newComment as any);

                  // ✅ Re-hydrate ticket (Read Model) like Laravel API Resource
                  const refreshed = db.tickets.getHydratedById(ticket.id);
                  if (refreshed) {
                    setTicket(refreshed as any);
                  } else {
                    setTicket({ ...ticket, updatedAt: new Date().toISOString() } as any);
                  }
                }}
                formatDate={formatDate}
                currentUserName={user?.fullName || ''}
                currentUserRole={user?.role || 'staff'}
                showInternalToggle={user?.role !== 'customer'}
                readOnly={ticket.status === 'closed'}
              />

            {/* Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>ไทม์ไลน์</CardTitle>
              </CardHeader>
              <CardContent>
                <TicketTimeline events={db.timeline.getByTicketId(ticket.id)} userRole={user?.role || 'staff'} ticket={ticket} />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* SLA Status */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">สถานะ SLA</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">สถานะ</span>
                  <SLAIndicator
                    createdAt={ticket.createdAt}
                    dueDate={ticket.dueDate}
                    status={ticket.status}
                    slaStatus={ticket.slaStatus}
                    showLabel={true}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">สร้างเมื่อ</span>
                  <span className="text-sm font-medium">{formatDate(ticket.createdAt)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">กำหนดเสร็จ</span>
                  <span className="text-sm font-medium">{formatDate(ticket.dueDate)}</span>
                </div>
              </CardContent>
            </Card>

            {/* Customer Information (Restored) */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">ข้อมูลลูกค้า</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-semibold text-lg shrink-0">
                    {(ticket.customerName || '?').charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium text-gray-900 truncate">{ticket.customerName}</p>
                    <p className="text-sm text-gray-500">
                      {ticket.createdByType === 'staff_on_behalf' ? (
                        <span className="flex items-center gap-1">
                          <UserCheck className="h-3 w-3" /> Staff แจ้งแทน
                        </span>
                      ) : 'แจ้งด้วยตนเอง'}
                    </p>
                  </div>
                </div>
                
                <div className="pt-3 border-t space-y-3">
                  <div className="flex items-start gap-3">
                    <Mail className="h-4 w-4 text-gray-400 mt-0.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-gray-500 mb-0.5">อีเมล</p>
                      <p className="text-sm text-gray-900 break-all">{ticket.customerEmail}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Phone className="h-4 w-4 text-gray-400 mt-0.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-gray-500 mb-0.5">เบอร์โทรศัพท์</p>
                      <p className="text-sm text-gray-900">{ticket.customerPhone || '-'}</p>
                    </div>
                  </div>

                  {ticket.department && (
                    <div className="flex items-start gap-3">
                      <Briefcase className="h-4 w-4 text-gray-400 mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-gray-500 mb-0.5">แผนก/หน่วยงาน</p>
                        <p className="text-sm text-gray-900">{ticket.department}</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">ข้อมูลเคส</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* 1. Priority Section */}
                <div className="space-y-1">
                  <Label className="text-xs text-gray-500">ความเร่งด่วน (Priority)</Label>
                  <div className="flex items-center gap-2">
                    <PriorityBadge priority={ticket.priority} />
                  </div>
                </div>

                {/* 2. Channel Section */}
                <div className="space-y-1 pt-3 border-t border-gray-100">
                  <Label className="text-xs text-gray-500">ช่องทาง (Channel)</Label>
                  <div className="flex items-center gap-2">
                    <ChannelBadge channel={ticket.channel} />
                  </div>
                </div>

                {/* 3. Product Section */}
                <div className="space-y-1 pt-3 border-t border-gray-100">
                  <Label className="text-xs text-gray-500">ผลิตภัณฑ์ (Product)</Label>
                  {ticketProducts.length > 0 ? (
                    ticketProducts.map((p: any) => (
                      <div key={p.id} className="flex items-center gap-2">
                        <Tag className="h-4 w-4 text-gray-400" />
                        <span className="text-sm font-medium">{p.productName}</span>
                      </div>
                    ))
                  ) : (
                    <div className="flex items-center gap-2">
                      <Tag className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-muted-foreground">-</span>
                    </div>
                  )}
                </div>

                {/* 4. Project Section */}
                <div className="space-y-1 pt-3 border-t border-gray-100">
                  <Label className="text-xs text-gray-500">โครงการ</Label>
                  <div className="flex items-center gap-2 mb-1">
                    <Briefcase className="h-4 w-4 text-gray-400" />
                    <span className="text-sm font-medium">{ticket.projectName || '-'}</span>
                  </div>
                  <div className="ml-6">
                    <ProjectBadge 
                      organizationShortName={ticket.organizationShortName}
                      projectCode={ticket.projectCode}
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <AssignmentInfoCard ticket={ticket} />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Takeover Confirmation Modal */}
      {ticket && (
        <TakeoverConfirmationModal
          open={showTakeoverModal}
          onOpenChange={setShowTakeoverModal}
          onConfirm={(reason) => handleTakeover(reason)}
          ticket={ticket}
          currentUserId={user?.id || ''}
          currentUserName={user?.fullName || ''}
        />
      )}
    </div>
  );
}
