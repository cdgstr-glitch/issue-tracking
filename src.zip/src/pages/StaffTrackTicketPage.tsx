import { useEffect } from 'react';
import { Button } from '../components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import TicketListPage from './TicketListPage';

interface StaffTrackTicketPageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}
export default function StaffTrackTicketPage({ onNavigate, onBackToMenu }: StaffTrackTicketPageProps) {
  const { user, isAuthenticated } = useAuth();

  // Redirect to home when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      console.log('✅ User logged out, navigating to /');
      onNavigate('/');
    }
  }, [isAuthenticated, onNavigate]);

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8">
      {/* Back Button */}
      <Button
        variant="ghost"
        className="mb-4"
        onClick={() => {
          if (onBackToMenu) return onBackToMenu();
          onNavigate('/');
        }}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        กลับหน้าแรก
      </Button>

      {/* Page Header */}
      <div className="mb-6">
        <h1 className="mb-2">
          ติดตามเคสของลูกค้าแจ้งโดยเจ้าหน้าที่ชื่อ {user?.fullName || 'เจ้าหน้าที่'}
        </h1>
        <p className="text-gray-600">
          ดูสถานะและความก้าวหน้าของเคสทั้งหมด
        </p>
      </div>

      {/* ✅ Render Ticket List (TicketListPage handles its own search/filter UI) */}
      <TicketListPage onNavigate={onNavigate} />
    </div>
  );
}
