import { useState, useEffect, useMemo } from 'react';
import { formatRelativeTime } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';
import { extractHashtags, removeHashtags } from '../lib/hashtagUtils';
import { Search, ArrowLeft } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Header } from '../components/layout/Header';
import { StatusBadge } from '../components/StatusBadge';
import { PriorityBadge } from '../components/PriorityBadge';
import { ChannelBadge } from '../components/ChannelBadge';
import { ProjectBadge } from '../components/ProjectBadge';
import { db } from '../lib/mockDb/client';
import { PaginationWithSelector } from '../components/ui/pagination-with-selector';

import { isTier1, isPureStaff } from '../lib/permissions';

interface RetroactiveClosedTicketsPageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
  isAdminContext?: boolean;
}
export default function RetroactiveClosedTicketsPage({ onNavigate, onBackToMenu, isAdminContext = false }: RetroactiveClosedTicketsPageProps) {
  const { user, logout, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(15);

  const handleLogout = () => {
    logout();
  };

  // Redirect to home when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      onNavigate('/');
    }
  }, [isAuthenticated, onNavigate]);

  // 🔒 Policy: staff (ผู้แจ้งเคส) ห้ามเข้าหน้านี้ทุกกรณี
  useEffect(() => {
    if (user && isPureStaff(user)) {
      console.warn('⛔ Blocked: staff attempted to access RetroactiveClosedTicketsPage');
      onNavigate('/');
    }
  }, [user, onNavigate]);

  // Filter only closed tickets
  const closedTickets = useMemo(() => {
    const allTickets = db.tickets.getAll();
    
    // ✅ เฉพาะเคสที่ปิดแล้ว + Phone/Email/Line + ปิดโดย Tier 1
    return allTickets.filter(ticket => {
      if (ticket.status !== 'closed') return false;
      if (!['phone', 'email', 'line'].includes(ticket.channel)) return false;
      if (!ticket.closedBy) return false;

      const closer = db.users.getById(ticket.closedBy);
      return isTier1(closer);
    });
  }, []);

  // Filter tickets based on search query
  const filteredTickets = useMemo(() => {
    if (!searchQuery) return closedTickets;
    
    const query = searchQuery.toLowerCase();
    return closedTickets.filter(ticket =>
      ticket.ticketNumber.toLowerCase().includes(query) ||
      ticket.title.toLowerCase().includes(query) ||
      ticket.category.toLowerCase().includes(query) ||
      ticket.customerName?.toLowerCase().includes(query) ||
      ticket.solution?.toLowerCase().includes(query) ||
      ticket.closureNotes?.toLowerCase().includes(query)
    );
  }, [searchQuery, closedTickets]);

  // Pagination logic
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const currentTickets = filteredTickets.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Reset to page 1 when search changes
  useMemo(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  const TicketTable = () => (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b bg-gray-50 text-left">
            <th className="px-4 py-3 font-medium text-gray-500">หมายเลข</th>
            <th className="px-4 py-3 font-medium text-gray-500">หัวข้อ</th>
            <th className="px-4 py-3 font-medium text-gray-500">ผลิตภัณฑ์</th>
            <th className="px-4 py-3 font-medium text-gray-500">โครงการ/รหัส</th>
            <th className="px-4 py-3 font-medium text-gray-500">ช่องทาง</th>
            <th className="px-4 py-3 font-medium text-gray-500">สถานะ</th>
            <th className="px-4 py-3 font-medium text-gray-500">ความสำคัญ</th>
            <th className="px-4 py-3 font-medium text-gray-500">ปิดโดย</th>
            <th className="px-4 py-3 font-medium text-gray-500">ปิดเมื่อ</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {currentTickets.map((ticket) => {
            const hashtags = extractHashtags(ticket.title);
            const titleWithoutHashtags = removeHashtags(ticket.title);
            const closedByUser = ticket.closedBy ? db.users.getById(ticket.closedBy) : null;

            return (
              <tr
                key={ticket.id}
                className="cursor-pointer transition-colors hover:bg-gray-50"
                onClick={() => {
                  if (isAdminContext) {
                    onNavigate('/admin/retroactive-closed-tickets', ticket.id);
                  } else {
                    onNavigate('/retroactive-closed-ticket-detail', ticket.id);
                  }
                }}
              >
                <td className="px-4 py-3 font-medium">
                  <span className="text-blue-600">{ticket.ticketNumber}</span>
                </td>
                <td className="px-4 py-3 max-w-[300px]">
                  <div className="flex flex-col gap-1">
                    <span className="font-medium truncate" title={titleWithoutHashtags}>
                      {titleWithoutHashtags}
                    </span>
                    {hashtags.length > 0 && (
                      <div className="flex gap-1 flex-wrap">
                        {hashtags.map((tag, idx) => (
                          <span key={idx} className="text-xs text-gray-500">#{tag}</span>
                        ))}
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {ticket.productName || ticket.product || ticket.category}
                </td>
                <td className="px-4 py-3">
                  <ProjectBadge 
                    organizationShortName={ticket.organizationShortName} 
                    projectCode={ticket.projectCode} 
                  />
                </td>
                <td className="px-4 py-3">
                  <ChannelBadge channel={ticket.channel} />
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={ticket.status} />
                </td>
                <td className="px-4 py-3">
                  <PriorityBadge priority={ticket.priority} />
                </td>
                <td className="px-4 py-3">
                  {closedByUser ? (
                    <div className="flex flex-col">
                      <span className="text-sm font-medium">{closedByUser.fullName}</span>
                      <span className="text-xs text-gray-500">
                        {isTier1(closedByUser) ? 'Tier 1 Support' : '—'}
                      </span>
                    </div>
                  ) : (
                    <span className="text-gray-400">-</span>
                  )}
                </td>
                <td className="px-4 py-3 text-gray-600 whitespace-nowrap">
                  {ticket.closedAt && formatRelativeTime(ticket.closedAt)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  const MobileCardView = () => (
    <div className="grid gap-4 md:hidden">
      {currentTickets.map((ticket) => {
        const hashtags = extractHashtags(ticket.title);
        const titleWithoutHashtags = removeHashtags(ticket.title);
        const closedByUser = ticket.closedBy ? db.users.getById(ticket.closedBy) : null;

        return (
          <Card 
            key={ticket.id} 
            className="cursor-pointer transition-all hover:shadow-md"
            onClick={() => {
              if (isAdminContext) {
                onNavigate('/admin/retroactive-closed-tickets', ticket.id);
              } else {
                onNavigate('/retroactive-closed-ticket-detail', ticket.id);
              }
            }}
          >
            <CardContent className="p-4 sm:p-6">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex-1 min-w-0">
                  <div className="mb-2 flex flex-wrap items-center gap-2">
                    <span className="text-sm font-mono text-blue-600">
                      {ticket.ticketNumber}
                    </span>
                    <StatusBadge status={ticket.status} />
                    <PriorityBadge priority={ticket.priority} />
                    <ChannelBadge channel={ticket.channel} />
                  </div>
                  
                  <h3 className="mb-2 text-base sm:text-lg break-words font-medium">
                    {titleWithoutHashtags}
                  </h3>
                  
                  {hashtags.length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-1">
                      {hashtags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-xs text-gray-500"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="text-sm text-gray-600">
                    {ticket.productName || ticket.product || ticket.category}
                  </div>

                  <div className="mt-2">
                    <ProjectBadge 
                      organizationShortName={ticket.organizationShortName} 
                      projectCode={ticket.projectCode} 
                    />
                  </div>
                  
                  {ticket.solution && (
                    <div className="mt-2 p-2 bg-green-50 rounded border border-green-200">
                      <p className="text-xs text-green-800 font-medium mb-1">✅ วิธีแก้ไข:</p>
                      <p className="text-xs text-green-700 line-clamp-2">{ticket.solution}</p>
                    </div>
                  )}
                </div>

                <div className="flex-shrink-0 text-right">
                  <div className="text-xs text-gray-500">
                    <div>ปิดเมื่อ</div>
                    <div className="font-medium">{ticket.closedAt ? formatRelativeTime(ticket.closedAt) : '-'}</div>
                  </div>
                  {closedByUser && (
                    <div className="mt-2 text-xs text-gray-600">
                      <div>ปิดโดย</div>
                      <div className="font-medium">{closedByUser.fullName}</div>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 sm:hidden">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isAdminContext) {
                      onNavigate('/admin/retroactive-closed-tickets', ticket.id);
                    } else {
                      onNavigate('/retroactive-closed-ticket-detail', ticket.id);
                    }
                  }}
                >
                  ดูรายละเอียด
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );

  const PaginationControls = () => (
    filteredTickets.length > 0 ? (
      <div className="mt-6">
        <PaginationWithSelector
          currentPage={currentPage}
          totalPages={totalPages}
          itemsPerPage={itemsPerPage}
          onPageChange={setCurrentPage}
          onItemsPerPageChange={setItemsPerPage}
          totalItems={filteredTickets.length}
        />
      </div>
    ) : null
  );

  const MainContent = () => (
    <>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">เคสที่ปิดย้อนหลัง</h1>
          <p className="text-sm text-gray-600 mt-1">
            แสดงเฉพาะเคสที่ปิดแล้วจาก Phone/Email/Line และปิดโดย Tier 1
          </p>
        </div>

        <div className="relative w-full sm:max-w-sm">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ค้นหาเลขเคส / หัวข้อ / หมวดหมู่ / ชื่อผู้ใช้..."
            className="pl-9"
          />
        </div>
      </div>

      {filteredTickets.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-gray-600">ไม่พบเคสที่ปิดย้อนหลังตามเงื่อนไข</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="hidden md:block">
            <CardContent className="p-0">
              <TicketTable />
            </CardContent>
          </Card>

          <MobileCardView />
          <PaginationControls />
        </>
      )}
    </>
  );

  // Wrapper for Admin Context
  if (isAdminContext) {
    return (
      <div className="container mx-auto px-4 py-8">
        <MainContent />
      </div>
    );
  }

  // Wrapper for Tier 1 Context (non-admin layout)
  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'tier1'
        }}
        onNavigate={onNavigate}
        currentPath="/admin/retroactive-closed-tickets"
        showSearch={false}
      />

      <div className="container mx-auto px-4 py-8">
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/')}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับหน้าแรก
        </Button>

        <MainContent />
      </div>
    </div>
  );
}
