import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  ArrowLeft, 
  FileSearch,
  Code,
  Database,
  Send,
  CheckCircle,
  ArrowRight,
  Clock,
  CirclePause,
  CheckCircle2,
  ArrowUpRight
} from 'lucide-react';
import { DecisionFlowchart } from '../components/DecisionFlowchart';
import { TierEscalationDiagram } from '../components/TierEscalationDiagram';
import { useAuth } from '../contexts/AuthContext';
import { Header } from '../components/layout/Header';

interface Tier2JourneyPageProps {
  onNavigate: (path: string) => void;
  onBackToMenu?: () => void;
}

const Tier2JourneyPage: React.FC<Tier2JourneyPageProps> = ({ onNavigate, onBackToMenu }) => {
  const { user } = useAuth();

  const steps = [
    {
      number: 1,
      icon: FileSearch,
      title: 'รับเคสจาก Tier 1',
      description: 'ตรวจสอบและรับเคสที่ส่งต่อมา',
      details: [
        'ตรวจสอบเคสที่ Tier 1 ส่งต่อมา',
        'อ่านรายละเอียดและข้อมูลการตรวจสอบเบื้องต้น',
        'ตรวจสอบเหตุผลในการส่งต่อ',
        'รับเคสและเปลี่ยนสถานะเป็น "กำลังดำเนินการ (Tier 2)"'
      ],
      color: 'orange',
      sla: 'SLA: 1-2 วัน'
    },
    {
      number: 2,
      icon: Code,
      title: 'วิเคราะห์ทางเทคนิค',
      description: 'ตรวจสอบล็อกและวิเคราะห์ปัญหาเชิงลึก',
      details: [
        'เข้าถึงล็อกระบบและฐานข้อมูล',
        'วิเคราะห์ Error Messages และ Stack Traces',
        'ตรวจสอบ Performance Metrics',
        'ระบุสาเหตุของปัญหาอย่างแม่นยำ',
        'ทดสอบการทำซ้ำปัญหาในสภาพแวดล้อมทดสอบ'
      ],
      color: 'purple'
    },
    {
      number: 3,
      icon: Database,
      title: 'แก้ไขปัญหาทางเทคนิค',
      description: 'ดำเนินการแก้ไขและทดสอบ',
      details: [
        'สร้างแผนการแก้ไขปัญหา',
        'ดำเนินการแก้ไข (Configuration, Code Fix, Database Update)',
        'ประสานงานกับทีม DevOps หากจำเป็น',
        'ทดสอบการแก้ไขอย่างละเอียด',
        'บันทึกวิธีการแก้ไขสำหรับอ้างอิงในอนาคต'
      ],
      color: 'green'
    },
    {
      number: 4,
      icon: Send,
      title: 'ส่งต่อไป Tier 3 (ถ้าจำเป็น)',
      description: 'ส่งปัญหาซับซ้อนไปยังผู้เชี่ยวชาญ',
      details: [
        'ประเมินว่าปัญหาต้องการความเชี่ยวชาญระดับสูง',
        'เลือก "ส่งต่อเคส" และระบุเหตุผลโดยละเอียด',
        'เลือกส่งไปยัง Tier 3 (Specialist Team)',
        'แนบผลการวิเคราะห์และข้อมูลทางเทคนิคทั้งหมด',
        'แจ้ง Tier 1 และลูกค้าเกี่ยวกับการส่งต่อ'
      ],
      color: 'red'
    },
    {
      number: 5,
      icon: CheckCircle,
      title: 'ยืนยันและปิดเคส',
      description: 'ตรวจสอบผลและปิดเคส',
      details: [
        'ยืนยันว่าปัญหาได้รับการแก้ไขแล้ว',
        'ทดสอบกับลูกค้าในสภาพแวดล้อมจริง',
        'อัปเดตเอกสารและ Knowledge Base',
        'เปลี่ยนสถานะเป็น "แก้ไขแล้ว"',
        'ส่งกลับไปยัง Tier 1 เพื่อติดตามกับลูกค้า'
      ],
      color: 'blue'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      orange: {
        bg: 'bg-orange-50',
        border: 'border-orange-200',
        text: 'text-orange-600',
        iconBg: 'bg-orange-600',
        gradient: 'from-orange-500 to-orange-600'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        text: 'text-purple-600',
        iconBg: 'bg-purple-600',
        gradient: 'from-purple-500 to-purple-600'
      },
      green: {
        bg: 'bg-green-50',
        border: 'border-green-200',
        text: 'text-green-600',
        iconBg: 'bg-green-600',
        gradient: 'from-green-500 to-green-600'
      },
      red: {
        bg: 'bg-red-50',
        border: 'border-red-200',
        text: 'text-red-600',
        iconBg: 'bg-red-600',
        gradient: 'from-red-500 to-red-600'
      },
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        text: 'text-blue-600',
        iconBg: 'bg-blue-600',
        gradient: 'from-blue-500 to-blue-600'
      }
    };
    return colors[color as keyof typeof colors] || colors.orange;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ✅ ใช้ Header component */}
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'tier2'
        }}
        onNavigate={onNavigate}
        onInformationClick={onBackToMenu}
        currentPath="/tier2-journey"
        showSearch={false}
      />

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* ✅ ปุ่มกลับหน้าแรก */}
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/admin/sa')}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับแดชบอร์ด SA
        </Button>

        {/* Page Header */}
        <div className="mb-8 text-center">
          <div className="mb-4 inline-flex items-center justify-center gap-3 rounded-full bg-orange-100 px-6 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-orange-600 text-white">
              T2
            </div>
            <h1 className="m-0 text-orange-900">Tier 2 - ทีม SA (System Administrator)</h1>
          </div>
          <p className="text-gray-600 text-lg mb-4">
            ทีมสนับสนุนด้านเทคนิค - วิเคราะห์ แก้ไข และจัดการปัญหาทางเทคนิค
          </p>

          {/* SLA Badge */}
          <Badge variant="outline" className="border-orange-600 text-orange-700 px-4 py-1.5 flex items-center gap-2 mx-auto w-fit">
            <Clock className="h-4 w-4" />
            SLA: 1-2 วัน
          </Badge>
        </div>

        {/* Main Responsibilities Card */}
        <Card className="mb-8 border-orange-200 bg-gradient-to-r from-orange-50 to-orange-100">
          <CardHeader>
            <CardTitle className="text-orange-900">ความรับผิดชอบหลัก</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-orange-900">วิเคราะห์เทคนิค</h3>
                <p className="text-sm text-gray-700">
                  ตรวจสอบล็อก ระบบ และวิเคราะห์ปัญหาเชิงลึก
                </p>
              </div>
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-orange-900">แก้ไขปัญหา</h3>
                <p className="text-sm text-gray-700">
                  ดำเนินการแก้ไขทางเทคนิคและทดสอบ
                </p>
              </div>
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-orange-900">ประสานงาน</h3>
                <p className="text-sm text-gray-700">
                  ประสานงานกับทีมพัฒนาและ DevOps
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Journey Steps */}
        <div className="mb-12">
          <h2 className="mb-8 text-center">ขั้นตอนการทำงาน</h2>

          {/* Desktop Flow - Horizontal */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Connecting Line */}
              <div className="absolute top-16 left-0 right-0 h-0.5 bg-gray-300" style={{ left: '10%', right: '10%' }} />
              
              <div className="grid grid-cols-5 gap-4">
                {steps.map((step, index) => {
                  const colors = getColorClasses(step.color);
                  const Icon = step.icon;
                  
                  return (
                    <div key={step.number} className="relative">
                      <Card className={`border-2 ${colors.border} ${colors.bg} h-full`}>
                        <CardContent className="p-6">
                          {/* Number Badge */}
                          <div className="flex justify-center mb-4">
                            <div className={`flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg relative z-10`}>
                              <Icon className="h-8 w-8 text-white" />
                            </div>
                          </div>

                          <h3 className={`mb-2 text-center ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-center text-sm text-gray-700 mb-4">
                            {step.description}
                          </p>

                          {step.sla && (
                            <div className="mb-4 text-center">
                              <Badge variant="outline" className={`${colors.text} border-current text-xs`}>
                                {step.sla}
                              </Badge>
                            </div>
                          )}

                          <ul className="space-y-2">
                            {step.details.map((detail, idx) => (
                              <li key={idx} className="flex items-start text-sm text-gray-700">
                                <span className={`mr-2 ${colors.text}`}>•</span>
                                <span>{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>

                      {/* Arrow */}
                      {index < steps.length - 1 && (
                        <div className="absolute top-16 -right-2 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                          <ArrowRight className="h-4 w-4 text-gray-400" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Mobile/Tablet Flow - Vertical */}
          <div className="lg:hidden space-y-6">
            {steps.map((step, index) => {
              const colors = getColorClasses(step.color);
              const Icon = step.icon;
              
              return (
                <div key={step.number} className="relative">
                  <Card className={`border-2 ${colors.border} ${colors.bg}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        {/* Icon */}
                        <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg`}>
                          <Icon className="h-7 w-7 text-white" />
                        </div>

                        {/* Title */}
                        <div className="flex-1">
                          <h3 className={`mb-1 ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-sm text-gray-700">
                            {step.description}
                          </p>
                          {step.sla && (
                            <Badge variant="outline" className={`mt-2 ${colors.text} border-current text-xs`}>
                              {step.sla}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <ul className="space-y-2">
                        {step.details.map((detail, idx) => (
                          <li key={idx} className="flex items-start text-sm text-gray-700">
                            <span className={`mr-2 ${colors.text}`}>•</span>
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Vertical Arrow */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                        <ArrowRight className="h-4 w-4 rotate-90 text-gray-400" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Tips Card */}
        <Card className="border-orange-200 bg-orange-50 mb-8">
          <CardHeader>
            <CardTitle className="text-orange-900">💡 เคล็ดลับสำหรับ Tier 2</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="mr-2 text-orange-600">✓</span>
                <span>บันทึกผลการวิเคราะห์อย่างละเอียดเพื่อช่วย Tier 3 หรืออ้างอิงในอนาคต</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-orange-600">✓</span>
                <span>ทดสอบการแก้ไขในสภาพแวดล้อมทดสอบก่อนนำไปใช้จริง</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-orange-600">✓</span>
                <span>ประสานงานกับทีมพัฒนาสำหรับ Bug ที่ต้องแก้ไขโค้ด</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-orange-600">✓</span>
                <span>อัปเดต Knowledge Base ด้วยวิธีแก้ไขใหม่ๆ</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Button Actions Guide */}
        <Card className="border-orange-300 mb-8">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
            <CardTitle className="text-orange-900">🎯 การใช้งานปุ่มหลัก (หลังจากรับเคสจาก Tier 1)</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Button 1: ส่งต่อ */}
              <div className="flex items-start gap-4 pb-6 border-b">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-red-100">
                  <ArrowUpRight className="h-6 w-6 text-red-600" />
                </div>
                <div className="flex-1">
                  <h3 className="mb-2 text-red-900">🔄 ส่งต่อ Tier 3 (Escalate)</h3>
                  <p className="text-sm text-gray-700 mb-3">
                    <strong>ใช้เมื่อ:</strong> ปัญหาต้องการผู้เชี่ยวชาญระดับสูงหรือ Vendor
                  </p>
                  <div className="bg-red-50 rounded-lg p-4 space-y-2 text-sm">
                    <p className="text-red-900"><strong>ตัวอย่างสถานการณ์:</strong></p>
                    <ul className="space-y-1 text-gray-700 ml-4">
                      <li>• เหตุการณ์วิกฤติ (System Down, Data Loss)</li>
                      <li>• ต้องการเปลี่ยนแปลง Infrastructure/Architecture</li>
                      <li>• ปัญหาด้าน Security หรือ Compliance</li>
                      <li>• ต้องติดต่อ Cloud Provider (AWS, Azure, GCP)</li>
                      <li>• Bug ที่ต้องให้ Software Vendor แก้ไข</li>
                    </ul>
                    <p className="text-red-900 pt-2"><strong>ขั้นตอน:</strong></p>
                    <p className="text-gray-700">1. คลิก "ส่งต่อ" → 2. เลือก Tier 3 → 3. แนบผลการวิเคราะห์และล็อกทั้งหมด</p>
                  </div>
                </div>
              </div>

              {/* Button 2: แก้ไขแล้ว */}
              <div className="flex items-start gap-4 pb-6 border-b">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-green-100">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <h3 className="mb-2 text-green-900">✅ แก้ไขแล้ว (Resolved)</h3>
                  <p className="text-sm text-gray-700 mb-3">
                    <strong>ใช้เมื่อ:</strong> แก้ไขทางเทคนิคเสร็จและทดสอบแล้ว
                  </p>
                  <div className="bg-green-50 rounded-lg p-4 space-y-2 text-sm">
                    <p className="text-green-900"><strong>ตัวอย่างสถานการณ์:</strong></p>
                    <ul className="space-y-1 text-gray-700 ml-4">
                      <li>• แก้ไข Configuration และทดสอบสำเร็จ</li>
                      <li>• แก้ไข Bug/Code และ Deploy แล้ว</li>
                      <li>• ทำ Database Migration สำเร็จ</li>
                      <li>• ปรับแต่ง Performance และทดสอบแล้ว</li>
                    </ul>
                    <p className="text-green-900 pt-2"><strong>ขั้นตอน:</strong></p>
                    <p className="text-gray-700">1. คลิก "แก้ไขแล้ว" → 2. สรุปวิธีแก้ไขและผลการทดสอบ → 3. ส่งกลับ Tier 1 เพื่อติดตามกับลูกค้า</p>
                  </div>
                </div>
              </div>

              {/* Button 3: ระงับเคส */}
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-yellow-100">
                  <CirclePause className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="flex-1">
                  <h3 className="mb-2 text-yellow-900">⏸️ ระงับเคส (On-Hold)</h3>
                  <p className="text-sm text-gray-700 mb-3">
                    <strong>ใช้เมื่อ:</strong> รอข้อมูลหรือการประสานงานภายนอก
                  </p>
                  <div className="bg-yellow-50 rounded-lg p-4 space-y-2 text-sm">
                    <p className="text-yellow-900"><strong>ตัวอย่างสถานการณ์:</strong></p>
                    <ul className="space-y-1 text-gray-700 ml-4">
                      <li>• รอการอนุมัติจากผู้บริหารเพื่อทำการเปลี่ยนแปลง</li>
                      <li>• รอทีมพัฒนาตรวจสอบและแก้ไขโค้ด</li>
                      <li>• รอการทดสอบในสภาพแวดล้อม UAT</li>
                      <li>• รอข้อมูลเพิ่มเติมจาก Tier 1 หรือลูกค้า</li>
                    </ul>
                    <p className="text-yellow-900 pt-2"><strong>ขั้นตอน:</strong></p>
                    <p className="text-gray-700">1. คลิก "ระงับเคส" → 2. ระบุว่ารออะไร → 3. ตั้งเตือนเพื่อติดตาม</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Decision Flow */}
        <Card className="border-orange-300 mb-8 bg-gradient-to-br from-orange-50 via-white to-red-50">
          <CardHeader>
            <CardTitle className="text-orange-900">⚡ Flow การตัดสินใจด่วน (Tier 2 SA)</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <DecisionFlowchart tier={2} />
          </CardContent>
        </Card>

        {/* Tier Escalation Diagram */}
        <Card className="border-orange-300 mb-8 bg-gradient-to-br from-orange-50 via-white to-red-50">
          <CardHeader>
            <CardTitle className="text-orange-900">📊 แผนการส่งต่อเคส</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <TierEscalationDiagram currentTier={2} />
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card className="border-orange-200 bg-gradient-to-r from-orange-600 to-orange-700 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="mb-4 text-white">พร้อมที่จะแก้ไขปัญหาทางเทคนิคแล้วหรือยัง?</h2>
            <p className="mb-6 text-orange-100">
              เริ่มต้นวิเคราะห์และแก้ไขปัญหาด้วยความเชี่ยวชาญของคุณ
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('/admin/tickets')}
              >
                ดูงานด้านเทคนิค
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-orange-600"
                onClick={() => onNavigate('/admin/sa')}
              >
                ไปที่แดชบอร์ด SA
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Tier2JourneyPage;