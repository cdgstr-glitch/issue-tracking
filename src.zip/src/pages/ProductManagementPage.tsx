import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { 
  ArrowLeft, 
  Plus, 
  Search, 
  Package, 
  Edit2, 
  Trash2,
  FileText,
  Users,
  Building,
  Briefcase,
  AlertTriangle
} from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { toast } from 'sonner@2.0.3';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../components/ui/dialog';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

interface ProductManagementPageProps {
  onNavigate: (path: string) => void;
}

// Category configuration
const CATEGORY_CONFIG: Record<string, { 
  label: string; 
  icon: any; 
  color: string;
  bgColor: string;
}> = {
  document: {
    label: 'เอกสารและสารบรรณ',
    icon: FileText,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  asset: {
    label: 'ทรัพย์สิน',
    icon: Package,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  hr: {
    label: 'ทรัพยากรบุคคล',
    icon: Users,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50'
  },
  facility: {
    label: 'สิ่งอำนวยความสะดวก',
    icon: Building,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50'
  },
  project: {
    label: 'โครงการและติดตาม',
    icon: Briefcase,
    color: 'text-red-600',
    bgColor: 'bg-red-50'
  },
  software: {
    label: 'ซอฟต์แวร์',
    icon: Package,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50'
  },
  service: {
    label: 'บริการ',
    icon: Users,
    color: 'text-teal-600',
    bgColor: 'bg-teal-50'
  }
};
export default function ProductManagementPage({ onNavigate }: ProductManagementPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any | null>(null);
  const [deletingProduct, setDeletingProduct] = useState<any | null>(null);
  const [replacementProductValue, setReplacementProductValue] = useState('');

  // ✅ Fetch data from DB
  const ALL_PRODUCTS = db.products.getAll();
  const tickets = db.tickets.getAll();
  const projects = db.projects.getAll();

  // Form state for add/edit
  const [formData, setFormData] = useState({
    value: '',
    label: '',
    description: '',
    category: 'document'
  });

  // Filter products by search
  const filteredProducts = ALL_PRODUCTS.filter(product => {
    const searchLower = searchQuery.toLowerCase();
    const config = CATEGORY_CONFIG[product.category] || CATEGORY_CONFIG.software;
    return (
      product.label.toLowerCase().includes(searchLower) ||
      product.value.toLowerCase().includes(searchLower) ||
      product.description?.toLowerCase().includes(searchLower) ||
      config.label.toLowerCase().includes(searchLower)
    );
  });

  // Group by category
  const productsByCategory = filteredProducts.reduce((acc, product) => {
    if (!acc[product.category]) {
      acc[product.category] = [];
    }
    acc[product.category].push(product);
    return acc;
  }, {} as Record<string, any[]>);

  // Reset form
  const resetForm = () => {
    setFormData({
      value: '',
      label: '',
      description: '',
      category: 'document'
    });
  };

  // Validate form
  const validateForm = (): string | null => {
    if (!formData.value.trim()) return 'กรุณากรอกรหัสผลิตภัณฑ์';
    if (!formData.label.trim()) return 'กรุณากรอกชื่อผลิตภัณฑ์';
    if (!formData.description.trim()) return 'กรุณากรอกคำอธิบาย';
    
    // Check kebab-case format
    if (!/^[a-z0-9-]+$/.test(formData.value)) {
      return 'รหัสผลิตภัณฑ์ต้องเป็นตัวพิมพ์เล็กและใช้ - คั่นเท่านั้น';
    }

    // Check duplicate (when adding)
    if (!editingProduct && ALL_PRODUCTS.some(p => p.value === formData.value)) {
      return 'รหัสผลิตภัณฑ์นี้มีอยู่แล้ว';
    }

    return null;
  };

  // Handle add product
  const handleAddProduct = () => {
    const error = validateForm();
    if (error) {
      toast.error(error);
      return;
    }

    // Add to DB
    db.products.add(formData);
    
    toast.success(`เพิ่มผลิตภัณฑ์ "${formData.label}" เรียบร้อย`);
    setShowAddModal(false);
    resetForm();
  };

  // Handle edit product
  const handleEditProduct = () => {
    if (!editingProduct) return;

    const error = validateForm();
    if (error) {
      toast.error(error);
      return;
    }

    // Update in DB
    db.products.update(editingProduct.value, {
      name: formData.label, // Map back to DB field name
      description: formData.description,
      category: formData.category
    });
      
    toast.success(`แก้ไขผลิตภัณฑ์ "${formData.label}" เรียบร้อย`);
    setShowEditModal(false);
    setEditingProduct(null);
    resetForm();
  };

  // Handle delete product
  const handleDeleteProduct = () => {
    if (!deletingProduct || !replacementProductValue) {
      toast.error('กรุณาเลือกผลิตภัณฑ์ทดแทน');
      return;
    }

    const oldValue = deletingProduct.value;
    const newValue = replacementProductValue;

    // ✅ 1. Migrate ข้อมูล Tickets จริงๆ
    let ticketsMigrated = 0;
    tickets.forEach(ticket => {
      if (ticket.productValue === oldValue) {
        ticket.productValue = newValue;
        ticketsMigrated++;
      }
    });

    // ✅ 2. Migrate ข้อมูล Projects จริงๆ
    let projectsMigrated = 0;
    projects.forEach(project => {
      if (project.purchasedProducts?.includes(oldValue)) {
        const index = project.purchasedProducts.indexOf(oldValue);
        if (index !== -1) {
          project.purchasedProducts[index] = newValue;
          projectsMigrated++;
        }
      }
    });

    // ✅ 3. ลบผลิตภัณฑ์ออกจาก DB
    const success = db.products.delete(oldValue);
    
    if (success) {
      const replacementProduct = ALL_PRODUCTS.find(p => p.value === newValue);
      
      toast.success(
        `ลบผลิตภัณฑ์ "${deletingProduct.label}" เรียบร้อย\n` +
        `✅ ย้ายข้อมูล ${ticketsMigrated} เคส และ ${projectsMigrated} โครงการ → ${replacementProduct?.label || newValue}`
      );
      
      setShowDeleteModal(false);
      setDeletingProduct(null);
      setReplacementProductValue('');
    }
  };

  // Get product usage statistics (จากข้อมูลจริง)
  const getProductUsageStats = (productValue: string) => {
    // ✅ นับจำนวนเคสจริงๆ
    const ticketCount = tickets.filter(
      ticket => ticket.productValue === productValue
    ).length;
    
    // ✅ นับจำนวนโครงการจริงๆ
    const projectCount = projects.filter(
      project => project.purchasedProducts?.includes(productValue)
    ).length;
    
    return { ticketCount, projectCount };
  };

  // Open edit modal
  const openEditModal = (product: any) => {
    setEditingProduct(product);
    setFormData({
      value: product.value,
      label: product.label,
      description: product.description || '',
      category: product.category
    });
    setShowEditModal(true);
  };

  // Open delete modal
  const openDeleteModal = (product: any) => {
    setDeletingProduct(product);
    setReplacementProductValue('');
    setShowDeleteModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto max-w-6xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('/admin/settings')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              กลับ
            </Button>
            <div>
              <h1 className="text-3xl mb-1 flex items-center gap-2">
                <Package className="h-8 w-8 text-blue-600" />
                จัดการผลิตภัณฑ์
              </h1>
              <p className="text-gray-600">
                เพิ่ม แก้ไข หรือลบผลิตภัณฑ์ที่ CDGS จำหน่าย
              </p>
            </div>
          </div>
          <Button onClick={() => setShowAddModal(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            เพิ่มผลิตภัณฑ์ใหม่
          </Button>
        </div>

        {/* Search */}
        <Card>
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="ค้นหาผลิตภัณฑ์ตามชื่อ รหัส หรือหมวดหมู่..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Statistics */}
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>ผลิตภัณฑ์ทั้งหมด</CardDescription>
              <CardTitle className="text-3xl">{ALL_PRODUCTS.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>หมวดหมู่</CardDescription>
              <CardTitle className="text-3xl">
                {Object.keys(productsByCategory).length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>ผลลัพธ์การค้นหา</CardDescription>
              <CardTitle className="text-3xl">{filteredProducts.length}</CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Products by Category */}
        <div className="space-y-4">
          {Object.keys(productsByCategory).map(category => {
            const products = productsByCategory[category];
            const config = CATEGORY_CONFIG[category] || CATEGORY_CONFIG.software;
            const Icon = config.icon;

            return (
              <Card key={category} className={config.bgColor}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Icon className={`h-5 w-5 ${config.color}`} />
                    {config.label} ({products.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {products.map(product => (
                      <div
                        key={product.value}
                        className="flex items-center justify-between p-4 bg-white border rounded-lg hover:shadow-sm transition-shadow"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold">{product.label}</h3>
                            <Badge variant="outline" className="text-xs">
                              {product.value}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            {product.description}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditModal(product)}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openDeleteModal(product)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Add Product Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>เพิ่มผลิตภัณฑ์ใหม่</DialogTitle>
            <DialogDescription>
              กรอกข้อมูลผลิตภัณฑ์ใหม่ที่ต้องการเพิ่มเข้าระบบ
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="add-value">
                รหัสผลิตภัณฑ์ <span className="text-red-500">*</span>
              </Label>
              <Input
                id="add-value"
                placeholder="e-workflow"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: e.target.value.toLowerCase() })}
              />
              <p className="text-xs text-gray-500">
                ต้องเป็นตัวพิมพ์เล็ก ใช้ - คั่น (เช่น e-workflow)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="add-label">
                ชื่อผลิตภัณฑ์ <span className="text-red-500">*</span>
              </Label>
              <Input
                id="add-label"
                placeholder="e-Workflow"
                value={formData.label}
                onChange={(e) => setFormData({ ...formData, label: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="add-description">
                คำอธิบาย <span className="text-red-500">*</span>
              </Label>
              <Input
                id="add-description"
                placeholder="ระบบจัดการเวิร์กโฟลว์"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="add-category">
                หมวดหมู่ <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger id="add-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(CATEGORY_CONFIG).map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {CATEGORY_CONFIG[cat].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowAddModal(false);
                resetForm();
              }}
            >
              ยกเลิก
            </Button>
            <Button onClick={handleAddProduct}>
              เพิ่มผลิตภัณฑ์
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Product Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>แก้ไขผลิตภัณฑ์</DialogTitle>
            <DialogDescription>
              แก้ไขข้อมูลผลิตภัณฑ์ (ไม่สามารถเปลี่ยนรหัสได้)
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>รหัสผลิตภัณฑ์</Label>
              <Input value={editingProduct?.value || ''} disabled />
              <p className="text-xs text-gray-500">
                ไม่สามารถเปลี่ยนรหัสได้ เนื่องจากถูกใช้อ้างอิงในระบบ
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-label">
                ชื่อผลิตภัณฑ์ <span className="text-red-500">*</span>
              </Label>
              <Input
                id="edit-label"
                value={formData.label}
                onChange={(e) => setFormData({ ...formData, label: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-description">
                คำอธิบาย <span className="text-red-500">*</span>
              </Label>
              <Input
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-category">
                หมวดหมู่ <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger id="edit-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(CATEGORY_CONFIG).map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {CATEGORY_CONFIG[cat].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowEditModal(false);
                setEditingProduct(null);
                resetForm();
              }}
            >
              ยกเลิก
            </Button>
            <Button onClick={handleEditProduct}>
              บันทึกการเปลี่ยนแปลง
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Product Modal */}
      <Dialog open={showDeleteModal} onOpenChange={setShowDeleteModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              ยืนยันการลบผลิตภัณฑ์
            </DialogTitle>
            <DialogDescription>
              การลบผลิตภัณฑ์จะย้ายข้อมูลทั้งหมดไปยังผลิตภัณฑ์ทดแทน
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="p-4 bg-red-50 border border-red-200 rounded">
              <p className="font-medium mb-2">
                คุณกำลังจะลบ: <span className="text-red-600">{deletingProduct?.label}</span>
              </p>
              <div className="text-sm space-y-1">
                <p>📊 การใช้งานปัจจุบัน:</p>
                <ul className="list-disc list-inside ml-2 space-y-1">
                  <li>มี {getProductUsageStats(deletingProduct?.value || '').ticketCount} เคสที่ใช้ผลิตภัณฑ์นี้</li>
                  <li>มี {getProductUsageStats(deletingProduct?.value || '').projectCount} โครงการที่ซื้อผลิตภัณฑ์นี้</li>
                </ul>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="replacement-product">
                กรุณาเลือกผลิตภัณฑ์ทดแทน <span className="text-red-500">*</span>
              </Label>
              <Select
                value={replacementProductValue}
                onValueChange={setReplacementProductValue}
              >
                <SelectTrigger id="replacement-product">
                  <SelectValue placeholder="เลือกผลิตภัณฑ์ทดแทน" />
                </SelectTrigger>
                <SelectContent>
                  {ALL_PRODUCTS
                    .filter(p => p.value !== deletingProduct?.value)
                    .map(product => (
                      <SelectItem key={product.value} value={product.value}>
                        {product.label}
                      </SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                ℹ️ ข้อมูลเดิมทั้งหมดจะถูกย้ายไปยังผลิตภัณฑ์ทดแทนที่เลือก
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDeleteModal(false);
                setDeletingProduct(null);
                setReplacementProductValue('');
              }}
            >
              ยกเลิก
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteProduct}
              disabled={!replacementProductValue}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              ยืนยันการลบ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}