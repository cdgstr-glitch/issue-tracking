import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getAllStatusConfigs, saveStatusConfig, resetStatusConfig, StatusConfig } from '../../lib/settings';
import { TicketStatus } from '../../types';
import { Check, RotateCcw, Save, Settings } from 'lucide-react';

export default function SystemSettingsPage() {
  const { user } = useAuth();
  const [configs, setConfigs] = useState<Record<TicketStatus, StatusConfig> | null>(null);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    // Load configs
    const current = getAllStatusConfigs();
    setConfigs(current);
  }, []);

  const handleChange = (status: TicketStatus, field: keyof StatusConfig, value: string) => {
    if (!configs) return;
    setConfigs({
      ...configs,
      [status]: {
        ...configs[status],
        [field]: value
      }
    });
  };

  const handleSave = () => {
    if (!configs) return;
    setSaving(true);
    
    // Simulate API delay
    setTimeout(() => {
      saveStatusConfig(configs);
      setSaving(false);
      setSuccessMessage('บันทึกการตั้งค่าเรียบร้อยแล้ว');
      setTimeout(() => setSuccessMessage(''), 3000);
      
      // Force reload to apply changes everywhere (simple way for prototype)
      window.location.reload();
    }, 800);
  };

  const handleReset = () => {
    if (confirm('คุณต้องการรีเซ็ตการตั้งค่าทั้งหมดกลับเป็นค่าเริ่มต้นใช่หรือไม่?')) {
      resetStatusConfig();
      window.location.reload();
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="p-8 text-center text-gray-500">
        คุณไม่มีสิทธิ์เข้าถึงหน้านี้ (Admin Only)
      </div>
    );
  }

  if (!configs) return <div className="p-8">Loading...</div>;

  return (
    <div className="max-w-5xl mx-auto py-8 px-4">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Settings className="h-6 w-6 text-indigo-600" />
            ตั้งค่าระบบ (System Settings)
          </h1>
          <p className="text-gray-500 mt-1">
            จัดการชื่อสถานะและข้อความที่แสดงในระบบ (Single Source of Truth)
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <RotateCcw className="h-4 w-4" />
            รีเซ็ตค่าเริ่มต้น
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
          >
            {saving ? 'กำลังบันทึก...' : (
              <>
                <Save className="h-4 w-4" />
                บันทึกการเปลี่ยนแปลง
              </>
            )}
          </button>
        </div>
      </div>

      {successMessage && (
        <div className="mb-6 p-4 bg-green-50 text-green-700 rounded-lg flex items-center gap-2 animate-fadeIn">
          <Check className="h-5 w-5" />
          {successMessage}
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200 bg-gray-50">
          <h2 className="font-semibold text-gray-900">จัดการสถานะ (Ticket Statuses)</h2>
          <p className="text-sm text-gray-500">
            แก้ไขชื่อที่แสดงต่อเจ้าหน้าที่ (Internal Label) และลูกค้า (Customer Label)
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-500">
              <tr>
                <th className="px-6 py-3 font-medium">Status Key</th>
                <th className="px-6 py-3 font-medium">Internal Label (เจ้าหน้าที่เห็น)</th>
                <th className="px-6 py-3 font-medium">Customer Label (ลูกค้าเห็น)</th>
                <th className="px-6 py-3 font-medium">Color Class</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {(Object.keys(configs) as TicketStatus[]).map((status) => (
                <tr key={status} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900 capitalize">
                    {status.replace('_', ' ')}
                  </td>
                  <td className="px-6 py-4">
                    <input
                      type="text"
                      value={configs[status].label}
                      onChange={(e) => handleChange(status, 'label', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <input
                      type="text"
                      value={configs[status].customerLabel || ''}
                      onChange={(e) => handleChange(status, 'customerLabel', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                      placeholder="Same as internal"
                    />
                  </td>
                  <td className="px-6 py-4 font-mono text-xs text-gray-500 max-w-xs truncate" title={configs[status].color}>
                    {configs[status].color}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-8 bg-blue-50 border border-blue-100 rounded-xl p-6">
        <h3 className="font-semibold text-blue-900 mb-2">คำแนะนำ</h3>
        <ul className="list-disc list-inside text-sm text-blue-800 space-y-1">
          <li><strong>Internal Label:</strong> ชื่อที่ใช้เรียกภายในองค์กรสำหรับเจ้าหน้าที่ทุกระดับ (Tier 1-3)</li>
          <li><strong>Customer Label:</strong> ชื่อที่เป็นมิตรที่ลูกค้าจะเห็น เช่น รวมสถานะ Tier 1-3 เป็น "กำลังดำเนินการ"</li>
          <li>การแก้ไขในหน้านี้จะมีผลทันทีทั่วทั้งระบบ (Real-time Single Source of Truth Update)</li>
        </ul>
      </div>
    </div>
  );
}
