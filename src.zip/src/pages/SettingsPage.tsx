import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Switch } from '../components/ui/switch';
import { Button } from '../components/ui/button';
import { Bell, User, Save, FolderOpen, Package, Clock, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface SettingsPageProps {
  onNavigate: (path: string) => void;
}
export default function SettingsPage({ onNavigate }: SettingsPageProps) {
  const { user } = useAuth();
  const [hasChanges, setHasChanges] = useState(false);

  const handleSave = () => {
    // TODO: Implement actual save logic
    // For now, just show toast
    toast.success('บันทึกการตั้งค่าเรียบร้อย');
    setHasChanges(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto max-w-4xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2">การตั้งค่า</h1>
            <p className="text-gray-600">จัดการการตั้งค่าบัญชีและการแจ้งเตือนของคุณ</p>
          </div>
          <Button 
            onClick={handleSave} 
            className="gap-2"
            disabled={!hasChanges}
          >
            <Save className="h-4 w-4" />
            บันทึกการเปลี่ยนแปลง
          </Button>
        </div>

        {/* Project Management Section - Admin Only */}
        {user?.roles?.includes('admin') && (
          <Card className="border-blue-200 bg-blue-50/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-blue-600" />
                จัดการโครงการและผลิตภัณฑ์
              </CardTitle>
              <CardDescription>
                กำหนดผลิตภัณฑ์ที่แต่ละโครงการซื้อไว้
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 border border-blue-200 rounded bg-white">
                  <div>
                    <div className="font-medium">การจัดการผลิตภัณฑ์โครงการ</div>
                    <p className="text-sm text-gray-600">
                      เลือกว่าแต่ละโครงการซื้อผลิตภัณฑ์ใดของเราบ้าง เพื่อให้ Staff เลือกได้ง่ายขึ้น
                    </p>
                  </div>
                  <Button 
                    onClick={() => onNavigate('/admin/settings/projects')}
                    variant="outline"
                    className="ml-4"
                  >
                    จัดการ
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border border-blue-200 rounded bg-white">
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      การจัดการผลิตภัณฑ์
                    </div>
                    <p className="text-sm text-gray-600">
                      เพิ่ม แก้ไข หรือลบผลิตภัณฑ์ที่ CDGS จำหน่าย
                    </p>
                  </div>
                  <Button 
                    onClick={() => onNavigate('/admin/settings/products')}
                    variant="outline"
                    className="ml-4"
                  >
                    จัดการ
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border border-blue-200 rounded bg-white">
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      ตั้งค่า SLA
                    </div>
                    <p className="text-sm text-gray-600">
                      กำหนดระยะเวลาการทำงาน (SLA) รายโครงการ หน่วยงาน และทั่วไป
                    </p>
                  </div>
                  <Button 
                    onClick={() => onNavigate('/admin/settings/sla')}
                    variant="outline"
                    className="ml-4"
                  >
                    จัดการ
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-blue-200 rounded bg-white">
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      ตั้งค่าสถานะระบบ (Ticket Statuses)
                    </div>
                    <p className="text-sm text-gray-600">
                      กำหนดชื่อสถานะ (Single Source of Truth) ที่แสดงต่อเจ้าหน้าที่และลูกค้า
                    </p>
                  </div>
                  <Button 
                    onClick={() => onNavigate('/admin/settings/system')}
                    variant="outline"
                    className="ml-4"
                  >
                    จัดการ
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-blue-200 rounded bg-white">
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      แบบประเมินความพึงพอใจ (CSAT)
                    </div>
                    <p className="text-sm text-gray-600">
                      เปิด/ปิด การแสดงแบบประเมินความพึงพอใจเมื่อเคสได้รับการแก้ไข
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">เปิดใช้งาน</span>
                    <Switch defaultChecked onChange={() => setHasChanges(true)} />
                  </div>
                </div>
                
                <p className="text-xs text-gray-500">
                  💡 <strong>คำแนะนำ:</strong> ตั้งค่าผลิตภัณฑ์ที่โครงการซื้อ เพื่อให้ Staff เห็นเฉพาะผลิตภัณฑ์ที่เกี่ยวข้องตอนแจ้งเคสแทนลูกค้า
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Profile Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              ข้อมูลโปรไฟล์
            </CardTitle>
            <CardDescription>
              ข้อมูลบัญชีและการเข้าถึงของคุณ
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-600">ชื่อ</label>
                <p className="font-medium">{user?.fullName}</p>
              </div>
              <div>
                <label className="text-sm text-gray-600">อีเมล</label>
                <p className="font-medium">{user?.email}</p>
              </div>
              <div>
                <label className="text-sm text-gray-600">บทบาท</label>
                <p className="font-medium">
                  {user?.role === 'tier1' && 'Tier 1 Support'}
                  {user?.role === 'tier2' && 'Tier 2 (SA)'}
                  {user?.role === 'tier3' && 'Tier 3 (Specialist)'}
                  {user?.role === 'admin' && 'ผู้ดูแลระบบ'}
                  {user?.role === 'customer' && 'ลูกค้า'}
                  {user?.role === 'staff' && 'เจ้าหน้าที่'}
                </p>
              </div>
              {user?.tier && (
                <div>
                  <label className="text-sm text-gray-600">Tier</label>
                  <p className="font-medium">Level {user.tier}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              การแจ้งเตือน
            </CardTitle>
            <CardDescription>
              จัดการการแจ้งเตือนและการส่งข่าวสาร
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <div className="font-medium">แจ้งเตือนเคสใหม่</div>
                  <p className="text-sm text-gray-600">รับการแจ้งเตือนเมื่อมีเคสใหม่</p>
                </div>
                <Switch defaultChecked onChange={() => setHasChanges(true)} />
              </div>
              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <div className="font-medium">แจ้งเตือน SLA</div>
                  <p className="text-sm text-gray-600">แจ้งเตือนเมื่อเคสใกล้หมดเวลา SLA</p>
                </div>
                <Switch defaultChecked onChange={() => setHasChanges(true)} />
              </div>
              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <div className="font-medium">แจ้งเตือนทางอีเมล</div>
                  <p className="text-sm text-gray-600">รับสรุปรายวันทางอีเมล</p>
                </div>
                <Switch onChange={() => setHasChanges(true)} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}