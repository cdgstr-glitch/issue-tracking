import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { ArrowLeft, Phone, Mail, MessageCircle, FileText, Clock, Search, CheckCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Header } from '../components/layout/Header';
import { Badge } from '../components/ui/badge';

interface StaffJourneyPageProps {
  onNavigate: (path: string) => void;
  onBackToMenu?: () => void;
}

const StaffJourneyPage: React.FC<StaffJourneyPageProps> = ({ onNavigate, onBackToMenu }) => {
  const { user } = useAuth();

  const steps = [
    {
      number: 1,
      icon: Phone,
      title: 'รับเคส',
      description: 'รับเรื่องจากลูกค้าผ่านอีเมล, Line, โทรศัพท์',
      details: [
        'ตรวจสอบช่องทางการติดต่อต่างๆ (อีเมล, Line, โทรศัพท์)',
        'รับฟังปัญหาและข้อมูลจากลูกค้า',
        'บันทึกข้อมูลเบื้องต้นของเคส',
        'ยืนยันการรับเรื่องกับลูกค้า'
      ],
      color: 'blue'
    },
    {
      number: 2,
      icon: FileText,
      title: 'บันทึกเคส',
      description: 'กรอกข้อมูลลูกค้าและรายละเอียดเคสในระบบ',
      details: [
        'เข้าสู่ระบบ CDGS Issue Tracking',
        'กรอกข้อมูลลูกค้า (ชื่อ, อีเมล, เบอร์โทร)',
        'เลือกหมวดหมู่ปัญหาที่เหมาะสม',
        'กรอกรายละเอียดปัญหาอย่างครบถ้วน',
        'แนบไฟล์หรือภาพประกอบ (ถ้ามี)'
      ],
      action: 'บันทึกเคสใหม่',
      actionPath: '/create',
      color: 'purple'
    },
    {
      number: 3,
      icon: Search,
      title: 'ส่งต่อ Tier 1',
      description: 'ระบบส่งเคสไปยังทีม Tier 1 อัตโนมัติ',
      details: [
        'ยืนยันข้อมูลก่อนส่ง',
        'กดปุ่ม "ส่งเคส"',
        'ระบบจะส่งเคสไปยังทีม Tier 1 โดยอัตโนมัติ',
        'ได้รับหมายเลขเคสสำหรับติดตาม',
        'แจ้งหมายเลขเคสให้ลูกค้าทราบ'
      ],
      color: 'indigo'
    },
    {
      number: 4,
      icon: Clock,
      title: 'รอตอบกลับ',
      description: 'รอทีม Tier 1 ตรวจสอบและแก้ไขปัญหา',
      details: [
        'ทีม Tier 1 จะรับเคสและเริ่มตรวจสอบ',
        'อาจมีการส่งต่อไปยัง Tier 2 หรือ Tier 3 หากจำเป็น',
        'สามารถติดตามสถานะผ่านระบบได้ตลอดเวลา',
        'รอการแจ้งเตือนเมื่อมีการอัพเดท'
      ],
      color: 'yellow'
    },
    {
      number: 5,
      icon: CheckCircle,
      title: 'ติดตามงาน',
      description: 'ตรวจสอบสถานะและแจ้งผลกลับให้ลูกค้า',
      details: [
        'ตรวจสอบสถานะเคสในระบบ',
        'อ่านข้อความการแก้ไขจากทีมงาน',
        'ติดต่อลูกค้าเพื่อแจ้งผลการแก้ไข',
        'ยืนยันว่าปัญหาได้รับการแก้ไขแล้ว',
        'ปิดเคสหากลูกค้าพึงพอใจ'
      ],
      color: 'green'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        text: 'text-blue-600',
        iconBg: 'bg-blue-600',
        gradient: 'from-blue-500 to-blue-600'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        text: 'text-purple-600',
        iconBg: 'bg-purple-600',
        gradient: 'from-purple-500 to-purple-600'
      },
      indigo: {
        bg: 'bg-indigo-50',
        border: 'border-indigo-200',
        text: 'text-indigo-600',
        iconBg: 'bg-indigo-600',
        gradient: 'from-indigo-500 to-indigo-600'
      },
      yellow: {
        bg: 'bg-yellow-50',
        border: 'border-yellow-200',
        text: 'text-yellow-600',
        iconBg: 'bg-yellow-600',
        gradient: 'from-yellow-500 to-yellow-600'
      },
      green: {
        bg: 'bg-green-50',
        border: 'border-green-200',
        text: 'text-green-600',
        iconBg: 'bg-green-600',
        gradient: 'from-green-500 to-green-600'
      }
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ✅ ใช้ Header component */}
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'staff'
        }}
        onNavigate={onNavigate}
        onInformationClick={onBackToMenu}
        currentPath="/staff-journey"
        showSearch={false}
      />

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* ✅ ปุ่มกลับหน้าแรก */}
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/')}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับหน้าแรก
        </Button>

        {/* Page Header */}
        <div className="mb-8 text-center">
          <p className="text-gray-600 text-lg mb-4">
            คู่มือการบันทึกเคสสำหรับเจ้าหน้าที่<br />
            ทำตามขั้นตอนเพื่อบันทึกและติดตามเคสของลูกค้า
          </p>

          {/* Channel Badges - Line, Email, Phone Only */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            <Badge variant="outline" className="border-green-600 text-green-700 px-4 py-1.5 flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              Line
            </Badge>
            <Badge variant="outline" className="border-red-600 text-red-700 px-4 py-1.5 flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Email
            </Badge>
            <Badge variant="outline" className="border-purple-600 text-purple-700 px-4 py-1.5 flex items-center gap-2">
              <Phone className="h-4 w-4" />
              โทรศัพท์
            </Badge>
          </div>

          {/* Main Action Card */}
          <Card className="max-w-md mx-auto border-purple-200 bg-gradient-to-r from-purple-50 to-purple-100">
            <CardContent className="p-8">
              <div className="flex justify-center mb-4">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600">
                  <FileText className="h-10 w-10 text-white" />
                </div>
              </div>
              <h2 className="mb-2 text-purple-900">บันทึกเคสใหม่</h2>
              <p className="text-purple-800 mb-4">
                บันทึกเคสที่ได้รับจากลูกค้าผ่านช่องทางต่างๆ<br />เข้าสู่ระบบเพื่อติดตามและจัดการ
              </p>
              <Button 
                size="lg" 
                className="bg-purple-600 hover:bg-purple-700"
                onClick={() => onNavigate('/create')}
              >
                เริ่มบันทึกเคส
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Journey Steps */}
        <div className="mb-12">
          <h2 className="mb-8 text-center">ขั้นตอนการใช้งาน</h2>

          {/* Desktop Flow - Horizontal */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Connecting Line */}
              <div className="absolute top-16 left-0 right-0 h-0.5 bg-gray-300" style={{ left: '10%', right: '10%' }} />
              
              <div className="grid grid-cols-5 gap-4">
                {steps.map((step, index) => {
                  const colors = getColorClasses(step.color);
                  const Icon = step.icon;
                  
                  return (
                    <div key={step.number} className="relative">
                      <Card className={`border-2 ${colors.border} ${colors.bg} h-full`}>
                        <CardContent className="p-6">
                          {/* Number Badge */}
                          <div className="flex justify-center mb-4">
                            <div className={`flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg relative z-10`}>
                              <Icon className="h-8 w-8 text-white" />
                            </div>
                          </div>

                          <h3 className={`mb-2 text-center ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-center text-sm text-gray-700 mb-4">
                            {step.description}
                          </p>

                          <ul className="space-y-2 mb-4">
                            {step.details.map((detail, idx) => (
                              <li key={idx} className="flex items-start text-sm text-gray-700">
                                <span className={`mr-2 ${colors.text}`}>•</span>
                                <span>{detail}</span>
                              </li>
                            ))}
                          </ul>

                          {step.action && (
                            <Button
                              variant="outline"
                              size="sm"
                              className={`w-full ${colors.text} border-current`}
                              onClick={() => onNavigate(step.actionPath!)}
                            >
                              {step.action}
                            </Button>
                          )}
                        </CardContent>
                      </Card>

                      {/* Arrow */}
                      {index < steps.length - 1 && (
                        <div className="absolute top-16 -right-2 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                          <ArrowRight className="h-4 w-4 text-gray-400" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Mobile/Tablet Flow - Vertical */}
          <div className="lg:hidden space-y-6">
            {steps.map((step, index) => {
              const colors = getColorClasses(step.color);
              const Icon = step.icon;
              
              return (
                <div key={step.number} className="relative">
                  <Card className={`border-2 ${colors.border} ${colors.bg}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        {/* Icon */}
                        <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg`}>
                          <Icon className="h-7 w-7 text-white" />
                        </div>

                        {/* Title */}
                        <div className="flex-1">
                          <h3 className={`mb-1 ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-sm text-gray-700">
                            {step.description}
                          </p>
                        </div>
                      </div>

                      <ul className="space-y-2 mb-4">
                        {step.details.map((detail, idx) => (
                          <li key={idx} className="flex items-start text-sm text-gray-700">
                            <span className={`mr-2 ${colors.text}`}>•</span>
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>

                      {step.action && (
                        <Button
                          variant="outline"
                          size="sm"
                          className={`w-full ${colors.text} border-current`}
                          onClick={() => onNavigate(step.actionPath!)}
                        >
                          {step.action}
                        </Button>
                      )}
                    </CardContent>
                  </Card>

                  {/* Vertical Arrow */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                        <ArrowRight className="h-4 w-4 rotate-90 text-gray-400" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-6 text-center">
              <div className="mb-3 text-3xl">📝</div>
              <h3 className="mb-2 text-blue-900">บันทึกง่าย</h3>
              <p className="text-sm text-blue-800">
                ฟอร์มที่ใช้งานง่าย<br />บันทึกได้รวดเร็ว
              </p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-purple-50">
            <CardContent className="p-6 text-center">
              <div className="mb-3 text-3xl">🔄</div>
              <h3 className="mb-2 text-purple-900">ติดตามได้</h3>
              <p className="text-sm text-purple-800">
                ดูสถานะและความคืบหน้า<br />ของทุกเคสได้ตลอดเวลา
              </p>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-6 text-center">
              <div className="mb-3 text-3xl">✅</div>
              <h3 className="mb-2 text-green-900">จัดการง่าย</h3>
              <p className="text-sm text-green-800">
                จัดการเคสทั้งหมด<br />ในที่เดียว
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <Card className="border-purple-200 bg-gradient-to-r from-purple-600 to-purple-700 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="mb-4 text-white">พร้อมที่จะเริ่มบันทึกเคสแล้วหรือยัง?</h2>
            <p className="mb-6 text-purple-100">
              เริ่มบันทึกเคสของลูกค้าและช่วยแก้ปัญหาได้ทันที
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('/create')}
              >
                บันทึกเคสแทนลูกค้าใหม่
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-purple-600"
                onClick={() => onNavigate('/admin')}
              >
                ดูเคสทั้งหมด
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StaffJourneyPage;