import { useState, useMemo, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Search, Paperclip, ArrowLeft, Filter, X } from 'lucide-react';
import { db } from '../lib/mockDb/client';
import { StatusBadge } from '../components/StatusBadge';
import { PriorityBadge } from '../components/PriorityBadge';
import { SLAIndicator } from '../components/SLAIndicator';
import { formatRelativeTime } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';
import { extractHashtags, removeHashtags } from '../lib/hashtagUtils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

interface CustomerTrackTicketPageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}
export default function CustomerTrackTicketPage({ onNavigate, onBackToMenu }: CustomerTrackTicketPageProps) {
  const { user, customer, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(15);

  // Filter states - Default เปิดอยู่
  const [showFilters, setShowFilters] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterSLA, setFilterSLA] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<string>('newest'); // newest, oldest

  // Redirect to home when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      console.log('User logged out, navigating to /');
      onNavigate('/');
    }
  }, [isAuthenticated, onNavigate]);

  // Filter tickets - customers see their own tickets only
  const userTickets = useMemo(() => {
    // Identify the current user credentials
    const currentEmail = customer?.email || user?.email;
    const currentUserId = customer?.id || user?.id;
    const currentUsername = user?.username;

    // Debug user identity
    console.log('CustomerTrackTicketPage: Identifying User', { 
      email: currentEmail, 
      id: currentUserId, 
      username: currentUsername 
    });

    // If no identity, return empty
    if (!currentEmail && !currentUserId && !currentUsername) return [];
    
    // Fetch tickets from DB
    const allTickets = db.tickets.getAll();

    const filtered = allTickets.filter(ticket => {
      // 1. Match by Email (Strongest match)
      if (currentEmail && ticket.customerEmail && ticket.customerEmail.toLowerCase() === currentEmail.toLowerCase()) {
        return true;
      }

      // 2. Match by User ID (Creator) - If the user created the ticket
      if (currentUserId && ticket.createdBy === currentUserId) {
        return true;
      }

      // 3. Fallback: Match by Username (if email is missing but username matches customerEmail field - rare but possible)
      if (!currentEmail && currentUsername && ticket.customerEmail === currentUsername) {
        return true;
      }
      
      return false;
    });
    
    return filtered;
  }, [user, customer]);

  // Filter tickets based on search query
  const filteredTickets = useMemo(() => {
    let result = userTickets;
    
    // Search query filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(ticket =>
        ticket.ticketNumber.toLowerCase().includes(query) ||
        ticket.title.toLowerCase().includes(query) ||
        ticket.category.toLowerCase().includes(query) ||
        ticket.status.toLowerCase().includes(query)
      );
    }
    
    // Status filter
    if (filterStatus !== 'all') {
      result = result.filter(ticket => ticket.status === filterStatus);
    }
    
    // SLA filter
    if (filterSLA !== 'all') {
      result = result.filter(ticket => {
        if (ticket.status === 'closed' || ticket.status === 'resolved') {
          return filterSLA === 'met';
        }
        
        const now = new Date();
        const due = new Date(ticket.dueDate);
        const timeLeft = due.getTime() - now.getTime();
        const hoursLeft = timeLeft / (1000 * 60 * 60);
        
        if (filterSLA === 'overdue') return hoursLeft < 0;
        if (filterSLA === 'at_risk') return hoursLeft >= 0 && hoursLeft <= 4;
        if (filterSLA === 'on_track') return hoursLeft > 4;
        return true;
      });
    }
    
    // Sort order
    if (sortOrder === 'newest') {
      result = [...result].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    } else if (sortOrder === 'oldest') {
      result = [...result].sort((a, b) => new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime());
    }
    
    return result;
  }, [searchQuery, userTickets, filterStatus, filterSLA, sortOrder]);
  
  // Clear all filters
  const clearFilters = () => {
    setFilterStatus('all');
    setFilterSLA('all');
    setCurrentPage(1);
  };
  
  // Check if any filter is active
  const hasActiveFilters = filterStatus !== 'all' || filterSLA !== 'all';

  // Pagination calculations
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedTickets = filteredTickets.slice(startIndex, endIndex);

  // Reset to page 1 when filters change
  const resetPagination = () => {
    setCurrentPage(1);
  };

  // Effect to reset pagination when search changes
  useMemo(() => {
    resetPagination();
  }, [searchQuery]);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        onClick={() => onNavigate('/')}
        className="gap-2 mb-4"
      >
        <ArrowLeft className="h-4 w-4" />
        กลับหน้าแรก
      </Button>

      {/* Page Header */}
      <div className="mb-6">
        <h1 className="mb-2">
          ติดตามเคสของลูกค้า {customer?.fullName || user?.fullName || 'ชื่อลูกค้า'}
        </h1>
        <p className="text-gray-600">
          ดูสถานะและความก้าวหน้าของเคสทั้งหมด
        </p>
      </div>

      {/* Search Bar */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="ค้นหาด้วยหมายเลขเคส, หัวเรื่อง, หมวดหมู่, หรือสถานะ..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Filter Section */}
      <Card className="mb-6">
        <CardContent className="p-4">
          {/* Filter Toggle Button */}
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2"
            >
              <Filter className="h-4 w-4" />
              {showFilters ? 'ซ่อนตัวกรอง' : 'แสดงตัวกรอง'}
              {hasActiveFilters && (
                <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-xs text-white">
                  {[filterStatus, filterSLA].filter(f => f !== 'all').length}
                </span>
              )}
            </Button>
            
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="gap-2 text-red-600 hover:text-red-700"
              >
                <X className="h-4 w-4" />
                ล้างตัวกรอง
              </Button>
            )}
          </div>

          {/* Filter Controls */}
          {showFilters && (
            <div className="pt-4 border-t">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* Status Filter */}
                <div>
                  <label className="text-xs font-medium mb-1.5 block text-gray-700">สถานะ</label>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="ทั้งหมด" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ทั้งหมด</SelectItem>
                      <SelectItem value="new">ใหม่</SelectItem>
                      <SelectItem value="in_progress">กำลังดำเนินการ</SelectItem>
                      <SelectItem value="on_hold">รอข้อมูล</SelectItem>
                      <SelectItem value="resolved">แก้ไขแล้ว</SelectItem>
                      <SelectItem value="closed">ปิดแล้ว</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* SLA Filter */}
                <div>
                  <label className="text-xs font-medium mb-1.5 block text-gray-700">สถานะ SLA</label>
                  <Select value={filterSLA} onValueChange={setFilterSLA}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="ทั้งหมด" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ทั้งหมด</SelectItem>
                      <SelectItem value="on_track">ตรงเวลา</SelectItem>
                      <SelectItem value="at_risk">ใกล้เกิน</SelectItem>
                      <SelectItem value="overdue">เกินกำหนด</SelectItem>
                      <SelectItem value="met">ทันกำหนด</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Sort Order */}
                <div>
                  <label className="text-xs font-medium mb-1.5 block text-gray-700">เรียงตาม</label>
                  <Select value={sortOrder} onValueChange={setSortOrder}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="เรียงลำดับ" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">ใหม่ไปเก่า</SelectItem>
                      <SelectItem value="oldest">เก่าไปใหม่</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="mb-4 flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-gray-600">
          {filteredTickets.length === userTickets.length
            ? `เคสทั้งหมด ${userTickets.length} รายการ`
            : `พบ ${filteredTickets.length} จาก ${userTickets.length} รายการ`}
        </p>
      </div>

      {/* Desktop Table View */}
      <Card className="hidden md:block">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs uppercase text-gray-600">
                    หมายเลขเคส
                  </th>
                  <th className="px-6 py-3 text-left text-xs uppercase text-gray-600">
                    หัวเรื่อง
                  </th>
                  <th className="px-6 py-3 text-left text-xs uppercase text-gray-600">
                    สถานะ
                  </th>
                  <th className="px-6 py-3 text-left text-xs uppercase text-gray-600">
                    ไฟล์แนบ
                  </th>
                  <th className="px-6 py-3 text-left text-xs uppercase text-gray-600">
                    SLA
                  </th>
                  <th className="px-6 py-3 text-left text-xs uppercase text-gray-600">
                    อัปเดตล่าสุด
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {paginatedTickets.length > 0 ? (
                  paginatedTickets.map((ticket) => (
                    <tr
                      key={ticket.id}
                      className="cursor-pointer transition-colors hover:bg-gray-50"
                      onClick={() => onNavigate('/track-ticket-detail', ticket.id)}
                    >
                      <td className="px-6 py-4">
                        <p className="text-blue-600">{ticket.ticketNumber}</p>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-baseline gap-2 flex-wrap mb-1">
                          <p className="line-clamp-2 m-0">{removeHashtags(ticket.title)}</p>
                          {extractHashtags(ticket.title).length > 0 && (
                            <div className="flex gap-1.5 flex-wrap">
                              {extractHashtags(ticket.title).map((hashtag, idx) => (
                                <span
                                  key={idx}
                                  className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700"
                                >
                                  {hashtag}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">{ticket.category}</p>
                      </td>
                      <td className="px-6 py-4">
                        <StatusBadge status={ticket.status} size="sm" userRole="customer" />
                      </td>
                      <td className="px-6 py-4">
                        {ticket.attachments && ticket.attachments.length > 0 ? (
                          <div className="flex items-center gap-1.5 text-gray-600">
                            <Paperclip className="h-4 w-4" />
                            <span className="text-sm">{ticket.attachments.length}</span>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400">-</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <SLAIndicator
                          createdAt={ticket.createdAt}
                          dueDate={ticket.dueDate}
                          status={ticket.status}
                        />
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {formatRelativeTime(ticket.updatedAt)}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                      {searchQuery
                        ? 'ไม่พบเคสที่ตรงกับคำค้นหา'
                        : 'ยังไม่มีเคสในระบบ'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Mobile Card View */}
      <div className="grid gap-4 md:hidden">
        {paginatedTickets.length > 0 ? (
          paginatedTickets.map((ticket) => (
            <Card
              key={ticket.id}
              className="cursor-pointer transition-shadow hover:shadow-md"
              onClick={() => onNavigate('/track-ticket-detail', ticket.id)}
            >
              <CardContent className="p-4">
                <div className="mb-3">
                  <p className="text-xs text-blue-600">{ticket.ticketNumber}</p>
                  <div className="flex items-baseline gap-2 flex-wrap mt-1">
                    <h3 className="m-0 line-clamp-2">{removeHashtags(ticket.title)}</h3>
                    {extractHashtags(ticket.title).length > 0 && (
                      <div className="flex gap-1.5 flex-wrap">
                        {extractHashtags(ticket.title).map((hashtag, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700"
                          >
                            {hashtag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{ticket.category}</p>
                </div>

                <div className="mb-3 flex flex-wrap gap-2">
                  <StatusBadge status={ticket.status} size="sm" userRole="customer" />
                </div>

                <div className="flex items-center justify-between border-t pt-3">
                  <SLAIndicator
                    createdAt={ticket.createdAt}
                    dueDate={ticket.dueDate}
                    status={ticket.status}
                    showLabel={false}
                  />
                  <p className="text-xs text-gray-600">
                    {formatRelativeTime(ticket.updatedAt)}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="p-8 text-center text-gray-500">
              {searchQuery
                ? 'ไม่พบเคสที่ตรงกับคำค้นหา'
                : 'ยังไม่มีเคสในระบบ'}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Pagination */}
      {filteredTickets.length > 0 && (
        <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          {/* Left side - Summary and Page Size */}
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
            <span className="text-sm text-gray-600">
              แสดง {startIndex + 1}-{Math.min(endIndex, filteredTickets.length)} จาก {filteredTickets.length} รายการ
            </span>
            <Select
              value={itemsPerPage.toString()}
              onValueChange={(value) => {
                setItemsPerPage(Number(value));
                setCurrentPage(1); // Reset to page 1 when changing items per page
              }}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 รายการ</SelectItem>
                <SelectItem value="15">15 รายการ</SelectItem>
                <SelectItem value="25">25 รายการ</SelectItem>
                <SelectItem value="50">50 รายการ</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Right side - Page Navigation */}
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            >
              ก่อนหน้า
            </Button>

            {/* Page numbers */}
            <div className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(page => {
                  // Show first page, last page, current page, and pages around current
                  if (page === 1 || page === totalPages) return true;
                  if (Math.abs(page - currentPage) <= 1) return true;
                  return false;
                })
                .map((page, idx, array) => (
                  <div key={page} className="flex items-center gap-1">
                    {idx > 0 && array[idx - 1] !== page - 1 && (
                      <span className="px-1 text-gray-400">...</span>
                    )}
                    <Button
                      variant={currentPage === page ? 'default' : 'outline'}
                      size="sm"
                      className="min-w-[32px] h-8"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </Button>
                  </div>
                ))}
            </div>

            <Button 
              variant="outline" 
              size="sm" 
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            >
              ถัดไป
            </Button>
          </div>
        </div>
      )}

      {/* Tips Card */}
      {userTickets.length === 0 && (
        <Card className="mt-6 border-blue-200 bg-blue-50">
          <CardContent className="p-6">
            <h3 className="mb-2 text-blue-900">💡 เริ่มต้นใช้งาน</h3>
            <p className="text-blue-800">
              ยังไม่มีเคสในระบบ คุณสามารถสร้างเคสใหม่ได้โดยคลิกปุ่ม "สร้างเคสใหม่" ที่ด้านบน
            </p>
            <Button 
              className="mt-4"
              onClick={() => onNavigate('/create')}
            >
              สร้างเคสใหม่
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}