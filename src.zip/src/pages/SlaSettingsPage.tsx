import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { can, CAPABILITIES } from '../lib/permissions';
import { Header } from '../components/layout/Header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { db } from '../lib/mockDb/client';
import { TicketPriority, TicketType } from '../types';
import { RawSlaSetting } from '../lib/mockDb/types';
import { Clock, Building2, Briefcase, Plus, Save, Trash2, ArrowLeft, AlertCircle } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';

interface SLATableProps {
  scope: 'general' | 'organization' | 'project';
  targetId?: string;
}

function SLATable({ scope, targetId }: SLATableProps) {
  const [settings, setSettings] = useState<RawSlaSetting[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  
  // Create mode state
  const [isCreating, setIsCreating] = useState(false);
  const [newPriority, setNewPriority] = useState<TicketPriority>('medium');
  const [newType, setNewType] = useState<TicketType>('incident');
  const [newHours, setNewHours] = useState<string>('24');

  useEffect(() => {
    loadSettings();
  }, [scope, targetId]);

  const loadSettings = () => {
    const data = db.slaSettings.getByScope(scope, targetId);
    setSettings(data);
  };

  const handleEdit = (setting: RawSlaSetting) => {
    setEditingId(setting.id);
    setEditValue(setting.hours.toString());
  };

  const handleSave = () => {
    if (!editingId) return;
    const hours = parseFloat(editValue);
    if (isNaN(hours) || hours <= 0) {
      toast.error('กรุณาระบุจำนวนชั่วโมงที่ถูกต้อง');
      return;
    }
    
    db.slaSettings.update(editingId, hours);
    toast.success('บันทึกข้อมูลเรียบร้อยแล้ว');
    setEditingId(null);
    loadSettings();
  };

  const handleDelete = (id: string) => {
    if (confirm('คุณต้องการลบการตั้งค่านี้ใช่หรือไม่?')) {
      db.slaSettings.delete(id);
      toast.success('ลบข้อมูลเรียบร้อยแล้ว');
      loadSettings();
    }
  };

  const handleCreate = () => {
    const hours = parseFloat(newHours);
    if (isNaN(hours) || hours <= 0) {
      toast.error('กรุณาระบุจำนวนชั่วโมงที่ถูกต้อง');
      return;
    }

    // Check duplicate
    const exists = settings.some(s => s.priority === newPriority && s.ticketType === newType);
    if (exists) {
      toast.error('มีการตั้งค่าสำหรับเงื่อนไขนี้อยู่แล้ว');
      return;
    }

    db.slaSettings.upsert({
      priority: newPriority,
      ticketType: newType,
      hours: hours,
      organizationId: scope === 'organization' ? targetId : undefined,
      projectId: scope === 'project' ? targetId : undefined
    });

    toast.success('เพิ่มการตั้งค่าเรียบร้อยแล้ว');
    setIsCreating(false);
    loadSettings();
  };

  // Helper to get remaining combinations to add
  const priorities: TicketPriority[] = ['critical', 'high', 'medium', 'low'];
  const types: TicketType[] = ['incident', 'service_request', 'security_incident'];

  return (
    <div className="space-y-4">
      {settings.length === 0 && !isCreating ? (
        <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-300">
          <Clock className="mx-auto h-8 w-8 text-gray-400 mb-2" />
          <p className="text-gray-500 mb-4">ยังไม่มีการตั้งค่า SLA สำหรับส่วนนี้ (จะใช้ค่า Default)</p>
          <Button onClick={() => setIsCreating(true)} variant="outline">
            <Plus className="h-4 w-4 mr-2" />
            เพิ่มการตั้งค่า
          </Button>
        </div>
      ) : (
        <>
          <div className="flex justify-end">
            {!isCreating && (
              <Button onClick={() => setIsCreating(true)} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                เพิ่มการตั้งค่าใหม่
              </Button>
            )}
          </div>

          <div className="bg-white rounded-md border">
            <div className="grid grid-cols-12 gap-4 p-3 bg-gray-50 border-b text-sm font-medium text-gray-500">
              <div className="col-span-3">Priority</div>
              <div className="col-span-3">Type</div>
              <div className="col-span-3">Hours</div>
              <div className="col-span-3 text-right">Actions</div>
            </div>

            {settings.map((setting) => (
              <div key={setting.id} className="grid grid-cols-12 gap-4 p-3 items-center border-b last:border-0 hover:bg-gray-50 transition-colors">
                <div className="col-span-3">
                  <Badge variant="outline" className={`
                    ${setting.priority === 'critical' ? 'bg-red-50 text-red-700 border-red-200' : ''}
                    ${setting.priority === 'high' ? 'bg-orange-50 text-orange-700 border-orange-200' : ''}
                    ${setting.priority === 'medium' ? 'bg-blue-50 text-blue-700 border-blue-200' : ''}
                    ${setting.priority === 'low' ? 'bg-gray-50 text-gray-700 border-gray-200' : ''}
                  `}>
                    {setting.priority.toUpperCase()}
                  </Badge>
                </div>
                <div className="col-span-3">
                  <span className="text-sm text-gray-700">
                    {setting.ticketType === 'incident' ? 'Incident' : 
                     setting.ticketType === 'service_request' ? 'Service Request' : 'Security Incident'}
                  </span>
                </div>
                <div className="col-span-3">
                  {editingId === setting.id ? (
                    <div className="flex items-center gap-2">
                      <Input 
                        type="number" 
                        value={editValue} 
                        onChange={(e) => setEditValue(e.target.value)}
                        className="h-8 w-24"
                      />
                      <span className="text-xs text-gray-500">ชม.</span>
                    </div>
                  ) : (
                    <span className="text-sm font-medium">{setting.hours} ชม.</span>
                  )}
                </div>
                <div className="col-span-3 flex justify-end gap-2">
                  {editingId === setting.id ? (
                    <>
                      <Button size="sm" variant="default" onClick={handleSave} className="h-8 w-8 p-0">
                        <Save className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditingId(null)} className="h-8 w-8 p-0 text-gray-500">
                        X
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button size="sm" variant="outline" onClick={() => handleEdit(setting)}>
                        แก้ไข
                      </Button>
                      <Button size="sm" variant="ghost" className="text-red-500 hover:text-red-600 hover:bg-red-50" onClick={() => handleDelete(setting.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}

            {isCreating && (
              <div className="grid grid-cols-12 gap-4 p-3 items-center bg-blue-50/50 border-t animate-in fade-in slide-in-from-top-2">
                <div className="col-span-3">
                  <Select value={newPriority} onValueChange={(v: any) => setNewPriority(v)}>
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-3">
                  <Select value={newType} onValueChange={(v: any) => setNewType(v)}>
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="incident">Incident</SelectItem>
                      <SelectItem value="service_request">Service Request</SelectItem>
                      <SelectItem value="security_incident">Security Incident</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-3">
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      value={newHours} 
                      onChange={(e) => setNewHours(e.target.value)}
                      className="h-9 w-full"
                      placeholder="Hours"
                    />
                    <span className="text-xs text-gray-500">ชม.</span>
                  </div>
                </div>
                <div className="col-span-3 flex justify-end gap-2">
                  <Button size="sm" onClick={handleCreate}>บันทึก</Button>
                  <Button size="sm" variant="ghost" onClick={() => setIsCreating(false)}>ยกเลิก</Button>
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
export default function SlaSettingsPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('general');
  const [selectedOrgId, setSelectedOrgId] = useState<string>('');
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');

  const organizations = db.organizations.getAll();
  const projects = db.projects.getAll();

  // Redirect if not authorized
  if (!user || !can(user, CAPABILITIES.MANAGE_SLA)) {
    // Note: Assuming MANAGE_SLA is implied for Admins. 
    // If permission specific, we should check user.role === 'admin' directly if capability isn't in older permissions.ts
    if (user?.role !== 'admin') {
      return (
        <div className="container mx-auto p-8 text-center">
          <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
          <p className="mt-2 text-gray-600">คุณไม่มีสิทธิ์เข้าถึงหน้านี้</p>
        </div>
      );
    }
  }

  return (
    <div className="min-h-screen bg-gray-50/50">
      <Header 
        user={{ fullName: user?.fullName || '', role: user?.role || 'admin' }} 
        onNavigate={(path) => window.location.hash = path} // Simple hash nav for now or props based
        currentPath="/admin/sla-settings"
      />
      
      <div className="container mx-auto py-8 px-4 max-w-6xl">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-gray-900">ตั้งค่า SLA</h1>
            <p className="text-gray-500 mt-2">กำหนดระยะเวลาการทำงานมาตรฐาน (Service Level Agreement)</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 h-auto p-1 bg-white border shadow-sm">
            <TabsTrigger value="project" className="py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 data-[state=active]:border-blue-200">
              <Briefcase className="w-4 h-4 mr-2" />
              <div className="text-left">
                <div className="font-semibold">รายโครงการ (Project)</div>
                <div className="text-xs opacity-70">สำคัญสูงสุด (Priority 1)</div>
              </div>
            </TabsTrigger>
            <TabsTrigger value="organization" className="py-3 data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700 data-[state=active]:border-purple-200">
              <Building2 className="w-4 h-4 mr-2" />
              <div className="text-left">
                <div className="font-semibold">รายหน่วยงาน (Organization)</div>
                <div className="text-xs opacity-70">สำคัญปานกลาง (Priority 2)</div>
              </div>
            </TabsTrigger>
            <TabsTrigger value="general" className="py-3 data-[state=active]:bg-gray-100">
              <Clock className="w-4 h-4 mr-2" />
              <div className="text-left">
                <div className="font-semibold">ทั่วไป (General)</div>
                <div className="text-xs opacity-70">ค่าเริ่มต้น (Priority 3)</div>
              </div>
            </TabsTrigger>
          </TabsList>

          {/* PROJECT TAB */}
          <TabsContent value="project">
            <Card>
              <CardHeader>
                <CardTitle>ตั้งค่า SLA รายโครงการ</CardTitle>
                <CardDescription>
                  การตั้งค่าในส่วนนี้จะมีความสำคัญสูงสุด และจะถูกนำมาใช้ก่อนการตั้งค่าอื่นๆ
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col gap-2">
                  <Label>เลือกโครงการ</Label>
                  <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                    <SelectTrigger className="w-full md:w-[400px]">
                      <SelectValue placeholder="ค้นหาหรือเลือกโครงการ..." />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map(p => (
                        <SelectItem key={p.id} value={p.id}>
                          <span className="font-medium mr-2">{p.projectCode}</span>
                          <span className="text-gray-500 text-xs">({p.projectName})</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedProjectId ? (
                  <div className="animate-in fade-in slide-in-from-bottom-2">
                     <div className="mb-4 p-3 bg-blue-50 text-blue-800 rounded-md text-sm flex items-center gap-2">
                        <Briefcase className="h-4 w-4" />
                        กำลังตั้งค่า SLA สำหรับโครงการ: <strong>{projects.find(p => p.id === selectedProjectId)?.projectCode}</strong>
                     </div>
                    <SLATable scope="project" targetId={selectedProjectId} />
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-400 bg-gray-50 rounded-lg border border-dashed">
                    <Briefcase className="mx-auto h-12 w-12 opacity-50 mb-3" />
                    <p>กรุณาเลือกโครงการเพื่อเริ่มตั้งค่า</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ORGANIZATION TAB */}
          <TabsContent value="organization">
            <Card>
              <CardHeader>
                <CardTitle>ตั้งค่า SLA รายหน่วยงาน</CardTitle>
                <CardDescription>
                  ใช้เมื่อไม่มีการกำหนดค่าในระดับโครงการ จะใช้ค่าของหน่วยงานแทน
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col gap-2">
                  <Label>เลือกหน่วยงาน</Label>
                  <Select value={selectedOrgId} onValueChange={setSelectedOrgId}>
                    <SelectTrigger className="w-full md:w-[400px]">
                      <SelectValue placeholder="ค้นหาหรือเลือกหน่วยงาน..." />
                    </SelectTrigger>
                    <SelectContent>
                      {organizations.map(o => (
                        <SelectItem key={o.id} value={o.id}>
                          <span className="font-medium mr-2">{o.code}</span>
                          <span className="text-gray-500 text-xs">({o.name})</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedOrgId ? (
                  <div className="animate-in fade-in slide-in-from-bottom-2">
                    <div className="mb-4 p-3 bg-purple-50 text-purple-800 rounded-md text-sm flex items-center gap-2">
                        <Building2 className="h-4 w-4" />
                        กำลังตั้งค่า SLA สำหรับหน่วยงาน: <strong>{organizations.find(o => o.id === selectedOrgId)?.name}</strong>
                     </div>
                    <SLATable scope="organization" targetId={selectedOrgId} />
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-400 bg-gray-50 rounded-lg border border-dashed">
                    <Building2 className="mx-auto h-12 w-12 opacity-50 mb-3" />
                    <p>กรุณาเลือกหน่วยงานเพื่อเริ่มตั้งค่า</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* GENERAL TAB */}
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>ตั้งค่า SLA ทั่วไป</CardTitle>
                <CardDescription>
                  ค่าเริ่มต้นสำหรับระบบ จะถูกใช้เมื่อไม่มีการกำหนดค่าในระดับโครงการและหน่วยงาน
                </CardDescription>
              </CardHeader>
              <CardContent>
                 <div className="mb-4 p-3 bg-gray-100 text-gray-700 rounded-md text-sm flex items-center gap-2">
                    <AlertCircle className="h-4 w-4" />
                    การแก้ไขในส่วนนี้จะมีผลกับทั้งระบบ (ยกเว้นที่มีการกำหนด Override ไว้)
                 </div>
                <SLATable scope="general" />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}