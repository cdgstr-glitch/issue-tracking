import { useState, useMemo } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Eye, EyeOff, Mail, CheckCircle, AlertCircle, Loader2, LogOut, HelpCircle } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { validateEmail } from '../lib/magicLink';
import { createMagicLinkToken, generateMagicLinkURL } from '../lib/magicLink';
import { sendMagicLinkEmail } from '../lib/emailTemplates';
import { EmailPreview } from '../components/customer/EmailPreview';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../components/ui/dialog';
import imgImage4 from '../assets/e6673285d07284ae5db1591edc6cbb88211b3d47.png';
import imgImage5 from '../assets/78ed83eba43431c0c08c68662a3249b4695d24ea.png';

/**
 * 🎨 CDGS Login Page - Unified Login Experience
 * 
 * 3 Modes:
 *    1. Staff Login (Username/Password) - Default
 *    2. Customer Registration (Quick Registration)
 *    3. Customer Magic Link Login
 */

interface LoginPageProps {
  onLoginSuccess: () => void;
  onNavigateToForgotPassword?: () => void;
  onNavigate?: (path: string, ticketId?: string, sourcePath?: string, magicToken?: string) => void;
}

type LoginMode = 'staff' | 'register' | 'magic-link';

// 3D Illustration Component
function IllustrationPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
      {/* Purple Gradient Background - แก้ไขตามรหัสสีจากภาพ */}
      <div 
        className="absolute inset-0"
        style={{ 
          background: 'radial-gradient(circle, rgb(46, 11, 159) 0%, rgb(72, 21, 236) 26%, rgb(59, 16, 198) 45%, rgb(30, 5, 111) 63%, rgb(20, 0, 85) 82%, rgb(19, 0, 81) 100%)'
        }} 
      />
      
      {/* Decorative Circles - ลดขนาดจาก 90% → 72% */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[72%] max-w-[620px] h-auto aspect-[772/746]">
        <svg className="block w-full h-full" fill="none" preserveAspectRatio="xMidYMid meet" viewBox="0 0 772 746">
          <circle cx="399" cy="373" r="371.5" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="32.5" cy="406.5" r="31" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="619.5" cy="72.5" r="31" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
        </svg>
      </div>

      {/* 3D Isometric Illustration - Rotated Image - ลดขนาดจาก 85% → 68% */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[68%] max-w-[560px] aspect-square">
        <div className="w-full h-full flex items-center justify-center">
          <div className="rotate-[81.215deg] w-full h-full">
            <img 
              alt="Analytics Dashboard Illustration" 
              className="w-full h-full object-contain opacity-[0.73] pointer-events-none mix-blend-screen" 
              src={imgImage4} 
              style={{ background: 'transparent' }}
            />
          </div>
        </div>
      </div>

      {/* Main Illustration Overlay - ลดขนาดจาก 85% → 68% */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[68%] max-w-[614px] aspect-[767/695]">
        <img 
          alt="Issue Tracking Platform" 
          className="w-full h-full object-contain pointer-events-none" 
          src={imgImage5} 
          style={{ background: 'transparent' }}
        />
      </div>
    </div>
  );
}
export default function LoginPage({ onLoginSuccess, onNavigateToForgotPassword, onNavigate }: LoginPageProps) {
  const { login, loginWithMagicLink } = useAuth(); // ✅ ใช้ loginWithMagicLink แทน loginCustomer
  const [mode, setMode] = useState<LoginMode>('staff');
  
  // Staff login states
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Customer registration states
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  
  // Magic link states
  const [magicEmail, setMagicEmail] = useState('');
  const [magicLinkSent, setMagicLinkSent] = useState(false);
  const [customerName, setCustomerName] = useState(''); // เก็บชื่อลูกค้า
  const [magicLinkURL, setMagicLinkURL] = useState(''); // เก็บ Magic Link URL
  const [successMode, setSuccessMode] = useState<'register' | 'login'>('login'); // 🆕 เก็บ mode ของ success screen
  
  // Common states
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // ✅ Prepare Demo Accounts from DB (Dynamic for Runtime Updates)
  const demoAccounts = useMemo(() => {
    const users = db.users.getAll();
    return users.filter(u => u.username).map(u => ({
      username: u.username,
      password: u.password, // Use actual password from DB
      role: u.primaryRole,
      description: u.primaryRole === 'admin' ? 'ผู้ดูแลระบบสูงสุด' :
                   u.primaryRole === 'staff' ? 'เจ้าหน้าที่รับเรื่อง (Helpdesk)' :
                   u.primaryRole === 'tier1' ? 'Tier 1 Support' :
                   u.primaryRole === 'tier2' ? 'Tier 2 (SA)' :
                   u.primaryRole === 'tier3' ? 'Tier 3 (Specialist)' : 
                   u.primaryRole === 'customer' ? 'ลูกค้า (Customer)' : 'User'
    }));
  }, [mode]); // Re-calculate when mode changes (e.g. after registration)

  const demoCustomers = useMemo(() => {
    const allUsers = db.users.getAll();
    // Filter users who have 'customer' role or primaryRole is 'customer'
    return allUsers
      .filter(u => u.primaryRole === 'customer' || u.roles?.includes('customer'))
      .map(u => ({
        email: u.email,
        name: u.fullName
      }));
  }, [mode]); // Re-calculate when mode changes

  // Staff Login Handler
  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const success = await login(username, password);
      if (success) {
        onLoginSuccess();
      } else {
        setError('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
      }
    } catch (err) {
      setError('เกิดข้อผิดพลาดในการเข้าสู่ระบบ กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsLoading(false);
    }
  };

  // Customer Registration Handler
  const handleRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!regFullName.trim()) {
      setError('กรุณากรอกชื่อ-นามสกุล');
      return;
    }
    
    if (!validateEmail(regEmail)) {
      setError('รูปแบบอีเมลไม่ถูกต้อง');
      return;
    }

    setIsLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check if email already exists
      const existingCustomer = db.users.getAll().find(
        c => c.email.toLowerCase() === regEmail.toLowerCase()
      );

      if (existingCustomer) {
        setError('อีเมลนี้ถูกใช้งานแล้ว กรุณาใช้อีเมลอื่น');
        setIsLoading(false);
        return;
      }

      // Create new customer (Using DB Client to persist in memory)
      let newCustomer;
      try {
        newCustomer = db.users.add({
          fullName: regFullName,
          email: regEmail,
          role: 'customer' as any
        });
      } catch (err: any) {
        setError(err.message || 'ไม่สามารถลงทะเบียนได้ในขณะนี้');
        setIsLoading(false);
        return;
      }
      
      // ✅ [FOR DEMO] - สร้าง Magic Link แต่ไม่ส่งจริง แสดง EmailPreview แทน
      console.log('✅ ลงทะเบียนสำเร็จ! แสดงตัวอย่างอีเมล...');
      console.log('Customer:', newCustomer);
      
      // สร้าง token และ Magic Link URL
      const token = createMagicLinkToken(newCustomer.email!, newCustomer.id, newCustomer.fullName, 30);
      const magicLinkURL = generateMagicLinkURL(token.token);
      
      console.log('📧 Magic Link URL (for demo):', magicLinkURL);
      console.log('🎫 Token:', token.token);
      
      // Show success screen with EmailPreview
      setCustomerName(regFullName);
      setMagicEmail(regEmail);
      setMagicLinkURL(magicLinkURL);
      setMagicLinkSent(true);
      setMode('magic-link');
      setSuccessMode('register');
    } catch (err) {
      console.error('Registration error:', err);
      setError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsLoading(false);
    }
  };

  // Magic Link Login Handler
  const handleMagicLinkLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!validateEmail(magicEmail)) {
      setError('รูปแบบอีเมลไม่ถูกต้อง');
      return;
    }

    setIsLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      const customer = db.users.getAll().find(
        c => c.email.toLowerCase() === magicEmail.toLowerCase() && 
        (c.primaryRole === 'customer' || c.roles?.includes('customer'))
      );

      if (!customer) {
        setError('ไม่พบอีเมลนี้ในระบบ กรุณาลงทะเบียนก่อน');
        setIsLoading(false);
        return;
      }

      // Create Magic Link
      const token = createMagicLinkToken(customer.email, customer.id, customer.fullName, 30); // 🆕 ส่ง fullName
      const magicLinkURL = generateMagicLinkURL(token.token);

      sendMagicLinkEmail(customer.email, customer.fullName, magicLinkURL);

      console.log('📧 ส่ง Magic Link แล้ว!');
      console.log('Customer:', customer);
      console.log('Magic Link URL:', magicLinkURL);

      // Show success
      setCustomerName(customer.fullName); // เก็บชื่อ
      setMagicLinkURL(magicLinkURL); // เก็บ URL
      setMagicLinkSent(true);
      setSuccessMode('login'); // 🆕 กำหนด mode เป็น login
    } catch (err) {
      console.error('Login error:', err);
      setError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsLoading(false);
    }
  };

  // Reset states when switching modes
  const switchMode = (newMode: LoginMode) => {
    setMode(newMode);
    setError('');
    setMagicLinkSent(false);
    setUsername('');
    setPassword('');
    setRegFullName('');
    setRegEmail('');
    setMagicEmail('');
  };

  // Magic Link Success View
  if (magicLinkSent && mode === 'magic-link') {
    return (
      <div className="min-h-screen flex flex-col lg:flex-row bg-[#fafbff]">
        <IllustrationPanel />
        
        <div className="w-full lg:w-1/2 flex items-center justify-center p-4 lg:p-8">
          <div className="w-full max-w-[488px]">
            <div className="text-center mb-8">
              <h1 className="text-[#101828] mb-3 text-2xl lg:text-[32px]">
                Application Support Center
              </h1>
              <p className="text-[#4a5565] text-sm lg:text-base leading-tight">
                แจ้งปัญหาระบบงานได้ที่นี่ ทีมงานพร้อมช่วยดูแลทุกระบบที่คุณใช้งาน
              </p>
            </div>

            <Card className="shadow-xl border-2 border-green-200">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <CardTitle className="text-2xl text-green-900">ส่งลิงก์แล้ว!</CardTitle>
                <CardDescription className="text-base">
                  กรุณาตรวจสอบอีเมลของคุณ
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-green-50 border-green-200">
                  <Mail className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    เราได้ส่งลิงก์เข้าสู่ระบบไปยัง <strong>{magicEmail}</strong> แล้ว
                  </AlertDescription>
                </Alert>

                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm text-gray-700">
                  <p className="font-medium mb-2">ขั้นตอนต่อไป:</p>
                  <ol className="list-decimal list-inside space-y-1">
                    <li>เปิดอีเมลของคุณ</li>
                    <li>คลิกลิงก์ "เข้าสู่ระบบ"</li>
                    <li>ระบบจะพาคุณเข้าสู่หน้าแดชบอร์ดอัตโนมัติ</li>
                  </ol>
                </div>

                <div className="text-center space-y-2">
                  <p className="text-xs text-gray-500">
                    ลิงก์จะหมดอายุใน 30 นาที
                  </p>
                  <p className="text-xs text-gray-500">
                    ไม่ได้รับอีเมล?{' '}
                    <button
                      onClick={() => setMagicLinkSent(false)}
                      className="text-blue-600 hover:underline"
                    >
                      ส่งอีกครั้ง
                    </button>
                  </p>
                </div>

                {/* Email Preview Button */}
                <EmailPreview
                  customerName={customerName}
                  customerEmail={magicEmail}
                  magicLinkURL={magicLinkURL}
                  onNavigate={onNavigate}
                  mode={successMode} // 🆕 ใช้ successMode แทน hardcoded 'login'
                />

                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => switchMode('staff')}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  กลับหน้าแรก
                </Button>
              </CardContent>
            </Card>

            <div className="text-center mt-8 space-y-2">
              <p className="text-sm text-[#6a7282]">© 2025 CDGS. All rights reserved.</p>
              <p className="text-sm text-[#6a7282]">Application Support Center</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#fafbff]">
      <IllustrationPanel />

      <div className="w-full lg:w-1/2 flex items-center justify-center p-4 lg:p-8">
        <div className="w-full max-w-[488px]">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-[#101828] mb-3 text-2xl lg:text-[32px]">
              Application Support Center
            </h1>
            <p className="text-[#4a5565] text-sm lg:text-base leading-tight">
              แจ้งปัญหาระบบงานได้ที่นี่ ทีมงานพร้อมช่วยดูแลทุกระบบที่คุณใช้งาน
            </p>
          </div>

          {/* Login Card */}
          <Card className="shadow-xl border-gray-200 rounded-[16px]">
            <CardHeader className="space-y-1 px-6 pt-8 pb-3">
              <CardTitle className="text-lg">
                {mode === 'staff' ? 'เข้าสู่ระบบ' : mode === 'register' ? 'ลงทะเบียนใหม่' : 'เข้าสู่ระบบลูกค้าเดิม'}
              </CardTitle>
              <CardDescription className="text-sm text-neutral-500">
                {mode === 'staff' 
                  ? 'กรุณาป้อนชื่อผู้ใช้และรหัสผ่านของคุณ'
                  : mode === 'register'
                  ? 'กรอกข้อมูลเพื่อลงทะเบียนและรับลิงก์เข้าสู่ระบบทางอีเมล'
                  : 'กรอกอีเมลของคุณเพื่อรับลิงก์เข้าสู่ระบบ'}
              </CardDescription>
            </CardHeader>

            <CardContent className="px-6 pb-8">
              {/* Staff Login Form */}
              {mode === 'staff' && (
                <form onSubmit={handleStaffLogin} className="space-y-5">
                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="username" className="text-sm text-neutral-950">
                      ชื่อผู้ใช้
                    </Label>
                    <Input
                      id="username"
                      type="text"
                      placeholder="กรอกชื่อผู้ใช้"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required
                      autoFocus
                      className="h-10 bg-gray-50 border-gray-300 rounded-lg"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm text-neutral-950">
                      รหัสผ่าน
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="กรอกรหัสผ่าน"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="h-10 bg-gray-50 border-gray-300 rounded-lg pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="text-right">
                    <button
                      type="button"
                      className="text-sm text-blue-600 hover:text-blue-700 hover:underline"
                      onClick={onNavigateToForgotPassword}
                    >
                      ลืมรหัสผ่าน?
                    </button>
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-11 bg-black hover:bg-gray-800 text-white rounded-lg"
                    disabled={isLoading}
                  >
                    {isLoading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ'}
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full h-11 border-2 border-gray-300 hover:bg-gray-50 rounded-lg"
                    onClick={() => switchMode('register')}
                  >
                    ลงทะเบียนใหม่
                  </Button>

                  <div className="text-center">
                    <button
                      type="button"
                      className="text-sm text-red-600 hover:text-red-700 hover:underline font-medium"
                      onClick={() => switchMode('magic-link')}
                    >
                      เข้าสู่ระบบด้วยวิธีส่งลิงก์ทางอีเมล
                    </button>
                  </div>

                  {/* Demo Accounts Button */}
                  <div className="pt-4 border-t border-gray-200">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          className="w-full h-10 bg-[rgba(229,229,229,0.3)] border-neutral-200 hover:bg-[rgba(229,229,229,0.5)] text-neutral-950 rounded-lg text-sm" 
                          type="button"
                        >
                          <HelpCircle className="w-4 h-4 mr-2" />
                          ข้อมูลบัญชีทดสอบ
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>บัญชีทดสอบ (Demo Accounts)</DialogTitle>
                          <DialogDescription>
                            ใช้บัญชีเหล่านี้เพื่อทดสอบระบบในบทบาทต่างๆ
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-3 mt-4">
                          {demoAccounts.map((mockUser) => (
                            <div
                              key={mockUser.username}
                              className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                              onClick={() => {
                                setUsername(mockUser.username || '');
                                setPassword(mockUser.password);
                              }}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <div>
                                  <div className="flex items-center gap-2 mb-1">
                                    <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                                      {mockUser.username}
                                    </span>
                                    <span
                                      className={`px-2 py-0.5 rounded text-xs ${
                                        mockUser.role === 'admin'
                                          ? 'bg-purple-100 text-purple-700'
                                          : mockUser.role === 'staff'
                                          ? 'bg-orange-100 text-orange-700'
                                          : mockUser.role === 'customer'
                                          ? 'bg-green-100 text-green-700'
                                          : mockUser.role === 'tier1'
                                          ? 'bg-blue-100 text-blue-700'
                                          : mockUser.role === 'tier2'
                                          ? 'bg-indigo-100 text-indigo-700'
                                          : mockUser.role === 'tier3'
                                          ? 'bg-pink-100 text-pink-700'
                                          : 'bg-gray-100 text-gray-700'
                                      }`}
                                    >
                                      {mockUser.role}
                                    </span>
                                  </div>
                                  <p className="text-sm text-gray-600">
                                    {mockUser.description}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-4 text-sm">
                                <div>
                                  <span className="text-gray-500">Password:</span>{' '}
                                  <span className="font-mono text-gray-900">
                                    {mockUser.password}
                                  </span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                          <p className="text-sm text-amber-800">
                            <strong>หมายเหตุ:</strong> นี่เป็นระบบทดสอบเท่านั้น 
                            ในสภาพแวดล้อมจริงจะใช้ระบบยืนยันตัวตนที่ปลอดภัยกว่า
                          </p>
                        </div>
                        <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                          <p className="text-sm text-blue-800">
                            <strong>💡 เคล็ดลับ:</strong> คลิกที่บัญชีใดก็ได้เพื่อกรอกข้อมูลอัตโนมัติ
                          </p>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </form>
              )}

              {/* Customer Registration Form */}
              {mode === 'register' && (
                <form onSubmit={handleRegistration} className="space-y-5">
                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="regFullName" className="text-sm text-neutral-950">
                      ชื่อ-นามสกุล <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="regFullName"
                      type="text"
                      placeholder="กรอกชื่อ-นามสกุล"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      required
                      autoFocus
                      className="h-10 bg-gray-50 border-gray-300 rounded-lg"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="regEmail" className="text-sm text-neutral-950">
                      อีเมล <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="regEmail"
                      type="email"
                      placeholder="example@company.com"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      required
                      className="h-10 bg-gray-50 border-gray-300 rounded-lg"
                    />
                  </div>

                  <Alert className="bg-blue-50 border-blue-200">
                    <Mail className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-800 text-sm">
                      เราจะส่งลิงก์พิเศษไปยังอีเมลของคุณ คลิกลิงก์เพื่อเข้าสู่ระบบทันที
                    </AlertDescription>
                  </Alert>

                  <Button
                    type="submit"
                    className="w-full h-11 bg-black hover:bg-gray-800 text-white rounded-lg"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        กำลังลงทะเบียน...
                      </>
                    ) : (
                      'ลงทะเบียนและรับลิงก์'
                    )}
                  </Button>

                  <div className="text-center">
                    <button
                      type="button"
                      className="text-sm text-gray-600 hover:text-gray-900"
                      onClick={() => switchMode('staff')}
                    >
                      กลับหน้าเข้าสู่ระบบ
                    </button>
                  </div>
                </form>
              )}

              {/* Magic Link Login Form */}
              {mode === 'magic-link' && (
                <form onSubmit={handleMagicLinkLogin} className="space-y-5">
                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="magicEmail" className="text-sm text-neutral-950">
                      อีเมล <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="magicEmail"
                      type="email"
                      placeholder="example@company.com"
                      value={magicEmail}
                      onChange={(e) => setMagicEmail(e.target.value)}
                      required
                      autoFocus
                      className="h-10 bg-gray-50 border-gray-300 rounded-lg"
                    />
                  </div>

                  <Alert className="bg-amber-50 border-amber-200">
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                    <AlertDescription className="text-amber-800 text-sm">
                      สำหรับลูกค้าที่มีบัญชีแล้วเท่านั้น
                    </AlertDescription>
                  </Alert>

                  <Button
                    type="submit"
                    className="w-full h-11 bg-black hover:bg-gray-800 text-white rounded-lg"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        กำลังส่งลิงก์...
                      </>
                    ) : (
                      'ส่งลิงก์เข้าสู่ระบบ'
                    )}
                  </Button>

                  <div className="text-center">
                    <button
                      type="button"
                      className="text-sm text-gray-600 hover:text-gray-900"
                      onClick={() => switchMode('staff')}
                    >
                      กลับหน้าเข้าสู่ระบบ
                    </button>
                  </div>
                </form>
              )}
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="text-center mt-8 space-y-4">
            <p className="text-sm text-[#6a7282]">© 2025 CDGS. All rights reserved.</p>
            <p className="text-sm text-[#6a7282]">Application Support Center</p>
          </div>
        </div>
      </div>
    </div>
  );
}