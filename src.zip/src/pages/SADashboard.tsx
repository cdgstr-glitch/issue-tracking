import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { StatsCard } from '../components/StatsCard';
import { AlertTriangle, Clock, CheckCircle, Code } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { TicketCard } from '../components/TicketCard';
import { Button } from '../components/ui/button';
import { useAuth } from '../contexts/AuthContext';
import { useEffect, useMemo } from 'react';

interface SADashboardProps {
  onNavigate: (path: string, ticketId?: string) => void;
  searchQuery?: string;
}
export default function SADashboard({ onNavigate, searchQuery = '' }: SADashboardProps) {
  const { user } = useAuth();
  
  // ✅ Fetch tickets from DB
  const tickets = db.tickets.getAll();
  
  // ✅ Auto-redirect to tickets page when searching from dashboard
  useEffect(() => {
    if (searchQuery && searchQuery.trim() !== '') {
      console.log('🔍 SA Dashboard search detected, redirecting to tickets page with query:', searchQuery);
      onNavigate('/admin/tickets');
    }
  }, [searchQuery, onNavigate]);
  
  // 🔧 กรองเฉพาะเคสที่มอบหมายให้ user ที่ login
  const tier2Tickets = tickets.filter(t => 
    t.stage === 'tier2' && t.assignedTo === user?.id
  );
  
  // ✅ Filter tier2 tickets by search query
  const filteredTier2Tickets = searchQuery
    ? tier2Tickets.filter(ticket =>
        ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ticket.id.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : tier2Tickets;
  
  const allTechnicalTickets = tickets.filter(t => 
    t.category === 'Network & Connectivity' || 
    t.category === 'Software & Applications' ||
    t.category === 'Hardware & Equipment'
  );

  // ✅ Dynamic Stats Calculation
  const resolvedToday = tickets.filter(t => {
    if ((t.status !== 'resolved' && t.status !== 'closed') || !t.resolvedAt) return false;
    const resolvedDate = new Date(t.resolvedAt);
    const today = new Date();
    return resolvedDate.getDate() === today.getDate() &&
           resolvedDate.getMonth() === today.getMonth() &&
           resolvedDate.getFullYear() === today.getFullYear();
  }).length;

  const avgResolutionTime = (() => {
    const resolvedTickets = tickets.filter(t => (t.status === 'resolved' || t.status === 'closed') && t.resolvedAt);
    if (resolvedTickets.length === 0) return "N/A";
    
    const totalDays = resolvedTickets.reduce((acc, t) => {
      const diff = new Date(t.resolvedAt!).getTime() - new Date(t.createdAt).getTime();
      return acc + diff;
    }, 0) / (1000 * 60 * 60 * 24);
    
    return `${(totalDays / resolvedTickets.length).toFixed(1)} วัน`;
  })();

  // ✅ Dynamic Category Stats
  const categoryStats = useMemo(() => {
    const categories = tickets.reduce((acc, t) => {
      const cat = t.category || 'Uncategorized';
      acc[cat] = (acc[cat] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(categories)
      .map(([category, count]) => ({
        category,
        count,
        percentage: Math.round((count / tickets.length) * 100)
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 4); // Top 4
  }, [tickets]);

  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      {/* Header */}
      <div className="rounded-lg bg-gradient-to-r from-orange-500 to-orange-600 p-6 text-white">
        <h1 className="mb-2 text-white">🔧 Tier 2 - แดชบอร์ด ทีมสนับสนุนด้านเทคนิค</h1>
        <p className="text-orange-50">ตรวจสอบและแก้ไขปัญหาทางเทคนิคขั้นสูง</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="มอบหมายให้ฉัน"
          value={tier2Tickets.length}
          icon={AlertTriangle}
          color="orange"
        />
        <StatsCard
          title="กำลังดำเนินการ"
          value={tier2Tickets.length}
          icon={Clock}
          color="blue"
        />
        <StatsCard
          title="แก้ไขวันนี้"
          value={resolvedToday}
          icon={CheckCircle}
          color="green"
        />
        <StatsCard
          title="เวลาเฉลี่ยในการแก้ไข"
          value={avgResolutionTime}
          icon={Code}
          color="gray"
        />
      </div>

      {/* Active Tickets - Tier 2 Specific */}
      <Card className="border-orange-200">
        <CardHeader className="bg-orange-50">
          <div className="flex items-center justify-between">
            <CardTitle className="text-orange-900">งานด้านเทคนิคที่มอบหมาย (Tier 2)</CardTitle>
            <Button variant="outline" onClick={() => onNavigate('/admin/tickets')}>
              ดูทั้งหมด
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {filteredTier2Tickets.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredTier2Tickets.map((ticket) => (
                <TicketCard
                  key={ticket.id}
                  ticket={ticket}
                  onClick={() => onNavigate('/admin/ticket', ticket.id)}
                />
              ))}
            </div>
          ) : (
            <div className="py-12 text-center text-gray-500">
              <Code className="mx-auto mb-3 h-12 w-12 text-gray-400" />
              <p>ไม่มีงาน Tier 2 ที่มอบหมายในขณะนี้</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* All Technical Tickets */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>งานด้านเทคนิคทั้งหมด</CardTitle>
            <span className="text-sm text-gray-500">{allTechnicalTickets.length} งาน</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {allTechnicalTickets.slice(0, 6).map((ticket) => (
              <TicketCard
                key={ticket.id}
                ticket={ticket}
                onClick={() => onNavigate('/admin/ticket', ticket.id)}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Problem Categories */}
      <Card>
        <CardHeader>
          <CardTitle>ปัญหาที่พบบ่อย (ทั้งหมด)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {categoryStats.map((item) => (
              <div key={item.category}>
                <div className="mb-1 flex justify-between text-sm">
                  <span>{item.category}</span>
                  <span className="text-orange-600">{item.count} งาน</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-gray-200">
                  <div
                    className="h-full rounded-full bg-orange-600"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Debug Tools */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-l-4 border-l-orange-500">
          <CardHeader>
            <CardTitle>🛠️ เครื่องมือด่วน</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start hover:bg-orange-50">
              <Code className="mr-2 h-4 w-4" />
              เข้าถึง System Logs
            </Button>
            <Button variant="outline" className="w-full justify-start hover:bg-orange-50">
              <AlertTriangle className="mr-2 h-4 w-4" />
              ดู Error Reports
            </Button>
            <Button variant="outline" className="w-full justify-start hover:bg-orange-50">
              <CheckCircle className="mr-2 h-4 w-4" />
              Knowledge Base
            </Button>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardHeader>
            <CardTitle>📋 แนวทางการส่งต่อ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-gray-700">
              <div className="rounded-lg bg-red-50 p-3 border border-red-200">
                <p className="mb-2 font-medium text-red-900">
                  ส่งต่อไปยัง Tier 3 เมื่อ:
                </p>
                <ul className="ml-4 space-y-1 text-xs text-red-800">
                  <li>• ปัญหาระดับ Infrastructure</li>
                  <li>• การละเมิดความปลอดภัย (Security breaches)</li>
                  <li>• ต้องการการสนับสนุนจาก Cloud Provider</li>
                  <li>• ไม่สามารถแก้ไขได้ภายใน 2 วัน</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}