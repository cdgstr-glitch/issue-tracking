import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ArrowLeft, Mail } from 'lucide-react';
import { db } from '../lib/mockDb/client';
import type { HydratedTicket } from '../lib/mockDb/client';
import { getAssigneeDisplayName } from '../lib/ticketUtils';
import { StatusBadge } from '../components/StatusBadge';
import { PriorityBadge } from '../components/PriorityBadge';
import { Badge } from '../components/ui/badge';
import { TicketTimeline } from '../components/TicketTimeline';
import { formatDate } from '../lib/utils';
import { extractHashtags, removeHashtags } from '../lib/hashtagUtils';
import { EmailPreviewModal } from '../components/EmailPreviewModal';
import { useAuth } from '../contexts/AuthContext';
import { AttachmentGallery } from '../components/AttachmentGallery'; 
import { CommentSection } from '../components/comments/CommentSection'; 
import { SatisfactionSurvey } from '../components/SatisfactionSurvey';

interface TrackTicketDetailPageProps {
  ticketId: string;
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}
export default function TrackTicketDetailPage({ ticketId, onNavigate, onBackToMenu }: TrackTicketDetailPageProps) {
  const { user, isAuthenticated } = useAuth();
  
  // Fetch from DB
  const [currentTicket, setCurrentTicket] = useState<HydratedTicket | null>(() => db.tickets.getHydratedById(ticketId));
  
  const [emailPreviewOpen, setEmailPreviewOpen] = useState(false);
  const [emailPreviewType, setEmailPreviewType] = useState<'customer' | 'staff'>('customer');

  // Sync currentTicket with ticket when ticketId changes
  useEffect(() => {
    const updatedTicket = db.tickets.getHydratedById(ticketId);
    if (updatedTicket) {
       setCurrentTicket(updatedTicket);
    }
  }, [ticketId]);

  if (!currentTicket) {
      return <div>Ticket not found</div>
  }

  // ดึงข้อมูลโครงการและผลิตภัณฑ์
  const project = currentTicket.projectId ? db.projects.getById(currentTicket.projectId) : null;
  
  // ดึง organization 
  const organization = project 
    ? db.organizations.getById(project.organizationId)
    : null;
    
  // Use db.products.getByCode instead of ALL_PRODUCTS.find
  const product = currentTicket.productValue ? db.products.getByCode(currentTicket.productValue) : null;

  // Redirect to home when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      console.log('User logged out, navigating to /');
      onNavigate('/');
    }
  }, [isAuthenticated, onNavigate]);

  const handleOpenEmailPreview = (type: 'customer' | 'staff') => {
    setEmailPreviewType(type);
    setEmailPreviewOpen(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        onClick={() => onNavigate('/track')}
        className="gap-2 mb-4"
      >
        <ArrowLeft className="h-4 w-4" />
        กลับรายการเคส
      </Button>

      {/* Page Header */}
      <div className="mb-6">
        <h1 className="mb-2">รายละเอียดเคสลูกค้า</h1>
        <p className="text-blue-600">{currentTicket.ticketNumber}</p>
      </div>

      {/* Ticket Info Card */}
      <Card className="mb-6">
        <CardHeader className="p-4 pb-0">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex-1">
              <div className="flex items-baseline gap-2 flex-wrap">
                <span className="text-gray-600">หัวเรื่อง</span>
                <CardTitle className="m-0">{removeHashtags(currentTicket.title)}</CardTitle>
                {/* Display hashtags as badges */}
                {extractHashtags(currentTicket.title).length > 0 && (
                  <div className="flex gap-1.5 flex-wrap">
                    {extractHashtags(currentTicket.title).map((hashtag, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700"
                      >
                        {hashtag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <p className="mt-2 text-sm text-gray-600">
                สร้างเมื่อ {formatDate(currentTicket.createdAt)}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <StatusBadge status={currentTicket.status} userRole="customer" />
              <PriorityBadge priority={currentTicket.priority} userRole="customer" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4 space-y-6">
          <div>
            <h3 className="mb-2">รายละเอียด</h3>
            <div 
              className="text-gray-700 prose prose-sm max-w-none"
              dangerouslySetInnerHTML={{ __html: currentTicket.description }}
            />
          </div>

          <div className="grid gap-4 border-t pt-6 md:grid-cols-2">
            {/* แสดงชื่อลูกค้า */}
            {currentTicket.customerName && (
              <div>
                <p className="text-sm text-gray-600">ชื่อลูกค้า</p>
                <p>{currentTicket.customerName}</p>
              </div>
            )}
            {/* แสดงชื่อเจ้าหน้าที่ที่แจ้งแทนลูกค้า */}
            {currentTicket.createdByType === 'staff_on_behalf' && (
              <div>
                <p className="text-sm text-gray-600">แจ้งโดยเจ้าหน้าที่</p>
                <p>{currentTicket.createdByStaffName || 'เจ้าหน้าที่'}</p>
              </div>
            )}
            
            {/* แสดงโครงการ */}
            {project && organization && (
              <div className="md:col-span-2">
                <p className="text-sm text-gray-600 mb-1">โครงการ/Project</p>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {organization.shortName}
                  </Badge>
                  <span className="text-sm text-gray-500">{project.code}</span>
                </div>
                <p className="mt-1">{project.name}</p>
              </div>
            )}
            
            {/* แสดงผลิตภัณฑ์ที่ใช้งาน */}
            {product && (
              <div className="md:col-span-2">
                <p className="text-sm text-gray-600 mb-1">ผลิตภัณฑ์ที่ใช้งาน</p>
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="font-medium text-blue-900">{product.name || product.code}</p>
                  <p className="text-xs text-blue-700 mt-0.5">{product.description}</p>
                </div>
              </div>
            )}
            
            <div>
              <p className="text-sm text-gray-600">หมวดหมู่</p>
              <p>{currentTicket.category}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">ประเภท</p>
              <p className="capitalize">{currentTicket.type.replace('_', ' ')}</p>
            </div>
            {currentTicket.assignedTo && (
              <div>
                <p className="text-sm text-gray-600">มอบหมายให้</p>
                <p>{getAssigneeDisplayName(currentTicket)}</p>
              </div>
            )}
            <div>
              <p className="text-sm text-gray-600">กำหนดเสร็จ</p>
              <p>{formatDate(currentTicket.dueDate)}</p>
            </div>
          </div>

          {/* เพิ่มส่วนแสดงไฟล์แนบ */}
          {currentTicket.attachments && currentTicket.attachments.length > 0 && (
            <div className="border-t pt-6">
              <AttachmentGallery attachments={currentTicket.attachments} showDownload={true} />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card className="mb-6">
        <CardHeader className="p-4 pb-0">
          <CardTitle>ไทม์ไลน์</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <TicketTimeline events={db.timeline.getByTicketId(currentTicket.id)} userRole="customer" ticket={currentTicket} />
        </CardContent>
      </Card>

      {/* Comments & Updates */}
      <CommentSection
        comments={currentTicket.comments}
        onAddComment={(commentText, isInternal, attachments) => {
          // 1. Prepare Data
          const commentId = `comment-${Date.now()}`;
          const eventId = `evt-${Date.now()}`;
          const timestamp = new Date();

          const newComment = {
            id: commentId,
            ticketId: currentTicket.id,
            author: user?.fullName || 'ลูกค้า',
            authorRole: 'customer',
            content: commentText,
            isInternal: false, // ลูกค้าส่งเป็น public เสมอ
            createdAt: timestamp,
            attachments: attachments || [] // เพิ่มไฟล์แนบ
          };
          
          // 2. Save to DB (Persistence)
          db.comments.add({
            ...newComment,
            authorId: user?.id
          });

          // 3. Add Timeline Event to DB
          const newEvent = {
            id: eventId,
            ticketId: currentTicket.id,
            timestamp: timestamp,
            type: 'comment' as const,
            description: 'ลูกค้าตอบกลับ',
            userId: user?.id,
            user: user?.fullName || 'ลูกค้า',
            userName: user?.fullName || 'ลูกค้า'
          };
          // @ts-ignore
          db.timeline.add(newEvent);

          // 4. Update Local State (Optimistic UI)
          setCurrentTicket({
            ...currentTicket,
            comments: [...currentTicket.comments, newComment],
            updatedAt: timestamp
          });
        }}
        formatDate={formatDate}
        currentUserName={user?.fullName || 'ลูกค้า'}
        currentUserRole="customer"
        showInternalToggle={false} // ซ่อน toggle สำหรับ Customer
        title="ความคิดเห็นและอัปเดต"
        placeholder="พิมพ์ข้อความของคุณที่นี่... (รองรับการแนบไฟล์)"
        submitButtonText="ส่งการตอบกลับ"
        readOnly={currentTicket.status === 'resolved' || currentTicket.status === 'closed'}
      />

      {/* Satisfaction Survey - Show when Resolved or Closed */}
      {(currentTicket.status === 'resolved' || currentTicket.status === 'closed') && (
        <SatisfactionSurvey 
          ticketId={currentTicket.id}
          status={currentTicket.status}
        />
      )}

      {/* Email Preview Card */}
      <Card className="mb-6 mt-6">
        <CardHeader className="p-4 pb-0">
          <CardTitle>ตัวอย่างการแจ้งเตือนทางอีเมล</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button 
              variant="outline" 
              className="flex-1 justify-start gap-2"
              onClick={() => handleOpenEmailPreview('customer')}
            >
              <Mail className="h-4 w-4" />
              ตัวอย่างอีเมลแจ้งตอบกลับส่งถึงลูกค้า
            </Button>
            <Button 
              variant="outline" 
              className="flex-1 justify-start gap-2"
              onClick={() => handleOpenEmailPreview('staff')}
            >
              <Mail className="h-4 w-4" />
              ตัวอย่างอีเมลแจ้งตอบกลับส่งไปยังเจ้าหน้าที่ที่รับเคส
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Closed Ticket Notice */}
      {(currentTicket.status === 'closed' || currentTicket.status === 'resolved') && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4 text-center">
            <p className="text-green-800">
              ✓ เคสนี้ได้รับการแก้ไขแล้ว หากต้องการความช่วยเหลือเพิ่มเติม กรุณาสร้างเคสใหม่
            </p>
            <Button 
              className="mt-4"
              onClick={() => onNavigate('/create')}
            >
              สร้างเคสใหม่
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Email Preview Modal */}
      <EmailPreviewModal
        isOpen={emailPreviewOpen}
        onClose={() => setEmailPreviewOpen(false)}
        type={emailPreviewType}
        ticket={currentTicket}
      />
    </div>
  );
}