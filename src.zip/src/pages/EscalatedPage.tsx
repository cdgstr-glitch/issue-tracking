import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { useAuth } from '../contexts/AuthContext';
import { ArrowUpRight, Info } from 'lucide-react';
import { useState } from 'react';
import { EscalatedSection } from '../components/EscalatedSection';

interface EscalatedPageProps {
  onNavigate: (path: string, ticketId?: string, sourcePath?: string) => void;
}

type ViewMode = 'cards' | 'table';
export default function EscalatedPage({ onNavigate }: EscalatedPageProps) {
  const { user, activeRole } = useAuth();
  const [viewMode, setViewMode] = useState<ViewMode>('table'); // ✅ เปลี่ยนจาก 'cards' เป็น 'table'

  // ✅ Fetch tickets from DB
  const tickets = db.tickets.getAll();

  // 🔧 กรองเคสที่ user ส่งต่อ (จากปุ่ม "ส่งต่อ" เท่านั้น)
  // - แสดงทุกเคสที่มีใน escalationChain ที่ user เป็น escalatedBy
  // - ไม่จำกัดทิศทาง เพราะในความเป็นจริง:
  //   * Tier1 อาจส่งต่อไป Tier3 เพื่อขอคำแนะนำ
  //   * Tier3 ส่งต่อกลับมา Tier1 เพื่อให้แก้ไข
  //   * ทุก Tier สามารถส่งต่อให้เพื่อนร่วมทีม (lateral transfer)
  
  const escalatedTickets = tickets.filter(ticket => {
    // 1. ตรวจสอบ escalationChain ว่ามี user นี้ส่งต่อหรือไม่
    const ticketEscalations = db.escalations.getByTicketId(ticket.id);
    if (ticketEscalations.length > 0) {
      const myEscalations = ticketEscalations.filter(
        chain => chain.escalatedBy === user?.id
      );
      if (myEscalations.length > 0) return true;
    }

    // 2. Fallback: ตรวจสอบจาก Timeline (เพราะ Mock Data บางส่วนอาจไม่มี escalationChain)
    const ticketTimeline = db.timeline.getByTicketId(ticket.id);
    if (ticketTimeline.length > 0) {
      const myEscalationEvents = ticketTimeline.filter(
        event => event.type === 'escalation' && event.userId === user?.id
      );
      if (myEscalationEvents.length > 0) return true;
    }

    // 3. Fallback: ตรวจสอบจาก assignedBy (เฉพาะกรณีส่งต่อไประดับอื่น)
    // เช็คว่า status ไม่ใช่ 'new' หรือ 'tier1' (กรณี Tier 1 เป็นคนส่ง)
    // และ assignedBy ต้องตรงกับ user.id
    if (ticket.assignedBy === user?.id) {
       // กรองเฉพาะเคสที่ stage เปลี่ยนไปจากเดิม หรือเป็น tier2/tier3
       return ['tier2', 'tier3'].includes(ticket.stage);
    }

    return false;
  });

  // แยกตาม stage (tier) และ status
  const closedEscalated = escalatedTickets.filter(t => 
    t.status === 'resolved' || t.status === 'closed'
  );
  const activeEscalated = escalatedTickets.filter(t => 
    !['resolved', 'closed'].includes(t.status)
  );
  const tier1Escalated = activeEscalated.filter(t => t.stage === 'tier1');
  const tier2Escalated = activeEscalated.filter(t => t.stage === 'tier2');
  const tier3Escalated = activeEscalated.filter(t => t.stage === 'tier3');

  // สร้างข้อมูลสรุป
  const totalEscalated = escalatedTickets.length;
  const activeCount = activeEscalated.length;

  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      {/* Header */}
      <div className="rounded-lg bg-gradient-to-r from-purple-500 to-purple-600 p-6 text-white">
        <div className="flex items-center gap-3">
          <ArrowUpRight className="h-8 w-8" />
          <div>
            <h1 className="mb-1 text-white">เคสที่ฉันส่งต่อ</h1>
            <p className="text-purple-50">
              ติดตามเคสที่คุณส่งต่อให้ทีมอื่น
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">ส่งต่อทั้งหมด</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{totalEscalated}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">กำลังดำเนินการ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-orange-600">{activeCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">แก้ไขแล้ว</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-600">{closedEscalated.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Info Alert */}
      {activeRole === 'tier1' && (
        <div className="rounded-lg bg-blue-50 border border-blue-200 p-4 flex gap-3">
          <Info className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-900">
            <p className="mb-1">
              <strong>การแจ้งเตือนอัตโนมัติ:</strong> คุณจะได้รับการแจ้งเตือนเมื่อเคสที่คุณส่งต่อมีการเปลี่ยนแปลงสถานะ
            </p>
            <p className="text-xs text-blue-700">
              หากเคสถูกส่งต่อไปยัง Tier 3 คุณยังคงได้ับการแจ้งเตือนต่อไป
            </p>
          </div>
        </div>
      )}

      {activeRole === 'tier2' && (
        <div className="rounded-lg bg-orange-50 border border-orange-200 p-4 flex gap-3">
          <Info className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-orange-900">
            <p className="mb-1">
              <strong>การแจ้งเตือนอัตโนมัติ:</strong> คุณจะได้รับการแจ้งเตือนเมื่อเคสที่คุณส่งต่อไปยัง Tier 3 มีการเปลี่ยนแปลง
            </p>
            <p className="text-xs text-orange-700">
              Tier 1 ที่ส่งเคสนี้มาให้คุณก็จะได้รับการแจ้งเตือนด้วย
            </p>
          </div>
        </div>
      )}

      {/* View Mode Toggle */}
      <div className="flex justify-end">
        <div className="inline-flex rounded-lg border border-gray-300 bg-white p-1">
          <button
            onClick={() => setViewMode('table')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              viewMode === 'table'
                ? 'bg-gray-900 text-white'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Table
          </button>
          <button
            onClick={() => setViewMode('cards')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              viewMode === 'cards'
                ? 'bg-gray-900 text-white'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Cards
          </button>
        </div>
      </div>

      {/* Tier 1 Escalated Cases */}
      {tier1Escalated.length > 0 && (
        <EscalatedSection
          title="เคสส่งต่อไปยัง Tier 1"
          tickets={tier1Escalated}
          tierColor="blue"
          viewMode={viewMode}
          onNavigate={onNavigate}
          sourcePath="/admin/escalated"
          showPaginationAlways={true}
        />
      )}

      {/* Tier 2 Escalated Cases */}
      {tier2Escalated.length > 0 && (
        <EscalatedSection
          title="เคสส่งต่อไปยัง Tier 2"
          tickets={tier2Escalated}
          tierColor="orange"
          viewMode={viewMode}
          onNavigate={onNavigate}
          sourcePath="/admin/escalated"
          showPaginationAlways={true}
        />
      )}

      {/* Tier 3 Escalated Cases */}
      {tier3Escalated.length > 0 && (
        <EscalatedSection
          title="เคสส่งต่อไปยัง Tier 3"
          tickets={tier3Escalated}
          tierColor="red"
          viewMode={viewMode}
          onNavigate={onNavigate}
          sourcePath="/admin/escalated"
          showPaginationAlways={true}
        />
      )}

      {/* Resolved/Closed Cases */}
      {closedEscalated.length > 0 && (
        <EscalatedSection
          title="เคสที่แก้ไขแล้ว"
          tickets={closedEscalated}
          tierColor="green"
          viewMode={viewMode}
          onNavigate={onNavigate}
          sourcePath="/admin/escalated"
          showPaginationAlways={true}
        />
      )}

      {/* Empty State */}
      {escalatedTickets.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <ArrowUpRight className="mx-auto mb-3 h-12 w-12 text-gray-400" />
            <p className="text-gray-600 mb-2">ยังไม่มีเคสที่ส่งต่อ</p>
            <p className="text-sm text-gray-500">
              เคสที่คุณส่งต่อให้ทีมอื่นจะแสดงที่นี่
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}