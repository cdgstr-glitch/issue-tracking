import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ArrowLeft, Search, MessageSquare, AlertTriangle, Send, CheckCircle, ArrowUp, FileText, ArrowRight, Clock, Users, ArrowUpRight, CheckCircle2, CirclePause } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Header } from '../components/layout/Header';
import { Badge } from '../components/ui/badge';
import { TierEscalationDiagram } from '../components/TierEscalationDiagram';

interface Tier1JourneyPageProps {
  onNavigate: (path: string) => void;
  onBackToMenu?: () => void;
}

const Tier1JourneyPage: React.FC<Tier1JourneyPageProps> = ({ onNavigate, onBackToMenu }) => {
  const { user } = useAuth();

  const steps = [
    {
      number: 1,
      icon: Search,
      title: 'ค้นหาเคส',
      description: 'ค้นหาเคสที่ต้องการจัดการ',
      details: [
        'เข้าสู่ระบบ Admin Dashboard',
        'ใช้ฟังก์ชันค้นหาเคส',
        'เลือกเคสที่ต้องการจัดการ'
      ],
      color: 'blue',
      sla: 'SLA: 2-4 ชั่วโมง'
    },
    {
      number: 2,
      icon: MessageSquare,
      title: 'สื่อสารกับลูกค้า',
      description: 'สื่อสารและสอบถามรายละเอียดปัญหา',
      details: [
        'สื่อสารกับลูกค้าผ่านช่องทางที่กำหนด',
        'สอบถามรายละเอียดปัญหาที่ลูกค้าพบ',
        'บันทึกรายละเอียดปัญหา'
      ],
      color: 'purple'
    },
    {
      number: 3,
      icon: AlertTriangle,
      title: 'วิเคราะห์ปัญหา',
      description: 'วิเคราะห์ปัญหาและกำหนดความสำคัญ',
      details: [
        'วิเคราะห์ปัญหาที่ลูกค้าพบ',
        'ระบุประเภทปัญหา (Technical, Access, Bug, Feature)',
        'กำหนดระดับความสำคัญ (Low, Medium, High, Critical)',
        'เปลี่ยนสถานะเป็น "กำลังดำเนินการ (Tier 1)"'
      ],
      color: 'green'
    },
    {
      number: 4,
      icon: Send,
      title: 'ส่งต่อไป Tier 2 (ถ้าจำเป็น)',
      description: 'ส่งเคสที่ซับซ้อนไปยังทีมทางเทคนิค',
      details: [
        'ประเมินว่าปัญหาซับซ้อนเกินกว่าขอบเขต Tier 1',
        'เลือก "ส่งต่อเคส" และระบุเหตุผล',
        'เลือกส่งไปยัง Tier 2 (SA Team)',
        'แนบข้อมูลการตรวจสอบเบื้องต้น',
        'แจ้งลูกค้าว่าเคสถูกส่งต่อไปยังทีมผู้เชี่ยวชาญ'
      ],
      color: 'orange'
    },
    {
      number: 5,
      icon: CheckCircle,
      title: 'ติดตามและปิดเคส',
      description: 'ติดตามผลและยืนยันการแก้ไข',
      details: [
        'ติดตามสถานะเคสที่ส่งต่อไป Tier 2/3',
        'ตรวจสอบความคิดเห็นจากลูกค้า',
        'ยืนยันว่าปัญหาได้รับการแก้ไขแล้ว',
        'เปลี่ยนสถานะเป็น "ปิด"',
        'ขอบคุณลูกค้าและบันทึกประสบการณ์'
      ],
      color: 'indigo'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        text: 'text-blue-600',
        iconBg: 'bg-blue-600',
        gradient: 'from-blue-500 to-blue-600'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        text: 'text-purple-600',
        iconBg: 'bg-purple-600',
        gradient: 'from-purple-500 to-purple-600'
      },
      green: {
        bg: 'bg-green-50',
        border: 'border-green-200',
        text: 'text-green-600',
        iconBg: 'bg-green-600',
        gradient: 'from-green-500 to-green-600'
      },
      orange: {
        bg: 'bg-orange-50',
        border: 'border-orange-200',
        text: 'text-orange-600',
        iconBg: 'bg-orange-600',
        gradient: 'from-orange-500 to-orange-600'
      },
      indigo: {
        bg: 'bg-indigo-50',
        border: 'border-indigo-200',
        text: 'text-indigo-600',
        iconBg: 'bg-indigo-600',
        gradient: 'from-indigo-500 to-indigo-600'
      }
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ✅ ใช้ Header component */}
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'tier1'
        }}
        onNavigate={onNavigate}
        onInformationClick={onBackToMenu}
        currentPath="/tier1-journey"
        showSearch={false}
      />

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* ✅ ปุ่มกลับหน้าแรก */}
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/admin')}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับหน้าแรก
        </Button>

        {/* Page Header */}
        <div className="mb-8 text-center">
          <div className="mb-4 inline-flex items-center justify-center gap-3 rounded-full bg-blue-100 px-6 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white">
              T1
            </div>
            <h1 className="m-0 text-blue-900">Tier 1 - ผู้ดูแลระดับแรก</h1>
          </div>
          <p className="text-gray-600 text-lg mb-4">
            ทีมตอบสนองลำดับแรก - รับ คัดกรอง และแก้ไขปัญหาเบื้องต้น
          </p>

          {/* SLA Badge */}
          <Badge variant="outline" className="border-blue-600 text-blue-700 px-4 py-1.5 flex items-center gap-2 mx-auto w-fit">
            <Clock className="h-4 w-4" />
            SLA: 2-4 ชั่วโมง
          </Badge>
        </div>

        {/* Main Responsibilities Card */}
        <Card className="mb-8 border-blue-200 bg-gradient-to-r from-blue-50 to-blue-100">
          <CardHeader>
            <CardTitle className="text-blue-900">ความรับผิดชอบหลัก</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-blue-900">รับเคส</h3>
                <p className="text-sm text-gray-700">
                  รับและตรวจสอบเคสใหม่จากกล่องขาเข้ารวม
                </p>
              </div>
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-blue-900">คัดกรอง</h3>
                <p className="text-sm text-gray-700">
                  จัดหมวดหมู่และประเมินความสำคัญของเคส
                </p>
              </div>
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-blue-900">แก้ไข/ส่งต่อ</h3>
                <p className="text-sm text-gray-700">
                  แก้ไขปัญหาง่ายๆ หรือส่งต่อไป Tier 2
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Journey Steps */}
        <div className="mb-12">
          <h2 className="mb-8 text-center">ขั้นตอนการทำงาน</h2>

          {/* Desktop Flow - Horizontal */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Connecting Line */}
              <div className="absolute top-16 left-0 right-0 h-0.5 bg-gray-300" style={{ left: '10%', right: '10%' }} />
              
              <div className="grid grid-cols-5 gap-4">
                {steps.map((step, index) => {
                  const colors = getColorClasses(step.color);
                  const Icon = step.icon;
                  
                  return (
                    <div key={step.number} className="relative">
                      <Card className={`border-2 ${colors.border} ${colors.bg} h-full`}>
                        <CardContent className="p-6">
                          {/* Number Badge */}
                          <div className="flex justify-center mb-4">
                            <div className={`flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg relative z-10`}>
                              <Icon className="h-8 w-8 text-white" />
                            </div>
                          </div>

                          <h3 className={`mb-2 text-center ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-center text-sm text-gray-700 mb-4">
                            {step.description}
                          </p>

                          {step.sla && (
                            <div className="mb-4 text-center">
                              <Badge variant="outline" className={`${colors.text} border-current text-xs`}>
                                {step.sla}
                              </Badge>
                            </div>
                          )}

                          <ul className="space-y-2">
                            {step.details.map((detail, idx) => (
                              <li key={idx} className="flex items-start text-sm text-gray-700">
                                <span className={`mr-2 ${colors.text}`}>•</span>
                                <span>{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>

                      {/* Arrow */}
                      {index < steps.length - 1 && (
                        <div className="absolute top-16 -right-2 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                          <ArrowRight className="h-4 w-4 text-gray-400" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Mobile/Tablet Flow - Vertical */}
          <div className="lg:hidden space-y-6">
            {steps.map((step, index) => {
              const colors = getColorClasses(step.color);
              const Icon = step.icon;
              
              return (
                <div key={step.number} className="relative">
                  <Card className={`border-2 ${colors.border} ${colors.bg}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        {/* Icon */}
                        <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg`}>
                          <Icon className="h-7 w-7 text-white" />
                        </div>

                        {/* Title */}
                        <div className="flex-1">
                          <h3 className={`mb-1 ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-sm text-gray-700">
                            {step.description}
                          </p>
                          {step.sla && (
                            <Badge variant="outline" className={`mt-2 ${colors.text} border-current text-xs`}>
                              {step.sla}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <ul className="space-y-2">
                        {step.details.map((detail, idx) => (
                          <li key={idx} className="flex items-start text-sm text-gray-700">
                            <span className={`mr-2 ${colors.text}`}>•</span>
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Vertical Arrow */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                        <ArrowRight className="h-4 w-4 rotate-90 text-gray-400" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Tips Card */}
        <Card className="border-blue-200 bg-blue-50 mb-8">
          <CardHeader>
            <CardTitle className="text-blue-900">💡 เคล็ดลับสำหรับ Tier 1</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="mr-2 text-blue-600">✓</span>
                <span>ตอบกลับลูกค้าภายใน 2-4 ชั่วโมงเพื่อให้เป็นไปตาม SLA</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-blue-600">✓</span>
                <span>ใช้เทมเพลตคำตอบสำหรับปัญหาที่พบบ่อยเพื่อประหยัดเวลา</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-blue-600">✓</span>
                <span>บันทึกรายละเอียดการตรวจสอบก่อนส่งต่อไป Tier 2</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-blue-600">✓</span>
                <span>ติดตามเคสที่ส่งต่อและอัปเดตลูกค้าเป็นระยะ</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Button Actions Guide */}
        <Card className="border-blue-300 mb-8">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100">
            <CardTitle className="text-blue-900">🎯 การใช้งานปุ่มหลัก (หลังจากรับเคส)</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Button 1: ส่งต่อ */}
              <div className="flex items-start gap-4 pb-6 border-b">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-orange-100">
                  <ArrowUpRight className="h-6 w-6 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h3 className="mb-2 text-orange-900">🔄 ส่งต่อ (Escalate)</h3>
                  <p className="text-sm text-gray-700 mb-3">
                    <strong>ใช้เมื่อ:</strong> ปัญหาซับซ้อนเกินกว่าความสามารถของ Tier 1
                  </p>
                  <div className="bg-orange-50 rounded-lg p-4 space-y-2 text-sm">
                    <p className="text-orange-900"><strong>ตัวอย่างสถานการณ์:</strong></p>
                    <ul className="space-y-1 text-gray-700 ml-4">
                      <li>• ต้องการเข้าถึงฐานข้อมูลหรือ Server Logs</li>
                      <li>• ปัญหาทางเทคนิคที่ต้องแก้ไข Code/Configuration</li>
                      <li>• Bug ในระบบที่ต้องให้ทีม SA ตรวจสอบ</li>
                      <li>• ต้องการความเชี่ยวชาญด้านเทคนิคเฉพาะทาง</li>
                    </ul>
                    <p className="text-orange-900 pt-2"><strong>ขั้นตอน:</strong></p>
                    <p className="text-gray-700">1. คลิก "ส่งต่อ" → 2. เลือก Tier 2 หรือ Tier 3 → 3. ระบุเหตุผลและข้อมูลที่ตรวจสอบแล้ว</p>
                  </div>
                </div>
              </div>

              {/* Button 2: แก้ไขแล้ว */}
              <div className="flex items-start gap-4 pb-6 border-b">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-green-100">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <h3 className="mb-2 text-green-900">✅ แก้ไขแล้ว (Resolved)</h3>
                  <p className="text-sm text-gray-700 mb-3">
                    <strong>ใช้เมื่อ:</strong> แก้ไขปัญหาสำเร็จและยืนยันกับลูกค้าแล้ว
                  </p>
                  <div className="bg-green-50 rounded-lg p-4 space-y-2 text-sm">
                    <p className="text-green-900"><strong>ตัวอย่างสถานการณ์:</strong></p>
                    <ul className="space-y-1 text-gray-700 ml-4">
                      <li>• ให้คำแนะนำและลูกค้าแก้ไขปัญหาได้แล้ว</li>
                      <li>• Reset Password หรือปลดล็อก Account สำเร็จ</li>
                      <li>• อธิบายวิธีใช้งานและลูกค้าเข้าใจแล้ว</li>
                      <li>• ทดสอบการแก้ไขกับลูกค้าและยืนยันว่าใช้งานได้</li>
                    </ul>
                    <p className="text-green-900 pt-2"><strong>ขั้นตอน:</strong></p>
                    <p className="text-gray-700">1. คลิก "แก้ไขแล้ว" → 2. เพิ่มความคิดเห็นสรุปวิธีแก้ไข → 3. เคสจะเปลี่ยนสถานะเป็น "Resolved"</p>
                  </div>
                </div>
              </div>

              {/* Button 3: ระงับเคส */}
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-yellow-100">
                  <CirclePause className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="flex-1">
                  <h3 className="mb-2 text-yellow-900">⏸️ ระงับเคส (On-Hold)</h3>
                  <p className="text-sm text-gray-700 mb-3">
                    <strong>ใช้เมื่อ:</strong> รอข้อมูลเพิ่มเติมจากลูกค้าหรือหน่วยงานอื่น
                  </p>
                  <div className="bg-yellow-50 rounded-lg p-4 space-y-2 text-sm">
                    <p className="text-yellow-900"><strong>ตัวอย่างสถานการณ์:</strong></p>
                    <ul className="space-y-1 text-gray-700 ml-4">
                      <li>• รอลูกค้าส่ง Screenshot หรือข้อมูลเพิ่มเติม</li>
                      <li>• รอการอนุมัติจากผู้จัดการ</li>
                      <li>• รอทีมอื่นให้ข้อมูลเพิ่มเติม</li>
                      <li>• ลูกค้าขอเวลาทดสอบก่อนปิดเคส</li>
                    </ul>
                    <p className="text-yellow-900 pt-2"><strong>ขั้นตอน:</strong></p>
                    <p className="text-gray-700">1. คลิก "ระงับเคส" → 2. ระบุเหตุผลที่ต้องระงับ → 3. เคสจะเปลี่ยนสถานะเป็น "On-Hold"</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tier Escalation Diagram */}
        <Card className="border-blue-300 mb-8 bg-gradient-to-br from-blue-50 via-white to-purple-50">
          <CardHeader>
            <CardTitle className="text-blue-900">📊 แผนการส่งต่อเคส</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <TierEscalationDiagram />
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card className="border-blue-200 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="mb-4 text-white">พร้อมที่จะจัดการเคสแล้วหรือยัง?</h2>
            <p className="mb-6 text-blue-100">
              เริ่มต้นจัดการเคสและให้บริการลูกค้าอย่างมืออาชีพ
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('/admin/tickets')}
              >
                ดูเคสทั้งหมด
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-blue-600"
                onClick={() => onNavigate('/admin')}
              >
                ไปที่แดชบอร์ด
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Tier1JourneyPage;