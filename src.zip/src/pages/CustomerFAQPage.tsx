import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { ChevronDown, ChevronUp, Search, HelpCircle, MessageCircle, Mail, Phone } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Header } from '../components/layout/Header';
import { Badge } from '../components/ui/badge';
import { PageBackButton } from '../components/common/PageBackButton'; // ✅ Import PageBackButton

interface CustomerFAQPageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

const faqData: FAQItem[] = [
  // ปัญหาการ Login/เข้าสู่ระบบ
  {
    id: '1',
    question: 'เข้าหน้า Login ระบบไม่ได้ ต้องทำอย่างไร?',
    answer: '1. ตรวจสอบ URL ว่าพิมพ์ถูกต้องหรือไม่\n\n- กรณีพิมพ์ URL ไม่ถูกต้อง ให้พิมพ์ใหม่ให้ถูกต้อง\n- กรณีพิมพ์ URL ถูกต้องแล้ว ยังไม่ขึ้นหน้า Login ตรวจสอบต่อตามข้อ 2\n\n2. ตรวจสอบ Internet ของหน่วยงานว่ามีปัญหาหรือไม่ ด้วยการเปิด website ทั่วไป เช่น Facebook เป็นต้น\n\n- กรณีเข้า website ทั่วไปไม่ได้ ให้ผู้ใช้ติดต่อเจ้าหน้าที่ที่ดูแลเกี่ยวกับ Internet ของหน่วยงาน\n- กรณีเข้า website ทั่วไปได้ ให้ผู้ใช้ Capture หน้าจอที่แจ้งว่าเข้าระบบสารบรรณไม่ได้แล้วแจ้งปัญหา\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ก่อนใช้งานระบบ จะต้องตั้งค่าเครื่องคอมพิวเตอร์ก่อน, ทุกครั้งที่เรียก URL ระบบสารบรรณฯ ควรตรวจสอบว่าพิมพ์ถูกต้องหรือไม่',
    category: 'ปัญหาการ Login/เข้าสู่ระบบ'
  },
  {
    id: '2',
    question: 'Login เข้าระบบสารบรรณไม่ได้ ระบบแจ้งว่า "ชื่อผู้ใช้หรือรหัสผ่านผิด กรุณาใส่ใหม่อีกครั้ง"',
    answer: 'ตรวจสอบ ชื่อผู้ใช้และรหัสผ่าน ว่าพิมพ์ถูกต้องหรือไม่\n\n- กรณีพิมพ์ชื่อผู้ใช้และรหัสผ่าน ไม่ถูกต้อง ให้พิมพ์ใหม่ให้ถูกต้อง\n- กรณีพิมพ์ชื่อผู้ใช้และรหัสผ่าน ถูกต้องแล้ว แต่ยัง Login เข้าระบบไม่ได้ ให้ผู้ใช้ติดต่อเจ้าหน้าที่ของหน่วยงานตนเองที่ดูแลเรื่องอีเมล ให้ตรวจสอบอีเมลและรหัสผ่านอีกครั้ง\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** เพื่อป้องกันปัญหาการลืม Username/Password ควรจดบันทึกไว้',
    category: 'ปัญหาการ Login/เข้าสู่ระบบ'
  },
  
  // ปัญหาการรับหนังสือ
  {
    id: '3',
    question: 'ต้นเรื่องไม่ส่งหนังสือมาในระบบ ส่งมาแต่กระดาษตัวจริง จึงไม่สามารถรับหนังสือในระบบได้',
    answer: '1. ตรวจสอบว่าหนังสือฉบับนั้นลงวันที่ก่อนใช้ระบบหรือไม่\n\n- กรณีถ้าหนังสือฉบับนั้นลงวันที่ก่อนใช้ระบบ ให้ปลายทางลงรับหนังสือโดยใช้โปรแกรม บันทึกหนังสือนอกระบบ\n- กรณีหนังสือฉบับนั้นลงวันที่เป็นวันที่ปัจจุบันที่เริ่มใช้ระบบแล้ว ต้องให้ทางต้นเรื่องสร้างหนังสือและออกเลขในระบบก่อน แล้วค่อยกดส่งมาปลายทาง\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการรับหนังสือ'
  },
  {
    id: '4',
    question: 'ระบบไม่แสดง Pop-Up หน้าจอแสดงเลขรับ-เลขส่ง ขึ้นมาให้',
    answer: 'แจ้งให้ผู้ใช้ทำการตั้งค่าเครื่องคอมพิวเตอร์ก่อนใช้งานระบบ โดยศึกษาจากคู่มือ\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ก่อนใช้งานระบบ จะต้องตั้งค่าเครื่องคอมพิวเตอร์ก่อน',
    category: 'ปัญหาการตั้งค่าและ Pop-Up'
  },
  {
    id: '5',
    question: 'ระบบแจ้งเตือนว่าไม่สามารถบันทึกหนังสือได้เพราะ "ลงวันที่ของหนังสือต้องไม่มากกว่าวันที่ปัจจุบัน"',
    answer: 'แจ้งให้ผู้ใช้ไปตั้งค่าวันที่, เวลาในเครื่องคอมพิวเตอร์ให้ตรงกับปัจจุบัน แล้ว Log In เข้าระบบใหม่\n\n- กรณี แก้ไขวันเวลาในเครื่องคอมพิวเตอร์ให้ตรงกับปัจจุบันแล้ว แต่วันที่กับเวลาไม่เปลี่ยนให้ แจ้งให้ผู้ใช้ ติดต่อกับศูนย์ IT ของหน่วยงาน เพื่อเปลี่ยนถ่าน Mainboard\n\n**ระยะเวลาดำเนินการ:** 30-60 นาที\n\n**การป้องกัน:** ตรวจสอบวัน, เวลา ของเครื่องคอมพิวเตอร์เสมอว่าตรงกับวันเวลาปัจจุบันหรือไม่',
    category: 'ปัญหาการตั้งค่าและ Pop-Up'
  },
  
  // ปัญหาการออกรายงาน
  {
    id: '6',
    question: 'สามารถออกรายงานให้เป็นแนวตั้งได้หรือไม่?',
    answer: 'สามารถทำได้ โดยให้ผู้ใช้บันทึกรายงานที่ต้องการมาไว้ในเครื่องคอมพิวเตอร์ก่อน แล้วจึงปรับตั้งค่าหน้ากระดาษก่อนสั่งพิมพ์ให้เป็นแนวตั้ง\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** แนะนำให้เจ้าหน้าที่บันทึกรายงานที่ต้องการเป็นไฟล์ แล้วจึงปรับตั้งค่าหน้ากระดาษตามที่ต้องการก่อนสั่งพิมพ์',
    category: 'ปัญหาการออกรายงาน'
  },
  {
    id: '7',
    question: 'ออกรายงานเป็นรูปแบบ PDF ไม่ได้ ต้องทำอย่างไร?',
    answer: 'ให้ผู้ใช้ตรวจสอบที่เครื่องคอมพิวเตอร์ว่าติดตั้งโปรแกรมอ่าน PDF แล้วหรือไม่\n\n- กรณีติดตั้งโปรแกรมอ่าน PDF แล้ว แต่ยังออกรายงานรูปแบบ PDF ไม่ได้ ให้เลือกการออกรายงานในรูปแบบอื่น เช่น RTF, XLS, HTML เป็นต้น\n- กรณียังไม่ติดตั้งโปรแกรมอ่าน PDF ให้ดาวน์โหลดโปรแกรม Adobe Reader หรือโปรแกรมอ่าน PDF อื่นๆ มาติดตั้ง หรือให้เลือกการออกรายงานในรูปแบบอื่น เช่น RTF, XLS, HTML เป็นต้น\n\n**ระยะเวลาดำเนินการ:** 30-60 นาที\n\n**การป้องกัน:** ควรติดตั้งโปรแกรมอ่าน PDF ที่เครื่องคอมพิวเตอร์ที่จะใช้งานระบบสารบรรณ หรือ เลือกการออกรายงานในรูปแบบอื่น เช่น RTF, XLS, HTML เป็นต้น',
    category: 'ปัญหาการออกรายงาน'
  },
  
  // ปัญหาการบันทึกข้อมูล
  {
    id: '8',
    question: 'หากหนังสือภายนอกที่ส่งมาให้ ไม่มีเลขที่หนังสือ ต้องทำอย่างไร?',
    answer: 'ในหน้าโปรแกรมบันทึกรับจากภายนอก ให้เจ้าหน้าที่คลิกเลือก "ใช้เลขรับ-ปี พ.ศ." แทนการใส่เลขที่หนังสือ เพื่อไม่ให้หนังสือซ้ำ\n\n**ระยะเวลาดำเนินการ:** 15 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '9',
    question: 'ลงทะเบียนรับหนังสือ แต่ไม่ได้เลขรับ ทำไม?',
    answer: 'หนังสือทุกฉบับที่ผู้ใช้ออกเลขทะเบียนส่งหนังสือเอง หากมีการลงทะเบียนรับอีกครั้ง จะไม่ได้เลขรับ แต่จะแสดงแค่วันที่กับเวลาที่ลงรับให้เท่านั้น\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '10',
    question: 'หากต้องการดูหนังสือทั้งหมดที่หน่วยงานของเราเคยรับมา หรือเคยออกเลขทะเบียนส่ง จะดูได้จากที่ไหน?',
    answer: 'สามารถค้นหาได้จากโปรแกรมค้นหารายการสมุดทะเบียน, เลือกเงื่อนไขสมุดทะเบียนรับหรือสมุดทะเบียนส่ง, แล้วกดค้นหา\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '11',
    question: 'บันทึกหนังสือรับจากภายนอก ระบบแจ้งว่าพบหนังสือซ้ำ ควรทำอย่างไร?',
    answer: 'สามารถรับหนังสือซ้ำได้ โดยในหน้าจอที่ระบบแจ้งหนังสือซ้ำนั้น ให้กดที่ชื่อเรื่อง, แล้วกดจัดเก็บ, ออกเลขทะเบียนรับ, ระบบจะออกเลขรับของหน่วยงานเองให้ โดยไม่ไปปนกับเลขรับของหน่วยงานอื่น\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '12',
    question: 'หนังสือที่มีชั้นความลับจะดำเนินการอย่างไร?',
    answer: 'แนะนำให้กรอกเลขที่หนังสือ และระบุชื่อเรื่องว่า "ลับ, ลับมาก หรือ ลับที่สุด" โดยไม่ต้องใส่รายละเอียดของหนังสือ และไม่ต้องแนบไฟล์\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '13',
    question: 'ถ้าใน "ดึงกลับ" มีหนังสือเยอะๆ จะทำให้หายได้อย่างไร?',
    answer: 'ทำไม่ได้ เพราะหนังสือที่อยู่ในสถานะ "ดึงกลับ" นั้นคือหนังสือที่เราส่งไปแล้ว แค่รอให้ปลายทางลงรับ หากปลายทางมีการรับหนังสือแล้ว หนังสือในสถานะ "ดึงกลับ" ก็จะลดลงเอง\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '14',
    question: 'ในโปรแกรม บันทึกหนังสือรับจากภายนอก วันที่ตรง "ลงวันที่" เป็นวันที่ในหนังสือหรือวันที่ปัจจุบัน?',
    answer: 'เป็น "ลงวันที่ของหนังสือ"\n\n**ระยะเวลาดำเนินการ:** 15 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  },
  {
    id: '15',
    question: 'ช่วงต้นปี ขึ้นปีใหม่ ค้นหาหนังสือไม่พบ ทำไม?',
    answer: 'ปัญหานี้มักเกิดจาก หนังสือที่ค้นหานั้นเป็นหนังสือที่ลงวันที่ของปีเก่า จึงแนะนำให้เปลี่ยนปี พ.ศ. เป็นปีเก่าก่อน จึงจะค้นหาพบ\n\n**ระยะเวลาดำเนินการ:** 15 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการค้นหาข้อมูล'
  },
  
  // ปัญหาการรับหนังสือ (ต่อ)
  {
    id: '16',
    question: 'หนังสือที่ส่งมายังหน่วยงานไม่ขึ้นตรง "รอรับ" ต้องทำอย่างไร?',
    answer: 'ให้ผู้ใช้ถามต้นเรื่อง ว่าได้ส่งหนังสือมาตามระบบหรือไม่\n\n- กรณีต้นเรื่องยังไม่ส่งหนังสือมาตามระบบ ให้ผู้ใช้แจ้งกับต้นเรื่องให้ส่งหนังสือมาตามระบบด้วย\n- กรณีต้นเรื่องส่งหนังสือมาตามระบบแล้ว ให้ผู้ใช้กด F5 หรือกดที่สถานะ "รอรับ" อีกครั้ง เพื่อ refresh หน้าจอ\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** หน่วยงานที่ใช้ระบบสารบรรณฯ ควรส่งหนังสือมาตามระบบด้วย, กด F5 หรือกดที่สถานะ "รอรับ" อีกครั้ง เพื่อ refresh หน้าจอ',
    category: 'ปัญหาการรับหนังสือ'
  },
  
  // ปัญหาการส่งหนังสือ
  {
    id: '17',
    question: 'ส่งหนังสือไปผิดหน่วยงาน แก้ไขอย่างไร?',
    answer: '1. กรณีหน่วยงานปลายทางยังไม่ได้ลงรับหนังสือฉบับที่ส่งไปผิด ให้ผู้ใช้ไปที่สถานะ "ดึงกลับ" คลิกเลือกหน้าหนังสือที่ส่งไปผิด แล้วกดปุ่ม "ดึงกลับ" ด้านขวาบน ใส่หมายเหตุว่าดึงกลับเพราะอะไร เมื่อดึงกลับมาแล้ว หนังสือจะย้ายไปอยู่สถานะ "ค้างส่ง" แล้วจึงค่อยส่งไปหน่วยงานที่ถูกต้อง\n\n2. กรณีหน่วยงานปลายทางลงรับหนังสือฉบับที่ส่งไปผิดแล้ว ต้องประสานไปยังหน่วยงานปลายทางให้กดคืนหนังสือกลับมาให้\n\n**ระยะเวลาดำเนินการ:** 30-45 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการส่งหนังสือ'
  },
  {
    id: '18',
    question: 'หากต้องส่งหนังสือให้กลุ่มภายใต้ แต่กลุ่มภายใต้ยังไม่ได้ใช้งานระบบ ต้องทำอย่างไร?',
    answer: 'ในระบบให้ผู้ใช้กดปิดเรื่องหนังสือฉบับที่ต้องส่งไปกลุ่มภายใต้ และใส่หมายเหตุไว้ว่าส่งให้กลุ่มภายใต้ดำเนินการแล้ว ส่วนเอกสารตัวจริงให้ส่งไปยังกลุ่มภายใต้ดำเนินการต่อ\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการส่งหนังสือ'
  },
  {
    id: '19',
    question: 'ถ้าปิดเรื่องไปแล้ว สามารถนำเรื่องนั้นกลับมาใช้ส่งได้อีกหรือไม่?',
    answer: 'สามารถนำเรื่องนั้นกลับมาส่งต่อได้ โดยการค้นหาหนังสือฉบับนั้นขึ้นมา แล้วกดส่งไปยังหน่วยงานที่ต้องการได้เลย\n\n**ระยะเวลาดำเนินการ:** 30 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการส่งหนังสือ'
  },
  {
    id: '20',
    question: 'ในโปรแกรมบันทึกหนังสือรับจากภายนอก วันที่ตรง "ลงวันที่" เป็นวันที่ในหนังสือหรือวันที่ปัจจุบัน?',
    answer: 'เป็น "ลงวันที่ของหนังสือ"\n\n**ระยะเวลาดำเนินการ:** 15 นาที\n\n**การป้องกัน:** ศึกษาจากคู่มือ',
    category: 'ปัญหาการบันทึกข้อมูล'
  }
];

const categories = ['ทั้งหมด', 'ปัญหาการ Login/เข้าสู่ระบบ', 'ปัญหาการรับหนังสือ', 'ปัญหาการตั้งค่าและ Pop-Up', 'ปัญหาการออกรายงาน', 'ปัญหาการบันทึกข้อมูล', 'ปัญหาการค้นหาข้อมูล', 'ปัญหาการส่งหนังสือ'];
export default function CustomerFAQPage({ onNavigate, onBackToMenu }: CustomerFAQPageProps) {
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ทั้งหมด');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Filter FAQ based on search and category
  const filteredFAQ = faqData.filter(item => {
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'ทั้งหมด' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <Header 
        onNavigate={onNavigate} 
        onBackToMenu={onBackToMenu}
        user={user ? {
          fullName: user.fullName || 'User',
          role: user.role || 'customer'
        } : undefined}
        showSearch={false}
      />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-12 text-white">
        <div className="container mx-auto px-4 text-center">
          <HelpCircle className="mx-auto mb-4 h-16 w-16" />
          <h1 className="mb-3">คำถามที่พบบ่อย (FAQ)</h1>
          <span className="mx-auto block max-w-3xl text-base sm:text-lg opacity-90">
            ค้นหาคำตอบสำหรับคำถามที่พบบ่อยเกี่ยวกับการใช้งานระบบ Application Support Center
          </span>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="container mx-auto px-4 py-8">
        <div className="mx-auto max-w-4xl">
          {/* ✅ Back Button */}
          <PageBackButton 
            onNavigate={onNavigate} 
            backPath="/" 
            label="กลับหน้าแรก"
            className="mb-6"
          />

          {/* Search Bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="ค้นหาคำถาม..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-base"
            />
          </div>

          {/* Category Filter */}
          <div className="mb-8 flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                onClick={() => setSelectedCategory(category)}
                size="sm"
              >
                {category}
              </Button>
            ))}
          </div>

          {/* FAQ Results Count */}
          <div className="mb-4 text-sm text-gray-600">
            พบ {filteredFAQ.length} คำถาม
            {searchQuery && ` สำหรับ "${searchQuery}"`}
            {selectedCategory !== 'ทั้งหมด' && ` ในหมวด "${selectedCategory}"`}
          </div>

          {/* FAQ List */}
          <div className="space-y-3">
            {filteredFAQ.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <HelpCircle className="mx-auto mb-4 h-12 w-12 text-gray-400" />
                  <p className="mb-2 text-gray-600">ไม่พบคำถามที่ตรงกับการค้นหา</p>
                  <p className="text-sm text-gray-500">ลองใช้คำค้นหาอื่นหรือติดต่อทีมสนับสนุนโดยตรง</p>
                </CardContent>
              </Card>
            ) : (
              filteredFAQ.map((item) => (
                <Card key={item.id} className="overflow-hidden transition-shadow hover:shadow-md">
                  <button
                    onClick={() => toggleExpand(item.id)}
                    className="w-full text-left"
                  >
                    <CardHeader className="flex flex-row items-center justify-between pb-3">
                      <div className="flex-1 pr-4">
                        <div className="mb-1 flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {item.category}
                          </Badge>
                        </div>
                        <CardTitle className="text-base sm:text-lg">
                          {item.question}
                        </CardTitle>
                      </div>
                      <div className="flex-shrink-0">
                        {expandedId === item.id ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </CardHeader>
                  </button>
                  
                  {expandedId === item.id && (
                    <CardContent className="border-t bg-gray-50 pt-4">
                      <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
                        {item.answer}
                      </p>
                    </CardContent>
                  )}
                </Card>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Contact Support Section */}
      <section className="container mx-auto px-4 py-12">
        <Card className="mx-auto max-w-4xl border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <MessageCircle className="h-6 w-6 text-blue-600" />
              ไม่พบคำตอบที่ต้องการ?
            </CardTitle>
            <CardDescription className="text-base">
              ทีมสนับสนุนของเรายินดีให้ความช่วยเหลือคุณ
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-3">
              <Card className="border-blue-200 bg-white">
                <CardHeader className="text-center">
                  <Mail className="mx-auto mb-2 h-8 w-8 text-blue-600" />
                  <CardTitle className="text-base">อีเมล</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="mb-3 text-sm text-gray-600">
                    ส่งอีเมลถึงเรา
                  </p>
                  <a 
                    href="mailto:support@cdgs.co.th"
                    className="text-sm font-medium text-blue-600 hover:underline"
                  >
                    support@cdgs.co.th
                  </a>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-white">
                <CardHeader className="text-center">
                  <Phone className="mx-auto mb-2 h-8 w-8 text-blue-600" />
                  <CardTitle className="text-base">โทรศัพท์</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="mb-3 text-sm text-gray-600">
                    จันทร์-ศุกร์ 9:00-18:00
                  </p>
                  <a 
                    href="tel:02-xxx-xxxx"
                    className="text-sm font-medium text-blue-600 hover:underline"
                  >
                    02-XXX-XXXX
                  </a>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-white">
                <CardHeader className="text-center">
                  <HelpCircle className="mx-auto mb-2 h-8 w-8 text-blue-600" />
                  <CardTitle className="text-base">แจ้งเคส</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="mb-3 text-sm text-gray-600">
                    สร้างเคสใหม่
                  </p>
                  <Button 
                    variant="link" 
                    className="h-auto p-0 text-sm font-medium text-blue-600"
                    onClick={() => onNavigate('/create')}
                  >
                    แจ้งเคสใหม่
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="mt-6 text-center">
              <Button 
                onClick={() => onNavigate('/create')}
                size="lg"
                className="min-w-[200px]"
              >
                แจ้งเคสใหม่
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Quick Tips */}
      <section className="container mx-auto px-4 pb-12">
        <div className="mx-auto max-w-4xl">
          <h2 className="mb-6 text-center text-2xl">เคล็ดลับการใช้งาน</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Card className="border-l-4 border-l-blue-500 bg-blue-50">
              <CardContent className="p-4">
                <h3 className="mb-2 font-medium text-blue-900">💡 ระบุรายละเอียดชัดเจน</h3>
                <p className="text-sm text-blue-800">
                  การให้รายละเอียดปัญหาที่ชัดเจนจะช่วยให้ทีมงานแก้ไขได้รวดเร็วขึ้น
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-500 bg-green-50">
              <CardContent className="p-4">
                <h3 className="mb-2 font-medium text-green-900">📸 แนบภาพหน้าจอ</h3>
                <p className="text-sm text-green-800">
                  ภาพหน้าจอของปัญหาจะช่วยให้ทีมงานเข้าใจสถานการณ์ได้ดีขึ้น
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500 bg-purple-50">
              <CardContent className="p-4">
                <h3 className="mb-2 font-medium text-purple-900">🔔 ติดตามการแจ้งเตือน</h3>
                <p className="text-sm text-purple-800">
                  เปิดการแจ้งเตือนเพื่อไม่พลาดอัพเดทสถานะเคสของคุณ
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white py-8">
        <div className="container mx-auto px-4 text-center text-sm text-gray-600">
          <p>© 2024 CDGS Application Support Center. สงวนลิขสิทธิ์</p>
          <p className="mt-2">การสนับสนุน IT ระดับองค์กร | เปิดบริการ 24/7</p>
        </div>
      </footer>
    </div>
  );
}