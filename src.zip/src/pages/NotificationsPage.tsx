import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Bell, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ArrowUp,
  MessageSquare,
  X,
  Filter,
  Check,
  Trash2,
  ArrowLeft
} from 'lucide-react';
import { cn } from '../lib/utils';
import { db } from '../lib/mockDb/client';
import { Notification as DBNotification, TicketPriority } from '../types';
import { UserRole } from '../contexts/AuthContext';
import { PriorityBadge } from '../components/PriorityBadge';

interface NotificationsPageProps {
  recipientId?: string;  // ✅ polymorphic FK → users.id or customers.id
  userRole?: string;     // UI hint only (display, navigation decisions)
  userRoles?: string[];  // UI hint only
  onNavigate?: (path: string, ticketId?: string) => void;
}

type NotificationType = 'all' | 'new' | 'escalated' | 'resolved' | 'update' | 'sla' | 'sla_warning' | 'sla_breached';

// Extend DB type with UI-specific properties
interface UINotification extends DBNotification {
  icon: any;
  iconColor: string;
  iconBg: string;
  slaType?: 'warning' | 'breached'; // Helper for filtering
}
export default function NotificationsPage({ recipientId, userRole = 'customer', onNavigate }: NotificationsPageProps) {
  const [filter, setFilter] = useState<NotificationType>('all');
  const [notifications, setNotifications] = useState<UINotification[]>([]);

  // ✅ Helper to map DB Notification to UI Notification (Add Icons/Colors)
  const mapToUINotification = (n: DBNotification): UINotification => {
    let icon = AlertCircle;
    let iconColor = 'text-gray-600';
    let iconBg = 'bg-gray-50';
    let slaType: 'warning' | 'breached' | undefined;

    switch (n.type) {
      case 'new':
        icon = AlertCircle;
        iconColor = 'text-blue-600';
        iconBg = 'bg-blue-50';
        break;
      case 'escalated':
        icon = ArrowUp;
        iconColor = 'text-purple-600';
        iconBg = 'bg-purple-50';
        if (n.priority === 'critical') {
            iconColor = 'text-red-600';
            iconBg = 'bg-red-50';
        }
        break;
      case 'resolved':
        icon = CheckCircle2;
        iconColor = 'text-green-600';
        iconBg = 'bg-green-50';
        break;
      case 'update':
        icon = MessageSquare;
        iconColor = 'text-blue-600';
        iconBg = 'bg-blue-50';
        break;
      case 'sla':
        // Determine SLA Type based on keywords
        const isBreached = n.title.includes('เกิน') || n.message.includes('เกิน') || n.priority === 'critical';
        slaType = isBreached ? 'breached' : 'warning';

        if (isBreached) {
            icon = AlertCircle;
            iconColor = 'text-red-600';
            iconBg = 'bg-red-50';
        } else {
            icon = Clock;
            iconColor = 'text-orange-600';
            iconBg = 'bg-orange-50';
        }
        break;
    }

    return {
      ...n,
      icon,
      iconColor,
      iconBg,
      slaType
    };
  };

  // ✅ Fetch notifications by userId FK — canonical contract
  useEffect(() => {
    if (!userId) {
      setNotifications([]);
      return;
    }

    const rawNotifications = db.notifications.getByRecipientId(recipientId);
    const uiNotifications = rawNotifications.map(mapToUINotification);
    setNotifications(uiNotifications);
  }, [recipientId]);

  const unreadCount = notifications.filter(n => n.isNew).length;

  const filteredNotifications = filter === 'all' 
    ? notifications 
    : notifications.filter(n => {
        if (filter === 'sla_warning') return n.slaType === 'warning';
        if (filter === 'sla_breached') return n.slaType === 'breached';
        return n.type === filter;
    });

  const handleMarkAsRead = (id: string) => {
    // 1. Update DB via canonical contract
    db.notifications.markRead(id);
    
    // 2. Update local state
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, isNew: false, isRead: true } : n)
    );
  };

  const handleMarkAllAsRead = () => {
    if (!recipientId) return;

    // 1. Update DB via canonical contract
    db.notifications.markAllReadByRecipientId(recipientId);
    
    // 2. Update local state
    setNotifications(prev => 
      prev.map(n => ({ ...n, isNew: false, isRead: true }))
    );
  };

  const handleDelete = (id: string) => {
    // Local state only (no delete in canonical contract — soft delete handled by backend later)
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleClearAll = () => {
    // Local state only
    setNotifications([]);
  };

  const handleNotificationClick = (notification: UINotification) => {
    // ✅ Admin mode: read-only - ไม่ mark as read (ยกเว้นกดปุ่ม check)
    if (userRole !== 'admin') {
      handleMarkAsRead(notification.id);
    }
    
    if (onNavigate) {
      if (notification.actionUrl) {
        if (userRole === 'admin') {
          onNavigate(notification.actionUrl);
        } else {
          const ticketId = notification.ticketId || notification.actionUrl.split('/').pop();
          
          if (userRole === 'customer') {
            onNavigate('/track-ticket-detail', ticketId);
          } else if (userRole === 'staff') {
            onNavigate('/staff-ticket-detail', ticketId);
          } else {
            onNavigate('/admin/ticket', ticketId);
          }
        }
      }
    }
  };

  const getPriorityBadge = (priority?: string) => {
    if (!priority) return null;
    
    // ✅ Use PriorityBadge component for Centralized Logic
    return (
      <PriorityBadge 
        priority={priority as TicketPriority} 
        userRole={userRole as UserRole} 
        showIcon={false} 
      />
    );
  };

  const filterOptions: { value: NotificationType; label: string; count: number }[] = (
    [
      { value: 'all' as NotificationType, label: 'ทั้งหมด', count: notifications.length },
      { value: 'new' as NotificationType, label: 'เคสใหม่', count: notifications.filter(n => n.type === 'new').length },
      { value: 'update' as NotificationType, label: 'อัปเดต', count: notifications.filter(n => n.type === 'update').length },
      { value: 'escalated' as NotificationType, label: 'ส่งต่อ', count: notifications.filter(n => n.type === 'escalated').length },
      { value: 'sla_warning' as NotificationType, label: 'SLA ใกล้หมด', count: notifications.filter(n => n.slaType === 'warning').length },
      { value: 'sla_breached' as NotificationType, label: 'SLA หลุด', count: notifications.filter(n => n.slaType === 'breached').length },
      { value: 'resolved' as NotificationType, label: 'แก้ไขแล้ว', count: notifications.filter(n => n.type === 'resolved').length },
    ] as { value: NotificationType; label: string; count: number }[]
  ).filter(opt => opt.count > 0);

  return (
    <div className="container max-w-5xl mx-auto p-6 space-y-6">
      {(userRole === 'customer' || userRole === 'staff') && onNavigate && (
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/')}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับหน้าแรก
        </Button>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="flex items-center gap-3">
            <Bell className="h-8 w-8 text-blue-600" />
            การแจ้งเตือน
          </h1>
          <p className="text-gray-600 mt-1">
            คุณมีการแจ้งเตือน {notifications.length} รายการ
            {unreadCount > 0 && (
              <span className="text-blue-600 font-medium"> ({unreadCount} ยังไม่ได้อ่าน)</span>
            )}
          </p>
        </div>

        {notifications.length > 0 && userRole !== 'admin' && (
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleMarkAllAsRead}
                className="gap-2"
              >
                <Check className="h-4 w-4" />
                อ่านทั้งหมด
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleClearAll}
              className="gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4" />
              ลบทั้งหมด
            </Button>
          </div>
        )}
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="h-4 w-4 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">กรอง:</span>
            {filterOptions.map((option) => (
              <Button
                key={option.value}
                variant={filter === option.value ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter(option.value)}
                className="gap-2"
              >
                {option.label}
                <Badge 
                  variant={filter === option.value ? "secondary" : "outline"}
                  className="ml-1"
                >
                  {option.count}
                </Badge>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Bell className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                ไม่มีการแจ้งเตือน
              </h3>
              <p className="text-gray-600">
                {filter === 'all' 
                  ? 'คุณไม่มีการแจ้งเตือนใดๆ ในขณะนี้'
                  : `ไม่มีการแจ้งเตือนประเภท "${filterOptions.find(f => f.value === filter)?.label}"`
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredNotifications.map((notification) => {
            const IconComponent = notification.icon;
            return (
              <Card 
                key={notification.id}
                className={cn(
                  "transition-all hover:shadow-md cursor-pointer group",
                  notification.isNew && "border-l-4 border-l-blue-500 bg-blue-50/30"
                )}
                onClick={() => handleNotificationClick(notification)}
              >
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className={cn(
                      "flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center",
                      notification.iconBg
                    )}>
                      <IconComponent className={cn("h-6 w-6", notification.iconColor)} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold text-gray-900">
                            {notification.title}
                          </h3>
                          {notification.isNew && (
                            <Badge variant="default" className="text-xs bg-blue-600">
                              ใหม่
                            </Badge>
                          )}
                          {notification.priority && getPriorityBadge(notification.priority)}
                        </div>

                        {userRole !== 'admin' && (
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            {notification.isNew && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                onClick={(e: React.MouseEvent) => {
                                  e.stopPropagation();
                                  handleMarkAsRead(notification.id);
                                }}
                                title="ทำเครื่องหมายว่าอ่านแล้ว"
                              >
                                <Check className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={(e: React.MouseEvent) => {
                                e.stopPropagation();
                                handleDelete(notification.id);
                              }}
                              title="ลบ"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>

                      <p className="text-gray-700 mb-2">
                        {notification.message}
                      </p>

                      <div className="flex items-center gap-3 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" />
                          {notification.time}
                        </span>
                        {notification.ticketNumber && (
                          <>
                            <span>•</span>
                            <span className="font-medium text-blue-600">
                              {notification.ticketNumber}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {notifications.length > 0 && (
        <Card className="bg-gray-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                <span>การแจ้งเตือนจะถูกลบอัตโนมัติหลังจาก 30 วัน</span>
              </div>
              <Button 
                variant="link" 
                size="sm"
                className="text-blue-600 hover:text-blue-700"
              >
                ตั้งค่าการแจ้งเตือน
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
