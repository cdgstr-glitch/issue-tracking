import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { ArrowLeft, Plus, Search, FileText, MessageSquare, CheckCircle, User, LogOut, Info, Bell, Clock, ArrowRight } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import { useAuth } from '../contexts/AuthContext';
import { getRoleDisplayName } from '../lib/utils';
import { Badge } from '../components/ui/badge';
import logoImage from '../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png';
import { Header } from '../components/layout/Header';

interface CustomerJourneyPageProps {
  onNavigate: (path: string) => void;
}
export default function CustomerJourneyPage({ onNavigate }: CustomerJourneyPageProps) {
  const { user } = useAuth();

  const steps = [
    {
      number: 1,
      icon: FileText,
      title: 'สร้างเคส',
      description: 'กรอกแบบฟอร์มออนไลน์ผ่าน Web App',
      details: [
        'กรอกข้อมูลติดต่อ',
        'ระบุรายละเอียดปัญหา',
        'เพิ่มป้ายกำกับ',
        'แนบไฟล์ (ถ้ามี)'
      ],
      action: 'สร้างเคสใหม่',
      actionPath: '/create',
      color: 'blue'
    },
    {
      number: 2,
      icon: Clock,
      title: 'รอการตอบกลับ',
      description: 'ทีมงานจะตรวจสอบและดำเนินการ',
      details: [
        'ได้รับอีเมลยืนยันทันที',
        'ทีมงานตรวจสอบภายใน 2-4 ชม.',
        'ได้รับการแจ้งเตือนทุกการอัปเดต',
        'สามารถตอบกลับเพิ่มเติมได้'
      ],
      color: 'yellow'
    },
    {
      number: 3,
      icon: Search,
      title: 'ติดตามสถานะ',
      description: 'ดูความคืบหน้าแบบ Real-time',
      details: [
        'ตรวจสอบสถานะได้ทุกเวลา',
        'ดูไทม์ไลน์ความเคลื่อนไหว',
        'อ่านความคิดเห็นจากทีมงาน',
        'ค้นหาและกรองเคสได้'
      ],
      action: 'ติดตามเคส',
      actionPath: '/track',
      color: 'purple'
    },
    {
      number: 4,
      icon: CheckCircle,
      title: 'ปิดเคส',
      description: 'เสร็จสิ้นและประเมินผล',
      details: [
        'ได้รับการแก้ไขปัญหา',
        'ตรวจสอบและยืนยันผล',
        'ประเมินความพึงพอใจ',
        'ปิดเคสอัตโนมัติ'
      ],
      color: 'green'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        text: 'text-blue-600',
        iconBg: 'bg-blue-600',
        gradient: 'from-blue-500 to-blue-600'
      },
      yellow: {
        bg: 'bg-yellow-50',
        border: 'border-yellow-200',
        text: 'text-yellow-600',
        iconBg: 'bg-yellow-600',
        gradient: 'from-yellow-500 to-yellow-600'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        text: 'text-purple-600',
        iconBg: 'bg-purple-600',
        gradient: 'from-purple-500 to-purple-600'
      },
      green: {
        bg: 'bg-green-50',
        border: 'border-green-200',
        text: 'text-green-600',
        iconBg: 'bg-green-600',
        gradient: 'from-green-500 to-green-600'
      }
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ✅ ใช้ Header component */}
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'customer'
        }}
        onNavigate={onNavigate}
        currentPath="/customer-journey"
        showSearch={false}
      />

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* ✅ ปุ่มกลับหน้าแรก */}
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/')}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับหน้าแรก
        </Button>

        {/* Page Header */}
        <div className="mb-8 text-center">
          <p className="text-gray-600 text-lg mb-8">
            ส่งคำถามโดยตรงผ่านฟอร์มออนไลน์ของเรา<br />
            ออนไลน์ได้เราจะตอบไว
          </p>

          {/* Main Channel Card */}
          <Card className="max-w-md mx-auto border-blue-200 bg-gradient-to-r from-blue-50 to-blue-100">
            <CardContent className="p-8">
              <div className="flex justify-center mb-4">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-r from-blue-500 to-blue-600">
                  <FileText className="h-10 w-10 text-white" />
                </div>
              </div>
              <h2 className="mb-2 text-blue-900">แบบฟอร์มเว็บ</h2>
              <p className="text-blue-800 mb-4">
                ส่งคำถามโดยตรงผ่านฟอร์มออนไลน์ของเรา<br />ออนไลน์ได้เราจะตอบไว
              </p>
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => onNavigate('/create')}
              >
                เริ่มสร้างเคส
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Journey Steps */}
        <div className="mb-12">
          <h2 className="mb-8 text-center">ขั้นตอนการใช้งาน</h2>

          {/* Desktop Flow - Horizontal */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Connecting Line */}
              <div className="absolute top-16 left-0 right-0 h-0.5 bg-gray-300" style={{ left: '10%', right: '10%' }} />
              
              <div className="grid grid-cols-4 gap-6">
                {steps.map((step, index) => {
                  const colors = getColorClasses(step.color);
                  const Icon = step.icon;
                  
                  return (
                    <div key={step.number} className="relative">
                      <Card className={`border-2 ${colors.border} ${colors.bg} h-full`}>
                        <CardContent className="p-6">
                          {/* Number Badge */}
                          <div className="flex justify-center mb-4">
                            <div className={`flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg relative z-10`}>
                              <Icon className="h-8 w-8 text-white" />
                            </div>
                          </div>

                          <h3 className={`mb-2 text-center ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-center text-sm text-gray-700 mb-4">
                            {step.description}
                          </p>

                          <ul className="space-y-2 mb-4">
                            {step.details.map((detail, idx) => (
                              <li key={idx} className="flex items-start text-sm text-gray-700">
                                <span className={`mr-2 ${colors.text}`}>•</span>
                                <span>{detail}</span>
                              </li>
                            ))}
                          </ul>

                          {step.action && (
                            <Button
                              variant="outline"
                              size="sm"
                              className={`w-full ${colors.text} border-current`}
                              onClick={() => onNavigate(step.actionPath!)}
                            >
                              {step.action}
                            </Button>
                          )}
                        </CardContent>
                      </Card>

                      {/* Arrow */}
                      {index < steps.length - 1 && (
                        <div className="absolute top-16 -right-3 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                          <ArrowRight className="h-4 w-4 text-gray-400" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Mobile/Tablet Flow - Vertical */}
          <div className="lg:hidden space-y-6">
            {steps.map((step, index) => {
              const colors = getColorClasses(step.color);
              const Icon = step.icon;
              
              return (
                <div key={step.number} className="relative">
                  <Card className={`border-2 ${colors.border} ${colors.bg}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        {/* Icon */}
                        <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg`}>
                          <Icon className="h-7 w-7 text-white" />
                        </div>

                        {/* Title */}
                        <div className="flex-1">
                          <h3 className={`mb-1 ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-sm text-gray-700">
                            {step.description}
                          </p>
                        </div>
                      </div>

                      <ul className="space-y-2 mb-4">
                        {step.details.map((detail, idx) => (
                          <li key={idx} className="flex items-start text-sm text-gray-700">
                            <span className={`mr-2 ${colors.text}`}>•</span>
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>

                      {step.action && (
                        <Button
                          variant="outline"
                          size="sm"
                          className={`w-full ${colors.text} border-current`}
                          onClick={() => onNavigate(step.actionPath!)}
                        >
                          {step.action}
                        </Button>
                      )}
                    </CardContent>
                  </Card>

                  {/* Vertical Arrow */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                        <ArrowRight className="h-4 w-4 rotate-90 text-gray-400" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-6 text-center">
              <div className="mb-3 text-3xl">⏱️</div>
              <h3 className="mb-2 text-blue-900">รวดเร็ว</h3>
              <p className="text-sm text-blue-800">
                ตอบกลับภายใน 2-4 ชั่วโมง<br />ในเวลาทำการ
              </p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-purple-50">
            <CardContent className="p-6 text-center">
              <div className="mb-3 text-3xl">🔒</div>
              <h3 className="mb-2 text-purple-900">ปลอดภัย</h3>
              <p className="text-sm text-purple-800">
                ข้อมูลของคุณได้รับการ<br />ปกป้องอย่างเต็มที่
              </p>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-6 text-center">
              <div className="mb-3 text-3xl">📊</div>
              <h3 className="mb-2 text-green-900">โปร่งใส</h3>
              <p className="text-sm text-green-800">
                ติดตามสถานะได้<br />ตลอด 24 ชั่วโมง
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <Card className="border-blue-200 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="mb-4 text-white">พร้อมที่จะเริ่มต้นแล้วหรือยัง?</h2>
            <p className="mb-6 text-blue-100">
              สร้างเคสของคุณตอนนี้และรับการสนับสนุนจากทีมผู้เชี่ยวชาญของเรา
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('/create')}
              >
                สร้างเคสใหม่
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-blue-600"
                onClick={() => onNavigate('/track')}
              >
                ติดตามเคสที่มีอยู่
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}