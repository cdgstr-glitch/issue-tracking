import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  ArrowLeft, 
  AlertTriangle,
  Users,
  Shield,
  Send,
  CheckCircle,
  ArrowRight,
  Clock
} from 'lucide-react';
import { DecisionFlowchart } from '../components/DecisionFlowchart';
import { TierEscalationDiagram } from '../components/TierEscalationDiagram';
import { useAuth } from '../contexts/AuthContext';
import { Header } from '../components/layout/Header';

interface Tier3JourneyPageProps {
  onNavigate: (path: string) => void;
  onBackToMenu?: () => void;
}

const Tier3JourneyPage: React.FC<Tier3JourneyPageProps> = ({ onNavigate, onBackToMenu }) => {
  const { user } = useAuth();

  const steps = [
    {
      number: 1,
      icon: AlertTriangle,
      title: 'รับเคสวิกฤติ',
      description: 'รับและประเมินเคสที่มีความซับซ้อนสูง',
      details: [
        'ตรวจสอบเคสที่ Tier 2 ส่งต่อมา',
        'อ่านรายละเอียดการวิเคราะห์จาก Tier 1 และ Tier 2',
        'ประเมินความร้ายแรงและผลกระทบต่อธุรกิจ',
        'กำหนดลำดับความสำคัญของการแก้ไข',
        'เปลี่ยนสถานะเป็น "กำลังดำเนินการ (Tier 3)"'
      ],
      color: 'red',
      sla: 'SLA: 2-5 วัน'
    },
    {
      number: 2,
      icon: Shield,
      title: 'วิเคราะห์ความปลอดภัย',
      description: 'ตรวจสอบภาพรวมและความปลอดภัย',
      details: [
        'วิเคราะห์ Security Logs และ Audit Trails',
        'ตรวจสอบ Security Breach หรือ Vulnerability',
        'ประเมินความเสี่ยงต่อระบบและข้อมูล',
        'ดำเนินการ Incident Response หากจำเป็น',
        'ประสานงานกับทีม Security หากพบปัญหาด้านความปลอดภัย'
      ],
      color: 'purple'
    },
    {
      number: 3,
      icon: Send,
      title: 'แก้ไขโครงสร้างพื้นฐาน',
      description: 'จัดการปัญหาระดับสถาปัตยกรรม',
      details: [
        'วิเคราะห์ระบบโครงสร้างพื้นฐาน (Infrastructure)',
        'แก้ไขปัญหา Network, Server, หรือ Cloud Configuration',
        'ดำเนินการ Disaster Recovery หากจำเป็น',
        'ปรับปรุง Performance และ Scalability',
        'ทดสอบในสภาพแวดล้อมที่คล้ายกับจริง'
      ],
      color: 'indigo'
    },
    {
      number: 4,
      icon: Users,
      title: 'ประสานงานผู้ให้บริการ',
      description: 'ติดต่อและประสานงานกับ Vendor',
      details: [
        'ติดต่อผู้ให้บริการ Cloud (AWS, Azure, GCP)',
        'เปิด Support Ticket กับ Third-party Vendors',
        'ประสานงานกับ Software Vendors',
        'ติดตามความคืบหน้าและ SLA ของผู้ให้บริการ',
        'รวบรวมข้อมูลและส่งต่อให้ผู้ให้บริการ'
      ],
      color: 'orange'
    },
    {
      number: 5,
      icon: CheckCircle,
      title: 'ยืนยันและบันทึกผล',
      description: 'ตรวจสอบผลและบันทึกเป็นเอกสาร',
      details: [
        'ทดสอบการแก้ไขอย่างละเอียดในทุกมิติ',
        'ตรวจสอบว่าไม่มีผลกระทบต่อระบบอื่น',
        'สร้างเอกสาร Post-Mortem Report',
        'อัปเดต Runbook และ Documentation',
        'ส่งกลับไปยัง Tier 2 และ Tier 1 เพื่อปิดเคส',
        'แชร์ความรู้กับทีมเพื่อป้องกันปัญหาในอนาคต'
      ],
      color: 'green'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      red: {
        bg: 'bg-red-50',
        border: 'border-red-200',
        text: 'text-red-600',
        iconBg: 'bg-red-600',
        gradient: 'from-red-500 to-red-600'
      },
      purple: {
        bg: 'bg-purple-50',
        border: 'border-purple-200',
        text: 'text-purple-600',
        iconBg: 'bg-purple-600',
        gradient: 'from-purple-500 to-purple-600'
      },
      indigo: {
        bg: 'bg-indigo-50',
        border: 'border-indigo-200',
        text: 'text-indigo-600',
        iconBg: 'bg-indigo-600',
        gradient: 'from-indigo-500 to-indigo-600'
      },
      orange: {
        bg: 'bg-orange-50',
        border: 'border-orange-200',
        text: 'text-orange-600',
        iconBg: 'bg-orange-600',
        gradient: 'from-orange-500 to-orange-600'
      },
      green: {
        bg: 'bg-green-50',
        border: 'border-green-200',
        text: 'text-green-600',
        iconBg: 'bg-green-600',
        gradient: 'from-green-500 to-green-600'
      }
    };
    return colors[color as keyof typeof colors] || colors.red;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ✅ ใช้ Header component */}
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'tier3'
        }}
        onNavigate={onNavigate}
        onInformationClick={onBackToMenu}
        currentPath="/tier3-journey"
        showSearch={false}
      />

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* ✅ ปุ่มกลับหน้าแรก */}
        <Button 
          variant="ghost" 
          onClick={() => onNavigate('/admin/specialist')}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับแดชบอร์ดผู้เชี่ยวชาญ
        </Button>

        {/* Page Header */}
        <div className="mb-8 text-center">
          <div className="mb-4 inline-flex items-center justify-center gap-3 rounded-full bg-red-100 px-6 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-600 text-white">
              T3
            </div>
            <h1 className="m-0 text-red-900">Tier 3 - ผู้เชี่ยวชาญ/ผู้ให้บริการ</h1>
          </div>
          <p className="text-gray-600 text-lg mb-4">
            ทีมผู้เชี่ยวชาญระดับสูง - จัดการเหตุการณ์วิกฤติและปัญหาซับซ้อน
          </p>

          {/* SLA Badge */}
          <Badge variant="outline" className="border-red-600 text-red-700 px-4 py-1.5 flex items-center gap-2 mx-auto w-fit">
            <Clock className="h-4 w-4" />
            SLA: 2-5 วัน
          </Badge>
        </div>

        {/* Main Responsibilities Card */}
        <Card className="mb-8 border-red-200 bg-gradient-to-r from-red-50 to-red-100">
          <CardHeader>
            <CardTitle className="text-red-900">ความรับผิดชอบหลัก</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-red-900">เหตุการณ์วิกฤติ</h3>
                <p className="text-sm text-gray-700">
                  จัดการปัญหาระดับ Critical ที่ส่งผลกระทบสูง
                </p>
              </div>
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-red-900">โครงสร้างพื้นฐาน</h3>
                <p className="text-sm text-gray-700">
                  แก้ไขปัญหา Infrastructure และ Architecture
                </p>
              </div>
              <div className="rounded-lg bg-white p-4 shadow-sm">
                <h3 className="mb-2 text-red-900">ประสานงาน Vendor</h3>
                <p className="text-sm text-gray-700">
                  ติดต่อผู้ให้บริการและประสานงานภายนอก
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Journey Steps */}
        <div className="mb-12">
          <h2 className="mb-8 text-center">ขั้นตอนการทำงาน</h2>

          {/* Desktop Flow - Horizontal */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Connecting Line */}
              <div className="absolute top-16 left-0 right-0 h-0.5 bg-gray-300" style={{ left: '10%', right: '10%' }} />
              
              <div className="grid grid-cols-5 gap-4">
                {steps.map((step, index) => {
                  const colors = getColorClasses(step.color);
                  const Icon = step.icon;
                  
                  return (
                    <div key={step.number} className="relative">
                      <Card className={`border-2 ${colors.border} ${colors.bg} h-full`}>
                        <CardContent className="p-6">
                          {/* Number Badge */}
                          <div className="flex justify-center mb-4">
                            <div className={`flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg relative z-10`}>
                              <Icon className="h-8 w-8 text-white" />
                            </div>
                          </div>

                          <h3 className={`mb-2 text-center ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-center text-sm text-gray-700 mb-4">
                            {step.description}
                          </p>

                          {step.sla && (
                            <div className="mb-4 text-center">
                              <Badge variant="outline" className={`${colors.text} border-current text-xs`}>
                                {step.sla}
                              </Badge>
                            </div>
                          )}

                          <ul className="space-y-2">
                            {step.details.map((detail, idx) => (
                              <li key={idx} className="flex items-start text-sm text-gray-700">
                                <span className={`mr-2 ${colors.text}`}>•</span>
                                <span>{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>

                      {/* Arrow */}
                      {index < steps.length - 1 && (
                        <div className="absolute top-16 -right-2 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                          <ArrowRight className="h-4 w-4 text-gray-400" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Mobile/Tablet Flow - Vertical */}
          <div className="lg:hidden space-y-6">
            {steps.map((step, index) => {
              const colors = getColorClasses(step.color);
              const Icon = step.icon;
              
              return (
                <div key={step.number} className="relative">
                  <Card className={`border-2 ${colors.border} ${colors.bg}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        {/* Icon */}
                        <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r ${colors.gradient} shadow-lg`}>
                          <Icon className="h-7 w-7 text-white" />
                        </div>

                        {/* Title */}
                        <div className="flex-1">
                          <h3 className={`mb-1 ${colors.text}`}>
                            {step.number}. {step.title}
                          </h3>
                          <p className="text-sm text-gray-700">
                            {step.description}
                          </p>
                          {step.sla && (
                            <Badge variant="outline" className={`mt-2 ${colors.text} border-current text-xs`}>
                              {step.sla}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <ul className="space-y-2">
                        {step.details.map((detail, idx) => (
                          <li key={idx} className="flex items-start text-sm text-gray-700">
                            <span className={`mr-2 ${colors.text}`}>•</span>
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Vertical Arrow */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md">
                        <ArrowRight className="h-4 w-4 rotate-90 text-gray-400" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Tips Card */}
        <Card className="border-red-200 bg-red-50 mb-8">
          <CardHeader>
            <CardTitle className="text-red-900">💡 เคล็ดลับสำหรับ Tier 3</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="mr-2 text-red-600">✓</span>
                <span>รักษาการสื่อสารกับ Tier 1 และ Tier 2 อย่างสม่ำเสมอ</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-red-600">✓</span>
                <span>สร้าง Post-Mortem Report สำหรับเหตุการณ์วิกฤติทุกครั้ง</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-red-600">✓</span>
                <span>ประสานงานกับผู้ให้บริการอย่างรวดเร็วและมีประสิทธิภาพ</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-red-600">✓</span>
                <span>บันทึกและแชร์ความรู้เพื่อป้องกันปัญหาซ้ำในอนาคต</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Decision Flow Diagram */}
        <Card className="border-red-300 mb-8 bg-gradient-to-br from-red-50 via-white to-purple-50">
          <CardHeader>
            <CardTitle className="text-red-900">⚡ Flow การตัดสินใจด่วน (Tier 3 Specialist)</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <DecisionFlowchart tier={3} />
          </CardContent>
        </Card>

        {/* Tier Escalation Diagram */}
        <Card className="border-red-300 mb-8 bg-gradient-to-br from-red-50 via-white to-purple-50">
          <CardHeader>
            <CardTitle className="text-red-900">📊 แผนการส่งต่อเคส</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <TierEscalationDiagram currentTier={3} />
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card className="border-red-200 bg-gradient-to-r from-red-600 to-red-700 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="mb-4 text-white">พร้อมที่จะจัดการเหตุการณ์วิกฤติแล้วหรือยัง?</h2>
            <p className="mb-6 text-red-100">
              ใช้ความเชี่ยวชาญของคุณในการแก้ไขปัญหาที่ซับซ้อนที่สุด
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={() => onNavigate('/admin/tickets')}
              >
                ดูเหตุการณ์วิกฤติ
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-red-600"
                onClick={() => onNavigate('/admin/specialist')}
              >
                ไปที่แดชบอร์ดผู้เชี่ยวชาญ
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Tier3JourneyPage;