// src/pages/CreateTicketPage.tsx
// ✅ SSoT: ใช้ db จาก ../lib/mockDb/client เท่านั้น
// ✅ กฏเหล็ก:
//    - canCreateForCustomer (Staff/Tier สร้างแทนลูกค้า): แสดง Project selector + channel/type/priority + product filter ตาม project
//    - Customer: ไม่ต้องเลือกหน่วยงาน/โครงการ แต่ “ต้องเลือกผลิตภัณฑ์ (required)” + title/description/tags/attachments

import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, CheckCircle, FolderOpen, Package, Upload, X } from 'lucide-react';

import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';

import { RichTextEditor } from '../components/RichTextEditor';
import { TagInput } from '../components/TagInput';
import { ImageUploader } from '../components/ImageUploader';
import { ProjectSelectorModal } from '../components/ProjectSelectorModal';

import { db } from '../lib/mockDb/client'; // ✅ SSoT entry point
import { useAuth } from '../contexts/AuthContext';
import { can, CAPABILITIES, isCustomer, isPureStaff, isTier1 } from '../lib/permissions';

import type { Attachment, User } from '../types';

interface CreateTicketPageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}

export default function CreateTicketPage({ onNavigate }: CreateTicketPageProps) {
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Success state
  const [ticketClosed, setTicketClosed] = useState(false);
  const [ticketAccepted, setTicketAccepted] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');
  const [createdTicketId, setCreatedTicketId] = useState('');

  // Form state
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);

  // Staff-only fields (shown only when canCreateForCustomer)
  const [selectedChannel, setSelectedChannel] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedPriority, setSelectedPriority] = useState('');
  const [incidentDate, setIncidentDate] = useState('');

  // Project modal
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [showProjectModal, setShowProjectModal] = useState(false);

  // Product (✅ required for both Customer + Staff)
  const [selectedProduct, setSelectedProduct] = useState('');

  // Solve & close modal (Tier1 only)
  const [showCloseTicketModal, setShowCloseTicketModal] = useState(false);
  const [solution, setSolution] = useState('');
  const [closureNotes, setClosureNotes] = useState('');
  const [resolvedBy, setResolvedBy] = useState('');
  const [resolvedAt, setResolvedAt] = useState('');
  const [availableStaff, setAvailableStaff] = useState<User[]>([]);

  const { user, customer } = useAuth();
  const currentUser = customer || user;

  // ✅ Permissions
  const canCreateForCustomer = can(currentUser, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER);
  const isUserTier1 = isTier1(currentUser);
  const isUserStaff = isPureStaff(currentUser);
  const isUserCustomer = isCustomer(currentUser);
  const canViewAllTickets = can(currentUser, CAPABILITIES.VIEW_ALL_TICKETS);

  // ✅ Master data (SSoT)
  const categories = db.master.getCategories();
  const channels = db.master.getChannels();
  const types = db.master.getTypes();
  const priorities = db.master.getPriorities();

  // ✅ Selected project/org (staff/tier only)
  const selectedProject = useMemo(() => db.projects.getById(selectedProjectId), [selectedProjectId]);
  const selectedOrganization = useMemo(() => {
    if (!selectedProject) return null;
    return db.organizations.getById((selectedProject as any).organizationId);
  }, [selectedProject]);

  // ✅ Products list (SSoT)
  const availableProducts = useMemo(() => {
    // Base list for UI (value = productId)
    const allProducts = db.products.getAll().map((p: any) => ({
      value: p.id,
      label: p.productName ?? p.id,
      category: p.category,
    }));

    // Customer: show all products (but still required)
    if (!canCreateForCustomer) return allProducts;

    // Staff/Tier: must select project first; options filtered by pivot project_products (via db method)
    if (!selectedProjectId) return [];

    const allowedIds = db.products.getByProjectId(selectedProjectId).map((p: any) => p.id);
    const filtered = allProducts.filter((p) => allowedIds.includes(p.value));

    // Deduplicate
    const unique = new Map<string, (typeof allProducts)[number]>();
    filtered.forEach((p) => {
      if (!unique.has(p.value)) unique.set(p.value, p);
    });

    return Array.from(unique.values());
  }, [canCreateForCustomer, selectedProjectId]);

  const selectedProductLabel = useMemo(() => {
    if (!selectedProduct) return '';
    const p = db.products.getById(selectedProduct) as any;
    return p?.productName || selectedProduct;
  }, [selectedProduct]);

  // 🎯 Auto-select product if only 1 available (Staff/Tier only)
  useEffect(() => {
    if (canCreateForCustomer && selectedProjectId && availableProducts.length === 1) {
      setSelectedProduct(availableProducts[0].value);
    }
  }, [canCreateForCustomer, selectedProjectId, availableProducts]);

  // 🧹 Clear product when project changes/clears (Staff/Tier only)
  useEffect(() => {
    if (canCreateForCustomer && !selectedProjectId) {
      setSelectedProduct('');
    }
  }, [canCreateForCustomer, selectedProjectId]);

  // Default incident date + load staff list (for resolve modal) — Staff/Tier only
  useEffect(() => {
    if (!canCreateForCustomer) return;

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    setIncidentDate(`${year}-${month}-${day}T${hours}:${minutes}`);

    const allUsers = db.users.getAll() as any as User[];
    const staffList = allUsers.filter(
      (u: any) =>
        ['tier1', 'tier2', 'tier3'].includes(u.role) ||
        u.roles?.some((r: any) => ['tier1', 'tier2', 'tier3'].includes(r)),
    );
    setAvailableStaff(staffList);
  }, [canCreateForCustomer]);

  // Default resolve modal values
  useEffect(() => {
    if (!showCloseTicketModal) return;

    if ((currentUser as any)?.fullName) setResolvedBy((currentUser as any).fullName);

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    setResolvedAt(`${year}-${month}-${day}T${hours}:${minutes}`);
  }, [showCloseTicketModal, currentUser]);

  // ✅ Modal: pick project only (product is dropdown in form) => disable product verification in modal
  const handleProjectSelect = (projectId: string) => {
    setSelectedProjectId(projectId);
    setShowProjectModal(false);
  };

  const handleClearProject = () => {
    setSelectedProjectId('');
    setSelectedProduct('');
  };

  const validateCustomer = (e: React.FormEvent) => {
    const formElement = e.target as HTMLFormElement;
    const titleInput = formElement.querySelector('#title') as HTMLInputElement;

    if (!titleInput?.value?.trim()) {
      alert('กรุณากรอกหัวเรื่อง');
      titleInput?.focus();
      return false;
    }

    if (!selectedProduct) {
      alert('กรุณาเลือกผลิตภัณฑ์');
      document.querySelector('[for="product"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    if (!description?.trim()) {
      alert('กรุณากรอกรายละเอียดปัญหา');
      document.getElementById('description')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    return true;
  };

  const validateStaff = () => {
    if (!selectedProject) {
      alert(
        '❌ กรุณาเลือกโครงการก่อนบันทึกเคส\n\nโครงการเป็นข้อมูลบังคับสำหรับทุกปุ่ม (บันทึกเคส, บันทึกและรับเคส, แก้ไขและปิดเคส)',
      );
      document.querySelector('[for="project"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    if (!selectedProduct) {
      alert('❌ กรุณาเลือกผลิตภัณฑ์ก่อนบันทึกเคส');
      document.querySelector('[for="product"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    if (!selectedChannel) {
      alert('❌ กรุณาเลือกช่องทางการติดต่อ');
      document.querySelector('[for="channel"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    if (!selectedType) {
      alert('❌ กรุณาเลือกประเภทปัญหา');
      document.querySelector('[for="type"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    if (!selectedPriority) {
      alert('❌ กรุณาเลือกความสำคัญ');
      document.querySelector('[for="priority"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }

    return true;
  };

  const fakeSubmit = (opts: { accepted?: boolean; closed?: boolean } = {}) => {
    setIsSubmitting(true);
    setTimeout(() => {
      const randomNum = Math.floor(100000 + Math.random() * 900000);
      setTicketNumber(`TKT-${randomNum}`);
      setCreatedTicketId(`TID-${randomNum}`);

      setTicketAccepted(!!opts.accepted);
      setTicketClosed(!!opts.closed);

      setSubmitted(true);
      setIsSubmitting(false);
    }, 1500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (isUserCustomer) {
      if (!validateCustomer(e)) return;
      fakeSubmit();
      return;
    }

    if (canCreateForCustomer) {
      if (!validateStaff()) return;
      fakeSubmit();
      return;
    }

    // fallback (shouldn't happen)
    fakeSubmit();
  };

  const handleSaveAndAccept = () => {
    if (isSubmitting) return;
    if (!validateStaff()) return;
    fakeSubmit({ accepted: true });
  };

  const handleSolveAndClose = () => {
    if (isSubmitting) return;
    if (!validateStaff()) return;
    setShowCloseTicketModal(true);
  };

  const handleConfirmSolveAndClose = () => {
    if (!resolvedAt) return alert('กรุณาระบุวันที่และเวลาที่แก้ไขเสร็จ');
    if (!resolvedBy.trim()) return alert('กรุณาระบุชื่อผู้แก้ไข');
    if (!solution.trim()) return alert('กรุณากรอกวิธีการแก้ไข');

    setShowCloseTicketModal(false);
    fakeSubmit({ closed: true });
  };

  // ===================== Submitted Screen =====================
  if (submitted) {
    const getMessage = () => {
      if (ticketClosed) {
        return {
          title: '✅ แก้ไขและปิดเคสสำเร็จ',
          description: `เคสนี้ได้รับการแก้ไขโดย ${resolvedBy} และปิดเรียบร้อยแล้ว (ปิดย้อนหลัง)`,
          status: 'ปิดเคส (Closed)',
          demoTicketId: 't1-003-clo-1',
          targetPage: '/admin/ticket',
        };
      }

      if (ticketAccepted) {
        return {
          title: '📥 บันทึกและรับเคสสำเร็จ',
          description: 'เคสนี้ถูกบันทึกและคุณได้รับเคสไว้แล้ว คุณสามารถเริ่มดำเนินการได้เลย',
          status: 'กำลังดำเนินการ (In Progress)',
          demoTicketId: 'c2',
          targetPage: '/admin/ticket',
        };
      }

      if (canCreateForCustomer) {
        return {
          title: 'เคสถูกส่งไปยัง Tier1 สำเร็จ',
          description: 'เคสนี้ถูกบันทึกและส่งไปยัง Tier1 แล้ว Tier1 จะต้องกด "รับเคส" เพื่อเริ่มดำเนินการ',
          status: 'รอการรับเคส (New)',
          demoTicketId: 'c5',
          targetPage: '/admin/pending',
        };
      }

      return {
        title: 'แจ้งเคสสำเร็จ',
        description: 'ทีมสนับสนุนของเราได้รับเคสของคุณแล้ว และจะติดต่อกลับโดยเร็วที่สุด',
        status: 'รอการตรวจสอบ',
        demoTicketId: 'c5',
        targetPage: '/track',
      };
    };

    const message = getMessage();

    return (
      <div className="container mx-auto max-w-2xl px-4 py-16 text-center">
        <Card>
          <CardContent className="pt-12 pb-8">
            <div className="mb-6">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>

              <h2 className="mb-2">{message.title}</h2>
              <p className="text-gray-600 mb-4">{message.description}</p>

              <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">
                <span className="text-sm text-gray-600">หมายเลขเคส:</span>
                <span className="text-lg font-semibold text-blue-600">{ticketNumber}</span>
              </div>

              <div className="mt-3">
                <Badge variant="outline" className="text-sm">
                  {message.status}
                </Badge>
              </div>

              {selectedProductLabel && (
                <div className="mt-3 text-xs text-gray-600 flex items-center justify-center gap-2">
                  <Package className="h-4 w-4 text-blue-600" />
                  <span>ผลิตภัณฑ์: {selectedProductLabel}</span>
                </div>
              )}
            </div>

            <p className="text-sm text-gray-500 mb-6">
              {canCreateForCustomer ? 'คุณสามารถติดตามสถานะเคสได้ในหน้า Dashboard' : 'คุณสามารถติดตามสถานะเคสได้ผ่านหมายเลขเคสด้านบน'}
            </p>

            <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Button
                onClick={() => {
                  if (canViewAllTickets) {
                    if (message.targetPage === '/admin/pending') onNavigate('/admin/pending', message.demoTicketId);
                    else onNavigate('/admin/ticket', message.demoTicketId);
                  } else {
                    onNavigate('/track');
                  }
                }}
              >
                ดูรายละเอียดเคส
              </Button>

              <Button
                variant="outline"
                onClick={() => {
                  if (canViewAllTickets) onNavigate('/admin');
                  else onNavigate('/');
                }}
              >
                กลับหน้าหลัก
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ===================== Form Screen =====================
  return (
    <div>
      <div className="container mx-auto max-w-3xl px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => (canViewAllTickets ? onNavigate('/admin') : onNavigate('/'))}
          className="gap-2 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับหน้าแรก
        </Button>

        <div className="mb-8">
          <h1 className="mb-2">
            {canCreateForCustomer ? `แจ้งเคสใหม่โดยเจ้าหน้าที่ชื่อ ${(currentUser as any)?.fullName || 'เจ้าหน้าที่'}` : 'แจ้งเคสใหม่'}
          </h1>
          {!canCreateForCustomer && (
            <p className="text-gray-600">กรอกแบบฟอร์มด้านล่างและทีมสนับสนุนของเราจะติดต่อกลับโดยเร็วที่สุด</p>
          )}
        </div>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>{canCreateForCustomer ? 'ข้อมูลงานลูกค้า' : 'ข้อมูลงาน'}</CardTitle>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* ===================== STAFF: Customer info ===================== */}
              {canCreateForCustomer && (
                <>
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="customerName">ชื่อ-นามสกุลลูกค้า *</Label>
                      <Input id="customerName" required placeholder="ศิริพร อารีมิตร" />
                      <p className="text-xs text-gray-500">กรอกชื่อลูกค้าที่ติดต่อเข้ามา</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customerEmail">อีเมลลูกค้า *</Label>
                      <Input id="customerEmail" type="email" required placeholder="customer@company.com" />
                      <p className="text-xs text-gray-500">กรอกอีเมลของลูกค้า</p>
                    </div>
                  </div>

                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="customerPhone">เบอร์โทรศัพท์ลูกค้า</Label>
                      <Input id="customerPhone" placeholder="+66-XX-XXX-XXXX" />
                      <p className="text-xs text-gray-500">ไม่บังคับ</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customerDepartment">หน่วยงาน/สังกัดลูกค้า</Label>
                      <Input id="customerDepartment" placeholder="เช่น ฝ่าย IT, การตลาด" />
                      <p className="text-xs text-gray-500">ไม่บังคับ</p>
                    </div>
                  </div>
                </>
              )}

              {/* ===================== STAFF: Channel ===================== */}
              {canCreateForCustomer && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="channel">ช่องทางการติดต่อ *</Label>
                    <Select required value={selectedChannel} onValueChange={setSelectedChannel}>
                      <SelectTrigger id="channel">
                        <SelectValue placeholder="เลือกช่องทางที่ลูกค้าติดต่อเข้ามา" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(channels as any).map(([key, config]: any) => {
                          if (key === 'internal' || key === 'web') return null;
                          return (
                            <SelectItem key={key} value={key}>
                              {config.label}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500">เลือกช่องทางที่ลูกค้าใช้ติดต่อเข้ามา</p>
                  </div>

                  {selectedChannel === 'line' && (
                    <div className="space-y-2">
                      <Label htmlFor="lineId">Line ID (ไม่บังคับ)</Label>
                      <Input id="lineId" placeholder="เช่น @example หรือ user123 (ถ้ามี)" />
                      <p className="text-xs text-gray-500">กรอกถ้ามีข้อมูล</p>
                    </div>
                  )}
                </>
              )}

              {/* ===================== STAFF: Project selector ===================== */}
              {canCreateForCustomer && (
                <div className="space-y-2">
                  <Label htmlFor="project">โครงการ / Project *</Label>

                  {selectedProject && selectedOrganization ? (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 px-4 py-3 rounded-lg border border-blue-200 bg-blue-50">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs bg-white">
                            {(selectedOrganization as any).organizationShortName}
                          </Badge>
                          <span className="text-xs text-gray-500">{(selectedProject as any).projectCode}</span>
                        </div>

                        <p className="text-sm font-medium">{(selectedProject as any).projectName}</p>
                        <p className="text-xs text-gray-500 mt-0.5">{(selectedOrganization as any).organizationName}</p>

                        {selectedProductLabel && (
                          <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-blue-200">
                            <Package className="h-3.5 w-3.5 text-blue-500 shrink-0" />
                            <span className="text-xs font-medium text-blue-700">{selectedProductLabel}</span>
                          </div>
                        )}
                      </div>

                      <Button type="button" variant="ghost" size="sm" onClick={handleClearProject} className="flex-shrink-0">
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <Button
                      type="button"
                      id="project"
                      variant="outline"
                      className="w-full justify-start text-gray-500"
                      onClick={() => setShowProjectModal(true)}
                    >
                      <FolderOpen className="h-4 w-4 mr-2" />
                      เลือกโครงการ...
                    </Button>
                  )}

                  <p className="text-xs text-gray-500">
                    ⚠️ <strong>จำเป็นต้องเลือก:</strong> โครงการเป็นข้อมูลบังคับสำหรับทุกปุ่ม (บันทึกเคส, บันทึกและรับเคส, แก้ไขและปิดเคส)
                  </p>
                </div>
              )}

              {/* ===================== PRODUCT (✅ required for both) ===================== */}
              <div className="space-y-2">
                <Label htmlFor="product">ผลิตภัณฑ์ *</Label>

                <Select required value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger id="product">
                    <SelectValue
                      placeholder={
                        canCreateForCustomer
                          ? selectedProjectId
                            ? 'เลือกผลิตภัณฑ์...'
                            : 'กรุณาเลือกโครงการก่อน'
                          : 'เลือกผลิตภัณฑ์...'
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {availableProducts.length === 0 ? (
                      <div className="px-3 py-2 text-xs text-muted-foreground">
                        {canCreateForCustomer && !selectedProjectId
                          ? 'ต้องเลือกโครงการก่อน จึงจะแสดงผลิตภัณฑ์'
                          : 'ไม่พบผลิตภัณฑ์'}
                      </div>
                    ) : (
                      availableProducts.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>

                <p className="text-xs text-gray-500">
                  {canCreateForCustomer
                    ? 'แสดงเฉพาะผลิตภัณฑ์ที่อยู่ในโครงการที่เลือก (ผ่าน pivot project_products)'
                    : 'ลูกค้าต้องเลือกผลิตภัณฑ์ที่ใช้งานอยู่เพื่อให้ทีมวิเคราะห์ปัญหาได้ถูกต้อง'}
                </p>
              </div>

              {/* ===================== Issue Details ===================== */}
              <div className="border-t pt-6">
                <h3 className="mb-4">รายละเอียดปัญหา</h3>

                {/* Category: hide for Customer */}
                {!isUserCustomer && (
                  <div className="space-y-2 mb-6">
                    <Label htmlFor="category">หมวดหมู่</Label>
                    <Select>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="เลือกหมวดหมู่ (ไม่บังคับ)" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat: any) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500">สามารถเลือกหมวดหมู่ทีหลังได้</p>
                  </div>
                )}

                {/* Staff/Tier: type + priority (rule: show only canCreateForCustomer) */}
                {canCreateForCustomer && (
                  <>
                    <div className="mt-6 grid gap-6 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="type">ประเภทปัญหา *</Label>
                        <Select required value={selectedType} onValueChange={setSelectedType}>
                          <SelectTrigger id="type">
                            <SelectValue placeholder="เลือกประเภท" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(types as any).map(([key, config]: any) => (
                              <SelectItem key={key} value={key}>
                                {config.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="priority">ความสำคัญ *</Label>
                        <Select required value={selectedPriority} onValueChange={setSelectedPriority}>
                          <SelectTrigger id="priority">
                            <SelectValue placeholder="เลือกความสำคัญ" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(priorities as any).map(([key, config]: any) => (
                              <SelectItem key={key} value={key}>
                                {config.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {selectedType === 'security_incident' && (
                      <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
                        <div className="flex gap-3">
                          <span className="text-red-600">🛡️</span>
                          <div>
                            <h4 className="text-sm font-semibold text-red-900">Security Incident</h4>
                            <p className="text-xs text-red-700 mt-1">
                              เคสนี้จะถูกส่งต่อให้ทีม Security (Tier 3) โดยอัตโนมัติ และมี SLA ที่เข้มงวดกว่าปกติ
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}

                <div className="space-y-2 mt-6">
                  <Label htmlFor="title">หัวเรื่อง *</Label>
                  <Input id="title" required placeholder="ระบุหัวข้อปัญหา" />
                </div>

                <div className="space-y-2 mt-6">
                  <Label htmlFor="description">รายละเอียด *</Label>
                  <RichTextEditor value={description} onChange={setDescription} placeholder="อธิบายรายละเอียดปัญหาให้ชัดเจน..." />
                </div>

                <div className="space-y-2 mt-6">
                  <Label>ป้ายกำกับ (Hashtags)</Label>
                  <TagInput tags={tags} onTagsChange={setTags} placeholder="พิมพ์และกด Enter เพื่อเพิ่ม Tag" />
                  <p className="text-xs text-gray-500">เช่น #ด่วน #Printer #Network</p>
                </div>

                <div className="space-y-2 mt-6">
                  <Label>แนบไฟล์/รูปภาพ</Label>
                  <ImageUploader images={attachments} onImagesChange={setAttachments} maxImages={5} />
                  <p className="text-xs text-gray-500">รองรับไฟล์รูปภาพ (JPG, PNG) และเอกสาร (PDF, DOCX) ขนาดไม่เกิน 5MB</p>
                </div>

                {/* Staff/Tier: incidentDate */}
                {canCreateForCustomer && (
                  <div className="space-y-4 mt-6 pt-6 border-t">
                    <div className="space-y-2">
                      <Label htmlFor="incidentDate">วันที่เกิดปัญหา (ย้อนหลังได้)</Label>
                      <div className="flex gap-4 items-center">
                        <Input
                          id="incidentDate"
                          type="datetime-local"
                          className="w-auto"
                          value={incidentDate}
                          onChange={(e) => setIncidentDate(e.target.value)}
                        />
                        <p className="text-xs text-gray-500 flex-1">
                          ระบุเวลาที่ลูกค้าแจ้งเข้ามาจริง (กรณีบันทึกย้อนหลัง)
                          <br />
                          หากไม่ระบุ ระบบจะใช้วันที่ปัจจุบัน
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* ===================== Actions ===================== */}
          <div className="mt-6 flex flex-col-reverse gap-4 sm:flex-row sm:justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={() => (canViewAllTickets ? onNavigate('/admin') : onNavigate('/'))}
            >
              ยกเลิก
            </Button>

            {canCreateForCustomer ? (
              <div className="flex flex-col gap-2 sm:flex-row">
                {isUserStaff && (
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'กำลังบันทึก...' : 'ส่งงาน'}
                  </Button>
                )}

                {isUserTier1 && (
                  <>
                    <Button
                      type="button"
                      variant="outline"
                      className="border-green-600 text-green-600 hover:bg-green-50"
                      onClick={handleSolveAndClose}
                      disabled={isSubmitting}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      {isSubmitting ? 'กำลังบันทึก...' : 'แก้ไขและปิดเคส'}
                    </Button>

                    <Button
                      type="button"
                      variant="secondary"
                      className="bg-blue-100 text-blue-800 hover:bg-blue-200"
                      onClick={handleSaveAndAccept}
                      disabled={isSubmitting}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกและรับเคส'}
                    </Button>

                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกเคส'}
                    </Button>
                  </>
                )}
              </div>
            ) : (
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'กำลังส่งข้อมูล...' : 'ส่งเคส'}
              </Button>
            )}
          </div>
        </form>
      </div>

      {/* ===================== Close Ticket Modal (Tier1) ===================== */}
      <Dialog open={showCloseTicketModal} onOpenChange={setShowCloseTicketModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              แก้ไขและปิดเคส
            </DialogTitle>
            <DialogDescription>บันทึกวิธีแก้ไขและปิดเคสทันที (ไม่ต้องผ่านกระบวนการรับเคส)</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="resolvedAt">วันที่และเวลาที่แก้ไขเสร็จ *</Label>
                <Input
                  id="resolvedAt"
                  type="datetime-local"
                  value={resolvedAt}
                  onChange={(e) => setResolvedAt(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="resolvedBy">ผู้แก้ไข (Resolved By) *</Label>
                <Select required value={resolvedBy} onValueChange={setResolvedBy}>
                  <SelectTrigger id="resolvedBy">
                    <SelectValue placeholder="เลือกผู้แก้ไข..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableStaff.map((s: any) => (
                      <SelectItem key={s.id} value={s.fullName}>
                        {s.fullName} {s.tier ? `(Tier ${s.tier})` : `(${s.role})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="solution">วิธีแก้ไขปัญหา *</Label>
              <Textarea
                id="solution"
                placeholder="ระบุสิ่งที่ทำเพื่อแก้ไขปัญหา..."
                className="min-h-[100px]"
                value={solution}
                onChange={(e) => setSolution(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="closureNotes">หมายเหตุ (ถ้ามี)</Label>
              <Textarea
                id="closureNotes"
                placeholder="ข้อมูลเพิ่มเติม..."
                value={closureNotes}
                onChange={(e) => setClosureNotes(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setShowCloseTicketModal(false)}>
              ยกเลิก
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={handleConfirmSolveAndClose} disabled={isSubmitting}>
              {isSubmitting ? 'กำลังบันทึก...' : 'ยืนยันปิดเคส'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===================== Project Selector Modal ===================== */}
      <ProjectSelectorModal
        isOpen={showProjectModal}
        onClose={() => setShowProjectModal(false)}
        onSelect={(projectId) => handleProjectSelect(projectId)}
        enableProductVerification={false} // ✅ product อยู่ใน dropdown ฟอร์ม (กฏเหล็ก)
      />
    </div>
  );
}
