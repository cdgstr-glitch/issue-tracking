import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { ArrowLeft, Mail, CheckCircle2 } from 'lucide-react';
import imgImage4 from '../assets/e6673285d07284ae5db1591edc6cbb88211b3d47.png';
import imgImage5 from '../assets/78ed83eba43431c0c08c68662a3249b4695d24ea.png';
import cdgsLogo from '../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png';

/**
 * 🎨 CDGS Forgot Password Page
 * 
 * ✨ Features:
 *    - ✅ Email validation
 *    - ✅ Success state with instructions
 *    - ✅ Back to login link
 *    - ✅ Consistent design with LoginPage
 *    - ✅ Responsive layout
 */

interface ForgotPasswordPageProps {
  onBackToLogin: () => void;
}

// 3D Illustration Component - Same as LoginPage
function IllustrationPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
      <div 
        className="absolute inset-0"
        style={{ 
          background: 'radial-gradient(circle, rgb(46, 11, 159) 0%, rgb(72, 21, 236) 26%, rgb(59, 16, 198) 45%, rgb(30, 5, 111) 63%, rgb(20, 0, 85) 82%, rgb(19, 0, 81) 100%)'
        }} 
      />
      
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[72%] max-w-[620px] h-auto aspect-[772/746]">
        <svg className="block w-full h-full" fill="none" preserveAspectRatio="xMidYMid meet" viewBox="0 0 772 746">
          <circle cx="399" cy="373" r="371.5" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="32.5" cy="406.5" r="31" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="619.5" cy="72.5" r="31" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
        </svg>
      </div>

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[68%] max-w-[560px] aspect-square">
        <div className="w-full h-full flex items-center justify-center">
          <div className="rotate-[81.215deg] w-full h-full">
            <img 
              alt="Analytics Dashboard Illustration" 
              className="w-full h-full object-contain opacity-[0.73] pointer-events-none mix-blend-screen" 
              src={imgImage4} 
              style={{ background: 'transparent' }}
            />
          </div>
        </div>
      </div>

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[68%] max-w-[614px] aspect-[767/695]">
        <img 
          alt="Issue Tracking Platform" 
          className="w-full h-full object-contain pointer-events-none" 
          src={imgImage5} 
          style={{ background: 'transparent' }}
        />
      </div>
    </div>
  );
}
export default function ForgotPasswordPage({ onBackToLogin }: ForgotPasswordPageProps) {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('กรุณากรอกอีเมลที่ถูกต้อง');
      setIsLoading(false);
      return;
    }

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setIsSuccess(true);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#fafbff]">
      {/* Left Panel - 3D Illustration (Desktop Only) */}
      <IllustrationPanel />

      {/* Right Panel - Forgot Password Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-4 lg:p-8">
        <div className="w-full max-w-[488px]">
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <h1 className="text-[#101828] mb-3 text-2xl lg:text-[32px]">
              Application Support Center
            </h1>
            <p className="text-[#4a5565] text-sm lg:text-base leading-tight">
              แจ้งปัญหาระบบงานได้ที่นี่ ทีมงานพร้อมช่วยดูแลทุกระบบที่คุณใช้งาน
            </p>
          </div>

          {/* Forgot Password Card */}
          <Card className="shadow-xl border-gray-200 rounded-[16.4px]">
            <CardHeader className="space-y-1 px-6 pt-10 pb-3">
              <CardTitle className="text-base">ลืมรหัสผ่าน</CardTitle>
              <CardDescription className="row-title-01 text-base text-neutral-500">
                {isSuccess 
                  ? 'ตรวจสอบอีเมลของคุณเพื่อรีเซ็ตรหัสผ่าน'
                  : 'กรอกอีเมลของคุณเพื่อรับลิงก์รีเซ็ตรหัสผ่าน'}
              </CardDescription>
            </CardHeader>
            <CardContent className="px-6 pb-10">
              {!isSuccess ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {error && (
                    <Alert variant="destructive" className="mb-3">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  {/* Email Field */}
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm text-neutral-950">
                      อีเมล
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6A7282]" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        autoComplete="email"
                        autoFocus
                        className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400 pl-10"
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    className="w-full h-9 bg-neutral-900 hover:bg-neutral-800 text-neutral-50 rounded-[6.8px] text-sm"
                    disabled={isLoading}
                  >
                    {isLoading ? 'กำลังส่งอีเมล...' : 'ส่งลิงก์รีเซ็ตรหัสผ่าน'}
                  </Button>

                  {/* Back to Login */}
                  <div className="text-center">
                    <button
                      type="button"
                      onClick={onBackToLogin}
                      className="inline-flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 hover:underline transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      กลับไปหน้าเข้าสู่ระบบ
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                  {/* Success Message */}
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-8 h-8 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-lg text-neutral-950 mb-2">ส่งอีเมลสำเร็จ!</h3>
                      <p className="text-sm text-[#6a7282]">
                        เราได้ส่งลิงก์สำหรับรีเซ็ตรหัสผ่านไปที่
                      </p>
                      <p className="text-sm text-neutral-950 mt-1">
                        {email}
                      </p>
                    </div>
                  </div>

                  {/* Instructions */}
                  <Alert className="bg-blue-50 border-blue-200">
                    <AlertDescription className="text-sm text-blue-800">
                      <strong>ขั้นตอนต่อไป:</strong>
                      <ol className="list-decimal list-inside mt-2 space-y-1">
                        <li>ตรวจสอบกล่องจดหมายของคุณ</li>
                        <li>คลิกลิงก์ในอีเมล (ลิงก์จะหมดอายุใน 24 ชั่วโมง)</li>
                        <li>สร้างรหัสผ่านใหม่</li>
                      </ol>
                    </AlertDescription>
                  </Alert>

                  {/* Resend Link */}
                  <div className="text-center text-sm text-[#6a7282]">
                    ไม่ได้รับอีเมล?{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setIsSuccess(false);
                        setEmail('');
                      }}
                      className="text-blue-600 hover:text-blue-700 hover:underline transition-colors"
                    >
                      ส่งอีกครั้ง
                    </button>
                  </div>

                  {/* Back to Login */}
                  <div className="text-center pt-4 border-t border-gray-200">
                    <button
                      type="button"
                      onClick={onBackToLogin}
                      className="inline-flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 hover:underline transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      กลับไปหน้าเข้าสู่ระบบ
                    </button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="text-center mt-8 space-y-4">
            <p className="text-sm text-[#6a7282]">© 2025 CDGS. All rights reserved.</p>
            <p className="text-sm text-[#6a7282]">Application Support Center</p>
          </div>
        </div>
      </div>
    </div>
  );
}