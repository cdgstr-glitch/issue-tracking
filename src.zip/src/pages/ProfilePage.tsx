import { ArrowLeft, User, Mail, Phone, Building2, Shield, Briefcase, Lock, CircleCheck } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { useAuth } from '../contexts/AuthContext';

interface ProfilePageProps {
  onNavigate?: (path: string) => void;
}
export default function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, customer, logout, activeRole } = useAuth();
  
  const currentUser = customer || user;
  const currentRole = customer ? 'customer' : activeRole;
  
  const handleBack = () => {
    if (currentRole === 'customer') {
      onNavigate?.('/');
    } else if (currentRole === 'staff') {
      onNavigate?.('/');
    } else {
      onNavigate?.('/admin');
    }
  };

  const getRoleDisplay = (role: string) => {
    const roleMap: Record<string, string> = {
      customer: 'ลูกค้า',
      staff: 'เจ้าหน้าที่',
      tier1: 'Tier 1',
      tier2: 'Tier 2',
      tier3: 'Tier 3',
      admin: 'ผู้ดูแลระบบ'
    };
    return roleMap[role] || role;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <Button variant="ghost" onClick={handleBack} className="mb-4 gap-2">
        <ArrowLeft className="h-4 w-4" />
        กลับ
      </Button>

      <div className="mb-6">
        <h1 className="mb-2">โปรไฟล์</h1>
        <p className="text-gray-600">จัดการข้อมูลส่วนตัวและการตั้งค่าบัญชี</p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-5 h-5" />
                <div>
                  <CardTitle>ข้อมูลส่วนตัว</CardTitle>
                  <CardDescription>ข้อมูลพื้นฐานของคุณในระบบ</CardDescription>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <User className="w-4 h-4 mr-2" />
                แก้ไข
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm text-gray-600 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  ชื่อ-นามสกุล
                </label>
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-neutral-950">{currentUser?.fullName || 'ไม่ระบุ'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-600 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  อีเมล
                  <span className="text-xs text-blue-600 font-medium">(คีย์หลัก)</span>
                </label>
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-neutral-950">{currentUser?.email || 'ไม่ระบุ'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-600 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  เบอร์โทรศัพท์
                </label>
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-neutral-950">{currentUser?.phone || 'ไม่ระบุ'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-600 flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  หน่วยงาน/สังกัด
                </label>
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-neutral-950">{currentUser?.department || 'ไม่ระบุ'}</p>
                </div>
              </div>

              {user && (
                <>
                  <div className="space-y-2">
                    <label className="text-sm text-gray-600 flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      ระดับ Support
                    </label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">{getRoleDisplay(currentRole)}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-600 flex items-center gap-2">
                      <Briefcase className="w-4 h-4" />
                      โครงการที่รับผิดชอบ
                    </label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">{user?.projectIds?.join(', ') || 'ไม่ระบุ'}</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              จัดการรหัสผ่าน
            </CardTitle>
            <CardDescription>เปลี่ยนรหัสผ่านหรือรีเซ็ตรหัสผ่านผ่านทางอีเมล</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2 text-green-800">
                <CircleCheck className="w-4 h-4" />
                <span className="text-sm font-medium">คุณมีรหัสผ่านแล้ว</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button variant="outline" className="flex-1">
                <Lock className="w-4 h-4 mr-2" />
                เปลี่ยนรหัสผ่าน
              </Button>
              <Button variant="outline" className="flex-1 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700">
                <Mail className="w-4 h-4 mr-2" />
                ลืมรหัสผ่าน? รีเซ็ตทางอีเมล
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="text-red-900">ออกจากระบบ</CardTitle>
            <CardDescription>ออกจากระบบและกลับสู่หน้าเข้าสู่ระบบ</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="destructive" onClick={logout} className="w-full sm:w-auto">
              ออกจากระบบ
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
