import { useState, useEffect } from 'react';
import { formatDate, getRoleDisplayName } from '../lib/utils';
import { extractHashtags, removeHashtags } from '../lib/hashtagUtils';
import { EmailPreviewModal } from '../components/EmailPreviewModal';
import { toast } from 'sonner@2.0.3';
import { useAuth } from '../contexts/AuthContext';
import { TicketActions } from '../components/TicketActions';
import { db } from '../lib/mockDb/client';
import type { HydratedTicket } from '../lib/mockDb/client'; // ✅ Use DB client
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ArrowLeft, Mail } from 'lucide-react';
import { ChannelBadge } from '../components/ChannelBadge';
import { StatusBadge } from '../components/StatusBadge';
import { PriorityBadge } from '../components/PriorityBadge';
import { Badge } from '../components/ui/badge';
import { AttachmentGallery } from '../components/AttachmentGallery';
import { TicketTimeline } from '../components/TicketTimeline';
import { CommentSection } from '../components/comments/CommentSection';
import { getAssigneeDisplayName } from '../lib/ticketUtils'; // ✅ Use ticketUtils

interface StaffTicketDetailPageProps {
  ticketId: string;
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}
export default function StaffTicketDetailPage({ ticketId, onNavigate, onBackToMenu }: StaffTicketDetailPageProps) {
  const { user, logout, isAuthenticated } = useAuth();
  
  // ✅ Fetch from DB
  const [currentTicket, setCurrentTicket] = useState<HydratedTicket | null>(() => db.tickets.getHydratedById(ticketId));

  const [reply, setReply] = useState('');
  const [isInternal, setIsInternal] = useState(false);
  const [emailPreviewOpen, setEmailPreviewOpen] = useState(false);
  const [emailPreviewType, setEmailPreviewType] = useState<'customer' | 'staff'>('customer');

  useEffect(() => {
    const updatedTicket = db.tickets.getHydratedById(ticketId);
    if(updatedTicket) {
      setCurrentTicket(updatedTicket);
    }
  }, [ticketId]);

  if (!currentTicket) {
      return <div>Ticket not found</div>
  }

  // ✅ SSoT: organization lookup จาก ticket.organizationId โดยตรง (FK หลัก)
  // ไม่ผ่าน project เพราะ projectId nullable — org มีอยู่แม้ project null
  const organization = currentTicket.organizationId
    ? db.organizations.getById(currentTicket.organizationId)
    : null;

  // ✅ SSoT: project lookup จาก ticket.projectId (nullable FK)
  const project = currentTicket.projectId
    ? db.projects.getById(currentTicket.projectId)
    : null;

  // ✅ SSoT: products จาก HydratedTicket.products (pivot ticket_products via hydrateTicketRow)
  // ไม่มี productValue field ใน Ticket schema — ใช้ products[] เท่านั้น
  const ticketProducts: any[] = (currentTicket as any).products ?? [];

  // Redirect to home when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      console.log('✅ User logged out, navigating to /');
      onNavigate('/');
    }
  }, [isAuthenticated, onNavigate]);

  const handleOpenEmailPreview = (type: 'customer' | 'staff') => {
    setEmailPreviewType(type);
    setEmailPreviewOpen(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        onClick={() => onNavigate('/track')}
        className="gap-2 mb-4"
      >
        <ArrowLeft className="h-4 w-4" />
        กลับรายการเคส
      </Button>

      {/* Page Header */}
      <div className="mb-6">
        <h1 className="mb-2">ดูรายละเอียดเคสลูกค้า</h1>
        <p className="text-blue-600">{currentTicket.ticketNumber}</p>
      </div>

      {/* Ticket Info Card */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap justify-between mb-2">
                <div className="flex items-baseline gap-2 flex-wrap flex-1">
                  <span className="text-gray-600">หัวเรื่อง</span>
                  <CardTitle className="m-0">{removeHashtags(currentTicket.title)}</CardTitle>
                </div>
                {/* Channel Badge - ด้านขวาของหัวเรื่อง */}
                <ChannelBadge channel={currentTicket.channel} />
              </div>
              {/* Display hashtags as badges */}
              {extractHashtags(currentTicket.title).length > 0 && (
                <div className="flex gap-1.5 flex-wrap mb-2">
                  {extractHashtags(currentTicket.title).map((hashtag, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-700"
                    >
                      {hashtag}
                    </span>
                  ))}
                </div>
              )}
              <p className="mt-2 text-sm text-gray-600">
                สร้างเมื่อ {formatDate(currentTicket.createdAt)}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <StatusBadge status={currentTicket.status} />
              <PriorityBadge priority={currentTicket.priority} />
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="mb-2">รายละเอียด</h3>
            <div 
              className="text-gray-700 prose prose-sm max-w-none"
              dangerouslySetInnerHTML={{ __html: currentTicket.description }}
            />
          </div>

          <div className="grid gap-4 border-t pt-6 md:grid-cols-2">
            {/* แสดงชื่อลูกค้า */}
            {currentTicket.customerName && (
              <div>
                <p className="text-sm text-gray-600">ชื่อลูกค้า</p>
                <p>{currentTicket.customerName}</p>
              </div>
            )}
            {/* แสดงชื่อเจ้าหน้าที่ที่แจ้งแทนลูกค้า */}
            {currentTicket.createdByType === 'staff_on_behalf' && (() => {
              // ✅ SSoT: lookup staff name จาก createdByUserId → users table
              const createdByUser = (currentTicket as any).createdByUserId
                ? db.users.getById((currentTicket as any).createdByUserId)
                : null;
              return (
                <div>
                  <p className="text-sm text-gray-600">แจ้งโดยเจ้าหน้าที่</p>
                  <p>{createdByUser?.fullName || 'เจ้าหน้าที่'}</p>
                </div>
              );
            })()}
            
            {/* ✅ SSoT: organization จาก ticket.organizationId — แสดงแม้ project null */}
            {organization && (
              <div>
                <p className="text-sm text-gray-600">หน่วยงานลูกค้า</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="text-xs font-semibold">
                    {organization.organizationShortName}
                  </Badge>
                  <span className="text-sm text-gray-700">{organization.organizationName}</span>
                </div>
              </div>
            )}
            
            {/* ✅ SSoT: project จาก ticket.projectId (nullable FK) */}
            {project && (
              <div>
                <p className="text-sm text-gray-600">โครงการ</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium text-gray-600">{project.projectCode}</span>
                  <span className="text-sm text-gray-700">{project.projectName}</span>
                </div>
              </div>
            )}
            
            {/* ✅ SSoT: products จาก HydratedTicket.products (pivot ticket_products) */}
            {ticketProducts.length > 0 && (
              <div className="md:col-span-2">
                <p className="text-sm text-gray-600 mb-1">สินค้า/ผลิตภัณฑ์</p>
                <div className="flex flex-col gap-2">
                  {ticketProducts.map((p: any) => (
                    <div key={p.id} className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="font-medium text-blue-900">{p.productName}</p>
                      {p.description && (
                        <p className="text-xs text-blue-700 mt-0.5">{p.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <p className="text-sm text-gray-600">หมวดหมู่</p>
              <p>{currentTicket.category}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">ประเภท</p>
              <p className="capitalize">{currentTicket.type.replace('_', ' ')}</p>
            </div>
            {currentTicket.assignedTo && (
              <div>
                <p className="text-sm text-gray-600">มอบหมายให้</p>
                <p>{getAssigneeDisplayName(currentTicket)}</p>
              </div>
            )}
            <div>
              <p className="text-sm text-gray-600">กำหนดเสร็จ</p>
              <p>{formatDate(currentTicket.dueDate)}</p>
            </div>
          </div>

          {/* ✅ เพิ่มส่วนแสดงไฟล์แนบ */}
          {currentTicket.attachments && currentTicket.attachments.length > 0 && (
            <div className="border-t pt-6">
              <AttachmentGallery attachments={currentTicket.attachments} showDownload={true} />
            </div>
          )}
        </CardContent>
      </Card>

      {/* ✅ Ticket Actions - รับเคส, ส่งต่อ, ส่งกลับ T1, ปิดเคส, หยุดชั่วคราว */}
      {user && (
        <div className="mb-6">
          <TicketActions
            ticket={currentTicket}
            userRole={user.role as 'tier1' | 'tier2' | 'tier3' | 'staff' | 'admin'}
            userId={user.id}
            onUpdate={(updates) => {
              setCurrentTicket({ ...currentTicket, ...updates });
              toast.success('อัปเดตเคสสำเร็จ');
            }}
          />
        </div>
      )}

      {/* Timeline */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>ไทม์ไลน์</CardTitle>
        </CardHeader>
        <CardContent>
        <TicketTimeline
          events={db.timeline.getByTicketId(currentTicket.id)}
          userRole="staff"
          ticket={currentTicket}
        />

        </CardContent>
      </Card>

      {/* ✅ Comments Section - ใช้ CommentSection component */}
      <CommentSection
        comments={currentTicket.comments}
        onAddComment={(commentText, isInternal) => {
          const newComment = {
            id: `comment-${Date.now()}`,
            ticketId: currentTicket.id,
            author: user?.fullName || 'เจ้าหน้าที่รับแจ้ง',
            authorRole: 'staff',
            content: commentText,
            isInternal: isInternal,
            createdAt: new Date()
          };
          
          // อัปเดต currentTicket โดยเพิ่ม comment ใหม่
          setCurrentTicket({
            ...currentTicket,
            comments: [...currentTicket.comments, newComment],
            updatedAt: new Date()
          });
        }}
        formatDate={formatDate}
        currentUserName={user?.fullName || 'เจ้าหน้าที่รับแจ้ง'}
        currentUserRole="staff"
        showInternalToggle={true}
        title="ความคิดเห็นและการตอบกลับ"
        placeholder="พิมพ์ข้อความของคุณที่นี่..."
        submitButtonText="ส่งการตอบกลับ"
        readOnly={currentTicket.status === 'closed'}
      />

      {/* Email Preview Card */}
      <Card className="mb-6 mt-6">
        <CardHeader>
          <CardTitle>ตัวอย่างการแจ้งเตือนทางอีเมล</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button 
              variant="outline" 
              className="flex-1 justify-start gap-2"
              onClick={() => handleOpenEmailPreview('customer')}
              disabled={isInternal} // Disable เมื่อเป็น Internal Comment
            >
              <Mail className="h-4 w-4" />
              ตัวอย่างอีเมลแจ้งตอบกลับส่งถึงลูกค้า
            </Button>
            <Button 
              variant="outline" 
              className="flex-1 justify-start gap-2"
              onClick={() => handleOpenEmailPreview('staff')}
            >
              <Mail className="h-4 w-4" />
              ตัวอย่างอีเลแจ้งตอบกลับส่งไปยังเจ้าหน้าที่ที่รับเคส
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Closed Ticket Notice */}
      {(currentTicket.status === 'closed' || currentTicket.status === 'resolved') && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-6 text-center">
            <p className="text-green-800">
              ✓ เคสนี้ได้รับการแก้ไขแล้ว
            </p>
          </CardContent>
        </Card>
      )}

      {/* Email Preview Modal */}
      <EmailPreviewModal 
        isOpen={emailPreviewOpen}
        onClose={() => setEmailPreviewOpen(false)}
        type={emailPreviewType}
        ticket={currentTicket}
        assignedBy={user}
        assignedTo={user}
      />
    </div>
  );
}