import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Plus, Clock, CheckCircle, FileText, User, LogOut, Info, Search, Phone, Mail, MessageCircle, Bell, HelpCircle } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import { useAuth } from '../contexts/AuthContext';
import { getRoleDisplayName } from '../lib/utils';
import { Badge } from '../components/ui/badge';
import logoImage from '../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png';
import { Header } from '../components/layout/Header';

interface StaffHomePageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}
export default function StaffHomePage({ onNavigate, onBackToMenu }: StaffHomePageProps) {
  const { user, logout, isAuthenticated } = useAuth();
  const [notificationOpen, setNotificationOpen] = useState(false);

  const handleLogout = () => {
    console.log('🚪 handleLogout called from StaffHomePage');
    logout();
  };

  // Redirect to home when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      console.log('✅ User logged out, navigating to /');
      onNavigate('/');
    }
  }, [isAuthenticated, onNavigate]);

  // Mock notifications data for staff
  const notifications = [
    { id: '1', title: 'เคสใหม่จากลูกค้า', message: 'มีเคสใหม่เข้ามาทางอีเมล รอการบันทึก', time: '5 นาทีที่แล้ว', isNew: true, ticketId: 's1' },
    { id: '2', title: 'ทีมสนับสนุนตอบกลับแล้ว', message: 'เคส #1234 ได้รับการแก้ไขเสร็จสิ้น', time: '1 ชั่วโมงที่แล้ว', isNew: true, ticketId: 's2' },
    { id: '3', title: 'ลูกค้าโทรสอบถาม', message: 'ลูกค้าติดต่อสอบถามสถานะเคส #1230', time: '2 ชั่วโมงที่แล้ว', isNew: false, ticketId: 's3' },
  ];

  const unreadCount = notifications.filter(n => n.isNew).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* ✅ ใช้ Header component */}
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'staff'
        }}
        onNavigate={onNavigate}
        onInformationClick={onBackToMenu}
        currentPath="/"
        showSearch={false}
      />

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="mb-4 text-3xl sm:text-4xl md:text-5xl lg:text-6xl">
            ยินดีต้อนรับสู่ CDGS Issue Tracking
          </h1>
          <p className="mb-8 text-lg text-gray-600 md:text-xl">
            แพลตฟอร์มสนับสนุนระดับองค์กร ส่งปัญหาของคุณ ติดตามความคืบหน้า และรับความช่วยเหลือจากทีมผู้เชี่ยวชาญของเราผ่านทุกช่องทาง
          </p>
          <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button size="lg" onClick={() => onNavigate('/create')} className="text-base">
              <Plus className="mr-2 h-5 w-5" />
              บันทึกเคสแทนลูกค้า
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => onNavigate('/track')} 
              className="text-base border-blue-300 text-blue-700 hover:bg-blue-50"
            >
              <Search className="mr-2 h-5 w-5" />
              ติดตามเคสที่บันทึกแทนลูกค้า
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works - Staff Section */}
      <section className="container mx-auto px-4 py-12">
        <h2 className="mb-8 text-center">วิธีการใช้งาน</h2>
        <div>
          <h3 className="mb-4 text-center text-xl">สำหรับเจ้าหน้าที่</h3>
            <div className="grid gap-6 md:grid-cols-5">
              <Card className="border-blue-200 bg-blue-50">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md">
                    1
                  </div>
                  <CardTitle className="text-blue-900">รับเคส</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-blue-800">
                    รับเรื่องจากลูกค้าผ่านอีเมล, Line, โทรศัพท์
                  </p>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-purple-50">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md">
                    2
                  </div>
                  <CardTitle className="text-purple-900">บันทึกเคส</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-purple-800">
                    กรอกข้อมูลลูกค้าและรายละเอียดเคสในระบบ
                  </p>
                </CardContent>
              </Card>

              <Card className="border-indigo-200 bg-indigo-50">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md">
                    3
                  </div>
                  <CardTitle className="text-indigo-900">ส่งต่อ Tier 1</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-indigo-800">
                    ระบบส่งเคสไปยังทีม Tier 1 อัตโนมัติ
                  </p>
                </CardContent>
              </Card>

              <Card className="border-orange-200 bg-orange-50">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-md">
                    4
                  </div>
                  <CardTitle className="text-orange-900">รอตอบกลับ</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-orange-800">
                    รอทีม Tier 1 ตรวจสอบและแก้ไขปัญหา
                  </p>
                </CardContent>
              </Card>

              <Card className="border-green-200 bg-green-50">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-green-500 to-green-600 text-white shadow-md">
                    5
                  </div>
                  <CardTitle className="text-green-900">ติดตามงาน</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-green-800">
                    ตรวจสอบสถานะและแจ้งผลกลับให้ลูกค้า
                  </p>
                </CardContent>
              </Card>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => onNavigate('/staff-journey')}
          >
            ดูรายละเอียดขั้นตอนทั้งหมด
          </Button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="container mx-auto px-4 py-12">
        <Card className="bg-blue-50">
          <CardContent className="p-8 text-center">
            <HelpCircle className="mx-auto mb-4 h-12 w-12 text-blue-600" />
            <h2 className="mb-2">ต้องการความช่วยเหลือ?</h2>
            <p className="mb-4 text-gray-600">
              ตรวจสอบคำถามที่พบบ่อยหรือติดต่อทีมสนับสนุนของเรา
            </p>
            <Button variant="outline" className="bg-white">
              ดูคำถามที่พบบ่อย
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white py-8">
        <div className="container mx-auto px-4 text-center text-sm text-gray-600">
          <p>© 2024 CDGS Issue Tracking Platform. สงวนลิขสิทธิ์</p>
          <p className="mt-2">การสนับสนุน IT ระดับองค์กร | เปิดบริการ 24/7</p>
        </div>
      </footer>
    </div>
  );
}