import { useState } from 'react';
import { db } from '../lib/mockDb/client';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Eye, EyeOff, ArrowLeft, CheckCircle2, User, Mail, Building2, Check } from 'lucide-react';
import imgImage4 from '../assets/e6673285d07284ae5db1591edc6cbb88211b3d47.png';
import imgImage5 from '../assets/78ed83eba43431c0c08c68662a3249b4695d24ea.png';
import cdgsLogo from '../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png';

/**
 * 🎨 CDGS Register Page
 * 
 * ✨ Features:
 *    - ✅ Full registration form
 *    - ✅ Password strength validation
 *    - ✅ Show/hide password
 *    - ✅ Terms & Conditions checkbox
 *    - ✅ Success state
 *    - ✅ Back to login link
 *    - ✅ Responsive layout
 */

interface RegisterPageProps {
  onBackToLogin: () => void;
}

// 3D Illustration Component - Same as LoginPage
function IllustrationPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
      <div 
        className="absolute inset-0"
        style={{ 
          background: 'radial-gradient(circle, rgb(46, 11, 159) 0%, rgb(72, 21, 236) 26%, rgb(59, 16, 198) 45%, rgb(30, 5, 111) 63%, rgb(20, 0, 85) 82%, rgb(19, 0, 81) 100%)'
        }} 
      />
      
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[72%] max-w-[620px] h-auto aspect-[772/746]">
        <svg className="block w-full h-full" fill="none" preserveAspectRatio="xMidYMid meet" viewBox="0 0 772 746">
          <circle cx="399" cy="373" r="371.5" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="32.5" cy="406.5" r="31" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
          <circle cx="619.5" cy="72.5" r="31" stroke="#DFE3FC" strokeOpacity="0.8" strokeWidth="3" />
        </svg>
      </div>

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[68%] max-w-[560px] aspect-square">
        <div className="w-full h-full flex items-center justify-center">
          <div className="rotate-[81.215deg] w-full h-full">
            <img 
              alt="Analytics Dashboard Illustration" 
              className="w-full h-full object-contain opacity-[0.73] pointer-events-none mix-blend-screen" 
              src={imgImage4} 
              style={{ background: 'transparent' }}
            />
          </div>
        </div>
      </div>

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[68%] max-w-[614px] aspect-[767/695]">
        <img 
          alt="Issue Tracking Platform" 
          className="w-full h-full object-contain pointer-events-none" 
          src={imgImage5} 
          style={{ background: 'transparent' }}
        />
      </div>
    </div>
  );
}
export default function RegisterPage({ onBackToLogin }: RegisterPageProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    organization: '',
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const validateForm = () => {
    // Full name validation
    if (formData.fullName.trim().length < 2) {
      setError('กรุณากรอกชื่อ-นามสกุลที่ถูกต้อง');
      return false;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('กรุณากรอกอีเมลที่ถูกต้อง');
      return false;
    }

    // Username validation
    if (formData.username.length < 4) {
      setError('ชื่อผู้ใช้ต้องมีความยาวอย่างน้อย 4 ตัวอักษร');
      return false;
    }

    // Password validation
    if (formData.password.length < 8) {
      setError('รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษร');
      return false;
    }

    // Password match validation
    if (formData.password !== formData.confirmPassword) {
      setError('รหัสผ่านไม่ตรงกัน');
      return false;
    }

    // Terms validation
    if (!acceptTerms) {
      setError('กรุณายอมรับข้อกำหนดและเงื่อนไข');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check duplicate email
      const existingEmail = db.users.getAll().find(
        c => c.email?.toLowerCase() === formData.email.toLowerCase()
      );
      if (existingEmail) {
        throw new Error('อีเมลนี้ถูกใช้งานแล้ว');
      }

      // Check duplicate username
      const existingUser = db.users.getAll().find(
        c => c.username?.toLowerCase() === formData.username.toLowerCase()
      );
      if (existingUser) {
        throw new Error('ชื่อผู้ใช้นี้ถูกใช้งานแล้ว');
      }

      // Register
      db.users.add({
        fullName: formData.fullName,
        email: formData.email,
        username: formData.username,
        password: formData.password,
        department: formData.organization,
        role: 'customer' as any,
        primaryRole: 'customer' as any
      });

      setIsLoading(false);
      setIsSuccess(true);
    } catch (err: any) {
      setIsLoading(false);
      setError(err.message || 'เกิดข้อผิดพลาดในการลงทะเบียน');
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#fafbff]">
      {/* Left Panel - 3D Illustration (Desktop Only) */}
      <IllustrationPanel />

      {/* Right Panel - Register Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-4 lg:p-8">
        <div className="w-full max-w-[488px]">
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <h1 className="text-[#101828] mb-3 text-2xl lg:text-[32px]">
              Application Support Center
            </h1>
            <p className="text-[#4a5565] text-sm lg:text-base leading-tight">
              แจ้งปัญหาระบบงานได้ที่นี่ ทีมงานพร้อมช่วยดูแลทุกระบบที่คุณใช้งาน
            </p>
          </div>

          {/* Register Card */}
          <Card className="shadow-xl border-gray-200 rounded-[16.4px]">
            <CardHeader className="space-y-1 px-6 pt-10 pb-3">
              <CardTitle className="text-base">ลงทะเบียน</CardTitle>
              <CardDescription className="row-title-01 text-base text-neutral-500">
                {isSuccess 
                  ? 'ลงทะเบียนสำเร็จ!'
                  : 'สร้างบัญชีใหม่เพื่อเข้าใช้งานระบบ'}
              </CardDescription>
            </CardHeader>
            <CardContent className="px-6 pb-10">
              {!isSuccess ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {error && (
                    <Alert variant="destructive" className="mb-3">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  {/* Full Name Field */}
                  <div className="space-y-2">
                    <Label htmlFor="fullName" className="text-sm text-neutral-950">
                      ชื่อ-นามสกุล
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6A7282]" />
                      <Input
                        id="fullName"
                        name="fullName"
                        type="text"
                        placeholder="กรอกชื่อ-นามสกุล"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                        autoComplete="name"
                        autoFocus
                        className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400 pl-10"
                      />
                    </div>
                  </div>

                  {/* Email Field */}
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm text-neutral-950">
                      อีเมล
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6A7282]" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        autoComplete="email"
                        className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400 pl-10"
                      />
                    </div>
                  </div>

                  {/* Organization Field */}
                  <div className="space-y-2">
                    <Label htmlFor="organization" className="text-sm text-neutral-950">
                      หน่วยงาน/สังกัด
                    </Label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6A7282]" />
                      <Input
                        id="organization"
                        name="organization"
                        type="text"
                        placeholder="กรอกชื่อหน่วยงาน/สังกัด"
                        value={formData.organization}
                        onChange={handleChange}
                        required
                        autoComplete="organization"
                        className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400 pl-10"
                      />
                    </div>
                  </div>

                  {/* Username Field */}
                  <div className="space-y-2">
                    <Label htmlFor="username" className="text-sm text-neutral-950">
                      ชื่อผู้ใช้
                    </Label>
                    <Input
                      id="username"
                      name="username"
                      type="text"
                      placeholder="กรอกชื่อผู้ใช้"
                      value={formData.username}
                      onChange={handleChange}
                      required
                      autoComplete="username"
                      className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400"
                    />
                  </div>

                  {/* Password Field */}
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm text-neutral-950">
                      รหัสผ่าน
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="กรอกรหัสผ่าน (อย่างน้อย 8 ตัวอักษร)"
                        value={formData.password}
                        onChange={handleChange}
                        required
                        autoComplete="new-password"
                        className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6A7282] hover:text-gray-700 transition-colors"
                        aria-label={showPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Password Field */}
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword" className="text-sm text-neutral-950">
                      ยืนยันรหัสผ่าน
                    </Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="กรอกรหัสผ่านอีกครั้ง"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        required
                        autoComplete="new-password"
                        className="h-9 bg-[rgba(229,229,229,0.3)] border-neutral-200 rounded-[6.8px] text-base placeholder:text-neutral-400 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6A7282] hover:text-gray-700 transition-colors"
                        aria-label={showConfirmPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Terms & Conditions */}
                  <div className="flex items-start space-x-2 pt-2">
                    {/* Custom Checkbox */}
                    <button
                      type="button"
                      onClick={() => setAcceptTerms(!acceptTerms)}
                      className={`
                        mt-1 w-4 h-4 rounded flex items-center justify-center cursor-pointer
                        transition-all duration-200 flex-shrink-0
                        ${acceptTerms 
                          ? 'bg-blue-600 border-blue-600' 
                          : 'bg-white border-gray-300'
                        }
                        border hover:border-blue-400
                      `}
                      aria-label="ยอมรับข้อกำหนดและเงื่อนไข"
                      aria-checked={acceptTerms}
                      role="checkbox"
                    >
                      {acceptTerms && (
                        <Check className="w-3 h-3 text-white" strokeWidth={3} />
                      )}
                    </button>
                    
                    <label 
                      htmlFor="terms" 
                      className="text-sm text-[#6a7282] cursor-pointer"
                      onClick={() => setAcceptTerms(!acceptTerms)}
                    >
                      ฉันยอมรับ{' '}
                      <button
                        type="button"
                        className="text-blue-600 hover:text-blue-700 hover:underline"
                        onClick={(e) => {
                          e.stopPropagation();
                          alert('ข้อกำหนดและเงื่อนไขจะพร้อมใช้งานในเร็วๆ นี้');
                        }}
                      >
                        ข้อกำหนดและเงื่อนไข
                      </button>
                      {' '}และ{' '}
                      <button
                        type="button"
                        className="text-blue-600 hover:text-blue-700 hover:underline"
                        onClick={(e) => {
                          e.stopPropagation();
                          alert('นโยบายความเป็นส่วนตัวจะพร้อมใช้งานในเร็วๆ นี้');
                        }}
                      >
                        นโยบายความเป็นส่วนตัว
                      </button>
                    </label>
                  </div>

                  {/* Register Button */}
                  <Button
                    type="submit"
                    className="w-full h-9 bg-neutral-900 hover:bg-neutral-800 text-neutral-50 rounded-[6.8px] text-sm mt-6"
                    disabled={isLoading}
                  >
                    {isLoading ? 'กำลังลงทะเบียน...' : 'ลงทะเบียน'}
                  </Button>

                  {/* Already have account */}
                  <div className="text-center pt-4 border-t border-gray-200">
                    <p className="text-sm text-[#6a7282]">
                      มีบัญชีอยู่แล้ว?{' '}
                      <button
                        type="button"
                        onClick={onBackToLogin}
                        className="text-blue-600 hover:text-blue-700 hover:underline transition-colors"
                      >
                        เข้าสู่ระบบ
                      </button>
                    </p>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                  {/* Success Message */}
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-8 h-8 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-lg text-neutral-950 mb-2">ลงทะเบียนสำเร็จ!</h3>
                      <p className="text-sm text-[#6a7282]">
                        ยินดีต้อนรับสู่ Application Support Center
                      </p>
                      <p className="text-sm text-neutral-950 mt-1">
                        {formData.fullName}
                      </p>
                    </div>
                  </div>

                  {/* Next Steps */}
                  <Alert className="bg-blue-50 border-blue-200">
                    <AlertDescription className="text-sm text-blue-800">
                      <strong>ขั้นตอนต่อไป:</strong>
                      <ol className="list-decimal list-inside mt-2 space-y-1">
                        <li>ตรวจสอบอีเมลยืนยันที่ {formData.email}</li>
                        <li>คลิกลิงก์เพื่อยืนยันบัญชี</li>
                        <li>เข้าสู่ระบบและเริ่มใช้งาน</li>
                      </ol>
                    </AlertDescription>
                  </Alert>

                  {/* Back to Login Button */}
                  <Button
                    onClick={onBackToLogin}
                    className="w-full h-9 bg-neutral-900 hover:bg-neutral-800 text-neutral-50 rounded-[6.8px] text-sm"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    กลับไปหน้าเข้าสู่ระบบ
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="text-center mt-8 space-y-4">
            <p className="text-sm text-[#6a7282]">© 2025 CDGS. All rights reserved.</p>
            <p className="text-sm text-[#6a7282]">Application Support Center</p>
          </div>
        </div>
      </div>
    </div>
  );
}