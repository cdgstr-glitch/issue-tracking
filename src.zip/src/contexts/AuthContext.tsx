import React, { createContext, useContext, useState, useEffect } from 'react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { CustomerUser } from '../types'; // ✅ เพิ่ม CustomerUser type
import { validateMagicLinkToken } from '../lib/magicLink'; // ✅ เพิ่ม Magic Link

export type UserRole = 'customer' | 'staff' | 'tier1' | 'tier2' | 'tier3' | 'admin' | 'supervisor';

// Multi-Role Support: User can have multiple roles
export interface User {
  id: string;
  username: string;
  fullName: string; // ✅ เปลี่ยนจาก name เป็น fullName
  role: UserRole; // Deprecated: Keep for backward compatibility
  roles: UserRole[]; // NEW: Array of all roles
  primaryRole: UserRole; // NEW: Main role for display
  email?: string;
  phone?: string; // ✅ เบอร์โทรศัพท์
  department?: string; // ✅ หน่วยงาน/สังกัด
  tier?: 1 | 2 | 3;
  // Phase 1 & 4: Project และ Manager hierarchy
  projectIds?: string[]; // โครงการที่รับผิดชอบ (สำหรับ multi-project)
  managerId?: string; // หัวหน้าคนที่ 1
  seniorManagerId?: string; // หัวหน้าคนที่ 2
  managerEmail?: string; // อีเมลหัวหน้า (สำหรับแจ้งเตือน)
}

interface AuthContextType {
  user: User | null;
  customer: CustomerUser | null; // ✅ เพิ่ม: Customer ที่ login ผ่าน Magic Link
  activeRole: UserRole; // 🆕 บทบาทที่กำลังใช้งาน
  setActiveRole: (role: UserRole) => void; // 🆕 ฟังก์ชันสลับบทบาท
  login: (username: string, password: string) => Promise<boolean>;
  loginWithMagicLink: (token: string) => Promise<boolean>; // ✅ เพิ่ม: Login ด้วย Magic Link
  logout: () => void;
  isAuthenticated: boolean;
  isCustomer: boolean; // ✅ เพิ่ม: ตรวจสอบว่าเป็น Customer หรือไม่
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [customer, setCustomer] = useState<CustomerUser | null>(null); // ✅ เพิ่ม Customer state
  const [isLoading, setIsLoading] = useState(true);
  // 🔧 Initialize with empty string first, will be set after user loads
  const [activeRole, setActiveRoleState] = useState<UserRole>('customer');

  // Check for existing session on mount - use sessionStorage with Safari fallback
  useEffect(() => {
    try {
      const storedUser = sessionStorage.getItem('cdgs_user');
      const storedCustomer = sessionStorage.getItem('cdgs_customer'); // ✅ เพิ่ม: อ่าน Customer จาก session
      const storedActiveRole = sessionStorage.getItem('cdgs_active_role');
      
      // ✅ กู้คืน Customer session (ถ้ามี)
      if (storedCustomer) {
        try {
          const parsedCustomer = JSON.parse(storedCustomer);
          setCustomer(parsedCustomer);
          setActiveRoleState('customer');
        } catch (error) {
          console.error('Error parsing stored customer:', error);
          sessionStorage.removeItem('cdgs_customer');
        }
      }
      // กู้คืน Staff/Tier session (ถ้ามี)
      else if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser);
          setUser(parsedUser);
          
          // กู้คืน activeRole หรือใช้ primaryRole
          if (storedActiveRole && parsedUser.roles?.includes(storedActiveRole as UserRole)) {
            setActiveRoleState(storedActiveRole as UserRole);
          } else {
            setActiveRoleState(parsedUser.primaryRole || 'customer');
          }
        } catch (error) {
          console.error('Error parsing stored user:', error);
          sessionStorage.removeItem('cdgs_user');
          sessionStorage.removeItem('cdgs_active_role');
        }
      }
    } catch (error) {
      // Safari private mode blocks sessionStorage
      console.warn('sessionStorage not available:', error);
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    // Mock login - in production, this would call an API
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // ✅ Get user from database
    const users = db.users.getAll();
    const userRecord = users.find(u => u.username === username);
    
    if (userRecord) {
      // ✅ Source of Truth: Read directly from database
      // Database schema: { primaryRole: 'supervisor', roles: ['supervisor'], ... }
      const fullUser: User = {
        id: userRecord.id,
        username: userRecord.username,
        fullName: userRecord.fullName,
        email: userRecord.email,
        phone: userRecord.phone,
        department: userRecord.department,
        tier: userRecord.tier,
        projectIds: userRecord.projectIds,
        managerId: userRecord.managerId,
        seniorManagerId: userRecord.seniorManagerId,
        managerEmail: userRecord.managerEmail,
        // ✅ Critical: Read roles array from DB (Laravel will return this)
        roles: userRecord.roles || [userRecord.primaryRole || 'customer'],
        primaryRole: userRecord.primaryRole || 'customer',
        // ⚠️ Deprecated: Keep for backward compatibility
        role: userRecord.primaryRole || 'customer',
      };

      setUser(fullUser);
      setCustomer(null); // Clear customer session
      
      // Set activeRole to primaryRole (first role user will use)
      const initialRole = fullUser.primaryRole;
      setActiveRoleState(initialRole);
      
      try {
        sessionStorage.setItem('cdgs_user', JSON.stringify(fullUser));
        sessionStorage.setItem('cdgs_active_role', initialRole);
        sessionStorage.removeItem('cdgs_customer');
      } catch (error) {
        // Safari private mode - continue without storage
        console.warn('Cannot save to sessionStorage:', error);
      }
      return true;
    }

    return false;
  };

  // ✅ เพิ่ม: Login ด้วย Magic Link (สำหรับ Customer)
  const loginWithMagicLink = async (token: string): Promise<boolean> => {
    console.log('🔑 [AuthContext] loginWithMagicLink called');
    console.log('   - token:', token);
    
    try {
      // Simulate API delay
      console.log('⏳ Simulating API delay...');
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Validate token
      console.log('🔍 Validating token...');
      const result = validateMagicLinkToken(token);
      console.log('📊 Validation result:', result);
      
      if (!result.isValid || !result.userId) {
        console.error('❌ Invalid magic link:', result.error);
        return false;
      }
      
      console.log('✅ Token valid! Looking up customer in DB...');
      console.log('   - userId:', result.userId);
      console.log('   - email:', result.email);
      
      // ✅ ดึงข้อมูล Customer จาก DB
      const customers = db.users.getAll().filter(u => u.primaryRole === 'customer');
      const customerRecord = customers.find(c => c.email === result.email);
      
      if (!customerRecord) {
        console.error('❌ Customer not found in DB:', result.email);
        return false;
      }
      
      console.log('✅ Customer found in DB:', customerRecord);
      
      const mockCustomer: CustomerUser = {
        id: customerRecord.id,
        fullName: customerRecord.fullName,
        email: customerRecord.email,
        phone: customerRecord.phone,
        department: customerRecord.department,
        role: 'customer',
        createdAt: new Date(), // Mock date if not in DB user
      };
      
      console.log('👤 Customer session created:', mockCustomer);
      
      setCustomer(mockCustomer);
      setUser(null); // ✅ Clear staff/tier session
      setActiveRoleState('customer');
      
      console.log('💾 Saving to sessionStorage...');
      try {
        sessionStorage.setItem('cdgs_customer', JSON.stringify(mockCustomer));
        sessionStorage.setItem('cdgs_active_role', 'customer');
        sessionStorage.removeItem('cdgs_user'); // ✅ Clear staff session
        console.log('✅ Session saved successfully');
      } catch (error) {
        console.warn('⚠️ Cannot save to sessionStorage:', error);
      }
      
      console.log('✅ Login with magic link successful!');
      return true;
    } catch (error) {
      console.error('❌ Magic link login error:', error);
      return false;
    }
  };

  const logout = () => {
    console.log('🚪 Logout called');
    console.log('🔍 Before logout - User:', user);
    console.log('🔍 Before logout - Customer:', customer);
    console.log('🔍 Before logout - isAuthenticated:', !!(user || customer));
    setUser(null);
    setCustomer(null); // ✅ Clear customer
    setActiveRoleState('customer');
    try {
      sessionStorage.removeItem('cdgs_user');
      sessionStorage.removeItem('cdgs_customer'); // ✅ Clear customer session
      sessionStorage.removeItem('cdgs_active_role');
      // ✅ Clear all session storage to ensure clean logout
      sessionStorage.clear();
      console.log('✅ Session cleared');
    } catch (error) {
      console.warn('Cannot remove from sessionStorage:', error);
    }
    console.log('🔍 After logout - User should be null');
  };

  // ฟังก์ชันสลับบทบาท พร้อมตรวจสอบสิทธิ์
  const setActiveRole = (role: UserRole) => {
    if (!user) return;
    
    // ตรวจสอบว่า user มี role นี้หรือไม่
    if (!user.roles?.includes(role)) {
      console.warn(`User does not have role: ${role}`);
      return;
    }
    
    setActiveRoleState(role);
    try {
      sessionStorage.setItem('cdgs_active_role', role);
    } catch (error) {
      console.warn('Cannot save activeRole to sessionStorage:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        customer, // ✅ เพิ่ม
        activeRole,
        setActiveRole,
        login,
        loginWithMagicLink, // ✅ เพิ่ม
        logout,
        isAuthenticated: !!(user || customer), // ✅ อัพเดท: รองรับ Customer
        isCustomer: !!customer && !user, // ✅ เพิ่ม
        isLoading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
