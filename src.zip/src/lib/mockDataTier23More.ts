import { Ticket } from '../types';

// ========================================
// ✅ TIER2-3 RESOLVED TICKETS (เพิ่มเติม)
// ========================================
// เคสสำหรับ Tier2-3 คนอื่นๆ (user-007, user-009, user-010)

export const tier23MoreTickets: Ticket[] = [
  // ========================================
  // Tier2+3 - ประกาศิต ประคองเพ็ชร (user-007)
  // ========================================
  
  // ✅ เคสที่ Tier2 ส่งกลับ T1 และรอ T1 ปิด (status = 'tier1')
  {
    id: 'test-t2t3-001',
    ticketNumber: 'CDGS-2024-T23-001',
    title: 'API Gateway Timeout บ่อย #API #Performance',
    description: 'API Gateway มีปัญหา Timeout บ่อย โดยเฉพาะ API /api/v1/orders ที่ใช้เวลานาน 15+ วินาที ส่งผลกระทบต่อระบบ Mobile App',
    status: 'tier1',
    type: 'incident',
    channel: 'web',
    priority: 'high',
    category: 'Application',
    customerName: 'อัจฉรา เอพีไอ',
    customerEmail: 'atchara.a@mhesi.go.th',
    customerPhone: '+66-88-901-2345',
    assignedTo: 'user-003',
    assignedBy: 'user-007',
    assignedAt: new Date(Date.now() - 25 * 60 * 1000),
    previousAssignee: 'user-007',
    projectId: 'proj-009',
    projectCode: 'D24-6059',
    projectName: 'กระทรวงการอุดมศึกษา วิทยาศาสตร์ วิจัยและนวัตกรรม',
    projectShortName: 'MHESI',
    createdAt: new Date(Date.now() - 150 * 60 * 1000),
    updatedAt: new Date(Date.now() - 25 * 60 * 1000),
    dueDate: new Date(Date.now() + 3 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-005',
      escalatedByName: 'ธัญญาพร ทองแก้ว',
      escalatedAt: new Date(Date.now() - 120 * 60 * 1000),
      reason: 'API performance issue - ต้องการ Application Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-007',
      escalatedByName: 'ประกาศิต ประคองเพ็ชร',
      escalatedAt: new Date(Date.now() - 25 * 60 * 1000),
      reason: 'เพิ่ม Cache และ Optimize Query แล้ว API เร็วขึ้น 80% - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2t3-001-timeline-1',
      timestamp: new Date(Date.now() - 150 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2t3-001-timeline-2',
      timestamp: new Date(Date.now() - 120 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประกาศิต ประคองเพ็ชร (Tier 2)',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'tier2'
    }, {
      id: 'test-t2t3-001-timeline-3',
      timestamp: new Date(Date.now() - 90 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประกาศิต ประคองเพ็ชร',
      status: 'in_progress'
    }, {
      id: 'test-t2t3-001-timeline-4',
      timestamp: new Date(Date.now() - 40 * 60 * 1000),
      type: 'comment',
      description: 'เพิ่ม Redis Cache และ Optimize Database Query แล้ว Response time ลดจาก 15s เหลือ 3s',
      user: 'ประกาศิต ประคองเพ็ชร'
    }, {
      id: 'test-t2t3-001-timeline-5',
      timestamp: new Date(Date.now() - 25 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'ประกาศิต ประคองเพ็ชร',
      status: 'tier1'
    }],
    comments: []
  },
  
  // ✅ เคสที่ Tier3 ส่งกลับ T1 และรอ T1 ปิด (status = 'tier1')
  {
    id: 'test-t2t3-tier3-001',
    ticketNumber: 'CDGS-2024-T3-007',
    title: 'ระบบ Load Balancer ไม่กระจาย Traffic #โครงสร้างพื้นฐาน #Load',
    description: 'Load Balancer ไม่กระจาย Traffic อย่างถูกต้อง Server 1 รับ Load 90% ขณะที่ Server 2-3 รับแค่ 5% ทำให้ Server 1 ช้ามาก',
    status: 'tier1',
    type: 'incident',
    channel: 'phone',
    priority: 'high',
    category: 'Infrastructure',
    customerName: 'ธนพล โหลดบาลานซ์',
    customerEmail: 'thanapol.l@moe.go.th',
    customerPhone: '+66-89-012-3456',
    assignedTo: 'user-004',
    assignedBy: 'user-007',
    assignedAt: new Date(Date.now() - 18 * 60 * 1000),
    previousAssignee: 'user-007',
    projectId: 'proj-010',
    projectCode: 'D24-6060',
    projectName: 'กระทรวงศึกษาธิการ',
    projectShortName: 'MOE',
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 18 * 60 * 1000),
    dueDate: new Date(Date.now() + 2 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-005',
      escalatedByName: 'ธัญญาพร ทองแก้ว',
      escalatedAt: new Date(Date.now() - 3.5 * 60 * 60 * 1000),
      reason: 'Load Balancer issue - ต้องการ Infrastructure Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-006',
      escalatedByName: 'ยุทธนา คณามิ่งมงคล',
      escalatedAt: new Date(Date.now() - 2.5 * 60 * 60 * 1000),
      reason: 'Advanced Load Balancer configuration - ต้องการ Senior Infrastructure Expert'
    }, {
      fromTier: 'tier3',
      toTier: 'tier1',
      escalatedBy: 'user-007',
      escalatedByName: 'ประกาศิต ประคองเพ็ชร',
      escalatedAt: new Date(Date.now() - 18 * 60 * 1000),
      reason: 'แก้ไข Algorithm เป็น Round Robin และปรับ Health Check แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2t3-tier3-001-timeline-1',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'Staff บันทึกเคสจาก Phone',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2t3-tier3-001-timeline-2',
      timestamp: new Date(Date.now() - 3.5 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ยุทธนา คณามิ่งมงคล (Tier 2)',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'tier2'
    }, {
      id: 'test-t2t3-tier3-001-timeline-3',
      timestamp: new Date(Date.now() - 2.5 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประกาศิต ประคองเพ็ชร (Tier 3)',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'tier3'
    }, {
      id: 'test-t2t3-tier3-001-timeline-4',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประกาศิต ประคองเพ็ชร',
      status: 'in_progress'
    }, {
      id: 'test-t2t3-tier3-001-timeline-5',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      type: 'comment',
      description: 'เปลี่ยน Algorithm เป็น Round Robin และปรับ Health Check interval แล้ว Traffic กระจายเท่าๆ กัน 33% ต่อ Server',
      user: 'ประกาศิต ประคองเพ็ชร'
    }, {
      id: 'test-t2t3-tier3-001-timeline-6',
      timestamp: new Date(Date.now() - 18 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง เขมิกา แซ่ตั้ง (Tier 1) เพื่อปิดเคส',
      user: 'ประกาศิต ประคองเพ็ชร',
      status: 'tier1'
    }],
    comments: []
  },
  
  // ✅ เคสที่ T2 ส่งกลับ T1 และ T1 ปิดให้แล้ว (status = 'closed')
  {
    id: 'test-t2t3-closed-001',
    ticketNumber: 'CDGS-2024-T23-C001',
    title: 'ขอสร้าง Development Environment ใหม่ #คำขอ #Environment',
    description: 'ขอสร้าง Development Environment สำหรับทีมพัฒนา 5 คน ต้องการ Linux Server (Ubuntu 22.04) พร้อม Docker และ Kubernetes',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'medium',
    category: 'Infrastructure',
    customerName: 'ปรีชา พัฒนาซอฟต์',
    customerEmail: 'preecha.p@dst.go.th',
    customerPhone: '+66-90-123-4567',
    assignedTo: 'user-005',
    assignedBy: 'user-007',
    assignedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
    previousAssignee: 'user-007',
    resolvedBy: 'user-005',
    resolvedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    closedBy: 'user-005',
    closedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
    projectId: 'proj-007',
    projectCode: 'D24-6073',
    projectName: 'สภาพัฒนาการเศรษฐกิจและสังคมแห่งชาติ',
    projectShortName: 'NESDC',
    createdAt: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-005',
      escalatedByName: 'ธัญญาพร ทองแก้ว',
      escalatedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      reason: 'Dev environment setup - ต้องการ Infrastructure Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-007',
      escalatedByName: 'ประกาศิต ประคองเพ็ชร',
      escalatedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
      reason: 'Setup Server พร้อม Docker + K8s แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2t3-closed-001-timeline-1',
      timestamp: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2t3-closed-001-timeline-2',
      timestamp: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประกาศิต ประคองเพ็ชร (Tier 2)',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'tier2'
    }, {
      id: 'test-t2t3-closed-001-timeline-3',
      timestamp: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประกาศิต ประคองเพ็ชร',
      status: 'in_progress'
    }, {
      id: 'test-t2t3-closed-001-timeline-4',
      timestamp: new Date(Date.now() - 12.5 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'Setup Ubuntu 22.04 + Docker 24.0 + K8s 1.28 แล้ว สร้าง User accounts 5 คนพร้อม Access rights',
      user: 'ประกาศิต ประคองเพ็ชร'
    }, {
      id: 'test-t2t3-closed-001-timeline-5',
      timestamp: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง ธัญญาพร ทองแก้ว (Tier 1) เพื่อปิดเคส',
      user: 'ประกาศิต ประคองเพ็ชร',
      status: 'tier1'
    }, {
      id: 'test-t2t3-closed-001-timeline-6',
      timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ตรวจสอบกับลูกค้าแล้วเรียบร้อย - Resolve เคส',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'resolved'
    }, {
      id: 'test-t2t3-closed-001-timeline-7',
      timestamp: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้ายืนยันว่าทีมใช้งานได้แล้ว - ปิดเคส',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'closed'
    }],
    comments: []
  },
  
  // ========================================
  // Tier3 - พุทธจักษ์ วงค์พันธ์ (user-009)
  // ========================================
  
  {
    id: 'test-t3-009-001',
    ticketNumber: 'CDGS-2024-T3-009',
    title: 'Database Replication ล้มเหลว #ฐานข้อมูล #Replication',
    description: 'Database Replication จาก Master ไป Slave ล้มเหลว Slave database ตามหลัง Master ถึง 6 ชั่วโมง ส่งผลกระทบต่อ Report และ Backup',
    status: 'tier1',
    type: 'incident',
    channel: 'email',
    priority: 'high',
    category: 'Data & Database',
    customerName: 'สุรชัย ดาต้าเบส',
    customerEmail: 'surachai.d@opdc.go.th',
    customerPhone: '+66-91-234-5678',
    assignedTo: 'user-003',
    assignedBy: 'user-009',
    assignedAt: new Date(Date.now() - 30 * 60 * 1000),
    previousAssignee: 'user-009',
    projectId: 'proj-009',
    projectCode: 'D24-6059',
    projectName: 'กระทรวงการอุดมศึกษา วิทยาศาสตร์ วิจัยและนวัตกรรม',
    projectShortName: 'MHESI',
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 30 * 60 * 1000),
    dueDate: new Date(Date.now() + 1 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-005',
      escalatedByName: 'ธัญญาพร ทองแก้ว',
      escalatedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      reason: 'Database replication failure - ต้องการ Database Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-008',
      escalatedByName: 'ประวิช จินทนากร',
      escalatedAt: new Date(Date.now() - 2.5 * 60 * 60 * 1000),
      reason: 'Complex replication issue - ต้องการ Senior Database Architect'
    }, {
      fromTier: 'tier3',
      toTier: 'tier1',
      escalatedBy: 'user-009',
      escalatedByName: 'พุทธจักษ์ วงค์พันธ์',
      escalatedAt: new Date(Date.now() - 30 * 60 * 1000),
      reason: 'แก้ไข Replication Config และ Rebuild Slave แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t3-009-001-timeline-1',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'Staff บันทึกเคสจาก Email',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t3-009-001-timeline-2',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประวิช จินทนากร (Tier 2)',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'tier2'
    }, {
      id: 'test-t3-009-001-timeline-3',
      timestamp: new Date(Date.now() - 2.5 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง พุทธจักษ์ วงค์พันธ์ (Tier 3)',
      user: 'ประวิช จินทนากร',
      status: 'tier3'
    }, {
      id: 'test-t3-009-001-timeline-4',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'พุทธจักษ์ วงค์พันธ์',
      status: 'in_progress'
    }, {
      id: 'test-t3-009-001-timeline-5',
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      type: 'comment',
      description: 'แก้ไข Replication binlog position และ Rebuild Slave database แล้ว Lag เหลือ 0 วินาที',
      user: 'พุทธจักษ์ วงค์พันธ์'
    }, {
      id: 'test-t3-009-001-timeline-6',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'พุทธจักษ์ วงค์พันธ์',
      status: 'tier1'
    }],
    comments: []
  },
  
  {
    id: 'test-t3-009-closed-001',
    ticketNumber: 'CDGS-2024-T3-C009',
    title: 'ออกแบบ Database Schema สำหรับระบบใหม่ #คำขอ #Database',
    description: 'ขอความช่วยเหลือในการออกแบบ Database Schema สำหรับระบบ CRM ใหม่ ต้องการ Design ที่รองรับ 1 ล้าน records และ High performance',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'medium',
    category: 'Data & Database',
    customerName: 'วิภาวี ซีอาร์เอ็ม',
    customerEmail: 'wipawee.c@most.go.th',
    customerPhone: '+66-92-345-6789',
    assignedTo: 'user-003',
    assignedBy: 'user-009',
    assignedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
    previousAssignee: 'user-009',
    resolvedBy: 'user-003',
    resolvedAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000),
    closedBy: 'user-003',
    closedAt: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
    projectId: 'proj-005',
    projectCode: 'D24-6065',
    projectName: 'กรมพัฒนาพลังงานทดแทนและอนุรักษ์พลังงาน',
    projectShortName: 'DEDE',
    createdAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-003',
      escalatedByName: 'วรรณภา แซ่ด่าง',
      escalatedAt: new Date(Date.now() - 24 * 24 * 60 * 60 * 1000),
      reason: 'Database schema design - ต้องการ Database Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-006',
      escalatedByName: 'ยุทธนา คณามิ่งมงคล',
      escalatedAt: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000),
      reason: 'Advanced database architecture - ต้องการ Senior Database Architect'
    }, {
      fromTier: 'tier3',
      toTier: 'tier1',
      escalatedBy: 'user-009',
      escalatedByName: 'พุทธจักษ์ วงค์พันธ์',
      escalatedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
      reason: 'ออกแบบ Schema พร้อม Indexing Strategy แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t3-009-closed-001-timeline-1',
      timestamp: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t3-009-closed-001-timeline-2',
      timestamp: new Date(Date.now() - 24 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ยุทธนา คณามิ่งมงคล (Tier 2)',
      user: 'วรรณภา แซ่ด่าง',
      status: 'tier2'
    }, {
      id: 'test-t3-009-closed-001-timeline-3',
      timestamp: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง พุทธจักษ์ วงค์พันธ์ (Tier 3)',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'tier3'
    }, {
      id: 'test-t3-009-closed-001-timeline-4',
      timestamp: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'พุทธจักษ์ วงค์พันธ์',
      status: 'in_progress'
    }, {
      id: 'test-t3-009-closed-001-timeline-5',
      timestamp: new Date(Date.now() - 20.5 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'ออกแบบ Normalized Schema (3NF) พร้อม Partitioning และ Indexing Strategy สำหรับ 1M+ records',
      user: 'พุทธจักษ์ วงค์พันธ์'
    }, {
      id: 'test-t3-009-closed-001-timeline-6',
      timestamp: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'พุทธจักษ์ วงค์พันธ์',
      status: 'tier1'
    }, {
      id: 'test-t3-009-closed-001-timeline-7',
      timestamp: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ตรวจสอบกับลูกค้าแล้วเรียบร้อย - Resolve เคส',
      user: 'วรรณภา แซ่ด่าง',
      status: 'resolved'
    }, {
      id: 'test-t3-009-closed-001-timeline-8',
      timestamp: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้ายืนยันว่า Schema ตรงตาม Requirements - ปิดเคส',
      user: 'วรรณภา แซ่ด่าง',
      status: 'closed'
    }],
    comments: []
  },
  
  // ========================================
  // Tier3 - วีระกร เยือกเย็น (user-010)
  // ========================================
  
  {
    id: 'test-t3-010-001',
    ticketNumber: 'CDGS-2024-T3-010',
    title: 'Cloud Migration Planning #Cloud #Migration',
    description: 'ขอคำปรึกษาในการวางแผน Migrate ระบบจาก On-Premise ไป Cloud (AWS) ต้องการ Architecture Design และ Migration Strategy',
    status: 'tier1',
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Infrastructure',
    customerName: 'ธีรพงษ์ คลาวด์',
    customerEmail: 'theerapong.c@onep.go.th',
    customerPhone: '+66-93-456-7890',
    assignedTo: 'user-005',
    assignedBy: 'user-010',
    assignedAt: new Date(Date.now() - 35 * 60 * 1000),
    previousAssignee: 'user-010',
    projectId: 'proj-008',
    projectCode: 'D24-6078',
    projectName: 'สำนักงานนโยบายและแผนทรัพยากรธรรมชาติและสิ่งแวดล้อม',
    projectShortName: 'ONEP',
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 35 * 60 * 1000),
    dueDate: new Date(Date.now() + 18 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-004',
      escalatedByName: 'เขมิกา แซ่ตั้ง',
      escalatedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      reason: 'Cloud migration planning - ต้องการ Cloud Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-006',
      escalatedByName: 'ยุทธนา คณามิ่งมงคล',
      escalatedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
      reason: 'Enterprise cloud architecture - ต้องการ Senior Cloud Architect'
    }, {
      fromTier: 'tier3',
      toTier: 'tier1',
      escalatedBy: 'user-010',
      escalatedByName: 'วีระกร เยือกเย็น',
      escalatedAt: new Date(Date.now() - 35 * 60 * 1000),
      reason: 'จัดทำ Migration Plan พร้อม Cost Estimate แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t3-010-001-timeline-1',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'Staff บันทึกเคสจาก Email',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t3-010-001-timeline-2',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ยุทธนา คณามิ่งมงคล (Tier 2)',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'tier2'
    }, {
      id: 'test-t3-010-001-timeline-3',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง วีระกร เยือกเย็น (Tier 3)',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'tier3'
    }, {
      id: 'test-t3-010-001-timeline-4',
      timestamp: new Date(Date.now() - 2.5 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'วีระกร เยือกเย็น',
      status: 'in_progress'
    }, {
      id: 'test-t3-010-001-timeline-5',
      timestamp: new Date(Date.now() - 90 * 60 * 1000),
      type: 'comment',
      description: 'จัดทำ Multi-Phase Migration Plan พร้อม AWS Architecture (EC2, RDS, S3, CloudFront) และ Cost Estimate 3 ปี',
      user: 'วีระกร เยือกเย็น'
    }, {
      id: 'test-t3-010-001-timeline-6',
      timestamp: new Date(Date.now() - 35 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง ธัญญาพร ทองแก้ว (Tier 1) เพื่อปิดเคส',
      user: 'วีระกร เยือกเย็น',
      status: 'tier1'
    }],
    comments: []
  },
  
  {
    id: 'test-t3-010-closed-001',
    ticketNumber: 'CDGS-2024-T3-C010',
    title: 'Disaster Recovery Plan #ความปลอดภัย #DR',
    description: 'ขอความช่วยเหลือในการจัดทำ Disaster Recovery Plan สำหรับระบบ Mission-Critical ต้องการ RTO < 4 ชม., RPO < 1 ชม.',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'high',
    category: 'Security',
    customerName: 'อนุชา ดีอาร์',
    customerEmail: 'anucha.d@nso.go.th',
    customerPhone: '+66-94-567-8901',
    assignedTo: 'user-005',
    assignedBy: 'user-010',
    assignedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
    previousAssignee: 'user-010',
    resolvedBy: 'user-005',
    resolvedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
    closedBy: 'user-005',
    closedAt: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000),
    projectId: 'proj-006',
    projectCode: 'D24-6056',
    projectName: 'กระทรวงการต่างประเทศ',
    projectShortName: 'MOFA',
    createdAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-005',
      escalatedByName: 'ธัญญาพร ทองแก้ว',
      escalatedAt: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
      reason: 'DR planning - ต้องการ Infrastructure Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-008',
      escalatedByName: 'ประวิช จินทนากร',
      escalatedAt: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000),
      reason: 'Enterprise DR strategy - ต้องการ Senior Infrastructure Architect'
    }, {
      fromTier: 'tier3',
      toTier: 'tier1',
      escalatedBy: 'user-010',
      escalatedByName: 'วีระกร เยือกเย็น',
      escalatedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      reason: 'จัดทำ DR Plan พร้อม Testing Procedure แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t3-010-closed-001-timeline-1',
      timestamp: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t3-010-closed-001-timeline-2',
      timestamp: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประวิช จินทนากร (Tier 2)',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'tier2'
    }, {
      id: 'test-t3-010-closed-001-timeline-3',
      timestamp: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง วีระกร เยือกเย็น (Tier 3)',
      user: 'ประวิช จินทนากร',
      status: 'tier3'
    }, {
      id: 'test-t3-010-closed-001-timeline-4',
      timestamp: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'วีระกร เยือกเย็น',
      status: 'in_progress'
    }, {
      id: 'test-t3-010-closed-001-timeline-5',
      timestamp: new Date(Date.now() - 14.5 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'จัดทำ DR Plan (Hot Standby, Auto-Failover, RTO 2 ชม., RPO 30 นาที) พร้อม Testing และ Recovery Procedure',
      user: 'วีระกร เยือกเย็น'
    }, {
      id: 'test-t3-010-closed-001-timeline-6',
      timestamp: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง ธัญญาพร ทองแก้ว (Tier 1) เพื่อปิดเคส',
      user: 'วีระกร เยือกเย็น',
      status: 'tier1'
    }, {
      id: 'test-t3-010-closed-001-timeline-7',
      timestamp: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ตรวจสอบกับลูกค้าแล้วเรียบร้อย - Resolve เคส',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'resolved'
    }, {
      id: 'test-t3-010-closed-001-timeline-8',
      timestamp: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้ายืนยันว่า DR Plan ครบถ้วน - ปิดเคส',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'closed'
    }],
    comments: []
  }
];
