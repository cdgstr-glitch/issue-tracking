import { Ticket } from '../types';

/**
 * Staff Closed Tickets (Renamed concept to Retroactive Tickets)
 * เคสที่ปิดย้อนหลัง (โดย Tier 1 / Admin)
 * เดิมชื่อ Staff Closed Tickets แต่เปลี่ยนเป็น Tier 1 บันทึกแทน
 */

export const staffClosedTickets: Ticket[] = [
  {
    id: 'staff-closed-1',
    ticketNumber: 'CDGS-2024-SC001',
    title: 'ลูกค้าสอบถามวิธีการ Reset รหัสผ่าน #ปิดแล้ว',
    description: '[บันทึกจากโทรศัพท์] ลูกค้าโทรมาสอบถามวิธีการรีเซ็ตรหัสผ่าน - ได้อธิบายขั้นตอนและแนะนำให้ใช้ฟีเจอร์ Forgot Password',
    status: 'closed',
    type: 'question',
    channel: 'phone',
    priority: 'low',
    category: 'User Account & Access',
    customerName: 'นายสมศักดิ์ ประเสริฐสุข',
    customerEmail: 'somsak.p@example.com',
    customerPhone: '+66-89-123-4567',
    // onBehalfOf: 'สมชาย ใจดี', // Removed staff reference
    createdBy: 'user-001', // Thiraporn (Admin/Tier1)
    assignedTo: 'user-001',
    assignedBy: 'user-001',
    assignedAt: new Date('2024-11-20T09:15:00'),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    productValue: 'smart-city',
    createdAt: new Date('2024-11-20T09:00:00'),
    updatedAt: new Date('2024-11-20T10:30:00'),
    dueDate: new Date('2024-11-20T17:00:00'),
    resolvedAt: new Date('2024-11-20T10:25:00'),
    resolvedBy: 'user-001',
    closedAt: new Date('2024-11-20T10:30:00'),
    closedBy: 'user-001',
    solution: 'แนะนำให้ลูกค้าใช้ฟีเจอร์ "ลืมรหัสผ่าน" ในหน้า Login และกรอกอีเมลเพื่อรับลิงก์รีเซ็ตรหัสผ่าน',
    closureNotes: 'ลูกค้าสามารถรีเซ็ตรหัสผ่านสำเร็จและเข้าระบบได้แล้ว',
    attachments: [],
    timeline: [
      {
        id: 'sc1-t1',
        timestamp: new Date('2024-11-20T09:00:00'),
        type: 'status_change',
        description: 'เจ้าหน้าที่บันทึกเคสจากโทรศัพท์',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล', // Changed from Somchai
        status: 'new'
      },
      {
        id: 'sc1-t2',
        timestamp: new Date('2024-11-20T09:15:00'),
        type: 'assignment',
        description: 'มอบหมายให้ ธิราภรณ์ รุ่งวิรัตน์กุล (Tier 1)',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'tier1'
      },
      {
        id: 'sc1-t3',
        timestamp: new Date('2024-11-20T09:20:00'),
        type: 'assignment',
        description: 'ธิราภรณ์ รุ่งวิรัตน์กุล (Tier 1) รับเคสเข้าดำเนินการ',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'tier1'
      },
      {
        id: 'sc1-t4',
        timestamp: new Date('2024-11-20T10:25:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้น',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'resolved'
      },
      {
        id: 'sc1-t5',
        timestamp: new Date('2024-11-20T10:30:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'closed'
      }
    ],
    comments: [
      {
        id: 'sc1-c1',
        ticketId: 'staff-closed-1',
        author: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        authorRole: 'tier1',
        content: 'ได้ติดต่อลูกค้าและแนะนำขั้นตอนการรีเซ็ตรหัสผ่านเรียบร้อยแล้ว ลูกค้าสามารถเข้าระบบได้',
        isInternal: false,
        createdAt: new Date('2024-11-20T10:25:00'),
        attachments: []
      }
    ]
  },
  {
    id: 'staff-closed-2',
    ticketNumber: 'CDGS-2024-SC002',
    title: 'ปัญหาการพิมพ์เอกสารไม่ออก #ฮาร์ดแวร์ #ปิดแล้ว',
    description: '[บันทึกจาก Line] ลูกค้า Line มาแจ้งว่าเครื่องพิมพ์ไม่สามารถพิมพ์เอกสารได้ แสดง Error Paper Jam',
    status: 'closed',
    type: 'incident',
    channel: 'line',
    priority: 'medium',
    category: 'Hardware & Equipment',
    customerName: 'นางสาววิภาดา ศรีสุข',
    customerEmail: 'wipada.s@example.com',
    customerPhone: '+66-92-345-6789',
    lineId: '@wipada_s',
    // onBehalfOf: 'สมชาย ใจดี',
    createdBy: 'user-003', // Wannapa (Tier1)
    assignedTo: 'user-003',
    assignedBy: 'user-003',
    assignedAt: new Date('2024-11-22T14:30:00'),
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    productValue: 'document-management',
    createdAt: new Date('2024-11-22T14:15:00'),
    updatedAt: new Date('2024-11-22T16:45:00'),
    dueDate: new Date('2024-11-22T17:00:00'),
    resolvedAt: new Date('2024-11-22T16:40:00'),
    resolvedBy: 'user-003',
    closedAt: new Date('2024-11-22T16:45:00'),
    closedBy: 'user-003',
    solution: 'ตรวจสอบพบว่ามีกระดาษติดภายในเครื่อง ได้ทำการเคลียร์กระดาษและทดสอบพิมพ์สำเร็จ',
    closureNotes: 'เครื่องพิมพ์ทำงานปกติแล้ว ลูกค้ายืนยันว่าพิมพ์ได้',
    attachments: [],
    timeline: [
      {
        id: 'sc2-t1',
        timestamp: new Date('2024-11-22T14:15:00'),
        type: 'status_change',
        description: 'เจ้าหน้าที่บันทึกเคสจาก Line',
        user: 'วรรณภา แซ่ด่าง', // Changed from Somchai
        status: 'new'
      },
      {
        id: 'sc2-t2',
        timestamp: new Date('2024-11-22T14:30:00'),
        type: 'assignment',
        description: 'มอบหมายให้ วรรณภา แซ่ด่าง (Tier 1)',
        user: 'วรรณภา แซ่ด่าง',
        status: 'tier1'
      },
      {
        id: 'sc2-t3',
        timestamp: new Date('2024-11-22T14:35:00'),
        type: 'assignment',
        description: 'วรรณภา แซ่ด่าง (Tier 1) รับเคสเข้าดำเนินการ',
        user: 'วรรณภา แซ่ด่าง',
        status: 'tier1'
      },
      {
        id: 'sc2-t4',
        timestamp: new Date('2024-11-22T16:40:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้น',
        user: 'วรรณภา แซ่ด่าง',
        status: 'resolved'
      },
      {
        id: 'sc2-t5',
        timestamp: new Date('2024-11-22T16:45:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'วรรณภา แซ่ด่าง',
        status: 'closed'
      }
    ],
    comments: []
  },
  {
    id: 'staff-closed-3',
    ticketNumber: 'CDGS-2024-SC003',
    title: 'ขอคู่มือการใช้งานระบบ #คำถาม #ปิดแล้ว',
    description: '[บันทึกจากอีเมล] ลูกค้าขอคู่มือการใช้งานระบบ Smart City Platform เพื่อฝึกอบรมพนักงานใหม่',
    status: 'closed',
    type: 'question',
    channel: 'email',
    priority: 'low',
    category: 'Documentation & Training',
    customerName: 'คุณประวิทย์ มั่นคง',
    customerEmail: 'prawit.m@example.com',
    customerPhone: '+66-81-234-5678',
    // onBehalfOf: 'สมชาย ใจดี',
    createdBy: 'user-001', // Thiraporn (Admin/Tier1)
    assignedTo: 'user-001',
    assignedBy: 'user-001',
    assignedAt: new Date('2024-11-25T10:00:00'),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    productValue: 'smart-city',
    createdAt: new Date('2024-11-25T09:45:00'),
    updatedAt: new Date('2024-11-25T11:00:00'),
    dueDate: new Date('2024-11-25T17:00:00'),
    resolvedAt: new Date('2024-11-25T10:55:00'),
    resolvedBy: 'user-001',
    closedAt: new Date('2024-11-25T11:00:00'),
    closedBy: 'user-001',
    solution: 'ส่งคู่มือการใช้งาน Smart City Platform (PDF) ทางอีเมลพร้อมลิงก์ดาวน์โหลด Video Tutorial',
    closureNotes: 'ลูกค้าได้รับคู่มือและพอใจกับเนื้อหา',
    attachments: [],
    timeline: [
      {
        id: 'sc3-t1',
        timestamp: new Date('2024-11-25T09:45:00'),
        type: 'status_change',
        description: 'เจ้าหน้าที่บันทึกเคสจากอีเมล',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล', // Changed from Somchai
        status: 'new'
      },
      {
        id: 'sc3-t2',
        timestamp: new Date('2024-11-25T10:00:00'),
        type: 'assignment',
        description: 'มอบหมายให้ ธิราภรณ์ รุ่งวิรัตน์กุล (Tier 1)',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'tier1'
      },
      {
        id: 'sc3-t3',
        timestamp: new Date('2024-11-25T10:05:00'),
        type: 'assignment',
        description: 'ธิราภรณ์ รุ่งวิรัตน์กุล (Tier 1) รับเคสเข้าดำเนินการ',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'tier1'
      },
      {
        id: 'sc3-t4',
        timestamp: new Date('2024-11-25T10:55:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้น',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'resolved'
      },
      {
        id: 'sc3-t5',
        timestamp: new Date('2024-11-25T11:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'closed'
      }
    ],
    comments: [
      {
        id: 'sc3-c1',
        ticketId: 'staff-closed-3',
        author: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        authorRole: 'tier1',
        content: 'ส่งคู่มือ PDF และลิงก์ Video Tutorial ให้ลูกค้าทางอีเมลเรียบร้อยแล้ว',
        isInternal: false,
        createdAt: new Date('2024-11-25T10:55:00'),
        attachments: []
      }
    ]
  }
];
