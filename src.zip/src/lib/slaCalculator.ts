/**
 * SLA Calculator - คำนวณ SLA, Due Date, และ SLA Status
 * 
 * ระบบคำนวณ SLA ตามมาตรฐาน ITIL (IT Service Management)
 * โดยพิจารณาจาก Priority และ Type ของเคส
 */

import { TicketPriority, TicketType, SLAStatus } from '../types';
import { db } from './mockDb/client';

/**
 * SLA Matrix (ชั่วโมง)
 * 
 * ตารางกำหนด SLA ตามประเภทและความสำคัญของเคส
 * ตัวเลขแสดงจำนวนชั่วโมงที่ต้องแก้ไขให้เสร็จ
 * 
 * Note: ตอนนี้ดึงข้อมูลจาก mockDb แล้ว แต่เก็บค่า Default ไว้เป็น Fallback
 */
const DEFAULT_SLA_MATRIX: Record<TicketPriority, Record<TicketType, number>> = {
  critical: {
    incident: 1,              // ด่วนมาก + Incident = 1 ชั่วโมง
    service_request: 2,       // ด่วนมาก + Service Request = 2 ชั่วโมง
    security_incident: 0.5,   // ด่วนมาก + Security = 30 นาที
  },
  high: {
    incident: 4,              // ด่วน + Incident = 4 ชั่วโมง
    service_request: 8,       // ด่วน + Service Request = 8 ชั่วโมง (1 วัน)
    security_incident: 2,     // ด่วน + Security = 2 ชั่วโมง
  },
  medium: {
    incident: 8,              // ปกติ + Incident = 8 ชั่วโมง (1 วัน)
    service_request: 24,      // ปกติ + Service Request = 24 ชั่วโมง (3 วัน)
    security_incident: 4,     // ปกติ + Security = 4 ชั่วโมง
  },
  low: {
    incident: 24,             // ต่ำ + Incident = 24 ชั่วโมง (3 วัน)
    service_request: 72,      // ต่ำ + Service Request = 72 ชั่วโมง (9 วัน)
    security_incident: 8,     // ต่ำ + Security = 8 ชั่วโมง (1 วัน)
  },
};

/**
 * คำนวณจำนวนชั่วโมง SLA
 * 
 * @param priority - ความสำคัญของเคส
 * @param type - ประเภทของเคส
 * @returns จำนวนชั่วโมงที่ต้องแก้ไข
 * 
 * @example
 * calculateSLAHours('medium', 'incident') // 8 ชั่วโมง
 * calculateSLAHours('critical', 'security_incident') // 0.5 ชั่วโมง (30 นาที)
 */
export function calculateSLAHours(
  priority: TicketPriority,
  type: TicketType,
  organizationId?: string,
  projectId?: string
): number {
  // Map 'question' type to 'service_request' if needed
  const lookupType = type === 'question' ? 'service_request' : type;
  
  // Use the intelligent query method from mockDb
  const setting = db.slaSettings.getByContext(priority, lookupType, organizationId, projectId);
  
  if (setting) {
    return setting.hours;
  }
  
  // Fallback to hardcoded matrix
  return DEFAULT_SLA_MATRIX[priority]?.[lookupType as any] || 24;
}

/**
 * คำนวณวันที่ครบกำหนด SLA
 * 
 * @param startDate - วันที่เริ่มต้น (วันที่สร้างเคสหรือรับเคส)
 * @param slaHours - จำนวนชั่วโมง SLA
 * @returns วันที่ครบกำหนด SLA
 * 
 * @example
 * const now = new Date('2026-01-21T14:00:00');
 * calculateSLADueDate(now, 8) // 2026-01-21T22:00:00 (14:00 + 8 ชั่วโมง)
 */
export function calculateSLADueDate(
  startDate: Date,
  slaHours: number
): Date {
  const dueDate = new Date(startDate);
  dueDate.setHours(dueDate.getHours() + slaHours);
  return dueDate;
}

/**
 * คำนวณสถานะ SLA
 * 
 * กฎการคำนวณ:
 * - on_track: ยังมีเวลาเหลือมากกว่า 25% ของ SLA
 * - at_risk: เหลือเวลา 0-25% ของ SLA
 * - breached: เกินกำหนดแล้ว
 * 
 * @param slaDueDate - วันที่ครบกำหนด SLA
 * @param slaHours - จำนวนชั่วโมง SLA ทั้งหมด
 * @param currentDate - วันที่ปัจจุบัน (optional, default: now)
 * @returns สถานะ SLA
 * 
 * @example
 * const dueDate = new Date('2026-01-21T22:00:00');
 * const now = new Date('2026-01-21T20:00:00'); // เหลือ 2 ชั่วโมง
 * calculateSLAStatus(dueDate, 8, now) // 'on_track' (เหลือ 25%)
 */
export function calculateSLAStatus(
  slaDueDate: Date,
  slaHours: number,
  currentDate: Date = new Date()
): SLAStatus {
  const timeRemaining = slaDueDate.getTime() - currentDate.getTime();
  
  // Breached: เกินกำหนดแล้ว
  if (timeRemaining <= 0) {
    return 'breached';
  }
  
  // คำนวณเวลาที่เหลือเป็น %
  const totalTime = slaHours * 60 * 60 * 1000; // แปลงชั่วโมงเป็น milliseconds
  const remainingPercent = (timeRemaining / totalTime) * 100;
  
  // At Risk: เหลือ 0-25%
  if (remainingPercent <= 25) {
    return 'at_risk';
  }
  
  // On Track: เหลือมากกว่า 25%
  return 'on_track';
}

/**
 * คำนวณ SLA ทั้งหมดในครั้งเดียว
 * 
 * @param priority - ความสำคัญของเคส
 * @param type - ประเภทของเคส
 * @param startDate - วันที่เริ่มต้น (default: now)
 * @returns Object ที่มี slaHours, slaDueDate, slaStatus
 * 
 * @example
 * const result = calculateFullSLA('medium', 'incident');
 * console.log(result);
 * // {
 * //   slaHours: 8,
 * //   slaDueDate: Date(2026-01-21T22:00:00),
 * //   slaStatus: 'on_track'
 * // }
 */
export function calculateFullSLA(
  priority: TicketPriority,
  type: TicketType,
  startDate: Date = new Date(),
  organizationId?: string,
  projectId?: string
): {
  slaHours: number;
  slaDueDate: Date;
  slaStatus: SLAStatus;
} {
  const slaHours = calculateSLAHours(priority, type, organizationId, projectId);
  const slaDueDate = calculateSLADueDate(startDate, slaHours);
  const slaStatus = calculateSLAStatus(slaDueDate, slaHours);
  
  return {
    slaHours,
    slaDueDate,
    slaStatus,
  };
}

/**
 * Format SLA Hours เป็นข้อความแสดงผล
 * 
 * @param slaHours - จำนวนชั่วโมง SLA
 * @returns ข้อความแสดงผล (เช่น "8 ชั่วโมง", "30 นาที", "3 วัน")
 * 
 * @example
 * formatSLAHours(8) // "8 ชั่วโมง"
 * formatSLAHours(0.5) // "30 นาที"
 * formatSLAHours(24) // "1 วัน"
 * formatSLAHours(72) // "3 วัน"
 */
export function formatSLAHours(slaHours: number): string {
  if (slaHours < 1) {
    const minutes = Math.round(slaHours * 60);
    return `${minutes} นาที`;
  }
  
  if (slaHours >= 24) {
    const days = Math.round(slaHours / 24);
    return `${days} วัน`;
  }
  
  return `${slaHours} ชั่วโมง`;
}

/**
 * Format SLA Due Date เป็นข้อความแสดงผล
 * 
 * @param slaDueDate - วันที่ครบกำหนด SLA
 * @returns ข้อความแสดงผล (เช่น "21 ม.ค. 2026 22:00")
 * 
 * @example
 * const dueDate = new Date('2026-01-21T22:00:00');
 * formatSLADueDate(dueDate) // "21 ม.ค. 2026 22:00"
 */
export function formatSLADueDate(slaDueDate: Date): string {
  const thaiMonths = [
    'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
    'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'
  ];
  
  const day = slaDueDate.getDate();
  const month = thaiMonths[slaDueDate.getMonth()];
  const year = slaDueDate.getFullYear();
  const hours = slaDueDate.getHours().toString().padStart(2, '0');
  const minutes = slaDueDate.getMinutes().toString().padStart(2, '0');
  
  return `${day} ${month} ${year} ${hours}:${minutes}`;
}

/**
 * Get SLA Status Color (สำหรับ UI)
 * 
 * @param slaStatus - สถานะ SLA
 * @returns CSS color class
 * 
 * @example
 * getSLAStatusColor('on_track') // 'text-green-600'
 * getSLAStatusColor('at_risk') // 'text-yellow-600'
 * getSLAStatusColor('breached') // 'text-red-600'
 */
export function getSLAStatusColor(slaStatus: SLAStatus): string {
  const colorMap: Record<SLAStatus, string> = {
    on_track: 'text-green-600',
    at_risk: 'text-yellow-600',
    breached: 'text-red-600',
  };
  
  return colorMap[slaStatus];
}

/**
 * Get SLA Status Label (ภาษาไทย)
 * 
 * @param slaStatus - สถานะ SLA
 * @returns ข้อความภาษาไทย
 * 
 * @example
 * getSLAStatusLabel('on_track') // 'ปกติ'
 * getSLAStatusLabel('at_risk') // 'ใกล้ครบกำหนด'
 * getSLAStatusLabel('breached') // 'เกินกำหนด'
 */
export function getSLAStatusLabel(slaStatus: SLAStatus): string {
  const labelMap: Record<SLAStatus, string> = {
    on_track: 'ปกติ',
    at_risk: 'ใกล้ครบกำหนด',
    breached: 'เกินกำหนด',
  };
  
  return labelMap[slaStatus];
}

/**
 * Get SLA Status Icon (สำหรับ UI)
 * 
 * @param slaStatus - สถานะ SLA
 * @returns Emoji icon
 * 
 * @example
 * getSLAStatusIcon('on_track') // '✅'
 * getSLAStatusIcon('at_risk') // '⚠️'
 * getSLAStatusIcon('breached') // '🔴'
 */
export function getSLAStatusIcon(slaStatus: SLAStatus): string {
  const iconMap: Record<SLAStatus, string> = {
    on_track: '✅',
    at_risk: '⚠️',
    breached: '🔴',
  };
  
  return iconMap[slaStatus];
}
