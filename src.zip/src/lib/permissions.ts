/**
 * 🔐 CDGS Issue Tracking Platform - Permissions & Capabilities System
 *
 * @description Capability-based Access Control (CBAC)
 * @version 2.0
 * @date 2025-01-22
 *
 * แทนที่จะเช็ค role ซ้ำๆ ทั่วทั้งระบบ
 * ให้เช็คความสามารถ (capability) แทน
 *
 * ตัวอย่าง:
 *   ❌ เก่า: hasRole(user, 'tier1') && hasRole(user, 'staff')
 *   ✅ ใหม่: can(user, CAPABILITIES.CLOSE_TICKET)
 */

import type { User, UserRole } from '../contexts/AuthContext';

// ========================================
// 📋 Capability Definitions
// ========================================

/**
 * ความสามารถทั้งหมดในระบบ
 */
export const CAPABILITIES = {
  // ===== Ticket Management =====

  /** บันทึกเคสแทนลูกค้า (Staff & Tier1) */
  CREATE_TICKET_FOR_CUSTOMER: 'create_ticket_for_customer',

  /** รับเคส (Tier1, Tier2, Tier3) */
  ACCEPT_TICKET: 'accept_ticket',

  /** ปิดเคส (เฉพาะ Tier1 เท่านั้น) */
  CLOSE_TICKET: 'close_ticket',

  /** ส่งต่อเคส (Tier1, Tier2, Tier3) */
  ESCALATE_TICKET: 'escalate_ticket',

  /** มอบหมายเคสให้คนอื่น (Tier1 เท่านั้น) */
  ASSIGN_TICKET: 'assign_ticket',

  /** แก้ไขเคส (Tier1, Tier2, Tier3) */
  UPDATE_TICKET: 'update_ticket',

  /** ดูเคสทั้งหมด (Tier1, Tier2, Tier3, Admin) */
  VIEW_ALL_TICKETS: 'view_all_tickets',

  /** ตอบกลับความคิดเห็นและกิจกรรม (Customer, Tier1, Tier2, Tier3, Admin) */
  ADD_COMMENT: 'add_comment',

  // ===== Customer Capabilities =====

  /** แจ้งเคสของตัวเอง (Customer) */
  CREATE_OWN_TICKET: 'create_own_ticket',

  /** ดูเคสของตัวเอง (Customer) */
  VIEW_OWN_TICKETS: 'view_own_tickets',

  /** ประเมินความพึงพอใจ (Customer) */
  SUBMIT_SATISFACTION_SURVEY: 'submit_satisfaction_survey',

  // ===== Staff Capabilities =====

  /** ดูเคสที่ตัวเองบันทึกแทนลูกค้า (Staff) */
  VIEW_OWN_CREATED_TICKETS: 'view_own_created_tickets',

  // ===== Admin Capabilities =====

  /** จัดการผู้ใช้ (Admin) */
  MANAGE_USERS: 'manage_users',

  /** จัดการโครงการ (Admin) */
  MANAGE_PROJECTS: 'manage_projects',

  /** ตั้งค่าระบบ (Admin) */
  MANAGE_SETTINGS: 'manage_settings',
} as const;

// Type สำหรับ capability
export type Capability = typeof CAPABILITIES[keyof typeof CAPABILITIES];

// ========================================
// 🎯 Role → Capabilities Mapping
// ========================================

/**
 * กำหนดความสามารถของแต่ละ Role
 *
 * กฎใหม่ (22 ม.ค. 2025):
 * - Customer: แจ้งเคสและดูเคสของตัวเองเท่านั้น
 * - Staff: บันทึกเคสแทนลูกค้าเท่านั้น (ไม่สามารถรับ/แก้/ปิดเคส)
 * - Tier1: มีสิทธิ์เต็มรูปแบบ (บันทึก + รับ + แก้ + ปิดเคส)
 * - Supervisor: เหมือน Tier1 + จัดการระบบ (manage)
 * - Tier2: รับและส่งต่อเคส (ไม่สามารถปิดเคส)
 * - Tier3: รับและส่งต่อเคส (ไม่สามารถปิดเคส)
 * - Admin: จัดการระบบ (ไม่สามารถปิดเคสถ้าไม่มี tier1)
 */

// ===== Shared Capability Sets (Laravel-friendly / avoid TDZ self-reference) =====
const TIER1_CAPS: Capability[] = [
  CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER,
  CAPABILITIES.ACCEPT_TICKET,
  CAPABILITIES.CLOSE_TICKET,
  CAPABILITIES.ESCALATE_TICKET,
  CAPABILITIES.ASSIGN_TICKET,
  CAPABILITIES.UPDATE_TICKET,
  CAPABILITIES.VIEW_ALL_TICKETS,
  CAPABILITIES.ADD_COMMENT,
];

export const ROLE_CAPABILITIES: Record<UserRole, Capability[]> = {
  // ===== Customer =====
  customer: [
    CAPABILITIES.CREATE_OWN_TICKET,
    CAPABILITIES.VIEW_OWN_TICKETS,
    CAPABILITIES.ADD_COMMENT,
    CAPABILITIES.SUBMIT_SATISFACTION_SURVEY,
  ],

  // ===== Staff (บันทึกเคสแทนลูกค้าเท่านั้น) =====
  staff: [CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER, CAPABILITIES.VIEW_OWN_CREATED_TICKETS],

  // ===== Tier1 (มีสิทธิ์เต็มรูปแบบ) =====
  tier1: TIER1_CAPS,

  // ===== Supervisor (Tier1 + manage) =====
  supervisor: [
    ...TIER1_CAPS,
    CAPABILITIES.MANAGE_USERS,
    CAPABILITIES.MANAGE_PROJECTS,
    CAPABILITIES.MANAGE_SETTINGS,
  ],

  // ===== Tier2 (รับและส่งต่อเท่านั้น) =====
  tier2: [
    CAPABILITIES.ACCEPT_TICKET,
    CAPABILITIES.ESCALATE_TICKET,
    CAPABILITIES.UPDATE_TICKET,
    CAPABILITIES.VIEW_ALL_TICKETS,
    CAPABILITIES.ADD_COMMENT,
  ],

  // ===== Tier3 (รับและส่งต่อเท่านั้น) =====
  tier3: [
    CAPABILITIES.ACCEPT_TICKET,
    CAPABILITIES.ESCALATE_TICKET,
    CAPABILITIES.UPDATE_TICKET,
    CAPABILITIES.VIEW_ALL_TICKETS,
    CAPABILITIES.ADD_COMMENT,
  ],

  // ===== Admin (จัดการระบบ) =====
  admin: [
    CAPABILITIES.MANAGE_USERS,
    CAPABILITIES.MANAGE_PROJECTS,
    CAPABILITIES.MANAGE_SETTINGS,
    CAPABILITIES.VIEW_ALL_TICKETS,
    CAPABILITIES.ADD_COMMENT,
  ],
};

// ========================================
// 🔧 Helper Functions
// ========================================

/**
 * เช็คว่า user มี capability นี้หรือไม่
 */
export function can(user: User | null | undefined, capability: Capability): boolean {
  if (!user) return false;

  const userCapabilities = getUserCapabilities(user);
  return userCapabilities.includes(capability);
}

/**
 * เช็คว่า user มี capabilities ทั้งหมดหรือไม่
 */
export function canAll(user: User | null | undefined, capabilities: Capability[]): boolean {
  return capabilities.every(cap => can(user, cap));
}

/**
 * เช็คว่า user มีอย่างน้อย 1 capability
 */
export function canAny(user: User | null | undefined, capabilities: Capability[]): boolean {
  return capabilities.some(cap => can(user, cap));
}

/**
 * ดึง capabilities ทั้งหมดของ user
 */
export function getUserCapabilities(user: User | null | undefined): Capability[] {
  if (!user) return [];

  const capabilities = new Set<Capability>();

  // รวม capabilities จากทุก role ที่ user มี
  const roles = user.roles || [user.role];

  roles.forEach(role => {
    const roleCaps = ROLE_CAPABILITIES[role] || [];
    roleCaps.forEach(cap => capabilities.add(cap));
  });

  return Array.from(capabilities);
}

/**
 * ดึง capabilities ที่ขาดหายของ user เทียบกับ required capabilities
 */
export function getMissingCapabilities(
  user: User | null | undefined,
  requiredCapabilities: Capability[]
): Capability[] {
  const userCaps = getUserCapabilities(user);
  return requiredCapabilities.filter(cap => !userCaps.includes(cap));
}

/**
 * แสดงชื่อ capability ที่อ่านง่าย
 */
export function getCapabilityDisplayName(capability: Capability): string {
  const displayNames: Record<Capability, string> = {
    [CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER]: 'บันทึกเคสแทนลูกค้า',
    [CAPABILITIES.ACCEPT_TICKET]: 'รับเคส',
    [CAPABILITIES.CLOSE_TICKET]: 'ปิดเคส',
    [CAPABILITIES.ESCALATE_TICKET]: 'ส่งต่อเคส',
    [CAPABILITIES.ASSIGN_TICKET]: 'มอบหมายเคส',
    [CAPABILITIES.UPDATE_TICKET]: 'แก้ไขเคส',
    [CAPABILITIES.VIEW_ALL_TICKETS]: 'ดูเคสทั้งหมด',
    [CAPABILITIES.ADD_COMMENT]: 'ตอบกลับความคิดเห็นและกิจกรรม',
    [CAPABILITIES.CREATE_OWN_TICKET]: 'แจ้งเคส',
    [CAPABILITIES.VIEW_OWN_TICKETS]: 'ดูเคสของฉัน',
    [CAPABILITIES.SUBMIT_SATISFACTION_SURVEY]: 'ประเมินความพึงพอใจ',
    [CAPABILITIES.VIEW_OWN_CREATED_TICKETS]: 'ดูเคสที่ตัวเองบันทึกแทนลูกค้า',
    [CAPABILITIES.MANAGE_USERS]: 'จัดการผู้ใช้',
    [CAPABILITIES.MANAGE_PROJECTS]: 'จัดการโครงการ',
    [CAPABILITIES.MANAGE_SETTINGS]: 'ตั้งค่าระบบ',
  };

  return displayNames[capability] || capability;
}

// ========================================
// 🎯 Role Helper Functions (for backward compatibility)
// ========================================

/**
 * Tier1 = มี capability ปิดเคส
 */
export function isTier1(user: User | null | undefined): boolean {
  return can(user, CAPABILITIES.CLOSE_TICKET);
}

/**
 * Pure Staff = บันทึกเคสแทนลูกค้าได้ แต่รับเคสไม่ได้
 */
export function isPureStaff(user: User | null | undefined): boolean {
  return can(user, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER) && !can(user, CAPABILITIES.ACCEPT_TICKET);
}

/**
 * Customer = แจ้งเคสเองได้ และไม่มีสิทธิ์ดูเคสทั้งหมด
 */
export function isCustomer(user: User | null | undefined): boolean {
  return can(user, CAPABILITIES.CREATE_OWN_TICKET) && !can(user, CAPABILITIES.VIEW_ALL_TICKETS);
}

/**
 * Admin = มีสิทธิ์จัดการผู้ใช้
 */
export function isAdmin(user: User | null | undefined): boolean {
  return can(user, CAPABILITIES.MANAGE_USERS);
}

/**
 * Operator = ผู้ปฏิบัติงานฝั่งระบบ (tier1/supervisor/tier2/tier3/admin)
 * ใช้ capability-based เท่านั้น เพื่อเป็น SSoT (ไม่ hardcode role list ใน UI)
 */
export function isOperator(user: User | null | undefined): boolean {
  if (!user) return false;

  return canAny(user, [
    CAPABILITIES.ACCEPT_TICKET,
    CAPABILITIES.UPDATE_TICKET,
    CAPABILITIES.ESCALATE_TICKET,
    CAPABILITIES.VIEW_ALL_TICKETS,
  ]);
}
