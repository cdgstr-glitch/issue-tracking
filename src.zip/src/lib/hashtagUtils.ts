// Utility functions for extracting and working with hashtags

/**
 * Extract hashtags from content (both HTML and plain text)
 * Looks for:
 * 1. <span class="hashtag-mention" data-hashtag="..."> (Rich Text Editor format)
 * 2. Plain text hashtags like #ด่วน #การเข้าถึง
 */
export function extractHashtags(content: string): string[] {
  if (!content) return [];
  
  const hashtags: string[] = [];
  
  // Extract from HTML (Rich Text Editor format)
  const htmlRegex = /<span[^>]*class="[^"]*hashtag-mention[^"]*"[^>]*data-hashtag="([^"]+)"[^>]*>/g;
  let match;
  while ((match = htmlRegex.exec(content)) !== null) {
    if (match[1] && !hashtags.includes(match[1])) {
      hashtags.push(match[1]);
    }
  }
  
  // Extract from plain text (like #ด่วน #การเข้าถึง)
  // Supports Thai, English, numbers
  const plainTextRegex = /#([\u0E00-\u0E7Fa-zA-Z0-9_]+)/g;
  while ((match = plainTextRegex.exec(content)) !== null) {
    const tag = '#' + match[1];
    if (!hashtags.includes(tag)) {
      hashtags.push(tag);
    }
  }
  
  return hashtags;
}

/**
 * Get all unique hashtags from a list of tickets, sorted by frequency (most used first)
 */
export function getAllHashtags(tickets: any[]): string[] {
  const hashtagCounts = new Map<string, number>();
  
  tickets.forEach(ticket => {
    // Extract from title
    if (ticket.title) {
      const titleHashtags = extractHashtags(ticket.title);
      titleHashtags.forEach(tag => {
        hashtagCounts.set(tag, (hashtagCounts.get(tag) || 0) + 1);
      });
    }
    
    // Extract from description
    if (ticket.description) {
      const descHashtags = extractHashtags(ticket.description);
      descHashtags.forEach(tag => {
        hashtagCounts.set(tag, (hashtagCounts.get(tag) || 0) + 1);
      });
    }
  });
  
  // Sort by frequency (most used first), then alphabetically
  return Array.from(hashtagCounts.entries())
    .sort((a, b) => {
      if (b[1] !== a[1]) {
        return b[1] - a[1]; // Sort by count descending
      }
      return a[0].localeCompare(b[0], 'th'); // Then sort alphabetically
    })
    .map(entry => entry[0]);
}

/**
 * Check if a ticket has a specific hashtag
 */
export function ticketHasHashtag(ticket: any, hashtag: string): boolean {
  // Check in title
  if (ticket.title) {
    const titleHashtags = extractHashtags(ticket.title);
    if (titleHashtags.includes(hashtag)) return true;
  }
  
  // Check in description
  if (ticket.description) {
    const descHashtags = extractHashtags(ticket.description);
    if (descHashtags.includes(hashtag)) return true;
  }
  
  return false;
}

/**
 * Render hashtags as badges for display
 */
export function renderHashtagBadges(htmlContent: string): React.ReactNode {
  const hashtags = extractHashtags(htmlContent);
  return hashtags;
}

/**
 * Remove all hashtags from content (for display purposes)
 */
export function removeHashtags(content: string): string {
  if (!content) return '';
  
  // Remove plain text hashtags (like #ด่วน #การเข้าถึง)
  // Supports Thai, English, numbers
  return content.replace(/#[\u0E00-\u0E7Fa-zA-Z0-9_]+/g, '').trim();
}
