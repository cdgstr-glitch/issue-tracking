import { db } from '../lib/mockDb/client';
import { Ticket, CreatedByType } from '../types';

/**
 * ✅ Enrich Tickets with createdByType and createdByStaffName
 *
 * Logic:
 * - channel = 'web' → createdByType = 'customer_self'
 * - channel = 'phone' | 'email' | 'line' → createdByType = 'staff_on_behalf'
 *
 * Source of staff name:
 * - ticket.createdByName (ถ้ามี) → ใช้ก่อน
 * - fallback: ใช้ Timeline event แรกของ ticket (db.timeline.getByTicketId)
 */
export function enrichTicketsWithCreatorType(tickets: Ticket[]): Ticket[] {
  return tickets.map(ticket => {
    let createdByType: CreatedByType;
    let createdByStaffName: string | undefined;

    if (ticket.channel === 'web') {
      createdByType = 'customer_self';
      createdByStaffName = undefined;
    } else {
      createdByType = 'staff_on_behalf';

      // ✅ 1) ใช้ createdByName ถ้ามี
      if (ticket.createdByName && ticket.createdByName.trim() !== '') {
        createdByStaffName = ticket.createdByName;
      } else {
        // ✅ 2) fallback: เอาจาก timeline event แรก (ที่เก่าที่สุด)
        const events = db.timeline.getByTicketId(ticket.id) || [];
        const firstEvent = events.length > 0 ? events[0] : undefined;

        // รองรับหลายชื่อ field (เผื่อ schema ต่างกันใน mock)
        const nameFromEvent =
          (firstEvent as any)?.performedByName ||
          (firstEvent as any)?.userNameLegacy ||
          (firstEvent as any)?.userName ||
          (firstEvent as any)?.user ||
          undefined;

        // กัน System/ว่าง
        if (
          nameFromEvent &&
          typeof nameFromEvent === 'string' &&
          nameFromEvent.trim() !== '' &&
          nameFromEvent.toLowerCase() !== 'system'
        ) {
          createdByStaffName = nameFromEvent.trim();
        } else {
          createdByStaffName = 'เจ้าหน้าที่ CDGS';
        }
      }
    }

    return {
      ...ticket,
      createdByType,
      createdByStaffName,
    };
  });
}

/**
 * ✅ Helper: สร้าง note ตาม createdByType
 */
export function getCreatorNote(ticket: Ticket): string {
  if (ticket.createdByType === 'customer_self') {
    return 'ลูกค้าเปิดเคสผ่านระบบด้วยตัวเอง';
  }
  if (ticket.createdByType === 'staff_on_behalf') {
    const staffName = ticket.createdByStaffName || 'เจ้าหน้าที่';
    return `เจ้าหน้าที่ ${staffName} บันทึกเคสแทนลูกค้า`;
  }
  return 'เปิดเคส';
}
