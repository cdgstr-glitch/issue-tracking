/**
 * 🔄 Backward Compatibility Wrapper
 * 
 * @deprecated ไฟล์นี้ถูกย้ายไปที่ /lib/mockData/users.ts แล้ว
 * @description Re-export จาก /lib/mockData/users.ts เพื่อ backward compatibility
 * 
 * ⚠️ กรุณาอัพเดท import เป็น:
 *   import { ... } from '@/lib/mockData'
 */

export * from './mockDb/data/users';
