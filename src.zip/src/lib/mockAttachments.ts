/**
 * 🔄 Backward Compatibility Wrapper
 * 
 * @deprecated ไฟล์นี้ถูก refactor และย้ายไปที่ /lib/mockData/helpers/attachments.ts แล้ว
 * @description Re-export จาก /lib/mockData/helpers/attachments.ts เพื่อ backward compatibility
 * 
 * ⚠️ สำหรับการใช้งานใหม่ กรุณาอัพเดท import เป็น:
 *   import { mockAttachments, sarabanAttachments } from '@/lib/mockData'
 */

// Re-export everything from new location
export * from './mockDb/data/attachments';
