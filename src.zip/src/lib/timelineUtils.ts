import { TimelineEvent } from '../types';

export type UserRole = 'customer' | 'staff' | 'tier1' | 'tier2' | 'tier3' | 'admin' | 'supervisor';

/**
 * กรอง Timeline events ตาม role ของผู้ใช้
 * - Customer: เห็นแค่ created, resolved, closed และความคิดเห็นสาธารณะ + event แรกของแต่ละ tier
 * - Staff/Tier/Admin: เห็นทุกอย่าง
 */
export function filterTimelineByRole(
  events: TimelineEvent[],
  userRole: UserRole
): TimelineEvent[] {
  // ลูกค้าเห็นเฉพาะ public events
  if (userRole === 'customer') {
    const filtered = events.filter(event => {
      // กรองเฉพาะ event ที่ไม่ใช่ internal
      if (event.isInternal) return false;
      
      // กรอง status_change: แสดง new, resolved, closed + tier1/tier2/tier3/in_progress (แต่จะปรับข้อความ)
      if (event.type === 'status_change') {
        const allowedStatuses = ['new', 'resolved', 'closed', 'tier1', 'tier2', 'tier3', 'in_progress'];
        return event.status ? allowedStatuses.includes(event.status) : false;
      }
      
      // แสดง comment, attachment และ created ที่ไม่ใช่ internal
      const allowedTypes: TimelineEvent['type'][] = ['comment', 'attachment', 'created'];
      return allowedTypes.includes(event.type);
    });
    
    // กรอง tier events: เก็บเฉพาะ tier event แรกของแต่ละ tier level
    const seenTiers = new Set<string>();
    return filtered.filter(event => {
      if (event.type === 'status_change' && event.status) {
        // ถ้าเป็น tier1/tier2/tier3 หรือ in_progress
        if (['tier1', 'tier2', 'tier3', 'in_progress'].includes(event.status)) {
          if (seenTiers.has(event.status)) {
            return false; // ซ่อน tier event ซ้ำ
          }
          seenTiers.add(event.status);
        }
      }
      return true;
    });
  }
  
  // เจ้าหน้าที่เห็นทุกอย่าง
  return events;
}

/**
 * ปรับข้อความ Timeline ให้เหมาะกับลูกค้า
 * - ซ่อนชื่อเจ้าหน้าที่
 * - เปลี่ยนคำศัพท์ภายใน
 */
export function sanitizeTimelineForCustomer(
  events: TimelineEvent[],
  customerName?: string
): TimelineEvent[] {
  return events.map(event => {
    // Determine the user name from the event
    const eventUserName = event.user || event.userName || '';
    
    // Check if the event actor is the customer
    const isCustomerAction = customerName && (
      eventUserName === customerName || 
      eventUserName.includes(customerName)
    );

    return {
      ...event,
      // If it's the customer, keep their name. If it's staff, mask as "เจ้าหน้าที่"
      user: isCustomerAction ? eventUserName : 'เจ้าหน้าที่', 
      userName: isCustomerAction ? eventUserName : 'เจ้าหน้าที่',
      description: sanitizeDescription(event.description, event.type)
    };
  });
}

/**
 * ปรับคำอธิบาย event ให้เหมาะกับลูกค้า
 */
function sanitizeDescription(description: string, type: TimelineEvent['type']): string {
  // สำหรับ status_change
  if (type === 'status_change') {
    if (description.includes('สร้างเคส')) {
      return 'เคสของคุณถูกสร้างเรียบร้อยแล้ว';
    }
    if (description.includes('แก้ไข') || description.includes('resolved')) {
      return 'เคสของคุณได้รับการแก้ไขเรียบร้อยแล้ว';
    }
    if (description.includes('ปิดเคส') || description.includes('closed')) {
      return 'เคสของคุณถูกปิดเรียบร้อยแล้ว';
    }
    // เพิ่ม: แปลง tier1/tier2/tier3/in_progress
    if (description.includes('Tier 1') || description.includes('tier1')) {
      return 'เจ้าหน้าที่กำลังดำเนินการเคสของคุณ';
    }
    if (description.includes('Tier 2') || description.includes('tier2')) {
      return '���จ้าหน้าที่ผู้เชี่ยวชาญกำลังดำเนินการเคสของคุณ';
    }
    if (description.includes('Tier 3') || description.includes('tier3')) {
      return 'ทีมผู้เชี่ยวชาญขั้นสูงกำลังดำเนินการเคสของคุณ';
    }
    if (description.includes('กำลัง') || description.includes('in_progress')) {
      return 'เจ้าหน้าที่กำลังแก้ไขปัญหาของคุณ';
    }
  }
  
  // สำหรับ comment - ใช้ตามเดิม
  if (type === 'comment') {
    return description;
  }
  
  // สำหรับ attachment
  if (type === 'attachment') {
    return 'แนบไฟล์';
  }
  
  // Default: กำลังดำเนินการ
  return 'กำลังดำเนินการ';
}

/**
 * แปลง status ภายในเป็นข้อความที่ลูกค้าเข้าใจ
 */
export function getCustomerFacingStatus(status: string): string {
  const statusMap: Record<string, string> = {
    'new': 'รอดำเนินการ',
    'tier1': 'กำลังดำเนินการ',
    'tier2': 'กำลังดำเนินการ',
    'tier3': 'กำลังดำเนินการ',
    'in_progress': 'กำลังแก้ไข',
    'on_hold': 'รอข้อมูลเพิ่มเติม',
    'pending_closure': 'รอการตรวจสอบ',
    'resolved': 'แก้ไขเสร็จสิ้น',
    'closed': 'ปิดเคส'
  };
  
  return statusMap[status] || status;
}