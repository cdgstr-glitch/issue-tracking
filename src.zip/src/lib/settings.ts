import { constants } from './mockDb/data/constants';
import { TicketStatus } from '../types';

export interface StatusConfig {
  label: string;
  customerLabel?: string;
  color: string;
  customerColor?: string;
  description?: string;
}

const STORAGE_KEY = 'CDGS_TICKET_STATUS_CONFIG';

export function getStatusConfig(status: TicketStatus): StatusConfig {
  // Default config
  const defaultConfig = constants.TICKET_STATUSES[status] as any;
  
  if (typeof window === 'undefined') {
    return defaultConfig;
  }

  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed[status]) {
        // Merge saved config with default to ensure all fields exist
        return { ...defaultConfig, ...parsed[status] };
      }
    }
  } catch (error) {
    console.warn('Failed to load status config from localStorage:', error);
  }

  return defaultConfig;
}

export function getAllStatusConfigs(): Record<TicketStatus, StatusConfig> {
  const result: any = { ...constants.TICKET_STATUSES };
  
  if (typeof window === 'undefined') {
    return result;
  }

  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Merge all keys
      Object.keys(parsed).forEach((key) => {
        if (result[key]) {
          result[key] = { ...result[key], ...parsed[key] };
        }
      });
    }
  } catch (error) {
    console.warn('Failed to load all status configs:', error);
  }

  return result;
}

export function saveStatusConfig(configs: Record<string, Partial<StatusConfig>>) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(configs));
  
  // Dispatch event for components to listen if needed (optional)
  window.dispatchEvent(new Event('status-config-updated'));
}

export function resetStatusConfig() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEY);
  window.dispatchEvent(new Event('status-config-updated'));
}
