// src/lib/mockDb/client.ts
// ✅ Issue Tracking mockDb client (Laravel-ready / relational-first / single source of truth)
//
// NON-NEGOTIABLE RULES enforced:
// 1) Export/Import standard: export const db ... / import { db } ...
// 2) Relational-first: FK + pivot, no denormalized storage
// 3) Single Source of Truth: client.ts is the only entry point
// 4) No quick fix: fix root-cause at data layer, not UI workarounds

import type {
  Attachment,
  Comment,
  Customer,
  Escalation,
  Notification,
  Organization,
  Product,
  Project,
  SatisfactionSurvey,
  SLASetting,
  SLAScope,
  Tag,
  Ticket,
  TicketProduct,
  TicketTag,
  TimelineEvent,
  User,
  UserOrganization,
} from '../../types';

import type { ProjectProduct } from './data/project_products';

import { constants } from './data/constants';

import { organizations as seedOrganizations } from './data/organizations';
import { projects as seedProjects } from './data/projects';
import { customers as seedCustomers } from './data/customers';
import { users as seedUsers } from './data/users';

import { tickets as seedTickets } from './data/tickets';
import { products as seedProducts } from './data/products';
import { tags as seedTags } from './data/tags';

import { ticketProducts as seedTicketProducts } from './data/ticket_products';
import { projectProducts as seedProjectProducts } from './data/project_products';
import { ticketTags as seedTicketTags } from './data/ticket_tags';
import { userOrganizations as seedUserOrganizations } from './data/user_organizations';

import { timeline as seedTimeline } from './data/timeline';
import { comments as seedComments } from './data/comments';
import { attachments as seedAttachments } from './data/attachments';
import { escalations as seedEscalations } from './data/escalations';

import { slaSettings as seedSlaSettings } from './data/slaSettings';
import { notifications as seedNotifications } from './data/notifications';
import { satisfactionSurveys as seedSatisfactionSurveys } from './data/satisfactionSurveys';

// =========================
// Internal mutable storage (normalized tables)
// =========================
let organizations: Organization[] = [...(seedOrganizations as any)];
let projects: Project[] = [...(seedProjects as any)];
let customers: Customer[] = [...(seedCustomers as any)];
let users: User[] = [...(seedUsers as any)];

let tickets: Ticket[] = [...(seedTickets as any)];
let products: Product[] = [...(seedProducts as any)];
let tags: Tag[] = [...(seedTags as any)];

let ticketProducts: TicketProduct[] = [...(seedTicketProducts as any)];
let projectProducts: ProjectProduct[] = [...(seedProjectProducts as any)];
let ticketTags: TicketTag[] = [...(seedTicketTags as any)];
let userOrganizations: UserOrganization[] = [...(seedUserOrganizations as any)];

let timeline: TimelineEvent[] = [...(seedTimeline as any)];
let comments: Comment[] = [...(seedComments as any)];
let attachments: Attachment[] = [...(seedAttachments as any)];
let escalations: Escalation[] = [...(seedEscalations as any)];

let slaSettings: SLASetting[] = [...(seedSlaSettings as any)];
let notifications: Notification[] = [...(seedNotifications as any)];
let satisfactionSurveys: SatisfactionSurvey[] = [...(seedSatisfactionSurveys as any)];

// =========================
// Utilities (MUST exist) ✅
// =========================
function deepFreeze<T>(obj: T): T {
  if (!obj || typeof obj !== 'object') return obj;
  Object.freeze(obj);
  for (const key of Object.keys(obj as any)) {
    const value = (obj as any)[key];
    if (value && typeof value === 'object' && !Object.isFrozen(value)) deepFreeze(value);
  }
  return obj;
}

function guardObject<T extends Record<string, any>>(label: string, obj: T): T {
  return new Proxy(obj, {
    set() {
      throw new Error(`[mockDb] Illegal mutation attempted on ${label}. Use db.*.add/update methods.`);
    },
  });
}

function assertUniqueIds(label: string, rows: Array<{ id: string }>) {
  const seen = new Set<string>();
  for (const r of rows) {
    const id = String((r as any).id);
    if (!id) throw new Error(`[mockDb] Missing id in ${label}`);
    if (seen.has(id)) throw new Error(`[mockDb] Duplicate id in ${label}: ${id}`);
    seen.add(id);
  }
}

// =========================
// Relationship helpers (pivot)
// =========================
function getProductIdsByProjectId(projectId: string): string[] {
  const pid = String(projectId);
  return projectProducts
    .filter((pp: any) => String(pp.projectId) === pid)
    .map((pp: any) => String(pp.productId));
}

function getProductIdsByTicketId(ticketId: string): string[] {
  const tid = String(ticketId);
  return ticketProducts
    .filter((tp: any) => String(tp.ticketId) === tid)
    .map((tp: any) => String(tp.productId));
}

function getTagIdsByTicketId(ticketId: string): string[] {
  const tid = String(ticketId);
  return ticketTags
    .filter((tt: any) => String(tt.ticketId) === tid)
    .map((tt: any) => String(tt.tagId));
}

// =========================
// Integrity validation (FK-first / fail fast)
// =========================
function validateIntegrityInternal() {
  assertUniqueIds('organizations', organizations as any);
  assertUniqueIds('projects', projects as any);
  assertUniqueIds('products', products as any);
  assertUniqueIds('tickets', tickets as any);
  assertUniqueIds('users', users as any);
  assertUniqueIds('customers', customers as any);
  assertUniqueIds('tags', tags as any);

  assertUniqueIds('project_products', projectProducts as any);
  assertUniqueIds('ticket_products', ticketProducts as any);
  assertUniqueIds('ticket_tags', ticketTags as any);
  assertUniqueIds('user_organizations', userOrganizations as any);

  // projects.organizationId -> organizations.id
  for (const p of projects as any[]) {
    if (p.organizationId && !organizations.some((o: any) => String(o.id) === String(p.organizationId))) {
      throw new Error(`[mockDb] FK missing: projects.organizationId=${p.organizationId}`);
    }
  }

  // tickets.projectId -> projects.id  ✅ Laravel-ready: nullable FK
  // - web tickets can be created with only product (no project)
  // - If projectId is present, it MUST reference projects.id
  for (const t of tickets as any[]) {
    const rawPid = (t as any).projectId;

    // allow null/undefined/empty string
    const hasPid =
      rawPid !== null &&
      rawPid !== undefined &&
      String(rawPid).trim() !== '';

    if (hasPid) {
      if (!projects.some((p: any) => String(p.id) === String(rawPid))) {
        throw new Error(`[mockDb] FK missing: tickets.projectId=${rawPid}`);
      }
    }
  }

  // tickets.organizationId -> organizations.id
  for (const t of tickets as any[]) {
    if (t.organizationId && !organizations.some((o: any) => String(o.id) === String(t.organizationId))) {
      throw new Error(`[mockDb] FK missing: tickets.organizationId=${t.organizationId}`);
    }
  }

  // tickets.customerId (if present) -> customers.id
  for (const t of tickets as any[]) {
    if (t.customerId && !customers.some((c: any) => String(c.id) === String(t.customerId))) {
      throw new Error(`[mockDb] FK missing: tickets.customerId=${t.customerId}`);
    }
  }

  // tickets.assignedTo (if present) -> users.id
  for (const t of tickets as any[]) {
    if (t.assignedTo && !users.some((u: any) => String(u.id) === String(t.assignedTo))) {
      throw new Error(`[mockDb] FK missing: tickets.assignedTo=${t.assignedTo}`);
    }
  }

  // project_products.projectId -> projects.id & productId -> products.id
  for (const pp of projectProducts as any[]) {
    if (!projects.some((p: any) => String(p.id) === String(pp.projectId))) {
      throw new Error(`[mockDb] FK missing: project_products.projectId=${pp.projectId}`);
    }
    if (!products.some((p: any) => String(p.id) === String(pp.productId))) {
      throw new Error(`[mockDb] FK missing: project_products.productId=${pp.productId}`);
    }
  }

  // ticket_products.ticketId -> tickets.id & productId -> products.id
  for (const tp of ticketProducts as any[]) {
    if (!tickets.some((t: any) => String(t.id) === String(tp.ticketId))) {
      throw new Error(`[mockDb] FK missing: ticket_products.ticketId=${tp.ticketId}`);
    }
    if (!products.some((p: any) => String(p.id) === String(tp.productId))) {
      throw new Error(`[mockDb] FK missing: ticket_products.productId=${tp.productId}`);
    }
  }

  // ticket_tags.ticketId -> tickets.id & tagId -> tags.id
  for (const tt of ticketTags as any[]) {
    if (!tickets.some((t: any) => String(t.id) === String(tt.ticketId))) {
      throw new Error(`[mockDb] FK missing: ticket_tags.ticketId=${tt.ticketId}`);
    }
    if (!tags.some((tg: any) => String(tg.id) === String(tt.tagId))) {
      throw new Error(`[mockDb] FK missing: ticket_tags.tagId=${tt.tagId}`);
    }
  }

  // user_organizations.userId -> users.id & organizationId -> organizations.id
  for (const uo of userOrganizations as any[]) {
    if (!users.some((u: any) => String(u.id) === String(uo.userId))) {
      throw new Error(`[mockDb] FK missing: user_organizations.userId=${uo.userId}`);
    }
    if (uo.organizationId && !organizations.some((o: any) => String(o.id) === String(uo.organizationId))) {
      throw new Error(`[mockDb] FK missing: user_organizations.organizationId=${uo.organizationId}`);
    }
  }

  // timeline.ticketId -> tickets.id
  for (const e of timeline as any[]) {
    if (e.ticketId && !tickets.some((t: any) => String(t.id) === String(e.ticketId))) {
      throw new Error(`[mockDb] FK missing: timeline.ticketId=${e.ticketId}`);
    }
  }

  // comments.ticketId -> tickets.id
  for (const c of comments as any[]) {
    if (c.ticketId && !tickets.some((t: any) => String(t.id) === String(c.ticketId))) {
      throw new Error(`[mockDb] FK missing: comments.ticketId=${c.ticketId}`);
    }
  }

  // attachments.ticketId -> tickets.id
  for (const a of attachments as any[]) {
    if (a.ticketId && !tickets.some((t: any) => String(t.id) === String(a.ticketId))) {
      throw new Error(`[mockDb] FK missing: attachments.ticketId=${a.ticketId}`);
    }
  }

  // escalations.ticketId -> tickets.id
  for (const e of escalations as any[]) {
    if (e.ticketId && !tickets.some((t: any) => String(t.id) === String(e.ticketId))) {
      throw new Error(`[mockDb] FK missing: escalations.ticketId=${e.ticketId}`);
    }
  }

  // notifications: polymorphic recipient FK validation
  for (const n of notifications as any[]) {
    const rType = String(n.recipientType ?? '');
    const rId = String(n.recipientId ?? '');
    if (!rType || !rId) {
      throw new Error(`[mockDb] notifications missing recipient: id=${n.id}`);
    }

    if (rType === 'user') {
      if (!users.some((u: any) => String(u.id) === rId)) {
        throw new Error(`[mockDb] FK missing: notifications.recipientId=${rId} (type=user)`);
      }
    } else if (rType === 'customer') {
      if (!customers.some((c: any) => String(c.id) === rId)) {
        throw new Error(`[mockDb] FK missing: notifications.recipientId=${rId} (type=customer)`);
      }
    } else {
      throw new Error(`[mockDb] Invalid notifications.recipientType=${rType} (id=${n.id})`);
    }
  }

  // satisfactionSurveys.ticketId -> tickets.id (if field exists)
  for (const s of satisfactionSurveys as any[]) {
    if (s.ticketId && !tickets.some((t: any) => String(t.id) === String(s.ticketId))) {
      throw new Error(`[mockDb] FK missing: satisfactionSurveys.ticketId=${s.ticketId}`);
    }
  }
}

// fail fast at startup
validateIntegrityInternal();

// =========================
// Rule-1 compliance: destructure constants used in dbRaw object literal
// (NO constants.X inside object literal)
// =========================
const {
  TICKET_CHANNELS,
  TICKET_CATEGORIES,
  TICKET_PRIORITIES,
  TICKET_TYPES,
  TICKET_STATUSES,
  PRODUCT_CATEGORIES,
  DEFAULT_SLA_CONFIG,
} = constants;

// =========================
// ✅ Read-model (Hydrated) Ticket shape
// - arrays must NEVER be undefined (prevents ".length" crashes)
// =========================
export type HydratedTicket = Ticket & {
  organization?: Organization;
  project?: Project;
  customer?: Customer;
  assignedToUser?: User | null;

  products: Product[];
  tags: Tag[];
  timeline: TimelineEvent[];
  comments: Comment[];
  attachments: Attachment[];
  escalations: Escalation[];

  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  department?: string;
  projectName?: string;
  projectCode?: string;
  organizationName?: string;
  organizationShortName?: string;  // ✅ SSoT: flat field จาก organization.organizationShortName
  assignedToName?: string;
};

function hydrateTicketRow(row: Ticket): HydratedTicket {
  const organization =
    organizations.find((o: any) => String(o.id) === String((row as any).organizationId)) ?? undefined;

  // ✅ projectId is nullable FK; when null => project undefined
  const project =
    ((row as any).projectId !== null && (row as any).projectId !== undefined && String((row as any).projectId).trim() !== '')
      ? (projects.find((p: any) => String(p.id) === String((row as any).projectId)) ?? undefined)
      : undefined;

  const customer =
    customers.find((c: any) => String(c.id) === String((row as any).customerId)) ?? undefined;

  const assignedToUser =
    (row as any).assignedTo
      ? (users.find((u: any) => String(u.id) === String((row as any).assignedTo)) ?? null)
      : null;

  const productIds = getProductIdsByTicketId(String(row.id));
  const hydratedProducts = products.filter((p: any) => productIds.includes(String(p.id)));

  const tagIds = getTagIdsByTicketId(String(row.id));
  const hydratedTags = tags.filter((tg: any) => tagIds.includes(String(tg.id)));

  const hydratedTimeline = (timeline ?? [])
    .filter((e: any) => String(e.ticketId) === String(row.id))
    .sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  // ✅ SSoT: resolve author name+role จาก FK (authorUserId / authorCustomerId)
  // ไม่เก็บ author เป็น flat field ใน data layer — hydrate ที่นี่เท่านั้น
  const hydratedComments = (comments ?? [])
    .filter((c: any) => String(c.ticketId) === String(row.id))
    .sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
    .map((c: any) => {
      let author: string | undefined;
      let authorRole: string | undefined;
      if (c.authorUserId) {
        const u = users.find((u: any) => String(u.id) === String(c.authorUserId));
        author = (u as any)?.fullName;
        authorRole = (u as any)?.primaryRole;
      } else if (c.authorCustomerId) {
        const cust = customers.find((cu: any) => String(cu.id) === String(c.authorCustomerId));
        author = (cust as any)?.fullName;
        authorRole = 'customer';
      }
      return { ...c, author, authorRole };
    });

  const hydratedAttachments = (attachments ?? []).filter(
    (a: any) => String(a.ticketId) === String(row.id),
  );

  const hydratedEscalations = (escalations ?? [])
    .filter((e: any) => String(e.ticketId) === String(row.id))
    .sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  return {
    ...row,
    organization,
    project,
    customer,
    assignedToUser,

    products: hydratedProducts,
    tags: hydratedTags,
    timeline: hydratedTimeline,
    comments: hydratedComments,
    attachments: hydratedAttachments,
    escalations: hydratedEscalations,

    customerName: (customer as any)?.fullName,
    customerEmail: (customer as any)?.email,
    customerPhone: (customer as any)?.phone,
    department: (customer as any)?.department,
    projectName: (project as any)?.projectName ?? (project as any)?.name,
    projectCode: (project as any)?.projectCode ?? (project as any)?.code,
    organizationName: (organization as any)?.organizationName ?? (organization as any)?.name,
    organizationShortName: (organization as any)?.organizationShortName,  // ✅ SSoT: map flat field
    assignedToName: (assignedToUser as any)?.fullName,
  };
}

// =========================
// dbRaw: single entry point API
// =========================
const dbRaw = {
  // keep constants for debugging/reads only (not referenced as constants.X in object literal)
  constants,

  master: {
    getChannels: () => TICKET_CHANNELS,
    getCategories: () => TICKET_CATEGORIES,
    getPriorities: () => TICKET_PRIORITIES,
    getTypes: () => TICKET_TYPES,
    getStatuses: () => TICKET_STATUSES,
    getProductCategories: () => PRODUCT_CATEGORIES,
  },

  organizations: {
    getAll: (): Organization[] => [...organizations],
    getById: (id: string): Organization | undefined =>
      organizations.find((o: any) => String(o.id) === String(id)),
    add: (row: Organization) => {
      organizations = [...organizations, row];
      validateIntegrityInternal();
    },
  },

  projects: {
    getAll: (): Project[] => [...projects],
    getById: (id: string): Project | undefined => projects.find((p: any) => String(p.id) === String(id)),

    getByOrganizationId: (organizationId: string): Project[] =>
      projects.filter((p: any) => String(p.organizationId) === String(organizationId)),

    // ✅ filter: only show projects that have products via pivot (Laravel-ready)
    hasProducts: (projectId: string): boolean => getProductIdsByProjectId(String(projectId)).length > 0,

    getSelectableByOrganizationId: (organizationId: string): Project[] =>
      projects
        .filter((p: any) => String(p.organizationId) === String(organizationId))
        .filter((p: any) => getProductIdsByProjectId(String(p.id)).length > 0),

    add: (row: Project) => {
      projects = [...projects, row];
      validateIntegrityInternal();
    },
  },

  customers: {
    getAll: (): Customer[] => [...customers],
    getById: (id: string): Customer | undefined =>
      customers.find((c: any) => String(c.id) === String(id)),
    add: (row: Customer) => {
      customers = [...customers, row];
      validateIntegrityInternal();
    },
  },

  users: {
    getAll: (): User[] => [...users],
    getById: (id: string): User | undefined => users.find((u: any) => String(u.id) === String(id)),
    add: (row: User) => {
      users = [...users, row];
      validateIntegrityInternal();
    },
  },

  products: {
    getAll: (): Product[] => [...products],
    getById: (id: string): Product | undefined =>
      products.find((p: any) => String(p.id) === String(id)),

    // relation read helper
    getByProjectId: (projectId: string): Product[] => {
      const ids = getProductIdsByProjectId(String(projectId));
      return products.filter((p: any) => ids.includes(String(p.id)));
    },

    add: (row: Product) => {
      products = [...products, row];
      validateIntegrityInternal();
    },
  },

  tags: {
    getAll: (): Tag[] => [...tags],
    getById: (id: string): Tag | undefined => tags.find((t: any) => String(t.id) === String(id)),
    add: (row: Tag) => {
      tags = [...tags, row];
      validateIntegrityInternal();
    },
  },

  relations: {
    getProductsByProjectId: (projectId: string): Product[] => {
      const ids = getProductIdsByProjectId(String(projectId));
      return products.filter((p: any) => ids.includes(String(p.id)));
    },
    getProductsByTicketId: (ticketId: string): Product[] => {
      const ids = getProductIdsByTicketId(String(ticketId));
      return products.filter((p: any) => ids.includes(String(p.id)));
    },
    getTagsByTicketId: (ticketId: string): Tag[] => {
      const ids = getTagIdsByTicketId(String(ticketId));
      return tags.filter((t: any) => ids.includes(String(t.id)));
    },
  },

  tickets: {
    // =========================
    // ✅ WRITE / STORAGE (Raw)
    // =========================
    getAllRaw: (): Ticket[] => [...tickets],
    getByIdRaw: (id: string): Ticket | undefined =>
      tickets.find((t: any) => String(t.id) === String(id)),

    // =========================
    // ✅ READ / RESOURCE (Hydrated)
    // =========================
    // ✅ SSoT: STUB tickets คือ internal FK seed เท่านั้น ไม่ใช่เคสจริง
    // กรอง ticketNumber ที่ขึ้นต้นด้วย 'STUB-' ออกจาก result ทุก query
    getAll: (): HydratedTicket[] =>
      [...tickets]
        .filter((t: any) => !String(t.ticketNumber).startsWith('STUB-'))
        .map(hydrateTicketRow),

    getById: (id: string): HydratedTicket | null => {
      const row = tickets.find((t: any) => String(t.id) === String(id));
      return row ? hydrateTicketRow(row) : null;
    },

    // ✅ Legacy contract used by pages
    getHydratedById: (id: string): HydratedTicket | null => {
      const row = tickets.find((t: any) => String(t.id) === String(id));
      return row ? hydrateTicketRow(row) : null;
    },

    getByOrganizationId: (organizationId: string): HydratedTicket[] =>
      tickets
        .filter((t: any) => String(t.organizationId) === String(organizationId))
        .map(hydrateTicketRow),

    getByProjectId: (projectId: string): HydratedTicket[] =>
      tickets
        .filter((t: any) => (t as any).projectId && String((t as any).projectId) === String(projectId))
        .map(hydrateTicketRow),

    add: (row: Ticket) => {
      tickets = [...tickets, row];
      validateIntegrityInternal();
    },
  },

  projectProducts: {
    getAll: (): ProjectProduct[] => [...projectProducts],
    getByProjectId: (projectId: string): ProjectProduct[] =>
      projectProducts.filter((x: any) => String(x.projectId) === String(projectId)),
    add: (row: ProjectProduct) => {
      projectProducts = [...projectProducts, row];
      validateIntegrityInternal();
    },
    removeByProjectId: (projectId: string) => {
      projectProducts = projectProducts.filter((x: any) => String(x.projectId) !== String(projectId));
      validateIntegrityInternal();
    },
  },

  ticketProducts: {
    getAll: (): TicketProduct[] => [...ticketProducts],
    getByTicketId: (ticketId: string): TicketProduct[] =>
      ticketProducts.filter((x: any) => String(x.ticketId) === String(ticketId)),
    add: (row: TicketProduct) => {
      ticketProducts = [...ticketProducts, row];
      validateIntegrityInternal();
    },
    removeByTicketId: (ticketId: string) => {
      ticketProducts = ticketProducts.filter((x: any) => String(x.ticketId) !== String(ticketId));
      validateIntegrityInternal();
    },
    // ✅ SSoT: replace all products for a ticket (used after accept triage)
    // ลบ pivot rows เดิมของ ticketId แล้วแทรก productIds ใหม่
    replaceForTicket: (ticketId: string, productIds: string[]) => {
      ticketProducts = ticketProducts.filter((x: any) => String(x.ticketId) !== String(ticketId));
      const now = new Date().toISOString();
      productIds.forEach((productId, i) => {
        ticketProducts = [...ticketProducts, {
          id: `tp-${ticketId}-${i}-${Date.now()}`,
          ticketId,
          productId,
          createdAt: now,
        } as any];
      });
      validateIntegrityInternal();
    },
  },

  ticketTags: {
    getAll: (): TicketTag[] => [...ticketTags],
    getByTicketId: (ticketId: string): TicketTag[] =>
      ticketTags.filter((x: any) => String(x.ticketId) === String(ticketId)),
    add: (row: TicketTag) => {
      ticketTags = [...ticketTags, row];
      validateIntegrityInternal();
    },
    removeByTicketId: (ticketId: string) => {
      ticketTags = ticketTags.filter((x: any) => String(x.ticketId) !== String(ticketId));
      validateIntegrityInternal();
    },
  },

  userOrganizations: {
    getAll: (): UserOrganization[] => [...userOrganizations],
    getByUserId: (userId: string): UserOrganization[] =>
      userOrganizations.filter((x: any) => String(x.userId) === String(userId)),
    add: (row: UserOrganization) => {
      userOrganizations = [...userOrganizations, row];
      validateIntegrityInternal();
    },
  },

  timeline: {
    getAll: (): TimelineEvent[] => [...timeline],
    getByTicketId: (ticketId: string): TimelineEvent[] =>
      timeline.filter((x: any) => String(x.ticketId) === String(ticketId)),
    add: (row: TimelineEvent) => {
      timeline = [...timeline, row];
      validateIntegrityInternal();
    },
  },

  comments: {
    getAll: (): Comment[] => [...comments],
    getByTicketId: (ticketId: string): Comment[] =>
      comments.filter((x: any) => String(x.ticketId) === String(ticketId)),
    add: (row: Comment) => {
      comments = [...comments, row];
      validateIntegrityInternal();
    },
  },

  attachments: {
    getAll: (): Attachment[] => [...attachments],
    getByTicketId: (ticketId: string): Attachment[] =>
      attachments.filter((x: any) => String(x.ticketId) === String(ticketId)),
    add: (row: Attachment) => {
      attachments = [...attachments, row];
      validateIntegrityInternal();
    },
  },

  escalations: {
    getAll: (): Escalation[] => [...escalations],
    getByTicketId: (ticketId: string): Escalation[] =>
      escalations.filter((x: any) => String(x.ticketId) === String(ticketId)),
    add: (row: Escalation) => {
      escalations = [...escalations, row];
      validateIntegrityInternal();
    },
  },

  slaSettings: {
    getAll: (): SLASetting[] => [...slaSettings],
    getByScope: (scope: SLAScope): SLASetting[] =>
      slaSettings.filter((s: any) => String(s.scope) === String(scope)),
    getByProductId: (productId: string): SLASetting[] =>
      slaSettings.filter((s: any) => String(s.productId ?? '') === String(productId)),
    // ✅ Rule-1 compliant: no constants.X reference here
    getDefault: () => DEFAULT_SLA_CONFIG,
    add: (row: SLASetting) => {
      slaSettings = [...slaSettings, row];
      validateIntegrityInternal();
    },
  },

  notifications: {
    getAll: (): Notification[] => [...notifications],
    getById: (id: string): Notification | undefined =>
      notifications.find((n: any) => String(n.id) === String(id)),

    // ✅ New contract (Laravel-ready)
    getByRecipientId: (recipientId: string): Notification[] => {
      const rid = String(recipientId);
      return [...notifications]
        .filter((n: any) => String(n.recipientId ?? '') === rid)
        .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    },

    add: (row: Notification) => {
      notifications = [...notifications, row];
      validateIntegrityInternal();
    },

    markRead: (id: string) => {
      const readAt = new Date().toISOString();
      notifications = notifications.map((n: any) =>
        String(n.id) === String(id)
          ? { ...n, isRead: true, isNew: false, readAt, updatedAt: readAt }
          : n,
      );
    },

    markAllReadByRecipientId: (recipientId: string) => {
      const rid = String(recipientId);
      const readAt = new Date().toISOString();
      notifications = notifications.map((n: any) =>
        String(n.recipientId ?? '') === rid
          ? { ...n, isRead: true, isNew: false, readAt, updatedAt: readAt }
          : n,
      );
    },
  },

  satisfactionSurveys: {
    getAll: (): SatisfactionSurvey[] => [...satisfactionSurveys],
    getByTicketId: (ticketId: string): SatisfactionSurvey | undefined =>
      satisfactionSurveys.find((s: any) => String(s.ticketId) === String(ticketId)),
    getByCustomerId: (customerId: string): SatisfactionSurvey[] =>
      satisfactionSurveys.filter((s: any) => String(s.customerId) === String(customerId)),
    add: (row: SatisfactionSurvey) => {
      satisfactionSurveys = [...satisfactionSurveys, row];
      validateIntegrityInternal();
    },
  },

  validateIntegrity: () => validateIntegrityInternal(),
};

// ✅ Standard export only (Rule-1)
// ✅ Single Source of Truth (Rule-3)
export const db = deepFreeze(guardObject('db', dbRaw));
