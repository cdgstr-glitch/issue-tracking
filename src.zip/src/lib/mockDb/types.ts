// lib/mockDb/types.ts
// types.ts (normalized: stage separated from status)

/**
 * ✅ Key Rules (Issue Tracking):
 * - stage = tier / workflow stage (tier1, tier2, tier3)
 * - status = work status (new, in_progress, on_hold, resolved, closed, etc.)
 * - Project uses projectStatus (NOT status) to avoid collision with ticket.status
 * - Keep legacy compatibility: some older mock tickets may have tier stored in status.
 */

// ==================== COMMON ENUMS ====================

export type TicketStage = 'tier1' | 'tier2' | 'tier3';

/**
 * TicketStatus = สถานะงาน (ไม่ใช่ tier)
 * หมายเหตุ: ในระบบเดิมบางส่วนอาจเคยใช้ tier เก็บใน status → ให้ map ไป legacyStatusTier แทน
 */
export type TicketStatus =
  | 'new'
  | 'in_progress'
  | 'on_hold'
  | 'resolved'
  | 'closed'
  // Optional: future-ready statuses (ปลอดภัยจะคงไว้ได้ ถ้าไม่ใช้ก็ลบได้)
  | 'cancelled'
  | 'rejected'
  | 'duplicate';

export type TicketType =
  | 'incident'
  | 'service_request'
  | 'security_incident'
  | 'problem'
  | 'change_request';

export type TicketChannel = 'web' | 'email' | 'line' | 'phone' | 'internal';

export type TicketPriority = 'low' | 'medium' | 'high' | 'critical';

export type SlaStatus = 'on_track' | 'at_risk' | 'breached' | 'met';

/**
 * ✅ TimelineEventType (tighten for analytics + consistency)
 * (Keep 'system' as safe fallback for auto events)
 */
export type TimelineEventType =
  | 'created'
  | 'status_change'
  | 'assignment'
  | 'escalation'
  | 'comment'
  | 'attachment'
  | 'closure'
  | 'system';

// ==================== MASTER DATA ====================

export type ProductCategory =
  | 'software'
  | 'service'
  | 'hardware'
  | 'document'
  | 'asset'
  | 'hr'
  | 'facility'
  | 'project';

export interface RawProduct {
  id: string;
  code: string; // value stored in project.purchasedProducts (e.g. 'e-saraban')
  name: string; // display name (e.g. 'ระบบสารบรรณอิเล็กทรอนิกส์')
  description?: string;
  category: ProductCategory;
  isActive: boolean;
}

export interface RawSatisfactionSurvey {
  id: string;
  ticketId: string;
  rating: number; // 1-5
  comment?: string;
  createdAt: string;
  userId?: string;
}

// ==================== ORGANIZATION & PROJECT ====================

export type OrganizationType =
  | 'university'
  | 'government'
  | 'enterprise'
  | 'public_sector'
  | 'private_sector';

export interface RawOrganization {
  id: string;
  code: string; // ORG-{NNN}
  name: string;
  shortName: string;
  type: OrganizationType;
  department?: string;
  contactPerson?: string;
  contactEmail?: string;
  description?: string;
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
}

export type ProjectStatus = 'active' | 'completed' | 'cancelled' | 'on_hold';

/**
 * ✅ IMPORTANT: Project MUST use projectStatus (NOT status)
 * เพื่อไม่ให้สับสนกับ ticket.status และทำให้ schema Laravel ชัดเจน
 */
export interface RawProject {
  id: string;
  organizationId: string;
  code: string; // D{YY}-{XXXX}
  name: string;

  projectStatus: ProjectStatus; // ✅ renamed from "status"

  startDate?: string;
  endDate?: string;
  budget?: number;

  /**
   * purchasedProducts: Array of Product Codes (References RawProduct.code)
   * หมายเหตุ: ให้ยึด "code" เป็น FK ไม่ใช้ id เพื่อความ Laravel-ready
   */
  purchasedProducts: string[];

  description?: string;
  projectManager?: string; // Optional (legacy)
  createdAt: string;
  updatedAt: string;
}

// ==================== USER ====================

/**
 * RawUser = mock auth user model
 * หมายเหตุ: supervisor เป็น role ทาง permission logic (ไม่จำเป็นต้องผูกกับ TicketStage)
 * ใช้ใน permissions/capabilities มากกว่า
 */
export type PrimaryRole =
  | 'customer'
  | 'staff'
  | 'tier1'
  | 'tier2'
  | 'tier3'
  | 'admin'
  | 'supervisor';

export interface RawUser {
  id: string;
  username: string;
  password?: string; // mock auth only
  email: string;
  fullName: string;
  phone?: string;
  department?: string;

  primaryRole: PrimaryRole;

  /**
   * tier: legacy numeric
   * - keep optional for compatibility (บางจุดอาจใช้เลข)
   */
  tier?: 1 | 2 | 3;

  managerId?: string;

  // Mock relationships (Many-to-Many)
  projectIds?: string[];
  roles?: string[];
}

// ==================== TICKET ====================

export type CreatedByType = 'customer_self' | 'staff_on_behalf';

export type ClosureSource = 'instant_close' | 'handoff_to_tier1_close' | 'normal_close';

export interface RawTicket {
  id: string;
  ticketNumber: string;
  title: string;
  description: string;

  /**
   * ✅ Normalized:
   * - stage: tier owner ของเคสตอนนี้
   * - status: สถานะงาน
   */
  stage: TicketStage;
  status: TicketStatus;

  /**
   * ✅ Legacy compatibility:
   * หากข้อมูลเก่าเคยเก็บ tier ไว้ใน status ให้ map มาที่นี่
   */
  legacyStatusTier?: TicketStage;

  type: TicketType;
  channel: TicketChannel;
  priority: TicketPriority;
  category: string;

  // Relations
  projectId: string; // References RawProject.id
  assignedTo?: string; // References RawUser.id
  assignedBy?: string; // References RawUser.id
  previousAssignee?: string; // References RawUser.id

  // Creator
  createdBy: string; // References RawUser.id (หรือ staff user id)
  createdByType: CreatedByType;

  // Customer info
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  department?: string;

  /**
   * ✅ Product FK: lock to product "code"
   * เพื่อกันสับสนระหว่าง code/id
   */
  productCode?: string; // References RawProduct.code

  // Timestamps
  createdAt: string;
  updatedAt: string;
  dueDate: string;

  resolvedAt?: string;
  resolvedBy?: string;

  closedAt?: string;
  closedBy?: string;

  closureSource?: ClosureSource;

  // Resolution
  solution?: string;
  closureNotes?: string;

  // SLA / legacy extras
  slaHours?: number;
  slaDueDate?: string;
  slaStatus?: SlaStatus;

  // legacy / misc
  onBehalfOf?: string;
  lineId?: string;
}

// ==================== TIMELINE / COMMENTS / ATTACHMENTS ====================

export interface RawTimelineEvent {
  id: string;
  ticketId: string;
  timestamp: string; // ISO timestamp
  type: TimelineEventType;

  action?: string;
  description: string;

  // legacy
  userId?: string; // RawUser.id

  // optional relationships
  assignedToUserId?: string; // RawUser.id

  /**
   * Optional status snapshot (not tier)
   */
  status?: TicketStatus;

  isInternal?: boolean;
}

export interface RawComment {
  id: string;
  ticketId: string;
  authorId: string; // RawUser.id
  content: string;
  isInternal: boolean;
  createdAt: string;
}

export interface RawAttachment {
  id: string;
  ticketId?: string;
  commentId?: string;
  filename: string;
  fileSize: number;
  fileType: string;
  url: string;
  uploadedBy: string;
  uploadedAt: string;
}

// ==================== SLA SETTINGS ====================

export interface RawSlaSetting {
  id: string;
  priority: TicketPriority;
  ticketType: TicketType;
  hours: number;

  // overrides
  organizationId?: string;
  projectId?: string;

  updatedAt: string;
}
