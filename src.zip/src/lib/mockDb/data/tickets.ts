// src/lib/mockDb/data/tickets.ts
// ✅ Minimal Test Suite - 11 cases covering all essential workflows
// ✅ Laravel-ready: FK-based, SSoT-compliant
// ✅ Status SSoT: 'pending' = รอดำเนินการ (ห้ามเปลี่ยนชื่อ)
//
// 🔑 Logic สำคัญ:
// - Customer สร้างเอง (customer_self): organizationId=null, projectId=null, มีแค่ productId
// - Staff สร้าง (staff_on_behalf): มี organizationId, projectId, productId ครบ
// - T1 รับเคส customer แล้วกรอก org/project เพิ่มทีหลัง

import type { Ticket } from '../../../types';

export const tickets: Ticket[] = [
  // ══════════════════════════════════════════════════════════════════
  // 1. MIN-NEW1: Staff สร้าง on behalf - มี org/project ครบ
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-new1',
    ticketNumber: 'MIN-NEW1',
    title: 'ระบบ e-Saraban ไม่สามารถเข้าใช้งานได้',
    description: 'เมื่อกดเข้าระบบ e-Saraban แล้วหน้าจอค้างอยู่ที่หน้า Loading ไม่สามารถเข้าใช้งานได้',
    stage: 'tier1',
    status: 'new',
    priority: 'high',
    channel: 'phone',
    organizationId: 'org-csv-001',  // ✅ Staff กรอก
    projectId: 'proj-001',           // ✅ Staff กรอก
    customerId: 'cust-001',
    assignedTo: null,
    accepted: false,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-19T08:00:00.000Z',
    updatedAt: '2026-02-19T08:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 2. MIN-PND1: Staff สร้าง - T1 assigned แต่ยังไม่ accept
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-pnd1',
    ticketNumber: 'MIN-PND1',
    title: 'ขอเปลี่ยนรหัสผ่านระบบ e-DMS',
    description: 'ต้องการเปลี่ยนรหัสผ่านเนื่องจากลืมรหัสผ่านเดิม',
    stage: 'tier1',
    status: 'pending',
    priority: 'medium',
    channel: 'phone',
    organizationId: 'org-csv-001',
    projectId: 'proj-001',
    customerId: 'cust-001',
    assignedTo: 'user-003',  // วรรณภา
    accepted: false,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-19T08:30:00.000Z',
    updatedAt: '2026-02-19T08:35:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 3. MIN-WIP1: Staff สร้าง - T1 กำลังดำเนินการ
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-wip1',
    ticketNumber: 'MIN-WIP1',
    title: 'ปัญหาการพิมพ์เอกสารจากระบบ e-Meeting',
    description: 'เมื่อกดพิมพ์เอกสารการประชุม ระบบแสดง error "Print service unavailable"',
    stage: 'tier1',
    status: 'in_progress',
    priority: 'medium',
    channel: 'email',
    organizationId: 'org-csv-001',
    projectId: 'proj-001',
    customerId: 'cust-001',
    assignedTo: 'user-003',  // วรรณภา
    accepted: true,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-19T07:00:00.000Z',
    updatedAt: '2026-02-19T09:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 4. MIN-H12: T1 → T2 (รอ T2 รับ) - ผู้รับ: user-007 (ประกาศิต)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-h12',
    ticketNumber: 'MIN-H12',
    title: 'ระบบ e-Saraban ทำงานช้ามาก',
    description: 'ระบบโหลดหน้าจอนานเกิน 30 วินาที ต้องการให้ทีมเทคนิคตรวจสอบ',
    stage: 'tier2',
    status: 'pending',
    priority: 'high',
    channel: 'web',
    organizationId: 'org-csv-001',
    projectId: 'proj-001',
    customerId: 'cust-001',
    assignedTo: 'user-007',  // ประกาศิต (tier2/tier3)
    accepted: false,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-19T06:00:00.000Z',
    updatedAt: '2026-02-19T10:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 5. MIN-H23: T2 → T3 (รอ T3 รับ) - ผู้รับ: user-007 (ประกาศิต as tier3)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-h23',
    ticketNumber: 'MIN-H23',
    title: 'Database Connection Pool หมด',
    description: 'ระบบ Network Infrastructure แจ้ง error: "Connection pool exhausted" ต้องการ Expert วิเคราะห์',
    stage: 'tier3',
    status: 'pending',
    priority: 'critical',
    channel: 'phone',
    organizationId: 'org-csv-001',
    projectId: 'proj-001',
    customerId: 'cust-001',
    assignedTo: 'user-007',  // ประกาศิต (switch to tier3)
    accepted: false,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-19T05:00:00.000Z',
    updatedAt: '2026-02-19T11:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 6. MIN-H33: T3 → T3 (reassign ภายใน tier3)
  //    เริ่ม: user-009 (พุทธจักษ์) → ส่งต่อให้: user-007 (ประกาศิต)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-h33',
    ticketNumber: 'MIN-H33',
    title: 'ต้องการ Specialist ด้าน CTL System',
    description: 'ปัญหาซับซ้อนเกี่ยวกับ CTL data synchronization ต้องการผู้เชี่ยวชาญเฉพาะทาง',
    stage: 'tier3',
    status: 'pending',
    priority: 'high',
    channel: 'email',
    organizationId: 'org-csv-004',
    projectId: 'proj-004',
    customerId: 'cust-004',
    assignedTo: 'user-007',  // ประกาศิต (รับต่อจาก user-009)
    accepted: false,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-19T04:00:00.000Z',
    updatedAt: '2026-02-19T12:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 7. MIN-BCK1: T2 → T1 for_continuation (ส่งกลับให้แก้ต่อ)
  //    status: 'pending' (ไม่ใช่ 'resolved')
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-bck1',
    ticketNumber: 'MIN-BCK1',
    title: 'ปัญหาการตั้งค่า User Permission',
    description: 'ผู้ใช้ไม่สามารถเข้าถึงเมนูบางอย่างได้ - T2 วิเคราะห์แล้วเป็นการตั้งค่า T1 ทำเองได้',
    stage: 'tier1',
    status: 'pending',  // ⭐ for_continuation → pending (ไม่ใช่ resolved)
    priority: 'medium',
    channel: 'email',
    organizationId: 'org-csv-001',
    projectId: 'proj-001',
    customerId: 'cust-001',
    assignedTo: 'user-003',  // วรรณภา (T1 รับกลับ)
    accepted: false,
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-18T10:00:00.000Z',
    updatedAt: '2026-02-19T13:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 8. MIN-C21: T2 → T1 for_closure (ส่งกลับให้ปิด) → ปิดแล้ว
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-c21',
    ticketNumber: 'MIN-C21',
    title: 'แก้ไข Database Configuration สำเร็จ',
    description: 'ปัญหา database connection timeout - T2 แก้ไขเสร็จแล้ว',
    stage: 'tier1',
    status: 'closed',
    priority: 'high',
    channel: 'phone',
    organizationId: 'org-csv-001',
    projectId: 'proj-001',
    customerId: 'cust-001',
    assignedTo: 'user-003',  // วรรณภา
    accepted: true,
    resolvedBy: 'user-007',  // ประกาศิต (T2 แก้ไข)
    resolvedAt: '2026-02-18T16:00:00.000Z',
    resolution: 'แก้ไข database connection pool configuration และ optimize query แล้ว',
    closedBy: 'user-003',  // ⭐ Tier1 เท่านั้นที่ปิดได้
    closedAt: '2026-02-18T17:00:00.000Z',
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-17T09:00:00.000Z',
    updatedAt: '2026-02-18T17:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 9. MIN-C31: T3 → T1 for_closure (ส่งกลับให้ปิด) → ปิดแล้ว
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-c31',
    ticketNumber: 'MIN-C31',
    title: 'แก้ไขปัญหา Critical System Failure',
    description: 'ระบบ e-DMS ล่มทั้งระบบ - T3 Expert แก้ไขเสร็จแล้ว',
    stage: 'tier1',
    status: 'closed',
    priority: 'critical',
    channel: 'phone',
    organizationId: 'org-csv-004',
    projectId: 'proj-004',
    customerId: 'cust-004',
    assignedTo: 'user-003',  // วรรณภา
    accepted: true,
    resolvedBy: 'user-007',  // ประกาศิต (T3 แก้ไข)
    resolvedAt: '2026-02-17T14:00:00.000Z',
    resolution: 'แก้ไข memory leak และ restart services ทั้งหมด - ระบบกลับมาทำงานปกติ',
    closedBy: 'user-003',  // ⭐ Tier1 เท่านั้นที่ปิดได้
    closedAt: '2026-02-17T15:00:00.000Z',
    createdByType: 'staff_on_behalf',
    createdBy: 'staff-002',
    createdAt: '2026-02-16T08:00:00.000Z',
    updatedAt: '2026-02-17T15:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 10. MIN-CUST1: ⭐ Customer สร้างเอง - ไม่มี org/project (รอ T1 กรอก)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-cust1',
    ticketNumber: 'MIN-CUST1',
    title: 'ไม่สามารถอัปโหลดไฟล์ขนาดใหญ่ได้',
    description: 'เมื่อพยายามอัปโหลดไฟล์ PDF ขนาด 50MB ระบบแจ้ง error "File too large"',
    stage: 'tier1',
    status: 'new',
    priority: 'medium',
    channel: 'web',
    organizationId: null,  // ⭐ Customer สร้างเอง = ไม่มี org
    projectId: null,       // ⭐ Customer สร้างเอง = ไม่มี project
    customerId: 'cust-001',
    assignedTo: null,
    accepted: false,
    createdByType: 'customer_self',  // ⭐ Customer สร้างเอง
    createdBy: 'cust-001',
    createdAt: '2026-02-19T09:00:00.000Z',
    updatedAt: '2026-02-19T09:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // 11. MIN-CUST2: ⭐ Customer สร้างเอง - T1 รับแล้ว + กรอก org/project แล้ว
  //     ตัวอย่างเคสที่ T1 รับและกรอกข้อมูลเพิ่มแล้ว
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'min-cust2',
    ticketNumber: 'MIN-CUST2',
    title: 'ระบบแสดงข้อมูลไม่ถูกต้อง',
    description: 'หน้ารายงานแสดงตัวเลขผิดพลาด ไม่ตรงกับข้อมูลจริง',
    stage: 'tier1',
    status: 'in_progress',
    priority: 'high',
    channel: 'web',
    organizationId: 'org-csv-001',  // ⭐ T1 กรอกเพิ่มตอนรับเคส
    projectId: 'proj-001',           // ⭐ T1 กรอกเพิ่มตอนรับเคส
    customerId: 'cust-001',
    assignedTo: 'user-003',  // วรรณภา
    accepted: true,
    createdByType: 'customer_self',  // ⭐ Customer สร้างเอง แต่ T1 กรอกข้อมูลเพิ่มแล้ว
    createdBy: 'cust-001',
    createdAt: '2026-02-19T07:30:00.000Z',
    updatedAt: '2026-02-19T09:30:00.000Z',
  },
];
