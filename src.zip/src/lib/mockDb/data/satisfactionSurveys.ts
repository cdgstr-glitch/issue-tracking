// src/lib/mockDb/data/satisfactionSurveys.ts
// ✅ Minimal Test Suite - Customer Satisfaction Surveys
// ✅ Laravel-ready: FK-based

import type { SatisfactionSurvey } from '../../../types';

export const satisfactionSurveys: SatisfactionSurvey[] = [
  // MIN-C21: ลูกค้าให้คะแนน 5 ดาว
  {
    id: 'survey-c21-001',
    ticketId: 'min-c21',
    customerId: 'cust-001',
    rating: 5,
    comment: 'แก้ปัญหาได้รวดเร็วมาก ขอบคุณทีมงานครับ',
    createdAt: '2026-02-18T17:30:00.000Z',
    updatedAt: '2026-02-18T17:30:00.000Z',
  },

  // MIN-C31: ลูกค้าให้คะแนน 4 ดาว
  {
    id: 'survey-c31-001',
    ticketId: 'min-c31',
    customerId: 'cust-004',
    rating: 4,
    comment: 'แก้ไขได้ดี แต่อยากให้มีการแจ้งความคืบหน้าบ่อยกว่านี้',
    createdAt: '2026-02-17T15:30:00.000Z',
    updatedAt: '2026-02-17T15:30:00.000Z',
  },
];
