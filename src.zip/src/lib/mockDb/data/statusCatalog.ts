export type StatusType = 'primary' | 'system';

export interface StatusCatalogItem {
  /** canonical key เช่น new, tier1, pending_closure */
  key: string;
  /** primary = สถานะหลัก, system = สถานะภายใน/legacy */
  type: StatusType;
  /** เปิด/ปิดการรองรับสถานะนี้ */
  isActive: boolean;
  /** คำอธิบายสำหรับ Admin */
  description?: string;
}

/**
 * ✅ Status Catalog (Canonical)
 * - ใช้เป็นรายการสถานะที่ระบบ “รองรับจริง”
 * - ห้ามใช้ label ภาษาไทยเป็น key
 * - UI จะไป map/แสดงผลผ่าน statusPresentation อีกชั้น
 */
export const statusCatalog: StatusCatalogItem[] = [
  // =========================
  // PRIMARY (สถานะหลัก)
  // =========================
  { key: 'new', type: 'primary', isActive: true, description: 'สร้างเคสใหม่' },
  { key: 'in_progress', type: 'primary', isActive: true, description: 'กำลังดำเนินการ' },
  { key: 'on_hold', type: 'primary', isActive: true, description: 'หยุดชั่วคราว/รอข้อมูล' },
  { key: 'resolved', type: 'primary', isActive: true, description: 'แก้ไขแล้ว' },
  { key: 'closed', type: 'primary', isActive: true, description: 'ปิดแล้ว' },

  // =========================
  // SYSTEM / INTERNAL (ภายใน)
  // =========================
  { key: 'tier1', type: 'system', isActive: true, description: 'คิวรอรับโดย Tier 1 (ยังไม่รับงาน)' },
  { key: 'tier2', type: 'system', isActive: true, description: 'คิวรอรับโดย Tier 2 (ยังไม่รับงาน)' },
  { key: 'tier3', type: 'system', isActive: true, description: 'คิวรอรับโดย Tier 3 (ยังไม่รับงาน)' },

  // รอปิดเคส/สถานะภายใน
  { key: 'pending_closure', type: 'system', isActive: true, description: 'แก้ไขแล้ว รอ Tier 1 ปิดเคส (ภายใน)' },
  { key: 'awaiting_closure', type: 'system', isActive: true, description: 'รอปิดเคส (legacy)' },

  // legacy alias ที่อาจพบในข้อมูล
  { key: 'on_hold', type: 'system', isActive: true, description: 'เทียบเป็น waiting (legacy)' },
];
