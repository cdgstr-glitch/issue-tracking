// src/lib/mockDb/data/masterData.ts
// ======================================================
// CDGS Issue Tracking - Master Data (Single Source)
// Laravel-ready structure
// ======================================================
//
// ✅ Single export
// ❌ No default export
// ❌ No dual export
// ❌ No scattered constants
//
// This file must be the ONLY source of lookup values.
//

export const masterData = {
  // =========================
  // Ticket Channels
  // =========================
  TICKET_CHANNELS: [
    { value: 'web', label: 'Web' },
    { value: 'phone', label: 'Phone' },
    { value: 'email', label: 'Email' },
    { value: 'line', label: 'LINE' },
  ],

  // =========================
  // Ticket Types
  // =========================
  TICKET_TYPES: [
    { value: 'incident', label: 'Incident' },
    { value: 'request', label: 'Service Request' },
    { value: 'problem', label: 'Problem' },
    { value: 'change', label: 'Change Request' },
  ],

  // =========================
  // Ticket Priorities
  // =========================
  TICKET_PRIORITIES: [
    { value: 'low', label: 'Low' },
    { value: 'medium', label: 'Medium' },
    { value: 'high', label: 'High' },
    { value: 'critical', label: 'Critical' },
  ],

  // =========================
  // Ticket Status
  // =========================
  TICKET_STATUSES: [
    { value: 'new', label: 'New' },
    { value: 'in_progress', label: 'In Progress' },
    { value: 'waiting', label: 'Waiting' },
    { value: 'resolved', label: 'Resolved' },
    { value: 'closed', label: 'Closed' },
  ],

  // =========================
  // Ticket Categories
  // =========================
  TICKET_CATEGORIES: [
    { value: 'system', label: 'System' },
    { value: 'network', label: 'Network' },
    { value: 'hardware', label: 'Hardware' },
    { value: 'software', label: 'Software' },
    { value: 'security', label: 'Security' },
  ],

  // =========================
  // Product Categories
  // =========================
  PRODUCT_CATEGORIES: [
    { value: 'document', label: 'Document Management' },
    { value: 'network', label: 'Network & Infrastructure' },
    { value: 'asset', label: 'Asset Management' },
    { value: 'project', label: 'Project Management' },
    { value: 'facility', label: 'Facility Management' },
  ],
} as const;
