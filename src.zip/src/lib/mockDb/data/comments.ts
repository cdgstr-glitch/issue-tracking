// src/lib/mockDb/data/comments.ts
// ✅ Minimal Test Suite - Comments for test cases
// ✅ Laravel-ready: FK-based, author resolved via hydration

import type { Comment } from '../../../types';

export const comments: Comment[] = [
  // ══════════════════════════════════════════════════════════════════
  // MIN-WIP1: T1 กำลังดำเนินการ
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'cmt-wip1-001',
    ticketId: 'min-wip1',
    authorUserId: 'user-003',  // วรรณภา
    content: 'ได้รับเคสแล้ว กำลังตรวจสอบปัญหาการพิมพ์เอกสาร',
    visibility: 'public',
    createdAt: '2026-02-19T09:05:00.000Z',
    updatedAt: '2026-02-19T09:05:00.000Z',
  },
  {
    id: 'cmt-wip1-002',
    ticketId: 'min-wip1',
    authorCustomerId: 'cust-001',  // ลูกค้า
    content: 'ขอบคุณครับ รอการตรวจสอบอยู่',
    visibility: 'public',
    createdAt: '2026-02-19T09:10:00.000Z',
    updatedAt: '2026-02-19T09:10:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-H12: T1 → T2 (ประกาศิต รอรับ)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'cmt-h12-001',
    ticketId: 'min-h12',
    authorUserId: 'user-003',  // วรรณภา
    content: 'ตรวจสอบเบื้องต้นแล้ว ปัญหาน่าจะเกิดจาก server ส่งต่อให้ทีมเทคนิคตรวจสอบ',
    visibility: 'internal',
    createdAt: '2026-02-19T09:55:00.000Z',
    updatedAt: '2026-02-19T09:55:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-BCK1: T2 → T1 for_continuation (มี comment อธิบาย)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'cmt-bck1-001',
    ticketId: 'min-bck1',
    authorUserId: 'user-007',  // ประกาศิต (T2)
    content: `ตรวจสอบแล้ว ปัญหานี้เกิดจากการตั้งค่า Permission ระดับ User ธรรมดา

**วิธีแก้ไข:**
1. เข้าไปที่เมนู Admin > User Management
2. เลือก User ที่มีปัญหา
3. กดปุ่ม Edit Permissions
4. เพิ่ม Permission: "view_reports" และ "export_data"
5. กด Save

T1 ดำเนินการเองได้ครับ`,
    visibility: 'internal',
    createdAt: '2026-02-19T12:50:00.000Z',
    updatedAt: '2026-02-19T12:50:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-C21: T2 → T1 for_closure (resolved)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'cmt-c21-001',
    ticketId: 'min-c21',
    authorUserId: 'user-003',  // วรรณภา
    content: 'ลูกค้าแจ้งว่าระบบ timeout บ่อยมาก ส่งให้ทีมเทคนิคตรวจสอบ',
    visibility: 'internal',
    createdAt: '2026-02-17T09:55:00.000Z',
    updatedAt: '2026-02-17T09:55:00.000Z',
  },
  {
    id: 'cmt-c21-002',
    ticketId: 'min-c21',
    authorUserId: 'user-007',  // ประกาศิต
    content: `พบสาเหตุแล้ว: Database Connection Pool เต็ม

**สิ่งที่ดำเนินการ:**
1. เพิ่ม max_connections จาก 100 เป็น 200
2. ปรับ connection timeout จาก 30s เป็น 60s
3. เพิ่ม connection pooling configuration
4. Optimize slow queries ที่พบ

ระบบกลับมาทำงานปกติแล้วครับ`,
    visibility: 'internal',
    createdAt: '2026-02-18T15:55:00.000Z',
    updatedAt: '2026-02-18T15:55:00.000Z',
  },
  {
    id: 'cmt-c21-003',
    ticketId: 'min-c21',
    authorUserId: 'user-003',  // วรรณภา
    content: 'ได้ตรวจสอบกับลูกค้าแล้ว ยืนยันว่าระบบทำงานได้ปกติ ปิดเคสครับ',
    visibility: 'public',
    createdAt: '2026-02-18T16:55:00.000Z',
    updatedAt: '2026-02-18T16:55:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-C31: T3 → T1 for_closure (critical resolved)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'cmt-c31-001',
    ticketId: 'min-c31',
    authorUserId: 'user-007',  // ประกาศิต (T3)
    content: `**Root Cause Analysis:**
พบ Memory Leak ใน e-DMS Service ทำให้ระบบล่ม

**สิ่งที่ดำเนินการ:**
1. ระบุตำแหน่ง Memory Leak ใน DocumentProcessor module
2. Apply hotfix patch
3. Restart all services
4. Monitor memory usage - stable

**Preventive Measures:**
- เพิ่ม memory monitoring alert
- Schedule weekly restart ช่วง maintenance window

ระบบกลับมาทำงานปกติแล้วครับ`,
    visibility: 'internal',
    createdAt: '2026-02-17T13:50:00.000Z',
    updatedAt: '2026-02-17T13:50:00.000Z',
  },
  {
    id: 'cmt-c31-002',
    ticketId: 'min-c31',
    authorUserId: 'user-003',  // วรรณภา
    content: 'ติดต่อลูกค้าแล้ว ยืนยันว่าระบบใช้งานได้ปกติ ขอบคุณทีม Expert ครับ',
    visibility: 'public',
    createdAt: '2026-02-17T14:55:00.000Z',
    updatedAt: '2026-02-17T14:55:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-CUST1: Customer สร้างเอง
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'cmt-cust1-001',
    ticketId: 'min-cust1',
    authorCustomerId: 'cust-001',  // ลูกค้าสร้างเอง
    content: 'ไฟล์ที่ต้องการอัปโหลดคือรายงานประจำเดือน ขนาดประมาณ 50MB ครับ',
    visibility: 'public',
    createdAt: '2026-02-19T09:05:00.000Z',
    updatedAt: '2026-02-19T09:05:00.000Z',
  },
];
