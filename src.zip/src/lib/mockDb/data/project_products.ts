// src/lib/mockDb/data/project_products.ts
// Laravel-ready pivot: projects <-> products
//
// ✅ Source of Truth for "which products are available under which project"
// - projectId -> projects.id
// - productId -> products.id
//
// Notes:
// - Keep ticket_products.ts as a separate pivot (tickets <-> products).
// - This table is used for UI cascading dropdowns and matches Laravel N:M schema.

export type ProjectProduct = {
  id: string;
  projectId: string;
  productId: string;
  createdAt: string;
};

export const projectProducts: ProjectProduct[] = [
  // =========================
  // EXISTING (kept)
  // =========================
  {
    id: 'pp-001',
    projectId: 'proj-001',
    productId: 'prod-001',
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-002',
    projectId: 'proj-001',
    productId: 'prod-008',
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-003',
    projectId: 'proj-002',
    productId: 'prod-001',
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-004',
    projectId: 'proj-003',
    productId: 'prod-001',
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // =========================
  // ADDED (to make relations complete)
  // Every project must have ≥ 1 product via pivot (Laravel-ready)
  // =========================

  // proj-004: NESDC sub-unit (seed)
  {
    id: 'pp-005',
    projectId: 'proj-004',
    productId: 'prod-002', // e-DMS
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-006',
    projectId: 'proj-004',
    productId: 'prod-004', // CTL
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-005: Ministry of Transport (seed)
  {
    id: 'pp-007',
    projectId: 'proj-005',
    productId: 'prod-007', // Car Booking
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-008',
    projectId: 'proj-005',
    productId: 'prod-005', // e-Booking
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-006: Ministry of Tourism and Sports (seed)
  {
    id: 'pp-009',
    projectId: 'proj-006',
    productId: 'prod-009', // Project Tracking
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-010',
    projectId: 'proj-006',
    productId: 'prod-003', // e-Meeting
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-007: NESDC (org-csv-017) (seed)
  {
    id: 'pp-011',
    projectId: 'proj-007',
    productId: 'prod-009', // Project Tracking
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-012',
    projectId: 'proj-007',
    productId: 'prod-001', // e-Saraban
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-008: PRD (seed)
  {
    id: 'pp-013',
    projectId: 'proj-008',
    productId: 'prod-001', // e-Saraban
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-014',
    projectId: 'proj-008',
    productId: 'prod-003', // e-Meeting
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-009: KU (seed)
  {
    id: 'pp-015',
    projectId: 'proj-009',
    productId: 'prod-002', // e-DMS
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-016',
    projectId: 'proj-009',
    productId: 'prod-006', // e-Leave
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-010: ETDA (seed)
  {
    id: 'pp-017',
    projectId: 'proj-010',
    productId: 'prod-004', // CTL
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-018',
    projectId: 'proj-010',
    productId: 'prod-008', // Network Infrastructure
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-011: Chonburi PAO (seed)
  {
    id: 'pp-019',
    projectId: 'proj-011',
    productId: 'prod-001', // e-Saraban
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-020',
    projectId: 'proj-011',
    productId: 'prod-002', // e-DMS
    createdAt: '2026-02-16T00:00:00.000Z',
  },
  {
    id: 'pp-021',
    projectId: 'proj-011',
    productId: 'prod-006', // e-Leave
    createdAt: '2026-02-16T00:00:00.000Z',
  },

  // proj-unassigned: placeholder project for web intake (must be FK-safe)
  {
    id: 'pp-022',
    projectId: 'proj-unassigned',
    productId: 'prod-001', // default to e-Saraban
    createdAt: '2026-02-16T00:00:00.000Z',
  },
];
