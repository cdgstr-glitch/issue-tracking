import type { Tag } from '../../../types';

export const tags: Tag[] = [
  {
    id: 'tag-001',
    tagName: 'ด่วน',
    tagSlug: 'urgent',
    usageCount: 15,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-002',
    tagName: 'การเข้าถึง',
    tagSlug: 'access',
    usageCount: 12,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-003',
    tagName: 'รหัสผ่าน',
    tagSlug: 'password',
    usageCount: 10,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-004',
    tagName: 'อีเมล',
    tagSlug: 'email',
    usageCount: 8,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-005',
    tagName: 'เครือข่าย',
    tagSlug: 'network',
    usageCount: 7,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-006',
    tagName: 'ฮาร์ดแวร์',
    tagSlug: 'hardware',
    usageCount: 6,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-007',
    tagName: 'ซอฟต์แวร์',
    tagSlug: 'software',
    usageCount: 9,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-008',
    tagName: 'ประสิทธิภาพ',
    tagSlug: 'performance',
    usageCount: 5,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-009',
    tagName: 'ความปลอดภัย',
    tagSlug: 'security',
    usageCount: 11,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'tag-010',
    tagName: 'การพิมพ์',
    tagSlug: 'printing',
    usageCount: 4,
    createdAt: '2024-01-01T00:00:00Z',
  },

  {
    id: 'tag-011',
    tagName: 'ตัวอย่างแท็ก 011',
    tagSlug: 'tag-011',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-012',
    tagName: 'ตัวอย่างแท็ก 012',
    tagSlug: 'tag-012',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-013',
    tagName: 'ตัวอย่างแท็ก 013',
    tagSlug: 'tag-013',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-014',
    tagName: 'ตัวอย่างแท็ก 014',
    tagSlug: 'tag-014',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-015',
    tagName: 'ตัวอย่างแท็ก 015',
    tagSlug: 'tag-015',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-016',
    tagName: 'ตัวอย่างแท็ก 016',
    tagSlug: 'tag-016',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-017',
    tagName: 'ตัวอย่างแท็ก 017',
    tagSlug: 'tag-017',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'tag-018',
    tagName: 'ตัวอย่างแท็ก 018',
    tagSlug: 'tag-018',
    usageCount: 0,
    createdAt: '2024-01-01T00:00:00.000Z'
  }
];
