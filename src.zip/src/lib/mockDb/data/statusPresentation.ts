export type StatusContext = 'staff' | 'customer' | 'report';

/**
 * หมายเหตุ:
 * - badgeVariant เป็น “ชื่อเชิงตรรกะ” สำหรับ UI (คุณจะ map ไป class จริงอีกที)
 * - ไม่ผูกกับ shadcn โดยตรง เพื่อให้ย้ายไป backend ได้ง่าย
 */
export type BadgeVariant =
  | 'blue'
  | 'green'
  | 'gray'
  | 'amber'
  | 'red'
  | 'zinc'
  | 'purple'
  | 'pink'
  | 'indigo';

export interface StatusPresentationItem {
  /** staff/customer/report */
  context: StatusContext;

  /**
   * key ที่ UI ใช้แสดง (แนะนำให้เป็น primary key เช่น new/in_progress/waiting/resolved/closed)
   * แต่อนาคตจะให้เป็น key อะไรก็ได้ (เช่น group key) ก็ทำได้
   */
  key: string;

  /** ชื่อที่แสดงผล (Admin เปลี่ยนได้) */
  label: string;

  /** สี/variant สำหรับ badge */
  badgeVariant?: BadgeVariant;

  /** ลำดับใน dropdown */
  order: number;

  /** กลุ่ม (optional) */
  groupKey?: string;

  /**
   * หัวใจของระบบ:
   * สถานะจริงใน ticket.status ใดบ้าง ที่ถูก “แสดงเป็น key นี้”
   * เช่น new mapsFrom = [new, tier1, tier2, tier3]
   */
  mapsFrom?: string[];

  /** เปิด/ปิดการแสดงใน UI */
  isActive: boolean;
}

/**
 * ✅ Status Presentation (Admin-configurable)
 * - เปลี่ยน label / สี / order / mapsFrom ได้ที่นี่
 * - ต่อไปย้ายไป DB จริงได้โดยใช้ schema เดียวกัน
 */



// บรรทัด 47-103 เปลี่ยนเป็น
export const statusPresentation: StatusPresentationItem[] = [
  // STAFF CONTEXT
  {
    context: 'staff',
    key: 'new',
    label: 'ใหม่',
    badgeVariant: 'blue',
    order: 10,
    mapsFrom: ['new'],  // ⭐ เฉพาะ new (assignedTo = null)
    isActive: true,
  },
  {
    context: 'staff',
    key: 'pending',  // ⭐ เพิ่ม pending
    label: 'รอดำเนินการ',
    badgeVariant: 'purple',
    order: 15,
    mapsFrom: ['tier1', 'tier2', 'tier3'],  // ⭐ tier ที่รอรับ
    isActive: true,
  },
  {
    context: 'staff',
    key: 'in_progress',
    label: 'กำลังดำเนินการ',
    badgeVariant: 'amber',
    order: 20,
    mapsFrom: ['in_progress'],
    isActive: true,
  },
  {
    context: 'staff',
    key: 'on_hold',
    label: 'หยุดชั่วคราว',
    badgeVariant: 'gray',
    order: 30,
    mapsFrom: ['waiting', 'on_hold'],
    isActive: true,
  },
  {
    context: 'staff',
    key: 'resolved',
    label: 'แก้ไขแล้ว',
    badgeVariant: 'green',
    order: 40,
    mapsFrom: ['resolved', 'pending_closure', 'awaiting_closure'],
    isActive: true,
  },
  {
    context: 'staff',
    key: 'closed',
    label: 'ปิดแล้ว',
    badgeVariant: 'zinc',
    order: 50,
    mapsFrom: ['closed'],
    isActive: true,
  },
  // ... customer/report เหมือนเดิม
  // =========================
  // CUSTOMER CONTEXT (หน้าลูกค้า)
  // =========================
  {
    context: 'customer',
    key: 'new',
    label: 'เปิดเคสแล้ว',
    badgeVariant: 'blue',
    order: 10,
    mapsFrom: ['new', 'tier1', 'tier2', 'tier3'],
    isActive: true,
  },
  {
    context: 'customer',
    key: 'in_progress',
    label: 'กำลังดำเนินการ',
    badgeVariant: 'amber',
    order: 20,
    mapsFrom: ['in_progress', 'waiting', 'on_hold'],
    isActive: true,
  },
  {
    context: 'customer',
    key: 'resolved',
    label: 'แก้ไขเรียบร้อย',
    badgeVariant: 'green',
    order: 30,
    mapsFrom: ['resolved', 'pending_closure', 'awaiting_closure'],
    isActive: true,
  },
  {
    context: 'customer',
    key: 'closed',
    label: 'ปิดเคสแล้ว',
    badgeVariant: 'zinc',
    order: 40,
    mapsFrom: ['closed'],
    isActive: true,
  },

  // =========================
  // REPORT CONTEXT (รายงาน/BI) - (optional)
  // =========================
  {
    context: 'report',
    key: 'new',
    label: 'New / Queue',
    badgeVariant: 'blue',
    order: 10,
    mapsFrom: ['new', 'tier1', 'tier2', 'tier3'],
    isActive: false, // ปิดไว้ก่อน (เปิดเมื่อทำ report)
  },
];
