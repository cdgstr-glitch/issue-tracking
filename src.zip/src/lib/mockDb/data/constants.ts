// src/lib/mockDb/data/constants.ts
// ======================================================
// CDGS Issue Tracking - Constants (Single Source of Truth)
// ======================================================
//
// ✅ Single export: export const constants = { ... }
// ❌ No default export
// ❌ No dual exports
//
// This file intentionally consolidates all previously-scattered constants
// into ONE object for Laravel-ready migration safety.
// (Think: Laravel config array / seed config)
//
// NOTE:
// - Keep this file pure configuration (no runtime logic / no side effects)
// - Use IDs/values that match your types and DB enums.
//

import type { TicketStatus, TicketPriority, TicketChannel, TicketType } from '../types';

export const constants = {
  // ==================== TICKET CONFIGURATION ====================

  TICKET_CATEGORIES: [
    'Hardware & Equipment',
    'Software & Applications',
    'Network & Connectivity',
    'User Account & Access',
    'Email & Communication',
    'Security',
    'Data & Backup',
    'Documentation',
    'License Management',
    'Performance',
    'Technical Support',
    'Product Information',
    'Other',
  ] as const,

  TICKET_PRIORITIES: {
    low: {
      label: 'low',
      customerLabel: 'ปกติ',
      color: 'bg-gray-100 text-gray-800',
      level: 1,
    },
    medium: {
      label: 'medium',
      customerLabel: 'ปานกลาง',
      color: 'bg-blue-100 text-blue-800',
      level: 2,
    },
    high: {
      label: 'high',
      customerLabel: 'ด่วน',
      color: 'bg-orange-100 text-orange-800',
      level: 3,
    },
    critical: {
      label: 'critical',
      customerLabel: 'เร่งด่วนมาก',
      color: 'bg-red-100 text-red-800',
      level: 4,
    },
  } as const satisfies Record<
    TicketPriority,
    { label: string; customerLabel: string; color: string; level: number }
  >,

  // ⚠️ Note:
  // You currently have tier1/tier2/tier3 here (legacy status-as-tier).
  // In your newer model, tier is "stage" not "status".
  // We keep these keys for backward compatibility but you should avoid
  // using them as TicketStatus in new logic.
  TICKET_STATUSES: {
    new: {
      label: 'รอรับเรื่อง',
      customerLabel: 'เปิดเคสแล้ว',
      color: 'bg-blue-100 text-blue-800',
      customerColor: 'bg-blue-50 text-blue-700 border-blue-200',
      description: 'เคสใหม่ที่ยังไม่มีผู้รับผิดชอบ',
    },

    // legacy (tier as status) — keep for compatibility
    tier1: {
      label: 'เทียร์ 1',
      customerLabel: 'กำลังดำเนินการ',
      color: 'bg-purple-100 text-purple-800',
      customerColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      description: 'กำลังดำเนินการโดย Tier 1',
    },
    tier2: {
      label: 'เทียร์ 2',
      customerLabel: 'กำลังดำเนินการ',
      color: 'bg-indigo-100 text-indigo-800',
      customerColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      description: 'ส่งต่อให้ Tier 2 ตรวจสอบ',
    },
    tier3: {
      label: 'เทียร์ 3',
      customerLabel: 'กำลังดำเนินการ',
      color: 'bg-pink-100 text-pink-800',
      customerColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      description: 'ส่งต่อให้ Tier 3 ผู้เชี่ยวชาญ',
    },

    in_progress: {
      label: 'กำลังดำเนินการ',
      customerLabel: 'กำลังดำเนินการ',
      color: 'bg-amber-100 text-amber-800',
      customerColor: 'bg-amber-50 text-amber-700 border-amber-200',
      description: 'เจ้าหน้าที่กำลังแก้ไขปัญหา',
    },
    waiting: {
      label: 'รอข้อมูล',
      customerLabel: 'รอข้อมูลเพิ่มเติม',
      color: 'bg-yellow-100 text-yellow-800',
      customerColor: 'bg-orange-50 text-orange-700 border-orange-200',
      description: 'รอข้อมูลเพิ่มเติมหรือหยุดเวลา SLA',
    },
    resolved: {
      label: 'แก้ไขแล้ว',
      customerLabel: 'แก้ไขเรียบร้อย',
      color: 'bg-green-100 text-green-800',
      customerColor: 'bg-green-50 text-green-700 border-green-200',
      description: 'ปัญหาได้รับการแก้ไขแล้ว รอปิดเคส',
    },
    pending_closure: {
      label: 'แก้ไขแล้ว',
      customerLabel: 'แก้ไขเรียบร้อย',
      color: 'bg-green-100 text-green-800',
      customerColor: 'bg-green-50 text-green-700 border-green-200',
      description: 'ปัญหาได้รับการแก้ไขแล้ว รอปิดเคส',
    },
    closed: {
      label: 'ปิดเคส',
      customerLabel: 'ปิดเคสแล้ว',
      color: 'bg-gray-100 text-gray-800',
      customerColor: 'bg-gray-50 text-gray-700 border-gray-200',
      description: 'เคสถูกปิดสมบูรณ์แล้ว',
    },
  } as const satisfies Record<
    string,
    {
      label: string;
      customerLabel: string;
      color: string;
      customerColor: string;
      description: string;
    }
  >,

  TICKET_CHANNELS: {
    web: { label: 'Web', color: 'bg-purple-100 text-purple-700', icon: 'Globe' },
    email: { label: 'Email', color: 'bg-blue-100 text-blue-700', icon: 'Mail' },
    line: { label: 'Line', color: 'bg-green-100 text-green-700', icon: 'MessageCircle' },
    phone: { label: 'Phone', color: 'bg-red-100 text-red-700', icon: 'Phone' },
  } as const satisfies Record<TicketChannel, { label: string; color: string; icon: string }>,

  TICKET_TYPES: {
    incident: { label: 'Incident', description: 'เหตุการณ์ขัดข้อง' },
    service_request: { label: 'Service Request', description: 'คำร้องขอใช้บริการ' },
    security_incident: { label: 'Security Incident', description: 'เหตุการณ์ความปลอดภัย' },
    change_request: {
      label: 'Change Request',
      description: 'คำขอเปลี่ยนแปลงระบบ/การตั้งค่า/กระบวนการ',
    },
    problem: { label: 'Problem', description: 'การวิเคราะห์สาเหตุราก (Root Cause) และป้องกันการเกิดซ้ำ' },
  } as const satisfies Record<TicketType, { label: string; description: string }>,

  // ==================== PRODUCT CONFIGURATION ====================

  PRODUCT_CATEGORIES: {
    software: { label: 'Software', icon: 'AppWindow' },
    hardware: { label: 'Hardware', icon: 'HardDrive' },
    service: { label: 'Service', icon: 'Headphones' },
    document: { label: 'Document', icon: 'FileText' },
    asset: { label: 'Asset', icon: 'Box' },
    hr: { label: 'HR', icon: 'Users' },
    facility: { label: 'Facility', icon: 'Building' },
    project: { label: 'Project', icon: 'Briefcase' },
  } as const,

  // ==================== BUSINESS RULES ====================

  // Inverted Visibility Model Rules
  VISIBILITY_RULES: {
    tier1: {
      allowedStatuses: [
        'new',
        'tier1',
        'tier2',
        'tier3',
        'in_progress',
        'on_hold',
        'resolved',
        'pending_closure',
        'closed',
      ],
      blockedStatuses: [],
    },
    tier2: {
      allowedStatuses: [
        'tier2',
        'tier3',
        'in_progress',
        'on_hold',
        'resolved',
        'pending_closure',
        'closed',
      ],
      blockedStatuses: ['new', 'tier1'],
    },
    tier3: {
      allowedStatuses: ['tier3', 'in_progress', 'on_hold', 'resolved', 'pending_closure', 'closed'],
      blockedStatuses: ['new', 'tier1', 'tier2'],
    },
  } as const,

  // Default SLA (Hours) - Fallback if not found in slaSettings table
  DEFAULT_SLA_CONFIG: {
    low: { incident: 24, service_request: 72, security_incident: 8, problem: 120, change_request: 168 },
    medium: { incident: 8, service_request: 48, security_incident: 4, problem: 72, change_request: 120 },
    high: { incident: 4, service_request: 24, security_incident: 2, problem: 48, change_request: 72 },
    critical: { incident: 1, service_request: 8, security_incident: 1, problem: 24, change_request: 48 },
  } as const,

  // ==================== UI CONFIGURATION ====================

  UI_CONFIG: {
    // 'view' = Show View Badge (Old behavior)
    // 'assignee' = Show Assignee Badge in Title Column
    TICKET_TABLE_BADGE_MODE: 'assignee' as 'view' | 'assignee',
  } as const,
} as const;
