export const closureSources = [
  { code: 'instant_close', label: 'แจ้งแล้วปิดทันที', description: 'รับแจ้งและปิดทันทีในขั้นตอนเดียว' },
  { code: 'handoff_to_tier1_close', label: 'ส่งมาให้ Tier1 ปิด', description: 'แก้ไขโดยทีมอื่นแล้วส่งกลับให้ Tier1 ปิด' },
  { code: 'normal_close', label: 'ปิดตามปกติ', description: 'ปิดตามกระบวนการปกติหลังดำเนินการ' },
] as const;

export type ClosureSourceCode = typeof closureSources[number]['code'];
