import { statusPresentation, type StatusContext } from '@/lib/mockDb/data/statusPresentation';
import { statusCatalog } from '@/lib/mockDb/data/statusCatalog';

/**
 * buildStatusResolver
 *
 * สร้าง resolver สำหรับจัดการ status แบบ flexible
 * - normalize: แปลง raw status เป็น display status
 * - getMeta: ดึง label/variant
 * - getOptions: ดึง dropdown options
 */
export function buildStatusResolver(context: StatusContext = 'staff') {
  try {
    // Filter presentation items by context
    const presentationItems = statusPresentation.filter(
      item => item.context === context && item.isActive
    );

    if (!presentationItems || presentationItems.length === 0) {
      console.error('❌ No presentation items found for context:', context);
      return createFallbackResolver();
    }

    // Build fromTo map
    const fromTo = new Map<string, string>();
    for (const item of presentationItems) {
      if (item.mapsFrom && Array.isArray(item.mapsFrom)) {
        for (const rawStatus of item.mapsFrom) {
          fromTo.set(rawStatus, item.key);
        }
      }
    }

    // Build metaByKey map
    const metaByKey = new Map<string, { label: string; variant: string }>();
    for (const item of presentationItems) {
      metaByKey.set(item.key, {
        label: item.label,
        variant: item.badgeVariant || 'gray',
      });
    }

    return {
      normalize: (rawStatus: string): string => {
        const normalized = fromTo.get(rawStatus);
        if (!normalized) {
          // unknown raw status -> return as-is
          return rawStatus;
        }
        return normalized;
      },

      getMeta: (statusKey: string) => {
        const meta = metaByKey.get(statusKey);
        if (!meta) {
          return { label: statusKey, variant: 'gray' };
        }
        return meta;
      },

      getOptions: () => {
        return presentationItems
          .sort((a, b) => a.order - b.order)
          .map(item => ({
            value: item.key,
            label: item.label,
          }));
      },

      _debug: () => ({
        context,
        itemsCount: presentationItems.length,
        fromToSize: fromTo.size,
        metaByKeySize: metaByKey.size,
        items: presentationItems,
      }),
    };
  } catch (error) {
    console.error('❌ Error building status resolver:', error);
    return createFallbackResolver();
  }
}

/**
 * Fallback resolver - ใช้เมื่อ build ล้มเหลว
 */
function createFallbackResolver() {
  return {
    normalize: (rawStatus: string): string => rawStatus,
    getMeta: (statusKey: string) => ({ label: statusKey, variant: 'gray' as const }),
    getOptions: () => [
      { value: 'new', label: 'ใหม่' },
      { value: 'in_progress', label: 'กำลังดำเนินการ' },
      { value: 'on_hold', label: 'หยุดชั่วคราว' },
      { value: 'resolved', label: 'แก้ไขแล้ว' },
      { value: 'closed', label: 'ปิดแล้ว' },
    ],
    _debug: () => ({ fallback: true }),
  };
}

/**
 * Helper: ตรวจสอบว่า status ถูกต้องหรือไม่
 */
export function isValidStatus(status: string): boolean {
  return statusCatalog.some(item => item.key === status && item.isActive);
}

/**
 * Helper: ดึง status ทั้งหมดที่ valid
 */
export function getAllValidStatuses(): string[] {
  return statusCatalog
    .filter(item => item.isActive)
    .map(item => item.key);
}
