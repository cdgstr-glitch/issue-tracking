// src/lib/mockDb/data/ticket_tags.ts
// ✅ Minimal Test Suite - Ticket Tags pivot (empty for now)
// ✅ Laravel-ready: FK-based

import type { TicketTag } from '../../../types';

export const ticketTags: TicketTag[] = [];
