// src/lib/mockDb/data/attachments.ts
// ✅ Minimal Test Suite - Attachments (empty for now)
// ✅ Laravel-ready: FK-based

import type { Attachment } from '../../../types';

export const attachments: Attachment[] = [];
