import type { SLASetting, TicketPriority, TicketType, SLAScope } from '../../types';

/**
 * SLA Settings (legacy-compatible + backend-ready)
 *
 * ✅ This file supports:
 * - Current UI: scope/targetId/ticketType/hours (legacy)
 * - Backend normalized: responseTimeHours/resolutionTimeHours (required)
 *
 * Notes:
 * - Canonical priority in masterData.ts uses: low/medium/high/critical
 * - ticketType supports: incident/service_request/security_incident/problem/change_request
 */
const now = () => new Date().toISOString();

type LegacyRow = {
  id: string;
  priority: TicketPriority;
  ticketType: TicketType;
  hours: number;

  // legacy
  scope?: SLAScope;
  targetId?: string | null;

  // legacy alt fields (if someone still uses them)
  organizationId?: string;
  projectId?: string;
};

const toSlaSetting = (r: LegacyRow): SLASetting => {
  // Normalize scope/targetId from legacy organizationId/projectId if present
  const scope: SLAScope =
    r.scope ??
    (r.projectId ? 'project' : r.organizationId ? 'organization' : 'global');

  const targetId =
    r.targetId ??
    (r.projectId ? r.projectId : r.organizationId ? r.organizationId : null);

  return {
    id: r.id,
    priority: r.priority,

    // ✅ backend-ready clocks (required)
    responseTimeHours: r.hours,
    resolutionTimeHours: r.hours,

    // ✅ legacy compatibility for existing SLA UI
    scope,
    targetId,
    ticketType: r.ticketType,
    hours: r.hours,

    isActive: true,
    createdAt: now(),
    updatedAt: now(),
  };
};

export const slaSettings: SLASetting[] = [
  // ==========================================
  // 1) GLOBAL DEFAULTS
  // ==========================================

  // Critical
  toSlaSetting({ id: 'sla-gen-1', priority: 'critical', ticketType: 'incident', hours: 1 }),
  toSlaSetting({ id: 'sla-gen-2', priority: 'critical', ticketType: 'service_request', hours: 2 }),
  toSlaSetting({ id: 'sla-gen-3', priority: 'critical', ticketType: 'security_incident', hours: 0.5 }),

  // High
  toSlaSetting({ id: 'sla-gen-4', priority: 'high', ticketType: 'incident', hours: 4 }),
  toSlaSetting({ id: 'sla-gen-5', priority: 'high', ticketType: 'service_request', hours: 8 }),
  toSlaSetting({ id: 'sla-gen-6', priority: 'high', ticketType: 'security_incident', hours: 2 }),

  // Medium
  toSlaSetting({ id: 'sla-gen-7', priority: 'medium', ticketType: 'incident', hours: 8 }),
  toSlaSetting({ id: 'sla-gen-8', priority: 'medium', ticketType: 'service_request', hours: 24 }),
  toSlaSetting({ id: 'sla-gen-9', priority: 'medium', ticketType: 'security_incident', hours: 4 }),

  // Low
  toSlaSetting({ id: 'sla-gen-10', priority: 'low', ticketType: 'incident', hours: 24 }),
  toSlaSetting({ id: 'sla-gen-11', priority: 'low', ticketType: 'service_request', hours: 72 }),
  toSlaSetting({ id: 'sla-gen-12', priority: 'low', ticketType: 'security_incident', hours: 8 }),

  // ==========================================
  // 2) ORGANIZATION OVERRIDES (example)
  // ==========================================
  // Use a real-ish org id (exists in your dataset): org-csv-001
  toSlaSetting({
    id: 'sla-org-1',
    priority: 'critical',
    ticketType: 'incident',
    hours: 0.5,
    scope: 'organization',
    targetId: 'org-csv-001',
  }),
  toSlaSetting({
    id: 'sla-org-2',
    priority: 'high',
    ticketType: 'incident',
    hours: 2,
    scope: 'organization',
    targetId: 'org-csv-001',
  }),

  // ==========================================
  // 3) PROJECT OVERRIDES (example)
  // ==========================================
  // Use a real-ish project id (exists in your dataset): proj-csv-001
  toSlaSetting({
    id: 'sla-proj-1',
    priority: 'critical',
    ticketType: 'incident',
    hours: 0.25, // 15 mins
    scope: 'project',
    targetId: 'proj-csv-001',
  }),
];
