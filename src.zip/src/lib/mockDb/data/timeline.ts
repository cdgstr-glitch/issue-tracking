// src/lib/mockDb/data/timeline.ts
// ✅ Minimal Test Suite - Timeline events for 11 test cases
// ✅ Laravel-ready: FK-based, SSoT-compliant

import type { TimelineEvent } from '../../../types';

export const timeline: TimelineEvent[] = [
  // ══════════════════════════════════════════════════════════════════
  // MIN-NEW1: เคสใหม่ Staff สร้าง (created only)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-new1-001',
    ticketId: 'min-new1',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-19T08:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-PND1: Pending (created + assignment)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-pnd1-001',
    ticketId: 'min-pnd1',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-19T08:30:00.000Z',
  },
  {
    id: 'tl-pnd1-002',
    ticketId: 'min-pnd1',
    eventType: 'assignment',
    actorUserId: 'user-001',  // Supervisor มอบหมาย
    assignedToUserId: 'user-003',  // วรรณภา
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-19T08:35:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-WIP1: In Progress (created + assignment + accepted)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-wip1-001',
    ticketId: 'min-wip1',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-19T07:00:00.000Z',
  },
  {
    id: 'tl-wip1-002',
    ticketId: 'min-wip1',
    eventType: 'assignment',
    actorUserId: 'user-001',
    assignedToUserId: 'user-003',
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-19T07:05:00.000Z',
  },
  {
    id: 'tl-wip1-003',
    ticketId: 'min-wip1',
    eventType: 'accepted',
    actorUserId: 'user-003',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-19T09:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-H12: T1 → T2 Escalation
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-h12-001',
    ticketId: 'min-h12',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-19T06:00:00.000Z',
  },
  {
    id: 'tl-h12-002',
    ticketId: 'min-h12',
    eventType: 'assignment',
    actorUserId: 'user-001',
    assignedToUserId: 'user-003',
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-19T06:05:00.000Z',
  },
  {
    id: 'tl-h12-003',
    ticketId: 'min-h12',
    eventType: 'accepted',
    actorUserId: 'user-003',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-19T06:10:00.000Z',
  },
  {
    id: 'tl-h12-004',
    ticketId: 'min-h12',
    eventType: 'escalation',
    actorUserId: 'user-003',  // T1 ส่งต่อ
    assignedToUserId: 'user-007',  // ประกาศิต
    fromTier: 'tier1',
    toTier: 'tier2',
    reason: 'ต้องการให้ทีมเทคนิคตรวจสอบปัญหา performance',
    description: 'ส่งต่อไปยัง Tier 2',
    createdAt: '2026-02-19T10:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-H23: T2 → T3 Escalation
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-h23-001',
    ticketId: 'min-h23',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-19T05:00:00.000Z',
  },
  {
    id: 'tl-h23-002',
    ticketId: 'min-h23',
    eventType: 'assignment',
    actorUserId: 'user-001',
    assignedToUserId: 'user-003',
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-19T05:05:00.000Z',
  },
  {
    id: 'tl-h23-003',
    ticketId: 'min-h23',
    eventType: 'escalation',
    actorUserId: 'user-003',
    assignedToUserId: 'user-008',  // ประวิช (T2)
    fromTier: 'tier1',
    toTier: 'tier2',
    reason: 'ปัญหา Critical ต้องการทีมเทคนิค',
    description: 'ส่งต่อไปยัง Tier 2',
    createdAt: '2026-02-19T05:30:00.000Z',
  },
  {
    id: 'tl-h23-004',
    ticketId: 'min-h23',
    eventType: 'accepted',
    actorUserId: 'user-008',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-19T05:35:00.000Z',
  },
  {
    id: 'tl-h23-005',
    ticketId: 'min-h23',
    eventType: 'escalation',
    actorUserId: 'user-008',  // T2 ส่งต่อ
    assignedToUserId: 'user-007',  // ประกาศิต (as T3)
    fromTier: 'tier2',
    toTier: 'tier3',
    reason: 'ต้องการ Expert วิเคราะห์ปัญหา Database Connection Pool',
    description: 'ส่งต่อไปยัง Tier 3',
    createdAt: '2026-02-19T11:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-H33: T3 → T3 Reassign
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-h33-001',
    ticketId: 'min-h33',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-19T04:00:00.000Z',
  },
  {
    id: 'tl-h33-002',
    ticketId: 'min-h33',
    eventType: 'escalation',
    actorUserId: 'user-001',
    assignedToUserId: 'user-009',  // พุทธจักษ์ (T3)
    fromTier: 'tier1',
    toTier: 'tier3',
    reason: 'ส่งตรงไป Expert',
    description: 'ส่งต่อไปยัง Tier 3',
    createdAt: '2026-02-19T04:10:00.000Z',
  },
  {
    id: 'tl-h33-003',
    ticketId: 'min-h33',
    eventType: 'accepted',
    actorUserId: 'user-009',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-19T04:15:00.000Z',
  },
  {
    id: 'tl-h33-004',
    ticketId: 'min-h33',
    eventType: 'escalation',
    actorUserId: 'user-009',  // พุทธจักษ์ ส่งต่อ
    assignedToUserId: 'user-007',  // ประกาศิต (T3 reassign)
    fromTier: 'tier3',
    toTier: 'tier3',  // ⭐ T3 → T3 (peer transfer)
    reason: 'ต้องการ Specialist ด้าน CTL โดยเฉพาะ',
    description: 'ส่งต่อภายใน Tier 3',
    createdAt: '2026-02-19T12:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-BCK1: T2 → T1 for_continuation
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-bck1-001',
    ticketId: 'min-bck1',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-18T10:00:00.000Z',
  },
  {
    id: 'tl-bck1-002',
    ticketId: 'min-bck1',
    eventType: 'assignment',
    actorUserId: 'user-001',
    assignedToUserId: 'user-003',
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-18T10:05:00.000Z',
  },
  {
    id: 'tl-bck1-003',
    ticketId: 'min-bck1',
    eventType: 'escalation',
    actorUserId: 'user-003',
    assignedToUserId: 'user-007',
    fromTier: 'tier1',
    toTier: 'tier2',
    reason: 'ต้องการตรวจสอบ Permission System',
    description: 'ส่งต่อไปยัง Tier 2',
    createdAt: '2026-02-18T10:30:00.000Z',
  },
  {
    id: 'tl-bck1-004',
    ticketId: 'min-bck1',
    eventType: 'accepted',
    actorUserId: 'user-007',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-18T10:35:00.000Z',
  },
  {
    id: 'tl-bck1-005',
    ticketId: 'min-bck1',
    eventType: 'escalation',
    actorUserId: 'user-007',  // T2 ส่งกลับ
    assignedToUserId: 'user-003',  // วรรณภา
    fromTier: 'tier2',
    toTier: 'tier1',
    escalationType: 'for_continuation',  // ⭐ ส่งกลับให้แก้ต่อ
    reason: 'เป็นการตั้งค่า User Permission ธรรมดา T1 ดำเนินการเองได้ ดู comment ประกอบ',
    description: 'ส่งกลับ Tier 1 เพื่อดำเนินการต่อ',
    createdAt: '2026-02-19T13:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-C21: T2 → T1 for_closure → Closed
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-c21-001',
    ticketId: 'min-c21',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-17T09:00:00.000Z',
  },
  {
    id: 'tl-c21-002',
    ticketId: 'min-c21',
    eventType: 'assignment',
    actorUserId: 'user-001',
    assignedToUserId: 'user-003',
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-17T09:05:00.000Z',
  },
  {
    id: 'tl-c21-003',
    ticketId: 'min-c21',
    eventType: 'escalation',
    actorUserId: 'user-003',
    assignedToUserId: 'user-007',
    fromTier: 'tier1',
    toTier: 'tier2',
    reason: 'ปัญหา Database Configuration ต้องการทีมเทคนิค',
    description: 'ส่งต่อไปยัง Tier 2',
    createdAt: '2026-02-17T10:00:00.000Z',
  },
  {
    id: 'tl-c21-004',
    ticketId: 'min-c21',
    eventType: 'accepted',
    actorUserId: 'user-007',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-17T10:10:00.000Z',
  },
  {
    id: 'tl-c21-005',
    ticketId: 'min-c21',
    eventType: 'status_change',
    actorUserId: 'user-007',
    fromStatus: 'in_progress',
    toStatus: 'resolved',
    description: 'แก้ไขปัญหาเสร็จสิ้น',
    createdAt: '2026-02-18T16:00:00.000Z',
  },
  {
    id: 'tl-c21-006',
    ticketId: 'min-c21',
    eventType: 'escalation',
    actorUserId: 'user-007',
    assignedToUserId: 'user-003',
    fromTier: 'tier2',
    toTier: 'tier1',
    escalationType: 'for_closure',  // ⭐ ส่งกลับเพื่อปิด
    reason: 'แก้ไข database configuration เสร็จแล้ว',
    description: 'ส่งกลับ Tier 1 เพื่อปิดเคส',
    createdAt: '2026-02-18T16:05:00.000Z',
  },
  {
    id: 'tl-c21-007',
    ticketId: 'min-c21',
    eventType: 'accepted',
    actorUserId: 'user-003',
    description: 'รับเคสกลับแล้ว',
    createdAt: '2026-02-18T16:30:00.000Z',
  },
  {
    id: 'tl-c21-008',
    ticketId: 'min-c21',
    eventType: 'closed',
    actorUserId: 'user-003',  // ⭐ Tier1 เท่านั้นที่ปิดได้
    description: 'ปิดเคส',
    createdAt: '2026-02-18T17:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-C31: T3 → T1 for_closure → Closed
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-c31-001',
    ticketId: 'min-c31',
    eventType: 'created',
    actorUserId: 'staff-002',
    description: 'สร้างเคสใหม่',
    createdAt: '2026-02-16T08:00:00.000Z',
  },
  {
    id: 'tl-c31-002',
    ticketId: 'min-c31',
    eventType: 'escalation',
    actorUserId: 'user-001',
    assignedToUserId: 'user-007',  // ประกาศิต (as T3)
    fromTier: 'tier1',
    toTier: 'tier3',
    reason: 'ปัญหา Critical System Failure ต้องการ Expert',
    description: 'ส่งตรงไปยัง Tier 3',
    createdAt: '2026-02-16T08:10:00.000Z',
  },
  {
    id: 'tl-c31-003',
    ticketId: 'min-c31',
    eventType: 'accepted',
    actorUserId: 'user-007',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-16T08:15:00.000Z',
  },
  {
    id: 'tl-c31-004',
    ticketId: 'min-c31',
    eventType: 'status_change',
    actorUserId: 'user-007',
    fromStatus: 'in_progress',
    toStatus: 'resolved',
    description: 'แก้ไขปัญหาเสร็จสิ้น',
    createdAt: '2026-02-17T14:00:00.000Z',
  },
  {
    id: 'tl-c31-005',
    ticketId: 'min-c31',
    eventType: 'escalation',
    actorUserId: 'user-007',
    assignedToUserId: 'user-003',
    fromTier: 'tier3',
    toTier: 'tier1',
    escalationType: 'for_closure',  // ⭐ ส่งกลับเพื่อปิด
    reason: 'แก้ไข memory leak และ restart services เรียบร้อยแล้ว',
    description: 'ส่งกลับ Tier 1 เพื่อปิดเคส',
    createdAt: '2026-02-17T14:10:00.000Z',
  },
  {
    id: 'tl-c31-006',
    ticketId: 'min-c31',
    eventType: 'accepted',
    actorUserId: 'user-003',
    description: 'รับเคสกลับแล้ว',
    createdAt: '2026-02-17T14:30:00.000Z',
  },
  {
    id: 'tl-c31-007',
    ticketId: 'min-c31',
    eventType: 'closed',
    actorUserId: 'user-003',  // ⭐ Tier1 เท่านั้นที่ปิดได้
    description: 'ปิดเคส',
    createdAt: '2026-02-17T15:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-CUST1: ⭐ Customer สร้างเอง (ยังไม่มี org/project)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-cust1-001',
    ticketId: 'min-cust1',
    eventType: 'created',
    actorCustomerId: 'cust-001',  // ⭐ Customer สร้างเอง
    description: 'ลูกค้าสร้างเคสใหม่',
    createdAt: '2026-02-19T09:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-CUST2: ⭐ Customer สร้างเอง + T1 รับแล้ว + กรอก org/project แล้ว
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'tl-cust2-001',
    ticketId: 'min-cust2',
    eventType: 'created',
    actorCustomerId: 'cust-001',  // ⭐ Customer สร้างเอง
    description: 'ลูกค้าสร้างเคสใหม่',
    createdAt: '2026-02-19T07:30:00.000Z',
  },
  {
    id: 'tl-cust2-002',
    ticketId: 'min-cust2',
    eventType: 'assignment',
    actorUserId: 'user-001',  // Supervisor มอบหมาย
    assignedToUserId: 'user-003',  // วรรณภา
    toTier: 'tier1',
    description: 'มอบหมายให้ วรรณภา แซ่ด่าง',
    createdAt: '2026-02-19T08:00:00.000Z',
  },
  {
    id: 'tl-cust2-003',
    ticketId: 'min-cust2',
    eventType: 'accepted',
    actorUserId: 'user-003',
    description: 'รับเคสแล้ว',
    createdAt: '2026-02-19T09:30:00.000Z',
  },
  {
    id: 'tl-cust2-004',
    ticketId: 'min-cust2',
    eventType: 'field_updated',
    actorUserId: 'user-003',
    fieldName: 'organizationId',
    newValue: 'org-csv-001',
    description: 'T1 กรอก หน่วยงาน: ERC',
    createdAt: '2026-02-19T09:31:00.000Z',
  },
  {
    id: 'tl-cust2-005',
    ticketId: 'min-cust2',
    eventType: 'field_updated',
    actorUserId: 'user-003',
    fieldName: 'projectId',
    newValue: 'proj-001',
    description: 'T1 กรอก รหัสโครงการ: D24-6001',
    createdAt: '2026-02-19T09:32:00.000Z',
  },
];
