import type { User } from '../../../types';

export const users: User[] = [
  // 1. Thiraporn Rungwiratkul - Supervisor
  {
    id: 'user-001',
    username: 'thiraporn.r',
    fullName: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
    primaryRole: 'supervisor',
    roles: ['supervisor'],
    email: 'thiraporn.r@cdg.co.th',
    phone: '+66-81-234-5678',
    department: 'ฝ่ายเทคโนโลยีสารสนเทศ',
    tier: 1,
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005', 'proj-006', 'proj-007', 'proj-008', 'proj-009', 'proj-010'],
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // 2. Sarin Chorphayorm - Supervisor
  {
    id: 'user-002',
    username: 'sarin.c',
    fullName: 'สาริน ช่อพะยอม',
    primaryRole: 'supervisor',
    roles: ['supervisor'],
    email: 'sarin.c@cdg.co.th',
    tier: 1,
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005', 'proj-006', 'proj-007', 'proj-008', 'proj-009', 'proj-010'],
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // 3. Wannapa Sae-dang - Tier1
  {
    id: 'user-003',
    username: 'wannapa.s',
    fullName: 'วรรณภา แซ่ด่าง',
    primaryRole: 'tier1',
    roles: ['tier1'],
    email: 'wannapa.s@cdg.co.th',
    tier: 1,
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005', 'proj-006', 'proj-007', 'proj-008', 'proj-009'],
    managerId: 'user-001',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 4. Khemika Saetang - Tier1
  {
    id: 'user-004',
    username: 'khemika.s',
    fullName: 'เขมิกา แซ่ตั้ง',
    primaryRole: 'tier1',
    roles: ['tier1'],
    email: 'khemika.s@cdg.co.th',
    tier: 1,
    projectIds: ['proj-001', 'proj-003', 'proj-004', 'proj-005', 'proj-008'],
    managerId: 'user-001',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 5. Thanyaporn Tongkaew - Tier1
  {
    id: 'user-005',
    username: 'thanyaporn.t',
    fullName: 'ธัญญาพร ทองแก้ว',
    primaryRole: 'tier1',
    roles: ['tier1'],
    email: 'thanyaporn.t@cdg.co.th',
    tier: 1,
    projectIds: ['proj-002', 'proj-003', 'proj-006', 'proj-007', 'proj-010'],
    managerId: 'user-001',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 6. Yuttana Knamingmongkol - Tier2
  {
    id: 'user-006',
    username: 'yuttana.k',
    fullName: 'ยุทธนา คณามิ่งมงคล',
    primaryRole: 'tier2',
    roles: ['tier2'],
    email: 'yuttana.k@cdg.co.th',
    tier: 2,
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005', 'proj-006', 'proj-007', 'proj-008', 'proj-009', 'proj-010'],
    managerId: 'user-001',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 7. Prakasit Prakongpetch - Tier2 + Tier3
  {
    id: 'user-007',
    username: 'prakasit.p',
    fullName: 'ประกาศิต ประคองเพ็ชร',
    primaryRole: 'tier2',
    roles: ['tier2', 'tier3'],
    email: 'prakasit.p@cdg.co.th',
    tier: 2,
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005', 'proj-006', 'proj-007', 'proj-008', 'proj-009', 'proj-010'],
    managerId: 'user-006',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 8. Pravich Jintanakorn - Tier2
  {
    id: 'user-008',
    username: 'pravich.j',
    fullName: 'ประวิช จินทนากร',
    primaryRole: 'tier2',
    roles: ['tier2'],
    email: 'pravich.j@cdg.co.th',
    tier: 2,
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005', 'proj-006', 'proj-007', 'proj-008'],
    managerId: 'user-006',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 9. Puttajak Wongphan - Tier3
  {
    id: 'user-009',
    username: 'puttajak.w',
    fullName: 'พุทธจักษ์ วงค์พันธ์',
    primaryRole: 'tier3',
    roles: ['tier3'],
    email: 'puttajak.w@cdg.co.th',
    tier: 3,
    projectIds: ['proj-001', 'proj-003', 'proj-004', 'proj-005', 'proj-009', 'proj-010'],
    managerId: 'user-006',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 10. Wirakorn Yuekyen - Tier3
  {
    id: 'user-010',
    username: 'wirakorn.y',
    fullName: 'วีระกร เยือกเย็น',
    primaryRole: 'tier3',
    roles: ['tier3'],
    email: 'wirakorn.y@cdg.co.th',
    tier: 3,
    projectIds: ['proj-001', 'proj-002', 'proj-006', 'proj-007', 'proj-008'],
    managerId: 'user-006',
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // 11. Pra-onrat Keeratiphajon - Admin
  {
    id: 'user-011',
    username: 'pra-onrat.k',
    fullName: 'ประอรรัตน์ กีรติผจญ',
    primaryRole: 'admin',
    roles: ['admin'],
    email: 'pra-onrat.k@cdg.co.th',
    projectIds: ['proj-001', 'proj-002', 'proj-003'],
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // Staff 1
  {
    id: 'staff-001',
    username: 'staff',
    fullName: 'เจ้าหน้าที่',
    primaryRole: 'staff',
    roles: ['staff'],
    email: 'staff@cdg.co.th',
    phone: '+66-82-345-6789',
    department: 'ฝ่ายบริการลูกค้า',
    projectIds: ['proj-001', 'proj-002', 'proj-003'],
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  
  // Staff 2
  {
    id: 'staff-002',
    username: 'eakkachai.b',
    fullName: 'เอกชัย เบ็นเจ๊ะอาหวัง',
    primaryRole: 'staff',
    roles: ['staff'],
    email: 'eakkachai.b@cdg.co.th',
    phone: '+66-82-456-7890',
    department: 'Digital & SaaS Project Support',
    projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005'],
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  // ⚠️ Customer records removed - customers live in customers.ts only
  // test-001 → customers.ts (id: 'test-001')
  // cust-002 → customers.ts (id: 'cust-002')
];