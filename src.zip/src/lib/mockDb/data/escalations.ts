// src/lib/mockDb/data/escalations.ts
// ✅ Minimal Test Suite - Escalation records
// ✅ Laravel-ready: FK-based, SSoT-compliant

import type { Escalation } from '../../../types';

export const escalations: Escalation[] = [
  // ══════════════════════════════════════════════════════════════════
  // MIN-H12: T1 → T2
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'esc-h12-001',
    ticketId: 'min-h12',
    fromTier: 'tier1',
    toTier: 'tier2',
    fromUserId: 'user-003',
    toUserId: 'user-007',
    reason: 'ต้องการให้ทีมเทคนิคตรวจสอบปัญหา performance',
    createdAt: '2026-02-19T10:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-H23: T1 → T2 → T3
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'esc-h23-001',
    ticketId: 'min-h23',
    fromTier: 'tier1',
    toTier: 'tier2',
    fromUserId: 'user-003',
    toUserId: 'user-008',
    reason: 'ปัญหา Critical ต้องการทีมเทคนิค',
    createdAt: '2026-02-19T05:30:00.000Z',
  },
  {
    id: 'esc-h23-002',
    ticketId: 'min-h23',
    fromTier: 'tier2',
    toTier: 'tier3',
    fromUserId: 'user-008',
    toUserId: 'user-007',
    reason: 'ต้องการ Expert วิเคราะห์ปัญหา Database Connection Pool',
    createdAt: '2026-02-19T11:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-H33: T1 → T3 → T3 (reassign)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'esc-h33-001',
    ticketId: 'min-h33',
    fromTier: 'tier1',
    toTier: 'tier3',
    fromUserId: 'user-001',
    toUserId: 'user-009',
    reason: 'ส่งตรงไป Expert',
    createdAt: '2026-02-19T04:10:00.000Z',
  },
  {
    id: 'esc-h33-002',
    ticketId: 'min-h33',
    fromTier: 'tier3',
    toTier: 'tier3',  // ⭐ T3 → T3 (peer transfer)
    fromUserId: 'user-009',
    toUserId: 'user-007',
    reason: 'ต้องการ Specialist ด้าน CTL โดยเฉพาะ',
    createdAt: '2026-02-19T12:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-BCK1: T1 → T2 → T1 (for_continuation)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'esc-bck1-001',
    ticketId: 'min-bck1',
    fromTier: 'tier1',
    toTier: 'tier2',
    fromUserId: 'user-003',
    toUserId: 'user-007',
    reason: 'ต้องการตรวจสอบ Permission System',
    createdAt: '2026-02-18T10:30:00.000Z',
  },
  {
    id: 'esc-bck1-002',
    ticketId: 'min-bck1',
    fromTier: 'tier2',
    toTier: 'tier1',
    fromUserId: 'user-007',
    toUserId: 'user-003',
    escalationType: 'for_continuation',  // ⭐ ส่งกลับให้แก้ต่อ
    reason: 'เป็นการตั้งค่า User Permission ธรรมดา T1 ดำเนินการเองได้ ดู comment ประกอบ',
    createdAt: '2026-02-19T13:00:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-C21: T1 → T2 → T1 (for_closure)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'esc-c21-001',
    ticketId: 'min-c21',
    fromTier: 'tier1',
    toTier: 'tier2',
    fromUserId: 'user-003',
    toUserId: 'user-007',
    reason: 'ปัญหา Database Configuration ต้องการทีมเทคนิค',
    createdAt: '2026-02-17T10:00:00.000Z',
  },
  {
    id: 'esc-c21-002',
    ticketId: 'min-c21',
    fromTier: 'tier2',
    toTier: 'tier1',
    fromUserId: 'user-007',
    toUserId: 'user-003',
    escalationType: 'for_closure',  // ⭐ ส่งกลับเพื่อปิด
    reason: 'แก้ไข database configuration เสร็จแล้ว',
    createdAt: '2026-02-18T16:05:00.000Z',
  },

  // ══════════════════════════════════════════════════════════════════
  // MIN-C31: T1 → T3 → T1 (for_closure)
  // ══════════════════════════════════════════════════════════════════
  {
    id: 'esc-c31-001',
    ticketId: 'min-c31',
    fromTier: 'tier1',
    toTier: 'tier3',
    fromUserId: 'user-001',
    toUserId: 'user-007',
    reason: 'ปัญหา Critical System Failure ต้องการ Expert',
    createdAt: '2026-02-16T08:10:00.000Z',
  },
  {
    id: 'esc-c31-002',
    ticketId: 'min-c31',
    fromTier: 'tier3',
    toTier: 'tier1',
    fromUserId: 'user-007',
    toUserId: 'user-003',
    escalationType: 'for_closure',  // ⭐ ส่งกลับเพื่อปิด
    reason: 'แก้ไข memory leak และ restart services เรียบร้อยแล้ว',
    createdAt: '2026-02-17T14:10:00.000Z',
  },
];
