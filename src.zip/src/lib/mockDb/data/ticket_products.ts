// src/lib/mockDb/data/ticket_products.ts
// ✅ Minimal Test Suite - Ticket-Product pivot table
// ✅ Laravel-ready: FK-based relational design
//
// 🔑 Logic สำคัญ:
// - ทุกเคสต้องมี product อย่างน้อย 1 รายการ
// - Customer สร้างเอง: เลือก product ได้ (ไม่ต้องรู้ org/project)

import type { TicketProduct } from '../../../types';

export const ticketProducts: TicketProduct[] = [
  // MIN-NEW1: e-Saraban
  {
    id: 'tp-new1-001',
    ticketId: 'min-new1',
    productId: 'prod-001',  // e-Saraban
    createdAt: '2026-02-19T08:00:00.000Z',
  },

  // MIN-PND1: e-DMS
  {
    id: 'tp-pnd1-001',
    ticketId: 'min-pnd1',
    productId: 'prod-002',  // e-DMS
    createdAt: '2026-02-19T08:30:00.000Z',
  },

  // MIN-WIP1: e-Meeting
  {
    id: 'tp-wip1-001',
    ticketId: 'min-wip1',
    productId: 'prod-003',  // e-Meeting
    createdAt: '2026-02-19T07:00:00.000Z',
  },

  // MIN-H12: e-Saraban
  {
    id: 'tp-h12-001',
    ticketId: 'min-h12',
    productId: 'prod-001',  // e-Saraban
    createdAt: '2026-02-19T06:00:00.000Z',
  },

  // MIN-H23: Network Infrastructure
  {
    id: 'tp-h23-001',
    ticketId: 'min-h23',
    productId: 'prod-008',  // Network Infrastructure
    createdAt: '2026-02-19T05:00:00.000Z',
  },

  // MIN-H33: CTL
  {
    id: 'tp-h33-001',
    ticketId: 'min-h33',
    productId: 'prod-004',  // CTL
    createdAt: '2026-02-19T04:00:00.000Z',
  },

  // MIN-BCK1: e-Saraban (permission issue)
  {
    id: 'tp-bck1-001',
    ticketId: 'min-bck1',
    productId: 'prod-001',  // e-Saraban
    createdAt: '2026-02-18T10:00:00.000Z',
  },

  // MIN-C21: e-Saraban (database config)
  {
    id: 'tp-c21-001',
    ticketId: 'min-c21',
    productId: 'prod-001',  // e-Saraban
    createdAt: '2026-02-17T09:00:00.000Z',
  },

  // MIN-C31: e-DMS (critical failure)
  {
    id: 'tp-c31-001',
    ticketId: 'min-c31',
    productId: 'prod-002',  // e-DMS
    createdAt: '2026-02-16T08:00:00.000Z',
  },

  // MIN-CUST1: ⭐ Customer สร้างเอง - เลือก e-DMS
  {
    id: 'tp-cust1-001',
    ticketId: 'min-cust1',
    productId: 'prod-002',  // e-DMS (Customer เลือกเอง)
    createdAt: '2026-02-19T09:00:00.000Z',
  },

  // MIN-CUST2: ⭐ Customer สร้างเอง - เลือก e-Saraban
  {
    id: 'tp-cust2-001',
    ticketId: 'min-cust2',
    productId: 'prod-001',  // e-Saraban (Customer เลือกเอง)
    createdAt: '2026-02-19T07:30:00.000Z',
  },
];
