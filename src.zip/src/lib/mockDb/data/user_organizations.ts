import type { UserOrganization } from '../../types';

/**
 * User ↔ Organization junction table (many-to-many)
 *
 * Design decisions:
 * - Every user must have exactly ONE row with isPrimary=true (their default org)
 * - Additional rows can be added for multi-org access (isPrimary=false)
 * - role field is optional — can be used for org-specific permissions later
 * - Composite unique: (userId, organizationId) — no duplicate pairs
 *
 * ⚠️ Note on org IDs:
 * - This file currently uses organizations.ts IDs (org-csv-xxx / org-legacy-*)
 * - When you run ID remap script later, include this file in the replace pass too.
 */

export const userOrganizations: UserOrganization[] = [
  // =========================================================================
  // SUPERVISORS — access ALL orgs (primary = first org they oversee)
  // =========================================================================

  // user-001: Thiraporn (Supervisor) — primary: ERC, also sees GPO, SSO
  {
    id: 'uo-001',
    userId: 'user-001',
    organizationId: 'org-csv-001',  // ERC
    role: 'supervisor',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-002',
    userId: 'user-001',
    organizationId: 'org-csv-004',  // GPO
    role: 'supervisor',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-003',
    userId: 'user-001',
    organizationId: 'org-csv-005',  // SSO
    role: 'supervisor',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // user-002: Sarin (Supervisor) — primary: RMUTP, also sees VRU
  {
    id: 'uo-004',
    userId: 'user-002',
    organizationId: 'org-csv-002',  // RMUTP
    role: 'supervisor',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-005',
    userId: 'user-002',
    organizationId: 'org-csv-003',  // VRU
    role: 'supervisor',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // =========================================================================
  // TIER 1 AGENTS — typically 1 primary org
  // =========================================================================

  // user-003: Wannapa (Tier1) — ERC
  {
    id: 'uo-006',
    userId: 'user-003',
    organizationId: 'org-csv-001',  // ERC
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // user-004: Khemika (Tier1) — GPO
  {
    id: 'uo-007',
    userId: 'user-004',
    organizationId: 'org-csv-004',  // GPO
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // user-005: Thanyaporn (Tier1) — RMUTP
  {
    id: 'uo-008',
    userId: 'user-005',
    organizationId: 'org-csv-002',  // RMUTP
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // =========================================================================
  // TIER 2 SPECIALISTS — shared service, can see multiple orgs
  // =========================================================================

  // user-006: Yuttana (Tier2) — primary: ERC, also SSO, AMLO
  {
    id: 'uo-009',
    userId: 'user-006',
    organizationId: 'org-csv-001',  // ERC
    role: 'specialist',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-010',
    userId: 'user-006',
    organizationId: 'org-csv-005',  // SSO
    role: 'specialist',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-011',
    userId: 'user-006',
    organizationId: 'org-csv-006',  // AMLO
    role: 'specialist',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // user-007: Prakasit (Tier2+Tier3) — ERC, GPO
  {
    id: 'uo-012',
    userId: 'user-007',
    organizationId: 'org-csv-001',  // ERC
    role: 'specialist',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-013',
    userId: 'user-007',
    organizationId: 'org-csv-004',  // GPO
    role: 'specialist',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // user-008: Pravich (Tier2) — ERC
  {
    id: 'uo-014',
    userId: 'user-008',
    organizationId: 'org-csv-001',  // ERC
    role: 'specialist',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // =========================================================================
  // TIER 3 EXPERTS — shared service
  // =========================================================================

  // user-009: Puttajak (Tier3) — ERC, VRU
  {
    id: 'uo-015',
    userId: 'user-009',
    organizationId: 'org-csv-001',  // ERC
    role: 'expert',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-016',
    userId: 'user-009',
    organizationId: 'org-csv-003',  // VRU
    role: 'expert',
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // user-010: Wirakorn (Tier3) — ERC
  {
    id: 'uo-017',
    userId: 'user-010',
    organizationId: 'org-csv-001',  // ERC
    role: 'expert',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // =========================================================================
  // ADMIN
  // =========================================================================

  // user-011: Pra-onrat (Admin) — all orgs via primary only (admin sees everything anyway)
  {
    id: 'uo-018',
    userId: 'user-011',
    organizationId: 'org-csv-001',  // ERC (primary for display)
    role: 'admin',
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // =========================================================================
  // STAFF
  // =========================================================================

  // staff-001: เจ้าหน้าที่ — ERC
  {
    id: 'uo-019',
    userId: 'staff-001',
    organizationId: 'org-csv-001',  // ERC
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },

  // staff-002: Eakkachai — ERC, RMUTP
  {
    id: 'uo-020',
    userId: 'staff-002',
    organizationId: 'org-csv-001',  // ERC
    isPrimary: true,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'uo-021',
    userId: 'staff-002',
    organizationId: 'org-csv-002',  // RMUTP
    isPrimary: false,
    isActive: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  },
];
