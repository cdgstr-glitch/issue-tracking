// ✅ โครงการทั้งหมดจากข้อมูล CSV ที่ได้รับ (23 หน่วยงาน)
// สร้างตามข้อมูลจริงจากระบบสารบรรณ วันที่ 5-12 มกราคม 2026

export interface Project {
  id: string;
  organizationId: string; // 🆕 เพิ่ม organizationId
  code: string;
  name: string;
  shortName: string;
  department?: string;
  description?: string;
}

export const csvProjects: Project[] = [
  {
    id: 'proj-csv-001',
    organizationId: 'org-csv-001', // 🆕 เชื่อมกับ ORG-001 (ERC)
    code: 'D26-0001',
    name: 'สำนักงานคณะกรรมการกำกับกิจการพลังงาน',
    shortName: 'ERC',
    department: 'หน่วยงานอิสระ',
    description: 'Energy Regulatory Commission - หน่วยงานกำกับดูแลกิจการพลังงาน'
  },
  {
    id: 'proj-csv-002',
    organizationId: 'org-csv-002', // 🆕 เชื่อมกับ ORG-002 (RMUTP)
    code: 'D26-0002',
    name: 'มหาวิทยาลัยเทคโนโลยีราชมงคลพระนคร',
    shortName: 'RMUTP',
    department: 'สถาบันการศึกษา',
    description: 'Rajamangala University of Technology Phra Nakhon'
  },
  {
    id: 'proj-csv-003',
    organizationId: 'org-csv-003', // 🆕 เชื่อมกับ ORG-003 (VRU)
    code: 'D26-0003',
    name: 'มหาวิทยาลัยราชภัฏวไลยอลงกรณ์ ในพระบรมราชูปถัมภ์',
    shortName: 'VRU',
    department: 'สถาบันการศึกษา',
    description: 'Valaya Alongkorn Rajabhat University'
  },
  {
    id: 'proj-csv-004',
    organizationId: 'org-csv-004', // 🆕 เชื่อมกับ ORG-004 (GPO)
    code: 'D26-0005',
    name: 'องค์การเภสัชกรรม',
    shortName: 'GPO',
    department: 'รัฐวิสาหกิจ',
    description: 'Government Pharmaceutical Organization'
  },
  {
    id: 'proj-csv-005',
    organizationId: 'org-csv-005', // 🆕 เชื่อมกับ ORG-005 (FIO)
    code: 'D26-0006',
    name: 'สำนักงานประกันสังคม',
    shortName: 'FIO',
    department: 'กระทรวงแรงงาน',
    description: 'Social Security Office - สำนักงานประกันสังคม'
  },
  {
    id: 'proj-csv-006',
    organizationId: 'org-csv-006', // 🆕 เชื่อมกับ ORG-006 (AMLO)
    code: 'D26-0007',
    name: 'สำนักงานป้องกันและปราบปรามการฟอกเงิน',
    shortName: 'AMLO',
    department: 'หน่วยงานในกำกับรัฐมนตรีว่าการกระทรวงยุติธรรม',
    description: 'Anti-Money Laundering Office'
  },
  {
    id: 'proj-csv-007',
    organizationId: 'org-csv-007', // 🆕 เชื่อมกับ ORG-007 (DOH)
    code: 'D26-0008',
    name: 'กรมทางหลวง',
    shortName: 'DOH',
    department: 'กระทรวงคมนาคม',
    description: 'Department of Highways'
  },
  {
    id: 'proj-csv-008',
    organizationId: 'org-csv-008', // 🆕 เชื่อมกับ ORG-008 (ACFS)
    code: 'D26-0009',
    name: 'สำนักงานมาตรฐานสินค้าเกษตรและอาหารแห่งชาติ',
    shortName: 'ACFS',
    department: 'กระทรวงเกษตรและสหกรณ์',
    description: 'National Bureau of Agricultural Commodity and Food Standards'
  },
  {
    id: 'proj-csv-009',
    organizationId: 'org-csv-009', // 🆕 เชื่อมกับ ORG-009 (DLPW)
    code: 'D26-0010',
    name: 'กรมสวัสดิการและคุ้มครองแรงงาน',
    shortName: 'DLPW',
    department: 'กระทรวงแรงงาน',
    description: 'Department of Labour Protection and Welfare'
  },
  {
    id: 'proj-csv-010',
    organizationId: 'org-csv-010', // 🆕 เชื่อมกับ ORG-010 (DGA)
    code: 'D26-0011',
    name: 'สำนักงานพัฒนารัฐบาลดิจิทัล (จัดเก็บเอกสาร)',
    shortName: 'DGA',
    department: 'องค์การมหาชน',
    description: 'Digital Government Development Agency - แผนกจัดเก็บเอกสาร'
  },
  {
    id: 'proj-csv-011',
    organizationId: 'org-csv-011', // 🆕 เชื่อมกับ ORG-011 (SUANLUANG)
    code: 'D26-0012',
    name: 'เทศบาลตำบลสวนหลวง',
    shortName: 'SUANLUANG',
    department: 'องค์กรปกครองส่วนท้องถิ่น',
    description: 'สวนหลวง Sub-district Municipality'
  },
  {
    id: 'proj-csv-012',
    organizationId: 'org-csv-012', // 🆕 เชื่อมกับ ORG-012 (OPM)
    code: 'D26-0013',
    name: 'สำนักเลขาธิการนายกรัฐมนตรี',
    shortName: 'OPM',
    department: 'สำนักนายกรัฐมนตรี',
    description: 'Office of the Prime Minister - สำนักเลขาธิการนายกรัฐมนตรี'
  },
  {
    id: 'proj-csv-013',
    organizationId: 'org-csv-013', // 🆕 เชื่อมกับ ORG-013 (RMUTK)
    code: 'D26-0014',
    name: 'มหาวิทยาลัยเทคโนโลยีราชมงคลกรุงเทพ',
    shortName: 'RMUTK',
    department: 'สถาบันการศึกษา',
    description: 'Rajamangala University of Technology Krungthep'
  },
  {
    id: 'proj-csv-014',
    organizationId: 'org-csv-014', // 🆕 เชื่อมกับ ORG-014 (KORATPAO)
    code: 'D26-0015',
    name: 'องค์การบริหารส่วนจังหวัดนครราชสีมา',
    shortName: 'KORATPAO',
    department: 'องค์กรปกครองส่วนท้องถิ่น',
    description: 'Nakhon Ratchasima Provincial Administrative Organization'
  },
  {
    id: 'proj-csv-015',
    organizationId: 'org-csv-015', // 🆕 เชื่อมกับ ORG-015 (LDD)
    code: 'D26-0016',
    name: 'กรมพัฒนาที่ดิน',
    shortName: 'LDD',
    department: 'กระทรวงเกษตรและสหกรณ์',
    description: 'Land Development Department'
  },
  {
    id: 'proj-csv-016',
    organizationId: 'org-csv-016', // 🆕 เชื่อมกับ ORG-016 (GIF)
    code: 'D26-0017',
    name: 'สถาบันการเงินของรัฐบาล',
    shortName: 'GIF',
    department: 'กระทรวงการคลัง',
    description: 'Government Investment Fund - กองทุนพัฒนาเอกชน'
  },
  {
    id: 'proj-csv-017',
    organizationId: 'org-csv-017', // 🆕 เชื่อมกับ ORG-017 (NESDC)
    code: 'D26-0018',
    name: 'สำนักงานสภาพัฒนาการเศรษฐกิจและสังคมแห่งชาติ',
    shortName: 'NESDC',
    department: 'หน่วยงานในสำนักนายกรัฐมนตรี',
    description: 'National Economic and Social Development Council'
  },
  {
    id: 'proj-csv-018',
    organizationId: 'org-csv-018', // 🆕 เชื่อมกับ ORG-018 (DOT)
    code: 'D26-0019',
    name: 'กรมการขนส่งทางบก',
    shortName: 'DOT',
    department: 'กระทรวงคมนาคม',
    description: 'Department of Land Transport'
  },
  {
    id: 'proj-csv-019',
    organizationId: 'org-csv-019', // 🆕 เชื่อมกับ ORG-019 (OTEP)
    code: 'D26-0020',
    name: 'สำนักงานคณะกรรมการนโยบายเขตพัฒนาพิเศษภาคตะวันออก',
    shortName: 'OTEP',
    department: 'หน่วยงานในสำนักนายกรัฐมนตรี',
    description: 'Office of The Eastern Economic Corridor'
  },
  {
    id: 'proj-csv-020',
    organizationId: 'org-csv-020', // 🆕 เชื่อมกับ ORG-020 (HSS)
    code: 'D26-0021',
    name: 'กรมสนับสนุนบริการสุขภาพ',
    shortName: 'HSS',
    department: 'กระทรวงสาธารณสุข',
    description: 'Department of Health Service Support'
  },
  {
    id: 'proj-csv-021',
    organizationId: 'org-csv-021', // 🆕 เชื่อมกับ ORG-021 (DRU)
    code: 'D26-0022',
    name: 'มหาวิทยาลัยราชภัฏธนบุรี',
    shortName: 'DRU',
    department: 'สถาบันการศึกษา',
    description: 'Dhonburi Rajabhat University'
  },
  {
    id: 'proj-csv-022',
    organizationId: 'org-csv-022', // 🆕 เชื่อมกับ ORG-022 (MOT)
    code: 'D26-0023',
    name: 'กระทรวงคมนาคม',
    shortName: 'MOT',
    department: 'กระทรวง',
    description: 'Ministry of Transport'
  },
  {
    id: 'proj-csv-023',
    organizationId: 'org-csv-023', // 🆕 เชื่อมกับ ORG-023 (CHONPAO)
    code: 'D26-0024',
    name: 'องค์การบริหารส่วนจังหวัดชลบุรี',
    shortName: 'CHONPAO',
    department: 'องค์กรปกครองส่วนท้องถิ่น',
    description: 'Chonburi Provincial Administrative Organization'
  }
];

// ✅ Helper function: หา project จากชื่อหน่วยงาน
export function getProjectByShortName(shortName: string): Project | undefined {
  const normalized = shortName.toUpperCase().trim();
  
  // จับคู่ชื่อพิเศษ
  const mapping: Record<string, string> = {
    'DGA-DARCHIVES': 'DGA',
    'OPM สปน': 'OPM',
    'OPM': 'OPM',
    'GIF กปว.': 'GIF',
    'KORATPAO': 'KORATPAO',
    'SUANLUANG เทศบาลตำบลสวนหลวง': 'SUANLUANG',
    'CHONPAO อบจ  ชลบุรี': 'CHONPAO',
    'HSSระบบลา': 'HSS'
  };
  
  const searchKey = mapping[shortName] || normalized;
  return csvProjects.find(p => p.shortName === searchKey);
}

// 🆕 เพิ่ม "โครงการของ" ให้กับชื่อโครงการทั้งหมด
export const csvProjectsWithPrefix: Project[] = csvProjects.map(project => ({
  ...project,
  name: `โครงการของ${project.name}`
}));