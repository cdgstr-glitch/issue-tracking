// ✅ Data Validation Script
// ตรวจสอบความสมบูรณ์ของข้อมูล Mock Data (Single Source of Truth: db.timeline.getByTicketId)

import { db } from './mockDb/client';
import type { Ticket, TimelineEvent } from '../types';

const mockTickets = db.tickets.getAllRaw() as Ticket[];

console.log('🔍 Starting Data Validation...\n');

// ==============================
// Helpers
// ==============================

const getTimeline = (ticketId: string): TimelineEvent[] => {
  try {
    const events = db.timeline.getByTicketId(ticketId);
    return Array.isArray(events) ? (events as TimelineEvent[]) : [];
  } catch {
    return [];
  }
};

const isClosedLike = (status?: string) => status === 'closed';
const isAssigned = (t: Ticket) => Boolean(t.assignedTo);

const hasAcceptEvent = (events: TimelineEvent[]) => {
  // “รับเคส” อาจมาได้หลายรูปแบบใน mock
  return events.some(e => {
    const desc = String((e as any).description || '');
    const action = String((e as any).action || '');
    const status = String((e as any).status || '');

    return (
      desc.includes('รับเคส') ||
      action === 'case_accepted' ||
      action === 'case_assigned' ||
      status === 'in_progress' ||
      status === 'tier1'
    );
  });
};

const hasStatusEvent = (events: TimelineEvent[], status: string) =>
  events.some(e => String((e as any).status || '') === status);

// ==============================
// Validation
// ==============================

// ตัวนับปัญหา
let totalIssues = 0;

// 1) ตรวจสอบ Timeline ของเคสที่ปิดแล้ว
console.log('📋 [1/5] ตรวจสอบ Timeline ของเคสที่ปิดแล้ว...');
const closedTickets = mockTickets.filter(t => isClosedLike(t.status));
const closedWithoutTimeline = closedTickets.filter(t => getTimeline(t.id).length === 0);

if (closedWithoutTimeline.length > 0) {
  console.log(`  ❌ พบเคสที่ปิดแล้วแต่ไม่มี timeline: ${closedWithoutTimeline.length} เคส`);
  closedWithoutTimeline.slice(0, 5).forEach(t => {
    console.log(`     - ${t.ticketNumber}: ${(t.title || '').substring(0, 50)}...`);
  });
  totalIssues += closedWithoutTimeline.length;
} else {
  console.log('  ✅ ทุกเคสที่ปิดแล้วมี timeline');
}

// 2) ตรวจสอบ assignedBy และ assignedAt
console.log('\n📋 [2/5] ตรวจสอบ assignedBy และ assignedAt...');
const assignedTickets = mockTickets.filter(t => isAssigned(t));
const assignedWithoutFields = assignedTickets.filter(t => !(t as any).assignedBy || !(t as any).assignedAt);

if (assignedWithoutFields.length > 0) {
  console.log(`  ❌ พบเคสที่ assigned แต่ไม่มี assignedBy/assignedAt: ${assignedWithoutFields.length} เคส`);
  assignedWithoutFields.slice(0, 5).forEach(t => {
    console.log(`     - ${t.ticketNumber}: assignedBy=${(t as any).assignedBy}, assignedAt=${(t as any).assignedAt}`);
  });
  totalIssues += assignedWithoutFields.length;
} else {
  console.log('  ✅ ทุกเคสที่ assigned มีฟิลด์ครบ');
}

// 3) ตรวจสอบ solution และ closedBy ของเคสที่ปิดแล้ว
console.log('\n📋 [3/5] ตรวจสอบ solution และ closedBy...');
const closedWithoutSolution = closedTickets.filter(t => !t.solution || !(t as any).closedBy);

if (closedWithoutSolution.length > 0) {
  console.log(`  ❌ พบเคสที่ปิดแล้วแต่ไม่มี solution/closedBy: ${closedWithoutSolution.length} เคส`);
  closedWithoutSolution.slice(0, 5).forEach(t => {
    console.log(`     - ${t.ticketNumber}: solution=${!!t.solution}, closedBy=${(t as any).closedBy}`);
  });
  totalIssues += closedWithoutSolution.length;
} else {
  console.log('  ✅ ทุกเคสที่ปิดแล้วมี solution และ closedBy');
}

// 4) ตรวจสอบ Timeline Events สำคัญ (รับเคส)
console.log('\n📋 [4/5] ตรวจสอบ Timeline Events สำคัญ...');
const inProgressLikeTickets = mockTickets.filter(t =>
  ['in_progress', 'on_hold', 'resolved', 'pending_closure', 'closed', 'tier1', 'tier2', 'tier3'].includes(String(t.status))
);

const inProgressWithoutAcceptEvent = inProgressLikeTickets.filter(t => {
  if (!isAssigned(t)) return false;
  const events = getTimeline(t.id);
  return !hasAcceptEvent(events);
});

if (inProgressWithoutAcceptEvent.length > 0) {
  console.log(`  ⚠️  พบเคสที่ดำเนินการแล้วแต่ไม่มี "รับเคส" event: ${inProgressWithoutAcceptEvent.length} เคส`);
  console.log(`     (อาจเป็นเรื่องปกติสำหรับเคสเก่าหรือเคสที่นำเข้าย้อนหลัง)`);
} else {
  console.log('  ✅ ทุกเคสที่ดำเนินการมี "รับเคส" event');
}

// 5) ตรวจสอบ pending_closure workflow
console.log('\n📋 [5/5] ตรวจสอบ pending_closure workflow...');
const pendingClosureTickets = mockTickets.filter(t => String(t.status) === 'pending_closure');
console.log(`  📊 พบเคส pending_closure: ${pendingClosureTickets.length} เคส`);

pendingClosureTickets.forEach(t => {
  const events = getTimeline(t.id);
  const hasPending = hasStatusEvent(events, 'pending_closure');
  const hasResolved = hasStatusEvent(events, 'resolved');

  if (!hasPending) {
    console.log(`  ⚠️  ${t.ticketNumber}: ไม่มี pending_closure event`);
  }
  if (!hasResolved) {
    console.log(`  ⚠️  ${t.ticketNumber}: ไม่มี resolved event (ควรมีก่อน pending_closure)`);
  }
});

// ==============================
// Summary
// ==============================

console.log('\n' + '='.repeat(60));
console.log('📊 สรุปผลการตรวจสอบ');
console.log('='.repeat(60));
console.log(`✅ เคสทั้งหมด: ${mockTickets.length} เคส`);
console.log(`✅ เคสที่ปิดแล้ว: ${closedTickets.length} เคส`);
console.log(`✅ เคสที่ assigned: ${assignedTickets.length} เคส`);
console.log(`✅ เคส pending_closure: ${pendingClosureTickets.length} เคส`);

if (totalIssues > 0) {
  console.log(`\n❌ พบปัญหาทั้งหมด: ${totalIssues} รายการ`);
  console.log('⚠️  แนะนำให้แก้ไขปัญหาก่อน Deploy');
} else {
  console.log('\n🎉 ข้อมูลครบถ้วนสมบูรณ์!');
  console.log('✅ พร้อม Deploy');
}

console.log('\n🔍 Data Validation Complete!\n');

// Export stats สำหรับใช้งาน
export const dataValidationStats = {
  totalTickets: mockTickets.length,
  closedTickets: closedTickets.length,
  closedWithoutTimeline: closedWithoutTimeline.length,
  assignedTickets: assignedTickets.length,
  assignedWithoutFields: assignedWithoutFields.length,
  closedWithoutSolution: closedWithoutSolution.length,
  pendingClosureTickets: pendingClosureTickets.length,
  totalIssues
};
