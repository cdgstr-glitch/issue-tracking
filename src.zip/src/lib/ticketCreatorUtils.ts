import { Ticket, CreatedByType } from '../types';

/**
 * ✅ Helper: แสดงข้อมูลผู้สร้างเคส
 * 
 * @param ticket - ข้อมูลเคส
 * @returns ข้อความแสดงผู้สร้างเคส
 * 
 * @example
 * // Customer แจ้งเคสเอง
 * getTicketCreatorDisplay(ticket) 
 * // => "สมชาย ใจดี (แจ้งเคสเอง)"
 * 
 * // Staff บันทึกแทนลูกค้า
 * getTicketCreatorDisplay(ticket)
 * // => "วิภา ศรีสุข (บันทึกโดย: สมชาย ใจดี)"
 */
export function getTicketCreatorDisplay(ticket: Ticket): string {
  const customerName = ticket.customerName || 'ไม่ระบุ';
  
  if (ticket.createdByType === 'customer_self') {
    return `${customerName} (แจ้งเคสเอง)`;
  } else if (ticket.createdByType === 'staff_on_behalf' && ticket.createdByStaffName) {
    return `${customerName} (บันทึกโดย: ${ticket.createdByStaffName})`;
  }
  
  // Fallback: ถ้าไม่มี createdByType
  return customerName;
}

/**
 * ✅ Helper: แสดงไอคอนผู้สร้างเคส
 * 
 * @param ticket - ข้อมูลเคส
 * @returns emoji icon
 */
export function getTicketCreatorIcon(ticket: Ticket): string {
  if (ticket.createdByType === 'customer_self') {
    return '👤'; // ลูกค้า
  } else if (ticket.createdByType === 'staff_on_behalf') {
    return '👔'; // เจ้าหน้าที่
  }
  return '📋'; // ไม่ระบุ
}

/**
 * ✅ Helper: แสดงข้อความย่อผู้สร้างเคส (สำหรับ Timeline)
 * 
 * @param ticket - ข้อมูลเคส
 * @returns ข้อความสำหรับ timeline
 * 
 * @example
 * // Customer
 * getTicketCreatorNote(ticket)
 * // => "ลูกค้าเปิดเคสผ่านระบบด้วยตัวเอง"
 * 
 * // Staff
 * getTicketCreatorNote(ticket)
 * // => "เจ้าหน้าที่ สมชาย ใจดี บันทึกเคสแทนลูกค้า"
 */
export function getTicketCreatorNote(ticket: Ticket): string {
  if (ticket.createdByType === 'customer_self') {
    return `ลูกค้าเปิดเคสผ่านระบบด้วยตัวเอง`;
  } else if (ticket.createdByType === 'staff_on_behalf' && ticket.createdByStaffName) {
    return `เจ้าหน้าที่ ${ticket.createdByStaffName} บันทึกเคสแทนลูกค้า`;
  }
  return 'เปิดเคส';
}

/**
 * ✅ Helper: สร้าง Timeline Event สำหรับการสร้างเคส
 * 
 * @param ticket - ข้อมูลเคส
 * @returns Timeline Event Object
 */
export function createTicketCreationTimelineEvent(ticket: Ticket) {
  const channelName = 
    ticket.channel === 'web' ? 'เว็บไซต์' :
    ticket.channel === 'email' ? 'อีเมล' :
    ticket.channel === 'line' ? 'Line' :
    ticket.channel === 'phone' ? 'โทรศัพท์' : ticket.channel;
  
  let description = '';
  let user = 'System';
  
  if (ticket.createdByType === 'customer_self') {
    description = `ลูกค้าสร้างเคสผ่าน${channelName}`;
    user = ticket.customerName || 'ลูกค้า';
  } else if (ticket.createdByType === 'staff_on_behalf') {
    description = `เจ้าหน้าที่บันทึกเคสจากช่องทาง${channelName}`;
    user = ticket.createdByStaffName || 'Staff System';
  } else {
    // Fallback
    description = ticket.channel === 'web' 
      ? 'ลูกค้าสร้างเคสผ่าน Web App' 
      : `เจ้าหน้าที่บันทึกเคสจากช่องทาง${channelName}`;
    user = ticket.channel === 'web' ? 'System' : 'Staff System';
  }
  
  return {
    id: `tl-${ticket.id}-created`,
    timestamp: ticket.createdAt,
    type: 'status_change' as const,
    action: 'ticket_created' as const,
    description,
    user,
    status: 'new' as const,
    isInternal: false,
    performedBy: ticket.createdBy
  };
}

/**
 * ✅ Helper: ตรวจสอบว่าเคสถูกสร้างโดย Staff หรือไม่
 */
export function isTicketCreatedByStaff(ticket: Ticket): boolean {
  return ticket.createdByType === 'staff_on_behalf';
}

/**
 * ✅ Helper: ตรวจสอบว่าเคสถูกสร้างโดยลูกค้าเองหรือไม่
 */
export function isTicketCreatedByCustomer(ticket: Ticket): boolean {
  return ticket.createdByType === 'customer_self';
}
