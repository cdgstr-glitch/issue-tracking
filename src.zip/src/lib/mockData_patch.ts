// Patch file to insert after line 326
// ✅ รวมโครงการทั้งหมด: CSV Projects (23 โครงการ) + Legacy Projects (50 โครงการ)
export const mockProjects: Project[] = [...csvProjectsData, ...legacyMockProjects];
