/**
 * Issue Tracking - Date utilities (LEGACY 100% compatible)
 * Goal:
 * - Accept backend ISO strings (Laravel)
 * - Output MUST match legacy utils.ts exactly (toLocaleDateString th-TH with same options)
 */

export type DateInput = unknown;

export function toDate(input: DateInput): Date | null {
  if (!input) return null;

  if (input instanceof Date) {
    return Number.isNaN(input.getTime()) ? null : input;
  }

  if (typeof input === "string") {
    const s = input.trim();
    if (!s) return null;
    const d = new Date(s);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  if (typeof input === "number") {
    const d = new Date(input);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  return null;
}

/**
 * ✅ 100% same as legacy utils.ts formatRelativeTime(date: Date | string)
 * - < 1 min: "เมื่อสักครู่"
 * - < 60 min: "X นาทีที่แล้ว"
 * - < 24 hr: "X ชั่วโมงที่แล้ว"
 * - < 7 days: "X วันที่แล้ว"
 * - else: dateObj.toLocaleDateString('th-TH', { year:'numeric', month:'short', day:'numeric' })
 */
export function formatRelativeTime(date: DateInput): string {
  const dateObj = toDate(date);
  if (!dateObj) return "-";

  const now = new Date();
  const diffInMs = now.getTime() - dateObj.getTime();
  const diffInMinutes = Math.floor(diffInMs / 60000);
  const diffInHours = Math.floor(diffInMinutes / 60);
  const diffInDays = Math.floor(diffInHours / 24);

  if (diffInMinutes < 1) {
    return "เมื่อสักครู่";
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes} นาทีที่แล้ว`;
  } else if (diffInHours < 24) {
    return `${diffInHours} ชั่วโมงที่แล้ว`;
  } else if (diffInDays < 7) {
    return `${diffInDays} วันที่แล้ว`;
  } else {
    return dateObj.toLocaleDateString("th-TH", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  }
}

/**
 * ✅ 100% same as legacy utils.ts formatDate(date: Date)
 * (yes: it uses toLocaleDateString with hour/minute)
 */
export function formatDateTime(date: DateInput): string {
  const dateObj = toDate(date);
  if (!dateObj) return "-";

  return dateObj.toLocaleDateString("th-TH", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Optional: date-only (safe, not used in legacy mapping)
 */
export function formatDate(date: DateInput): string {
  const dateObj = toDate(date);
  if (!dateObj) return "-";

  return dateObj.toLocaleDateString("th-TH", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}
