// Predefined hashtags for issue tracking
export const suggestedHashtags = [
  // Priority & Urgency
  { id: 'urgent', value: '#ด่วน', category: 'priority', description: 'ต้องการความช่วยเหลือเร่งด่วน' },
  { id: 'critical', value: '#วิกฤติ', category: 'priority', description: 'ปัญหาร้ายแรงมาก' },
  { id: 'important', value: '#สำคัญ', category: 'priority', description: 'เรื่องสำคัญ' },
  { id: 'normal', value: '#ปกติ', category: 'priority', description: 'ความสำคัญปกติ' },
  
  // Issue Type
  { id: 'system-issue', value: '#ปัญหาระบบ', category: 'type', description: 'ปัญหาเกี่ยวกับระบบ' },
  { id: 'bug', value: '#บั๊ก', category: 'type', description: 'พบข้อผิดพลาดในระบบ' },
  { id: 'error', value: '#ข้อผิดพลาด', category: 'type', description: 'เกิดข้อผิดพลาด' },
  { id: 'network', value: '#เครือข่าย', category: 'type', description: 'ปัญหาเครือข่าย' },
  { id: 'hardware', value: '#ฮาร์ดแวร์', category: 'type', description: 'ปัญหาฮาร์ดแวร์' },
  { id: 'software', value: '#ซอฟต์แวร์', category: 'type', description: 'ปัญหาซอฟต์แวร์' },
  { id: 'access', value: '#การเข้าถึง', category: 'type', description: 'ปัญหาการเข้าถึงระบบ' },
  { id: 'password', value: '#รหัสผ่าน', category: 'type', description: 'ปัญหารหัสผ่าน' },
  { id: 'login', value: '#เข้าสู่ระบบ', category: 'type', description: 'ไม่สามารถเข้าสู่ระบบได้' },
  
  // Request Type
  { id: 'help', value: '#ขอความช่วยเหลือ', category: 'request', description: 'ต้องการความช่วยเหลือ' },
  { id: 'support', value: '#ช่วยเหลือ', category: 'request', description: 'ขอการสนับสนุน' },
  { id: 'question', value: '#สอบถาม', category: 'request', description: 'มีคำถาม' },
  { id: 'request', value: '#คำขอ', category: 'request', description: 'ขอบริการ' },
  { id: 'feature', value: '#คุณสมบัติใหม่', category: 'request', description: 'ขอเพิ่มคุณสมบัติ' },
  
  // Status & Progress
  { id: 'follow-up', value: '#ติดตาม', category: 'status', description: 'ติดตามความคืบหน้า' },
  { id: 'on_hold', value: '#รอดำเนินการ', category: 'status', description: 'รอการดำเนินการ' },
  { id: 'in-progress', value: '#กำลังดำเนินการ', category: 'status', description: 'อยู่ระหว่างดำเนินการ' },
  { id: 'resolved', value: '#แก้ไขแล้ว', category: 'status', description: 'แก้ไขเสร็จสิ้น' },
  
  // Department/Category
  { id: 'it', value: '#ไอที', category: 'department', description: 'เกี่ยวกับฝ่ายไอที' },
  { id: 'hr', value: '#ทรัพยากรบุคคล', category: 'department', description: 'เกี่ยวกับฝ่าย HR' },
  { id: 'finance', value: '#การเงิน', category: 'department', description: 'เกี่ยวกับฝ่ายการเงิน' },
  { id: 'admin', value: '#ธุรการ', category: 'department', description: 'เกี่ยวกับฝ่ายธุรการ' },
  
  // Device/Platform
  { id: 'windows', value: '#Windows', category: 'platform', description: 'Windows' },
  { id: 'mac', value: '#Mac', category: 'platform', description: 'macOS' },
  { id: 'mobile', value: '#มือถือ', category: 'platform', description: 'อุปกรณ์มือถือ' },
  { id: 'tablet', value: '#แท็บเล็ต', category: 'platform', description: 'แท็บเล็ต' },
  { id: 'web', value: '#เว็บ', category: 'platform', description: 'เว็บไซต์' },
  
  // Common Issues
  { id: 'slow', value: '#ช้า', category: 'issue', description: 'ระบบช้า' },
  { id: 'not-working', value: '#ไม่ทำงาน', category: 'issue', description: 'ไม่ทำงาน' },
  { id: 'freeze', value: '#ค้าง', category: 'issue', description: 'ค้าง/หยุดทำงาน' },
  { id: 'data-loss', value: '#ข้อมูลหาย', category: 'issue', description: 'ข้อมูลสูญหาย' },
  { id: 'printer', value: '#เครื่องพิมพ์', category: 'issue', description: 'ปัญหาเครื่องพิมพ์' },
  { id: 'email', value: '#อีเมล', category: 'issue', description: 'ปัญหาอีเมล' },
];

// Get hashtags by category
export function getHashtagsByCategory(category: string) {
  return suggestedHashtags.filter(tag => tag.category === category);
}

// Search hashtags
export function searchHashtags(query: string) {
  const lowerQuery = query.toLowerCase();
  return suggestedHashtags.filter(tag => 
    tag.value.toLowerCase().includes(lowerQuery) ||
    tag.description.toLowerCase().includes(lowerQuery)
  );
}

// Get all hashtag values
export function getAllHashtagValues() {
  return suggestedHashtags.map(tag => tag.value);
}
