import { TimelineEvent, TicketStatus } from '../types';

/**
 * Helper function เพื่อเพิ่ม isInternal field ใน timeline events
 * - new, resolved, closed, tier1, tier2, tier3, in_progress = ลูกค้าเห็นได้ (isInternal: false)
 * - assignment, escalation, waiting, pending_closure = ซ่อนจากลูกค้า (isInternal: true)
 */
export function enrichTimelineWithInternalFlag(events: TimelineEvent[]): TimelineEvent[] {
  // ตรวจสอบว่า events เป็น array หรือไม่
  if (!events || !Array.isArray(events)) {
    return [];
  }
  
  return events.map(event => {
    // ถ้ามี isInternal อยู่แล้ว ใช้ค่าเดิม
    if (event.isInternal !== undefined) {
      return event;
    }

    // กำหนด isInternal ตาม type และ status
    let isInternal = false;

    // 1. Assignment และ Escalation = internal
    if (event.type === 'assignment' || event.type === 'escalation') {
      isInternal = true;
    }
    
    // 2. Status change - แยกตาม status
    else if (event.type === 'status_change' && event.status) {
      // Public statuses: new, resolved, closed, tier1, tier2, tier3, in_progress
      const publicStatuses: TicketStatus[] = ['new', 'resolved', 'closed', 'tier1', 'tier2', 'tier3', 'in_progress'];
      isInternal = !publicStatuses.includes(event.status);
    }
    
    // 3. Comment และ Attachment = public (แต่อาจมี isInternal ใน comment แล้ว)
    else if (event.type === 'comment' || event.type === 'attachment') {
      isInternal = false;
    }

    return {
      ...event,
      isInternal
    };
  });
}