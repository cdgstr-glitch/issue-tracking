import { db } from './mockDb/client';
import { Ticket, User } from '../types';

// Get team name based on ticket status when no assignee
export function getTeamNameByStatus(status: string): string {
  switch (status) {
    case 'new':
    case 'tier1':
    case 'in_progress':
    case 'on_hold':
      return 'ทีม Service';
    case 'tier2':
      return 'ทีม App';
    case 'tier3':
      return 'ทีม Special';
    default:
      return 'ไม่มีผู้รับผิดชอบ';
  }
}

// Get assignee display name (person name or team name)
export function getAssigneeDisplayName(ticket: { assignedTo?: string; status: string }): string {
  if (ticket.assignedTo) {
    const user = db.users.getById(ticket.assignedTo);
    return user?.fullName || ticket.assignedTo;
  }
  
  // If no assignee, return team name based on status
  return getTeamNameByStatus(ticket.status);
}

// ✅ Find Tier 1 user for a project (Mock logic: just find any Tier 1)
export function getTier1ForProject(projectId?: string): User | undefined {
  const users = db.users.getAll();
  // In real app, we would check project assignment. 
  // For now, return any user with tier 1 role.
  return users.find(u => u.tier === 1 || u.roles?.includes('tier1') || u.role === 'tier1');
}

// ✅ Find user with least tickets
export function findUserWithLeastTickets(users: User[]): User | undefined {
  if (users.length === 0) return undefined;
  
  // This is a simplified "least tickets" logic
  // In a real app, we would query the DB for ticket counts per user
  // For now, just return a random user from the list to simulate load balancing
  const randomIndex = Math.floor(Math.random() * users.length);
  return users[randomIndex];
}
