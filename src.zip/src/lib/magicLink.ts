/**
 * Magic Link Authentication System
 * 
 * ระบบ Passwordless Authentication สำหรับ Customer
 * ใช้ Magic Link (One-Time Link) ส่งทางอีเมล
 */

import { MagicLinkToken, CustomerUser } from '../types';

/**
 * Mock Database: Magic Link Tokens
 * ในระบบจริง จะเก็บใน Database (Supabase, PostgreSQL, etc.)
 */
let mockMagicLinkTokens: MagicLinkToken[] = [];

/**
 * สร้าง Magic Link Token
 * 
 * @param email - อีเมลของ Customer
 * @param userId - Customer User ID
 * @param fullName - ชื่อ-นามสกุล ของลูกค้า
 * @param expiryMinutes - จำนวนนาทีที่ token จะหมดอายุ (default: 30 นาที)
 * @returns Magic Link Token Object
 * 
 * @example
 * const token = createMagicLinkToken('siriporn@example.com', 'customer-001', 'สิริพร ใจดี');
 * console.log(token.token); // "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
 */
export function createMagicLinkToken(
  email: string,
  userId: string,
  fullName: string,
  expiryMinutes: number = 30
): MagicLinkToken {
  console.log('🎫 [magicLink.ts] createMagicLinkToken called');
  console.log('   - email:', email);
  console.log('   - userId:', userId);
  console.log('   - fullName:', fullName);
  console.log('   - expiryMinutes:', expiryMinutes);
  
  // สร้าง UUID Token (ในระบบจริงใช้ crypto.randomUUID())
  const token = generateUUID();
  console.log('   - generated token:', token);
  
  const now = new Date();
  const expiresAt = new Date(now.getTime() + expiryMinutes * 60 * 1000);
  console.log('   - expiresAt:', expiresAt.toISOString());
  
  const magicLinkToken: MagicLinkToken = {
    token,
    email: email.toLowerCase(), // Normalize email
    userId,
    fullName, // 🆕 เก็บชื่อเต็มไว้
    createdAt: now,
    expiresAt,
    usedAt: undefined,
    isValid: true,
  };
  
  // บันทึก token ลง mock database
  mockMagicLinkTokens.push(magicLinkToken);
  console.log('✅ Token created and saved to mockMagicLinkTokens');
  console.log('📊 Total tokens in database:', mockMagicLinkTokens.length);
  
  return magicLinkToken;
}

/**
 * ตรวจสอบและใช้งาน Magic Link Token
 * 
 * @param token - Token string จาก URL
 * @returns Object { isValid, userId, error }
 * 
 * @example
 * const result = validateMagicLinkToken('a1b2c3d4-...');
 * if (result.isValid) {
 *   // Login success
 *   console.log('User ID:', result.userId);
 * } else {
 *   // Login failed
 *   console.error(result.error);
 * }
 */
export function validateMagicLinkToken(
  token: string
): {
  isValid: boolean;
  userId?: string;
  email?: string;
  fullName?: string; // 🆕 เพิ่ม fullName ใน return type
  error?: string;
} {
  console.log('🔍 [magicLink.ts] validateMagicLinkToken called');
  console.log('   - token:', token);
  console.log('   - mockMagicLinkTokens.length:', mockMagicLinkTokens.length);
  console.log('   - all tokens:', mockMagicLinkTokens.map(t => ({ token: t.token, email: t.email, isValid: t.isValid, usedAt: t.usedAt })));
  
  // หา token ใน database
  const magicLinkToken = mockMagicLinkTokens.find(t => t.token === token);
  console.log('   - found token:', magicLinkToken ? 'YES' : 'NO');
  
  // Token ไม่พบ
  if (!magicLinkToken) {
    console.error('❌ Token not found in database');
    return {
      isValid: false,
      error: 'ลิงก์ไม่ถูกต้องหรือหมดอายุแล้ว',
    };
  }
  
  console.log('   - token details:', {
    email: magicLinkToken.email,
    userId: magicLinkToken.userId,
    fullName: magicLinkToken.fullName,
    usedAt: magicLinkToken.usedAt,
    expiresAt: magicLinkToken.expiresAt.toISOString(),
  });
  
  // Token ถูกใช้งานไปแล้ว
  if (magicLinkToken.usedAt) {
    console.error('❌ Token already used at:', magicLinkToken.usedAt);
    return {
      isValid: false,
      error: 'ลิงก์นี้ถูกใช้งานไปแล้ว',
    };
  }
  
  // Token หมดอายุ
  const now = new Date();
  console.log('   - now:', now.toISOString());
  console.log('   - expiresAt:', magicLinkToken.expiresAt.toISOString());
  console.log('   - expired?', now > magicLinkToken.expiresAt);
  
  if (now > magicLinkToken.expiresAt) {
    console.error('❌ Token expired');
    return {
      isValid: false,
      error: 'ลิงก์หมดอายุแล้ว กรุณาขอลิงก์ใหม่',
    };
  }
  
  // Token ถูกต้อง → ทำเครื่องหมายว่าใช้งานแล้ว
  magicLinkToken.usedAt = now;
  magicLinkToken.isValid = false; // ใช้ได้ครั้งเดียว
  
  console.log('✅ Token valid! Marking as used.');
  console.log('   - userId:', magicLinkToken.userId);
  console.log('   - email:', magicLinkToken.email);
  console.log('   - fullName:', magicLinkToken.fullName);
  
  return {
    isValid: true,
    userId: magicLinkToken.userId,
    email: magicLinkToken.email,
    fullName: magicLinkToken.fullName, // 🆕 return fullName
  };
}

/**
 * สร้าง Magic Link URL
 * 
 * @param token - Magic Link Token
 * @param baseUrl - Base URL ของระบบ (optional, default: window.location.origin)
 * @returns Magic Link URL
 * 
 * @example
 * const token = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';
 * const url = generateMagicLinkURL(token);
 * console.log(url);
 * // "https://support.cdgs.co.th/auth/magic?token=a1b2c3d4-..."
 */
export function generateMagicLinkURL(
  token: string,
  baseUrl?: string
): string {
  const base = baseUrl || (typeof window !== 'undefined' ? window.location.origin : 'https://support.cdgs.co.th');
  return `${base}/auth/magic?token=${token}`;
}

/**
 * ลบ Token ที่หมดอายุ (Cleanup)
 * 
 * ควรเรียกฟังก์ชันนี้เป็นระยะๆ (เช่น ทุกวัน) เพื่อลบ token ที่หมดอายุออก
 * 
 * @returns จำนวน token ที่ถูกลบ
 * 
 * @example
 * const deletedCount = cleanupExpiredTokens();
 * console.log(`ลบ token หมดอายุ ${deletedCount} ตัว`);
 */
export function cleanupExpiredTokens(): number {
  const now = new Date();
  const beforeCount = mockMagicLinkTokens.length;
  
  mockMagicLinkTokens = mockMagicLinkTokens.filter(
    token => token.expiresAt > now && !token.usedAt
  );
  
  return beforeCount - mockMagicLinkTokens.length;
}

/**
 * ยกเลิก Token ทั้งหมดของ User (เช่น เมื่อ Logout หรือเปลี่ยนรหัสผ่าน)
 * 
 * @param userId - Customer User ID
 * @returns จำนวน token ที่ถูกยกเลิก
 * 
 * @example
 * const revokedCount = revokeUserTokens('customer-001');
 * console.log(`ยกเลิก token ${revokedCount} ตัว`);
 */
export function revokeUserTokens(userId: string): number {
  const beforeCount = mockMagicLinkTokens.length;
  
  mockMagicLinkTokens = mockMagicLinkTokens.filter(
    token => token.userId !== userId
  );
  
  return beforeCount - mockMagicLinkTokens.length;
}

/**
 * Get Active Tokens (สำหรับ Debug/Admin)
 * 
 * @returns รายการ token ที่ยังใช้งานได้
 */
export function getActiveTokens(): MagicLinkToken[] {
  const now = new Date();
  return mockMagicLinkTokens.filter(
    token => token.expiresAt > now && !token.usedAt
  );
}

/**
 * Generate UUID (Simple version for Mock)
 * 
 * ในระบบจริงใช้ crypto.randomUUID() หรือ uuid package
 */
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

/**
 * Validate Email Format
 * 
 * @param email - อีเมล
 * @returns true ถ้า format ถูกต้อง
 * 
 * @example
 * validateEmail('siriporn@example.com') // true
 * validateEmail('invalid-email') // false
 */
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Format Token Expiry (สำหรับแสดงผล)
 * 
 * @param expiresAt - วันที่หมดอายุ
 * @returns ข้อความแสดงผล (เช่น "เหลืออีก 25 นาที", "หมดอายุแล้ว")
 * 
 * @example
 * const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 นาทีจากนี้
 * formatTokenExpiry(expiresAt) // "เหลืออีก 15 นาที"
 */
export function formatTokenExpiry(expiresAt: Date): string {
  const now = new Date();
  const diffMs = expiresAt.getTime() - now.getTime();
  
  if (diffMs <= 0) {
    return 'หมดอายุแล้ว';
  }
  
  const diffMinutes = Math.floor(diffMs / (60 * 1000));
  
  if (diffMinutes < 60) {
    return `เหลืออีก ${diffMinutes} นาที`;
  }
  
  const diffHours = Math.floor(diffMinutes / 60);
  return `เหลืออีก ${diffHours} ชั่วโมง`;
}

/**
 * ฟังก์ชัน Mock สำหรับทดสอบ
 * (ในระบบจริงจะไม่มี - ใช้สำหรับ development/testing เท่านั้น)
 */
export const __mockHelpers = {
  /**
   * Get all tokens (รวมทั้งหมดอายุและใช้แล้ว)
   */
  getAllTokens: () => mockMagicLinkTokens,
  
  /**
   * Clear all tokens
   */
  clearAllTokens: () => {
    mockMagicLinkTokens = [];
  },
  
  /**
   * Set custom token (สำหรับทดสอบ)
   */
  addMockToken: (token: MagicLinkToken) => {
    mockMagicLinkTokens.push(token);
  },
};