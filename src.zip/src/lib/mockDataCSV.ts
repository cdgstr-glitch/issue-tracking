// ✅ Main CSV Data Export
// รวมข้อมูลทั้งหมดจาก CSV (Projects, Users, Tickets)

import { Ticket, User } from '../types';
import { csvProjects, csvProjectsWithPrefix, Project } from './mockDataCSVProjects';
import { allCSVUsers, csvStaffUsers, csvCustomerUsers } from './mockDataCSVUsers';
import { allCSVTickets } from './mockDataCSVTickets';

// ==================== EXPORTS ====================

// Projects (23 โครงการ) - 🆕 ใช้ version ที่มี prefix "โครงการของ"
export const projects = csvProjectsWithPrefix;
export type { Project };

// Users (Staff 9 คน + Customers 33 คน = 42 คน)
export const users = allCSVUsers;
export const staffUsers = csvStaffUsers;
export const customerUsers = csvCustomerUsers;

// Tickets (50 เคส จาก CSV)
export const tickets = allCSVTickets;

// ==================== HELPER FUNCTIONS ====================

export function getProjectById(projectId: string): Project | undefined {
  return csvProjectsWithPrefix.find(p => p.id === projectId);
}

export function getProjectByCode(projectCode: string): Project | undefined {
  return csvProjectsWithPrefix.find(p => p.code === projectCode);
}

export function getProjectByShortName(shortName: string): Project | undefined {
  const normalized = shortName.toUpperCase().trim();
  return csvProjects.find(p => p.shortName === normalized);
}

export function getUserById(userId: string): User | undefined {
  return allCSVUsers.find(u => u.id === userId);
}

export function getUsersByProject(projectId: string): User[] {
  return allCSVUsers.filter(u => u.projects?.includes(projectId));
}

export function getTicketsByProject(projectId: string): Ticket[] {
  return allCSVTickets.filter(t => t.projectId === projectId);
}

export function getTicketsByDepartment(department: string): Ticket[] {
  return allCSVTickets.filter(t => t.department === department);
}

export function getTicketsByStatus(status: string): Ticket[] {
  return allCSVTickets.filter(t => t.status === status);
}

export function getTicketsByPriority(priority: string): Ticket[] {
  return allCSVTickets.filter(t => t.priority === priority);
}

export function getTicketsByType(type: string): Ticket[] {
  return allCSVTickets.filter(t => t.type === type);
}

// ==================== STATISTICS ====================

export function getTicketStats() {
  const total = allCSVTickets.length;
  const byStatus = {
    open: allCSVTickets.filter(t => t.status === 'open').length,
    assigned: allCSVTickets.filter(t => t.status === 'assigned').length,
    in_progress: allCSVTickets.filter(t => t.status === 'in_progress').length,
  on_hold: allCSVTickets.filter(t => t.status === 'on_hold').length,
    resolved: allCSVTickets.filter(t => t.status === 'resolved').length,
    closed: allCSVTickets.filter(t => t.status === 'closed').length
  };

  const byPriority = {
    critical: allCSVTickets.filter(t => t.priority === 'critical').length,
    high: allCSVTickets.filter(t => t.priority === 'high').length,
    medium: allCSVTickets.filter(t => t.priority === 'medium').length,
    low: allCSVTickets.filter(t => t.priority === 'low').length
  };

  const byType = {
    bug: allCSVTickets.filter(t => t.type === 'bug').length,
    feature: allCSVTickets.filter(t => t.type === 'feature').length,
    support: allCSVTickets.filter(t => t.type === 'support').length,
    incident: allCSVTickets.filter(t => t.type === 'incident').length
  };

  return {
    total,
    byStatus,
    byPriority,
    byType
  };
}

// ==================== DEFAULT EXPORT ====================

export default {
  projects,
  users,
  tickets,
  staffUsers,
  customerUsers,
  getProjectById,
  getProjectByCode,
  getProjectByShortName,
  getUserById,
  getUsersByProject,
  getTicketsByProject,
  getTicketsByDepartment,
  getTicketsByStatus,
  getTicketsByPriority,
  getTicketsByType,
  getTicketStats
};
