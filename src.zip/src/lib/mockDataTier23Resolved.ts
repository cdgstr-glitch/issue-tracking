import { Ticket } from '../types';

// ========================================
// ✅ TIER2-3 RESOLVED TICKETS (ส่งกลับ Tier1)
// ========================================
// เคสที่ Tier2-3 แก้ไขแล้วและส่งกลับ Tier1 เพื่อปิด (status = 'tier1')

export const tier23ResolvedTickets: Ticket[] = [
  // ========================================
  // Tier2 - ประวิช จินทนากร (user-008)
  // ========================================
  
  // ✅ เคสที่ส่งกลับ T1 และรอ T1 ปิด (status = 'tier1')
  {
    id: 'test-t2-001', // ✅ ใช้ ID เดิม
    ticketNumber: 'CDGS-2024-T2-001', // ✅ ใช้ Ticket Number เดิม
    title: 'ปัญหาฐานข้อมูลช้ามาก - Query Timeout #ด่วน #ฐานข้อมูล',
    description: 'ระบบฐานข้อมูลหลักทำงานช้ามากผิดปกติ query ที่ใช้เวลาปกติ 1-2 วินาที ตอนนี้ใช้เวลามากกว่า 30 วินาที บางครั้ง timeout เลย ส่งผลกระทบต่อการทำงานของพนักงาน 50+ คน',
    status: 'tier1', // ✅ ส่งกลับ Tier1 แล้ว (รอ Tier1 รับเคสเพื่อปิด)
    type: 'incident',
    channel: 'web',
    priority: 'high',
    category: 'Data & Database',
    customerName: 'อรรถพล จันทร์เจริญ',
    customerEmail: 'attapol.c@drt.go.th',
    customerPhone: '+66-83-345-6783',
    assignedTo: 'user-003', // ส่งกลับให้ วรรณภา (Tier1)
    assignedBy: 'user-008', // ประวิช (Tier2) เป็นคนส่งกลับ
    assignedAt: new Date(Date.now() - 15 * 60 * 1000),
    previousAssignee: 'user-008', // เดิมเป็นของประวิช
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DRT',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 15 * 60 * 1000),
    dueDate: new Date(Date.now() + 2 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-003',
      escalatedByName: 'วรรณภา แซ่ด่าง',
      escalatedAt: new Date(Date.now() - 90 * 60 * 1000),
      reason: 'Database performance issue - ต้องการผู้เชี่ยวชาญ'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-008', // ✅ ประวิช (Tier2) ส่งกลับ Tier1
      escalatedByName: 'ประวิช จินทนากร',
      escalatedAt: new Date(Date.now() - 15 * 60 * 1000),
      reason: 'เพิ่ม Index แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2-001-timeline-1',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2-001-timeline-2',
      timestamp: new Date(Date.now() - 90 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประวิช จินทนากร (Tier 2)',
      user: 'วรรณภา แซ่ด่าง',
      status: 'tier2'
    }, {
      id: 'test-t2-001-timeline-3',
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประวิช จินทนากร',
      status: 'in_progress'
    }, {
      id: 'test-t2-001-timeline-4',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      type: 'comment',
      description: 'เพิ่ม Index ที่ตาราง users และ orders แล้ว Query เร็วขึ้นมาก',
      user: 'ประวิช จินทนากร'
    }, {
      id: 'test-t2-001-timeline-5',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'ประวิช จินทนากร',
      status: 'tier1'
    }],
    comments: []
  },
  
  {
    id: 'test-t2-005', // ✅ ใช้ ID เดิม
    ticketNumber: 'CDGS-2024-T2-005', // ✅ ใช้ Ticket Number เดิม
    title: 'ระบบ Backup ล้มเหลว 3 วันติดต่อกัน #วิกฤติ #Backup',
    description: 'ระบบ Backup อัตโนมัติล้มเหลว 3 คืนติดต่อกัน ไม่สามารถสำรองข้อมูลได้ พบ error "Insufficient storage space - 98% full" ข้อมูลที่ต้อง backup ประมาณ 8TB',
    status: 'tier1', // ✅ ส่งกลับ Tier1 แล้ว
    type: 'incident',
    channel: 'web',
    priority: 'critical',
    category: 'Data & Database',
    customerName: 'ศิริพร ระบบงาน',
    customerEmail: 'siriporn.r@nesdc.go.th',
    customerPhone: '+66-89-012-3457',
    assignedTo: 'user-003', // ส่งกลับให้ วรรณภา (Tier1)
    assignedBy: 'user-008', // ประวิช (Tier2) เป็นคนส่งกลับ
    assignedAt: new Date(Date.now() - 10 * 60 * 1000),
    previousAssignee: 'user-008', // เดิมเป็นของประวิช
    projectId: 'proj-007',
    projectCode: 'D24-6073',
    projectName: 'สภาพัฒนาการเศรษฐกิจและสังคมแห่งชาติ',
    projectShortName: 'NESDC',
    createdAt: new Date(Date.now() - 90 * 60 * 1000),
    updatedAt: new Date(Date.now() - 10 * 60 * 1000),
    dueDate: new Date(Date.now() + 2 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-003',
      escalatedByName: 'วรรณภา แซ่ด่าง',
      escalatedAt: new Date(Date.now() - 70 * 60 * 1000),
      reason: 'Backup system critical - ต้องการ Infrastructure Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-008', // ✅ ประวิช (Tier2) ส่งกลับ Tier1
      escalatedByName: 'ประวิช จินทนากร',
      escalatedAt: new Date(Date.now() - 10 * 60 * 1000),
      reason: 'เพิ่ม Storage และแก้ไข Script แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2-005-timeline-1',
      timestamp: new Date(Date.now() - 90 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2-005-timeline-2',
      timestamp: new Date(Date.now() - 70 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อเร่งด่วนไปยัง ประวิช จินทนากร (Tier 2)',
      user: 'วรรณภา แซ่ด่าง',
      status: 'tier2'
    }, {
      id: 'test-t2-005-timeline-3',
      timestamp: new Date(Date.now() - 50 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประวิช จินทนากร',
      status: 'in_progress'
    }, {
      id: 'test-t2-005-timeline-4',
      timestamp: new Date(Date.now() - 25 * 60 * 1000),
      type: 'comment',
      description: 'ตรวจสอบแล้ว Storage เต็ม ได้เพิ่ม Storage และแก้ไข Backup Script แล้ว',
      user: 'ประวิช จินทนากร'
    }, {
      id: 'test-t2-005-timeline-5',
      timestamp: new Date(Date.now() - 10 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'ประวิช จินทนากร',
      status: 'tier1'
    }],
    comments: []
  },
  
  // ========================================
  // ✅ เคสที่ T2 ส่งกลับ T1 และ T1 ปิดให้แล้ว (status = 'closed')
  // ========================================
  {
    id: 'test-t2-closed-001',
    ticketNumber: 'CDGS-2024-T2-C001',
    title: 'ปัญหา VPN ขาดหายบ่อย #เครือข่าย #VPN',
    description: 'พนักงานทำงาน Remote ประมาณ 20 คน พบปัญหา VPN ขาดหายทุก 15-30 นาที ต้อง reconnect ซ้ำๆ ส่งผลกระทบต่อการทำงาน ใช้ VPN Client version 5.2.1',
    status: 'closed', // ✅ T1 ปิดแล้ว
    type: 'incident',
    channel: 'web',
    priority: 'medium',
    category: 'Network',
    customerName: 'ภูมิพัฒน์ เน็ตเวิร์ค',
    customerEmail: 'phumipat.n@moc.go.th',
    customerPhone: '+66-84-567-8901',
    assignedTo: 'user-003', // Tier1 (วรรณภา) ปิดเคส
    assignedBy: 'user-008', // ประวิช (Tier2) ส่งกลับ
    assignedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 วันที่แล้ว
    previousAssignee: 'user-008',
    resolvedBy: 'user-003', // ✅ Tier1 resolve
    resolvedAt: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000), // 1.5 วันที่แล้ว
    closedBy: 'user-003', // ✅ Tier1 ปิดเคส
    closedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 วันที่แล้ว
    projectId: 'proj-002',
    projectCode: 'D24-6052',
    projectName: 'กระทรวงพาณิชย์',
    projectShortName: 'MOC',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 วันที่แล้ว
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-004', // เขมิกา (Tier1)
      escalatedByName: 'เขมิกา แซ่ตั้ง',
      escalatedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      reason: 'VPN connectivity issue - ต้องการ Network Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-008', // ✅ ประวิช (Tier2) ส่งกลับ Tier1
      escalatedByName: 'ประวิช จินทนากร',
      escalatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      reason: 'อัพเกรด VPN Firmware และปรับ Config แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2-closed-001-timeline-1',
      timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้าสร้างเคสผ่าน Web App',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2-closed-001-timeline-2',
      timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประวิช จินทนากร (Tier 2)',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'tier2'
    }, {
      id: 'test-t2-closed-001-timeline-3',
      timestamp: new Date(Date.now() - 3.5 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประวิช จินทนากร',
      status: 'in_progress'
    }, {
      id: 'test-t2-closed-001-timeline-4',
      timestamp: new Date(Date.now() - 2.5 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'อัพเกรด VPN Firmware เป็น version 6.0.2 และปรับ timeout settings แล้ว',
      user: 'ประวิช จินทนากร'
    }, {
      id: 'test-t2-closed-001-timeline-5',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'ประวิช จินทนากร',
      status: 'tier1'
    }, {
      id: 'test-t2-closed-001-timeline-6',
      timestamp: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ทดสอบแล้วเรียบร้อย - Resolve เคส',
      user: 'วรรณภา แซ่ด่าง',
      status: 'resolved'
    }, {
      id: 'test-t2-closed-001-timeline-7',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้ายืนยันว่าแก้ไขแล้ว - ปิดเคส',
      user: 'วรรณภา แซ่ด่าง',
      status: 'closed'
    }],
    comments: []
  },
  
  {
    id: 'test-t2-closed-002',
    ticketNumber: 'CDGS-2024-T2-C002',
    title: 'ขอเพิ่ม RAM Server Production #คำขอ #Hardware',
    description: 'Server Production (SRV-PROD-01) มี RAM เหลือน้อย ต้องการเพิ่ม RAM จาก 32GB เป็น 64GB เพื่อรองรับ Load ที่เพิ่มขึ้น 40% จากไตรมาสที่แล้ว',
    status: 'closed', // ✅ T1 ปิดแล้ว
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Infrastructure',
    customerName: 'วัชระ เซิร์ฟเวอร์',
    customerEmail: 'watchara.s@doe.go.th',
    customerPhone: '+66-85-678-9012',
    assignedTo: 'user-004', // Tier1 (เขมิกา) ปิดเคส
    assignedBy: 'user-008', // ประวิช (Tier2) ส่งกลับ
    assignedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 วันที่แล้ว
    previousAssignee: 'user-008',
    resolvedBy: 'user-004', // ✅ Tier1 resolve
    resolvedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000), // 8 วันที่แล้ว
    closedBy: 'user-004', // ✅ Tier1 ปิดเคส
    closedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 วันที่แล้ว
    projectId: 'proj-005',
    projectCode: 'D24-6065',
    projectName: 'กรมพัฒนาพลังงานทดแทนและอนุรักษ์พลังงาน',
    projectShortName: 'DEDE',
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 วันที่แล้ว
    updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-003', // วรรณภา (Tier1)
      escalatedByName: 'วรรณภา แซ่ด่าง',
      escalatedAt: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
      reason: 'Hardware upgrade - ต้องการ Infrastructure Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-008', // ✅ ประวิช (Tier2) ส่งกลับ Tier1
      escalatedByName: 'ประวิช จินทนากร',
      escalatedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      reason: 'ติดตั้ง RAM 32GB เพิ่มเติมแล้ว รวมเป็น 64GB - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2-closed-002-timeline-1',
      timestamp: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'Staff บันทึกเคสจาก Email',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2-closed-002-timeline-2',
      timestamp: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ประวิช จินทนากร (Tier 2)',
      user: 'วรรณภา แซ่ด่าง',
      status: 'tier2'
    }, {
      id: 'test-t2-closed-002-timeline-3',
      timestamp: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ประวิช จินทนากร',
      status: 'in_progress'
    }, {
      id: 'test-t2-closed-002-timeline-4',
      timestamp: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'สั่ง RAM DDR4 32GB ECC Registered แล้ว คาดว่าจะได้รับภายใน 3 วันทำการ',
      user: 'ประวิช จินทนากร'
    }, {
      id: 'test-t2-closed-002-timeline-5',
      timestamp: new Date(Date.now() - 10.5 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'ติดตั้ง RAM เพิ่มเติมแล้ว ทดสอบด้วย memtest86 ผ่านเรียบร้อย',
      user: 'ประวิช จินทนากร'
    }, {
      id: 'test-t2-closed-002-timeline-6',
      timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง เขมิกา แซ่ตั้ง (Tier 1) เพื่อปิดเคส',
      user: 'ประวิช จินทนากร',
      status: 'tier1'
    }, {
      id: 'test-t2-closed-002-timeline-7',
      timestamp: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ตรวจสอบกับลูกค้าแล้วเรียบร้อย - Resolve เคส',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'resolved'
    }, {
      id: 'test-t2-closed-002-timeline-8',
      timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้ายืนยันว่าระบบทำงานปกติ - ปิดเคส',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'closed'
    }],
    comments: []
  },
  
  // ========================================
  // Tier2 - ยุทธนา คณามิ่งมงคล (user-006) - Tier2 Lead
  // ========================================
  
  // ✅ เคสที่ส่งกลับ T1 และรอ T1 ปิด (status = 'tier1')
  {
    id: 'test-t2-lead-001',
    ticketNumber: 'CDGS-2024-T2L-001',
    title: 'ระบบ Email Server ล่ม - ส่งเมลไม่ได้ทั้งองค์กร #วิกฤติ #Email',
    description: 'Email Server หลัก (Exchange Server) ล่มทั้งระบบ ไม่สามารถส่ง-รับเมลได้ ส่งผลกระทบต่อพนักงาน 150+ คน พบ error "Connection to server failed" และ "Authentication timeout"',
    status: 'tier1',
    type: 'incident',
    channel: 'phone',
    priority: 'critical',
    category: 'Infrastructure',
    customerName: 'วิชัย เมลล์เซิร์ฟเวอร์',
    customerEmail: 'wichai.m@moph.go.th',
    customerPhone: '+66-86-789-0123',
    assignedTo: 'user-003',
    assignedBy: 'user-006',
    assignedAt: new Date(Date.now() - 20 * 60 * 1000),
    previousAssignee: 'user-006',
    projectId: 'proj-004',
    projectCode: 'D24-6054',
    projectName: 'กระทรวงสาธารณสุข',
    projectShortName: 'MOPH',
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 20 * 60 * 1000),
    dueDate: new Date(Date.now() + 1 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-004',
      escalatedByName: 'เขมิกา แซ่ตั้ง',
      escalatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      reason: 'Email server down - ต้องการ Infrastructure Lead'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-006',
      escalatedByName: 'ยุทธนา คณามิ่งมงคล',
      escalatedAt: new Date(Date.now() - 20 * 60 * 1000),
      reason: 'Restart Service และแก้ไข Authentication Config แล้ว - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2-lead-001-timeline-1',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'Staff บันทึกเคสจาก Phone',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2-lead-001-timeline-2',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อเร่งด่วนไปยัง ยุทธนา คณามิ่งมงคล (Tier 2 Lead)',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'tier2'
    }, {
      id: 'test-t2-lead-001-timeline-3',
      timestamp: new Date(Date.now() - 100 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'in_progress'
    }, {
      id: 'test-t2-lead-001-timeline-4',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      type: 'comment',
      description: 'Restart Exchange Service และแก้ไข Authentication timeout settings แล้ว ทดสอบส่งเมลได้ปกติ',
      user: 'ยุทธนา คณามิ่งมงคล'
    }, {
      id: 'test-t2-lead-001-timeline-5',
      timestamp: new Date(Date.now() - 20 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง วรรณภา แซ่ด่าง (Tier 1) เพื่อปิดเคส',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'tier1'
    }],
    comments: []
  },
  
  {
    id: 'test-t2-lead-closed-001',
    ticketNumber: 'CDGS-2024-T2L-C001',
    title: 'ขอติดตั้ง SSL Certificate ใหม่ #ความปลอดภัย #SSL',
    description: 'SSL Certificate ของเว็บไซต์หลักหมดอายุแล้ว 3 วัน ขอติดตั้ง Certificate ใหม่โดยเร็ว เพื่อป้องกัน Browser แสดง Warning ให้ลูกค้า',
    status: 'closed',
    type: 'service_request',
    channel: 'email',
    priority: 'high',
    category: 'Security',
    customerName: 'สมพร รักษาความปลอดภัย',
    customerEmail: 'somporn.s@mofa.go.th',
    customerPhone: '+66-87-890-1234',
    assignedTo: 'user-004',
    assignedBy: 'user-006',
    assignedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    previousAssignee: 'user-006',
    resolvedBy: 'user-004',
    resolvedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    closedBy: 'user-004',
    closedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    projectId: 'proj-006',
    projectCode: 'D24-6056',
    projectName: 'กระทรวงการต่างประเทศ',
    projectShortName: 'MOFA',
    createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    attachments: [],
    escalationChain: [{
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-003',
      escalatedByName: 'วรรณภา แซ่ด่าง',
      escalatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      reason: 'SSL Certificate renewal - ต้องการ Security Expert'
    }, {
      fromTier: 'tier2',
      toTier: 'tier1',
      escalatedBy: 'user-006',
      escalatedByName: 'ยุทธนา คณามิ่งมงคล',
      escalatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      reason: 'ติดตั้ง SSL Certificate ใหม่แล้ว (Wildcard, Valid 2 years) - ส่งกลับ Tier1 เพื่อปิดเคส'
    }],
    timeline: [{
      id: 'test-t2-lead-closed-001-timeline-1',
      timestamp: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'Staff บันทึกเคสจาก Email',
      user: 'System',
      status: 'new'
    }, {
      id: 'test-t2-lead-closed-001-timeline-2',
      timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง ยุทธนา คณามิ่งมงคล (Tier 2 Lead)',
      user: 'วรรณภา แซ่ด่าง',
      status: 'tier2'
    }, {
      id: 'test-t2-lead-closed-001-timeline-3',
      timestamp: new Date(Date.now() - 6.5 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'รับเคสเรียบร้อย',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'in_progress'
    }, {
      id: 'test-t2-lead-closed-001-timeline-4',
      timestamp: new Date(Date.now() - 5.5 * 24 * 60 * 60 * 1000),
      type: 'comment',
      description: 'สั่ง Wildcard SSL Certificate แล้ว ได้รับ Certificate จาก CA แล้ว กำลังติดตั้ง',
      user: 'ยุทธนา คณามิ่งมงคล'
    }, {
      id: 'test-t2-lead-closed-001-timeline-5',
      timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งกลับไปยัง เขมิกา แซ่ตั้ง (Tier 1) เพื่อปิดเคส',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'tier1'
    }, {
      id: 'test-t2-lead-closed-001-timeline-6',
      timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ตรวจสอบ SSL ทำงานปกติ - Resolve เคส',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'resolved'
    }, {
      id: 'test-t2-lead-closed-001-timeline-7',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'ลูกค้ายืนยันว่าไม่มี Warning แล้ว - ปิดเคส',
      user: 'เขมิกา แซ่ตั้ง',
      status: 'closed'
    }],
    comments: []
  }
];