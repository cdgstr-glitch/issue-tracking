import { Ticket } from '../types';

// ✅ ========================================
// 🧪 Read-only Mode Testing Tickets
// ========================================
// เคสสำหรับทดสอบ Read-only mode และ Takeover

export const readOnlyTestTickets: Ticket[] = [
  // 1. เคส assign ให้ ธัญญาพร ทองแก้ว (Tier1) - คนอื่นเปิดดูแบบ read-only
  {
    id: 'readonly-test-001',
    ticketNumber: 'CDGS-T1001',
    title: 'ระบบ Login ไม่ได้ - รหัสผ่านถูกล็อก #ระบบล็อกอิน #รหัสผ่าน',
    description: '<p>พนักงานไม่สามารถ Login เข้าระบบได้หลังจากพยายามใส่รหัสผ่านผิด 3 ครั้ง</p><p>กรุณาตรวจสอบและปลดล็อคบัญชีให้ด้วยค่ะ</p>',
    status: 'in_progress',
    type: 'incident',
    channel: 'web',
    priority: 'high',
    category: 'การเข้าใช้งานระบบ',
    product: 'Asset Management',
    customerName: 'ดาริน มานะชาติ',
    assignedTo: 'user-005', // ธัญญาพร ทองแก้ว (Tier1)
    assignedBy: 'user-005',
    assignedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdBy: 'test-001',
    createdByName: 'ดาริน มานะชาติ',
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 30 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 21 * 60 * 60 * 1000),
    attachments: [],
    timeline: [{
      id: 'ro-001-tl-1',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'เคสถูกสร้างโดยลูกค้า',
      user: 'ดาริน มานะชาติ',
      status: 'new'
    }, {
      id: 'ro-001-tl-2',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'assignment',
      description: 'รับเคสโดย ธัญญาพร ทองแก้ว',
      user: 'ธัญญาพร ทองแก้ว',
      status: 'in_progress'
    }],
    comments: [{
      id: 'ro-001-c1',
      ticketId: 'readonly-test-001',
      author: 'ธัญญาพร ทองแก้ว',
      authorRole: 'tier1',
      content: 'กำลังตรวจสอบปัญหาค่ะ รอสักครู่',
      isInternal: false,
      createdAt: new Date(Date.now() - 30 * 60 * 60 * 1000)
    }]
  },

  // 2. เคส assign ให้ วรรณภา แซ่ด่าง (Tier1)
  {
    id: 'readonly-test-002',
    ticketNumber: 'CDGS-T1002',
    title: 'ไม่สามารถพิมพ์รายงานได้ #ระบบพิมพ์ #รายงาน',
    description: '<p>ระบบรายงานไม่สามารถพิมพ์เอกสารออกมาได้</p><p>กดปุ่มพิมพ์แล้วไม่มีอะไรเกิดขึ้น</p>',
    status: 'in_progress',
    type: 'incident',
    channel: 'email',
    priority: 'medium',
    category: 'การใช้งานระบบ',
    product: 'e-Booking',
    customerName: 'กัญญารัตน์ รัตนโชติสกุล',
    assignedTo: 'user-003', // วรรณภา แซ่ด่าง (Tier1)
    assignedBy: 'user-003',
    assignedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdBy: 'test-002',
    createdByName: 'กัญญารัตน์ รัตนโชติสกุล',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 15 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 22 * 60 * 60 * 1000),
    attachments: [],
    timeline: [{
      id: 'ro-002-tl-1',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'เคสถูกสร้างโดยลูกค้า',
      user: 'กัญญารัตน์ รัตนโชติสกุล',
      status: 'new'
    }, {
      id: 'ro-002-tl-2',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
      type: 'assignment',
      description: 'รับเคสโดย วรรณภา แซ่ด่าง',
      user: 'วรรณภา แซ่ด่าง',
      status: 'in_progress'
    }],
    comments: []
  },

  // 3. เคส assign ให้ ยุทธนา คณามิ่งมงคล (Tier2)
  {
    id: 'readonly-test-003',
    ticketNumber: 'CDGS-T2001',
    title: 'Database Connection Error #database #error',
    description: '<p>ระบบเกิดข้อผิดพลาดในการเชื่อมต่อกับ Database</p><p>Error: Connection timeout after 30 seconds</p>',
    status: 'in_progress',
    type: 'incident',
    channel: 'phone',
    priority: 'critical',
    category: 'ระบบขัดข้อง',
    product: 'ระบบฐานข้อมูล',
    customerName: 'นพดล เดชะพันธ์',
    assignedTo: 'user-006', // ยุทธนา คณามิ่งมงคล (Tier2)
    assignedBy: 'user-001', // Escalated โดย Admin
    assignedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DRT',
    createdBy: 'test-003',
    createdByName: 'นพดล เดชะพันธ์',
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 45 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 19 * 60 * 60 * 1000),
    attachments: [],
    timeline: [{
      id: 'ro-003-tl-1',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'เคสถูกสร้างโดยลูกค้า',
      user: 'นพดล เดชะพันธ์',
      status: 'new'
    }, {
      id: 'ro-003-tl-2',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง Tier 2',
      user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
      status: 'tier2'
    }, {
      id: 'ro-003-tl-3',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      type: 'assignment',
      description: 'รับเคสโดย ยุทธนา คณามิ่งมงคล',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'in_progress'
    }],
    comments: [{
      id: 'ro-003-c1',
      ticketId: 'readonly-test-003',
      author: 'ยุทธนา คณามิ่งมงคล',
      authorRole: 'tier2',
      content: 'กำลังตรวจสอบ database connection pool ครับ',
      isInternal: true,
      createdAt: new Date(Date.now() - 45 * 60 * 60 * 1000)
    }]
  },

  // 4. เคส assign ให้ พุทธจักษ์ วงค์พันธ์ (Tier3)
  {
    id: 'readonly-test-004',
    ticketNumber: 'CDGS-T3001',
    title: 'ระบบช้า Performance Issue #performance #optimization',
    description: '<p>ระบบทำงานช้ามาก โดยเฉพาะในช่วงเวลา 9:00-12:00</p><p>ต้องการให้ทีมวิเคราะห์และแก้ไขปัญหา</p>',
    status: 'on_hold',
    type: 'incident',
    channel: 'web',
    priority: 'high',
    category: 'ประสิทธิภาพระบบ',
    product: 'Asset Management',
    customerName: 'พิมพ์ลภัส วงศ์ใหญ่',
    customerEmail: 'pimplapas.w@example.com',
    customerPhone: '08-7777-8888',
    assignedTo: 'user-009', // พุทธจักษ์ วงค์พันธ์ (Tier3)
    assignedBy: 'user-006', // Escalated โดย Tier2
    assignedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdBy: 'test-004',
    createdByName: 'พิมพ์ลภัส วงศ์ใหญ่',
    createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 16 * 60 * 60 * 1000),
    attachments: [],
    timeline: [{
      id: 'ro-004-tl-1',
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'เคสถูกสร้างโดยลูกค้า',
      user: 'พิมพ์ลภัส วงศ์ใหญ่',
      status: 'new'
    }, {
      id: 'ro-004-tl-2',
      timestamp: new Date(Date.now() - 7 * 60 * 60 * 1000),
      type: 'escalation',
      description: 'ส่งต่อไปยัง Tier 3',
      user: 'ยุทธนา คณามิ่งมงคล',
      status: 'tier3'
    }, {
      id: 'ro-004-tl-3',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      type: 'assignment',
      description: 'รับเคสโดย พุทธจักษ์ วงค์พันธ์',
      user: 'พุทธจักษ์ วงค์พันธ์',
      status: 'in_progress'
    }, {
      id: 'ro-004-tl-4',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'พักชั่วคราว - รอรันการทดสอบ Performance',
      user: 'พุทธจักษ์ วงค์พันธ์',
      status: 'on_hold'
    }],
    comments: [{
      id: 'ro-004-c1',
      ticketId: 'readonly-test-004',
      author: 'พุทธจักษ์ วงค์พันธ์',
      authorRole: 'tier3',
      content: 'กำลังรัน performance profiling tool ครับ รอผลการทดสอบ',
      isInternal: true,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000)
    }]
  },

  // 5. เคส assign ให้ อภิญญา ทองชัย (Tier1) - เพื่อทดสอบ Takeover
  {
    id: 'readonly-test-005',
    ticketNumber: 'CDGS-T1003',
    title: 'ต้องการเพิ่มผู้ใช้งานใหม่ #ผู้ใช้งาน #เพิ่มสิทธิ์',
    description: '<p>ต้องการเพิ่มผู้ใช้งานใหม่เข้าระบบ Asset Management</p><p>ชื่อ: นายทดสอบ ระบบดี</p><p>Email: test.system@example.com</p>',
    status: 'in_progress',
    type: 'service_request',
    channel: 'line',
    priority: 'medium',
    category: 'จัดการผู้ใช้งาน',
    product: 'Asset Management',
    customerName: 'สุภาพร ทรงธรรม',
    customerEmail: 'supaporn.s@example.com',
    customerPhone: '08-3333-4444',
    assignedTo: 'user-012', // อภิญญา ทองชัย (Tier1)
    assignedBy: 'user-012',
    assignedAt: new Date(Date.now() - 30 * 60 * 60 * 1000),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdBy: 'test-005',
    createdByName: 'สุภาพร ทรงธรรม',
    createdAt: new Date(Date.now() - 45 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 10 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 23 * 60 * 60 * 1000 + 15 * 60 * 60 * 1000),
    attachments: [],
    timeline: [{
      id: 'ro-005-tl-1',
      timestamp: new Date(Date.now() - 45 * 60 * 60 * 1000),
      type: 'status_change',
      description: 'เคสถูกสร้างโดยลูกค้า',
      user: 'สุภาพร ทรงธรรม',
      status: 'new'
    }, {
      id: 'ro-005-tl-2',
      timestamp: new Date(Date.now() - 30 * 60 * 60 * 1000),
      type: 'assignment',
      description: 'รับเคสโดย อภิญญา ทองชัย',
      user: 'อภิญญา ทองชัย',
      status: 'in_progress'
    }],
    comments: []
  }
];