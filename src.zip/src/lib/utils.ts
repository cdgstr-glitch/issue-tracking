import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import type { UserRole } from "../contexts/AuthContext";
import type { User } from "../contexts/AuthContext";
import type { TicketStatus, TicketPriority, Attachment } from "../types";
import { constants } from "./mockDb/data/constants";
import { getStatusConfig } from "./settings";
import {
  formatDate as formatDateStd,
  formatDateTime as formatDateTimeStd,
  formatRelativeTime as formatRelativeTimeStd,
} from "./date";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ========================================
// Multi-Role Utility Functions
// ========================================

/**
 * Check if user has a specific role
 * @param user - User object
 * @param role - Role to check
 * @returns true if user has the role
 */
export function hasRole(user: User | null | undefined, role: UserRole): boolean {
  if (!user) return false;

  // NEW: Check in roles array
  if (user.roles && Array.isArray(user.roles)) {
    return user.roles.includes(role);
  }

  // FALLBACK: Backward compatibility with single role
  return user.role === role;
}

/**
 * Check if user has ANY of the specified roles
 * @param user - User object
 * @param roles - Array of roles to check
 * @returns true if user has at least one of the roles
 */
export function hasAnyRole(user: User | null | undefined, roles: UserRole[]): boolean {
  if (!user) return false;

  // NEW: Check in roles array
  if (user.roles && Array.isArray(user.roles)) {
    return roles.some((role) => user.roles.includes(role));
  }

  // FALLBACK: Backward compatibility with single role
  return roles.includes(user.role);
}

/**
 * Check if user has ALL of the specified roles
 * @param user - User object
 * @param roles - Array of roles to check
 * @returns true if user has all of the roles
 */
export function hasAllRoles(user: User | null | undefined, roles: UserRole[]): boolean {
  if (!user) return false;

  // NEW: Check in roles array
  if (user.roles && Array.isArray(user.roles)) {
    return roles.every((role) => user.roles.includes(role));
  }

  // FALLBACK: Backward compatibility with single role
  return roles.length === 1 && roles[0] === user.role;
}

/**
 * Check if role is user's primary role
 * @param user - User object
 * @param role - Role to check
 * @returns true if role is primary role
 */
export function isPrimaryRole(user: User | null | undefined, role: UserRole): boolean {
  if (!user) return false;

  // NEW: Check primaryRole
  if (user.primaryRole) {
    return user.primaryRole === role;
  }

  // FALLBACK: Backward compatibility with single role
  return user.role === role;
}

/**
 * Get user's primary role
 * @param user - User object
 * @returns primary role or undefined
 */
export function getPrimaryRole(user: User | null | undefined): UserRole | undefined {
  if (!user) return undefined;

  // NEW: Return primaryRole
  if (user.primaryRole) {
    return user.primaryRole;
  }

  // FALLBACK: Backward compatibility with single role
  return user.role;
}

/**
 * Get all user's roles
 * @param user - User object
 * @returns array of roles
 */
export function getAllRoles(user: User | null | undefined): UserRole[] {
  if (!user) return [];

  // NEW: Return roles array
  if (user.roles && Array.isArray(user.roles)) {
    return user.roles;
  }

  // FALLBACK: Backward compatibility with single role
  return [user.role];
}

/**
 * Get user's tier roles only (tier2, tier3) สำหรับสลับบทบาท
 * ⚠️ IMPORTANT: tier1 ไม่มีการสลับบทบาท - ใช้ได้เฉพาะ tier2 และ tier3
 * @param user - User object
 * @returns array of tier roles (tier2, tier3 only)
 */
export function getTierRoles(user: User | null | undefined): UserRole[] {
  const allRoles = getAllRoles(user);
  // ✅ สลับบทบาทได้เฉพาะ tier2 และ tier3 เท่านั้น (ไม่รวม tier1 และ admin)
  return allRoles.filter((role) => ["tier2", "tier3"].includes(role));
}

/**
 * Check if user needs role selector (has multiple tier roles)
 * @param user - User object
 * @returns true if user has more than 1 tier role
 */
export function needsRoleSelector(user: User | null | undefined): boolean {
  const tierRoles = getTierRoles(user);
  return tierRoles.length > 1;
}

// ========================================
// Original Utility Functions
// ========================================

export function getRoleDisplayName(role: UserRole, username?: string): string {
  const roleMap: Record<UserRole, string> = {
    customer: "ลูกค้า",
    staff: "พนักงาน",
    tier1: "เทียร์ 1",
    tier2: "เทียร์ 2",
    tier3: "เทียร์ 3",
    admin: "ผู้ดูแลระบบ",
  };

  return roleMap[role] || role;
}

export function getStatusColor(status: TicketStatus): string {
  // Use Single Source of Truth from DB Constants (via Settings wrapper)
  const config = getStatusConfig(status);
  if (config) {
    return config.color;
  }

  // Fallback
  return "bg-gray-100 text-gray-800";
}

export function getStatusLabel(status: TicketStatus): string {
  // Use Single Source of Truth from DB Constants (via Settings wrapper)
  const config = getStatusConfig(status);
  if (config) {
    return config.label;
  }

  return status;
}

/**
 * Get customer-friendly status label
 * - ซ่อน tier1/tier2/tier3 → แสดง "กำลังดำเนินการ"
 * - แปลภาษาให้เป็นมิตรกับลูกค้า
 */
export function getStatusLabelForCustomer(status: TicketStatus): string {
  // Use Single Source of Truth from DB Constants (via Settings wrapper)
  const config = getStatusConfig(status);
  if (config && (config as any).customerLabel) {
    return (config as any).customerLabel;
  }

  // Fallback to standard label
  return getStatusLabel(status);
}

/**
 * Get customer-friendly status color
 * - tier1/tier2/tier3 → ใช้สีเดียวกัน (กำลังดำเนินการ)
 */
export function getStatusColorForCustomer(status: TicketStatus): string {
  // Use Single Source of Truth from DB Constants (via Settings wrapper)
  const config = getStatusConfig(status);
  if (config && (config as any).customerColor) {
    return (config as any).customerColor;
  }

  // Fallback to standard color
  return getStatusColor(status);
}

export function getPriorityColor(priority: TicketPriority): string {
  // Use Single Source of Truth from DB Constants
  if (constants.TICKET_PRIORITIES[priority]) {
    return constants.TICKET_PRIORITIES[priority].color;
  }

  // Fallback
  const colors: Record<TicketPriority, string> = {
    low: "bg-gray-100 text-gray-700",
    medium: "bg-blue-100 text-blue-700",
    high: "bg-orange-100 text-orange-700",
    critical: "bg-red-100 text-red-700",
  };
  return colors[priority] || colors.medium;
}

export function getPriorityLabel(priority: TicketPriority): string {
  // Use Single Source of Truth from DB Constants
  if (constants.TICKET_PRIORITIES[priority]) {
    return constants.TICKET_PRIORITIES[priority].label;
  }

  const labels: Record<TicketPriority, string> = {
    low: "น้อย",
    medium: "ปานกลาง",
    high: "สูง",
    critical: "วิกฤติ",
  };
  return labels[priority] || priority;
}

/**
 * Get customer-friendly priority label
 * - ใช้คำที่อ่อนลงและเป็นบวก
 */
export function getPriorityLabelForCustomer(priority: TicketPriority): string {
  const config = constants.TICKET_PRIORITIES[priority] as any;
  if (config && config.customerLabel) {
    return config.customerLabel;
  }

  const labels: Record<TicketPriority, string> = {
    low: "ปกติ",
    medium: "ปานกลาง",
    high: "ด่วน",
    critical: "เร่งด่วนมาก",
  };
  return labels[priority] || priority;
}

export function calculateSLAStatus(
  createdAt: Date,
  dueDate: Date,
  status: TicketStatus,
  resolvedAt?: Date | null,
  closedAt?: Date | null
): "ok" | "warning" | "breached" {
  // Determine effective completion time if ticket is done
  let completionTime: Date | null = null;

  if (status === "resolved") {
    completionTime = resolvedAt || null;
  } else if (status === "closed") {
    // For closed tickets, use resolvedAt if available (work finished), otherwise closedAt
    completionTime = resolvedAt || closedAt || null;
  }

  // If we have a completion time, check if it met the SLA
  if (completionTime) {
    return completionTime.getTime() > dueDate.getTime() ? "breached" : "ok";
  }

  // Fallback: If status is resolved/closed but no dates provided, assume OK
  if (status === "resolved" || status === "closed") {
    return "ok";
  }

  const now = new Date();
  const timeRemaining = dueDate.getTime() - now.getTime();
  const totalTime = dueDate.getTime() - createdAt.getTime();
  const percentageRemaining = (timeRemaining / totalTime) * 100;

  if (timeRemaining < 0) {
    return "breached";
  } else if (percentageRemaining < 25) {
    return "warning";
  } else {
    return "ok";
  }
}

// ----------------------------------------------------------------------
// Date Helpers (Single Source via src/lib/date.ts)
// NOTE: keep behavior same as legacy implementation (100%)
// ----------------------------------------------------------------------

export function formatRelativeTime(date: unknown): string {
  return formatRelativeTimeStd(date);
}

// NOTE: keep same behavior as before (date + time)
export function formatDate(date: unknown): string {
  return formatDateTimeStd(date);
}

// ----------------------------------------------------------------------
// Attachment Helpers
// ----------------------------------------------------------------------

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

export function isImageFile(attachment: Attachment): boolean {
  const imageExtensions = ["jpg", "jpeg", "png", "gif", "webp", "svg"];
  const ext = attachment.filename?.split(".").pop()?.toLowerCase() || "";
  return imageExtensions.includes(ext) || (attachment.type?.startsWith("image/") ?? false);
}

export function getFileIcon(attachment: Attachment): string {
  if (isImageFile(attachment)) return "🖼️";

  const ext = attachment.filename.split(".").pop()?.toLowerCase();
  switch (ext) {
    case "pdf":
      return "📄";
    case "doc":
    case "docx":
      return "📝";
    case "xls":
    case "xlsx":
      return "📊";
    case "ppt":
    case "pptx":
      return "📉";
    case "zip":
    case "rar":
      return "📦";
    default:
      return "📎";
  }
}
