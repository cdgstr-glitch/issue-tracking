import { Ticket } from '../types';

// เพิ่มข้อมูลเคส closed และ in_progress สำหรับ user ที่ยังไม่ครบ

export const extraTickets: Ticket[] = [
  // ==================== user-001 (ธิราภรณ์ รุ่งวิรัตน์กุล - Admin+Tier1) ====================
  {
    id: 'thiraporn-r-closed-1',
    ticketNumber: 'CDGS-2024-TR301',
    title: 'ติดตั้ง Antivirus ให้เครื่องใหม่เสร็จสิ้น #แก้ไขแล้ว',
    description: 'ติดตั้ง Antivirus สำหรับเครื่องคอมพิวเตอร์ใหม่ 5 เครื่อง - เสร็จสมบูรณ์',
    status: 'closed',
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Software & Applications',
    customerName: 'ฝ่าย IT',
    customerEmail: 'it@example.com',
    customerPhone: '+66-85-111-1111',
    assignedTo: 'user-001',
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-24T09:00:00'),
    updatedAt: new Date('2024-11-24T16:00:00'),
    closedAt: new Date('2024-11-24T16:00:00'),
    closedBy: 'user-001', // ธิราภรณ์ รุ่งวิรัตน์กุล (Admin)
    dueDate: new Date('2024-11-24T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-tr-c1',
        timestamp: new Date('2024-11-24T09:30:00'),
        type: 'status_change',
        description: 'ธิราภรณ์ รุ่งวิรัตน์กุล รับเคส',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'in_progress'
      },
      {
        id: 'tl-tr-c2',
        timestamp: new Date('2024-11-24T15:30:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้น',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'resolved'
      },
      {
        id: 'tl-tr-c3',
        timestamp: new Date('2024-11-24T16:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'closed'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (resolved) - ธิราภรณ์
  {
    id: 'thiraporn-r-resolved-1',
    ticketNumber: 'CDGS-2024-TR401',
    title: 'อัพเดท Microsoft Office เวอร์ชันใหม่ #software #resolved',
    description: 'อัพเดท Microsoft Office จากเวอร์ชัน 2019 เป็น Microsoft 365 สำหรับเครื่องในฝ่ายการตลาด 10 เครื่อง รวมถึงการ migrate license และ activate บัญชีผู้ใช้ใหม่',
    status: 'resolved',
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Software & Applications',
    customerName: 'ฝ่ายการตลาด',
    customerEmail: 'marketing@mrta.co.th',
    customerPhone: '+66-85-100-1001',
    assignedTo: 'user-001',
    assignedBy: 'user-001',
    assignedAt: new Date('2024-11-26T09:15:00'),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-26T09:00:00'),
    updatedAt: new Date('2024-11-27T14:30:00'),
    resolvedAt: new Date('2024-11-27T14:30:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'thiraporn-r1-tl-1',
        timestamp: new Date('2024-11-26T09:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'thiraporn-r1-tl-2',
        timestamp: new Date('2024-11-26T09:15:00'),
        type: 'assignment',
        description: 'รับเคสโดย ธิราภรณ์ รุ่งวิรัตน์กุล',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'in_progress'
      },
      {
        id: 'thiraporn-r1-tl-3',
        timestamp: new Date('2024-11-27T14:30:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - อัพเดท Office และ activate license ครบทั้ง 10 เครื่อง ทดสอบการทำงานสำเร็จ',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (pending_closure) - ธิราภรณ์
  {
    id: 'thiraporn-r-pending-1',
    ticketNumber: 'CDGS-2024-TR402',
    title: 'ย้ายข้อมูล File Server เก่าไปเซิร์ฟเวอร์ใหม่ #migration #pending_closure',
    description: 'ย้ายข้อมูลจาก File Server เก่า (Windows Server 2012) ไปยังเซิร์ฟเวอร์ใหม่ (Windows Server 2022) รวมข้อมูลทั้งหมด 2.5 TB พร้อมตั้งค่า Permission และ Share Folder ใหม่',
    status: 'pending_closure',
    type: 'service_request',
    channel: 'web',
    priority: 'high',
    category: 'Infrastructure',
    customerName: 'ฝ่าย IT Infrastructure',
    customerEmail: 'it-infra@mrta.co.th',
    customerPhone: '+66-85-100-1002',
    assignedTo: 'user-001',
    assignedBy: 'user-001',
    assignedAt: new Date('2024-11-25T10:00:00'),
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-25T10:00:00'),
    updatedAt: new Date('2024-11-27T16:00:00'),
    resolvedAt: new Date('2024-11-27T16:00:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'thiraporn-pc1-tl-1',
        timestamp: new Date('2024-11-25T10:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'thiraporn-pc1-tl-2',
        timestamp: new Date('2024-11-25T10:30:00'),
        type: 'assignment',
        description: 'รับเคสโดย ธิราภรณ์ รุ่งวิรัตน์กุล',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'in_progress'
      },
      {
        id: 'thiraporn-pc1-tl-3',
        timestamp: new Date('2024-11-27T16:00:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - Migration เสร็จสมบูรณ์ ตั้งค่า Permission และทดสอบการเข้าถึงสำเร็จ',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'pending_closure'
      }
    ],
    comments: []
  },

  // ==================== user-002 (สาริน ช่อพะยอม - Admin+Tier1) ====================
  {
    id: 'sarin-closed-1',
    ticketNumber: 'CDGS-2024-SC301',
    title: 'แก้ไขปัญหาเครื่องพิมพ์ Offline เสร็จสิ้น #แก้ไขแล้ว',
    description: 'เครื่องพิมพ์แสดง Offline - แก้ไขโดย restart print spooler service',
    status: 'closed',
    type: 'incident',
    channel: 'phone',
    priority: 'medium',
    category: 'Hardware',
    customerName: 'ฝ่ายบัญชี',
    customerEmail: 'accounting@example.com',
    customerPhone: '+66-85-222-2222',
    assignedTo: 'user-002',
    projectId: 'proj-005',
    projectCode: 'D24-6067',
    projectName: 'กระทรวงคมนาคม',
    projectShortName: 'MOT',
    createdAt: new Date('2024-11-23T11:00:00'),
    updatedAt: new Date('2024-11-23T14:00:00'),
    closedAt: new Date('2024-11-23T14:00:00'),
    closedBy: 'user-002', // สาริน ช่อพะยอม (Admin)
    dueDate: new Date('2024-11-23T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-sc-c1',
        timestamp: new Date('2024-11-23T11:20:00'),
        type: 'status_change',
        description: 'สาริน ช่อพะยอม รับเคส',
        user: 'สาริน ช่อพะยอม',
        status: 'in_progress'
      },
      {
        id: 'tl-sc-c2',
        timestamp: new Date('2024-11-23T14:00:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและปิดเคส',
        user: 'สาริน ช่อพะยอม',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-003 (วรรณภา แซ่ด่าง - Tier1) ====================
  {
    id: 'praaornrat-closed-1',
    ticketNumber: 'CDGS-2024-PP301',
    title: 'Reset Password Domain Account เสร็จสิ้น #แก้ไขแล้ว',
    description: 'ลืมรหัสผ่าน Domain Account - reset password เรียบร้อย',
    status: 'closed',
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Access & Permissions',
    customerName: 'พนักงานฝ่ายขาย',
    customerEmail: 'sales-user@example.com',
    customerPhone: '+66-85-333-3333',
    assignedTo: 'user-003',
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DOPA',
    createdAt: new Date('2024-11-22T10:00:00'),
    updatedAt: new Date('2024-11-22T10:30:00'),
    closedAt: new Date('2024-11-22T10:30:00'),
    closedBy: 'user-003', // วรรณภา แซ่ด่าง (Tier1)
    dueDate: new Date('2024-11-22T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-pp-c1',
        timestamp: new Date('2024-11-22T10:10:00'),
        type: 'status_change',
        description: 'วรรณภา แซ่ด่าง รับเคส',
        user: 'วรรณภา แซ่ด่าง',
        status: 'in_progress'
      },
      {
        id: 'tl-pp-c2',
        timestamp: new Date('2024-11-22T10:30:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'วรรณภา แซ่ด่าง',
        status: 'closed'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (resolved) - วรรณภา
  {
    id: 'wannapa-resolved-1',
    ticketNumber: 'CDGS-2024-WP401',
    title: 'เพิ่มสิทธิ์การเข้าถึง Shared Drive #access #resolved',
    description: 'พนักงานใหม่ฝ่ายการเงิน 3 คน ต้องการสิทธิ์เข้าถึง Shared Drive "Finance Documents" เพื่อทำงานร่วมกับทีม รวมถึงการตั้งค่า Read/Write Permission ตามตำแหน่งงาน',
    status: 'resolved',
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Access & Permissions',
    customerName: 'ฝ่ายการเงิน',
    customerEmail: 'finance@dopa.go.th',
    customerPhone: '+66-85-200-2001',
    assignedTo: 'user-003',
    assignedBy: 'user-003',
    assignedAt: new Date('2024-11-26T10:00:00'),
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DRT',
    createdAt: new Date('2024-11-26T10:00:00'),
    updatedAt: new Date('2024-11-27T13:15:00'),
    resolvedAt: new Date('2024-11-27T13:15:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'wannapa-r1-tl-1',
        timestamp: new Date('2024-11-26T10:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'wannapa-r1-tl-2',
        timestamp: new Date('2024-11-26T10:20:00'),
        type: 'assignment',
        description: 'รับเคสโดย วรรณภา แซ่ด่าง',
        user: 'วรรณภา แซ่ด่าง',
        status: 'in_progress'
      },
      {
        id: 'wannapa-r1-tl-3',
        timestamp: new Date('2024-11-27T13:15:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - เพิ่มสิทธิ์ทั้ง 3 คน และตั้งค่า Permission ตามตำแหน่งเรียบร้อย ทดสอบการเข้าถึงสำเร็จ',
        user: 'วรรณภา แซ่ด่าง',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (pending_closure) - วรรณภา
  {
    id: 'wannapa-pending-1',
    ticketNumber: 'CDGS-2024-WP402',
    title: 'ติดตั้งโปรแกรม Adobe Acrobat Pro #software #pending_closure',
    description: 'ติดตั้งและ activate โปรแกรม Adobe Acrobat Pro DC สำหรับฝ่ายนิติกรรม 5 เครื่อง เพื่อใช้ในการจัดการเอกสาร PDF และลงนามอิเล็กทรอนิกส์',
    status: 'pending_closure',
    type: 'service_request',
    channel: 'web',
    priority: 'medium',
    category: 'Software & Applications',
    customerName: 'ฝ่ายนิติกรรม',
    customerEmail: 'legal@dopa.go.th',
    customerPhone: '+66-85-200-2002',
    assignedTo: 'user-003',
    assignedBy: 'user-003',
    assignedAt: new Date('2024-11-25T11:00:00'),
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DRT',
    createdAt: new Date('2024-11-25T11:00:00'),
    updatedAt: new Date('2024-11-27T15:30:00'),
    resolvedAt: new Date('2024-11-27T15:30:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'wannapa-pc1-tl-1',
        timestamp: new Date('2024-11-25T11:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'wannapa-pc1-tl-2',
        timestamp: new Date('2024-11-25T11:30:00'),
        type: 'assignment',
        description: 'รับเคสโดย วรรณภา แซ่ด่าง',
        user: 'วรรณภา แซ่ด่าง',
        status: 'in_progress'
      },
      {
        id: 'wannapa-pc1-tl-3',
        timestamp: new Date('2024-11-27T15:30:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - ติดตั้งและ activate Adobe Acrobat Pro ครบทั้ง 5 เครื่อง ทดสอบฟีเจอร์ต่างๆ สำเร็จ',
        user: 'วรรณภา แซ่ด่าง',
        status: 'pending_closure'
      }
    ],
    comments: []
  },

  // ==================== user-004 (เขมิกา แซ่ตั้ง - Tier1) ====================
  {
    id: 'khemika-closed-1',
    ticketNumber: 'CDGS-2024-KS301',
    title: 'แก้ไขปัญหา Wi-Fi ขาดหายเสร็จสิ้น #แก้ไขแล้ว',
    description: 'Wi-Fi ในห้องประชุมขาดหาย - แก้ไขโดย restart access point',
    status: 'closed',
    type: 'incident',
    channel: 'line',
    priority: 'high',
    category: 'Network & Connectivity',
    customerName: 'ฝ่ายบริหาร',
    customerEmail: 'executive@example.com',
    customerPhone: '+66-85-444-4444',
    assignedTo: 'user-004',
    projectId: 'proj-004',
    projectCode: 'D24-6053',
    projectName: 'กรมการแพทย์แผนไทยและการแพทย์ทดแทน',
    projectShortName: 'DTAM',
    createdAt: new Date('2024-11-21T14:00:00'),
    updatedAt: new Date('2024-11-21T15:30:00'),
    closedAt: new Date('2024-11-21T15:30:00'),
    closedBy: 'user-004', // เขมิกา แซ่ตั้ง (Tier1)
    dueDate: new Date('2024-11-21T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-ks-c1',
        timestamp: new Date('2024-11-21T14:15:00'),
        type: 'status_change',
        description: 'เขมิกา แซ่ตั้ง รับเคส',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'in_progress'
      },
      {
        id: 'tl-ks-c2',
        timestamp: new Date('2024-11-21T15:30:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและปิดเคส',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-005 (ธัญญาพร ทองแก้ว - Tier1) ====================
  {
    id: 'thiraporn-t-inprog-1',
    ticketNumber: 'CDGS-2024-TT101',
    title: 'Monitor ไม่แสดงผล #hardware',
    description: 'จอ Monitor เปิดแล้วไม่แสดงผล มีเพียงไฟ LED กระพริบ',
    status: 'in_progress',
    type: 'incident',
    channel: 'phone',
    priority: 'high',
    category: 'Hardware',
    customerName: 'ฝ่ายเอกสาร',
    customerEmail: 'document-dept@example.com',
    customerPhone: '+66-85-555-5555',
    assignedTo: 'user-005',
    assignedBy: 'user-004', // เขมิกา แซ่ตั้ง (Tier1) ส่งต่อมา
    assignedAt: new Date('2024-11-27T09:20:00'),
    previousAssignee: 'user-004',
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-27T09:00:00'),
    updatedAt: new Date('2024-11-27T09:30:00'),
    dueDate: new Date('2024-11-27T15:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-tt0',
        timestamp: new Date('2024-11-27T09:10:00'),
        type: 'status_change',
        description: 'เขมิกา แซ่ตั้ง รับเคส',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'in_progress'
      },
      {
        id: 'tl-tt1',
        timestamp: new Date('2024-11-27T09:20:00'),
        type: 'escalation',
        description: 'เขมิกา แซ่ตั้ง ส่งต่อมายัง Tier 1',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'tier1'
      },
      {
        id: 'tl-tt2',
        timestamp: new Date('2024-11-27T09:30:00'),
        type: 'status_change',
        description: 'ธัญญาพร ทองแก้ว รับเคสและเริ่มดำเนินการ',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'in_progress'
      }
    ],
    comments: []
  },
  {
    id: 'thiraporn-t-closed-1',
    ticketNumber: 'CDGS-2024-TT301',
    title: 'ติดตั้ง Printer Driver เสร็จสิ้น #แก้ไขแล้ว',
    description: 'ติดตั้ง Printer Driver สำหรับเครื่องพิมพ์ใหม่ - เสร็จสมบูรณ์',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'medium',
    category: 'Software & Applications',
    customerName: 'ฝ่าย IT',
    customerEmail: 'it-support@example.com',
    customerPhone: '+66-85-666-6666',
    assignedTo: 'user-005',
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DOPA',
    createdAt: new Date('2024-11-20T10:00:00'),
    updatedAt: new Date('2024-11-20T11:00:00'),
    closedAt: new Date('2024-11-20T11:00:00'),
    closedBy: 'user-005', // ธัญญาพร ทองแก้ว (Tier1)
    dueDate: new Date('2024-11-20T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-tt-c1',
        timestamp: new Date('2024-11-20T10:15:00'),
        type: 'status_change',
        description: 'ธัญญาพร ทองแก้ว รับเคส',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'in_progress'
      },
      {
        id: 'tl-tt-c2',
        timestamp: new Date('2024-11-20T11:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-006 (ยุทธนา คณามิ่งมงคล - Tier2) ====================
  {
    id: 'yuttana-inprog-1',
    ticketNumber: 'CDGS-2024-YK101',
    title: 'ออกแบบ Database Schema ใหม่ #development',
    description: 'ต้องการออกแบบ Database Schema สำหรับระบบจัดการเอกสารใหม่',
    status: 'in_progress',
    type: 'service_request',
    channel: 'email',
    priority: 'high',
    category: 'Data & Database',
    customerName: 'ทีมพัฒนา',
    customerEmail: 'dev-team@example.com',
    customerPhone: '+66-84-111-1111',
    assignedTo: 'user-006',
    assignedBy: 'user-003', // Wannapa Sae-dang (Tier1) ส่งต่อ
    assignedAt: new Date('2024-11-26T08:30:00'),
    previousAssignee: 'user-003',
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-26T08:00:00'),
    updatedAt: new Date('2024-11-27T10:00:00'),
    dueDate: new Date('2024-11-30T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-yk1',
        timestamp: new Date('2024-11-26T08:30:00'),
        type: 'escalation',
        description: 'Tier 1 ส่งต่อมายัง Tier 2',
        user: 'วรรณภา แซ่ด่าง',
        status: 'tier2'
      },
      {
        id: 'tl-yk2',
        timestamp: new Date('2024-11-26T09:00:00'),
        type: 'status_change',
        description: 'ยุทธนา คณามิ่งมงคล รับเคสและเริ่มดำเนินการ',
        user: 'ยุทธนา คณามิ่งมงคล',
        status: 'in_progress'
      }
    ],
    comments: []
  },
  {
    id: 'yuttana-closed-1',
    ticketNumber: 'CDGS-2024-YK301',
    title: 'Optimize SQL Query เสร็จสิ้น #แก้ไขแล้ว',
    description: 'Optimize SQL Query ที่ทำงานช้า - ปรับปรุงเสร็จสิ้น',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'high',
    category: 'Data & Database',
    customerName: 'ทีม Backend',
    customerEmail: 'backend@example.com',
    customerPhone: '+66-84-222-2222',
    assignedTo: 'user-006',
    assignedBy: 'user-001', // Thiraporn R (Tier1) ส่งต่อมา (จากชื่อ Nattapon ในคอมเมนต์เดิม - ใช้ admin แทน)
    assignedAt: new Date('2024-11-19T10:00:00'),
    previousAssignee: 'user-001',
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-19T09:00:00'),
    updatedAt: new Date('2024-11-20T16:00:00'),
    closedAt: new Date('2024-11-20T16:00:00'),
    closedBy: 'user-001', // ธิราภรณ์ รุ่งวิรัตน์กุล (Admin) - Thiraporn Rungwiratkul ปิดเคส
    dueDate: new Date('2024-11-20T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-yk-c1',
        timestamp: new Date('2024-11-19T09:30:00'),
        type: 'escalation',
        description: 'Tier 1 ส่งต่อมายัง Tier 2',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'tier2'
      },
      {
        id: 'tl-yk-c2',
        timestamp: new Date('2024-11-19T10:00:00'),
        type: 'status_change',
        description: 'ยุทธนา คณามิ่งมงคล รับเคส',
        user: 'ยุทธนา คณามิ่งมงคล',
        status: 'in_progress'
      },
      {
        id: 'tl-yk-c3',
        timestamp: new Date('2024-11-20T15:30:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและส่งกลับ T1 เพื่อปิด',
        user: 'ยุทธนา คณามิ่งมงคล',
        status: 'pending_closure'
      },
      {
        id: 'tl-yk-c4',
        timestamp: new Date('2024-11-20T16:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'ธิราภรณ์ รุ่งวิรัตน์กุล',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-007 (ประกาศิต ประคองเพ็ชร - Tier2+Tier3) ====================
  {
    id: 'prakasit-extra-closed-1',
    ticketNumber: 'CDGS-2024-PK301',
    title: 'Setup Load Balancer เสร็จสิ้น #แก้ไขแล้ว',
    description: 'ติดตั้งและ configure Load Balancer สำหรับ web server - เสร็จสมบูรณ์',
    status: 'closed',
    type: 'service_request',
    channel: 'email',
    priority: 'high',
    category: 'Infrastructure',
    customerName: 'ทีม DevOps',
    customerEmail: 'devops@example.com',
    customerPhone: '+66-84-333-3333',
    assignedTo: 'user-007',
    assignedBy: 'user-004', // Khemika Saetang (Tier1+Staff) ส่งต่อมา
    assignedAt: new Date('2024-11-18T11:00:00'),
    previousAssignee: 'user-004',
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-18T10:00:00'),
    updatedAt: new Date('2024-11-19T17:00:00'),
    closedAt: new Date('2024-11-19T17:00:00'),
    closedBy: 'user-004', // Khemika Saetang (Tier1+Staff) ปิดเคส
    dueDate: new Date('2024-11-19T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-pk-c1',
        timestamp: new Date('2024-11-18T10:30:00'),
        type: 'escalation',
        description: 'Tier 1 ส่งต่อมายัง Tier 2',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'tier2'
      },
      {
        id: 'tl-pk-c2',
        timestamp: new Date('2024-11-18T11:00:00'),
        type: 'status_change',
        description: 'ประกาศิต ประคองเพ็ชร รับเคส',
        user: 'ประกาศิต ประคองเพ็ชร',
        status: 'in_progress'
      },
      {
        id: 'tl-pk-c3',
        timestamp: new Date('2024-11-19T16:30:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและส่งกลับ T1 เพื่อปิด',
        user: 'ประกาศิต ประคองเพ็ชร',
        status: 'pending_closure'
      },
      {
        id: 'tl-pk-c4',
        timestamp: new Date('2024-11-19T17:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-008 (ประวิช จินทนากร - Tier2) ====================
  {
    id: 'pravich-closed-1',
    ticketNumber: 'CDGS-2024-PJ301',
    title: 'แก้ไข Memory Leak ในระบบเสร็จสิ้น #แก้ไขแล้ว',
    description: 'แก้ไข Memory Leak ที่ทำให้ระบบช้า - แก้ไขเสร็จสมูรณ์',
    status: 'closed',
    type: 'incident',
    channel: 'line',
    priority: 'critical',
    category: 'Software & Applications',
    customerName: 'ทีม Platform',
    customerEmail: 'platform@example.com',
    customerPhone: '+66-84-444-4444',
    assignedTo: 'user-008',
    assignedBy: 'user-004', // Khemika Saetang (Tier1) ส่งต่อมา
    assignedAt: new Date('2024-11-17T09:00:00'),
    previousAssignee: 'user-004',
    projectId: 'proj-009',
    projectCode: 'PD250019',
    projectName: 'มหาวิทยาลัยเกษตรศาสตร์',
    projectShortName: 'KU',
    createdAt: new Date('2024-11-17T08:00:00'),
    updatedAt: new Date('2024-11-18T18:00:00'),
    closedAt: new Date('2024-11-18T18:00:00'),
    closedBy: 'user-004', // Khemika Saetang (Tier1) ปิดเคส
    dueDate: new Date('2024-11-18T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-pj-c1',
        timestamp: new Date('2024-11-17T08:30:00'),
        type: 'escalation',
        description: 'Tier 1 ส่งต่อมายัง Tier 2',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'tier2'
      },
      {
        id: 'tl-pj-c2',
        timestamp: new Date('2024-11-17T09:00:00'),
        type: 'status_change',
        description: 'ประวิช จินทนากร รับเคส',
        user: 'ประวิช จินทนากร',
        status: 'in_progress'
      },
      {
        id: 'tl-pj-c3',
        timestamp: new Date('2024-11-18T17:30:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและส่งกลับ T1 เพื่อปิด',
        user: 'ประวิช จินทนากร',
        status: 'pending_closure'
      },
      {
        id: 'tl-pj-c4',
        timestamp: new Date('2024-11-18T18:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-009 (พุทธจักษ์ วงค์พันธ์ - Tier3) ====================
  {
    id: 'puttajak-inprog-1',
    ticketNumber: 'CDGS-2024-PW101',
    title: 'Architecture Review สำหรับ Microservices #architecture',
    description: 'ทบทวน Architecture ของระบบ Microservices และให้คำแนะนำในการปรับปรุง',
    status: 'in_progress',
    type: 'service_request',
    channel: 'email',
    priority: 'high',
    category: 'Infrastructure',
    customerName: 'ทีม Architecture',
    customerEmail: 'architecture@example.com',
    customerPhone: '+66-83-111-1111',
    assignedTo: 'user-009',
    assignedBy: 'user-006', // Yuttana Knamingmongkol (Tier2) ส่งต่อมา
    assignedAt: new Date('2024-11-25T10:00:00'),
    previousAssignee: 'user-006',
    projectId: 'proj-005',
    projectCode: 'D24-6054',
    projectName: 'สำนักงานประกันสังคม',
    projectShortName: 'SSO',
    createdAt: new Date('2024-11-25T09:00:00'),
    updatedAt: new Date('2024-11-27T10:00:00'),
    dueDate: new Date('2024-11-30T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-pw1',
        timestamp: new Date('2024-11-25T09:30:00'),
        type: 'escalation',
        description: 'Tier 2 ส่งต่อมายัง Tier 3',
        user: 'ยุทธนา คณามิ่งมงคล',
        status: 'tier3'
      },
      {
        id: 'tl-pw2',
        timestamp: new Date('2024-11-25T10:00:00'),
        type: 'status_change',
        description: 'พุทธจักษ์ วงค์พันธ์ รับเคสและเริ่มดำเนินการ',
        user: 'พุทธจักษ์ วงค์พันธ์',
        status: 'in_progress'
      }
    ],
    comments: []
  },
  {
    id: 'puttajak-closed-1',
    ticketNumber: 'CDGS-2024-PW301',
    title: 'Setup Disaster Recovery Site เสร็จสิ้น #แก้ไขแล้ว',
    description: 'ติดตั้งและ configure Disaster Recovery Site - เสร็จสมบูรณ์',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'critical',
    category: 'Infrastructure',
    customerName: 'ฝ่าย Infrastructure',
    customerEmail: 'infra@example.com',
    customerPhone: '+66-83-222-2222',
    assignedTo: 'user-009',
    assignedBy: 'user-006', // Yuttana Knamingmongkol (Tier2) ส่งต่อมา (จากชื่อ Jutharat ในคอมเมนต์เดิม)
    assignedAt: new Date('2024-11-15T11:00:00'),
    previousAssignee: 'user-006',
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-15T10:00:00'),
    updatedAt: new Date('2024-11-18T17:00:00'),
    closedAt: new Date('2024-11-18T17:00:00'),
    closedBy: 'user-003', // Wannapa Sae-dang (user-003) ปิดเคส
    dueDate: new Date('2024-11-18T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-pw-c1',
        timestamp: new Date('2024-11-15T10:30:00'),
        type: 'escalation',
        description: 'Tier 2 ส่งต่อมายัง Tier 3',
        user: 'ยุทธนา คณามิ่งมงคล',
        status: 'tier3'
      },
      {
        id: 'tl-pw-c2',
        timestamp: new Date('2024-11-15T11:00:00'),
        type: 'status_change',
        description: 'พุทธจักษ์ วงค์พันธ์ รับเคส',
        user: 'พุทธจักษ์ วงค์พันธ์',
        status: 'in_progress'
      },
      {
        id: 'tl-pw-c3',
        timestamp: new Date('2024-11-18T16:00:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและส่งกลับ T1 เพื่อปิด',
        user: 'พุทธจักษ์ วงค์พันธ์',
        status: 'pending_closure'
      },
      {
        id: 'tl-pw-c4',
        timestamp: new Date('2024-11-18T17:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'วรรณภา แซ่ด่าง',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-010 (วีระกร เยือกเย็น - Tier3) ====================
  {
    id: 'wirakorn-inprog-1',
    ticketNumber: 'CDGS-2024-WY101',
    title: 'Performance Tuning สำหรับ Database Cluster #performance',
    description: 'ปรับแต่งประสิทธิภาพของ Database Cluster เพื่อรองรับ traffic ที่เพิ่มขึ้น',
    status: 'in_progress',
    type: 'service_request',
    channel: 'email',
    priority: 'high',
    category: 'Data & Database',
    customerName: 'ทีม DBA',
    customerEmail: 'dba@example.com',
    customerPhone: '+66-83-333-3333',
    assignedTo: 'user-010',
    assignedBy: 'user-007', // Prakasit Prakongpetch (Tier2+3) ส่งต่อมา
    assignedAt: new Date('2024-11-24T09:00:00'),
    previousAssignee: 'user-007',
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-24T08:00:00'),
    updatedAt: new Date('2024-11-27T10:00:00'),
    dueDate: new Date('2024-11-30T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-wy1',
        timestamp: new Date('2024-11-24T08:30:00'),
        type: 'escalation',
        description: 'Tier 2 ส่งต่อมายัง Tier 3',
        user: 'ประกาศิต ประคองเพ็ชร',
        status: 'tier3'
      },
      {
        id: 'tl-wy2',
        timestamp: new Date('2024-11-24T09:00:00'),
        type: 'status_change',
        description: 'วีระกร เยือกเย็น รับเคสและเริ่มดำเนินการ',
        user: 'วีระกร เยือกเย็น',
        status: 'in_progress'
      }
    ],
    comments: []
  },
  {
    id: 'wirakorn-closed-1',
    ticketNumber: 'CDGS-2024-WY301',
    title: 'Security Audit เสร็จสิ้น #แก้ไขแล้ว',
    description: 'ตรวจสอบช่องโหว่ด้านความปลอดภัยและแก้ไข - เสร็จสมบูรณ์',
    status: 'closed',
    type: 'service_request',
    channel: 'web',
    priority: 'critical',
    category: 'Security & Compliance',
    customerName: 'ฝ่ายรักษาความปลอดภัย',
    customerEmail: 'security@example.com',
    customerPhone: '+66-83-444-4444',
    assignedTo: 'user-010',
    assignedBy: 'user-006', // Yuttana Knamingmongkol (Tier2) ส่งต่อมา
    assignedAt: new Date('2024-11-14T10:00:00'),
    previousAssignee: 'user-006',
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-14T09:00:00'),
    updatedAt: new Date('2024-11-17T18:00:00'),
    closedAt: new Date('2024-11-17T18:00:00'),
    closedBy: 'user-003', // Wannapa Sae-dang (user-003) ปิดเคส
    dueDate: new Date('2024-11-17T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-wy-c1',
        timestamp: new Date('2024-11-14T09:30:00'),
        type: 'escalation',
        description: 'Tier 2 ส่งต่อมายัง Tier 3',
        user: 'ยุทธนา คณามิ่งมงคล',
        status: 'tier3'
      },
      {
        id: 'tl-wy-c2',
        timestamp: new Date('2024-11-14T10:00:00'),
        type: 'status_change',
        description: 'วีระกร เยือกเย็น รับเคส',
        user: 'วีระกร เยือกเย็น',
        status: 'in_progress'
      },
      {
        id: 'tl-wy-c3',
        timestamp: new Date('2024-11-17T17:00:00'),
        type: 'status_change',
        description: 'แก้ไขเสร็จสิ้นและส่งกลับ T1 เพื่อปิด',
        user: 'วีระกร เยือกเย็น',
        status: 'pending_closure'
      },
      {
        id: 'tl-wy-c4',
        timestamp: new Date('2024-11-17T18:00:00'),
        type: 'status_change',
        description: 'ปิดเคสเรียบร้อย',
        user: 'วรรณภา แซ่ด่าง',
        status: 'closed'
      }
    ],
    comments: []
  },

  // ==================== user-012 (อภิญญา ทองชัย - Tier1) ====================
  {
    id: 'apinya-inprog-1',
    ticketNumber: 'CDGS-2024-AT101',
    title: 'Keyboard ไม่ทำงาน #hardware',
    description: 'Keyboard พิมพ์ไม่ได้บางปุ่ม ต้องการตรวจสอบและแก้ไข',
    status: 'in_progress',
    type: 'incident',
    channel: 'phone',
    priority: 'medium',
    category: 'Hardware',
    customerName: 'ฝ่ายบัญชี',
    customerEmail: 'acc-dept@example.com',
    customerPhone: '+66-82-111-1111',
    assignedTo: 'user-012',
    projectId: 'proj-004',
    projectCode: 'D24-6053',
    projectName: 'กรมการแพทย์แผนไทยและการแพทย์ทดแทน',
    projectShortName: 'DTAM',
    createdAt: new Date('2024-11-27T08:30:00'),
    updatedAt: new Date('2024-11-27T09:00:00'),
    dueDate: new Date('2024-11-27T14:30:00'),
    attachments: [],
    timeline: [
      {
        id: 'tl-at1',
        timestamp: new Date('2024-11-27T09:00:00'),
        type: 'status_change',
        description: 'อภิญญา ทองชัย รับเคสและเริ่มดำเนินการ',
        user: 'อภิญญา ทองชัย',
        status: 'in_progress'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด #1 (resolved) - อภิญญา
  {
    id: 'apinya-resolved-1',
    ticketNumber: 'CDGS-2024-AT201',
    title: 'Email ไม่สามารถส่งได้ #email #resolved',
    description: 'ผู้ใช้ไม่สามารถส่ง Email ออกจาก Outlook ได้ ได้รับแจ้งเตือน "Cannot connect to server"',
    status: 'resolved',
    type: 'incident',
    channel: 'phone',
    priority: 'high',
    category: 'Email',
    customerName: 'สุรชัย วงศ์สวัสดิ์',
    customerEmail: 'surachai.w@example.com',
    customerPhone: '+66-82-222-2222',
    assignedTo: 'user-012', // อภิญญา ทองชัย
    projectId: 'proj-001',
    projectCode: 'D24-6061',
    projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
    projectShortName: 'MRTA',
    createdAt: new Date('2024-11-26T14:00:00'),
    updatedAt: new Date('2024-11-27T10:30:00'),
    resolvedAt: new Date('2024-11-27T10:30:00'),
    dueDate: new Date('2024-11-26T18:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'apinya-r1-tl-1',
        timestamp: new Date('2024-11-26T14:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'apinya-r1-tl-2',
        timestamp: new Date('2024-11-26T14:15:00'),
        type: 'assignment',
        description: 'รับเคสโดย อภิญญา ทองชัย',
        user: 'อภิญญา ทองชัย',
        status: 'in_progress'
      },
      {
        id: 'apinya-r1-tl-3',
        timestamp: new Date('2024-11-27T10:30:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - ตั้งค่า SMTP ใหม่และทดสอบส่ง Email สำเร็จ',
        user: 'อภิญญา ทองชัย',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด #2 (pending_closure) - อภิญญา
  {
    id: 'apinya-pending-closure-1',
    ticketNumber: 'CDGS-2024-AT202',
    title: 'Printer ไม่พิมพ์ออกมา #printer #pending_closure',
    description: 'Printer ไม่พิมพ์เอกสารออกมา แสดง Error "Paper Jam" แต่ไม่มีกระดาษติด',
    status: 'pending_closure',
    type: 'incident',
    channel: 'line',
    priority: 'medium',
    category: 'Hardware',
    customerName: 'วิไลวรรณ สมบูรณ์',
    customerEmail: 'wilaiwan.s@example.com',
    customerPhone: '+66-82-333-3333',
    assignedTo: 'user-012', // อภิญญา ทองชัย
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-25T09:00:00'),
    updatedAt: new Date('2024-11-26T16:45:00'),
    resolvedAt: new Date('2024-11-26T16:45:00'),
    dueDate: new Date('2024-11-25T15:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'apinya-pc1-tl-1',
        timestamp: new Date('2024-11-25T09:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'apinya-pc1-tl-2',
        timestamp: new Date('2024-11-25T09:30:00'),
        type: 'assignment',
        description: 'รับเคสโดย อภิญญา ทองชัย',
        user: 'อภิญญา ทองชัย',
        status: 'in_progress'
      },
      {
        id: 'apinya-pc1-tl-3',
        timestamp: new Date('2024-11-26T16:45:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - ทำความสะอาด Sensor และรีเซ็ต Printer แล้ว ทดสอบพิมพ์สำเร็จ',
        user: 'อภิญญา ทองชัย',
        status: 'pending_closure'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด #3 (resolved) - อภิญญา
  {
    id: 'apinya-resolved-2',
    ticketNumber: 'CDGS-2024-AT203',
    title: 'VPN ไม่สามารถเชื่อมต่อได้ #vpn #network',
    description: 'พนักงานทำงาน WFH ไม่สามารถเชื่อมต่อ VPN เข้าระบบภายในได้',
    status: 'resolved',
    type: 'incident',
    channel: 'email',
    priority: 'high',
    category: 'Network',
    customerName: 'ณัฐพล แสงสว่าง',
    customerEmail: 'nattaphon.s@example.com',
    customerPhone: '+66-82-444-4444',
    assignedTo: 'user-012', // อภิญญา ทองชัย
    projectId: 'proj-003',
    projectCode: 'D24-6083',
    projectName: 'กรมการปกครอง',
    projectShortName: 'DRT',
    createdAt: new Date('2024-11-27T07:00:00'),
    updatedAt: new Date('2024-11-27T11:15:00'),
    resolvedAt: new Date('2024-11-27T11:15:00'),
    dueDate: new Date('2024-11-27T13:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'apinya-r2-tl-1',
        timestamp: new Date('2024-11-27T07:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'apinya-r2-tl-2',
        timestamp: new Date('2024-11-27T08:00:00'),
        type: 'assignment',
        description: 'รับเคสโดย อภิญญา ทองชัย',
        user: 'อภิญญา ทองชัย',
        status: 'in_progress'
      },
      {
        id: 'apinya-r2-tl-3',
        timestamp: new Date('2024-11-27T11:15:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - Reset VPN Client และอัพเดท Certificate ใหม่ ทดสอบเชื่อมต่อสำเร็จ',
        user: 'อภิญญา ทองชัย',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (resolved) - สาริน (user-002)
  {
    id: 'sarin-resolved-1',
    ticketNumber: 'CDGS-2024-SC401',
    title: 'ตั้งค่า Email Signature ใหม่ #email #resolved',
    description: 'ตั้งค่า Email Signature มาตรฐานให้กับพนักงานใหม่ 8 คน ตาม Corporate Branding Guidelines รวมถึงการเพิ่มโลโก้และข้อมูลติดต่ออย่างครบถ้วน',
    status: 'resolved',
    type: 'service_request',
    channel: 'email',
    priority: 'low',
    category: 'Email',
    customerName: 'ฝ่ายทรัพยากรบุคคล',
    customerEmail: 'hr@mot.go.th',
    customerPhone: '+66-85-300-3001',
    assignedTo: 'user-002',
    assignedBy: 'user-002',
    assignedAt: new Date('2024-11-26T11:00:00'),
    projectId: 'proj-005',
    projectCode: 'D24-6067',
    projectName: 'กระทรวงคมนาคม',
    projectShortName: 'MOT',
    createdAt: new Date('2024-11-26T11:00:00'),
    updatedAt: new Date('2024-11-27T12:45:00'),
    resolvedAt: new Date('2024-11-27T12:45:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'sarin-r1-tl-1',
        timestamp: new Date('2024-11-26T11:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'sarin-r1-tl-2',
        timestamp: new Date('2024-11-26T11:20:00'),
        type: 'assignment',
        description: 'รับเคสโดย สาริน ช่อพะยอม',
        user: 'สาริน ช่อพะยอม',
        status: 'in_progress'
      },
      {
        id: 'sarin-r1-tl-3',
        timestamp: new Date('2024-11-27T12:45:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - ตั้งค่า Email Signature ครบทั้ง 8 คน พร้อมทดสอบการแสดงผลสำเร็จ',
        user: 'สาริน ช่อพะยอม',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (pending_closure) - สาริน (user-002)
  {
    id: 'sarin-pending-1',
    ticketNumber: 'CDGS-2024-SC402',
    title: 'Backup ข้อมูล Server ก่อนอัพเกรด #backup #pending_closure',
    description: 'Backup ข้อมูลจาก Application Server ก่อนทำการอัพเกรด OS เป็น version ใหม่ รวมข้อมูลทั้งหมด 800 GB พร้อมยืนยันความสมบูรณ์ของข้อมูล',
    status: 'pending_closure',
    type: 'service_request',
    channel: 'web',
    priority: 'high',
    category: 'Infrastructure',
    customerName: 'ฝ่ายระบบสารสนเทศ',
    customerEmail: 'it-system@mot.go.th',
    customerPhone: '+66-85-300-3002',
    assignedTo: 'user-002',
    assignedBy: 'user-002',
    assignedAt: new Date('2024-11-25T14:00:00'),
    projectId: 'proj-005',
    projectCode: 'D24-6067',
    projectName: 'กระทรวงคมนาคม',
    projectShortName: 'MOT',
    createdAt: new Date('2024-11-25T14:00:00'),
    updatedAt: new Date('2024-11-27T17:30:00'),
    resolvedAt: new Date('2024-11-27T17:30:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'sarin-pc1-tl-1',
        timestamp: new Date('2024-11-25T14:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'sarin-pc1-tl-2',
        timestamp: new Date('2024-11-25T14:30:00'),
        type: 'assignment',
        description: 'รับเคสโดย สาริน ช่อพะยอม',
        user: 'สาริน ช่อพะยอม',
        status: 'in_progress'
      },
      {
        id: 'sarin-pc1-tl-3',
        timestamp: new Date('2024-11-27T17:30:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - Backup เสร็จสมบูรณ์ ยืนยันความสมบูรณ์ของข้อมูลด้วย Checksum สำเร็จ',
        user: 'สาริน ช่อพะยอม',
        status: 'pending_closure'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (resolved) - เขมิกา (user-004)
  {
    id: 'khemika-resolved-1',
    ticketNumber: 'CDGS-2024-KS401',
    title: 'แก้ไขปัญหา Slow Network Performance #network #resolved',
    description: 'Network ช้าในช่วงเช้า พบว่ามี Broadcast Storm จาก Switch ห้อง 5 ต้องแก้ไขเพื่อให้ Network กลับมาทำงานปกติ',
    status: 'resolved',
    type: 'incident',
    channel: 'phone',
    priority: 'high',
    category: 'Network & Connectivity',
    customerName: 'ฝ่าย IT Operations',
    customerEmail: 'it-ops@dtam.go.th',
    customerPhone: '+66-85-400-4001',
    assignedTo: 'user-004',
    assignedBy: 'user-004',
    assignedAt: new Date('2024-11-26T08:30:00'),
    projectId: 'proj-004',
    projectCode: 'D24-6053',
    projectName: 'กรมการแพทย์แผนไทยและการแพทย์ทดแทน',
    projectShortName: 'DTAM',
    createdAt: new Date('2024-11-26T08:30:00'),
    updatedAt: new Date('2024-11-27T14:15:00'),
    resolvedAt: new Date('2024-11-27T14:15:00'),
    dueDate: new Date('2024-11-27T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'khemika-r1-tl-1',
        timestamp: new Date('2024-11-26T08:30:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'khemika-r1-tl-2',
        timestamp: new Date('2024-11-26T08:45:00'),
        type: 'assignment',
        description: 'รับเคสโดย เขมิกา แซ่ตั้ง',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'in_progress'
      },
      {
        id: 'khemika-r1-tl-3',
        timestamp: new Date('2024-11-27T14:15:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - แก้ไข Broadcast Storm โดยการ restart Switch และตั้งค่า Port Security ใหม่ ทดสอบ Network Speed สำเร็จ',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (pending_closure) - เขมิกา (user-004)
  {
    id: 'khemika-pending-1',
    ticketNumber: 'CDGS-2024-KS402',
    title: 'ติดตั้ง UPS ใหม่ #hardware #pending_closure',
    description: 'ติดตั้ง UPS ใหม่ขนาด 3 KVA สำหรับ Server Room พร้อมตั้งค่า Auto Shutdown และทดสอบการทำงานเมื่อไฟดับ',
    status: 'pending_closure',
    type: 'service_request',
    channel: 'line',
    priority: 'high',
    category: 'Hardware',
    customerName: 'ฝ่าย Data Center',
    customerEmail: 'datacenter@dtam.go.th',
    customerPhone: '+66-85-400-4002',
    assignedTo: 'user-004',
    assignedBy: 'user-004',
    assignedAt: new Date('2024-11-25T13:00:00'),
    projectId: 'proj-004',
    projectCode: 'D24-6053',
    projectName: 'กรมการแพทย์แผนไทยและการแพทย์ทดแทน',
    projectShortName: 'DTAM',
    createdAt: new Date('2024-11-25T13:00:00'),
    updatedAt: new Date('2024-11-27T16:45:00'),
    resolvedAt: new Date('2024-11-27T16:45:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'khemika-pc1-tl-1',
        timestamp: new Date('2024-11-25T13:00:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'khemika-pc1-tl-2',
        timestamp: new Date('2024-11-25T13:30:00'),
        type: 'assignment',
        description: 'รับเคสโดย เขมิกา แซ่ตั้ง',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'in_progress'
      },
      {
        id: 'khemika-pc1-tl-3',
        timestamp: new Date('2024-11-27T16:45:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - ติดตั้ง UPS และตั้งค่า Auto Shutdown เรียบร้อย ทดสอบไฟดับสำเร็จ',
        user: 'เขมิกา แซ่ตั้ง',
        status: 'pending_closure'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (resolved) - ธัญญาพร (user-005)
  {
    id: 'thanyaporn-resolved-1',
    ticketNumber: 'CDGS-2024-TT401',
    title: 'ติดตั้ง Antivirus ให้เครื่องใหม่ #security #resolved',
    description: 'ติดตั้งและ activate Antivirus สำหรับเครื่องคอมพิวเตอร์ใหม่ 6 เครื่อง พร้อมอัพเดท Virus Definition และทดสอบ Scan',
    status: 'resolved',
    type: 'service_request',
    channel: 'email',
    priority: 'medium',
    category: 'Security & Compliance',
    customerName: 'ฝ่ายบริหารงานทั่วไป',
    customerEmail: 'admin@dot.go.th',
    customerPhone: '+66-85-500-5001',
    assignedTo: 'user-005',
    assignedBy: 'user-005',
    assignedAt: new Date('2024-11-26T10:30:00'),
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-26T10:30:00'),
    updatedAt: new Date('2024-11-27T15:00:00'),
    resolvedAt: new Date('2024-11-27T15:00:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'thanyaporn-r1-tl-1',
        timestamp: new Date('2024-11-26T10:30:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'thanyaporn-r1-tl-2',
        timestamp: new Date('2024-11-26T11:00:00'),
        type: 'assignment',
        description: 'รับเคสโดย ธัญญาพร ทองแก้ว',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'in_progress'
      },
      {
        id: 'thanyaporn-r1-tl-3',
        timestamp: new Date('2024-11-27T15:00:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - ติดตั้ง Antivirus ครบทั้ง 6 เครื่อง อัพเดท Definition และทดสอบ Scan สำเร็จ',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'resolved'
      }
    ],
    comments: []
  },
  
  // ✅ เคสรอปิด (pending_closure) - ธัญญาพร (user-005)
  {
    id: 'thanyaporn-pending-1',
    ticketNumber: 'CDGS-2024-TT402',
    title: 'ตั้งค่า VLAN ใหม่สำหรับฝ่าย Finance #network #pending_closure',
    description: 'สร้างและตั้งค่า VLAN ใหม่สำหรับฝ่ายการเงิน เพื่อแยก Network Segment ออกจากส่วนอื่น พร้อมตั้งค่า Firewall Rules และทดสอบการเชื่อมต่อ',
    status: 'pending_closure',
    type: 'service_request',
    channel: 'web',
    priority: 'high',
    category: 'Network & Connectivity',
    customerName: 'ฝ่ายการเงิน',
    customerEmail: 'finance@dot.go.th',
    customerPhone: '+66-85-500-5002',
    assignedTo: 'user-005',
    assignedBy: 'user-005',
    assignedAt: new Date('2024-11-25T09:30:00'),
    projectId: 'proj-002',
    projectCode: 'D24-6006',
    projectName: 'กรมการขนส่งทางบก',
    projectShortName: 'DOT',
    createdAt: new Date('2024-11-25T09:30:00'),
    updatedAt: new Date('2024-11-27T17:00:00'),
    resolvedAt: new Date('2024-11-27T17:00:00'),
    dueDate: new Date('2024-11-28T17:00:00'),
    attachments: [],
    timeline: [
      {
        id: 'thanyaporn-pc1-tl-1',
        timestamp: new Date('2024-11-25T09:30:00'),
        type: 'status_change',
        description: 'เคสถูกสร้าง',
        user: 'System',
        status: 'new'
      },
      {
        id: 'thanyaporn-pc1-tl-2',
        timestamp: new Date('2024-11-25T10:00:00'),
        type: 'assignment',
        description: 'รับเคสโดย ธัญญาพร ทองแก้ว',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'in_progress'
      },
      {
        id: 'thanyaporn-pc1-tl-3',
        timestamp: new Date('2024-11-27T17:00:00'),
        type: 'status_change',
        description: 'แก้ไขปัญหาเรียบร้อย - สร้าง VLAN และตั้งค่า Firewall Rules เรียบร้อย ทดสอบการเชื่อมต่อสำเร็จ',
        user: 'ธัญญาพร ทองแก้ว',
        status: 'pending_closure'
      }
    ],
    comments: []
  }
];