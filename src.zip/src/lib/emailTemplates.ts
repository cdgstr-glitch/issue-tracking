/**
 * Email Templates - ระบบ Email สำหรับแจ้งเตือน Customer
 * 
 * Template ทั้งหมด:
 * 1. Welcome Email - หลังลงทะเบียน
 * 2. Ticket Created - หลังแจ้งเคสสำเร็จ
 * 3. Ticket Assigned - หลัง Tier1 รับเคส
 * 4. Comment Notification - มีความคิดเห็นใหม่
 * 5. Magic Link - ส่งลิงก์เข้าสู่ระบบ
 * 6. Ticket Status Changed - สถานะเคสเปลี่ยน
 * 7. Ticket Resolved - เคสถูกแก้ไขแล้ว
 * 8. Ticket Closed - เคสถูกปิดแล้ว
 */

import { Ticket, CustomerUser } from '../types';
import { generateMagicLinkURL } from './magicLink';
import { formatSLAHours, formatSLADueDate } from './slaCalculator';

/**
 * Email Configuration
 */
const EMAIL_CONFIG = {
  fromName: 'CDGS Application Support Center',
  fromEmail: 'support@cdgs.co.th',
  replyTo: 'noreply@cdgs.co.th',
  baseUrl: 'https://support.cdgs.co.th', // ในระบบจริงจะอ่านจาก env variable
};

/**
 * Email Footer Template (ใช้ร่วมกันทุก Email)
 */
function getEmailFooter(): string {
  return `
    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 12px;">
      <p>ส่งจาก CDGS Issue Tracking Platform</p>
      <p>หากมีคำถาม กรุณาตอบกลับอีเมลนี้</p>
      <p>© ${new Date().getFullYear()} CDGS. All rights reserved.</p>
    </div>
  `;
}

/**
 * Email Header Template (ใช้ร่วมกันทุก Email)
 */
function getEmailHeader(customerName: string): string {
  return `
    <div style="font-family: 'Anuphan', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #1f2937; font-size: 24px; margin: 0;">Application Support Center</h1>
      </div>
      <div style="background: #f9fafb; padding: 20px; border-radius: 8px;">
        <p style="color: #374151; font-size: 16px; margin: 0;">สวัสดี คุณ${customerName}</p>
      </div>
  `;
}

/**
 * Button Component
 */
function getButton(text: string, url: string, color: string = '#2563eb'): string {
  return `
    <div style="text-align: center; margin: 30px 0;">
      <a href="${url}" style="display: inline-block; padding: 12px 24px; background-color: ${color}; color: white; text-decoration: none; border-radius: 6px; font-weight: 600;">
        ${text}
      </a>
    </div>
  `;
}

/**
 * Info Box Component
 */
function getInfoBox(label: string, value: string): string {
  return `
    <div style="margin: 10px 0;">
      <span style="color: #6b7280; font-size: 14px;">${label}:</span>
      <span style="color: #1f2937; font-weight: 600; margin-left: 8px;">${value}</span>
    </div>
  `;
}

// ============================================================================
// EMAIL TEMPLATES
// ============================================================================

/**
 * 1. Welcome Email - ส่งหลังลงทะเบียนสำเร็จ
 */
export function getWelcomeEmail(customer: CustomerUser): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = 'ยินดีต้อนรับสู่ CDGS Application Support Center';
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <p style="color: #374151; line-height: 1.6;">
          ขอบคุณที่ลงทะเบียนกับ <strong>CDGS Application Support Center</strong>
        </p>
        <p style="color: #374151; line-height: 1.6;">
          คุณสามารถติดตามเคสของคุณได้ทุกเมื่อผ่านอีเมลนี้ 
          หรือเข้าสู่ระบบผ่านลิงก์ด้านล่าง
        </p>
        ${getButton('เข้าสู่ระบบ', `${EMAIL_CONFIG.baseUrl}/login`)}
        <div style="background: #eff6ff; padding: 15px; border-radius: 6px; border-left: 4px solid #2563eb; margin-top: 20px;">
          <p style="color: #1e40af; margin: 0; font-size: 14px;">
            💡 <strong>ทราบหรือไม่?</strong> คุณไม่ต้องจำรหัสผ่าน! 
            เราจะส่ง Magic Link ทางอีเมลทุกครั้งที่คุณต้องการเข้าสู่ระบบ
          </p>
        </div>
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

ขอบคุณที่ลงทะเบียนกับ CDGS Application Support Center

คุณสามารถติดตามเคสของคุณได้ทุกเมื่อผ่านอีเมลนี้
หรือเข้าสู่ระบบที่: ${EMAIL_CONFIG.baseUrl}/login

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 2. Ticket Created Email - ส่งหลังแจ้งเคสสำเร็จ
 */
export function getTicketCreatedEmail(
  customer: CustomerUser,
  ticket: Ticket,
  magicLinkToken: string
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = `[CDGS] เคส #${ticket.ticketNumber} ถูกสร้างแล้ว`;
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <h2 style="color: #059669; font-size: 20px; margin-bottom: 15px;">✅ เคสของคุณถูกสร้างเรียบร้อยแล้ว</h2>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
          ${getInfoBox('หมายเลขเคส', ticket.ticketNumber)}
          ${getInfoBox('หัวเรื่อง', ticket.title)}
          ${getInfoBox('สถานะ', 'รอดำเนินการ')}
        </div>
        
        <p style="color: #374151; line-height: 1.6;">
          เราจะแจ้งให้คุณทราบทันทีเมื่อมีการอัพเดท
        </p>
        
        ${getButton('ดูรายละเอียดเคส', magicLinkUrl)}
        
        <div style="background: #fef3c7; padding: 15px; border-radius: 6px; border-left: 4px solid #f59e0b; margin-top: 20px;">
          <p style="color: #92400e; margin: 0; font-size: 14px;">
            📧 <strong>เก็บอีเมลนี้ไว้!</strong> คุณสามารถกลับมาดูเคสได้ทุกเมื่อผ่านลิงก์ด้านบน
          </p>
        </div>
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

✅ เคสของคุณถูกสร้างเรียบร้อยแล้ว

หมายเลขเคส: ${ticket.ticketNumber}
หัวเรื่อง: ${ticket.title}
สถานะ: รอดำเนินการ

เราจะแจ้งให้คุณทราบทันทีเมื่อมีการอัพเดท

ดูรายละเอียดเคส: ${magicLinkUrl}

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 3. Ticket Assigned Email - ส่งหลัง Tier1 รับเคส
 */
export function getTicketAssignedEmail(
  customer: CustomerUser,
  ticket: Ticket,
  assigneeName: string,
  magicLinkToken: string
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = `[CDGS] เคส #${ticket.ticketNumber} ได้รับการมอบหมายแล้ว`;
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  const slaText = ticket.slaHours ? formatSLAHours(ticket.slaHours) : 'ไม่ระบุ';
  const dueDateText = ticket.slaDueDate ? formatSLADueDate(ticket.slaDueDate) : 'ไม่ระบุ';
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <h2 style="color: #2563eb; font-size: 20px; margin-bottom: 15px;">👤 เคสของคุณได้รับการมอบหมายแล้ว</h2>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
          ${getInfoBox('หมายเลขเคส', ticket.ticketNumber)}
          ${getInfoBox('ผู้รับผิดชอบ', assigneeName)}
          ${ticket.projectName ? getInfoBox('โครงการ', ticket.projectName) : ''}
          ${getInfoBox('SLA', slaText)}
          ${getInfoBox('ครั้งกำหนด', dueDateText)}
        </div>
        
        <p style="color: #374151; line-height: 1.6;">
          ทีมงานของเรากำลังดำเนินการแก้ไขปัญหาของคุณ
        </p>
        
        ${getButton('ดูรายละเอียดเคส', magicLinkUrl)}
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

👤 เคสของคุณได้รับการมอบหมายแล้ว

หมายเลขเคส: ${ticket.ticketNumber}
ผู้รับผิดชอบ: ${assigneeName}
${ticket.projectName ? `โครงการ: ${ticket.projectName}` : ''}
SLA: ${slaText}
ครบกำหนด: ${dueDateText}

ทีมงานของเรากำลังดำเนินการแก้ไขปัญหาของคุณ

ดูรายละเอียดเคส: ${magicLinkUrl}

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 4. Comment Notification Email - มีความคิดเห็นใหม่
 */
export function getCommentNotificationEmail(
  customer: CustomerUser,
  ticket: Ticket,
  commentAuthor: string,
  commentContent: string,
  magicLinkToken: string
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = `[CDGS] มีความคิดเห็นใหม่ในเคส #${ticket.ticketNumber}`;
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  // ตัดข้อความถ้ายาวเกิน 200 ตัวอักษร
  const truncatedContent = commentContent.length > 200 
    ? commentContent.substring(0, 200) + '...' 
    : commentContent;
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <h2 style="color: #7c3aed; font-size: 20px; margin-bottom: 15px;">💬 ความคิดเห็นใหม่</h2>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
          ${getInfoBox('เคส', ticket.ticketNumber)}
          ${getInfoBox('จาก', commentAuthor)}
        </div>
        
        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; border-left: 4px solid #7c3aed; margin: 20px 0;">
          <p style="color: #374151; line-height: 1.6; margin: 0; white-space: pre-wrap;">${truncatedContent}</p>
        </div>
        
        ${getButton('ดูและตอบกลับ', magicLinkUrl, '#7c3aed')}
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

💬 ความคิดเห็นใหม่จาก ${commentAuthor}:

"${truncatedContent}"

เคส: ${ticket.ticketNumber}

ดูและตอบกลับ: ${magicLinkUrl}

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 5. Magic Link Email - ส่งลิงก์เข้าสู่ระบบ
 */
export function getMagicLinkEmail(
  customer: CustomerUser,
  magicLinkToken: string,
  expiryMinutes: number = 30
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = 'เข้าสู่ระบบ CDGS Support';
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <p style="color: #374151; line-height: 1.6;">
          คุณได้ขอลิงก์เข้าสู่ระบบ
        </p>
        
        ${getButton('เข้าสู่ระบบ', magicLinkUrl)}
        
        <div style="background: #f9fafb; padding: 15px; border-radius: 6px; margin: 20px 0;">
          <p style="color: #6b7280; font-size: 14px; margin: 0;">
            หรือคัดลอกลิงก์:
          </p>
          <p style="color: #2563eb; font-size: 14px; margin: 5px 0; word-break: break-all;">
            ${magicLinkUrl}
          </p>
        </div>
        
        <div style="background: #fef2f2; padding: 15px; border-radius: 6px; border-left: 4px solid #ef4444; margin-top: 20px;">
          <p style="color: #991b1b; margin: 0; font-size: 14px;">
            ⚠️ <strong>ลิงก์นี้จะหมดอายุใน ${expiryMinutes} นาที</strong>
          </p>
        </div>
        
        <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
          หากคุณไม่ได้ขอลิงก์นี้ กรุณาละเว้นอีเมลนี้
        </p>
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

คุณได้ขอลิงก์เข้าสู่ระบบ

เข้าสู่ระบบ: ${magicLinkUrl}

⚠️ ลิงก์นี้จะหมดอายุใน ${expiryMinutes} นาที

หากคุณไม่ได้ขอลิงก์นี้ กรุณาละเว้นอีเมลนี้

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 6. Ticket Status Changed Email - สถานะเคสเปลี่ยน
 */
export function getTicketStatusChangedEmail(
  customer: CustomerUser,
  ticket: Ticket,
  oldStatus: string,
  newStatus: string,
  magicLinkToken: string
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = `[CDGS] สถานะเคส #${ticket.ticketNumber} เปลี่ยนแปลง`;
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  const statusLabelMap: Record<string, string> = {
    new: 'รอดำเนินการ',
    in_progress: 'กำลังดำเนินการ',
    waiting: 'รอข้อมูลเพิ่มเติม',
    resolved: 'แก้ไขแล้ว',
    closed: 'ปิดแล้ว',
  };
  
  const oldStatusLabel = statusLabelMap[oldStatus] || oldStatus;
  const newStatusLabel = statusLabelMap[newStatus] || newStatus;
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <h2 style="color: #0891b2; font-size: 20px; margin-bottom: 15px;">🔄 สถานะเคสเปลี่ยนแปลง</h2>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
          ${getInfoBox('หมายเลขเคส', ticket.ticketNumber)}
          ${getInfoBox('หัวเรื่อง', ticket.title)}
          ${getInfoBox('สถานะเดิม', oldStatusLabel)}
          ${getInfoBox('สถานะใหม่', `<strong>${newStatusLabel}</strong>`)}
        </div>
        
        ${getButton('ดูรายละเอียดเคส', magicLinkUrl)}
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

🔄 สถานะเคสเปลี่ยนแปลง

หมายเลขเคส: ${ticket.ticketNumber}
สถานะเดิม: ${oldStatusLabel}
สถานะใหม่: ${newStatusLabel}

ดูรายละเอียดเคส: ${magicLinkUrl}

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 7. Ticket Resolved Email - เคสถูกแก้ไขแล้ว
 */
export function getTicketResolvedEmail(
  customer: CustomerUser,
  ticket: Ticket,
  resolverName: string,
  magicLinkToken: string
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = `[CDGS] เคส #${ticket.ticketNumber} ถูกแก้ไขแล้ว`;
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <h2 style="color: #059669; font-size: 20px; margin-bottom: 15px;">✅ เคสของคุณถูกแก้ไขแล้ว</h2>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
          ${getInfoBox('หมายเลขเคส', ticket.ticketNumber)}
          ${getInfoBox('แก้ไขโดย', resolverName)}
          ${ticket.solution ? getInfoBox('วิธีแก้ไข', ticket.solution) : ''}
        </div>
        
        <p style="color: #374151; line-height: 1.6;">
          กรุณาตรวจสอบว่าปัญหาของคุณได้รับการแก้ไขแล้ว
          หากยังไม่หาย กรุณาแจ้งให้เราทราบ
        </p>
        
        ${getButton('ตรวจสอบและปิดเคส', magicLinkUrl, '#059669')}
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

✅ เคสของคุณถูกแก้ไขแล้ว

หมายเลขเคส: ${ticket.ticketNumber}
แก้ไขโดย: ${resolverName}
${ticket.solution ? `วิธีแก้ไข: ${ticket.solution}` : ''}

กรุณาตรวจสอบว่าปัญหาของคุณได้รับการแก้ไขแล้ว

ดูรายละเอียดเคส: ${magicLinkUrl}

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * 8. Ticket Closed Email - เคสถูกปิดแล้ว
 */
export function getTicketClosedEmail(
  customer: CustomerUser,
  ticket: Ticket,
  closerName: string,
  magicLinkToken: string
): {
  subject: string;
  html: string;
  text: string;
} {
  const subject = `[CDGS] เคส #${ticket.ticketNumber} ถูกปิดแล้ว`;
  const magicLinkUrl = generateMagicLinkURL(magicLinkToken, EMAIL_CONFIG.baseUrl);
  
  const html = `
    ${getEmailHeader(customer.fullName)}
      <div style="margin-top: 20px;">
        <h2 style="color: #6b7280; font-size: 20px; margin-bottom: 15px;">🎉 เคสของคุณถูกปิดแล้ว</h2>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0;">
          ${getInfoBox('หมายเลขเคส', ticket.ticketNumber)}
          ${getInfoBox('ปิดโดย', closerName)}
          ${ticket.closureNotes ? getInfoBox('หมายเหตุ', ticket.closureNotes) : ''}
        </div>
        
        <p style="color: #374151; line-height: 1.6;">
          ขอบคุณที่ใช้บริการ CDGS Application Support Center
        </p>
        
        <p style="color: #374151; line-height: 1.6;">
          หากมีปัญหาเพิ่มเติม สามารถแจ้งเคสใหม่ได้ทุกเมื่อ
        </p>
        
        ${getButton('ดูรายละเอียดเคส', magicLinkUrl)}
      </div>
      ${getEmailFooter()}
    </div>
  `;
  
  const text = `
สวัสดี คุณ${customer.fullName}

🎉 เคสของคุณถูกปิดแล้ว

หมายเลขเคส: ${ticket.ticketNumber}
ปิดโดย: ${closerName}

ขอบคุณที่ใช้บริการ CDGS Application Support Center

ดูรายละเอียดเคส: ${magicLinkUrl}

---
CDGS Issue Tracking Platform
  `.trim();
  
  return { subject, html, text };
}

/**
 * Mock Function: Send Email (ในระบบจริงจะใช้ SMTP/SendGrid/AWS SES)
 */
export function sendEmail(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  // Mock implementation - ในระบบจริงจะส่งจริงๆ
  console.log('📧 [Mock] Sending email to:', to);
  console.log('📧 [Mock] Subject:', subject);
  console.log('📧 [Mock] HTML length:', html.length, 'characters');
  console.log('📧 [Mock] Text length:', text.length, 'characters');
  
  // Simulate async operation
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        messageId: `mock-${Date.now()}`,
      });
    }, 100);
  });
}

/**
 * ✅ Helper Function: Send Magic Link Email
 * 
 * ส่ง Magic Link ไปอีเมลลูกค้า (ใช้ใน Registration และ Login)
 * 
 * @param email - อีเมลของลูกค้า
 * @param customerName - ชื่อลูกค้า
 * @param magicLinkUrl - Magic Link URL
 * @param expiryMinutes - จำนวนนาทีที่จะหมดอายุ (default: 30)
 */
export async function sendMagicLinkEmail(
  email: string,
  customerName: string,
  magicLinkUrl: string,
  expiryMinutes: number = 30
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  // สร้าง customer object แบบง่าย (ใช้แค่ชื่อ)
  const customer: CustomerUser = {
    id: 'temp',
    email,
    firstName: customerName.split(' ')[0] || customerName,
    lastName: customerName.split(' ').slice(1).join(' ') || '',
    fullName: customerName,
    createdAt: new Date(),
    isVerified: false,
  };
  
  // Extract token from URL
  const urlParams = new URLSearchParams(magicLinkUrl.split('?')[1]);
  const token = urlParams.get('token') || '';
  
  // สร้าง email template
  const emailData = getMagicLinkEmail(customer, token, expiryMinutes);
  
  // ส่ง email
  return sendEmail(email, emailData.subject, emailData.html, emailData.text);
}