/**
 * ✅ Test Script: ตรวจสอบว่า Mock Data ทั้งหมดมี createdByType และ createdByStaffName
 * 
 * Run: เรียกใช้ใน Console หรือ Test file
 */

import { db } from './mockDb/client';
import { getTicketCreatorDisplay, getTicketCreatorNote } from './ticketCreatorUtils';

const mockTickets = db.tickets.getAll();

export function testMockDataCreatorType() {
  console.log('🧪 Testing Mock Data - createdByType & createdByStaffName\n');
  
  // ============================================================
  // Test 1: ตรวจสอบว่าทุก Ticket มีฟิลด์ createdByType
  // ============================================================
  console.log('📋 Test 1: ตรวจสอบว่าทุก Ticket มีฟิลด์ createdByType');
  
  const ticketsWithoutCreatedByType = mockTickets.filter(t => !t.createdByType);
  
  if (ticketsWithoutCreatedByType.length === 0) {
    console.log('✅ PASS: ทุก Ticket มีฟิลด์ createdByType แล้ว');
  } else {
    console.log(`❌ FAIL: พบ ${ticketsWithoutCreatedByType.length} Tickets ที่ยังไม่มีฟิลด์ createdByType:`);
    ticketsWithoutCreatedByType.slice(0, 5).forEach(t => {
      console.log(`  - ${t.ticketNumber}: ${t.title.substring(0, 50)}...`);
    });
  }
  
  console.log('');
  
  // ============================================================
  // Test 2: ตรวจสอบว่า Web Tickets = customer_self
  // ============================================================
  console.log('📋 Test 2: ตรวจสอบว่า Web Tickets มี createdByType = "customer_self"');
  
  const webTickets = mockTickets.filter(t => t.channel === 'web');
  const invalidWebTickets = webTickets.filter(t => t.createdByType !== 'customer_self');
  
  console.log(`   จำนวน Web Tickets: ${webTickets.length}`);
  
  if (invalidWebTickets.length === 0) {
    console.log('✅ PASS: ทุก Web Tickets มี createdByType = "customer_self"');
  } else {
    console.log(`❌ FAIL: พบ ${invalidWebTickets.length} Web Tickets ที่มี createdByType ไม่ถูกต้อง:`);
    invalidWebTickets.slice(0, 5).forEach(t => {
      console.log(`  - ${t.ticketNumber}: createdByType = ${t.createdByType}`);
    });
  }
  
  console.log('');
  
  // ============================================================
  // Test 3: ตรวจสอบว่า Phone/Email/Line Tickets = staff_on_behalf
  // ============================================================
  console.log('📋 Test 3: ตรวจสอบว่า Phone/Email/Line Tickets มี createdByType = "staff_on_behalf"');
  
  const staffChannelTickets = mockTickets.filter(t => 
    ['phone', 'email', 'line'].includes(t.channel)
  );
  const invalidStaffTickets = staffChannelTickets.filter(t => 
    t.createdByType !== 'staff_on_behalf'
  );
  
  console.log(`   จำนวน Phone/Email/Line Tickets: ${staffChannelTickets.length}`);
  
  if (invalidStaffTickets.length === 0) {
    console.log('✅ PASS: ทุก Phone/Email/Line Tickets มี createdByType = "staff_on_behalf"');
  } else {
    console.log(`❌ FAIL: พบ ${invalidStaffTickets.length} Tickets ที่มี createdByType ไม่ถูกต้อง:`);
    invalidStaffTickets.slice(0, 5).forEach(t => {
      console.log(`  - ${t.ticketNumber}: channel = ${t.channel}, createdByType = ${t.createdByType}`);
    });
  }
  
  console.log('');
  
  // ============================================================
  // Test 4: ตรวจสอบว่า staff_on_behalf มี createdByStaffName
  // ============================================================
  console.log('📋 Test 4: ตรวจสอบว่า staff_on_behalf Tickets มี createdByStaffName');
  
  const staffOnBehalfTickets = mockTickets.filter(t => t.createdByType === 'staff_on_behalf');
  const missingStaffName = staffOnBehalfTickets.filter(t => !t.createdByStaffName);
  
  console.log(`   จำนวน staff_on_behalf Tickets: ${staffOnBehalfTickets.length}`);
  
  if (missingStaffName.length === 0) {
    console.log('✅ PASS: ทุก staff_on_behalf Tickets มี createdByStaffName');
  } else {
    console.log(`❌ FAIL: พบ ${missingStaffName.length} Tickets ที่ไม่มี createdByStaffName:`);
    missingStaffName.slice(0, 5).forEach(t => {
      console.log(`  - ${t.ticketNumber}: createdByStaffName = ${t.createdByStaffName}`);
    });
  }
  
  console.log('');
  
  // ============================================================
  // Test 5: ตรวจสอบว่า customer_self ไม่มี createdByStaffName
  // ============================================================
  console.log('📋 Test 5: ตรวจสอบว่า customer_self Tickets ไม่มี createdByStaffName');
  
  const customerSelfTickets = mockTickets.filter(t => t.createdByType === 'customer_self');
  const hasStaffName = customerSelfTickets.filter(t => t.createdByStaffName);
  
  console.log(`   จำนวน customer_self Tickets: ${customerSelfTickets.length}`);
  
  if (hasStaffName.length === 0) {
    console.log('✅ PASS: ทุก customer_self Tickets ไม่มี createdByStaffName (undefined)');
  } else {
    console.log(`❌ FAIL: พบ ${hasStaffName.length} customer_self Tickets ที่มี createdByStaffName:`);
    hasStaffName.slice(0, 5).forEach(t => {
      console.log(`  - ${t.ticketNumber}: createdByStaffName = ${t.createdByStaffName}`);
    });
  }
  
  console.log('');
  
  // ============================================================
  // Test 6: ทดสอบ Helper Functions
  // ============================================================
  console.log('📋 Test 6: ทดสอบ Helper Functions');
  
  // Test customer_self
  const customerTicket = mockTickets.find(t => t.createdByType === 'customer_self');
  if (customerTicket) {
    const display = getTicketCreatorDisplay(customerTicket);
    const note = getTicketCreatorNote(customerTicket);
    console.log(`   Customer Ticket (${customerTicket.ticketNumber}):`);
    console.log(`   - Display: ${display}`);
    console.log(`   - Note: ${note}`);
    console.log(display.includes('แจ้งเคสเอง') ? '   ✅ Display ถูกต้อง' : '   ❌ Display ผิด');
  }
  
  console.log('');
  
  // Test staff_on_behalf
  const staffTicket = mockTickets.find(t => t.createdByType === 'staff_on_behalf');
  if (staffTicket) {
    const display = getTicketCreatorDisplay(staffTicket);
    const note = getTicketCreatorNote(staffTicket);
    console.log(`   Staff Ticket (${staffTicket.ticketNumber}):`);
    console.log(`   - Display: ${display}`);
    console.log(`   - Note: ${note}`);
    console.log(display.includes('บันทึกโดย') ? '   ✅ Display ถูกต้อง' : '   ❌ Display ผิด');
  }
  
  console.log('');
  
  // ============================================================
  // สรุปผลการทดสอบ
  // ============================================================
  console.log('📊 สรุปผลการทดสอบ:');
  console.log(`   จำนวน Tickets ทั้งหมด: ${mockTickets.length}`);
  console.log(`   - Web (customer_self): ${customerSelfTickets.length}`);
  console.log(`   - Phone/Email/Line (staff_on_behalf): ${staffOnBehalfTickets.length}`);
  console.log('');
  
  const allPassed = 
    ticketsWithoutCreatedByType.length === 0 &&
    invalidWebTickets.length === 0 &&
    invalidStaffTickets.length === 0 &&
    missingStaffName.length === 0 &&
    hasStaffName.length === 0;
  
  if (allPassed) {
    console.log('🎉 ผลการทดสอบ: ✅ PASS ทุก Test Cases!');
  } else {
    console.log('⚠️  ผลการทดสอบ: ❌ FAIL - พบปัญหาบางส่วน');
  }
  
  return allPassed;
}

// ============================================================
// Export for use in other files
// ============================================================
export function getMockDataStatistics() {
  const stats = {
    total: mockTickets.length,
    customerSelf: mockTickets.filter(t => t.createdByType === 'customer_self').length,
    staffOnBehalf: mockTickets.filter(t => t.createdByType === 'staff_on_behalf').length,
    withoutCreatedByType: mockTickets.filter(t => !t.createdByType).length,
    byChannel: {
      web: mockTickets.filter(t => t.channel === 'web').length,
      phone: mockTickets.filter(t => t.channel === 'phone').length,
      email: mockTickets.filter(t => t.channel === 'email').length,
      line: mockTickets.filter(t => t.channel === 'line').length
    }
  };
  
  return stats;
}

// ============================================================
// Auto-run when imported in development
// ============================================================
if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
  // Run tests in browser console
  console.log('🔧 Development Mode: Running Mock Data Tests...\n');
  testMockDataCreatorType();
}
