import { Ticket, Stakeholder } from '../types';

/**
 * ตรวจสอบว่า user เป็น stakeholder ของเคสหรือไม่
 */
export function isStakeholder(ticket: Ticket, userId: string): boolean {
  if (!ticket.stakeholders) return false;
  return ticket.stakeholders.some(s => s.userId === userId);
}

/**
 * ตรวจสอบว่า user เป็นผู้สร้างเคสหรือไม่
 */
export function isCreator(ticket: Ticket, userId: string): boolean {
  return ticket.createdBy === userId;
}

/**
 * ตรวจสอบว่า user เป็น current owner ของเคสหรือไม่
 */
export function isCurrentOwner(ticket: Ticket, userId: string): boolean {
  return ticket.assignedTo === userId;
}

/**
 * ตรวจสอบว่า user เป็นผู้ส่งต่อเคส (escalator) หรือไม่
 */
export function isEscalator(ticket: Ticket, userId: string): boolean {
  if (!ticket.stakeholders) return false;
  return ticket.stakeholders.some(s => s.userId === userId && s.type === 'escalator');
}

/**
 * หา stakeholder ของ user ในเคส
 */
export function getUserStakeholder(ticket: Ticket, userId: string): Stakeholder | undefined {
  if (!ticket.stakeholders) return undefined;
  return ticket.stakeholders.find(s => s.userId === userId);
}

/**
 * หาบทบาทของ user ในเคส
 */
export function getUserRole(ticket: Ticket, userId: string): 'owner' | 'creator' | 'escalator' | 'stakeholder' | 'none' {
  if (isCurrentOwner(ticket, userId)) return 'owner';
  if (isCreator(ticket, userId)) return 'creator';
  if (isEscalator(ticket, userId)) return 'escalator';
  if (isStakeholder(ticket, userId)) return 'stakeholder';
  return 'none';
}

/**
 * สร้างข้อความอธิบายบทบาทของ user
 */
export function getRoleDescription(ticket: Ticket, userId: string): string {
  const role = getUserRole(ticket, userId);
  const stakeholder = getUserStakeholder(ticket, userId);
  
  switch (role) {
    case 'owner':
      return 'ผู้รับผิดชอบปัจจุบัน';
    case 'creator':
      return 'ผู้เปิดเคส';
    case 'escalator':
      if (ticket.escalationChain && ticket.escalationChain.length > 0) {
        const lastEscalation = ticket.escalationChain[ticket.escalationChain.length - 1];
        return `ผู้ส่งต่อไป ${lastEscalation.toTier.toUpperCase()}`;
      }
      return 'ผู้ส่งต่อ';
    case 'stakeholder':
      return 'ผู้เกี่ยวข้อง';
    default:
      return '';
  }
}

/**
 * สร้างข้อความสถานะของเคสสำหรับ stakeholder
 */
export function getStakeholderStatusMessage(ticket: Ticket, userId: string): string {
  const role = getUserRole(ticket, userId);
  
  if (role === 'owner') {
    return 'คุณกำลังรับผิดชอบเคสนี้';
  }
  
  if (role === 'escalator') {
    // หาว่าส่งต่อไป tier ไหน
    const lastEscalation = ticket.escalationChain?.[ticket.escalationChain.length - 1];
    if (lastEscalation) {
      const tierName = lastEscalation.toTier.replace('tier', 'Tier');
      const assigneeName = ticket.assignedTo ? getAssigneeName(ticket) : 'รอมอบหมาย';
      return `ส่งต่อไป ${tierName} - ${assigneeName}`;
    }
  }
  
  if (role === 'creator') {
    return 'คุณเป็นผู้เปิดเคสนี้';
  }
  
  return 'คุณเกี่ยวข้องกับเคสนี้';
}

/**
 * ดึงชื่อของ assignee จาก stakeholders
 */
function getAssigneeName(ticket: Ticket): string {
  if (!ticket.assignedTo || !ticket.stakeholders) return 'ไม่ระบุ';
  const assignee = ticket.stakeholders.find(s => s.userId === ticket.assignedTo);
  return assignee?.name || 'ไม่ระบุ';
}

/**
 * ตรวจสอบสิทธิ์การเข้าถึงเคส
 */
export function canAccessTicket(ticket: Ticket, userId: string, userRole: string): boolean {
  // Admin เห็นทุกอย่าง
  if (userRole === 'admin') return true;
  
  // Current owner เห็นได้
  if (isCurrentOwner(ticket, userId)) return true;
  
  // Stakeholders เห็นได้
  if (isStakeholder(ticket, userId)) return true;
  
  // Tier1 เห็นทุกเคส (ตาม inverted pyramid model)
  if (userRole === 'tier1') return true;
  
  // Tier2 เห็นเฉพาะ tier2
  if (userRole === 'tier2' && ticket.stage === 'tier2') return true;
  
  // Tier3 เห็นเฉพาะ tier3
  if (userRole === 'tier3' && ticket.stage === 'tier3') return true;
  
  return false;
}

/**
 * ตรวจสอบสิทธิ์การแก้ไขเคส
 */
export function canEditTicket(ticket: Ticket, userId: string, userRole: string): boolean {
  // Admin แก้ไขได้ทุกอย่าง
  if (userRole === 'admin') return true;
  
  // เฉพาะ current owner แก้ไขได้
  return isCurrentOwner(ticket, userId);
}

/**
 * ตรวจสอบสิทธิ์การแสดงความคิดเห็น
 */
export function canCommentOnTicket(ticket: Ticket, userId: string, userRole: string): boolean {
  // Admin comment ได้ทุกอย่าง
  if (userRole === 'admin') return true;
  
  // Current owner comment ได้
  if (isCurrentOwner(ticket, userId)) return true;
  
  // Stakeholders comment ได้ (เพื่อให้ข้อมูลเพิ่มเติม)
  if (isStakeholder(ticket, userId)) return true;
  
  // Tier1 comment ได้ทุกเคส
  if (userRole === 'tier1') return true;
  
  return false;
}

/**
 * ตรวจสอบสิทธิ์การปิดเคส
 */
export function canCloseTicket(ticket: Ticket, userId: string, userRole: string): boolean {
  // เฉพาะ Tier1 ปิดเคสได้
  return userRole === 'tier1' || userRole === 'admin';
}
