import { Ticket } from '../types';

// ✅ Mock Data จาก CSV จริง - เคสล่าสุด (5-12 มกราคม 2026)
// แปลงจากรายงานปัญหาระบบสารบรรณอิเล็กทรอนิกส์

// Helper: แปลงวันที่จาก CSV (5/1/2026) เป็น ISO date
const parseDate = (dateStr: string, timeStr?: string): string => {
  if (!dateStr) return new Date().toISOString();
  const [day, month, year] = dateStr.split('/');
  const time = timeStr || '00:00';
  const [hours, minutes] = time.split(':');
  
  // สร้าง Date object โดยตรง (month เริ่มที่ 0)
  const date = new Date(
    parseInt(year),
    parseInt(month) - 1,
    parseInt(day),
    parseInt(hours),
    parseInt(minutes),
    0
  );
  
  return date.toISOString();
};

// Helper: สุ่มเลขเคส
let ticketCounter = 1200; // เริ่มจาก 1200 (เคสใหม่)

export const csvTickets: Ticket[] = [
  // ERC
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามเกี่ยวกับเลขจอง - กรณีมีการจองเลขไว้แต่ใช้งานไม่ได้',
    description: 'คุณ Salila สอบถามเกี่ยวกับเลขจอง กรณีมีการจองเลขจองไว้วันที่ 30 ธนวาคม 2568 แต่พอจะมาใช้งานในวันนี้ไม่สามารถใช้งานเลขจองได้ ระบบขึ้นว่าจำนวนเลขจองไม่เพียงพอ',
    status: 'closed',
    priority: 'high',
    category: 'technical',
    channel: 'line',
    project: 'ERC',
    reporterId: 'cust-erc-001',
    reporterName: 'คุณ Salila',
    assignedTo: 'user-005', // ธัญญาพร
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '10:07'),
    updatedAt: parseDate('5/1/2026', '10:18'),
    resolvedAt: parseDate('5/1/2026', '10:18'),
    resolution: 'ดำเนินการตรวจสอบ พบว่ามีเลขจองในระบบ ที่ผู้ใช้งานไม่สามารถใช้เลขจองได้เกิดจากการเลือกวันที่ ผู้ใช้งานต้องทำการเปลี่ยนวันที่เป็นของปี 2568 จึงจะสามารถใช้งานเลขจองได้',
  },
  
  // RMUTP
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามการลบเลขหนังสือที่จองไปแล้ว',
    description: 'คุณ Nop สอบถามเกี่ยวกับการลบเลขหนังสือที่จองไปแล้ว ต้องดำเนินการอย่างไร',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'line',
    project: 'RMUTP',
    reporterId: 'cust-rmutp-001',
    reporterName: 'คุณ Nop',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '09:51'),
    updatedAt: parseDate('5/1/2026', '10:05'),
    resolvedAt: parseDate('5/1/2026', '10:05'),
    resolution: 'ชี้แจงผู้ใช้งานว่าเลขจองไม่สามารถลบได้ แนะนำให้ทำการออกหนังสือและลบหนังสือแทน',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'แจ้งขอตัดข้อความที่แสดงบนหน้าจอหลังพยายามลบเลขจอง',
    description: 'คุณ Nop แจ้งขอตัดข้อความที่แสดงบนหน้าจอหลังพยายามลบเลขจอง โดยลบคำว่า ติดต่อเจ้าหน้าที่เพื่อทำการแก้ไขออก เนื่องจากผู้ใช้งานเกิดความเข้าใจผิดว่าแอดมินสามารถแก้ไขได้',
    status: 'closed',
    priority: 'low',
    category: 'feature_request',
    channel: 'line',
    project: 'RMUTP',
    reporterId: 'cust-rmutp-001',
    reporterName: 'คุณ Nop',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '10:05'),
    updatedAt: parseDate('5/1/2026', '10:07'),
    resolvedAt: parseDate('5/1/2026', '10:07'),
    resolution: 'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข',
  },
  
  // VRU
  {
    id: `T-${ticketCounter++}`,
    title: 'ปัญหาหนังสือคำสั่งที่สร้างไว้ตั้งแต่ปี 2568 ไม่ทับปี พ.ศ.',
    description: 'คุณ Trinpisit พบปัญหาหนังสือคำสั่งที่สร้างหนังสือไว้ตั้งแต่ปี 2568 เมื่อกดออกเลขปี 2569 ระบบไม่เปลี่ยนทับปี พ.ศ. เป็นปี 2569',
    status: 'closed',
    priority: 'normal',
    category: 'bug',
    channel: 'line',
    project: 'VRU',
    reporterId: 'cust-vru-001',
    reporterName: 'คุณ Trinpisit',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '09:00'),
    updatedAt: parseDate('5/1/2026', '09:13'),
    resolvedAt: parseDate('5/1/2026', '09:13'),
    resolution: 'แนะนำผู้ใช้งาน กดปุ่มแก้ไขหนังสือ ทำการคลิกเอาเครื่องหมายถูกที่ทับปี พ.ศ. ออกก่อน แล้วคลิกเลือกใหม่อีกครั้ง ทำการบันทึกการแก้ไข หนังสือจะเป็นทับปี 2569',
  },
  
  // GPO
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามการแก้ไขเลขจองที่ทำผิด',
    description: 'คุณลักษณ์ สอบถามเกี่ยวกับเลขจอง กรณีผู้ใช้งานลืมจองเลขที่หนังสือสามารถเอาเลขจองที่เคยทำผิดมาทำการแก้ไขเพื่อเอาเลขคืนได้หรือไม่',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'line',
    project: 'GPO',
    reporterId: 'cust-gpo-001',
    reporterName: 'คุณลักษณ์',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '10:30'),
    updatedAt: parseDate('5/1/2026', '10:31'),
    resolvedAt: parseDate('5/1/2026', '10:31'),
    resolution: 'ชี้แจงผู้ใช้งานว่าเลขจองที่ออกไปแล้วไม่สามารถลบหรือแก้ไขได้ แนะนำผู้ใช้งานให้สร้างและใช้เลขจองใหม่ให้ถูกต้อง',
  },
  
  // FIO
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามวิธีการรีเซ็ตรหัสผ่านการลงนาม',
    description: 'คุณ เหน่ง สอบถามการใช้งานระบบสารบรรณวิธีการรีเซ็ตรหัสผ่านการลงนาม',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'phone',
    project: 'FIO',
    reporterId: 'cust-fio-001',
    reporterName: 'คุณ เหน่ง',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-006',
    createdAt: parseDate('6/1/2026', '11:17'),
    updatedAt: parseDate('6/1/2026', '11:20'),
    resolvedAt: parseDate('6/1/2026', '11:20'),
    resolution: 'ดำเนินการแนะนำวิธีการรีเซ็ตรหัสผ่านการลงนาม',
  },
  
  // AMLO
  {
    id: `T-${ticketCounter++}`,
    title: 'อีเมลค้างอยู่ 453,786 เรื่อง ตั้งแต่ 8 พ.ค. - 30 ธค. 2568',
    description: 'คุณ Rungforever แจ้งตรวจสอบ มีอีเมลค้างอยู่ 453,786 เรื่อง ตั้งแต่ 8 พ.ค. - 30 ธค. 2568',
    status: 'closed',
    priority: 'critical',
    category: 'bug',
    channel: 'line',
    project: 'AMLO',
    reporterId: 'cust-amlo-001',
    reporterName: 'คุณ Rungforever',
    assignedTo: 'user-011', // ยุทธนา
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '11:50'),
    updatedAt: parseDate('5/1/2026', '12:06'),
    resolvedAt: parseDate('5/1/2026', '12:06'),
    resolution: 'แจ้งทีมงานเพื่อตรวจสอบ ทีมงานแจ้งทำการลบเมลที่ดึงมาเป็นชื่อเรื่อง Undelivered Mail Returned to Sender เรียบร้อยแล้ว',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ระบบอีเมล์ไม่ดึงเข้ามาในระบบสารบรรณตั้งแต่ 30 ธ.ค. 68',
    description: 'คุณ Non Tacha แจ้งตรวจสอบระบบอีเมล์ไม่ดึงเข้ามาในระบบสารบรรณ รบกวนช่วยตรวจสอบ ตั้งแต่วันที่ 30 ธ.ค. 68',
    status: 'closed',
    priority: 'critical',
    category: 'bug',
    channel: 'line',
    project: 'AMLO',
    reporterId: 'cust-amlo-002',
    reporterName: 'คุณ Non Tacha',
    assignedTo: 'user-011', // ยุทธนา
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '11:50'),
    updatedAt: parseDate('5/1/2026', '13:31'),
    resolvedAt: parseDate('5/1/2026', '13:31'),
    resolution: 'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข ปัจจุบันอีเมลถูกดึงเข้าสู่ระบบอัตโนมัติตามปกติ',
  },
  
  // DOH
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเพิ่มสมุดทะเบียนส่งของสำนักรวดเร็วปลอดภัย 6 เล่ม',
    description: 'คุณ Suthisak Mooyotha แจ้งขอเพิ่มสมุดทะเบียนส่ง ของสำนักรวดเร็วปลอดภัย กรมทางหลวง ทั้งหมด 6 เล่ม',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DOH',
    reporterId: 'cust-doh-001',
    reporterName: 'คุณ Suthisak Mooyotha',
    assignedTo: 'user-010', // สาริน
    createdBy: 'user-010',
    createdAt: parseDate('5/1/2026', '09:15'),
    updatedAt: parseDate('5/1/2026', '09:34'),
    resolvedAt: parseDate('5/1/2026', '09:34'),
    resolution: 'ดำเนินการเพิ่มสมุดทะเบียนส่งทั้ง 6 เล่มให้ ตามข้อมูลที่ผู้ใช้งานแจ้ง',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอปิดการใช้งานทะเบียนส่ง',
    description: 'คุณ Suthisak Mooyotha แจ้งขอปิดการใช้งานทะเบียนส่ง ของสำนักรวดเร็วปลอดภัย กรมทางหลวง ตามไฟล์แนบ',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DOH',
    reporterId: 'cust-doh-001',
    reporterName: 'คุณ Suthisak Mooyotha',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '10:23'),
    updatedAt: parseDate('5/1/2026', '10:27'),
    resolvedAt: parseDate('5/1/2026', '10:27'),
    resolution: 'ดำเนินการยกเลิกทะเบียนส่ง สมุดทะเบียนส่งภายใน เล่มที่ผู้ใช้งานแจ้ง เรียบร้อยแล้ว',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ไม่มีสมุดทะเบียนรับภายใน',
    description: 'คุณ Suthisak Mooyotha แจ้งตรวจสอบสำนักรวดเร็วปลอดภัย กรมทางหลวง เวลาจะลงรับ แต่ไม่มีสมุดทะเบียนรับภายใน',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'DOH',
    reporterId: 'cust-doh-001',
    reporterName: 'คุณ Suthisak Mooyotha',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '11:15'),
    updatedAt: parseDate('5/1/2026', '11:23'),
    resolvedAt: parseDate('5/1/2026', '11:23'),
    resolution: 'ดำเนินการตรวจสอบ พบว่าเกิดจากการไปปิดสมุดทะเบียนผิดเล่ม จึงทำให้ไม่สามารถใช้งานสมุดทะเบียนได้ ปัจจุบันทำการแก้ไขและใช้งานสมุดทะเบียนได้ตามปกติ',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอลบตัวเลือกบทบาทผู้ใช้งาน มีมากกว่า 70 บทบาท',
    description: 'คุณ Suthisak Mooyotha แจ้งลบตัวเลือกบทบาทผู้ใช้งาน ตอนนี้มีมากกว่า 70 บทบาท สามารถลบหรือทำให้น้อยลงได้หรือไม่',
    status: 'closed',
    priority: 'low',
    category: 'feature_request',
    channel: 'line',
    project: 'DOH',
    reporterId: 'cust-doh-001',
    reporterName: 'คุณ Suthisak Mooyotha',
    assignedTo: 'user-012', // ประกาศิต
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '14:48'),
    updatedAt: parseDate('5/1/2026', '14:51'),
    resolvedAt: parseDate('5/1/2026', '14:51'),
    resolution: 'แจ้งทีมงานเพื่อตรวจสอบและดำเนินการแก้ไข',
  },
  
  // DLPW - มีเยอะมากที่สุด
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเปลี่ยนชื่อกลุ่มงานและเพิ่มบทบาทธุรการ',
    description: 'คุณBank แจ้งขอเปลี่ยนชื่อกลุ่มงานภายในให้เป็นปัจจุบันและแจ้งเพิ่มบทบาทผู้ใช้งานธุรการกลุ่มงาน',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-001',
    reporterName: 'คุณBank',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '06:47'),
    updatedAt: parseDate('5/1/2026', '06:47'),
    resolvedAt: parseDate('5/1/2026', '06:47'),
    resolution: 'แจ้งประสานกับทางทีมงานแก้ไขและเพิ่มบทบาทเรียบร้อย',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'เข้าระบบไม่ได้',
    description: 'คุณpuk.kusuma แจ้งเข้าระบบไม่ได้',
    status: 'closed',
    priority: 'high',
    category: 'technical',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-002',
    reporterName: 'คุณpuk.kusuma',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '07:47'),
    updatedAt: parseDate('5/1/2026', '08:34'),
    resolvedAt: parseDate('5/1/2026', '08:34'),
    resolution: 'แจ้งเข้าระบบผ่านลิ้งใหม่เรียบร้อย',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'เข้าระบบไม่ได้ - ไม่มีสิทธิ์',
    description: 'คุณS.Wachiraya แจ้งเข้าระบบไม่ได้',
    status: 'closed',
    priority: 'high',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-003',
    reporterName: 'คุณS.Wachiraya',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '08:37'),
    updatedAt: parseDate('5/1/2026', '08:39'),
    resolvedAt: parseDate('5/1/2026', '08:39'),
    resolution: 'ตรวจสอบพบรหัสผู้ใช้ไม่มีสิทธิ์และดำเนินการเพิ่มสิทธิ์เรียบร้อย',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามการออกเลขทะเบียนส่งหนังสือ',
    description: 'คุณNuna369 สอบถามออกเลขทะเบียนส่งหนังสือ ต้องเข้าไปจองเลขก่อนหรือไม่',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-004',
    reporterName: 'คุณNuna369',
    assignedTo: 'user-005', // ธัญญาพร
    createdBy: 'user-005',
    createdAt: parseDate('5/1/2026', '09:00'),
    updatedAt: parseDate('5/1/2026', '09:08'),
    resolvedAt: parseDate('5/1/2026', '09:08'),
    resolution: 'แจ้งวิธีการสร้างหนังสือในระบบแล้วกดออกเลขทันที่ได้',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเพิ่มบทบาทผู้ใช้งาน',
    description: 'คุณNOON แจ้งเพิ่มบทบาทผู้ใช้งาน',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-005',
    reporterName: 'คุณNOON',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '09:06'),
    updatedAt: parseDate('5/1/2026', '09:12'),
    resolvedAt: parseDate('5/1/2026', '09:12'),
    resolution: 'ดำเนินการเพิ่มสิทธิเรียบร้อย',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามคู่มือการใช้งานระบบ',
    description: 'คุณรักษ์ สอบถามคู่มือการใช้งานระบบ',
    status: 'closed',
    priority: 'low',
    category: 'general_inquiry',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-006',
    reporterName: 'คุณรักษ์',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '09:18'),
    updatedAt: parseDate('5/1/2026', '09:20'),
    resolvedAt: parseDate('5/1/2026', '09:20'),
    resolution: 'สามารถดาวน์โหลดได้จากหน้าระบบงาน',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอแก้ไขหน่วยงาน',
    description: 'คุณกะแต นิริศรา แจ้งแก้ไขหน่วยงาน',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-007',
    reporterName: 'คุณกะแต นิริศรา',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '09:20'),
    updatedAt: parseDate('5/1/2026', '09:23'),
    resolvedAt: parseDate('5/1/2026', '09:23'),
    resolution: 'ดำเนินการแก้ไขเรียบร้อย',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเพิ่มสิทธิการใช้งานระบบ',
    description: 'คุณS.Wachiraya แจ้งเพิ่มสิทธิการใช้งานระบบ',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-003',
    reporterName: 'คุณS.Wachiraya',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('5/1/2026', '08:32'),
    updatedAt: parseDate('5/1/2026', '09:27'),
    resolvedAt: parseDate('5/1/2026', '09:27'),
    resolution: 'ดำเนินการเพิ่มสิทธิและแจ้งลูกค้าเข้าระบบอีกครั้ง',
  },
  
  // DGA
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามรายงานข้อมูลค้างรับดำเนินการ',
    description: 'คุณ Denzz สอบถามเกี่ยวกับระบบสารบรรณมีรายงานในส่วนของข้อมูลค้างรับดำเนินการ สามารถแยกประเภทหนังสือส่งออก หนังสือรับเข้าและ บันทึกข้อความ หรือมีอยู่ที่เมนูปุ่มไหนหรือไม่',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'line',
    project: 'DGA',
    reporterId: 'cust-dga-001',
    reporterName: 'คุณ Denzz',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '09:18'),
    updatedAt: parseDate('5/1/2026', '10:02'),
    resolvedAt: parseDate('5/1/2026', '10:02'),
    resolution: 'ชี้แจงผู้ใช้งานว่า ถ้าในสถานะด้านซ้ายมือ จะมีให้คลิกเลือกเฉพาะด้านขวาบน สามารถคลิกเลือกจากตรงนั้นได้',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอดาวน์โหลดไฟล์ลงนามส่งอีเมล',
    description: 'คุณ Maye แจ้งขอดาวน์โหลดไฟล์ลงนาม เลขที่หนังสือ สพร 2568/ว3755 มาที่อีเมล issari.Bundirake@dga.or.th',
    status: 'closed',
    priority: 'normal',
    category: 'other',
    channel: 'line',
    project: 'DGA',
    reporterId: 'cust-dga-002',
    reporterName: 'คุณ Maye',
    assignedTo: 'user-012', // ประกาศิต
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '14:50'),
    updatedAt: parseDate('5/1/2026', '16:38'),
    resolvedAt: parseDate('5/1/2026', '16:38'),
    resolution: 'ดำเนินการดาวน์โหลดไฟล์แนบ และส่งให้อีเมลที่แจ้ง เรียบร้อยแล้ว',
  },
  
  // SUANLUANG
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามการลงรับหนังสือย้อนหลัง',
    description: 'คุณโก้ สอบถามเกี่ยวกับการลงรับหนังสือย้อนหลังไม่สามารถทำได้ ต้องดำเนินการอย่างไร',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'line',
    project: 'SUANLUANG',
    reporterId: 'cust-suanluang-001',
    reporterName: 'คุณโก้',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('6/1/2026', '10:38'),
    updatedAt: parseDate('6/1/2026', '10:39'),
    resolvedAt: parseDate('6/1/2026', '10:39'),
    resolution: 'ชี้แจงผู้ใช้งานว่าไม่สามารถรับย้อนหลังได้ หากไม่มีการจองเลขไว้ แนะนำให้ลองใช้การรับนอกระบบแทน',
  },
  
  // OPM สปน
  {
    id: `T-${ticketCounter++}`,
    title: 'ไม่สามารถเสนอหนังสือเพื่อลงนาม ระบบแสดงยังไม่เลือกเล่มทะเบียน',
    description: 'คุณสุระศักดิ์ แจ้งตรวจสอบผู้ทรงคุณวุฒิพิเศษประจำสำนักนายกรัฐมนตรี (นายฉันทานนท์ วรรณเขจร) ไม่สามารถเสนอหนังสือเพื่อลงนาม ระบบแสดงหน้าจอยังไม่ได้เลือกเล่มทะเบียน',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'OPM',
    reporterId: 'cust-opm-001',
    reporterName: 'คุณสุระศักดิ์',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '09:41'),
    updatedAt: parseDate('5/1/2026', '09:59'),
    resolvedAt: parseDate('5/1/2026', '09:59'),
    resolution: 'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข ปัจจุบันสามารถใช้งานได้ตามปกติ',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'กดรับหนังสือของปี 2568 เลขรับไม่ขึ้น',
    description: 'คุณสุระศักดิ์ แจ้งตรวจสอบ ผู้ใช้งานแจ้งว่ากดรับหนังสือของปี 2568 เลขรับไม่ขึ้น',
    status: 'closed',
    priority: 'normal',
    category: 'bug',
    channel: 'line',
    project: 'OPM',
    reporterId: 'cust-opm-001',
    reporterName: 'คุณสุระศักดิ์',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '09:51'),
    updatedAt: parseDate('5/1/2026', '10:14'),
    resolvedAt: parseDate('5/1/2026', '10:14'),
    resolution: 'ดำเนินการตรวจสอบ พบว่าทั้ง 2 ฉบับ กลุ่มงานบริหารระบบฐานข้อมูลสารสนเทศ ศทก. เป็นต้นเรื่อง จึงทำให้ไม่มีเลขรับ',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'หัวหน้าผู้ตรวจราชการไม่สามารถรับหนังสือได้',
    description: 'คุณสุรศักดิ์ แจ้งตรวจสอบ หัวหน้าผู้ตรวจราชการสำนักนายกรัฐมนตรีไม่สามารถรับหนังสือได้',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'OPM',
    reporterId: 'cust-opm-001',
    reporterName: 'คุณสุระศักดิ์',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('5/1/2026', '11:03'),
    updatedAt: parseDate('5/1/2026', '11:19'),
    resolvedAt: parseDate('5/1/2026', '11:19'),
    resolution: 'ดำเนินการตรวจสอบ พบว่าสมุดทะเบียนหายไป จึงทำการเพิ่มเล่มสมุดทะเบียนให้ใหม่ ปัจจุบันสามารถใช้งานได้ตามปกติ',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'กดออกรายงานทำให้ระบบช้า CPU พีค',
    description: 'คุณสุระศักดิ์ แจ้งตรวจสอบ เนื่องจากมีผู้ใช้งานกดออกรายงาน แล้วทำให้ระบบช้า เพราะ CPU เกิดพีคขึ้น',
    status: 'closed',
    priority: 'critical',
    category: 'bug',
    channel: 'line',
    project: 'OPM',
    reporterId: 'cust-opm-001',
    reporterName: 'คุณสุระศักดิ์',
    assignedTo: 'user-011', // ยุทธนา
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('6/1/2026', '08:55'),
    updatedAt: parseDate('6/1/2026', '09:01'),
    resolvedAt: parseDate('6/1/2026', '09:01'),
    resolution: 'แจ้งทีมงานเพื่อตรวจสอบ พบว่าเกิดจาก service Report Server จึงดำเนินการแก้ไข ปัจจุบันสามารถใช้งานได้ตามปกติ',
  },
  
  // RMUTK
  {
    id: `T-${ticketCounter++}`,
    title: 'รีโมทตรวจสอบไม่สามารถเจนหนังสือ .docx ได้',
    description: 'คุณโจ้ แจ้งรีโมทตรวจสอบ เนื่องจากมีเครื่องของผู้ใช้งานที่ไม่สามารถเจนหนังสือ .docx ได้',
    status: 'closed',
    priority: 'high',
    category: 'technical',
    channel: 'line',
    project: 'RMUTK',
    reporterId: 'cust-rmutk-001',
    reporterName: 'คุณโจ้',
    assignedTo: 'user-010', // สาริน
    createdBy: 'user-010',
    createdAt: parseDate('6/1/2026', '11:20'),
    updatedAt: parseDate('6/1/2026', '11:49'),
    resolvedAt: parseDate('6/1/2026', '11:49'),
    resolution: 'ดำเนินการรีโมทไปตั้งค่า Chrome ให้ เรียบร้อยแล้ว ปัจจุบันสามารถร่างหนังสือ .docx ได้เรียบร้อยแล้ว',
  },
  
  // MOT
  {
    id: `T-${ticketCounter++}`,
    title: 'ลงรับหนังสือมากกว่า 1 เรื่องแล้วระบบขึ้น error',
    description: 'คุณมอส แจ้งว่า user แจ้งมาว่า ลงรับหนังสือมากกว่า 1 เรื่อง แล้วระบบขึ้น error',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'MOT',
    reporterId: 'cust-mot-001',
    reporterName: 'คุณมอส',
    assignedTo: 'user-011', // ยุทธนา
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('8/1/2026', '10:55'),
    updatedAt: parseDate('8/1/2026', '11:19'),
    resolvedAt: parseDate('8/1/2026', '11:19'),
    resolution: 'ตรวจสอบเบื้องต้น ทั้ง 3 ฉบับเป็นหนังสือที่ สรค เคยรับมาแล้วครั้งนึง และตอนนี้สถานะยังอยู่ที่ รอรับ',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ระบบ CTL พิมพ์รายงานข้อมูลบุคคลไม่ได้',
    description: 'คุณเอ็น แจ้งระบบ CTL พิมพ์รายงานข้อมูลบุคคลไม่ได้',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'MOT',
    reporterId: 'cust-mot-002',
    reporterName: 'คุณเอ็น',
    assignedTo: 'user-013', // ปิยะมาศ
    createdBy: 'user-005', // ธัญญาพร
    createdAt: parseDate('8/1/2026', '11:41'),
    updatedAt: parseDate('9/1/2026', '13:24'),
    resolvedAt: parseDate('9/1/2026', '13:24'),
    resolution: 'แจ้งทีมหลังบ้านแก้ไขสามารถออกรายงานข้อมูลบุคคลได้เรียบร้อย',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'สอบถามการ reset password จัดเก็บเอกสาร',
    description: 'คุณเอ็น แจ้งระบบCTL สามารถ reset password สำหรับเข้าระบบจัดเก็บเอกสารได้อย่างไร',
    status: 'closed',
    priority: 'normal',
    category: 'general_inquiry',
    channel: 'line',
    project: 'MOT',
    reporterId: 'cust-mot-002',
    reporterName: 'คุณเอ็น',
    assignedTo: 'user-005', // ธัญญาพร
    createdBy: 'user-005',
    createdAt: parseDate('9/1/2026', '09:34'),
    updatedAt: parseDate('9/1/2026', '09:57'),
    resolvedAt: parseDate('9/1/2026', '09:57'),
    resolution: 'แจ้งลูกค้าที่ mot ต่อ ldap จะล้างรหัสผ่านที่ ctl ไม่ได้ ต้องแก้ไขที่ Ldap หน่วยงาน',
  },
  
  // VRU - เพิ่มเติม
  {
    id: `T-${ticketCounter++}`,
    title: 'กดคืนเรื่องแล้วระบบขึ้น Error',
    description: 'คุณ Trinpisit แจ้งตรวจสอบ กดคืนเรื่องแล้วระบบขึ้นแจ้งเตือน Error เลขที่หนังสือ อว0630.02/20',
    status: 'closed',
    priority: 'normal',
    category: 'bug',
    channel: 'line',
    project: 'VRU',
    reporterId: 'cust-vru-001',
    reporterName: 'คุณ Trinpisit',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('8/1/2026', '13:55'),
    updatedAt: parseDate('8/1/2026', '14:17'),
    resolvedAt: parseDate('8/1/2026', '14:17'),
    resolution: 'ดำเนินการตรวจสอบ พบว่าหนังสือถูกลงรับไปเรียบร้อยแล้ว จึงทำให้ไม่สามารถกดคืนเรื่องได้',
  },
  
  // DLPW - เพิ่มเติม (มีเยอะมาก)
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเพิ่มสิทธิการใช้งานระบบ - สสค.นครปฐม',
    description: 'คุณparichat แจ้งเพิ่มสิทธิการใช้งานระบบ ของ สสค.นครปฐม',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-020',
    reporterName: 'คุณparichat',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-009',
    createdAt: parseDate('6/1/2026', '16:14'),
    updatedAt: parseDate('6/1/2026', '16:28'),
    resolvedAt: parseDate('6/1/2026', '16:28'),
    resolution: 'ดำเนินการเพิ่มสิทธิและแจ้งลูกค้าเข้าระบบอีกครั้ง',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'รายงานสมุดทะเบียนรับแสดงข้อมูลไม่ถูกต้อง',
    description: 'คุณแก้วตา แจ้งระบบแสดงรายงานสมุดทะเบียนรับ แสดงข้อมูลไม่ถูกต้อง',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-021',
    reporterName: 'คุณแก้วตา',
    assignedTo: 'user-014', // ทีม App
    createdBy: 'user-009', // วรรณภา
    createdAt: parseDate('6/1/2026', '16:14'),
    updatedAt: parseDate('7/1/2026', '09:00'),
    resolvedAt: parseDate('7/1/2026', '09:00'),
    resolution: 'ทีมพัฒนาระบบดำเนินการแก้ไขเรียบร้อย',
    currentTier: 'tier2',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเปลี่ยนชื่อท่านสสค.นนทบุรี',
    description: 'คุณปทิตตา แจ้งเปลี่ยนชื่อ ท่านสสค.นนทบุรี',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-022',
    reporterName: 'คุณปทิตตา',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-009',
    createdAt: parseDate('6/1/2026', '14:12'),
    updatedAt: parseDate('6/1/2026', '14:18'),
    resolvedAt: parseDate('6/1/2026', '14:18'),
    resolution: 'ดำเนินปรับปรุงข้อมูลผ่านโปรแกรมข้อมูลหน่วยงาน',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'กลุ่มงานยุทธศาสตร์แรงงานสัมพันธ์ไม่สามารถลงทะเบียนรับได้',
    description: 'คุณchuyamon แจ้งกลุ่มงานยุทธศาสตร์แรงงานสัมพันธ์ไม่สามารถลงทะเบียนรับได้',
    status: 'closed',
    priority: 'high',
    category: 'bug',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-023',
    reporterName: 'คุณchuyamon',
    assignedTo: 'user-009', // วรรณภา
    createdBy: 'user-009',
    createdAt: parseDate('6/1/2026', '12:30'),
    updatedAt: parseDate('6/1/2026', '13:47'),
    resolvedAt: parseDate('6/1/2026', '13:47'),
    resolution: 'ดำเนินปรับปรุงข้อมูลผ่านโปรแกรมข้อมูลหน่วยงาน และโปรแกรมสมุดทะเบียน',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'บันทึกหนังสือรับเดือนธันวาคมไม่ได้ ระบบประมวลผลนาน',
    description: 'คุณปู วราภรณ์ แจ้งหนังสือรับที่ลงวันที่เดือนธันวาคม ไม่สามารถบันทึกได้ระบบแจ้งประมวลผลนาน',
    status: 'closed',
    priority: 'critical',
    category: 'bug',
    channel: 'line',
    project: 'DLPW',
    reporterId: 'cust-dlpw-024',
    reporterName: 'คุณปู วราภรณ์',
    assignedTo: 'user-014', // ทีม App
    createdBy: 'user-009', // วรรณภา
    createdAt: parseDate('5/1/2026', '16:08'),
    updatedAt: parseDate('6/1/2026', '08:00'),
    resolvedAt: parseDate('6/1/2026', '08:00'),
    resolution: 'ทีมพัฒนาระบบดำเนินการแก้ไขโปรแกรม และดีพอยโปรแกรม',
    currentTier: 'tier2',
  },
  
  // DOT
  {
    id: `T-${ticketCounter++}`,
    title: 'ระบบสารบรรณไม่สามารถใช้งานได้',
    description: 'คุณ Aegapong แจ้งตรวจสอบ ระบบสารบรรณไม่สามารถใช้งานได้',
    status: 'closed',
    priority: 'critical',
    category: 'bug',
    channel: 'line',
    project: 'DOT',
    reporterId: 'cust-dot-001',
    reporterName: 'คุณ Aegapong',
    assignedTo: 'user-012', // ประกาศิต
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('6/1/2026', '19:57'),
    updatedAt: parseDate('6/1/2026', '21:20'),
    resolvedAt: parseDate('6/1/2026', '21:20'),
    resolution: 'ทีมงานดำเนินการตรวจสอบและแก้ไข เรียบร้อยแล้ว ปัจจุบันสามารถใช้งานได้ตามปกติ',
    currentTier: 'tier2',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ระบบสารบรรณไม่สามารถใช้งานได้ - Server ล่ม',
    description: 'คุณ Pingple แจ้งตรวจสอบ ระบบสารบรรณไม่สามารถใช้งานได้',
    status: 'closed',
    priority: 'critical',
    category: 'bug',
    channel: 'line',
    project: 'DOT',
    reporterId: 'cust-dot-002',
    reporterName: 'คุณ Pingple',
    assignedTo: 'user-012', // ประกาศิต
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('7/1/2026', '12:57'),
    updatedAt: parseDate('7/1/2026', '16:15'),
    resolvedAt: parseDate('7/1/2026', '16:15'),
    resolution: 'ตรวจสอบ พบว่าเป็น Server ระบบงาน ทางบริษัทได้แจ้งให้ IT ทราบ หลังจาก IT แก้ไขปัญหา Server แล้ว ทางบริษัทเข้าไปตรวจสอบอีกครั้ง ทั้งระบบงานสารบรรณ และระบบจัดเก็บเอกสาร กลับมาใช้งานได้ปกติ มี table เสียหาย 3 table ทำการซ่อมแซมเรียบร้อย',
    currentTier: 'tier3',
  },
  
  // OTEP
  {
    id: `T-${ticketCounter++}`,
    title: 'ร่างหนังสือหน้ากระดาษแสดงอักษรพิเศษ',
    description: 'คุณ N-OK สอบถามเกี่ยวกับการร่างหนังสือ หน้ากระดาษแสดงอักษรพิเศษต้องดำเนินการแก้ไขอย่างไร',
    status: 'closed',
    priority: 'normal',
    category: 'technical',
    channel: 'line',
    project: 'OTEP',
    reporterId: 'cust-otep-001',
    reporterName: 'คุณ N-OK',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('7/1/2026', '11:59'),
    updatedAt: parseDate('7/1/2026', '13:09'),
    resolvedAt: parseDate('7/1/2026', '13:09'),
    resolution: 'ชี้แจงขั้นตอนในการแก้ไขและตั้งค่าเพื่อแก้ไขความผิดปกติที่เกิดขึ้น พร้อมทั้งแนบคู่มือประกอบการตั้งค่าการอัปเดต Chrome',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ลงนามผ่านแอปมือถือต้องเพิ่มตำแหน่งทุกครั้ง',
    description: 'คุณ Kultida แจ้งตรวจสอบ ลงนามผ่านแอปลิเคชั่นในมือถือต้องมาทำการเพิ่มตำแหน่งด้วยตนเองในทุกครั้ง เกิดจากอะไร ต้องดำเนินการแก้ไขอย่างไร',
    status: 'closed',
    priority: 'low',
    category: 'feature_request',
    channel: 'line',
    project: 'OTEP',
    reporterId: 'cust-otep-002',
    reporterName: 'คุณ Kultida',
    assignedTo: 'user-006', // ธิราภรณ์
    createdBy: 'user-010', // สาริน
    createdAt: parseDate('7/1/2026', '13:06'),
    updatedAt: parseDate('7/1/2026', '13:12'),
    resolvedAt: parseDate('7/1/2026', '13:12'),
    resolution: 'ชี้แจงผู้ใช้งานว่าในโทรศัพท์มือถือ ยังไม่มีปุ่มให้ติ๊กเลือกตำแหน่งอัตโนมัติ แจ้งทีมงานเก็บข้อแนะนำไว้พัฒนาต่อในเวอร์ชั่นถัดไป',
  },
  
  {
    id: `T-${ticketCounter++}`,
    title: 'ขอเพิ่มผู้ใช้งาน 1 ท่าน',
    description: 'คุณ Kultida แจ้งขอเพิ่มผู้ใช้งาน 1 ท่าน นายโสมนัส คงศรี',
    status: 'closed',
    priority: 'normal',
    category: 'account',
    channel: 'line',
    project: 'OTEP',
    reporterId: 'cust-otep-002',
    reporterName: 'คุณ Kultida',
    assignedTo: 'user-010', // สาริน
    createdBy: 'user-010',
    createdAt: parseDate('7/1/2026', '13:30'),
    updatedAt: parseDate('7/1/2026', '13:31'),
    resolvedAt: parseDate('7/1/2026', '13:31'),
    resolution: 'ดำเนินการเพิ่มผู้ใช้งานให้ ตามข้อมูลที่ได้รับแจ้ง',
  },
];

// User mapping for reports
export const reportUsers = {
  'user-005': { id: 'user-005', name: 'ธัญญาพร', role: 'tier1' },
  'user-006': { id: 'user-006', name: 'ธิราภรณ์', role: 'tier1' },
  'user-009': { id: 'user-009', name: 'วรรณภา', role: 'tier1' },
  'user-010': { id: 'user-010', name: 'สาริน', role: 'tier1' },
  'user-011': { id: 'user-011', name: 'ยุทธนา', role: 'tier2' },
  'user-012': { id: 'user-012', name: 'ประกาศิต', role: 'tier2' },
  'user-013': { id: 'user-013', name: 'ปิยะมาศ', role: 'tier2' },
  'user-014': { id: 'user-014', name: 'ทีม App', role: 'tier3' },
};