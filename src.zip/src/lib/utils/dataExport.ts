/**
 * 📤 Data Export Utilities
 * 
 * @description Helper functions สำหรับ Export ข้อมูล Organization/Project
 * @version 1.0 - Phase 5
 */

import { Organization, Project } from '../../types';

/**
 * Export Organizations เป็น CSV
 */
export function exportOrganizationsToCSV(organizations: Organization[]): string {
  const headers = [
    'ID',
    'รหัสหน่วยงาน',
    'ชื่อย่อ',
    'ชื่อเต็ม',
    'ประเภท',
    'แผนก/ส่วน',
    'ผู้ติดต่อ',
    'อีเมล',
    'โทรศัพท์'
  ];

  const rows = organizations.map(org => [
    org.id,
    org.organizationCode,
    org.organizationShortName,
    org.organizationName,
    org.organizationType,
    org.department || '',
    org.contactPerson || '',
    org.contactEmail || '',
    org.contactPhone || ''
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');

  return csvContent;
}

/**
 * Export Projects เป็น CSV
 */
export function exportProjectsToCSV(projects: Project[], organizations: Organization[]): string {
  const headers = [
    'ID',
    'รหัสโครงการ',
    'ชื่อโครงการ',
    'รหัสหน่วยงาน',
    'ชื่อหน่วยงาน',
    'สถานะ',
    'ผู้จัดการโครงการ',
    'งบประมาณ',
    'วันเริ่ม',
    'วันสิ้นสุด',
    'รายละเอียด'
  ];

  const rows = projects.map(project => {
    const org = organizations.find(o => o.id === project.organizationId);
    return [
      project.id,
      project.projectCode,
      project.projectName,
      org?.organizationCode || '',
      org?.organizationName || '',
      project.projectStatus,
      project.projectManager || '',
      project.budget?.toString() || '',
      project.startDate?.toISOString().split('T')[0] || '',
      project.endDate?.toISOString().split('T')[0] || '',
      project.description || ''
    ];
  });

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');

  return csvContent;
}

/**
 * Export Organizations เป็น JSON
 */
export function exportOrganizationsToJSON(organizations: Organization[]): string {
  return JSON.stringify(organizations, null, 2);
}

/**
 * Export Projects เป็น JSON
 */
export function exportProjectsToJSON(projects: Project[]): string {
  return JSON.stringify(projects, null, 2);
}

/**
 * Download file helper
 */
export function downloadFile(content: string, filename: string, type: 'csv' | 'json') {
  const mimeType = type === 'csv' 
    ? 'text/csv;charset=utf-8;' 
    : 'application/json;charset=utf-8;';
    
  const blob = new Blob(['\uFEFF' + content], { type: mimeType });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Export Organizations (wrapper)
 */
export function exportOrganizations(
  organizations: Organization[],
  format: 'csv' | 'json' = 'csv'
) {
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `organizations_${timestamp}.${format}`;
  
  const content = format === 'csv'
    ? exportOrganizationsToCSV(organizations)
    : exportOrganizationsToJSON(organizations);
  
  downloadFile(content, filename, format);
}

/**
 * Export Projects (wrapper)
 */
export function exportProjects(
  projects: Project[],
  organizations: Organization[],
  format: 'csv' | 'json' = 'csv'
) {
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `projects_${timestamp}.${format}`;
  
  const content = format === 'csv'
    ? exportProjectsToCSV(projects, organizations)
    : exportProjectsToJSON(projects);
  
  downloadFile(content, filename, format);
}

/**
 * Export Combined Data (Organization + Projects)
 */
export function exportCombinedData(
  organizations: Organization[],
  projects: Project[]
) {
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `cdgs_data_${timestamp}.json`;
  
  const data = {
    exportDate: new Date().toISOString(),
    version: '1.0',
    organizations,
    projects,
    summary: {
      totalOrganizations: organizations.length,
      totalProjects: projects.length,
      byType: organizations.reduce((acc, org) => {
        acc[org.organizationType] = (acc[org.organizationType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    }
  };
  
  const content = JSON.stringify(data, null, 2);
  downloadFile(content, filename, 'json');
}
