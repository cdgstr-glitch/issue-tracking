/**
 * 📁 Project Utilities
 * 
 * @description Helper functions สำหรับจัดการ Projects
 * @version 1.0 - Phase 1
 */

import { Project, ProjectStatus, Organization } from '../../types';

/**
 * หา Project จาก ID
 * 
 * @param id - Project ID
 * @param projects - Array of projects
 * @returns Project หรือ undefined
 */
export function getProjectById(
  id: string,
  projects: Project[]
): Project | undefined {
  return projects.find(proj => proj.id === id);
}

/**
 * หา Project จาก projectCode
 * 
 * @param projectCode - รหัสโครงการ เช่น 'PRJ-VRU-2026-001'
 * @param projects - Array of projects
 * @returns Project หรือ undefined
 */
export function getProjectByCode(
  projectCode: string,
  projects: Project[]
): Project | undefined {
  return projects.find(proj => proj.projectCode === projectCode);
}

/**
 * ดึง Projects ทั้งหมดของ Organization
 * 
 * @param organizationId - Organization ID
 * @param projects - Array of projects
 * @returns Array of projects
 */
export function getProjectsByOrganization(
  organizationId: string,
  projects: Project[]
): Project[] {
  return projects.filter(proj => proj.organizationId === organizationId);
}

/**
 * นับจำนวน Projects ใน Organization
 * 
 * @param organizationId - Organization ID
 * @param projects - Array of projects
 * @returns จำนวนโครงการ
 */
export function countProjectsByOrganization(
  organizationId: string,
  projects: Project[]
): number {
  return projects.filter(
    proj => proj.organizationId === organizationId
  ).length;
}

/**
 * ดึง Active Projects เท่านั้น
 * 
 * @param projects - Array of projects
 * @returns Array of active projects
 */
export function getActiveProjects(projects: Project[]): Project[] {
  return projects.filter(proj => proj.projectStatus === 'active');
}

/**
 * ดึง Projects ตาม status
 * 
 * @param projectStatus - สถานะโครงการ
 * @param projects - Array of projects
 * @returns Array of projects
 */
export function getProjectsByStatus(
  projectStatus: ProjectStatus,
  projects: Project[]
): Project[] {
  return projects.filter(proj => proj.projectStatus === projectStatus);
}

/**
 * ค้นหา Projects (ชื่อ, รหัส)
 * 
 * @param searchTerm - คำค้นหา
 * @param projects - Array of projects
 * @returns Array of projects
 */
export function searchProjects(
  searchTerm: string,
  projects: Project[]
): Project[] {
  const term = searchTerm.toLowerCase().trim();
  
  if (!term) return projects;
  
  return projects.filter(proj =>
    proj.projectName.toLowerCase().includes(term) ||
    proj.projectCode.toLowerCase().includes(term) ||
    proj.projectManager?.toLowerCase().includes(term) ||
    proj.description?.toLowerCase().includes(term)
  );
}

/**
 * Format Project Display (แสดงชื่อ)
 * 
 * @param project - Project object
 * @param includeCode - แสดงรหัสด้วยไหม
 * @returns String แสดงผล
 * 
 * @example
 * formatProjectDisplay(project, true)
 * // => "D26-0003 - โครงการพัฒนาระบบสารบรรณอิเล็กทรอนิกส์"
 */
export function formatProjectDisplay(
  project: Project,
  includeCode: boolean = true
): string {
  if (includeCode) {
    return `${project.projectCode} - ${project.projectName}`;
  }
  return project.projectName;
}

/**
 * Format Project Display พร้อม Organization
 * 
 * @param project - Project object
 * @param organization - Organization object
 * @returns String แสดงผล
 * 
 * @example
 * formatProjectWithOrganization(project, org)
 * // => "VRU D26-0003 - โครงการพัฒนาระบบสารบรรณอิเล็กทรอนิกส์"
 */
export function formatProjectWithOrganization(
  project: Project,
  organization?: Organization
): string {
  if (!organization) {
    return formatProjectDisplay(project);
  }
  
  return `${organization.organizationShortName} ${project.projectCode} - ${project.projectName}`;
}

/**
 * เรียงลำดับ Projects ตามรหัส
 * 
 * @param projects - Array of projects
 * @param order - 'asc' | 'desc'
 * @returns Sorted array
 */
export function sortProjectsByCode(
  projects: Project[],
  order: 'asc' | 'desc' = 'asc'
): Project[] {
  return [...projects].sort((a, b) => {
    const comparison = a.projectCode.localeCompare(b.projectCode);
    return order === 'asc' ? comparison : -comparison;
  });
}

/**
 * เรียงลำดับ Projects ตามชื่อ
 * 
 * @param projects - Array of projects
 * @param order - 'asc' | 'desc'
 * @returns Sorted array
 */
export function sortProjectsByName(
  projects: Project[],
  order: 'asc' | 'desc' = 'asc'
): Project[] {
  return [...projects].sort((a, b) => {
    const comparison = a.projectName.localeCompare(b.projectName, 'th');
    return order === 'asc' ? comparison : -comparison;
  });
}

/**
 * เรียงลำดับ Projects ตาม startDate (ใหม่ล่าสุดก่อน)
 * 
 * @param projects - Array of projects
 * @param order - 'asc' | 'desc'
 * @returns Sorted array
 */
export function sortProjectsByStartDate(
  projects: Project[],
  order: 'desc' | 'asc' = 'desc'
): Project[] {
  return [...projects].sort((a, b) => {
    if (!a.startDate && !b.startDate) return 0;
    if (!a.startDate) return 1;
    if (!b.startDate) return -1;
    
    const comparison = a.startDate.getTime() - b.startDate.getTime();
    return order === 'desc' ? -comparison : comparison;
  });
}

/**
 * เช็คว่า Project กำลังดำเนินการอยู่หรือไม่
 * 
 * @param project - Project object
 * @returns Boolean
 */
export function isProjectActive(project: Project): boolean {
  if (project.projectStatus !== 'active') return false;
  
  const now = new Date();
  
  // ถ้ามี startDate และยังไม่ถึงวันเริ่ม
  if (project.startDate && project.startDate > now) return false;
  
  // ถ้ามี endDate และเกินวันสิ้นสุดแล้ว
  if (project.endDate && project.endDate < now) return false;
  
  return true;
}

/**
 * เช็คว่า Project หมดอายุหรือไม่
 * 
 * @param project - Project object
 * @returns Boolean
 */
export function isProjectExpired(project: Project): boolean {
  if (!project.endDate) return false;
  return project.endDate < new Date();
}

/**
 * คำนวณความคืบหน้าของโครงการ (%)
 * 
 * @param project - Project object
 * @returns เปอร์เซ็นต์ 0-100
 */
export function calculateProjectProgress(project: Project): number {
  if (!project.startDate || !project.endDate) return 0;
  
  const now = new Date();
  const start = project.startDate.getTime();
  const end = project.endDate.getTime();
  const current = now.getTime();
  
  if (current < start) return 0;
  if (current > end) return 100;
  
  const progress = ((current - start) / (end - start)) * 100;
  return Math.round(progress);
}

/**
 * คำนวณจำนวนวันที่เหลือ
 * 
 * @param project - Project object
 * @returns จำนวนวัน (ถ้าเป็นลบ = เลยกำหนดแล้ว)
 */
export function getDaysRemaining(project: Project): number | null {
  if (!project.endDate) return null;
  
  const now = new Date();
  const end = project.endDate;
  
  const diffTime = end.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
}

/**
 * สร้างรหัสโครงการใหม่แบบอัตโนมัติ
 * 
 * @param projects - Array of projects
 * @param year - ปี (default = ปีปัจจุบัน)
 * @returns รหัสโครงการใหม่
 * 
 * @example
 * generateProjectCode(projects, 2026)
 * // => "D26-0025" (ถ้ามี 24 โครงการในปี 2026 อยู่แล้ว)
 * 
 * @format D{YY}-{NNNN}
 * - D = นำหน้าคงที่
 * - YY = ปี 2 หลักสุดท้าย (26)
 * - NNNN = เลขที่โครงการ 4 หลัก (0001-9999)
 */
export function generateProjectCode(
  projects: Project[],
  year: number = new Date().getFullYear()
): string {
  const yearShort = year.toString().slice(-2); // เอา 2 หลักสุดท้าย (2026 -> 26)
  const prefix = `D${yearShort}-`;
  
  // นับโครงการที่มีรหัสขึ้นต้นด้วย prefix นี้
  const projectsInYear = projects.filter(p => p.projectCode.startsWith(prefix));
  const nextNumber = projectsInYear.length + 1;
  
  // Format เป็น 4 หลัก (0001, 0002, ...)
  const numberPadded = nextNumber.toString().padStart(4, '0');
  
  return `${prefix}${numberPadded}`;
}

/**
 * Group Projects ตาม Organization
 * 
 * @param projects - Array of projects
 * @returns Object grouped by organizationId
 */
export function groupProjectsByOrganization(
  projects: Project[]
): Record<string, Project[]> {
  return projects.reduce((acc, proj) => {
    if (!acc[proj.organizationId]) {
      acc[proj.organizationId] = [];
    }
    acc[proj.organizationId].push(proj);
    return acc;
  }, {} as Record<string, Project[]>);
}

/**
 * Group Projects ตาม status
 * 
 * @param projects - Array of projects
 * @returns Object grouped by status
 */
export function groupProjectsByStatus(
  projects: Project[]
): Record<ProjectStatus, Project[]> {
  return projects.reduce((acc, proj) => {
    if (!acc[proj.projectStatus]) {
      acc[proj.projectStatus] = [];
    }
    acc[proj.projectStatus].push(proj);
    return acc;
  }, {} as Record<ProjectStatus, Project[]>);
}

/**
 * คำนวณงบประมาณรวมของ Projects
 * 
 * @param projects - Array of projects
 * @returns งบประมาณรวม (บาท)
 */
export function calculateTotalBudget(projects: Project[]): number {
  return projects.reduce((total, proj) => {
    return total + (proj.budget || 0);
  }, 0);
}

/**
 * Format งบประมาณ (เพิ่มคอมม่า)
 * 
 * @param budget - จำนวนเงิน
 * @returns String with comma
 * 
 * @example
 * formatBudget(5000000)
 * // => "5,000,000"
 */
export function formatBudget(budget: number): string {
  return budget.toLocaleString('th-TH');
}