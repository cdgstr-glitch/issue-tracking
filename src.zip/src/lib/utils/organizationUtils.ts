/**
 * 🏢 Organization Utilities
 * 
 * @description Helper functions สำหรับจัดการ Organizations
 * @version 1.0 - Phase 1
 */

import { Organization, OrganizationType } from '../../types';

/**
 * หา Organization จาก ID
 * 
 * @param id - Organization ID
 * @param organizations - Array of organizations
 * @returns Organization หรือ undefined
 */
export function getOrganizationById(
  id: string,
  organizations: Organization[]
): Organization | undefined {
  return organizations.find(org => org.id === id);
}

/**
 * หา Organization จาก organizationCode
 * 
 * @param organizationCode - รหัสหน่วยงาน เช่น 'D26-2002'
 * @param organizations - Array of organizations
 * @returns Organization หรือ undefined
 */
export function getOrganizationByCode(
  organizationCode: string,
  organizations: Organization[]
): Organization | undefined {
  return organizations.find(
    org => org.organizationCode === organizationCode
  );
}

/**
 * หา Organization จาก organizationShortName
 * 
 * @param organizationShortName - ชื่อย่อ เช่น 'VRU', 'GPO'
 * @param organizations - Array of organizations
 * @returns Organization หรือ undefined
 */
export function getOrganizationByShortName(
  organizationShortName: string,
  organizations: Organization[]
): Organization | undefined {
  const normalized = organizationShortName.toUpperCase().trim();
  return organizations.find(
    org => org.organizationShortName.toUpperCase() === normalized
  );
}

/**
 * กรอง Organizations ตาม organizationType
 * 
 * @param organizationType - ประเภทองค์กร
 * @param organizations - Array of organizations
 * @returns Array of organizations
 */
export function getOrganizationsByType(
  organizationType: OrganizationType,
  organizations: Organization[]
): Organization[] {
  return organizations.filter(
    org => org.organizationType === organizationType
  );
}

/**
 * กรอง Organizations ตาม department
 * 
 * @param department - หน่วยงาน
 * @param organizations - Array of organizations
 * @returns Array of organizations
 */
export function getOrganizationsByDepartment(
  department: string,
  organizations: Organization[]
): Organization[] {
  return organizations.filter(
    org => org.department?.toLowerCase().includes(department.toLowerCase())
  );
}

/**
 * ค้นหา Organizations (ชื่อ, ชื่อย่อ, รหัส)
 * 
 * @param searchTerm - คำค้นหา
 * @param organizations - Array of organizations
 * @returns Array of organizations
 */
export function searchOrganizations(
  searchTerm: string,
  organizations: Organization[]
): Organization[] {
  const term = searchTerm.toLowerCase().trim();
  
  if (!term) return organizations;
  
  return organizations.filter(org =>
    org.organizationName.toLowerCase().includes(term) ||
    org.organizationShortName.toLowerCase().includes(term) ||
    org.organizationCode.toLowerCase().includes(term) ||
    org.department?.toLowerCase().includes(term)
  );
}

/**
 * Format Organization Display (แสดงชื่อ)
 * 
 * @param organization - Organization object
 * @returns String แสดงผล
 * 
 * @example
 * formatOrganizationDisplay(org)
 * // => "VRU - มหาวิทยาลัยราชภัฏวไลยอลงกรณ์ ในพระบรมราชูปถัมภ์"
 */
export function formatOrganizationDisplay(organization: Organization): string {
  return `${organization.organizationShortName} - ${organization.organizationName}`;
}

/**
 * Format Organization Short (แสดงชื่อย่อ + รหัส)
 * 
 * @param organization - Organization object
 * @returns String แสดงผล
 * 
 * @example
 * formatOrganizationShort(org)
 * // => "VRU (D26-2002)"
 */
export function formatOrganizationShort(organization: Organization): string {
  return `${organization.organizationShortName} (${organization.organizationCode})`;
}

/**
 * เรียงลำดับ Organizations ตามชื่อย่อ
 * 
 * @param organizations - Array of organizations
 * @param order - 'asc' | 'desc'
 * @returns Sorted array
 */
export function sortOrganizationsByShortName(
  organizations: Organization[],
  order: 'asc' | 'desc' = 'asc'
): Organization[] {
  return [...organizations].sort((a, b) => {
    const nameA = a.organizationShortName || '';
    const nameB = b.organizationShortName || '';
    const comparison = nameA.localeCompare(nameB);
    return order === 'asc' ? comparison : -comparison;
  });
}

/**
 * เรียงลำดับ Organizations ตามชื่อเต็ม
 * 
 * @param organizations - Array of organizations
 * @param order - 'asc' | 'desc'
 * @returns Sorted array
 */
export function sortOrganizationsByName(
  organizations: Organization[],
  order: 'asc' | 'desc' = 'asc'
): Organization[] {
  return [...organizations].sort((a, b) => {
    const nameA = a.organizationName || '';
    const nameB = b.organizationName || '';
    const comparison = nameA.localeCompare(nameB, 'th');
    return order === 'asc' ? comparison : -comparison;
  });
}

/**
 * เช็คว่า Organization มีข้อมูลติดต่อครบหรือไม่
 * 
 * @param organization - Organization object
 * @returns Boolean
 */
export function hasCompleteContactInfo(organization: Organization): boolean {
  return !!(
    organization.contactPerson &&
    (organization.contactEmail || organization.contactPhone)
  );
}

/**
 * Group Organizations ตาม type
 * 
 * @param organizations - Array of organizations
 * @returns Object grouped by type
 */
export function groupOrganizationsByType(
  organizations: Organization[]
): Record<OrganizationType, Organization[]> {
  return organizations.reduce((acc, org) => {
    if (!acc[org.organizationType]) {
      acc[org.organizationType] = [];
    }
    acc[org.organizationType].push(org);
    return acc;
  }, {} as Record<OrganizationType, Organization[]>);
}

/**
 * นับจำนวน Organizations ตาม type
 * 
 * @param organizationType - ประเภทองค์กร
 * @param organizations - Array of organizations
 * @returns จำนวน
 */
export function countOrganizationsByType(
  organizationType: OrganizationType,
  organizations: Organization[]
): number {
  return organizations.filter(
    org => org.organizationType === organizationType
  ).length;
}
