/**
 * 📥 Data Import Utilities
 * 
 * @description Helper functions สำหรับ Import ข้อมูล Organization/Project
 * @version 1.0 - Phase 5
 */

import { Organization, Project, OrganizationType, ProjectStatus } from '../../types';

/**
 * Validate Organization data
 */
function validateOrganization(data: any): data is Organization {
  return (
    typeof data.id === 'string' &&
    typeof data.organizationCode === 'string' &&
    typeof data.organizationShortName === 'string' &&
    typeof data.organizationName === 'string' &&
    typeof data.organizationType === 'string'
  );
}

/**
 * Validate Project data
 */
function validateProject(data: any): data is Project {
  return (
    typeof data.id === 'string' &&
    typeof data.projectCode === 'string' &&
    typeof data.projectName === 'string' &&
    typeof data.organizationId === 'string' &&
    typeof data.projectStatus === 'string'
  );
}

/**
 * Parse CSV to Organizations
 */
export function parseCSVToOrganizations(csvContent: string): Organization[] {
  const lines = csvContent.trim().split('\n');
  
  if (lines.length < 2) {
    throw new Error('ไฟล์ CSV ไม่มีข้อมูล');
  }
  
  // Skip header
  const dataLines = lines.slice(1);
  
  const organizations: Organization[] = [];
  
  for (let i = 0; i < dataLines.length; i++) {
    const line = dataLines[i].trim();
    if (!line) continue;
    
    // Simple CSV parser (handles quoted fields)
    const fields = line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g) || [];
    const cleanFields = fields.map(f => f.replace(/^"|"$/g, '').trim());
    
    if (cleanFields.length < 5) {
      console.warn(`Row ${i + 2}: ข้อมูลไม่ครบ`);
      continue;
    }
    
    const [
      id,
      organizationCode,
      organizationShortName,
      organizationName,
      organizationType,
      department,
      contactPerson,
      contactEmail,
      contactPhone
    ] = cleanFields;
    
    const org: Organization = {
      id: id || `org-${Date.now()}-${i}`,
      organizationCode,
      organizationShortName,
      organizationName,
      organizationType: organizationType as OrganizationType,
      department: department || undefined,
      contactPerson: contactPerson || undefined,
      contactEmail: contactEmail || undefined,
      contactPhone: contactPhone || undefined
    };
    
    if (validateOrganization(org)) {
      organizations.push(org);
    } else {
      console.warn(`Row ${i + 2}: ข้อมูลไม่ถูกต้อง`);
    }
  }
  
  return organizations;
}

/**
 * Parse CSV to Projects
 */
export function parseCSVToProjects(csvContent: string): Project[] {
  const lines = csvContent.trim().split('\n');
  
  if (lines.length < 2) {
    throw new Error('ไฟล์ CSV ไม่มีข้อมูล');
  }
  
  // Skip header
  const dataLines = lines.slice(1);
  
  const projects: Project[] = [];
  
  for (let i = 0; i < dataLines.length; i++) {
    const line = dataLines[i].trim();
    if (!line) continue;
    
    const fields = line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g) || [];
    const cleanFields = fields.map(f => f.replace(/^"|"$/g, '').trim());
    
    if (cleanFields.length < 5) {
      console.warn(`Row ${i + 2}: ข้อมูลไม่ครบ`);
      continue;
    }
    
    const [
      id,
      projectCode,
      projectName,
      organizationId,
      ,  // organizationName (skip)
      projectStatus,
      projectManager,
      budgetStr,
      startDateStr,
      endDateStr,
      description
    ] = cleanFields;
    
    const project: Project = {
      id: id || `proj-${Date.now()}-${i}`,
      projectCode,
      projectName,
      organizationId,
      projectStatus: (projectStatus as ProjectStatus) || 'active',
      projectManager: projectManager || undefined,
      budget: budgetStr ? parseFloat(budgetStr) : undefined,
      startDate: startDateStr ? new Date(startDateStr) : undefined,
      endDate: endDateStr ? new Date(endDateStr) : undefined,
      description: description || undefined
    };
    
    if (validateProject(project)) {
      projects.push(project);
    } else {
      console.warn(`Row ${i + 2}: ข้อมูลไม่ถูกต้อง`);
    }
  }
  
  return projects;
}

/**
 * Parse JSON to Organizations
 */
export function parseJSONToOrganizations(jsonContent: string): Organization[] {
  try {
    const data = JSON.parse(jsonContent);
    
    // Check if it's array or object with organizations property
    const orgs = Array.isArray(data) ? data : data.organizations;
    
    if (!Array.isArray(orgs)) {
      throw new Error('รูปแบบ JSON ไม่ถูกต้อง');
    }
    
    return orgs.filter(validateOrganization);
  } catch (error) {
    throw new Error(`ไม่สามารถอ่านไฟล์ JSON: ${error}`);
  }
}

/**
 * Parse JSON to Projects
 */
export function parseJSONToProjects(jsonContent: string): Project[] {
  try {
    const data = JSON.parse(jsonContent);
    
    // Check if it's array or object with projects property
    const projects = Array.isArray(data) ? data : data.projects;
    
    if (!Array.isArray(projects)) {
      throw new Error('รูปแบบ JSON ไม่ถูกต้อง');
    }
    
    // Convert date strings to Date objects
    return projects
      .map(proj => ({
        ...proj,
        startDate: proj.startDate ? new Date(proj.startDate) : undefined,
        endDate: proj.endDate ? new Date(proj.endDate) : undefined
      }))
      .filter(validateProject);
  } catch (error) {
    throw new Error(`ไม่สามารถอ่านไฟล์ JSON: ${error}`);
  }
}

/**
 * Read file content
 */
export function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const content = e.target?.result as string;
      resolve(content);
    };
    
    reader.onerror = () => {
      reject(new Error('ไม่สามารถอ่านไฟล์ได้'));
    };
    
    reader.readAsText(file, 'UTF-8');
  });
}

/**
 * Import Organizations from file
 */
export async function importOrganizations(file: File): Promise<Organization[]> {
  const content = await readFile(file);
  const ext = file.name.split('.').pop()?.toLowerCase();
  
  if (ext === 'csv') {
    return parseCSVToOrganizations(content);
  } else if (ext === 'json') {
    return parseJSONToOrganizations(content);
  } else {
    throw new Error('รองรับเฉพาะไฟล์ .csv หรือ .json เท่านั้น');
  }
}

/**
 * Import Projects from file
 */
export async function importProjects(file: File): Promise<Project[]> {
  const content = await readFile(file);
  const ext = file.name.split('.').pop()?.toLowerCase();
  
  if (ext === 'csv') {
    return parseCSVToProjects(content);
  } else if (ext === 'json') {
    return parseJSONToProjects(content);
  } else {
    throw new Error('รองรับเฉพาะไฟล์ .csv หรือ .json เท่านั้น');
  }
}

/**
 * Validate imported data against existing data
 */
export function validateImportedData(
  imported: Organization[] | Project[],
  existing: Organization[] | Project[]
): {
  valid: typeof imported;
  duplicates: typeof imported;
  errors: string[];
} {
  const existingIds = new Set(existing.map(item => item.id));
  const valid: typeof imported = [];
  const duplicates: typeof imported = [];
  const errors: string[] = [];
  
  imported.forEach((item, index) => {
    if (existingIds.has(item.id)) {
      duplicates.push(item);
      errors.push(`แถวที่ ${index + 1}: ID ${item.id} ซ้ำกับข้อมูลเดิม`);
    } else {
      valid.push(item);
    }
  });
  
  return { valid, duplicates, errors };
}
