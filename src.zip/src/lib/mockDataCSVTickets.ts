// ✅ Tickets จาก CSV ระบบสารบรรณ (5-12 มกราคม 2026)
// สร้างจากข้อมูลจริง พร้อม Smart Enrichment

import { Ticket, Comment, TimelineEvent, Attachment } from '../types';
import { csvProjects, getProjectByShortName } from './mockDataCSVProjects';
import { allCSVUsers, getUserByName } from './mockDataCSVUsers';

// ==================== HELPER FUNCTIONS ====================

function parseCSVDate(dateStr: string, timeStr: string): Date {
  // dateStr format: "5/1/2026" or "12/1/2026"
  // timeStr format: "10:07" or "10:07:00"
  const [day, month, year] = dateStr.split('/').map(Number);
  const [hour, minute] = timeStr.split(':').map(Number);
  return new Date(year, month - 1, day, hour, minute || 0);
}

function determineType(title: string, resolution: string): 'bug' | 'feature' | 'support' | 'incident' {
  const combined = (title + ' ' + resolution).toLowerCase();
  
  if (combined.includes('ไม่สามารถใช้งานได้') || combined.includes('ระบบล่ม') || combined.includes('error') || combined.includes('ข้อผิดพลาด')) {
    return 'incident';
  }
  
  if (combined.includes('แจ้งขอเพิ่ม') || combined.includes('แจ้งเพิ่ม') || combined.includes('ขอเปลี่ยน') || combined.includes('แจ้งขอแก้ไข')) {
    return 'feature';
  }
  
  if (combined.includes('สอบถาม') || combined.includes('รบกวนสอบถาม') || combined.includes('วิธีการ') || combined.includes('แนะนำ')) {
    return 'support';
  }
  
  // Default: bug
  return 'bug';
}

function determinePriority(title: string, resolution: string, type: string): 'critical' | 'high' | 'medium' | 'low' {
  const combined = (title + ' ' + resolution).toLowerCase();
  
  if (combined.includes('ระบบไม่สามารถใช้งานได้') || combined.includes('ล่ม') || combined.includes('เข้าระบบไม่ได้')) {
    return 'critical';
  }
  
  if (type === 'incident' || combined.includes('error') || combined.includes('แจ้งตรวจสอบ') || combined.includes('พบปัญหา')) {
    return 'high';
  }
  
  if (type === 'feature' || combined.includes('แจ้งขอเพิ่ม') || combined.includes('แก้ไข')) {
    return 'medium';
  }
  
  return 'low';
}

function mapChannel(channel: string): 'portal' | 'email' | 'phone' | 'line' {
  const lower = channel.toLowerCase();
  if (lower.includes('line')) return 'line';
  if (lower.includes('email') || lower.includes('อีเมล')) return 'email';
  if (lower.includes('โทร')) return 'phone';
  return 'portal';
}

function createTimeline(
  createdAt: Date,
  actionDate?: Date,
  completedDate?: Date,
  assignee?: string,
  assigneeName?: string
): TimelineEvent[] {
  const timeline: TimelineEvent[] = [
    {
      id: `event-${Date.now()}-1`,
      ticketId: '',
      type: 'created',
      timestamp: createdAt,
      userId: 'system',
      userName: 'ระบบ',
      description: 'สร้างเคสใหม่',
      isInternal: false
    }
  ];

  if (actionDate) {
    timeline.push({
      id: `event-${Date.now()}-2`,
      ticketId: '',
      type: 'assignment',
      timestamp: actionDate,
      userId: 'system',
      userName: 'ระบบ',
      description: `มอบหมายให้ ${assigneeName || 'เจ้าหน้าที่'}`,
      isInternal: false
    });

    timeline.push({
      id: `event-${Date.now()}-3`,
      ticketId: '',
      type: 'status_change',
      timestamp: new Date(actionDate.getTime() + 1000), // +1 second after assignment
      userId: assignee || 'system',
      userName: assigneeName || 'เจ้าหน้าที่',
      description: 'เปลี่ยนสถานะเป็น: กำลังดำเนินการ',
      isInternal: false
    });
  }

  if (completedDate) {
    timeline.push({
      id: `event-${Date.now()}-4`,
      ticketId: '',
      type: 'resolved',
      timestamp: completedDate,
      userId: assignee || 'system',
      userName: assigneeName || 'เจ้าหน้าที่',
      description: 'แก้ไขปัญหาเสร็จสิ้น',
      isInternal: false
    });

    timeline.push({
      id: `event-${Date.now()}-5`,
      ticketId: '',
      type: 'closed',
      timestamp: new Date(completedDate.getTime() + 60000), // +1 minute after resolved
      userId: assignee || 'system',
      userName: assigneeName || 'เจ้าหน้าที่',
      description: 'ปิดเคส',
      isInternal: false
    });
  }

  return timeline;
}

function createComments(resolution: string, assignee?: string, assigneeName?: string, completedDate?: Date): Comment[] {
  if (!resolution || resolution === '') return [];
  
  return [{
    id: `comment-${Date.now()}`,
    ticketId: '',
    userId: assignee || 'system',
    userName: assigneeName || 'ระบบ',
    author: assigneeName || 'ระบบ', // ✅ เพิ่ม author field
    authorRole: 'staff',
    content: resolution,
    createdAt: completedDate || new Date(),
    isInternal: false,
    attachments: []
  }];
}

// ==================== CSV TICKETS DATA ====================

export const csvTicketsRaw: Ticket[] = [
  // CDGS-001: ERC - สอบถามเลขจอง
  {
    id: 'ticket-csv-001',
    ticketNumber: 'CDGS-001',
    title: 'สอบถามเกี่ยวกับเลขจอง กรณีมีการจองเลขจองไว้วันที่ 30 ธันวาคม 2568 แต่พอจะมาใช้งานในวันนี้ไม่สามารถใช้งานเลขจองได้',
    description: 'ระบบขึ้นว่าจำนวนเลขจองไม่เพียงพอ ต้องการตรวจสอบสาเหตุและวิธีแก้ไข',
    status: 'closed',
    type: 'support',
    channel: 'line',
    priority: 'medium',
    category: 'ระบบสารบรรณ',
    product: 'ระบบจองเลขหนังสือ',
    department: 'ERC',
    customerName: 'คุณ Salila',
    customerEmail: 'salila@erc.or.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-002',
    projectId: 'proj-csv-001',
    projectCode: 'D26-0001', // ✅ แก้ไขจาก D26-1001
    projectName: 'สำนักงานคณะกรรมการกำกับกิจการพลังงาน',
    projectShortName: 'ERC',
    createdBy: 'user-customer-001',
    createdByName: 'คุณ Salila',
    createdAt: parseCSVDate('5/1/2026', '10:07'),
    updatedAt: parseCSVDate('5/1/2026', '10:18'),
    dueDate: new Date('2026-01-07T10:07:00'),
    resolvedAt: parseCSVDate('5/1/2026', '10:18'),
    resolvedBy: 'user-003',
    closedAt: parseCSVDate('5/1/2026', '10:18'),
    closedBy: 'user-003',
    solution: 'ดำเนินการตรวจสอบ พบว่ามีเลขจองในระบบ ที่ผู้ใช้งานไม่สามารถใช้เลขจองได้เกิดจากการเลือกวันที่ ผู้ใช้งานต้องทำการเปลี่ยนวันที่เป็นของปี 2568 จึงจะสามารถใช้งานเลขจองได้',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '10:07'),
      parseCSVDate('5/1/2026', '10:07'),
      parseCSVDate('5/1/2026', '10:18'),
      'user-003',
      'วรรณภา แซ่ด่าง'
    ),
    comments: createComments(
      'ดำเนินการตรวจสอบ พบว่ามีเลขจองในระบบ ที่ผู้ใช้งานไม่สามารถใช้เลขจองได้เกิดจากการเลือกวันที่ ผู้ใช้งานต้องทำการเปลี่ยนวันที่เป็นของปี 2568 จึงจะสามารถใช้งานเลขจองได้',
      'user-003',
      'วรรณภา แซ่ด่าง',
      parseCSVDate('5/1/2026', '10:18')
    )
  },

  // CDGS-002: RMUTP - ลบเลขจอง
  {
    id: 'ticket-csv-002',
    ticketNumber: 'CDGS-002',
    title: 'สอบถามเกี่ยวกับการลบเลขหนังสือที่จองไปแล้ว ต้องดำเนินการอย่างไร',
    description: 'ต้องการทราบวิธีการลบเลขจองที่ทำการจองไว้แล้ว',
    status: 'closed',
    type: 'support',
    channel: 'line',
    priority: 'low',
    category: 'ระบบสารบรรณ',
    product: 'ระบบจองเลขหนังสือ',
    department: 'RMUTP',
    customerName: 'คุณ Nop',
    customerEmail: 'nop@rmutp.ac.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-005',
    projectId: 'proj-csv-002',
    projectCode: 'D26-0002', // ✅ แก้ไขจาก D26-2001
    projectName: 'มหาวิทยาลัยเทคโนโลยีราชมงคลพระนคร',
    projectShortName: 'RMUTP',
    createdBy: 'user-customer-003',
    createdByName: 'คุณ Nop',
    createdAt: parseCSVDate('5/1/2026', '9:51'),
    updatedAt: parseCSVDate('5/1/2026', '10:05'),
    dueDate: new Date('2026-01-07T09:51:00'),
    resolvedAt: parseCSVDate('5/1/2026', '10:05'),
    resolvedBy: 'user-005',
    closedAt: parseCSVDate('5/1/2026', '10:05'),
    closedBy: 'user-005',
    solution: 'ชี้แจงผู้ใช้งานว่าเลขจองไม่สามารถลบได้ แนะนำให้ทำการออกหนังสือและลบหนังสือแทน',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '9:51'),
      parseCSVDate('5/1/2026', '9:51'),
      parseCSVDate('5/1/2026', '10:05'),
      'user-005',
      'ธัญญาพร ทองแก้ว'
    ),
    comments: createComments(
      'ชี้แจงผู้ใช้งานว่าเลขจองไม่สามารถลบได้ แนะนำให้ทำการออกหนังสือและลบหนังสือแทน',
      'user-005',
      'ธัญญาพร ทองแก้ว',
      parseCSVDate('5/1/2026', '10:05')
    )
  },

  // CDGS-003: RMUTP - แจ้งขอตัดข้อความ (Feature Request)
  {
    id: 'ticket-csv-003',
    ticketNumber: 'CDGS-003',
    title: 'แจ้งขอตัดข้อความที่แสดงบนหน้าจอหลังพยายามลบเลขจอง',
    description: 'โดยลบคำว่า \"ติดต่อเจ้าหน้าที่เพื่อทำการแก้ไข\" ออก เนื่องจากผู้ใช้งานเกิดความเข้าใจผิดว่าแอดมินสามารถแก้ไขได้',
    status: 'closed',
    type: 'feature',
    channel: 'line',
    priority: 'medium',
    category: 'ระบบสารบรรณ',
    product: 'UI/UX Improvement',
    department: 'RMUTP',
    customerName: 'คุณ Nop',
    customerEmail: 'nop@rmutp.ac.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-005',
    projectId: 'proj-csv-002',
    projectCode: 'D26-0002', // ✅ แก้ไขจาก D26-2001
    projectName: 'มหาวิทยาลัยเทคโนโลยีราชมงคลพระนคร',
    projectShortName: 'RMUTP',
    createdBy: 'user-customer-003',
    createdByName: 'คุณ Nop',
    createdAt: parseCSVDate('5/1/2026', '10:05'),
    updatedAt: parseCSVDate('5/1/2026', '10:07'),
    dueDate: new Date('2026-01-07T10:05:00'),
    resolvedAt: parseCSVDate('5/1/2026', '10:07'),
    resolvedBy: 'user-005',
    closedAt: parseCSVDate('5/1/2026', '10:07'),
    closedBy: 'user-005',
    solution: 'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '10:05'),
      parseCSVDate('5/1/2026', '10:05'),
      parseCSVDate('5/1/2026', '10:07'),
      'user-005',
      'ธัญญาพร ทองแก้ว'
    ),
    comments: createComments(
      'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข',
      'user-005',
      'ธัญญาพร ทองแก้ว',
      parseCSVDate('5/1/2026', '10:07')
    )
  },

  // CDGS-004: VRU - ปัญหาหนังสือคำสั่ง
  {
    id: 'ticket-csv-004',
    ticketNumber: 'CDGS-004',
    title: 'พบปัญหาหนังสือคำสั่งที่สร้างหนังสือไว้ตั้งแต่ปี 2568 เมื่อกดออกเลขปี 2569 ระบบไม่เปลี่ยนทับปี พ.ศ. เป็นปี 2569',
    description: 'ต้องการแก้ไขปัญหาการทับปี พ.ศ. ที่ไม่ถูกต้อง',
    status: 'closed',
    type: 'bug',
    channel: 'line',
    priority: 'high',
    category: 'ระบบสารบรรณ',
    product: 'ระบบหนังสือคำสั่ง',
    department: 'VRU',
    customerName: 'คุณ Trinpisit',
    customerEmail: 'trinpisit@vru.ac.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-005',
    projectId: 'proj-csv-003',
    projectCode: 'D26-0003', // ✅ แก้ไขจาก D26-2002
    projectName: 'มหาวิทยาลัยราชภัฏวไลยอลงกรณ์ ในพระบรมราชูปถัมภ์',
    projectShortName: 'VRU',
    createdBy: 'user-customer-004',
    createdByName: 'คุณ Trinpisit',
    createdAt: parseCSVDate('5/1/2026', '9:00'),
    updatedAt: parseCSVDate('5/1/2026', '9:13'),
    dueDate: new Date('2026-01-07T09:00:00'),
    resolvedAt: parseCSVDate('5/1/2026', '9:13'),
    resolvedBy: 'user-005',
    closedAt: parseCSVDate('5/1/2026', '9:13'),
    closedBy: 'user-005',
    solution: 'แนะนำผู้ใช้งาน กดปุ่มแก้ไขหนังสือ ทำการคลิกเอาเครื่องหมายถูกที่ทับปี พ.ศ. ออกก่อน แล้วคลิกเลือกใหม่อีกครั้ง ทำการบันทึกการแก้ไข หนังสือจะเป็นทับปี 2569 และทำการร่างหนังสือใหม่อีกครั้ง',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '9:00'),
      parseCSVDate('5/1/2026', '9:00'),
      parseCSVDate('5/1/2026', '9:13'),
      'user-005',
      'ธัญญาพร ทองแก้ว'
    ),
    comments: createComments(
      'แนะนำผู้ใช้งาน กดปุ่มแก้ไขหนังสือ ทำการคลิกเอาเครื่องหมายถูกที่ทับปี พ.ศ. ออกก่อน แล้วคลิกเลือกใหม่อีกครั้ง ทำการบันทึกการแก้ไข หนังสือจะเป็นทับปี 2569 และทำการร่างหนังสือใหม่อีกครั้ง',
      'user-005',
      'ธัญญาพร ทองแก้ว',
      parseCSVDate('5/1/2026', '9:13')
    )
  },

  // CDGS-005: GPO - สอบถามเลขจอง
  {
    id: 'ticket-csv-005',
    ticketNumber: 'CDGS-005',
    title: 'สอบถามเกี่ยวกับเลขจอง กรณีผู้ใช้งานลืมจองเลขที่หนังสือสามารถเอาเลขจองที่เคยทำผิดมาทำการแก้ไขเพื่อเอาเลขคืนได้หรือไม่',
    description: 'ต้องการทราบว่าสามารถแก้ไขเลขจองที่ทำผิดได้หรือไม่',
    status: 'closed',
    type: 'support',
    channel: 'line',
    priority: 'low',
    category: 'ระบบสารบรรณ',
    product: 'ระบบจองเลขหนังสือ',
    department: 'GPO',
    customerName: 'คุณลักษณ์',
    customerEmail: 'lak@gpo.or.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-005',
    projectId: 'proj-csv-004',
    projectCode: 'D26-0005', // ✅ แก้ไขจาก D26-3001
    projectName: 'องค์การเภสัชกรรม',
    projectShortName: 'GPO',
    createdBy: 'user-customer-005',
    createdByName: 'คุณลักษณ์',
    createdAt: parseCSVDate('5/1/2026', '10:30'),
    updatedAt: parseCSVDate('5/1/2026', '10:31'),
    dueDate: new Date('2026-01-07T10:30:00'),
    resolvedAt: parseCSVDate('5/1/2026', '10:31'),
    resolvedBy: 'user-005',
    closedAt: parseCSVDate('5/1/2026', '10:31'),
    closedBy: 'user-005',
    solution: 'ชี้แจงผู้ใช้งานว่าเลขจองที่ออกไปแล้วไม่สามารถลบหรือแก้ไขได้ แนะนำผู้ใช้งานให้สร้างและใช้เลขจองใหม่ให้ถูกต้อง',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '10:30'),
      parseCSVDate('5/1/2026', '10:30'),
      parseCSVDate('5/1/2026', '10:31'),
      'user-005',
      'ธัญญาพร ทองแก้ว'
    ),
    comments: createComments(
      'ชี้แจงผู้ใช้งานว่าเลขจองที่ออกไปแล้วไม่สามารถลบหรือแก้ไขได้ แนะนำผู้ใช้งานให้สร้างและใช้เลขจองใหม่ให้ถูกต้อง',
      'user-005',
      'ธัญญาพร ทองแก้ว',
      parseCSVDate('5/1/2026', '10:31')
    )
  },

  // CDGS-006: FIO - รีเซ็ตรหัสผ่าน
  {
    id: 'ticket-csv-006',
    ticketNumber: 'CDGS-006',
    title: 'สอบถามการใช้งานระบบสารบรรณวิธีการรีเซ็ตรหัสผ่านการลงนาม',
    description: 'ต้องการทราบวิธีการรีเซ็ตรหัสผ่านการลงนาม',
    status: 'closed',
    type: 'support',
    channel: 'phone',
    priority: 'low',
    category: 'ระบบสารบรรณ',
    product: 'ระบบลงนามอิเล็กทรอนิกส์',
    department: 'FIO',
    customerName: 'คุณ เหน่ง',
    customerEmail: 'neng@sso.go.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-005',
    projectId: 'proj-csv-005',
    projectCode: 'D26-0006', // ✅ แก้ไขจาก D26-3002
    projectName: 'สำนักงานประกันสังคม',
    projectShortName: 'FIO',
    createdBy: 'user-customer-006',
    createdByName: 'คุณ เหน่ง',
    createdAt: parseCSVDate('6/1/2026', '11:17'),
    updatedAt: parseCSVDate('6/1/2026', '11:20'),
    dueDate: new Date('2026-01-08T11:17:00'),
    resolvedAt: parseCSVDate('6/1/2026', '11:20'),
    resolvedBy: 'user-005',
    closedAt: parseCSVDate('6/1/2026', '11:20'),
    closedBy: 'user-005',
    solution: 'ดำเนินการแนะนำวิธีการรีเซ็ตรหัสผ่านการลงนาม',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('6/1/2026', '11:17'),
      parseCSVDate('6/1/2026', '11:17'),
      parseCSVDate('6/1/2026', '11:20'),
      'user-005',
      'ธัญญาพร ทองแก้ว'
    ),
    comments: createComments(
      'ดำเนินการแนะนำวิธีการรีเซ็ตรหัสผ่านการลงนาม',
      'user-005',
      'ธัญญาพร ทองแก้ว',
      parseCSVDate('6/1/2026', '11:20')
    )
  },

  // CDGS-007: AMLO - อีเมลค้างอยู่ (Escalated to Tier 2)
  {
    id: 'ticket-csv-007',
    ticketNumber: 'CDGS-007',
    title: 'แจ้งตรวจสอบ มีอีเมลค้างอยู่ 453,786 เรื่อง ตั้งแต่ 8 พ.ค. - 30 ธค. 2568',
    description: 'พบว่ามีอีเมลค้างจำนวนมาก ต้องการตรวจสอบและแก้ไข',
    status: 'closed',
    type: 'bug',
    channel: 'line',
    priority: 'high',
    category: 'ระบบสารบรรณ',
    product: 'ระบบอีเมล',
    department: 'AMLO',
    customerName: 'คุณ Rungforever',
    customerEmail: 'rungforever@amlo.go.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-003',
    projectId: 'proj-csv-006',
    projectCode: 'D26-4001', // ✅ คืนค่ากลับมา - รูปแบบถูกต้องแล้ว
    projectName: 'สำนักงานป้องกันและปราบปรามการฟอกเงิน',
    projectShortName: 'AMLO',
    createdBy: 'user-customer-009',
    createdByName: 'คุณ Rungforever',
    createdAt: parseCSVDate('5/1/2026', '11:50'),
    updatedAt: parseCSVDate('5/1/2026', '12:06'),
    dueDate: new Date('2026-01-07T11:50:00'),
    resolvedAt: parseCSVDate('5/1/2026', '12:06'),
    resolvedBy: 'user-003',
    closedAt: parseCSVDate('5/1/2026', '12:06'),
    closedBy: 'user-003',
    solution: 'แจ้งทีมงานเพื่อตรวจสอบ ทีมงานแจ้งทำการ ลบเมลที่ดึงมา เป็น ชื่อเรื่อง Undelivered Mail Returned to Sender เรียบร้อยแล้ว',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '11:50'),
      parseCSVDate('5/1/2026', '11:50'),
      parseCSVDate('5/1/2026', '12:06'),
      'user-003',
      'วรรณภา แซ่ด่าง'
    ),
    comments: createComments(
      'แจ้งทีมงานเพื่อตรวจสอบ ทีมงานแจ้งทำการ ลบเมลที่ดึงมา เป็น ชื่อเรื่อง Undelivered Mail Returned to Sender เรียบร้อยแล้ว',
      'user-003',
      'วรรณภา แซ่ด่าง',
      parseCSVDate('5/1/2026', '12:06')
    )
  },

  // CDGS-008: AMLO - ระบบอีเมล์ไม่ดึง (Escalated to Tier 2)
  {
    id: 'ticket-csv-008',
    ticketNumber: 'CDGS-008',
    title: 'แจ้งตรวจสอบระบบอีเมล์ไม่ดึงเข้ามาในระบบสารบรรณ ตั้งแต่วันที่ 30 ธ.ค. 68',
    description: 'รบกวนช่วยตรวจสอบว่าทำไมอีเมล์ไม่ดึงเข้ามาอัตโนมัติ',
    status: 'closed',
    type: 'incident',
    channel: 'line',
    priority: 'critical',
    category: 'ระบบสารบรรณ',
    product: 'ระบบอีเมล',
    department: 'AMLO',
    customerName: 'คุณ Non Tacha',
    customerEmail: 'nontacha@amlo.go.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-003',
    projectId: 'proj-csv-006',
    projectCode: 'D26-4001', // ✅ คืนค่าเดิม (รูปแบบถูกต้องอยู่แล้ว)
    projectName: 'สำนักงานป้องกันและปราบปรามการฟอกเงิน',
    projectShortName: 'AMLO',
    createdBy: 'user-customer-009',
    createdByName: 'คุณ Non Tacha',
    createdAt: parseCSVDate('5/1/2026', '11:50'),
    updatedAt: parseCSVDate('5/1/2026', '13:31'),
    dueDate: new Date('2026-01-06T11:50:00'), // Critical = 1 day
    resolvedAt: parseCSVDate('5/1/2026', '13:31'),
    resolvedBy: 'user-003',
    closedAt: parseCSVDate('5/1/2026', '13:31'),
    closedBy: 'user-003',
    solution: 'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข ปัจจุบันอีเมลถูกดึงเข้าสู่ระบบอัตโนมัติตามปกติ',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '11:50'),
      parseCSVDate('5/1/2026', '11:50'),
      parseCSVDate('5/1/2026', '13:31'),
      'user-003',
      'วรรณภา แซ่ด่าง'
    ),
    comments: createComments(
      'แจ้งทีมงานเพื่อตรวจสอบและแก้ไข ปัจจุบันอีเมลถูกดึงเข้าสู่ระบบอัตโนมัติตามปกติ',
      'user-003',
      'วรรณภา แซ่ด่าง',
      parseCSVDate('5/1/2026', '13:31')
    )
  },

  // CDGS-009: DOH - ขอเพิ่มสมุดทะเบียนส่ง
  {
    id: 'ticket-csv-009',
    ticketNumber: 'CDGS-009',
    title: 'แจ้งขอเพิ่มสมุดทะเบียนส่ง ของสำนักรวดเร็วปลอดภัย กรมทางหลวง ทั้งหมด 6 เล่ม',
    description: 'ต้องการขอเพิ่มสมุดทะเบียนส่ง 6 เล่ม',
    status: 'closed',
    type: 'feature',
    channel: 'line',
    priority: 'medium',
    category: 'ระบบสารบรรณ',
    product: 'ระบบทะเบียนหนังสือ',
    department: 'DOH',
    customerName: 'คุณ Suthisak Mooyotha',
    customerEmail: 'suthisak@doh.go.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-002',
    projectId: 'proj-csv-007',
    projectCode: 'D26-5001', // ✅ คืนค่าเดิม (รูปแบบถูกต้องอยู่แล้ว)
    projectName: 'กรมทางหลวง',
    projectShortName: 'DOH',
    createdBy: 'user-customer-011',
    createdByName: 'คุณ Suthisak Mooyotha',
    createdAt: parseCSVDate('5/1/2026', '9:15'),
    updatedAt: parseCSVDate('5/1/2026', '9:34'),
    dueDate: new Date('2026-01-07T09:15:00'),
    resolvedAt: parseCSVDate('5/1/2026', '9:34'),
    resolvedBy: 'user-002',
    closedAt: parseCSVDate('5/1/2026', '9:34'),
    closedBy: 'user-002',
    solution: 'ดำเนินการเพิ่มสมุดทะเบียนส่งทั้ง 6 เล่มให้ ตามข้อมูลที่ผู้ใช้งานแจ้ง',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '9:15'),
      parseCSVDate('5/1/2026', '9:15'),
      parseCSVDate('5/1/2026', '9:34'),
      'user-002',
      'สาริน ช่อพะยอม'
    ),
    comments: createComments(
      'ดำเนินการเพิ่มสมุดทะเบียนส่งทั้ง 6 เล่มให้ ตามข้อมูลที่ผู้ใช้งานแจ้ง',
      'user-002',
      'สาริน ช่อพะยอม',
      parseCSVDate('5/1/2026', '9:34')
    )
  },

  // CDGS-010: DOH - ปิดการใช้งานทะเบียนส่ง
  {
    id: 'ticket-csv-010',
    ticketNumber: 'CDGS-010',
    title: 'แจ้งขอปิดการใช้งานทะเบียนส่ง ของสำนักรวดเร็วปลอดภัย กรมทางหลวง ตามไฟล์แนบ',
    description: 'ต้องการยกเลิกสมุดทะเบียนส่งบางเล่ม',
    status: 'closed',
    type: 'feature',
    channel: 'line',
    priority: 'medium',
    category: 'ระบบสารบรรณ',
    product: 'ระบบทะเบียนหนังสือ',
    department: 'DOH',
    customerName: 'คุณ Suthisak Mooyotha',
    customerEmail: 'suthisak@doh.go.th',
    customerPhone: '02-xxx-xxxx',
    assignedTo: 'user-005',
    projectId: 'proj-csv-007',
    projectCode: 'D26-5001', // ✅ คืนค่ากลับมา - รูปแบบถูกต้องแล้ว
    projectName: 'กรมทางหลวง',
    projectShortName: 'DOH',
    createdBy: 'user-customer-011',
    createdByName: 'คุณ Suthisak Mooyotha',
    createdAt: parseCSVDate('5/1/2026', '10:23'),
    updatedAt: parseCSVDate('5/1/2026', '10:27'),
    dueDate: new Date('2026-01-07T10:23:00'),
    resolvedAt: parseCSVDate('5/1/2026', '10:27'),
    resolvedBy: 'user-005',
    closedAt: parseCSVDate('5/1/2026', '10:27'),
    closedBy: 'user-005',
    solution: 'ดำเนินการยกเลิกทะเบียนส่ง สมุดทะเบียนส่งภายใน เล่มที่ผู้ใช้งานแจ้ง เรียบร้อยแล้ว',
    attachments: [],
    timeline: createTimeline(
      parseCSVDate('5/1/2026', '10:23'),
      parseCSVDate('5/1/2026', '10:23'),
      parseCSVDate('5/1/2026', '10:27'),
      'user-005',
      'ธัญญาพร ทองแก้ว'
    ),
    comments: createComments(
      'ดำเนินการยกเลิกทะเบียนส่ง สมุดทะเบียนส่งภายใน เล่มที่ผู้ใช้งานแจ้ง เรียบร้อยแล้ว',
      'user-005',
      'ธัญญาพร ทองแก้ว',
      parseCSVDate('5/1/2026', '10:27')
    )
  }
];

// ==================== MERGE WITH PART 2 ====================
import { csvTicketsPart2 } from './mockDataCSVTicketsPart2';

// รวม Tickets ทั้งหมดจาก CSV (Part 1 + Part 2 = 50 เคส)
export const allCSVTickets = [
  ...csvTicketsRaw,
  ...csvTicketsPart2
];

// Export เป็น default
export const csvTickets = allCSVTickets;