# 🎫 CDGS Issue Tracking Platform

ระบบติดตามและจัดการเคสระดับองค์กร พร้อมเวิร์กโฟลว์การส่งต่อสามระดับ (Tier 1 → Tier 2 → Tier 3)

## ✨ คุณสมบัติหลัก

- 🔐 **ระบบ Authentication** - เข้าสู่ระบบ ลงทะเบียน และรีเซ็ตรหัสผ่าน
- 👥 **Multi-Role System** - รองรับ 6 บทบาท: Customer, Staff, Tier1, Tier2, Tier3, Admin
- 🎯 **Multi-Project Support** - ทำงานหลายโครงการพร้อมกันด้วยบทบาทที่แตกต่างกัน
- 📊 **Dashboard สำหรับแต่ละบทบาท** - แดชบอร์ดเฉพาะตามสิทธิ์การเข้าถึง
- 🔄 **Symmetric Tier Transfer** - ส่งต่อเคสได้ครบทุกทิศทาง (T1↔T2↔T3)
- 📈 **Analytics & Reporting** - รายงานและสถิติแบบเรียลไทม์
- 🌐 **Inverted Visibility Model** - Tier1 เห็นเคสมากสุด, Tier3 เห็นเคสน้อยสุด
- 🎨 **Enterprise Design** - ดีไซน์มาตรฐานองค์กรคล้าย Microsoft/Atlassian/ServiceNow

## 🚀 เริ่มต้นใช้งาน

### ข้อกำหนดเบื้องต้น

- Node.js 18.x หรือสูงกว่า
- npm 9.x หรือสูงกว่า (หรือ yarn/pnpm)

### การติดตั้ง

1. **Clone repository**

```bash
git clone <repository-url>
cd cdgs-issue-tracking-platform
```

2. **ติดตั้ง dependencies**

```bash
npm install
```

3. **ตั้งค่า Environment Variables**

```bash
cp .env.example .env
```

แก้ไขไฟล์ `.env` ตามความต้องการ

4. **รัน Development Server**

```bash
npm run dev
```

เปิดเบราว์เซอร์ที่ [http://localhost:3000](http://localhost:3000)

### คำสั่งที่ใช้บ่อย

```bash
# รัน development server
npm run dev

# Build สำหรับ production
npm run build

# Preview production build
npm run preview

# รัน linter
npm run lint
```

## 📁 โครงสร้างโปรเจค

```
/
├── components/           # React components
│   ├── ui/              # UI component library
│   ├── *Page.tsx        # Page components
│   └── *.tsx            # Feature components
├── contexts/            # React Context (AuthContext)
├── docs/                # 📚 Documentation
│   ├── PROJECT_OVERVIEW.md
│   ├── PERMISSION_MATRIX.md
│   ├── STAFF_ROLE_DOCUMENTATION.md
│   ├── NAVIGATION_MENU.md
│   ├── WORKFLOW.md
│   └── TODO_IMPROVEMENTS.md
├── lib/                 # Utility functions & mock data
├── styles/              # CSS files (globals.css, quill-custom.css)
├── types/               # TypeScript type definitions
├── src/                 # Source entry point
│   └── main.tsx         # Application entry
├── App.tsx              # Main App component
├── CHANGELOG.md         # 📝 Bug fixes & updates log
├── PHASE1_TESTING.md    # 🧪 Manual testing guide
├── index.html           # HTML template
├── package.json         # Dependencies
├── tsconfig.json        # TypeScript config
└── vite.config.ts       # Vite config
```

## 📚 Documentation

- **[CHANGELOG.md](./CHANGELOG.md)** - บันทึกการแก้ไข bug และอัปเดตระบบ
- **[PHASE1_TESTING.md](./PHASE1_TESTING.md)** - คู่มือการทดสอบแบบ Manual
- **[docs/PROJECT_OVERVIEW.md](./docs/PROJECT_OVERVIEW.md)** - ภาพรวมโครงการ
- **[docs/PERMISSION_MATRIX.md](./docs/PERMISSION_MATRIX.md)** - ตารางสิทธิ์การเข้าถึง
- **[docs/STAFF_ROLE_DOCUMENTATION.md](./docs/STAFF_ROLE_DOCUMENTATION.md)** - เอกสารบทบาท Staff
- **[docs/NAVIGATION_MENU.md](./docs/NAVIGATION_MENU.md)** - โครงสร้างเมนู
- **[docs/WORKFLOW.md](./docs/WORKFLOW.md)** - Flow การทำงาน

## 🔑 บทบาทผู้ใช้งาน

| บทบาท | คำอธิบาย | สิทธิ์หลัก |
|--------|----------|------------|
| **Customer** | ลูกค้าผู้ใช้บริการ | สร้างเคส, ติดตามเคส |
| **Staff** | เจ้าหน้าที่ Call Center / Email Support | บันทึกเคสแทนลูกค้า (2 ทางเลือก: แก้ไขและปิดเคส / ส่งงาน), บันทึกย้อนหลัง, ติดตามเคส |
| **Tier1** | ทีมซัพพอร์ตระดับ 1 | รับเคส, ตอบกลับ, ส่งต่อ T1/T2/T3 |
| **Tier2** | ทีมซัพพอร์ตระดับ 2 | รับเคส, จัดการเคสซับซ้อน, ส่งต่อ T1/T2/T3 |
| **Tier3** | ทีมซัพพอร์ตระดับ 3 | รับเคสยาก, แก้ปัญหาลึก, ส่งต่อ T1/T2/T3 |
| **Admin** | ผู้ดูแลระบบ | จัดการผู้ใช้, โครงการ, การตั้งค่า |

## 🎨 เทคโนโลยีที่ใช้

- **React 18** - UI Library
- **TypeScript** - Type Safety
- **Tailwind CSS v4** - Styling Framework
- **Vite** - Build Tool
- **Radix UI** - Headless UI Components
- **Lucide React** - Icon Library
- **Recharts** - Chart Library
- **Sonner** - Toast Notifications
- **React Hook Form** - Form Management

## 🔗 การเชื่อมต่อ Backend

ระบบถูกออกแบบให้เชื่อมต่อกับ Laravel API Backend:

1. ตั้งค่า `VITE_LARAVEL_API_URL` ใน `.env`
2. Backend ต้องมี CORS enabled
3. ดู API endpoints ใน AuthContext

## 🌐 ฟอนต์และภาษา

- **ฟอนต์:** Anuphan (Google Fonts) - เหมาะกับตัวอักษรไทย
- **ภาษา:** ภาษาไทยทั้งระบบ
- **คำศัพท์:**
  - "เคส" แทน "งาน"
  - "หัวเรื่อง" แทน "หัวข้อ"

## 📝 License

สงวนลิขสิทธิ์ © 2024 CDGS Issue Tracking Platform

## 🤝 การสนับสนุน

หากพบปัญหาหรือต้องการความช่วยเหลือ กรุณาติดต่อทีมพัฒนา