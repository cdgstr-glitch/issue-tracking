#!/usr/bin/env python3
"""
Script to fix incorrect names in mockData.ts and related files
"""

import os
import re

# Define the replacements
REPLACEMENTS = [
    ('ธีรพร รุ่งวิรัติกุล', 'ธิราภรณ์ รุ่งวิรัตน์กุล'),
    ('ธัญพร ทองแก้ว', 'ธัญญาพร ทองแก้ว'),
    ('ประกาศิต ประกอบเพชร', 'ประกาศิต ประคองเพ็ชร'),
]

FILES_TO_FIX = [
    '/lib/mockData.ts',
    '/lib/mockDataExtra.ts',
]

def fix_names_in_file(filepath):
    """Fix incorrect names in a single file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        changes_made = []
        
        # Apply each replacement
        for old_name, new_name in REPLACEMENTS:
            count = content.count(old_name)
            if count > 0:
                content = content.replace(old_name, new_name)
                changes_made.append(f"  - Replaced '{old_name}' → '{new_name}' ({count} occurrences)")
        
        # Only write if changes were made
        if content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Fixed {filepath}:")
            for change in changes_made:
                print(change)
            return True
        else:
            print(f"✓ No changes needed in {filepath}")
            return False
            
    except FileNotFoundError:
        print(f"⚠️  File not found: {filepath}")
        return False
    except Exception as e:
        print(f"❌ Error processing {filepath}: {e}")
        return False

def main():
    print("🔧 Starting name correction process...\n")
    
    total_fixed = 0
    for filepath in FILES_TO_FIX:
        if fix_names_in_file(filepath):
            total_fixed += 1
        print()
    
    print(f"✨ Complete! Fixed {total_fixed} file(s).")

if __name__ == '__main__':
    main()
