// Quick fix script to replace all assignedTo names with IDs
// Run this in browser console or node

const replacements = {
  "'สมศรี ช่วยเหลือ'": "'2'",
  "'สมหมาย แก้ปัญหา'": "'3'",
  "'สมปอง เชี่ยวชาญ'": "'4'",
  "'สมหญิง ผู้รับผิดชอบ'": "'5'",  // admin
};

// Copy the file content, then run:
// Object.keys(replacements).forEach(key => {
//   content = content.replaceAll(key, replacements[key]);
// });

console.log('Replace these manually in mockData.ts:');
console.log(replacements);
