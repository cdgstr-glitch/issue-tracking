import type { HydratedTicket } from '../lib/mockDb/client';
import { Card, CardContent } from './ui/card';
import { StatusBadge } from './StatusBadge';
import { PriorityBadge } from './PriorityBadge';
import { ChannelBadge } from './ChannelBadge';
import { SLAIndicator } from './SLAIndicator';
import { formatRelativeTime } from '../lib/utils';
import { User, Calendar, MessageSquare } from 'lucide-react';

interface TicketCardProps {
  ticket: HydratedTicket;
  onClick?: () => void;
}

export function TicketCard({ ticket, onClick }: TicketCardProps) {
  return (
    <Card 
      className="cursor-pointer transition-shadow hover:shadow-md"
      onClick={onClick}
    >
      <CardContent className="p-4">
        {/* Header */}
        <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
          <div className="flex-1">
            <div className="mb-1 flex items-center gap-2">
              <span className="text-xs text-gray-500">{ticket.ticketNumber}</span>
              <ChannelBadge channel={ticket.channel} />
            </div>
            <h3 className="m-0 line-clamp-2">{ticket.title}</h3>
          </div>
          <StatusBadge status={ticket.status} size="sm" />
        </div>

        {/* Description */}
        <p className="mb-3 line-clamp-2 text-sm text-gray-600">
          {ticket.description}
        </p>

        {/* Metadata */}
        <div className="mb-3 flex flex-wrap gap-2">
          <PriorityBadge priority={ticket.priority} />
          <SLAIndicator
            createdAt={ticket.createdAt}
            dueDate={ticket.dueDate}
            status={ticket.status}
            showLabel={false}
          />
        </div>

        {/* Footer */}
        <div className="flex flex-wrap items-center gap-4 border-t pt-3 text-xs text-gray-600">
          <div className="flex items-center gap-1">
            <User className="h-3.5 w-3.5" />
            <span>{ticket.customerName}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="h-3.5 w-3.5" />
            <span>{formatRelativeTime(ticket.createdAt)}</span>
          </div>
          {ticket.comments.length > 0 && (
            <div className="flex items-center gap-1">
              <MessageSquare className="h-3.5 w-3.5" />
              <span>{ticket.comments.length}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
