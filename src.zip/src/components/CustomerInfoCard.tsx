import { useState, useEffect } from 'react';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Pencil, User, Mail, Phone, Building } from 'lucide-react';
import { User as UserType } from '../contexts/AuthContext';

interface CustomerInfoCardProps {
  user: UserType | null;
  isStaff?: boolean;
}

export function CustomerInfoCard({ user, isStaff = false }: CustomerInfoCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [customerName, setCustomerName] = useState(user?.fullName || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [customerPhone, setCustomerPhone] = useState(user?.phone || '');
  const [customerDepartment, setCustomerDepartment] = useState(user?.department || '');

  // ✅ Sync state with prop changes
  useEffect(() => {
    setCustomerName(user?.fullName || '');
    setCustomerEmail(user?.email || '');
    setCustomerPhone(user?.phone || '');
    setCustomerDepartment(user?.department || '');
  }, [user]);

  const handleSave = () => {
    // TODO: Save to backend/context
    setIsEditing(false);
  };

  const handleCancel = () => {
    // Reset to original values
    setCustomerName(user?.fullName || '');
    setCustomerEmail(user?.email || '');
    setCustomerPhone(user?.phone || '');
    setCustomerDepartment(user?.department || '');
    setIsEditing(false);
  };

  if (isEditing) {
    // ✅ แสดงโหมดแก้ไข
    return (
      <Card className="border-blue-100 bg-blue-50/30">
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-base">
            <span className="flex items-center gap-2">
              <User className="h-4 w-4 text-blue-600" />
              {isStaff ? 'ข้อมูลลูกค้า' : 'ข้อมูลผู้แจ้ง'}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="edit-name">ชื่อ-นามสกุล *</Label>
              <Input 
                id="customerName" 
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                required 
                placeholder="ศิริพร อารีมิตร" 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">อีเมล *</Label>
              <Input 
                id="edit-email" 
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                required 
                placeholder="somchai@company.com" 
              />
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="edit-phone">เบอร์โทรศัพท์</Label>
              <Input 
                id="edit-phone"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="+66-XX-XXX-XXXX" 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-department">หน่วยงาน/สังกัด</Label>
              <Input 
                id="edit-department"
                value={customerDepartment}
                onChange={(e) => setCustomerDepartment(e.target.value)}
                placeholder="เช่น ฝ่าย IT, การตลาด" 
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button type="button" onClick={handleSave} size="sm" className="bg-blue-600 hover:bg-blue-700">
              บันทึก
            </Button>
            <Button type="button" variant="outline" onClick={handleCancel} size="sm" className="border-blue-300 text-blue-700 hover:bg-blue-50">
              ยกเลิก
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // ✅ แสดงโหมดดูข้อมูล (Read-only Card)
  return (
    <Card className="border-blue-100 bg-blue-50/30">
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2">
            <User className="h-4 w-4 text-blue-600" />
            {isStaff ? 'ข้อมูลลูกค้า' : 'ข้อมูลผู้แจ้ง'}
          </span>
          <Button 
            type="button"
            variant="ghost" 
            size="sm"
            onClick={() => setIsEditing(true)}
            className="text-blue-600 hover:text-blue-700 hover:bg-blue-100"
          >
            <Pencil className="h-4 w-4 mr-1" />
            แก้ไข
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2">
          {/* ชื่อ-นามสกุล */}
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
              <User className="h-5 w-5 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-500 mb-0.5">ชื่อ-นามสกุล</p>
              <p className="font-medium text-gray-900 truncate">{customerName || '-'}</p>
            </div>
          </div>

          {/* อีเมล */}
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
              <Mail className="h-5 w-5 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-500 mb-0.5">อีเมล</p>
              <p className="font-medium text-gray-900 truncate">{customerEmail || '-'}</p>
            </div>
          </div>

          {/* เบอร์โทร */}
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
              <Phone className="h-5 w-5 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-500 mb-0.5">เบอร์โทรศัพท์</p>
              <p className="font-medium text-gray-400 truncate">{customerPhone || 'ยังไม่ระบุ'}</p>
            </div>
          </div>

          {/* หน่วยงาน */}
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 flex-shrink-0">
              <Building className="h-5 w-5 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-500 mb-0.5">หน่วยงาน/สังกัด</p>
              <p className="font-medium text-gray-400 truncate">{customerDepartment || 'ยังไม่ระบุ'}</p>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-blue-200">
          <p className="text-xs text-blue-600 flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-full bg-green-500"></span>
            ข้อมูลดึงจากโปรไฟล์ของคุณ (คลิก "แก้ไข" เพื่อเปลี่ยนแปลงเฉพาะเคสนี้)
          </p>
        </div>
      </CardContent>
    </Card>
  );
}