import { TicketStatus, Ticket } from '../types';
import type { UserRole } from '../contexts/AuthContext';
import { buildStatusResolver } from '../lib/mockDb/data/statusService';

interface StatusBadgeProps {
  status: TicketStatus;
  size?: 'sm' | 'md' | 'lg';
  userRole?: UserRole; // เพิ่ม: แสดงข้อความต่างกันตาม role
  ticket?: Ticket; // ✅ เพิ่ม: ส่ง ticket object เพื่อตรวจสอบ escalationChain
}

export function StatusBadge({ status, size = 'md', userRole, ticket }: StatusBadgeProps) {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-1.5'
  };

  const isCustomer = userRole === 'customer';

  // ✅ ตรวจสอบว่าเป็นเคสที่ส่งกลับ Tier1 หรือไม่
  const isSentBackToTier1 =
    status === 'tier1' &&
    ticket?.escalationChain &&
    ticket.escalationChain.length > 0 &&
    ticket.escalationChain.some(chain =>
      (chain.fromTier === 'tier2' || chain.fromTier === 'tier3') && chain.toTier === 'tier1'
    );

  // ✅ DB-driven resolver (ให้ label ตรงกับ dropdown/statusPresentation)
  const resolver = buildStatusResolver(isCustomer ? 'customer' : 'staff');
  const normalizedStatus = resolver.normalize(status);
  const meta = resolver.getMeta(normalizedStatus);

  const variantToClass: Record<string, string> = {
    gray: 'bg-gray-50 text-gray-700 border-gray-200',
    blue: 'bg-blue-50 text-blue-700 border-blue-200',
    green: 'bg-green-50 text-green-700 border-green-200',
    yellow: 'bg-yellow-50 text-yellow-800 border-yellow-200',
    orange: 'bg-orange-50 text-orange-800 border-orange-200',
    red: 'bg-red-50 text-red-700 border-red-200',
    purple: 'bg-purple-50 text-purple-700 border-purple-200',
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  };

  let label = meta.label;
  let colorClass = variantToClass[meta.variant] || variantToClass.gray;

  // ✅ ถ้าเป็นเคสที่ส่งกลับ Tier1 → แสดง label พิเศษ
  if (isSentBackToTier1 && !isCustomer) {
    label = 'ส่งกลับ Tier 1';
    colorClass = 'bg-blue-50 text-blue-700 border-blue-200';
  }

  return (
    <span
      className={`inline-flex items-center rounded-full border font-medium ${colorClass} ${sizeClasses[size]}`}
    >
      {label}
    </span>
  );
}
