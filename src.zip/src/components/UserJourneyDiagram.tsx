import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ArrowRight, User, Headphones, Users, Award } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function UserJourneyDiagram() {
  const { user } = useAuth();
  
  // Determine which tier cards to show based on user role
  const showTier1 = user?.role === 'admin' || user?.role === 'tier1';
  const showTier2 = user?.role === 'admin' || user?.role === 'tier2';
  const showTier3 = user?.role === 'admin' || user?.role === 'tier3';
  
  return (
    <div className="space-y-8">
      {/* Customer Journey */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            การเดินทางของลูกค้า
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Step 1: Submit */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white">
                1
              </div>
              <div className="flex-1">
                <h3 className="mb-1">ส่งปัญหา</h3>
                <p className="text-sm text-gray-600">
                  ลูกค้าสร้างงานผ่านแบบฟอร์มเว็บ อีเมล Line หรือโทรศัพท์
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <span className="rounded bg-purple-100 px-2 py-1 text-xs text-purple-700">🌐 เว็บ</span>
                  <span className="rounded bg-blue-100 px-2 py-1 text-xs text-blue-700">📧 อีเมล</span>
                  <span className="rounded bg-green-100 px-2 py-1 text-xs text-green-700">💬 Line</span>
                  <span className="rounded bg-red-100 px-2 py-1 text-xs text-red-700">📞 โทรศัพท์</span>
                </div>
              </div>
              <ArrowRight className="hidden shrink-0 text-gray-400 md:block" />
            </div>

            {/* Step 2: Confirmation */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white">
                2
              </div>
              <div className="flex-1">
                <h3 className="mb-1">รับการยืนยัน</h3>
                <p className="text-sm text-gray-600">
                  หมายเลขงานส่งทางอีเมล/Line + เข้าถึงหน้าติดตามเคส
                </p>
              </div>
              <ArrowRight className="hidden shrink-0 text-gray-400 md:block" />
            </div>

            {/* Step 3: Track */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white">
                3
              </div>
              <div className="flex-1">
                <h3 className="mb-1">ติดตามความคืบหน้า</h3>
                <p className="text-sm text-gray-600">
                  ติดตามสถานะ: ใหม่ → ระดับ 1 → ระดับ 2 → ระดับ 3 → แก้ไขแล้ว → ปิด
                </p>
                <div className="mt-2 flex flex-wrap gap-1 text-xs">
                  <span className="rounded border border-gray-300 bg-gray-100 px-2 py-1 text-gray-800">ใหม่</span>
                  <span>→</span>
                  <span className="rounded border border-blue-300 bg-blue-100 px-2 py-1 text-blue-800">ระดับ 1</span>
                  <span>→</span>
                  <span className="rounded border border-orange-300 bg-orange-100 px-2 py-1 text-orange-800">ระดับ 2</span>
                  <span>→</span>
                  <span className="rounded border border-red-300 bg-red-100 px-2 py-1 text-red-800">ระดับ 3</span>
                  <span>→</span>
                  <span className="rounded border border-green-300 bg-green-100 px-2 py-1 text-green-800">แก้ไขแล้ว</span>
                </div>
              </div>
              <ArrowRight className="hidden shrink-0 text-gray-400 md:block" />
            </div>

            {/* Step 4: Updates */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white">
                4
              </div>
              <div className="flex-1">
                <h3 className="mb-1">รับการอัปเดต</h3>
                <p className="text-sm text-gray-600">
                  การแจ้งเตือนอัตโนมัติเมื่อมีการเปลี่ยนสถานะและความคิดเห็นใหม่
                </p>
              </div>
              <ArrowRight className="hidden shrink-0 text-gray-400 md:block" />
            </div>

            {/* Step 5: Resolution */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-green-600 text-white">
                5
              </div>
              <div className="flex-1">
                <h3 className="mb-1">ยืนยันการแก้ไข</h3>
                <p className="text-sm text-gray-600">
                  ลูกค้ายืนยันว่าปัญหาได้รับการแก้ไข → งานถูกปิด
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Admin/Support Journey */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Headphones className="h-5 w-5" />
            การเดินทางของแอดมิน/ฝ่ายสนับสนุน
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Tier 1 */}
            {showTier1 && (
              <>
                <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white">
                      T1
                    </div>
                    <div>
                      <h3 className="mb-0">ระดับ 1 - การตอบสนองครั้งแรก</h3>
                      <p className="text-sm text-gray-600">SLA: 2-4 ชั่วโมง</p>
                    </div>
                  </div>
                  <ul className="ml-12 space-y-1 text-sm text-gray-700">
                    <li>• รับงานจากกล่องขาเข้ารวม</li>
                    <li>• คัดแยกและจัดหมวดหมู่เบื้องต้น</li>
                    <li>• แก้ไขปัญหาง่ายๆ ทันที</li>
                    <li>• ส่งต่อปัญหาที่ซับซ้อนไปยังระดับ 2</li>
                  </ul>
                </div>

                {showTier2 && (
                  <div className="ml-12 flex items-center gap-2 text-gray-400">
                    <ArrowRight />
                    <span className="text-sm">ส่งต่อหากแก้ไขไม่ได้</span>
                  </div>
                )}
              </>
            )}

            {/* Tier 2 */}
            {showTier2 && (
              <>
                <div className="rounded-lg border-2 border-orange-200 bg-orange-50 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-orange-600 text-white">
                      T2
                    </div>
                    <div>
                      <h3 className="mb-0">ระดับ 2 - การสนับสนุนทางเทคนิค</h3>
                      <p className="text-sm text-gray-600">SLA: 1-2 วัน</p>
                    </div>
                  </div>
                  <ul className="ml-12 space-y-1 text-sm text-gray-700">
                    <li>• จัดการการแก้ไขปัญหาทางเทคนิค</li>
                    <li>• เข้าถึงล็อกระบบและการแก้จุดบกพร่อง</li>
                    <li>• ประสานงานกับทีมพัฒนา</li>
                    <li>• ส่งต่อปัญหาร้ายแรงไปยังระดับ 3</li>
                  </ul>
                </div>

                {showTier3 && (
                  <div className="ml-12 flex items-center gap-2 text-gray-400">
                    <ArrowRight />
                    <span className="text-sm">ส่งต่อปัญหาร้ายแรง/ซับซ้อน</span>
                  </div>
                )}
              </>
            )}

            {/* Tier 3 */}
            {showTier3 && (
              <div className="rounded-lg border-2 border-red-200 bg-red-50 p-4">
                <div className="mb-3 flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-600 text-white">
                    T3
                  </div>
                  <div>
                    <h3 className="mb-0">ระดับ 3 - ผู้เชี่ยวชาญ/ผู้ให้บริการ</h3>
                    <p className="text-sm text-gray-600">SLA: 2-5 วัน</p>
                  </div>
                </div>
                <ul className="ml-12 space-y-1 text-sm text-gray-700">
                  <li>• จัดการปัญหาโครงสร้างพื้นฐานที่ซับซ้อน</li>
                  <li>• เหตุการณ์ด้านความปลอดภัยและการสืบสวนการละเมิด</li>
                  <li>• ประสานงานกับผู้ให้บริการคลาวด์/ผู้ขาย</li>
                  <li>• การแก้ปัญหาระดับสถาปนิก</li>
                </ul>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Monitoring & Analytics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            การติดตามอย่างต่อเนื่อง
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2">การติดตาม SLA</h3>
              <p className="text-sm text-gray-600">
                การติดตามเวลาตอบสนองและการแก้ไขแบบเรียลไทม์
              </p>
            </div>
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2">การกระจายภาระงาน</h3>
              <p className="text-sm text-gray-600">
                ติดตามเคสต่อเจ้าหน้าที่และประสิทธิภาพของแต่ละระดับ
              </p>
            </div>
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2">การวิเคราะห์และรายงาน</h3>
              <p className="text-sm text-gray-600">
                แนวโน้มหมวดหมู่ ปริมาณช่องทาง และอัตราการแก้ไข
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}