import { Bell, Menu, Search, User, LogOut, ChevronDown, Info, AlertCircle, Clock, CheckCircle2, Plus, Check, ArrowUp, MessageSquare } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { useAuth } from '../../contexts/AuthContext';
import { getRoleDisplayName, getTierRoles, needsRoleSelector } from '../../lib/utils';
import { can, CAPABILITIES, isTier1, isPureStaff, isCustomer } from '../../lib/permissions';
import logoImage from '../../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png';
import { useState, useEffect } from 'react';
import { db } from '../../lib/mockDb/client';
import { UserRole } from '../../types';

interface HeaderProps {
  onMenuClick?: () => void;
  showSearch?: boolean;
  user?: {
    fullName: string; // ✅ เปลี่ยนจาก name เป็น fullName
    role: string;
  };
  onInformationClick?: () => void;
  onNavigate?: (path: string, ticketId?: string) => void;
  currentPath?: string; // เพิ่ม prop สำหรับเช็คว่าอยู่หน้าไหน
  onSearch?: (query: string) => void; // ✅ เพิ่ม callback สำหรับการค้นหา
  searchQuery?: string; // ✅ เพิ่ม state สำหรับ search query
}

export function Header({ onMenuClick, showSearch = true, user, onInformationClick, onNavigate, currentPath, onSearch, searchQuery = '' }: HeaderProps) {
  const { user: authUser, customer: authCustomer, logout, activeRole, setActiveRole } = useAuth();
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  const handleLogout = () => {
    console.log('🚪 handleLogout called from Header');
    logout();
  };

  // 🆕 ตรวจสอบว่า user มีหลาย tier roles หรือไม่
  const showRoleSelector = needsRoleSelector(authUser);
  const tierRoles = getTierRoles(authUser);
  
  // 🔧 ตรวจสอบว่า activeRole ตรงกับ tierRoles หรือไม่
  const isActiveRoleValid = tierRoles.length > 0 && tierRoles.includes(activeRole);

  // Determine if user is customer or staff (tier1, tier2, tier3)
  const isCustomerOrStaff = user?.role === 'customer' || 
                           user?.role === 'tier1' || 
                           user?.role === 'tier2' || 
                           user?.role === 'tier3';
  
  // Check if user has staff role (for showing "Create Ticket" button)
  const isStaff = isPureStaff(authUser);
  
  // ✅ ใช้ customer หรือ authUser สำหรับเช็ค role
  const currentUser = authCustomer || authUser;
  const currentRole = authCustomer ? 'customer' : activeRole;
  
  // ✅ กำหนดชื่อแอปพลิเคชันตาม role - ลูกค้าเห็น "Application Support Center"
  const appTitle = authCustomer || currentRole === 'customer' ? 'Application Support Center' : 'CDGS Issue Tracking Platform';
  
  // ✅ สร้างตัวอักษรย่อจากชื่อ (เอาตัวแรกของแต่ละคำ)
  const getInitials = (fullName: string) => {
    const names = fullName.trim().split(' ');
    if (names.length >= 2) {
      return (names[0][0] + names[names.length - 1][0]).toUpperCase();
    }
    return fullName.substring(0, 2).toUpperCase();
  };
  
  // ✅ แสดงปุ่ม "แจ้งเคสใหม่" เฉพาะหน้า Dashboard และมี capability CREATE_TICKET_FOR_CUSTOMER
  // (รวม Staff และ Tier1 ทั้งคู่)
  const shouldShowCreateButton = (isCustomer(authUser) || can(authUser, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER) || authCustomer) && currentPath === '/admin';
  
  // Mock notifications based on role
  useEffect(() => {
    // ✅ Canonical contract: getByRecipientId — polymorphic (user | customer)
    const currentUserId = authCustomer?.id || authUser?.id;
    if (!currentUserId) {
      setNotifications([]);
      return;
    }

    // Fetch from mock DB using FK
    const rawNotifications = db.notifications.getByRecipientId(currentUserId);
    
    // Map to UI
    const uiNotifications = rawNotifications.map(n => {
      let icon = AlertCircle;
      let iconColor = 'text-gray-600';

      switch (n.type) {
        case 'new':
          icon = AlertCircle;
          iconColor = 'text-blue-600';
          break;
        case 'escalated':
          icon = ArrowUp;
          iconColor = 'text-purple-600';
          if (n.priority === 'critical') iconColor = 'text-red-600';
          break;
        case 'resolved':
          icon = CheckCircle2;
          iconColor = 'text-green-600';
          break;
        case 'update':
          icon = MessageSquare;
          iconColor = 'text-blue-600';
          break;
        case 'sla':
          icon = Clock;
          iconColor = 'text-orange-600';
          if (n.priority === 'critical') iconColor = 'text-red-600';
          break;
      }

      return {
        ...n,
        icon,
        iconColor
      };
    });

    // Already sorted by client.ts; keep as-is
    setNotifications(uiNotifications);
  }, [activeRole, authUser, authCustomer]);

  const unreadCount = notifications.filter(n => n.isNew).length;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      <div className="flex h-16 items-center gap-4 px-4 lg:px-6">
        {/* Mobile menu button */}
        {onMenuClick && (
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={onMenuClick}
          >
            <Menu className="h-5 w-5" />
          </Button>
        )}

        {/* Logo - Hidden on desktop when sidebar is present */}
        <div 
          className={`flex items-center gap-2 cursor-pointer ${onMenuClick ? 'lg:hidden' : ''}`}
          onClick={() => onNavigate?.('/')}
        >
          <img 
            src={logoImage} 
            alt="CDGS Logo" 
            className="h-12 w-12 object-contain"
          />
          <div className="hidden sm:flex sm:items-center">
            <h1 className="m-0 text-xs md:text-sm">{appTitle}</h1>
          </div>
        </div>

        {/* Search bar - Desktop */}
        {showSearch && (
          <div className="hidden flex-1 md:flex md:max-w-md lg:ml-0">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                type="search"
                placeholder="Search tickets..."
                className="w-full pl-9"
                value={searchQuery}
                onChange={(e) => onSearch?.(e.target.value)}
              />
            </div>
          </div>
        )}

        {/* Right section */}
        <div className="ml-auto flex items-center gap-2">
          {/* Search icon - Mobile */}
          {showSearch && (
            <Button variant="ghost" size="sm" className="md:hidden">
              <Search className="h-5 w-5" />
            </Button>
          )}

          {/* Create Ticket Button - Staff (ทุกหน้า) หรือ Tier1 (เฉพาะ Dashboard + เคสทั้งหมด) */}
          {shouldShowCreateButton && onNavigate && (
            <Button 
              size="sm" 
              className="hidden md:flex gap-1.5 bg-blue-600 hover:bg-blue-700 text-white"
              onClick={() => onNavigate('/admin/create')}
            >
              <Plus className="h-4 w-4" />
              <span>แจ้งเคสใหม่</span>
            </Button>
          )}

          {/* Notifications */}
          <DropdownMenu open={notificationOpen} onOpenChange={setNotificationOpen}>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                    {unreadCount}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-96">
              <DropdownMenuLabel className="flex items-center justify-between">
                <span>การแจ้งเตือน</span>
                {unreadCount > 0 && (
                  <span className="text-xs text-blue-600">{unreadCount} รายการใหม่</span>
                )}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-[400px] overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="py-8 text-center text-sm text-gray-500">
                    ไม่มีการแจ้งเตือน
                  </div>
                ) : (
                  notifications.map((notification: any) => {
                    const IconComponent = notification.icon;
                    return (
                      <DropdownMenuItem 
                        key={notification.id}
                        className="flex items-start gap-3 p-4 cursor-pointer hover:bg-gray-50 focus:bg-gray-50"
                        onClick={() => {
                          setNotificationOpen(false);
                          
                          // Mark as read via canonical contract
                          db.notifications.markRead(notification.id);
                          setNotifications(prev => prev.map(n => n.id === notification.id ? { ...n, isNew: false } : n));

                          // Navigate based on role and ticketId
                          if (onNavigate && (notification.ticketId || notification.actionUrl)) {
                            // Prefer ticketId, fallback to parsing actionUrl
                            const ticketId = notification.ticketId || notification.actionUrl.split('/').pop();
                            const targetRole = authCustomer ? 'customer' : activeRole;

                            if (targetRole === 'customer') {
                              onNavigate('/track-ticket-detail', ticketId);
                            } else if (targetRole === 'staff') {
                              onNavigate('/staff-ticket-detail', ticketId);
                            } else {
                              // tier1, tier2, tier3, admin
                              onNavigate('/admin/ticket', ticketId);
                            }
                          }
                        }}
                      >
                        <div className={`mt-1 ${notification.iconColor}`}>
                          <IconComponent className="h-5 w-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-sm font-medium">
                              {notification.title}
                            </p>
                            {notification.isNew && (
                              <span className="h-2 w-2 rounded-full bg-blue-600 flex-shrink-0"></span>
                            )}
                          </div>
                          <p className="text-xs text-gray-600 mb-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-xs text-gray-400">
                            {notification.time}
                          </p>
                        </div>
                      </DropdownMenuItem>
                    );
                  })
                )}
              </div>
              {notifications.length > 0 && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="justify-center text-center text-sm text-blue-600 hover:text-blue-700 cursor-pointer font-medium"
                    onClick={() => {
                      setNotificationOpen(false);
                      onNavigate?.('/admin/notifications');
                    }}
                  >
                    ดูทั้งหมด
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User menu - แสดงถ้ามี user prop และมี authUser หรือ authCustomer */}
          {user && (authUser || authCustomer) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-lg border bg-gray-50 px-3 py-2 hover:bg-gray-100 transition-colors">
                  {/* Avatar - แสดงตัวอักษรย่อจากชื่อ */}
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white flex-shrink-0 text-xs font-semibold">
                    {getInitials(authCustomer ? authCustomer.fullName : user.fullName)}
                  </div>
                  {/* User Info - แสดงทั้ง Mobile และ Desktop */}
                  <div className="text-sm text-left">
                    <div className="font-medium text-neutral-950">{authCustomer ? authCustomer.fullName : user.fullName}</div>
                    <div className="text-xs text-gray-600">{getRoleDisplayName(authCustomer ? 'customer' : activeRole)}</div>
                  </div>
                  <ChevronDown className="h-4 w-4 text-gray-600" />
                </button>
              </DropdownMenuTrigger>

              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>บัญชีของฉัน</DropdownMenuLabel>
                <DropdownMenuSeparator />
                
                {/* 🆕 Role Selector Section - แสดงเฉพาะเมื่อมีหลาย tier roles */}
                {showRoleSelector && tierRoles.length > 0 && (
                  <>
                    <DropdownMenuLabel className="text-xs text-gray-500">สลับบทบาท</DropdownMenuLabel>
                    {tierRoles.map(role => (
                      <DropdownMenuItem 
                        key={role}
                        onClick={() => setActiveRole(role as UserRole)}
                        className="cursor-pointer"
                      >
                        <div className="flex items-center justify-between w-full">
                          <span>{getRoleDisplayName(role)}</span>
                          {role === activeRole && (
                            <Check className="h-4 w-4 text-blue-600" />
                          )}
                        </div>
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator />
                  </>
                )}
                
                <DropdownMenuItem onClick={() => {
                  // ✅ All roles use /admin/profile (handled by special case in App.tsx)
                  onNavigate?.('/admin/profile');
                }}>
                  <User className="mr-2 h-4 w-4" />
                  <span>โปรไฟล์</span>
                </DropdownMenuItem>
                {onInformationClick && (
                  <DropdownMenuItem onClick={onInformationClick}>
                    <Info className="mr-2 h-4 w-4" />
                    <span>Information</span>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600 focus:text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>ออกจากระบบ</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  );
}
