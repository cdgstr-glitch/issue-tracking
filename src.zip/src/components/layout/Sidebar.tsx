import { useMemo } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/button';
import { cn } from '../../lib/utils';
import { can, CAPABILITIES } from '../../lib/permissions';
import logoImage from '../../assets/0bda074fa9558e46ee8a520d3e35ff532ff12481.png';
import { db } from '../../lib/mockDb/client';
import {
  LayoutDashboard,
  Inbox,
  Clock,
  FolderKanban,
  CheckCircle,
  ArrowUpRight,
  BarChart3,
  Users,
  Settings,
  FileText,
  Archive,
  User,
  LogOut,
  X,
} from 'lucide-react';

interface SidebarProps {
  onNavigate: (path: string, ticketId?: string) => void;
  isOpen: boolean;
  onClose: () => void;
  currentPath?: string;
}

function getRoleDisplayName(role: string): string {
  const roleMap: Record<string, string> = {
    customer: 'ลูกค้า',
    staff: 'ผู้แจ้งเคส',
    tier1: 'Tier 1 Support',
    tier2: 'Tier 2 (SA)',
    tier3: 'Tier 3 (Specialist)',
    admin: 'ผู้ดูแลระบบ',
  };

  return roleMap[role] || role;
}

export function Sidebar({ onNavigate, isOpen, onClose, currentPath }: SidebarProps) {
  const { user, logout, activeRole } = useAuth();

  const hasTierRole =
    user?.roles?.some((role) => ['tier1', 'tier2', 'tier3'].includes(role)) || false;

  const badgeCounts = useMemo(() => {
    if (!user) return {};

    const tickets = db.tickets.getAll();
    const counts: Record<string, number> = {};

    if (activeRole === 'tier1') {
      const pendingNew = tickets.filter((t) => t.status === 'new').length;
      const pendingTier1 = tickets.filter(
        (t) => t.stage === 'tier1' && (t.assignedTo === user?.id || !t.assignedTo)
      ).length;
      const awaitingClosure = tickets.filter(
        (t) => t.status === 'resolved' && t.assignedTo === user?.id
      ).length;

      counts.pending = pendingNew + pendingTier1 + awaitingClosure;
    } else if (activeRole === 'tier2') {
      counts.pending = tickets.filter(
        (t) => t.stage === 'tier2' && t.assignedTo === user?.id
      ).length;
    } else if (activeRole === 'tier3') {
      counts.pending = tickets.filter(
        (t) => t.stage === 'tier3' && t.assignedTo === user?.id
      ).length;
    } else if (activeRole === 'admin') {
      counts.pending = tickets.filter((t) => t.status === 'new').length;
    }

    counts.myTickets = tickets.filter(
      (t) => t.assignedTo === user?.id && t.status === 'in_progress'
    ).length;

    counts.resolved = tickets.filter(
      (t) => t.status === 'resolved' && t.assignedTo === user?.id
    ).length;

    return counts;
  }, [user, activeRole]);

  const navigation = useMemo(() => {
    const navItems: Array<{ name: string; icon: any; path: string }> = [];

    // Dashboard
    if (activeRole === 'tier1') {
      navItems.push({ name: 'แดชบอร์ด', icon: LayoutDashboard, path: '/admin' });
    } else if (activeRole === 'tier2') {
      navItems.push({ name: 'แดชบอร์ด SA', icon: LayoutDashboard, path: '/admin/sa' });
    } else if (activeRole === 'tier3') {
      navItems.push({
        name: 'แดชบอร์ดผู้เชี่ยวชาญ',
        icon: LayoutDashboard,
        path: '/admin/specialist',
      });
    } else {
      navItems.push({ name: 'แดชบอร์ด', icon: LayoutDashboard, path: '/admin' });
    }

    // Operational Menus
    if (can(user, CAPABILITIES.VIEW_ALL_TICKETS)) {
      navItems.push({ name: 'เคสทั้งหมด', icon: Inbox, path: '/admin/tickets' });
      navItems.push({ name: 'รอดำเนินการ', icon: Clock, path: '/admin/pending' });

      // ✅ ย้าย "งานของฉัน" มาไว้ก่อน "แก้ไขแล้ว"
      if (
        can(user, CAPABILITIES.ACCEPT_TICKET) ||
        activeRole === 'tier1' ||
        activeRole === 'tier2' ||
        activeRole === 'tier3'
      ) {
        navItems.push({
          name: 'งานของฉัน',
          icon: FolderKanban,
          path: '/admin/my-tickets',
        });
      }

      navItems.push({
        name: 'แก้ไขแล้ว',
        icon: CheckCircle,
        path: '/admin/resolved',
      });
    }

    if (
      can(user, CAPABILITIES.ESCALATE_TICKET) ||
      activeRole === 'tier1' ||
      activeRole === 'tier2' ||
      activeRole === 'tier3'
    ) {
      navItems.push({
        name: 'เคสที่ฉันส่งต่อ',
        icon: ArrowUpRight,
        path: '/admin/escalated',
      });
    }

    if (activeRole === 'tier1' || activeRole === 'admin') {
      navItems.push({
        name: 'เคสที่ปิดย้อนหลัง',
        icon: Archive,
        path: '/admin/retroactive-closed-tickets',
      });
    }

    if (
      can(user, CAPABILITIES.MANAGE_SETTINGS) ||
      can(user, CAPABILITIES.MANAGE_USERS) ||
      hasTierRole
    ) {
      navItems.push({
        name: 'การวิเคราะห์',
        icon: BarChart3,
        path: '/admin/analytics',
      });
    }

    if (can(user, CAPABILITIES.MANAGE_SETTINGS)) {
      navItems.push({
        name: 'รายงาน',
        icon: FileText,
        path: '/admin/reports',
      });
    }

    if (can(user, CAPABILITIES.MANAGE_USERS)) {
      navItems.push({
        name: 'ทีม',
        icon: Users,
        path: '/admin/team',
      });
    }

    if (can(user, CAPABILITIES.MANAGE_SETTINGS)) {
      navItems.push({
        name: 'การตั้งค่า',
        icon: Settings,
        path: '/admin/settings',
      });
    }

    return navItems;
  }, [activeRole, user, hasTierRole]);

  const handleNavigate = (path: string) => {
    onNavigate?.(path);
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={onClose} />
      )}

      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-64 transform border-r bg-white transition-transform duration-200 ease-in-out lg:sticky lg:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex h-full flex-col">

          {/* Header */}
          <div className="flex h-16 items-center justify-between border-b px-4">
            <div className="flex items-center gap-2">
              <img src={logoImage} alt="CDGS Logo" className="h-12 w-12 object-contain" />
              <span className="text-xs md:text-sm hidden sm:block">
                CDGS Issue Tracking
              </span>
            </div>
            <Button variant="ghost" size="sm" className="lg:hidden" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-1 overflow-y-auto p-4">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = currentPath === item.path;

              return (
                <button
                  key={item.path}
                  onClick={() => handleNavigate(item.path)}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors',
                    isActive
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span className="flex-1 text-left">{item.name}</span>

                  {item.path === '/admin/pending' && (badgeCounts as any).pending > 0 && (
                    <span className="badge bg-red-500 text-white text-xs px-2 rounded-full">
                      {(badgeCounts as any).pending}
                    </span>
                  )}
                  {item.path === '/admin/my-tickets' &&
                    (badgeCounts as any).myTickets > 0 && (
                      <span className="badge bg-blue-500 text-white text-xs px-2 rounded-full">
                        {(badgeCounts as any).myTickets}
                      </span>
                    )}
                  {item.path === '/admin/resolved' &&
                    (badgeCounts as any).resolved > 0 && (
                      <span className="badge bg-green-500 text-white text-xs px-2 rounded-full">
                        {(badgeCounts as any).resolved}
                      </span>
                    )}
                </button>
              );
            })}
          </nav>
        </div>
      </aside>
    </>
  );
}
