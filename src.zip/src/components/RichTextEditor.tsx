import { useState, useRef } from 'react';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { 
  Bold, 
  Italic, 
  Underline, 
  List, 
  ListOrdered, 
  Link as LinkIcon,
  Image as ImageIcon
} from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  id?: string;
  required?: boolean;
}

export function RichTextEditor({ 
  value, 
  onChange, 
  placeholder = 'พิมพ์รายละเอียด...', 
  className = '',
  id,
  required 
}: RichTextEditorProps) {
  const [focused, setFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const insertFormatting = (prefix: string, suffix: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    try {
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const selectedText = value.substring(start, end);
      const beforeText = value.substring(0, start);
      const afterText = value.substring(end);

      const newText = beforeText + prefix + selectedText + suffix + afterText;
      onChange(newText);

      // Set cursor position after insertion
      requestAnimationFrame(() => {
        if (textarea) {
          textarea.focus();
          const newCursorPos = start + prefix.length + selectedText.length + suffix.length;
          textarea.setSelectionRange(newCursorPos, newCursorPos);
        }
      });
    } catch (error) {
      console.error('Error inserting formatting:', error);
    }
  };

  const formatButtons = [
    { icon: Bold, label: 'ตัวหนา', action: () => insertFormatting('**', '**') },
    { icon: Italic, label: 'ตัวเอียง', action: () => insertFormatting('_', '_') },
    { icon: Underline, label: 'ขีดเส้นใต้', action: () => insertFormatting('<u>', '</u>') },
    { icon: List, label: 'รายการแบบจุด', action: () => insertFormatting('\n• ') },
    { icon: ListOrdered, label: 'รายการแบบตัวเลข', action: () => insertFormatting('\n1. ') },
    { icon: LinkIcon, label: 'แทรกลิงค์', action: () => insertFormatting('[', '](url)') },
    { icon: ImageIcon, label: 'แทรกรูปภาพ', action: () => {} },
  ];

  return (
    <div className={`border rounded-lg bg-white ${className}`} id={id}>
      {/* Formatting Toolbar */}
      <div className="flex items-center gap-1 p-2 border-b bg-gray-50">
        {formatButtons.map((btn, index) => (
          <Button
            key={index}
            type="button"
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={btn.action}
            title={btn.label}
          >
            <btn.icon className="h-4 w-4" />
          </Button>
        ))}
        <div className="ml-auto text-xs text-gray-500">
          รองรับ Markdown
        </div>
      </div>

      {/* Text Area */}
      <Textarea
        ref={textareaRef}
        id={id || 'rich-text-area'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="min-h-[200px] border-0 focus-visible:ring-0 focus-visible:ring-offset-0 rounded-t-none"
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        required={required}
      />

      {/* Helper Text */}
      {focused && (
        <div className="px-3 py-2 text-xs text-gray-500 bg-blue-50 border-t">
          💡 เคล็ดลับ: เลือกข้อความแล้วคลิกปุ่มด้านบนเพื่อจัดรูปแบบ หรือใช้ Markdown (**, _, #, -, 1.)
        </div>
      )}
    </div>
  );
}