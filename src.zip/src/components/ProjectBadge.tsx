import { Project } from '../types';

interface ProjectBadgeProps {
  organizationShortName?: string;
  projectCode?: string;
  className?: string;
}

export function ProjectBadge({ organizationShortName, projectCode, className = '' }: ProjectBadgeProps) {
  if (!projectCode) return <span className="text-gray-400">-</span>;

  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      {organizationShortName && (
        <span className="inline-flex items-center rounded-md border border-gray-200 bg-white px-2 py-0.5 text-xs font-semibold text-gray-900 shadow-sm">
          {organizationShortName}
        </span>
      )}
      <span className="text-sm font-medium text-gray-600">
        {projectCode}
      </span>
    </span>
  );
}
