/**
 * Common Components - Reusable components for CDGS Issue Tracking Platform
 * 
 * Priority 1 Components (Critical - Must Have):
 * - PageBackButton: ปุ่มกลับที่ใช้ร่วมกันทั้งระบบ
 * - PageHeader: Header หน้าที่ใช้ร่วมกันทั้งระบบ
 * - EmptyState: แสดงสถานะว่างเปล่า
 * - SuccessPage: หน้าแสดงผลสำเร็จ
 */

export { PageBackButton } from './PageBackButton';
export { PageHeader } from './PageHeader';
export { EmptyState } from './EmptyState';
export { SuccessPage } from './SuccessPage';