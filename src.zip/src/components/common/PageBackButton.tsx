import React from 'react';
import { Button } from '../ui/button';
import { ArrowLeft } from 'lucide-react';

interface PageBackButtonProps {
  onNavigate: (path: string) => void;
  backPath: string;
  label?: string;
  variant?: 'ghost' | 'outline' | 'default';
  size?: 'sm' | 'default' | 'lg';
  className?: string;
  showIcon?: boolean;
  hideTextOnMobile?: boolean;
}

/**
 * PageBackButton - ปุ่มกลับที่ใช้ร่วมกันทั้งระบบ
 * 
 * @example
 * ```tsx
 * // ขนาดเล็ก ซ่อนข้อความบน mobile
 * <PageBackButton 
 *   onNavigate={onNavigate} 
 *   backPath="/dashboard" 
 *   size="sm"
 *   hideTextOnMobile
 * />
 * 
 * // ขนาดปกติ พร้อมข้อความ
 * <PageBackButton 
 *   onNavigate={onNavigate} 
 *   backPath="/track" 
 *   label="กลับรายการเคส"
 * />
 * ```
 */
export function PageBackButton({ 
  onNavigate, 
  backPath, 
  label = 'กลับ',
  variant = 'ghost',
  size = 'default',
  className = '',
  showIcon = true,
  hideTextOnMobile = false
}: PageBackButtonProps) {
  return (
    <Button 
      variant={variant} 
      size={size}
      onClick={() => onNavigate(backPath)}
      className={`gap-2 ${className}`}
    >
      {showIcon && <ArrowLeft className="h-4 w-4" />}
      <span className={hideTextOnMobile ? 'hidden sm:inline' : ''}>
        {label}
      </span>
    </Button>
  );
}
