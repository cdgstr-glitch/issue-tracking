import React from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}

/**
 * PageHeader - Header หน้าที่ใช้ร่วมกันทั้งระบบ
 * 
 * @example
 * ```tsx
 * // Header พื้นฐาน
 * <PageHeader 
 *   title="งานของฉัน" 
 *   subtitle="รายการงานที่คุณรับผิดชอบ" 
 * />
 * 
 * // Header พร้อม Badge และ Actions
 * <PageHeader 
 *   title="รายการเคสทั้งหมด"
 *   subtitle="จัดการและติดตามเคสของคุณ"
 *   badge={<Badge variant="secondary">{ticketCount} เคส</Badge>}
 *   actions={
 *     <div className="flex gap-2">
 *       <Button variant="outline">ส่งออก</Button>
 *       <Button>สร้างเคสใหม่</Button>
 *     </div>
 *   }
 * />
 * ```
 */
export function PageHeader({ 
  title, 
  subtitle, 
  badge,
  actions,
  className = 'mb-6'
}: PageHeaderProps) {
  return (
    <div className={className}>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="mb-0">{title}</h1>
          {badge && <div>{badge}</div>}
        </div>
        {actions && <div className="flex gap-2">{actions}</div>}
      </div>
      {subtitle && <p className="text-gray-600 mt-2">{subtitle}</p>}
    </div>
  );
}
