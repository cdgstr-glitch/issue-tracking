import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'outline' | 'secondary';
  };
  variant?: 'default' | 'info' | 'warning';
  size?: 'sm' | 'md' | 'lg';
  showCard?: boolean;
  className?: string;
}

/**
 * EmptyState - แสดงสถานะว่างเปล่าที่ใช้ร่วมกันทั้งระบบ
 * 
 * @example
 * ```tsx
 * // Empty state พื้นฐาน
 * <EmptyState
 *   icon={Inbox}
 *   title="ไม่พบเคส"
 *   description="ไม่มีเคสที่ตรงกับเงื่อนไข"
 * />
 * 
 * // Empty state พร้อม action button
 * <EmptyState
 *   icon={Users}
 *   title="ไม่พบสมาชิกทีม"
 *   description="ลองค้นหาด้วยคำอื่น"
 *   action={{
 *     label: 'ล้างการค้นหา',
 *     onClick: handleReset
 *   }}
 *   size="md"
 * />
 * 
 * // Empty state แบบ info (ไม่มี card wrapper)
 * <EmptyState
 *   icon={FolderOpen}
 *   title="ยังไม่มีโครงการ"
 *   description="สร้างโครงการแรกของคุณเพื่อเริ่มต้น"
 *   variant="info"
 *   showCard={false}
 *   action={{
 *     label: 'สร้างโครงการใหม่',
 *     onClick: () => setShowCreateModal(true)
 *   }}
 * />
 * ```
 */
export function EmptyState({ 
  icon: Icon, 
  title, 
  description,
  action,
  variant = 'default',
  size = 'md',
  showCard = true,
  className = ''
}: EmptyStateProps) {
  const sizeClasses = {
    sm: 'py-8',
    md: 'py-12',
    lg: 'py-16'
  };

  const iconSizes = {
    sm: 'h-8 w-8',
    md: 'h-12 w-12',
    lg: 'h-16 w-16'
  };

  const variantClasses = {
    default: '',
    info: 'border-blue-200 bg-blue-50',
    warning: 'border-yellow-200 bg-yellow-50'
  };

  const content = (
    <div className={`text-center ${sizeClasses[size]}`}>
      {Icon && (
        <Icon className={`mx-auto mb-4 text-gray-400 ${iconSizes[size]}`} />
      )}
      <h3 className="mb-2 text-gray-900">{title}</h3>
      {description && (
        <p className="text-gray-600 mb-4">{description}</p>
      )}
      {action && (
        <Button 
          onClick={action.onClick}
          variant={action.variant || 'default'}
        >
          {action.label}
        </Button>
      )}
    </div>
  );

  if (!showCard) {
    return <div className={className}>{content}</div>;
  }

  return (
    <Card className={`${variantClasses[variant]} ${className}`}>
      <CardContent className="p-0">
        {content}
      </CardContent>
    </Card>
  );
}
