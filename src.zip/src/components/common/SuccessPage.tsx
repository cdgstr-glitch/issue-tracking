import React from 'react';
import { LucideIcon, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';

interface SuccessPageProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  variant?: 'success' | 'info' | 'warning';
  ticketNumber?: string;
  details?: {
    label: string;
    value: string | React.ReactNode;
  }[];
  actions?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'outline' | 'secondary';
  }[];
  className?: string;
}

/**
 * SuccessPage - หน้าแสดงผลสำเร็จที่ใช้ร่วมกันทั้งระบบ
 * 
 * @example
 * ```tsx
 * // Success page พื้นฐาน
 * <SuccessPage
 *   title="แจ้งเคสสำเร็จ!"
 *   description="งานของคุณได้ถูกส่งแล้ว และทีมสนับสนุนของเราจะตรวจสอบในไม่ช้า"
 *   variant="success"
 *   ticketNumber="TK-2026-001"
 *   actions={[
 *     {
 *       label: 'กลับหน้าแรก',
 *       onClick: () => onNavigate('/')
 *     }
 *   ]}
 * />
 * 
 * // Success page พร้อม details และ multiple actions
 * <SuccessPage
 *   title="✅ บันทึกและรับเคสสำเร็จ!"
 *   description="เคสได้ถูกบันทึกและรับเข้าสู่งานของคุณแล้ว"
 *   variant="info"
 *   ticketNumber="TK-2026-002"
 *   details={[
 *     { label: 'สถานะ', value: 'กำลังดำเนินการ' },
 *     { label: 'ผู้รับผิดชอบ', value: 'คุณ (Tier 1)' },
 *     { label: 'ประเภท', value: 'ปัญหาทางเทคนิค' }
 *   ]}
 *   actions={[
 *     {
 *       label: 'ดูรายละเอียดเคส',
 *       onClick: () => onNavigate('/ticket', ticketId)
 *     },
 *     {
 *       label: 'กลับรายการงาน',
 *       onClick: () => onNavigate('/admin/my-tickets'),
 *       variant: 'outline'
 *     }
 *   ]}
 * />
 * ```
 */
export function SuccessPage({
  title,
  description,
  icon: Icon = CheckCircle,
  variant = 'success',
  ticketNumber,
  details,
  actions,
  className = ''
}: SuccessPageProps) {
  const variantConfig = {
    success: {
      cardClass: 'border-green-200 bg-green-50',
      iconBg: 'bg-green-600'
    },
    info: {
      cardClass: 'border-blue-200 bg-blue-50',
      iconBg: 'bg-blue-600'
    },
    warning: {
      cardClass: 'border-yellow-200 bg-yellow-50',
      iconBg: 'bg-yellow-600'
    }
  };

  const config = variantConfig[variant];

  return (
    <div className={`container mx-auto max-w-2xl px-4 py-12 ${className}`}>
      <Card className={config.cardClass}>
        <CardContent className="p-12 text-center">
          {/* Icon */}
          <div className="mb-6 flex justify-center">
            <div className={`flex h-20 w-20 items-center justify-center rounded-full ${config.iconBg}`}>
              <Icon className="h-10 w-10 text-white" />
            </div>
          </div>

          {/* Title */}
          <h2 className="mb-4">{title}</h2>

          {/* Description */}
          <p className="mb-6 text-gray-700">{description}</p>

          {/* Ticket Details */}
          {(ticketNumber || details) && (
            <div className="mb-6 rounded-lg bg-white p-6 text-left">
              {ticketNumber && (
                <div className="mb-4 pb-4 border-b">
                  <p className="text-sm text-gray-600">หมายเลขเคส</p>
                  <p className="text-lg font-semibold text-blue-600">{ticketNumber}</p>
                </div>
              )}
              {details && details.map((detail, index) => (
                <div key={index} className={index > 0 ? 'mt-3 pt-3 border-t' : ''}>
                  <p className="text-sm text-gray-600">{detail.label}</p>
                  <div className="mt-1 font-medium">{detail.value}</div>
                </div>
              ))}
            </div>
          )}

          {/* Actions */}
          {actions && actions.length > 0 && (
            <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
              {actions.map((action, index) => (
                <Button
                  key={index}
                  onClick={action.onClick}
                  variant={action.variant || 'default'}
                  className="w-full sm:w-auto"
                >
                  {action.label}
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
