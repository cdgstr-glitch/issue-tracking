import { useEffect, useRef } from 'react';
import { suggestedHashtags } from '../lib/hashtags';

interface HashtagDropdownProps {
  searchTerm: string;
  position: { top: number; left: number };
  onSelect: (hashtag: string) => void;
  onClose: () => void;
}

export function HashtagDropdown({ searchTerm, position, onSelect, onClose }: HashtagDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Filter hashtags based on search term
  const filteredHashtags = suggestedHashtags.filter(tag =>
    tag.value.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tag.description.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, 10); // Limit to 10 results

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (filteredHashtags.length === 0) {
    return null;
  }

  const categoryColors: Record<string, string> = {
    'priority': 'bg-red-100 text-red-700',
    'type': 'bg-blue-100 text-blue-700',
    'request': 'bg-green-100 text-green-700',
    'status': 'bg-yellow-100 text-yellow-700',
    'department': 'bg-purple-100 text-purple-700',
    'platform': 'bg-orange-100 text-orange-700',
    'issue': 'bg-pink-100 text-pink-700',
  };

  return (
    <div
      ref={dropdownRef}
      className="absolute z-50 w-80 max-h-64 overflow-y-auto bg-white border border-gray-300 rounded-lg shadow-xl"
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
      }}
    >
      <div className="p-2 text-xs text-gray-500 border-b bg-gray-50">
        พิมพ์เพื่อค้นหาแฮชแท็ก...
      </div>
      <div className="p-1">
        {filteredHashtags.map((tag) => {
          const colorClass = categoryColors[tag.category] || 'bg-gray-100 text-gray-700';
          
          return (
            <button
              key={tag.id}
              type="button"
              className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-50 rounded cursor-pointer text-left transition-colors"
              onClick={() => onSelect(tag.value)}
            >
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${colorClass}`}>
                {tag.value}
              </span>
              <span className="text-xs text-gray-500 flex-1">{tag.description}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
