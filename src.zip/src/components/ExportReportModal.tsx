import { useState } from 'react';
import { X, Download, FileText, FileSpreadsheet, File } from 'lucide-react';
import { Button } from './ui/button';

interface ExportReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportType: string;
}

type ExportFormat = 'excel' | 'pdf' | 'csv';
type DateRange = 'today' | 'last7days' | 'last30days' | 'thisMonth' | 'lastMonth' | 'custom';

export function ExportReportModal({ isOpen, onClose, reportType }: ExportReportModalProps) {
  const [format, setFormat] = useState<ExportFormat>('excel');
  const [dateRange, setDateRange] = useState<DateRange>('last30days');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  
  // Fields to include in export
  const [selectedFields, setSelectedFields] = useState({
    ticketId: true,
    organization: true,
    channel: true,
    createdDate: true,
    createdTime: true,
    reporter: true,
    title: true,
    status: true,
    priority: true,
    dueDate: true,
    closedDate: true,
    tier: true,
    slaStatus: true,
    responseTime: true,
    resolutionTime: true,
    assignee: true,
  });

  const fieldLabels = {
    ticketId: 'รหัสเคส',
    organization: 'หน่วยงาน',
    channel: 'ช่องทางแจ้งปัญหา',
    createdDate: 'วันที่รับแจ้ง',
    createdTime: 'เวลาที่รับแจ้ง',
    reporter: 'ชื่อลูกค้าที่แจ้ง',
    title: 'หัวข้อปัญหาและกิจกรรม',
    status: 'สถานะ',
    priority: 'ความสำคัญ',
    dueDate: 'วันครบกำหนด',
    closedDate: 'วันที่ปิด',
    tier: 'ระดับการดำเนินการ',
    slaStatus: 'สถานะ SLA',
    responseTime: 'เวลาตอบกลับ',
    resolutionTime: 'เวลาแก้ไข',
    assignee: 'ชื่อผู้ดำเนินการแก้ไข',
  };

  const dateRangeOptions = [
    { value: 'today', label: 'วันนี้' },
    { value: 'last7days', label: '7 วันที่แล้ว' },
    { value: 'last30days', label: '30 วันที่แล้ว' },
    { value: 'thisMonth', label: 'เดือนนี้' },
    { value: 'lastMonth', label: 'เดือนที่แล้ว' },
    { value: 'custom', label: 'กำหนดเอง' },
  ];

  const formatOptions = [
    { value: 'excel', label: 'Excel (XLSX)', icon: FileSpreadsheet, color: 'text-green-600' },
    { value: 'pdf', label: 'PDF', icon: FileText, color: 'text-red-600' },
    { value: 'csv', label: 'CSV', icon: File, color: 'text-blue-600' },
  ];

  const toggleField = (field: keyof typeof selectedFields) => {
    setSelectedFields(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const selectAllFields = () => {
    const allSelected = Object.fromEntries(
      Object.keys(selectedFields).map(key => [key, true])
    ) as typeof selectedFields;
    setSelectedFields(allSelected);
  };

  const deselectAllFields = () => {
    const allDeselected = Object.fromEntries(
      Object.keys(selectedFields).map(key => [key, false])
    ) as typeof selectedFields;
    setSelectedFields(allDeselected);
  };

  const handleExport = () => {
    const selectedCount = Object.values(selectedFields).filter(Boolean).length;
    
    if (selectedCount === 0) {
      alert('กรุณาเลือกฟิลด์อย่างน้อย 1 รายการ');
      return;
    }

    if (dateRange === 'custom' && (!customStartDate || !customEndDate)) {
      alert('กรุณาระบุช่วงวันที่');
      return;
    }

    // TODO: Implement actual export logic
    const formatLabel = formatOptions.find(f => f.value === format)?.label;
    const dateLabel = dateRangeOptions.find(d => d.value === dateRange)?.label;
    
    alert(`กำลังส่งออก${reportType}\nรูปแบบ: ${formatLabel}\nช่วงเวลา: ${dateLabel}\nฟิลด์ที่เลือก: ${selectedCount} รายการ`);
    onClose();
  };

  if (!isOpen) return null;

  // Sample data for preview
  const sampleData = [
    {
      ticketId: 'CDGS-2024-001',
      title: 'ระบบล็อกอินไม่ได้',
      status: 'ปิดแล้ว',
      priority: 'สูง',
      reporter: 'ศิริพร อารีมิตร',
      assignee: 'วรรณภา แซ่ด่าง',
      createdDate: '2024-01-10',
      createdTime: '10:30:00',
      dueDate: '2024-01-12',
      closedDate: '2024-01-11',
      channel: 'Email',
      organization: 'MRTA',
      tier: 'Tier 2',
      slaStatus: 'ผ่าน',
      responseTime: '15 นาที',
      resolutionTime: '1.5 ชั่วโมง',
    },
    {
      ticketId: 'CDGS-2024-002',
      title: 'ขอเพิ่ม User Account',
      status: 'กำลังดำเนินการ',
      priority: 'ปานกลาง',
      reporter: 'นางสาววิภา เพชรรัตน์',
      assignee: 'วรรณภา แซ่ด่าง',
      createdDate: '2024-01-11',
      createdTime: '11:45:00',
      dueDate: '2024-01-13',
      closedDate: '-',
      channel: 'Web Portal',
      organization: 'DOT',
      tier: 'Tier 1',
      slaStatus: 'ในเกณฑ์',
      responseTime: '8 นาที',
      resolutionTime: '-',
    },
    {
      ticketId: 'CDGS-2024-003',
      title: 'เครื่อง Printer ขัดข้อง',
      status: 'รอดำเนินการ',
      priority: 'น้อย',
      reporter: 'นายอนุชา สุขสันต์',
      assignee: '-',
      createdDate: '2024-01-12',
      createdTime: '12:00:00',
      dueDate: '2024-01-15',
      closedDate: '-',
      channel: 'Phone',
      organization: 'DRT',
      tier: 'Tier 1',
      slaStatus: 'ในเกณฑ์',
      responseTime: '12 นาที',
      resolutionTime: '-',
    },
    {
      ticketId: 'CDGS-2024-004',
      title: 'ขอติดตั้งโปรแกรม AutoCAD',
      status: 'ปิดแล้ว',
      priority: 'ปานกลาง',
      reporter: 'นางพิมพ์ใจ ศรีสุข',
      assignee: 'ยุทธนา คณามิ่งมงคล',
      createdDate: '2024-01-09',
      createdTime: '09:15:00',
      dueDate: '2024-01-11',
      closedDate: '2024-01-10',
      channel: 'Web Portal',
      organization: 'DTAM',
      tier: 'Tier 2',
      slaStatus: 'ผ่าน',
      responseTime: '5 นาที',
      resolutionTime: '45 นาที',
    },
    {
      ticketId: 'CDGS-2024-005',
      title: 'ระบบ VPN เชื่อมต่อไม่ได้',
      status: 'กำลังดำเนินการ',
      priority: 'สูงมาก',
      reporter: 'นายธนพล มั่นคง',
      assignee: 'ประกาศิต ประคองเพ็ชร',
      createdDate: '2024-01-13',
      createdTime: '13:30:00',
      dueDate: '2024-01-13',
      closedDate: '-',
      channel: 'Email',
      organization: 'MOT',
      tier: 'Tier 3',
      slaStatus: 'ล่าช้า',
      responseTime: '3 นาที',
      resolutionTime: '-',
    },
    {
      ticketId: 'CDGS-2024-006',
      title: 'ขอสิทธิ์เข้าถึง Database',
      status: 'หยุดชั่วคราว',
      priority: 'ปานกลาง',
      reporter: 'นางสาวชนิดา บุญมี',
      assignee: 'ประวิช จินทนากร',
      createdDate: '2024-01-08',
      createdTime: '08:00:00',
      dueDate: '2024-01-10',
      closedDate: '-',
      channel: 'Web Portal',
      organization: 'MOTS',
      tier: 'Tier 2',
      slaStatus: 'ในเกณฑ์',
      responseTime: '20 นาที',
      resolutionTime: '-',
    },
    {
      ticketId: 'CDGS-2024-007',
      title: 'Email ไม่สามารถส่งออกได้',
      status: 'ปิดแล้ว',
      priority: 'สูง',
      reporter: 'นายกิตติพงษ์ แก้วขาว',
      assignee: 'เขมิกา แซ่ตั้ง',
      createdDate: '2024-01-07',
      createdTime: '07:45:00',
      dueDate: '2024-01-09',
      closedDate: '2024-01-08',
      channel: 'Phone',
      organization: 'NESDC',
      tier: 'Tier 1',
      slaStatus: 'ผ่าน',
      responseTime: '10 นาที',
      resolutionTime: '2 ชั่วโมง',
    },
    {
      ticketId: 'CDGS-2024-008',
      title: 'ขอ Reset Password',
      status: 'ปิดแล้ว',
      priority: 'น้อย',
      reporter: 'นางสาวมณีรัตน์ ทองดี',
      assignee: 'ธัญญาพร ทองแก้ว',
      createdDate: '2024-01-12',
      createdTime: '12:15:00',
      dueDate: '2024-01-12',
      closedDate: '2024-01-12',
      channel: 'Chat',
      organization: 'PRD',
      tier: 'Tier 1',
      slaStatus: 'ผ่าน',
      responseTime: '2 นาที',
      resolutionTime: '5 นาที',
    },
  ];

  const getVisibleColumns = () => {
    return Object.entries(selectedFields)
      .filter(([_, isSelected]) => isSelected)
      .map(([key]) => ({
        key: key as keyof typeof selectedFields,
        label: fieldLabels[key as keyof typeof fieldLabels],
      }));
  };

  const visibleColumns = getVisibleColumns();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-2 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header - Reduced height */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 sm:px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Download className="h-5 w-5 flex-shrink-0" />
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-semibold truncate">ส่งออกรายงาน</h2>
              <p className="text-xs text-blue-100 truncate">{reportType}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white transition-colors flex-shrink-0"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 sm:space-y-6">
          {/* Export Format */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-3">
              รูปแบบไฟล์
            </label>
            <div className="grid grid-cols-3 gap-3">
              {formatOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <button
                    key={option.value}
                    onClick={() => setFormat(option.value as ExportFormat)}
                    className={`
                      p-4 rounded-lg border-2 transition-all
                      ${format === option.value
                        ? 'border-blue-500 bg-blue-50 shadow-md'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }
                    `}
                  >
                    <Icon className={`h-8 w-8 mx-auto mb-2 ${option.color}`} />
                    <div className="text-sm font-medium text-gray-900">
                      {option.label}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date Range */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-3">
              ช่วงเวลา
            </label>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as DateRange)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {dateRangeOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>

            {dateRange === 'custom' && (
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div>
                  <label className="block text-xs text-gray-600 mb-1">วันที่เริ่มต้น</label>
                  <input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-600 mb-1">วันที่สิ้นสุด</label>
                  <input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Fields Selection */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-medium text-gray-900">
                เลือกฟิลด์ที่ต้องการส่งออก
              </label>
              <div className="flex gap-2">
                <button
                  onClick={selectAllFields}
                  className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                >
                  เลือกทั้งหมด
                </button>
                <span className="text-gray-300">|</span>
                <button
                  onClick={deselectAllFields}
                  className="text-xs text-gray-600 hover:text-gray-700 font-medium"
                >
                  ยกเลิกทั้งหมด
                </button>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
              <div className="grid grid-cols-2 gap-3">
                {Object.entries(fieldLabels).map(([key, label]) => (
                  <label
                    key={key}
                    className="flex items-center gap-2 cursor-pointer group"
                  >
                    <input
                      type="checkbox"
                      checked={selectedFields[key as keyof typeof selectedFields]}
                      onChange={() => toggleField(key as keyof typeof selectedFields)}
                      className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-2 focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-700 group-hover:text-gray-900">
                      {label}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div className="mt-2 text-xs text-gray-500">
              เลือกแล้ว {Object.values(selectedFields).filter(Boolean).length} จาก {Object.keys(selectedFields).length} รายการ
            </div>
          </div>

          {/* Preview Table */}
          {visibleColumns.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-900 mb-3">
                ตัวอย่างตาราง ({visibleColumns.length} คอลัมน์)
              </label>
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        {visibleColumns.map((col) => (
                          <th
                            key={col.key}
                            className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider whitespace-nowrap"
                          >
                            {col.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {sampleData.map((row, idx) => (
                        <tr key={idx} className="hover:bg-gray-50">
                          {visibleColumns.map((col) => (
                            <td
                              key={col.key}
                              className="px-4 py-3 text-sm text-gray-900 whitespace-nowrap"
                            >
                              {row[col.key as keyof typeof row]}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <p className="mt-2 text-xs text-gray-500">
                แสดง {sampleData.length} แถวจากข้อมูลจริง (ตัวอย่าง)
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50 flex justify-end gap-3">
          <Button
            onClick={onClose}
            variant="outline"
          >
            ยกเลิก
          </Button>
          <Button
            onClick={handleExport}
            className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
          >
            <Download className="h-4 w-4" />
            ส่งออกรายงาน
          </Button>
        </div>
      </div>
    </div>
  );
}