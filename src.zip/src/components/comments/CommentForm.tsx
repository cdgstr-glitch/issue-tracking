import React, { useState, useRef, useEffect } from 'react';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { MessageSquare, Paperclip, X } from 'lucide-react';
import { PublicCommentConfirmDialog } from './PublicCommentConfirmDialog';

interface CommentFormProps {
  comment: string;
  setComment: (comment: string) => void;
  isInternal: boolean;
  setIsInternal: (isInternal: boolean) => void;
  onSubmit: (attachments?: File[]) => void; // ✅ เพิ่ม parameter สำหรับไฟล์แนบ
  showInternalToggle?: boolean; // ซ่อนสำหรับ Customer
  placeholder?: string;
  submitButtonText?: string;
  disabled?: boolean;
}

export function CommentForm({
  comment,
  setComment,
  isInternal,
  setIsInternal,
  onSubmit,
  showInternalToggle = true,
  placeholder = 'พิมพ์ความคิดเห็นของคุณที่นี่...',
  submitButtonText = 'เพิ่มความคิดเห็น',
  disabled = false,
}: CommentFormProps) {
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [attachments, setAttachments] = useState<File[]>([]); // ✅ เก็บไฟล์แนบ
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ✅ Clear attachments เมื่อ comment ถูก clear (หลังส่งสำเร็จ)
  useEffect(() => {
    if (comment === '') {
      setAttachments([]);
    }
  }, [comment]);

  const handleSubmitClick = () => {
    if (!comment.trim()) return;

    // ✅ ถ้าเป็น "ความคิดเห็นสาธารณะ" → แสดง Modal เตือน
    if (!isInternal) {
      setShowConfirmDialog(true);
      return;
    }

    // ✅ ถ้าเป็น "หมายเหตุภายใน" → ส่งเลย (ไม่มี Modal)
    onSubmit(attachments);
  };

  const handleConfirmSubmit = () => {
    setShowConfirmDialog(false);
    onSubmit(attachments);
  };

  const handleCancelSubmit = () => {
    setShowConfirmDialog(false);
  };

  // ✅ จัดการไฟล์แนบ
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newFiles = Array.from(files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
    // Reset input เพื่อให้สามารถเลือกไฟล์เดิมซ้ำได้
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <>
      <div className="space-y-3 border-t pt-4">
        <Textarea
          placeholder={placeholder}
          rows={4}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="resize-none"
          disabled={disabled}
        />
        
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex gap-2">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              onChange={handleFileChange}
              className="hidden"
              accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
              disabled={disabled}
            />
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => fileInputRef.current?.click()}
              disabled={disabled}
            >
              <Paperclip className="mr-2 h-4 w-4" />
              แนบไฟล์
            </Button>
          </div>
          
          <div className="flex gap-2">
            {/* ✅ แสดง Dropdown เฉพาะ Staff/Tier/Admin - ซ่อนสำหรับ Customer */}
            {showInternalToggle && (
              <Select 
                value={isInternal ? 'internal' : 'public'} 
                onValueChange={(value) => setIsInternal(value === 'internal')}
                disabled={disabled}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">
                    👁️ ความคิดเห็นสาธารณะ
                  </SelectItem>
                  <SelectItem value="internal">
                    🔒 หมายเหตุภายใน
                  </SelectItem>
                </SelectContent>
              </Select>
            )}
            
            <Button 
              onClick={handleSubmitClick}
              disabled={disabled || !comment.trim()}
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              {submitButtonText}
            </Button>
          </div>
        </div>

        {/* ✅ แสดงรายการไฟล์แนบ (ย้ายมาอยู่หลังปุ่มแนบไฟล์) */}
        {attachments.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-gray-600">ไฟล์ที่แนบ ({attachments.length}):</p>
            {attachments.map((file, index) => (
              <div 
                key={index}
                className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-lg p-2"
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <Paperclip className="h-4 w-4 text-gray-400 flex-shrink-0" />
                  <span className="text-sm text-gray-700 truncate">
                    {file.name}
                  </span>
                  <span className="text-xs text-gray-500 flex-shrink-0">
                    ({(file.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemoveAttachment(index)}
                  className="flex-shrink-0"
                  disabled={disabled}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {/* ✅ คำอธิบายเพิ่มเติม */}
        {showInternalToggle && (
          <div className="text-xs text-gray-500 space-y-1">
            {!isInternal ? (
              <p className="text-amber-600">
                <span className="font-medium">👁️ ความคิดเห็นสาธารณะ:</span> ลูกค้าจะเห็นข้อความนี้ และได้รับอีเมลแจ้งเตือน
              </p>
            ) : (
              <p className="text-gray-600">
                <span className="font-medium">🔒 หมายเหตุภายใน:</span> เฉพาะเจ้าหน้าที่เท่านั้นที่เห็นข้อความนี้ (ลูกค้าไม่เห็น)
              </p>
            )}
          </div>
        )}
      </div>

      {/* ✅ Modal ยืนยันการส่งความคิดเห็นสาธารณะ */}
      <PublicCommentConfirmDialog
        open={showConfirmDialog}
        onOpenChange={setShowConfirmDialog}
        commentText={comment}
        onConfirm={handleConfirmSubmit}
        onCancel={handleCancelSubmit}
      />
    </>
  );
}