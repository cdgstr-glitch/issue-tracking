import React from 'react';
import { Paperclip, User, ShieldCheck } from 'lucide-react';

interface Comment {
  id: string;
  author: string;
  authorRole?: string;
  content: string;
  isInternal: boolean;
  createdAt: Date;
  attachments?: string[] | File[];
}

interface CommentItemProps {
  comment: Comment;
  formatDate: (date: Date) => string;
}

export function CommentItem({ comment, formatDate }: CommentItemProps) {
  // Helper to determine badge
  const getRoleBadge = () => {
    const role = comment.authorRole?.toLowerCase() || '';
    
    if (role === 'customer') {
      return (
        <span className="inline-flex items-center gap-1 rounded bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-700">
          <User className="h-3 w-3" />
          ลูกค้า
        </span>
      );
    }
    
    if (['staff', 'tier1', 'tier2', 'tier3', 'admin'].includes(role)) {
      return (
        <span className="inline-flex items-center gap-1 rounded bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">
          <ShieldCheck className="h-3 w-3" />
          เจ้าหน้าที่
        </span>
      );
    }
    
    return null;
  };

  return (
    <div 
      className={`rounded-lg border p-4 ${ 
        comment.isInternal 
          ? 'border-yellow-200 bg-yellow-50' 
          : 'bg-white'
      }`}
    >
      <div className="mb-2 flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white text-sm">
            {comment.author?.charAt(0) || '?'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="font-medium text-gray-900">{comment.author || 'Unknown'}</p>
              {getRoleBadge()}
            </div>
            <p className="text-xs text-gray-600">
              {formatDate(comment.createdAt)}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          {comment.isInternal && (
            <span className="rounded bg-yellow-200 px-2 py-0.5 text-xs font-medium text-yellow-800">
              🔒 หมายเหตุภายใน
            </span>
          )}
          {!comment.isInternal && (
            <span className="rounded bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">
              👁️ สาธารณะ
            </span>
          )}
        </div>
      </div>
      <p className="text-gray-700 whitespace-pre-wrap">{comment.content}</p>
      
      {/* ✅ แสดงไฟล์แนบ */}
      {comment.attachments && comment.attachments.length > 0 && (
        <div className="mt-3 space-y-2">
          <p className="text-xs text-gray-500 font-medium">ไฟล์แนบ:</p>
          {comment.attachments.map((file, index) => {
            const fileName = typeof file === 'string' ? file : file.name;
            const fileSize = typeof file === 'string' ? null : file.size;
            
            return (
              <div 
                key={index}
                className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg p-2"
              >
                <Paperclip className="h-4 w-4 text-gray-400 flex-shrink-0" />
                <span className="text-sm text-gray-700 truncate">
                  {fileName}
                </span>
                {fileSize && (
                  <span className="text-xs text-gray-500 flex-shrink-0">
                    ({(fileSize / 1024).toFixed(1)} KB)
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}