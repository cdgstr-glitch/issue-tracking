import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { AlertTriangle } from 'lucide-react';

interface PublicCommentConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  commentText: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function PublicCommentConfirmDialog({
  open,
  onOpenChange,
  commentText,
  onConfirm,
  onCancel,
}: PublicCommentConfirmDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100">
              <AlertTriangle className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <DialogTitle className="text-lg">ยืนยันส่งความคิดเห็นสาธารณะ</DialogTitle>
              <DialogDescription className="text-sm text-gray-600">
                ข้อความนี้จะแสดงให้ลูกค้าเห็น
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* คำเตือน */}
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
            <div className="flex gap-2">
              <AlertTriangle className="h-5 w-5 flex-shrink-0 text-amber-600 mt-0.5" />
              <div className="text-sm space-y-1">
                <p className="font-medium text-amber-900">
                  ⚠️ ข้อความนี้จะถูกส่งไปยัง Timeline ของลูกค้า
                </p>
                <ul className="text-amber-800 space-y-1 ml-4 list-disc">
                  <li>ลูกค้าจะเห็นข้อความนี้ทันที</li>
                  <li>ระบบจะส่งอีเมลแจ้งเตือนไปยังลูกค้า</li>
                  <li>โปรดตรวจสอบความถูกต้องก่อนส่ง</li>
                </ul>
              </div>
            </div>
          </div>

          {/* แสดงข้อความที่จะส่ง */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">
              📝 ข้อความที่จะส่ง:
            </p>
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
              <p className="text-sm text-gray-900 whitespace-pre-wrap">
                {commentText || '(ไม่มีข้อความ)'}
              </p>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
          >
            ยกเลิก
          </Button>
          <Button
            type="button"
            onClick={onConfirm}
            className="bg-blue-600 hover:bg-blue-700"
          >
            ✅ ยืนยันส่งความคิดเห็น
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
