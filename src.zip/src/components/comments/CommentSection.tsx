import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { CommentItem } from './CommentItem';
import { CommentForm } from './CommentForm';
import { toast } from 'sonner';

interface Comment {
  id: string;
  author: string;
  authorRole?: string;
  content: string;
  isInternal: boolean;
  createdAt: Date;
  attachments?: string[] | File[]; // ✅ เพิ่มไฟล์แนบ
}

interface CommentSectionProps {
  comments: Comment[];
  onAddComment: (comment: string, isInternal: boolean, attachments?: File[]) => void; // ✅ เพิ่ม attachments
  formatDate: (date: Date) => string;
  currentUserName: string;
  currentUserRole: string;
  showInternalToggle?: boolean; // ซ่อนสำหรับ Customer
  readOnly?: boolean; // สำหรับหน้าที่อ่านอย่างเดียว (เช่น TrackTicketDetailPage)
  title?: string;
  placeholder?: string;
  submitButtonText?: string;
}

export function CommentSection({
  comments,
  onAddComment,
  formatDate,
  currentUserName,
  currentUserRole,
  showInternalToggle = true,
  readOnly = false,
  title = 'ความคิดเห็นและกิจกรรม',
  placeholder = 'พิมพ์ความคิดเห็นของคุณที่นี่...',
  submitButtonText = 'เพิ่มความคิดเห็น',
}: CommentSectionProps) {
  const [comment, setComment] = useState('');
  const [isInternal, setIsInternal] = useState(false);

  const handleAddComment = (attachments?: File[]) => {
    if (!comment.trim()) return;

    // เรียก callback function พร้อมไฟล์แนบ
    onAddComment(comment.trim(), isInternal, attachments);

    // แสดง toast แจ้งเตือน
    toast.success(
      isInternal 
        ? '✅ เพิ่มหมายเหตุภายในเรียบร้อย' 
        : '✅ เพิ่มความคิดเห็นสาธารณะเรียบร้อย'
    );

    // Clear form
    setComment('');
    setIsInternal(false); // Reset กลับไปเป็น public
  };

  // ✅ กรองเฉพาะ comment ที่ user มีสิทธิ์เห็น
  const visibleComments = comments.filter(comment => {
    // ✅ ถ้าเป็น Customer → เห็นเฉพาะ public comments
    if (currentUserRole === 'customer') {
      return !comment.isInternal;
    }
    // ✅ ถ้าเป็น Staff/Tier/Admin → เห็นทั้ง public และ internal
    return true;
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* แสดง Comments */}
        {visibleComments.length === 0 ? (
          <p className="text-sm text-gray-500 text-center py-4">
            ยังไม่มีความคิดเห็น
          </p>
        ) : (
          visibleComments.map((comment) => (
            <CommentItem 
              key={comment.id} 
              comment={comment} 
              formatDate={formatDate} 
            />
          ))
        )}

        {/* ✅ ฟอร์มเพิ่ม Comment (แสดงเฉพาะเมื่อ readOnly = false) */}
        {!readOnly && (
          <CommentForm
            comment={comment}
            setComment={setComment}
            isInternal={isInternal}
            setIsInternal={setIsInternal}
            onSubmit={handleAddComment}
            showInternalToggle={showInternalToggle}
            placeholder={placeholder}
            submitButtonText={submitButtonText}
          />
        )}
      </CardContent>
    </Card>
  );
}