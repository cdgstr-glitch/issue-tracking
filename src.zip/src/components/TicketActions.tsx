import { useState } from 'react';
import { Label } from './ui/label';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { AssigneeSelector } from './AssigneeSelector';
import { EmailPreviewModal } from './EmailPreviewModal';
import { ProjectSelectorModal } from './ProjectSelectorModal';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/mockDb/client';
import { toast } from 'sonner@2.0.3';
import { UserCheck, ArrowUpCircle, ArrowDownCircle, CheckCircle, PauseCircle, PlayCircle } from 'lucide-react';
import { Ticket, TicketStatus, TicketStage, User } from '../types';
import { getTier1ForProject, findUserWithLeastTickets } from '../lib/ticketUtils';
import { can, CAPABILITIES } from '../lib/permissions';

interface TicketActionsProps {
  ticket: Ticket;
  userRole: string; // Legacy
  userId: string;
  onUpdate: (updates: Partial<Ticket>) => void;
}

export function TicketActions({ ticket, userRole, userId, onUpdate }: TicketActionsProps) {
  const { user, activeRole } = useAuth();

  // UI States
  const [showEscalateDialog, setShowEscalateDialog] = useState(false);
  const [showReturnDialog, setShowReturnDialog] = useState(false);
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [showResolveDialog, setShowResolveDialog] = useState(false);
  const [showHoldDialog, setShowHoldDialog] = useState(false);

  // ✅ Project Selector with Triage
  const [showProjectSelector, setShowProjectSelector] = useState(false);

  // Form States
  const [escalateTier, setEscalateTier] = useState<1 | 2 | 3 | ''>('');
  const [selectedAssignee, setSelectedAssignee] = useState<string>('auto');
  const [escalateNote, setEscalateNote] = useState('');
  const [returnNote, setReturnNote] = useState('');
  const [closeNote, setCloseNote] = useState('');
  const [resolveNote, setResolveNote] = useState('');
  const [holdReason, setHoldReason] = useState('');

  // Ticket Context
  const isAssignedToMe = ticket.assignedTo === userId;
  const isUnassigned = !ticket.assignedTo;
  const isInProgress = ticket.status === 'in_progress';
  const isWaiting = ticket.status === 'on_hold';
  const isResolved = ticket.status === 'resolved';

  // Permissions Check (Capability Based)
  const isPureAdmin = activeRole === 'admin' && !can(user, CAPABILITIES.ACCEPT_TICKET);
  if (isPureAdmin) return null;
  if (ticket.status === 'closed') return null;

  const hasTier1Role = user?.roles?.includes('tier1');
  const hasTier2Role = user?.roles?.includes('tier2');
  const hasTier3Role = user?.roles?.includes('tier3');

  // ✅ SSoT: canAccept ใช้ accepted === false เป็น source of truth เดียว
  // 'new'     → เคสใหม่ assignedTo = null
  // 'pending' → รอดำเนินการ: มอบหมายแล้ว accepted = false ห้ามเปลี่ยนชื่อ status นี้
  // 'resolved' ที่ accepted = false → T1 รับกลับเพื่อปิด (canClose จัดการ ไม่ใช่ canAccept)
  const canAccept =
    can(user, CAPABILITIES.ACCEPT_TICKET) &&
    ticket.accepted === false &&
    ['new', 'pending'].includes(ticket.status) &&
    (isUnassigned || isAssignedToMe) &&
    (
      // ✅ FIX: supervisor ทำงานเหมือน tier1 (ไม่เปลี่ยน UI, แก้ logic เท่านั้น)
      (ticket.stage === 'tier1' &&
        (activeRole === 'tier1' ||
          activeRole === 'supervisor' ||
          (activeRole === 'admin' && hasTier1Role))) ||
      (ticket.stage === 'tier2' &&
        (activeRole === 'tier2' || (activeRole === 'admin' && hasTier2Role))) ||
      (ticket.stage === 'tier3' &&
        (activeRole === 'tier3' || (activeRole === 'admin' && hasTier3Role)))
    );

  // ✅ canClose: เฉพาะ T1 (CLOSE_TICKET capability) และเคสต้องอยู่ใน stage tier1
  // รับกลับมาแล้ว (accepted = true, in_progress) หรือ resolved ที่ T1 แก้เองตั้งแต่ต้น
  const canClose =
    can(user, CAPABILITIES.CLOSE_TICKET) &&
    ticket.stage === 'tier1' &&
    (isResolved || isInProgress) &&
    isAssignedToMe;

  // ✅ canResolve: T1 แก้ไขเองแล้วต้องการ mark resolved ก่อนปิด
  // ใช้ CLOSE_TICKET เพราะเป็น T1 action ที่นำไปสู่การปิด
  const canResolve =
    can(user, CAPABILITIES.CLOSE_TICKET) &&
    ticket.stage === 'tier1' &&
    isInProgress &&
    isAssignedToMe;

  // ✅ canReturnToT1: T2/T3 ส่งกลับ T1 เพื่อปิด (ไม่มี CLOSE_TICKET แต่มี UPDATE_TICKET)
  const canReturnToT1 =
    !can(user, CAPABILITIES.CLOSE_TICKET) &&
    can(user, CAPABILITIES.UPDATE_TICKET) &&
    isInProgress &&
    isAssignedToMe;

  const canEscalate = can(user, CAPABILITIES.ESCALATE_TICKET) && isInProgress && isAssignedToMe;
  const canHold = can(user, CAPABILITIES.UPDATE_TICKET) && isInProgress && isAssignedToMe;
  const canResume = can(user, CAPABILITIES.UPDATE_TICKET) && isWaiting && isAssignedToMe;

  // --- Handlers ---

  const handleAcceptClick = () => {
    // ✅ Always show ProjectSelector (Triage Modal) for "Accept" action
    setShowProjectSelector(true);
  };

  const handleConfirmAccept = (triageData: any) => {
    toast.success(`รับเคสสำเร็จ`);

    const updates: Partial<Ticket> = {
      status: 'in_progress',
      accepted: true, // ✅ SSoT: mark กดรับแล้ว
      assignedTo: userId,
      assignedBy: userId,
      assignedAt: new Date().toISOString(),
      ...triageData,
    };

    // ✅ Laravel-ready: store product selection in pivot (ticket_products)
    // NOTE: ProjectSelectorModal ส่ง productId มา → รองรับทั้ง productId / productValue แบบ backward compatible
    const productCode = triageData?.productValue ?? triageData?.productId;
    if (productCode) {
      updates.product = productCode;

      const product =
        db.products.getByCode(productCode) ||
        db.products
          .getAll()
          .find((p: any) => String((p as any).value ?? '').trim() === String(productCode).trim());

      if (product?.id) {
        db.ticketProducts.replaceForTicket(ticket.id, [product.id]);
      }
    }

    onUpdate(updates);
    setShowProjectSelector(false);
  };

  const handleEscalate = () => {
    if (!escalateTier) {
      toast.error('กรุณาเลือก Tier ที่จะส่งต่อ');
      return;
    }

    let assigneeId: string | undefined;
    const newStage: TicketStage = escalateTier === 1 ? 'tier1' : escalateTier === 2 ? 'tier2' : 'tier3';

    if (selectedAssignee === 'auto') {
      let users: User[] = [];
      if (escalateTier === 1) {
        const t1 = getTier1ForProject(ticket.projectId);
        if (t1) users = [t1];
      } else {
        users = db.users.getAll().filter(u => u.tier === escalateTier);
      }

      const u = findUserWithLeastTickets(users);
      assigneeId = u?.id;
    } else {
      assigneeId = selectedAssignee;
    }

    if (!assigneeId) {
      toast.error('ไม่พบผู้รับผิดชอบในระดับที่เลือก');
      return;
    }

    const assignee = db.users.getById(assigneeId);
    toast.success(`ส่งต่อเคสไปยัง ${assignee?.fullName || 'ผู้รับผิดชอบ'} (Tier ${escalateTier}) สำเร็จ`);

    onUpdate({
      stage: newStage, // ✅ stage เปลี่ยนตาม tier ที่ส่งต่อ
      status: 'pending', // ✅ รอดำเนินการ: มอบหมายแล้ว ยังไม่กดรับ — SSoT ห้ามเปลี่ยนชื่อ
      accepted: false, // ✅ SSoT: ผู้รับยังไม่กดรับ
      assignedTo: assigneeId,
      assignedBy: userId,
      assignedAt: new Date().toISOString(),
      previousAssignee: ticket.assignedTo,
    });

    setShowEscalateDialog(false);
    setEscalateNote('');
    setEscalateTier('');
    setSelectedAssignee('auto');
  };

  const handleReturnToTier1 = () => {
    let tier1: User | undefined = undefined;

    if (ticket.previousAssignee) {
      const prev = db.users.getById(ticket.previousAssignee);
      if (prev && prev.tier === 1) tier1 = prev;
    }

    if (!tier1 && ticket.assignedBy) {
      const by = db.users.getById(ticket.assignedBy);
      if (by && by.tier === 1) tier1 = by;
    }

    if (!tier1) {
      tier1 = getTier1ForProject(ticket.projectId);
    }

    if (!tier1) {
      toast.error('ไม่พบผู้รับผิดชอบ Tier1 สำหรับงานโครงการนี้');
      return;
    }

    toast.success(`ส่งกลับไปยัง ${tier1.fullName} (T1) เพื่อปิดเคส`);

    onUpdate({
      stage: 'tier1', // ✅ เคสกลับมาอยู่ที่ tier1
      status: 'resolved', // ✅ T2/T3 แก้เสร็จแล้ว → resolved (for_closure flow)
      accepted: false, // ✅ SSoT: T1 ยังต้องกดรับอีกครั้ง
      assignedTo: tier1.id,
      assignedBy: userId,
      assignedAt: new Date().toISOString(),
      previousAssignee: ticket.assignedTo,
      resolvedBy: userId,
      resolvedAt: new Date().toISOString(),
      resolution: returnNote || undefined,
    });

    setShowReturnDialog(false);
    setReturnNote('');
  };

  const handleClose = () => {
    toast.success('ปิดเคสสำเร็จ');
    onUpdate({
      status: 'closed',
      closedBy: userId,
      closedAt: new Date().toISOString(),
      closureNotes: closeNote || undefined,
    });
    setShowCloseDialog(false);
    setCloseNote('');
  };

  const handleResolve = () => {
    toast.success('มาร์คเคสเป็นแก้ไขเสร็จแล้ว');
    onUpdate({
      status: 'resolved',
      resolvedBy: userId,
      resolvedAt: new Date().toISOString(),
      resolution: resolveNote || undefined,
    });
    setShowResolveDialog(false);
    setResolveNote('');
  };

  const handleHold = () => {
    toast.success('หยุดดำเนินการเคสสำเร็จ');
    onUpdate({ status: 'on_hold' });
    setShowHoldDialog(false);
    setHoldReason('');
  };

  const handleResume = () => {
    toast.success('กลับมาดำเนินการเคสต่อ');
    onUpdate({ status: 'in_progress' });
  };

  return (
    <div className="flex flex-wrap gap-2">
      {/* Accept Button */}
      {canAccept && (
        <>
          <Button onClick={handleAcceptClick} className="gap-2 bg-blue-600 hover:bg-blue-700">
            <UserCheck className="h-4 w-4" />
            รับเคส
          </Button>

          <ProjectSelectorModal
            isOpen={showProjectSelector}
            onClose={() => setShowProjectSelector(false)}
            onSelect={(projectId, productId) => handleConfirmAccept({ projectId, productId })}
            enableProductVerification={true}
            initialProjectId={ticket.projectId}
            initialProduct={ticket.productValue || ticket.product || ''}
            initialType={ticket.type || ''}
            initialPriority={ticket.priority || ''}
            initialCategory={ticket.category || ''}
          />
        </>
      )}

      {/* Escalate Button */}
      {canEscalate && (
        <Dialog open={showEscalateDialog} onOpenChange={setShowEscalateDialog}>
          <DialogTrigger asChild>
            <Button variant="outline" className="gap-2">
              <ArrowUpCircle className="h-4 w-4" />
              ส่งต่อ
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>ส่งต่อเคส</DialogTitle>
              <DialogDescription>เลือกระดับและผู้รับผิดชอบที่จะส่งต่อเคสนี้</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label>ส่งต่อไปยัง</Label>
                <select
                  className="w-full mt-1 rounded-md border border-gray-300 p-2"
                  value={escalateTier}
                  onChange={e => {
                    const value = e.target.value;
                    setEscalateTier(value === '' ? '' : (parseInt(value) as 1 | 2 | 3));
                    setSelectedAssignee('auto');
                  }}
                >
                  <option value="">เลือกระดับ...</option>

                  {/* ✅ FIX: supervisor เหมือน tier1 (ไม่เปลี่ยน UI, แก้ logic เงื่อนไขเท่านั้น) */}
                  {(activeRole === 'tier1' || activeRole === 'supervisor') && (
                    <>
                      <option value="1">Tier 1 - ส่งให้เพื่อนร่วมทีม</option>
                      <option value="2">Tier 2 (SA)</option>
                      <option value="3">Tier 3 (Specialist)</option>
                    </>
                  )}

                  {activeRole === 'tier2' && (
                    <>
                      <option value="2">Tier 2 - ส่งให้เพื่อนร่วมทีม</option>
                      <option value="3">Tier 3 (Specialist)</option>
                    </>
                  )}
                  {activeRole === 'tier3' && (
                    <>
                      <option value="3">Tier 3 - ส่งให้เพื่อนร่วมทีม</option>
                    </>
                  )}
                  {activeRole === 'admin' && (
                    <>
                      <option value="1">Tier 1</option>
                      <option value="2">Tier 2</option>
                      <option value="3">Tier 3</option>
                    </>
                  )}
                </select>
              </div>

              {escalateTier && (
                <AssigneeSelector
                  tier={escalateTier as 1 | 2 | 3}
                  projectId={ticket.projectId}
                  value={selectedAssignee}
                  onChange={setSelectedAssignee}
                  currentUserId={userId}
                />
              )}

              <div>
                <Label>หมายเหตุ (ไม่บังคับ)</Label>
                <Textarea
                  placeholder="ระบุเหตุผลหรือรายละเอียดเพิ่มเติม..."
                  value={escalateNote}
                  onChange={e => setEscalateNote(e.target.value)}
                  rows={3}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowEscalateDialog(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleEscalate} disabled={!escalateTier}>
                ส่งต่อเคส
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Return to T1 Button */}
      {canReturnToT1 && (
        <Dialog open={showReturnDialog} onOpenChange={setShowReturnDialog}>
          <DialogTrigger asChild>
            <Button variant="outline" className="gap-2 border-green-600 text-green-600 hover:bg-green-50">
              <ArrowDownCircle className="h-4 w-4" />
              แก้ไขแล้วส่ง → T1 เพื่อปิด
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ส่งกลับ Tier 1 เพื่อปิดเคส</DialogTitle>
              <DialogDescription>เคสนี้จะถูกส่งกลับไปยัง Tier 1 เพื่อตรวจสอบและปิดเคส</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">สรุปการแก้ไข</Label>
                <Textarea
                  placeholder="สรุปวิธีการแก้ไขและผลลัพธ์..."
                  value={returnNote}
                  onChange={e => setReturnNote(e.target.value)}
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowReturnDialog(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleReturnToTier1} className="bg-green-600 hover:bg-green-700">
                ส่งกลับ T1
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Close Button (Tier 1 Only) */}
      {canClose && (
        <Dialog open={showCloseDialog} onOpenChange={setShowCloseDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-blue-600 hover:bg-blue-700">
              <CheckCircle className="h-4 w-4" />
              ปิดเคส
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ปิดเคส</DialogTitle>
              <DialogDescription>ยืนยันการปิดเคสนี้ เคสที่ปิดแล้วจะไม่สามารถแก้ไขได้</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">หมายเหตุการปิด (ไม่บังคับ)</Label>
                <Textarea
                  placeholder="ระบุหมายเหตุเพิ่มเติม..."
                  value={closeNote}
                  onChange={e => setCloseNote(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCloseDialog(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleClose} className="bg-blue-600 hover:bg-blue-700">
                ยืนยันการปิดเคส
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Resolve Button (Tier 1 Only - แก้ไขเองโดยไม่ผ่าน T2/T3) */}
      {canResolve && (
        <Dialog open={showResolveDialog} onOpenChange={setShowResolveDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-green-600 hover:bg-green-700">
              <CheckCircle className="h-4 w-4" />
              แก้ไขเสร็จแล้ว
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>แก้ไขเสร็จแล้ว</DialogTitle>
              <DialogDescription>ยืนยันการแก้ไขเสร็จแล้วและมาร์คเคสเป็น resolved</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">หมายเหตุการแก้ไข (ไม่บังคับ)</Label>
                <Textarea
                  placeholder="ระบุหมายเหตุเพิ่มเติม..."
                  value={resolveNote}
                  onChange={e => setResolveNote(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowResolveDialog(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleResolve} className="bg-green-600 hover:bg-green-700">
                ยืนยันการแก้ไขเสร็จแล้ว
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Hold Button */}
      {canHold && (
        <Dialog open={showHoldDialog} onOpenChange={setShowHoldDialog}>
          <DialogTrigger asChild>
            <Button variant="outline" className="gap-2 border-red-600 text-red-600 hover:bg-red-50">
              <PauseCircle className="h-4 w-4" />
              หยุดดำเนินการ
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>หยุดดำเนินการเคส</DialogTitle>
              <DialogDescription>ระบุเหตุผลในการหยุดดำเนินการเคส</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">เหตุผลในการหยุดดำเนินการ</Label>
                <Textarea
                  placeholder="ระบุเหตุผลในการหยุดดำเนินการ..."
                  value={holdReason}
                  onChange={e => setHoldReason(e.target.value)}
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowHoldDialog(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleHold} disabled={!holdReason} className="bg-red-600 hover:bg-red-700">
                หยุดดำเนินการ
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Resume Button */}
      {canResume && (
        <Button onClick={handleResume} className="gap-2 bg-blue-600 hover:bg-blue-700">
          <PlayCircle className="h-4 w-4" />
          ดำเนินการต่อ
        </Button>
      )}
    </div>
  );
}
