import React, { useState } from 'react';
import { X, Download, ZoomIn, FileText, File as FileIcon } from 'lucide-react';
import { Attachment } from '../types';
import { formatFileSize, isImageFile, getFileIcon } from '../lib/utils'; // Use utils instead of mockData
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AttachmentGalleryProps {
  attachments: Attachment[];
  showDownload?: boolean;
}

export function AttachmentGallery({ attachments, showDownload = true }: AttachmentGalleryProps) {
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  if (!attachments || attachments.length === 0) {
    return null;
  }

  const imageAttachments = attachments.filter(isImageFile);
  const otherAttachments = attachments.filter((att) => !isImageFile(att));

  const handleImageClick = (url: string) => {
    setLightboxImage(url);
  };

  const closeLightbox = () => {
    setLightboxImage(null);
  };

  return (
    <div className="space-y-4">
      {/* Image Gallery */}
      {imageAttachments.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
            <span>🖼️</span>
            <span>รูปภาพ ({imageAttachments.length})</span>
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {imageAttachments.map((attachment) => (
              <div
                key={attachment.id}
                className="relative group image-gallery-thumbnail rounded-lg overflow-hidden aspect-square cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                onClick={() => handleImageClick(attachment.url)}
              >
                <ImageWithFallback
                  src={attachment.url}
                  alt={attachment.filename}
                  className="w-full h-full object-cover image-preview-unlock"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all flex items-center justify-center">
                  <ZoomIn className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                {/* File Info Overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-white text-xs truncate font-medium">
                    {attachment.filename}
                  </p>
                  <p className="text-white/80 text-[10px]">
                    {formatFileSize(attachment.fileSize)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Other Files List */}
      {otherAttachments.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
            <span>📎</span>
            <span>ไฟล์เอกสาร ({otherAttachments.length})</span>
          </h4>
          <div className="space-y-2">
            {otherAttachments.map((attachment) => (
              <div
                key={attachment.id}
                className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-lg p-3 hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="text-2xl">{getFileIcon(attachment)}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {attachment.filename}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatFileSize(attachment.fileSize)} • อัปโหลดโดย {attachment.uploadedBy}
                    </p>
                  </div>
                </div>
                {showDownload && (
                  <button
                    className="ml-2 p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                    aria-label="ดาวน์โหลดไฟล์"
                    title="ดาวน์โหลด"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Lightbox for Images */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors z-10"
            aria-label="ปิด"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightboxImage}
            alt="Preview"
            className="max-w-[90vw] max-h-[90vh] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}

// Component สำหรับแสดงรายการไฟล์แนบแบบ Compact (ใช้ใน Timeline หรือ Comments)
interface AttachmentListProps {
  attachments: Attachment[];
  compact?: boolean;
  onImageClick?: (url: string) => void;
}

export function AttachmentList({
  attachments,
  compact = false,
  onImageClick,
}: AttachmentListProps) {
  if (!attachments || attachments.length === 0) {
    return null;
  }

  if (compact) {
    return (
      <div className="flex flex-wrap gap-2 mt-2">
        {attachments.map((attachment) => (
          <div
            key={attachment.id}
            className={`flex items-center gap-2 bg-gray-100 rounded px-3 py-1.5 text-xs ${
              isImageFile(attachment) && onImageClick
                ? 'cursor-pointer hover:bg-gray-200'
                : ''
            }`}
            onClick={() => {
              if (isImageFile(attachment) && onImageClick) {
                onImageClick(attachment.url);
              }
            }}
          >
            <span>{getFileIcon(attachment)}</span>
            <span className="font-medium truncate max-w-[150px]">
              {attachment.filename}
            </span>
            <span className="text-gray-500">
              {formatFileSize(attachment.fileSize)}
            </span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {attachments.map((attachment) => {
        const isImage = isImageFile(attachment);
        
        return (
          <div
            key={attachment.id}
            className={`flex items-center gap-3 p-2 bg-gray-50 rounded border border-gray-200 ${
              isImage && onImageClick ? 'cursor-pointer hover:bg-gray-100' : ''
            }`}
            onClick={() => {
              if (isImage && onImageClick) {
                onImageClick(attachment.url);
              }
            }}
          >
            {isImage && attachment.url ? (
              <ImageWithFallback
                src={attachment.url}
                alt={attachment.filename}
                className="w-12 h-12 object-cover rounded image-preview-unlock"
              />
            ) : (
              <div className="w-12 h-12 flex items-center justify-center bg-gray-200 rounded text-xl">
                {getFileIcon(attachment)}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {attachment.filename}
              </p>
              <p className="text-xs text-gray-500">
                {formatFileSize(attachment.fileSize)}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
