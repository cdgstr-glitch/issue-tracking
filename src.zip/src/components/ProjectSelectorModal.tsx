// src/components/ProjectSelectorModal.tsx
// ✅ 2-step wizard: Organization → Project (SSoT)
// ✅ Canonical data access via db relational methods
// ✅ onSelect(projectId)

import { useEffect, useMemo, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Building2, CheckCircle2, ChevronRight, FolderOpen, Search, X } from 'lucide-react';
import { db } from '../lib/mockDb/client';

interface ProjectSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (projectId: string) => void;
  initialOrganizationId?: string;
  initialProjectId?: string;
}

function normalize(s: any): string {
  return String(s ?? '').trim().toLowerCase();
}

export function ProjectSelectorModal({
  isOpen,
  onClose,
  onSelect,
  initialOrganizationId,
  initialProjectId,
}: ProjectSelectorModalProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [selectedOrgId, setSelectedOrgId] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const perPage = 6;

  // ── Data (SSoT) ──────────────────────────────────────────────────────────
  const organizations = useMemo(
    () =>
      typeof (db.organizations as any).getSelectableForTicketCreate === 'function'
        ? (db.organizations as any).getSelectableForTicketCreate()
        : db.organizations.getAll(),
    [],
  );

  const orgProjects = useMemo(() => {
    if (!selectedOrgId) return [];
    return typeof (db.projects as any).getSelectableByOrganizationId === 'function'
      ? (db.projects as any).getSelectableByOrganizationId(selectedOrgId)
      : db.projects.getByOrganizationId(selectedOrgId);
  }, [selectedOrgId]);

  // ── Reset on open ────────────────────────────────────────────────────────
  useEffect(() => {
    if (!isOpen) return;
    setStep(1);
    setSelectedOrgId(initialOrganizationId ?? '');
    setSelectedProjectId(initialProjectId ?? '');
    setSearchQuery('');
    setPage(1);

    // ถ้ามี initial org แล้ว เปิด step 2 ให้เลย
    if (initialOrganizationId) setStep(2);
  }, [isOpen, initialOrganizationId, initialProjectId]);

  // ── Filter + page ────────────────────────────────────────────────────────
  const filteredProjects = useMemo(() => {
    const q = normalize(searchQuery);
    if (!q) return orgProjects;
    return (orgProjects as any[]).filter((p: any) => {
      return normalize(p.projectName).includes(q) || normalize(p.projectCode ?? '').includes(q);
    });
  }, [orgProjects, searchQuery]);

  const totalPages = Math.max(1, Math.ceil((filteredProjects as any[]).length / perPage));
  const pagedProjects = useMemo(() => {
    const p = Math.min(Math.max(1, page), totalPages);
    return (filteredProjects as any[]).slice((p - 1) * perPage, p * perPage);
  }, [filteredProjects, page, totalPages]);

  // ── Derived display ───────────────────────────────────────────────────────
  const selectedOrg = useMemo(
    () => (organizations as any[]).find((o: any) => o.id === selectedOrgId),
    [organizations, selectedOrgId],
  );

  // ── Actions ───────────────────────────────────────────────────────────────
  const goToStep2 = (orgId: string) => {
    setSelectedOrgId(orgId);
    setSelectedProjectId('');
    setSearchQuery('');
    setPage(1);
    setStep(2);
  };

  const confirm = (projectId: string) => {
    if (!projectId) return;
    onSelect(projectId);
    onClose();
  };

  const steps = [
    { num: 1, label: 'หน่วยงาน', icon: Building2 },
    { num: 2, label: 'โครงการ', icon: FolderOpen },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={(v) => (!v ? onClose() : undefined)}>
      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col gap-0 p-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-4 border-b shrink-0">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <FolderOpen className="h-5 w-5 text-blue-600" />
            เลือกหน่วยงาน / โครงการ
          </DialogTitle>
          <DialogDescription className="text-xs text-muted-foreground mt-1">
            แสดงเฉพาะหน่วยงานที่มีโครงการ และโครงการที่มีผลิตภัณฑ์ (ผ่าน pivot)
          </DialogDescription>

          <div className="flex items-center gap-1 mt-3">
            {steps.map((s, i) => {
              const Icon = s.icon;
              const isDone = step > s.num;
              const isActive = step === s.num;
              return (
                <div key={s.num} className="flex items-center gap-1">
                  <div
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                      isDone
                        ? 'bg-green-100 text-green-700'
                        : isActive
                        ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-300'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {isDone ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Icon className="h-3.5 w-3.5" />}
                    <span>{s.label}</span>
                  </div>
                  {i < steps.length - 1 && <ChevronRight className="h-3.5 w-3.5 text-gray-300 shrink-0" />}
                </div>
              );
            })}
          </div>

          {selectedOrg && (
            <div className="flex items-center gap-1.5 mt-2 flex-wrap">
              <Badge variant="secondary" className="text-xs gap-1">
                <Building2 className="h-3 w-3" />
                {selectedOrg.organizationShortName ?? selectedOrg.organizationName}
              </Badge>
            </div>
          )}
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {step === 1 && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-700 mb-3">เลือกหน่วยงาน</p>
              {(organizations as any[]).length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">ไม่พบหน่วยงาน</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(organizations as any[]).map((org: any) => {
                    const projectCount = (db.projects as any).getSelectableByOrganizationId
                      ? (db.projects as any).getSelectableByOrganizationId(org.id).length
                      : 0;
                    return (
                      <button
                        key={org.id}
                        onClick={() => goToStep2(org.id)}
                        className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:border-blue-400 hover:bg-blue-50 transition-all text-left group"
                      >
                        <div className="h-9 w-9 rounded-lg bg-blue-100 flex items-center justify-center shrink-0 group-hover:bg-blue-200 transition-colors">
                          <Building2 className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {org.organizationShortName ? `${org.organizationShortName}` : org.organizationName}
                          </p>
                          {org.organizationShortName && (
                            <p className="text-xs text-muted-foreground truncate">{org.organizationName}</p>
                          )}
                        </div>
                        <Badge variant="outline" className="text-xs shrink-0">
                          {projectCount} โครงการ
                        </Badge>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium text-gray-700 flex-1">เลือกโครงการ</p>
                <button onClick={() => setStep(1)} className="text-xs text-blue-600 hover:underline">
                  ← เปลี่ยนหน่วยงาน
                </button>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-9 h-9 text-sm"
                  placeholder="ค้นหาโครงการ..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setPage(1);
                  }}
                />
              </div>

              {pagedProjects.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">ไม่พบโครงการ</p>
              ) : (
                <div className="space-y-1.5">
                  {pagedProjects.map((proj: any) => (
                    <button
                      key={proj.id}
                      onClick={() => confirm(proj.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all text-left group ${
                        selectedProjectId === proj.id
                          ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-300'
                          : 'border-gray-200 hover:border-blue-400 hover:bg-blue-50'
                      }`}
                    >
                      <div className="h-8 w-8 rounded-md bg-indigo-100 flex items-center justify-center shrink-0 group-hover:bg-indigo-200 transition-colors">
                        <FolderOpen className="h-4 w-4 text-indigo-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{proj.projectName}</p>
                        {proj.projectCode && <p className="text-xs text-muted-foreground">{proj.projectCode}</p>}
                      </div>
                      <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-blue-500 shrink-0" />
                    </button>
                  ))}
                </div>
              )}

              {totalPages > 1 && (
                <div className="flex items-center justify-between pt-1">
                  <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                    ก่อนหน้า
                  </Button>
                  <span className="text-xs text-muted-foreground">
                    {page}/{totalPages} • {(filteredProjects as any[]).length} รายการ
                  </span>
                  <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>
                    ถัดไป
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t shrink-0 flex justify-end gap-2 bg-gray-50">
          <Button variant="outline" onClick={onClose} className="gap-1">
            <X className="h-4 w-4" />
            ยกเลิก
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
