import { useMemo } from 'react';
import { db } from '../../lib/mockDb/client'; // ✅ Use new DB client
import { reportUsers } from '../../lib/mockDataReports';
import { useAuth } from '../../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Trophy, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts';

export default function StaffReport() {
  const { currentUser } = useAuth();
  const mockTickets = db.tickets.getAll(); // ✅ Fetch from DB
  const isAdmin = currentUser?.role === 'admin';

  // Calculate staff statistics
  const staffStats = useMemo(() => {
    const stats: Record<string, {
      name: string;
      role: string;
      assigned: number;
      closed: number;
      inProgress: number;
      avgTime: number;
      resolutionTimes: number[];
      categories: Record<string, number>;
    }> = {};

    // Initialize from CSV report users
    Object.values(reportUsers).forEach(user => {
      stats[user.id] = {
        name: user.name,
        role: user.role,
        assigned: 0,
        closed: 0,
        inProgress: 0,
        avgTime: 0,
        resolutionTimes: [],
        categories: {},
      };
    });

    mockTickets.forEach(ticket => {
      const assignedTo = ticket.assignedTo;
      if (!assignedTo) return;

      // Initialize if not exists
      if (!stats[assignedTo]) {
        stats[assignedTo] = {
          name: assignedTo,
          role: 'staff',
          assigned: 0,
          closed: 0,
          inProgress: 0,
          avgTime: 0,
          resolutionTimes: [],
          categories: {},
        };
      }

      stats[assignedTo].assigned++;

      if (ticket.status === 'closed') {
        stats[assignedTo].closed++;
        
        // Calculate resolution time
        if (ticket.resolvedAt && ticket.createdAt) {
          const diff = new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime();
          const hours = diff / (1000 * 60 * 60);
          stats[assignedTo].resolutionTimes.push(hours);
        }
      } else if (ticket.status === 'in_progress') {
        stats[assignedTo].inProgress++;
      }

      // Track categories
      const category = ticket.category || 'other';
      stats[assignedTo].categories[category] = (stats[assignedTo].categories[category] || 0) + 1;
    });

    // Calculate averages
    Object.keys(stats).forEach(userId => {
      if (stats[userId].resolutionTimes.length > 0) {
        stats[userId].avgTime = stats[userId].resolutionTimes.reduce((a, b) => a + b, 0) / stats[userId].resolutionTimes.length;
      }
    });

    return stats;
  }, []);

  // Filter: Admin sees all, staff sees only themselves
  const filteredStaffData = useMemo(() => {
    const data = Object.entries(staffStats)
      .filter(([userId, data]) => {
        // Filter out users with no assigned tickets
        if (data.assigned === 0) return false;
        
        // If not admin, show only current user's data
        if (!isAdmin && userId !== currentUser?.id) {
          return false;
        }
        
        return true;
      })
      .map(([userId, data]) => ({
        userId,
        ...data,
        efficiency: data.assigned > 0 ? ((data.closed / data.assigned) * 100).toFixed(1) : '0',
      }))
      .sort((a, b) => b.assigned - a.assigned);

    return data;
  }, [staffStats, isAdmin, currentUser?.id]);

  // Leaderboard data
  const leaderboardData = useMemo(() => {
    return filteredStaffData.slice(0, 5);
  }, [filteredStaffData]);

  // Workload distribution
  const workloadData = useMemo(() => {
    return filteredStaffData.map(item => ({
      name: item.name,
      'รับเคส': item.assigned,
      'แก้เสร็จ': item.closed,
      'กำลังทำ': item.inProgress,
    }));
  }, [filteredStaffData]);

  // Performance comparison (for admin only)
  const performanceData = useMemo(() => {
    if (!isAdmin) return [];
    
    const categories = ['technical', 'account', 'bug', 'feature_request', 'general_inquiry'];
    const topStaff = filteredStaffData.slice(0, 3);
    
    return categories.map(cat => {
      const categoryLabels: Record<string, string> = {
        'technical': 'เทคนิค',
        'account': 'บัญชี',
        'bug': 'บั๊ก',
        'feature_request': 'ฟีเจอร์',
        'general_inquiry': 'สอบถาม',
      };
      
      const dataPoint: any = { category: categoryLabels[cat] || cat };
      
      topStaff.forEach(staff => {
        dataPoint[staff.name] = staff.categories[cat] || 0;
      });
      
      return dataPoint;
    });
  }, [isAdmin, filteredStaffData]);

  const roleLabels: Record<string, string> = {
    'tier1': 'Tier 1',
    'tier2': 'Tier 2',
    'tier3': 'Tier 3',
    'staff': 'Staff',
    'admin': 'Admin',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold">
          {isAdmin ? 'รายงานตามเจ้าหน้าที่' : 'ประสิทธิภาพการทำงานของฉัน'}
        </h2>
        <p className="text-sm text-gray-600 mt-1">
          {isAdmin 
            ? 'วิเคราะห์ Workload และประสิทธิภาพของทีม'
            : 'สถิติและประสิทธิภาพการทำงานส่วนตัว'
          }
        </p>
      </div>

      {/* Leaderboard (Admin only) */}
      {isAdmin && leaderboardData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Top 5 ผู้ปฏิบัติงาน
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leaderboardData.map((staff, index) => (
                <div key={staff.userId} className="flex items-center gap-4">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                    index === 0 ? 'bg-yellow-100 text-yellow-600' :
                    index === 1 ? 'bg-gray-100 text-gray-600' :
                    index === 2 ? 'bg-orange-100 text-orange-600' :
                    'bg-blue-50 text-blue-600'
                  } font-bold text-sm`}>
                    {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : index + 1}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        <span className="font-medium">{staff.name}</span>
                        <span className="text-xs text-gray-500 ml-2">
                          ({roleLabels[staff.role] || staff.role})
                        </span>
                      </div>
                      <div className="text-sm text-gray-600">
                        {staff.assigned} เคส
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1">
                        <CheckCircle className="w-3 h-3 text-green-500" />
                        <span className="text-green-600 font-medium">{staff.closed} แก้แล้ว</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-blue-500" />
                        <span>{staff.avgTime.toFixed(1)} ชม./เคส</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-purple-500" />
                        <span>{staff.efficiency}% ประสิทธิภาพ</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Staff Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {isAdmin ? `สถิติทีม (${filteredStaffData.length} คน)` : 'สถิติของฉัน'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">ชื่อ</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">บทบาท</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">รับเคส</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">แก้เสร็จ</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">กำลังทำ</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">เวลาเฉลี่ย</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">ประสิทธิภาพ</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filteredStaffData.map((staff) => (
                  <tr key={staff.userId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">
                      {staff.name}
                      {staff.userId === currentUser?.id && (
                        <span className="ml-2 text-xs text-blue-600">(คุณ)</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-700">
                        {roleLabels[staff.role] || staff.role}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-center font-medium text-gray-900">
                      {staff.assigned}
                    </td>
                    <td className="px-4 py-3 text-sm text-center">
                      <span className="text-green-600 font-medium">{staff.closed}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-center">
                      <span className="text-purple-600 font-medium">{staff.inProgress}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-center text-gray-900">
                      {staff.avgTime > 0 ? `${staff.avgTime.toFixed(1)} ชม.` : '-'}
                    </td>
                    <td className="px-4 py-3 text-sm text-center">
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              parseFloat(staff.efficiency) >= 90 ? 'bg-green-500' :
                              parseFloat(staff.efficiency) >= 70 ? 'bg-blue-500' :
                              parseFloat(staff.efficiency) >= 50 ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`}
                            style={{ width: `${staff.efficiency}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-600 w-12">
                          {staff.efficiency}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredStaffData.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                ไม่มีข้อมูล
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Workload Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">กระจาย Workload</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={workloadData.slice(0, 10)} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={80} style={{ fontSize: '12px' }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="รับเคส" fill="#3b82f6" />
                <Bar dataKey="แก้เสร็จ" fill="#10b981" />
                <Bar dataKey="กำลังทำ" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Performance Radar (Admin only) */}
        {isAdmin && performanceData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">เปรียบเทียบความเชี่ยวชาญ (Top 3)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={performanceData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="category" style={{ fontSize: '12px' }} />
                  <PolarRadiusAxis />
                  <Tooltip />
                  <Legend />
                  {leaderboardData.slice(0, 3).map((staff, index) => (
                    <Radar
                      key={staff.userId}
                      name={staff.name}
                      dataKey={staff.name}
                      stroke={['#3b82f6', '#10b981', '#f59e0b'][index]}
                      fill={['#3b82f6', '#10b981', '#f59e0b'][index]}
                      fillOpacity={0.3}
                    />
                  ))}
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Personal Stats (Non-admin) */}
        {!isAdmin && filteredStaffData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">ความเชี่ยวชาญของฉัน</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(filteredStaffData[0].categories)
                  .sort(([, a], [, b]) => b - a)
                  .slice(0, 5)
                  .map(([category, count]) => {
                    const categoryLabels: Record<string, string> = {
                      'technical': 'ปัญหาทางเทคนิค',
                      'account': 'บัญชีและสิทธิ์',
                      'bug': 'บั๊ก/ข้อผิดพลาด',
                      'feature_request': 'ขอฟีเจอร์ใหม่',
                      'general_inquiry': 'สอบถามทั่วไป',
                      'other': 'อื่นๆ',
                    };
                    
                    const percentage = ((count / filteredStaffData[0].assigned) * 100).toFixed(0);
                    
                    return (
                      <div key={category}>
                        <div className="flex items-center justify-between mb-1 text-sm">
                          <span className="text-gray-700">{categoryLabels[category] || category}</span>
                          <span className="font-medium text-gray-900">{count} เคส ({percentage}%)</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-500 h-2 rounded-full"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
