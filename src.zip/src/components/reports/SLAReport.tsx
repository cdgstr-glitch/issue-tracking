import { useMemo } from 'react';
import { db } from '../../lib/mockDb/client'; // ✅ Use new DB client
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { CheckCircle, AlertTriangle, Clock, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend, PieChart, Pie, Cell } from 'recharts';

export default function SLAReport() {
  // ✅ Fetch tickets from DB
  const mockTickets = db.tickets.getAll();

  // SLA targets (in hours)
  const slaTargets: Record<string, number> = {
    'critical': 1,
    'high': 4,
    'normal': 8,
    'low': 24,
  };

  // Calculate SLA statistics
  const slaStats = useMemo(() => {
    const stats: Record<string, {
      total: number;
      met: number;
      breached: number;
      avgTime: number;
      times: number[];
    }> = {
      'critical': { total: 0, met: 0, breached: 0, avgTime: 0, times: [] },
      'high': { total: 0, met: 0, breached: 0, avgTime: 0, times: [] },
      'normal': { total: 0, met: 0, breached: 0, avgTime: 0, times: [] },
      'low': { total: 0, met: 0, breached: 0, avgTime: 0, times: [] },
    };

    const resolvedTickets = mockTickets.filter(t => t.resolvedAt && t.createdAt);

    resolvedTickets.forEach(ticket => {
      const priority = ticket.priority || 'normal';
      if (!stats[priority]) return;

      const diff = new Date(ticket.resolvedAt!).getTime() - new Date(ticket.createdAt).getTime();
      const hours = diff / (1000 * 60 * 60);

      stats[priority].total++;
      stats[priority].times.push(hours);

      if (hours <= slaTargets[priority]) {
        stats[priority].met++;
      } else {
        stats[priority].breached++;
      }
    });

    // Calculate averages
    Object.keys(stats).forEach(priority => {
      if (stats[priority].times.length > 0) {
        stats[priority].avgTime = stats[priority].times.reduce((a, b) => a + b, 0) / stats[priority].times.length;
      }
    });

    return stats;
  }, []);

  // Overall SLA compliance
  const overallCompliance = useMemo(() => {
    const totalResolved = Object.values(slaStats).reduce((sum, s) => sum + s.total, 0);
    const totalMet = Object.values(slaStats).reduce((sum, s) => sum + s.met, 0);
    
    return totalResolved > 0 ? ((totalMet / totalResolved) * 100).toFixed(1) : '0';
  }, [slaStats]);

  // Prepare chart data
  const complianceData = useMemo(() => {
    const priorityLabels: Record<string, string> = {
      'critical': 'Critical',
      'high': 'High',
      'normal': 'Normal',
      'low': 'Low',
    };

    return Object.entries(slaStats)
      .map(([priority, data]) => ({
        priority: priorityLabels[priority] || priority,
        target: slaTargets[priority],
        actual: data.avgTime,
        compliance: data.total > 0 ? ((data.met / data.total) * 100).toFixed(1) : '0',
        met: data.met,
        breached: data.breached,
      }))
      .filter(item => item.met + item.breached > 0);
  }, [slaStats]);

  // Response time vs Resolution time comparison
  const timeComparisonData = useMemo(() => {
    return complianceData.map(item => ({
      priority: item.priority,
      'SLA Target': parseFloat(item.target.toFixed(1)),
      'เวลาเฉลี่ยจริง': parseFloat(item.actual.toFixed(1)),
    }));
  }, [complianceData]);

  // Breached tickets list
  const breachedTickets = useMemo(() => {
    return mockTickets
      .filter(ticket => {
        if (!ticket.resolvedAt || !ticket.createdAt) return false;
        const diff = new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime();
        const hours = diff / (1000 * 60 * 60);
        const target = slaTargets[ticket.priority || 'normal'];
        return hours > target;
      })
      .map(ticket => {
        const diff = new Date(ticket.resolvedAt!).getTime() - new Date(ticket.createdAt).getTime();
        const hours = diff / (1000 * 60 * 60);
        const target = slaTargets[ticket.priority || 'normal'];
        const overdue = hours - target;
        
        return {
          ...ticket,
          actualTime: hours,
          targetTime: target,
          overdueTime: overdue,
        };
      })
      .sort((a, b) => b.overdueTime - a.overdueTime)
      .slice(0, 10);
  }, []);

  // Distribution of ticket resolution times
  const distributionData = useMemo(() => {
    const ranges = [
      { label: '< 1 ชม.', min: 0, max: 1 },
      { label: '1-4 ชม.', min: 1, max: 4 },
      { label: '4-8 ชม.', min: 4, max: 8 },
      { label: '8-24 ชม.', min: 8, max: 24 },
      { label: '> 1 วัน', min: 24, max: Infinity },
    ];

    const distribution = ranges.map(range => {
      const count = mockTickets.filter(ticket => {
        if (!ticket.resolvedAt || !ticket.createdAt) return false;
        const diff = new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime();
        const hours = diff / (1000 * 60 * 60);
        return hours >= range.min && hours < range.max;
      }).length;

      return {
        name: range.label,
        value: count,
      };
    });

    return distribution;
  }, []);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  const priorityLabels: Record<string, string> = {
    'critical': 'Critical',
    'high': 'High',
    'normal': 'Normal',
    'low': 'Low',
  };

  const priorityColors: Record<string, string> = {
    'critical': 'bg-red-100 text-red-700',
    'high': 'bg-orange-100 text-orange-700',
    'normal': 'bg-blue-100 text-blue-700',
    'low': 'bg-gray-100 text-gray-700',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold">SLA Performance</h2>
        <p className="text-sm text-gray-600 mt-1">
          วิเคราะห์ประสิทธิภาพการแก้ปัญหาตาม SLA ที่กำหนด
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">SLA Compliance</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallCompliance}%</div>
            <p className="text-xs text-gray-500 mt-1">
              {parseFloat(overallCompliance) >= 90 ? '✅ ดีเยี่ยม' : 
               parseFloat(overallCompliance) >= 80 ? '⚠️ ดี' : '❌ ต้องปรับปรุง'}
            </p>
          </CardContent>
        </Card>

        {Object.entries(slaStats).map(([priority, data]) => {
          if (data.total === 0) return null;
          
          const compliance = ((data.met / data.total) * 100).toFixed(1);
          
          return (
            <Card key={priority}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {priorityLabels[priority] || priority}
                </CardTitle>
                {parseFloat(compliance) >= 90 ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-orange-500" />
                )}
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{compliance}%</div>
                <p className="text-xs text-gray-500 mt-1">
                  {data.met}/{data.total} บรรลุ SLA ({slaTargets[priority]} ชม.)
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SLA Goal vs Actual */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">SLA Target vs เวลาจริง</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={timeComparisonData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="priority" />
                <YAxis label={{ value: 'ชั่วโมง', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="SLA Target" fill="#10b981" />
                <Bar dataKey="เวลาเฉลี่ยจริง" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Resolution Time Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">กระจายเวลาแก้ปัญหา</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={90}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Compliance by Priority */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">SLA Compliance แยกตาม Priority</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={complianceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="priority" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="met" stackId="a" fill="#10b981" name="บรรลุ SLA" />
              <Bar dataKey="breached" stackId="a" fill="#ef4444" name="เกิน SLA" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Breached SLA Tickets */}
      {breachedTickets.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              เคสที่เกิน SLA ({breachedTickets.length} เคส)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">เลขเคส</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">หน่วยงาน</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">หัวเรื่อง</th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">Priority</th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">Target</th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">เวลาจริง</th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">เกินมา</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {breachedTickets.map(ticket => (
                    <tr key={ticket.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">
                        {ticket.id}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">
                        {ticket.project || '-'}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900 max-w-xs truncate">
                        {ticket.title}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${priorityColors[ticket.priority || 'normal']}`}>
                          {priorityLabels[ticket.priority || 'normal']}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-center text-gray-900">
                        {ticket.targetTime.toFixed(1)} ชม.
                      </td>
                      <td className="px-4 py-3 text-sm text-center text-gray-900">
                        {ticket.actualTime.toFixed(1)} ชม.
                      </td>
                      <td className="px-4 py-3 text-sm text-center">
                        <span className="text-red-600 font-medium">
                          +{ticket.overdueTime.toFixed(1)} ชม.
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">💡 ข้อเสนอแนะ</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {parseFloat(overallCompliance) >= 90 && (
              <div className="flex items-start gap-2">
                <span className="text-green-500 mt-0.5">✅</span>
                <p className="text-sm text-gray-700">
                  <strong>ยอดเยี่ยม!</strong> ทีมสามารถบรรลุ SLA ได้ {overallCompliance}% ซึ่งเกินเป้าหมาย
                </p>
              </div>
            )}

            {parseFloat(overallCompliance) < 80 && (
              <div className="flex items-start gap-2">
                <span className="text-orange-500 mt-0.5">⚠️</span>
                <p className="text-sm text-gray-700">
                  <strong>ต้องปรับปรุง:</strong> SLA Compliance อยู่ที่ {overallCompliance}% ควรมีการวิเคราะห์สาเหตุและปรับปรุงกระบวนการ
                </p>
              </div>
            )}

            {Object.entries(slaStats).filter(([, data]) => data.total > 0 && (data.met / data.total) < 0.8).length > 0 && (
              <div className="flex items-start gap-2">
                <span className="text-red-500 mt-0.5">🔴</span>
                <p className="text-sm text-gray-700">
                  <strong>Priority ที่ต้องเร่งแก้:</strong> {
                    Object.entries(slaStats)
                      .filter(([, data]) => data.total > 0 && (data.met / data.total) < 0.8)
                      .map(([priority]) => priorityLabels[priority])
                      .join(', ')
                  }
                </p>
              </div>
            )}

            {breachedTickets.length > 5 && (
              <div className="flex items-start gap-2">
                <span className="text-yellow-500 mt-0.5">💡</span>
                <p className="text-sm text-gray-700">
                  มีเคสที่เกิน SLA ทั้งหมด {breachedTickets.length} เคส ควรพิจารณาเพิ่ม resource หรือปรับ SLA target ให้เหมาะสม
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
