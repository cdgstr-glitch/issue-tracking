import { useMemo, useState } from 'react';
import { db } from '../../lib/mockDb/client'; // ✅ Use new DB client
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Search, ChevronDown, ChevronUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function OrganizationReport() {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedOrg, setExpandedOrg] = useState<string | null>(null);

  // ✅ Fetch tickets from DB
  const mockTickets = db.tickets.getAll();

  // Calculate organization statistics
  const orgStats = useMemo(() => {
    const stats: Record<string, {
      total: number;
      closed: number;
      pending: number;
      avgTime: number;
      topIssues: Record<string, number>;
    }> = {};

    mockTickets.forEach(ticket => {
      const org = ticket.project || 'ไม่ระบุ';
      
      if (!stats[org]) {
        stats[org] = {
          total: 0,
          closed: 0,
          pending: 0,
          avgTime: 0,
          topIssues: {},
        };
      }

      stats[org].total++;
      
      if (ticket.status === 'closed') {
        stats[org].closed++;
        
        // Calculate resolution time
        if (ticket.resolvedAt && ticket.createdAt) {
          const diff = new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime();
          const hours = diff / (1000 * 60 * 60);
          stats[org].avgTime += hours;
        }
      } else {
        stats[org].pending++;
      }

      // Track issue categories
      const category = ticket.category || 'other';
      stats[org].topIssues[category] = (stats[org].topIssues[category] || 0) + 1;
    });

    // Calculate average time
    Object.keys(stats).forEach(org => {
      if (stats[org].closed > 0) {
        stats[org].avgTime = stats[org].avgTime / stats[org].closed;
      }
    });

    return stats;
  }, []);

  // Filter and sort organizations
  const filteredOrgs = useMemo(() => {
    const filtered = Object.entries(orgStats)
      .filter(([name]) => name.toLowerCase().includes(searchTerm.toLowerCase()))
      .map(([name, data]) => ({
        name,
        ...data,
        closedPercentage: data.total > 0 ? ((data.closed / data.total) * 100).toFixed(1) : '0',
      }))
      .sort((a, b) => b.total - a.total);

    return filtered;
  }, [orgStats, searchTerm]);

  const categoryLabels: Record<string, string> = {
    'technical': 'ปัญหาทางเทคนิค',
    'account': 'บัญชีและสิทธิ์',
    'bug': 'บั๊ก/ข้อผิดพลาด',
    'feature_request': 'ขอฟีเจอร์ใหม่',
    'general_inquiry': 'สอบถามทั่วไป',
    'other': 'อื่นๆ',
  };

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">รายงานตามหน่วยงาน</h2>
          <p className="text-sm text-gray-600 mt-1">
            วิเคราะห์จำนวนเคสและประสิทธิภาพแยกตามหน่วยงาน
          </p>
        </div>
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            type="text"
            placeholder="ค้นหาหน่วยงาน..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Organization Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">สถิติตามหน่วยงาน ({filteredOrgs.length} หน่วยงาน)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">หน่วยงาน</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">เคสทั้งหมด</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">แก้แล้ว</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">ค้างอยู่</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">เวลาเฉลี่ย</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500">ประสิทธิภาพ</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500"></th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filteredOrgs.map((org) => (
                  <>
                    <tr key={org.name} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">
                        {org.name}
                      </td>
                      <td className="px-4 py-3 text-sm text-center text-gray-900">
                        {org.total}
                      </td>
                      <td className="px-4 py-3 text-sm text-center">
                        <span className="text-green-600 font-medium">{org.closed}</span>
                      </td>
                      <td className="px-4 py-3 text-sm text-center">
                        <span className="text-orange-600 font-medium">{org.pending}</span>
                      </td>
                      <td className="px-4 py-3 text-sm text-center text-gray-900">
                        {org.avgTime > 0 ? `${org.avgTime.toFixed(1)} ชม.` : '-'}
                      </td>
                      <td className="px-4 py-3 text-sm text-center">
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-green-500 h-2 rounded-full"
                              style={{ width: `${org.closedPercentage}%` }}
                            />
                          </div>
                          <span className="text-xs text-gray-600 w-12">
                            {org.closedPercentage}%
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => setExpandedOrg(expandedOrg === org.name ? null : org.name)}
                          className="text-blue-600 hover:text-blue-800 p-1"
                        >
                          {expandedOrg === org.name ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                    </tr>

                    {/* Expanded Details */}
                    {expandedOrg === org.name && (
                      <tr>
                        <td colSpan={7} className="px-4 py-4 bg-gray-50">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Top Issues */}
                            <div>
                              <h4 className="text-sm font-semibold mb-3">ประเภทปัญหาหลัก</h4>
                              <div className="space-y-2">
                                {Object.entries(org.topIssues)
                                  .sort(([, a], [, b]) => b - a)
                                  .slice(0, 5)
                                  .map(([category, count]) => (
                                    <div key={category} className="flex items-center justify-between text-sm">
                                      <span className="text-gray-700">
                                        {categoryLabels[category] || category}
                                      </span>
                                      <span className="font-medium text-gray-900">
                                        {count} เคส ({((count / org.total) * 100).toFixed(0)}%)
                                      </span>
                                    </div>
                                  ))}
                              </div>
                            </div>

                            {/* Chart */}
                            <div>
                              <h4 className="text-sm font-semibold mb-3">กราฟสัดส่วน</h4>
                              <ResponsiveContainer width="100%" height={150}>
                                <BarChart
                                  data={[
                                    { name: 'แก้แล้ว', value: org.closed },
                                    { name: 'ค้างอยู่', value: org.pending },
                                  ]}
                                  layout="vertical"
                                >
                                  <XAxis type="number" />
                                  <YAxis dataKey="name" type="category" width={80} />
                                  <Tooltip />
                                  <Bar dataKey="value" fill="#3b82f6" />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                ))}
              </tbody>
            </table>

            {filteredOrgs.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                ไม่พบหน่วยงานที่ค้นหา
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
