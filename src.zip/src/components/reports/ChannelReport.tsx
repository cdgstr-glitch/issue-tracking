import { useMemo } from 'react';
import { db } from '../../lib/mockDb/client'; // ✅ Use new DB client
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { MessageSquare, Mail, Phone, Globe, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

export default function ChannelReport() {
  // ✅ Fetch tickets from DB
  const mockTickets = db.tickets.getAll();

  // Channel labels and icons
  const channelInfo: Record<string, { label: string; icon: any; color: string }> = {
    'line': { label: 'Line', icon: MessageSquare, color: '#10b981' },
    'web': { label: 'เว็บไซต์', icon: Globe, color: '#3b82f6' },
    'email': { label: 'อีเมล', icon: Mail, color: '#f59e0b' },
    'phone': { label: 'โทรศัพท์', icon: Phone, color: '#ef4444' },
    'in_person': { label: 'On-site', icon: Users, color: '#8b5cf6' },
  };

  // Calculate channel statistics
  const channelStats = useMemo(() => {
    const stats: Record<string, {
      total: number;
      closed: number;
      pending: number;
      avgTime: number;
      avgResponseTime: number;
      resolutionTimes: number[];
    }> = {};

    mockTickets.forEach(ticket => {
      const channel = ticket.channel || 'other';
      
      if (!stats[channel]) {
        stats[channel] = {
          total: 0,
          closed: 0,
          pending: 0,
          avgTime: 0,
          avgResponseTime: 0,
          resolutionTimes: [],
        };
      }

      stats[channel].total++;
      
      if (ticket.status === 'closed') {
        stats[channel].closed++;
        
        // Calculate resolution time
        if (ticket.resolvedAt && ticket.createdAt) {
          const diff = new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime();
          const hours = diff / (1000 * 60 * 60);
          stats[channel].resolutionTimes.push(hours);
        }
      } else {
        stats[channel].pending++;
      }

      // Calculate response time (assume first update is response - simplified)
      if (ticket.updatedAt && ticket.createdAt) {
        const diff = new Date(ticket.updatedAt).getTime() - new Date(ticket.createdAt).getTime();
        const minutes = diff / (1000 * 60);
        stats[channel].avgResponseTime += minutes;
      }
    });

    // Calculate averages
    Object.keys(stats).forEach(channel => {
      if (stats[channel].resolutionTimes.length > 0) {
        stats[channel].avgTime = stats[channel].resolutionTimes.reduce((a, b) => a + b, 0) / stats[channel].resolutionTimes.length;
      }
      if (stats[channel].total > 0) {
        stats[channel].avgResponseTime = stats[channel].avgResponseTime / stats[channel].total;
      }
    });

    return stats;
  }, []);

  // Prepare data for charts
  const channelData = useMemo(() => {
    return Object.entries(channelStats)
      .map(([channel, data]) => ({
        channel,
        label: channelInfo[channel]?.label || channel,
        total: data.total,
        closed: data.closed,
        pending: data.pending,
        avgTime: data.avgTime,
        avgResponseTime: data.avgResponseTime,
        closedPercentage: data.total > 0 ? ((data.closed / data.total) * 100).toFixed(1) : '0',
        color: channelInfo[channel]?.color || '#6b7280',
      }))
      .sort((a, b) => b.total - a.total);
  }, [channelStats]);

  // Comparison data
  const comparisonData = useMemo(() => {
    return channelData.map(item => ({
      name: item.label,
      'จำนวนเคส': item.total,
      'เวลาเฉลี่ย (ชม.)': parseFloat(item.avgTime.toFixed(1)),
    }));
  }, [channelData]);

  // Distribution pie data
  const distributionData = useMemo(() => {
    return channelData.map(item => ({
      name: item.label,
      value: item.total,
    }));
  }, [channelData]);

  const COLORS = channelData.map(item => item.color);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold">รายงานตามช่องทาง</h2>
        <p className="text-sm text-gray-600 mt-1">
          วิเคราะห์ประสิทธิภาพและสถิติแยกตามช่องทางการแจ้งปัญหา
        </p>
      </div>

      {/* Channel Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {channelData.map((item) => {
          const Icon = channelInfo[item.channel]?.icon || MessageSquare;
          
          return (
            <Card key={item.channel}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{item.label}</CardTitle>
                <Icon className="h-4 w-4" style={{ color: item.color }} />
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="text-2xl font-bold">{item.total}</div>
                  <p className="text-xs text-gray-500">เคสทั้งหมด</p>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">แก้แล้ว:</span>
                  <span className="font-medium text-green-600">{item.closed} ({item.closedPercentage}%)</span>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">ค้างอยู่:</span>
                  <span className="font-medium text-orange-600">{item.pending}</span>
                </div>
                
                <div className="pt-2 border-t">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-600">เวลาเฉลี่ย:</span>
                    <span className="font-medium">
                      {item.avgTime > 0 ? `${item.avgTime.toFixed(1)} ชม.` : '-'}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs mt-1">
                    <span className="text-gray-600">ตอบรับเฉลี่ย:</span>
                    <span className="font-medium">
                      {item.avgResponseTime > 0 ? `${item.avgResponseTime.toFixed(0)} นาที` : '-'}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="h-2 rounded-full"
                    style={{
                      width: `${item.closedPercentage}%`,
                      backgroundColor: item.color,
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Distribution Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">สัดส่วนช่องทางการแจ้ง</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={90}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Comparison Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">เปรียบเทียบจำนวนเคสและเวลา</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" style={{ fontSize: '12px' }} />
                <YAxis yAxisId="left" orientation="left" stroke="#3b82f6" />
                <YAxis yAxisId="right" orientation="right" stroke="#10b981" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="จำนวนเคส" fill="#3b82f6" />
                <Bar yAxisId="right" dataKey="เวลาเฉลี่ย (ชม.)" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">💡 ข้อมูลเชิงลึก</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {channelData.length > 0 && (
              <>
                <div className="flex items-start gap-2">
                  <span className="text-green-500 mt-0.5">✅</span>
                  <p className="text-sm text-gray-700">
                    <strong>{channelData[0].label}</strong> เป็นช่องทางที่ได้รับความนิยมมากสุด ({channelData[0].total} เคส, {((channelData[0].total / channelData.reduce((sum, c) => sum + c.total, 0)) * 100).toFixed(0)}% ของทั้งหมด)
                  </p>
                </div>

                {channelData.filter(c => c.avgTime > 0).length > 0 && (
                  <div className="flex items-start gap-2">
                    <span className="text-blue-500 mt-0.5">⚡</span>
                    <p className="text-sm text-gray-700">
                      <strong>{channelData.filter(c => c.avgTime > 0).sort((a, b) => a.avgTime - b.avgTime)[0].label}</strong> แก้ปัญหาได้เร็วที่สุด (เฉลี่ย {channelData.filter(c => c.avgTime > 0).sort((a, b) => a.avgTime - b.avgTime)[0].avgTime.toFixed(1)} ชม.)
                    </p>
                  </div>
                )}

                {channelData.filter(c => parseFloat(c.closedPercentage) > 80).length > 0 && (
                  <div className="flex items-start gap-2">
                    <span className="text-yellow-500 mt-0.5">🎯</span>
                    <p className="text-sm text-gray-700">
                      ช่องทางที่มีอัตราการแก้ปัญหาสูง ({'>'}80%): <strong>{channelData.filter(c => parseFloat(c.closedPercentage) > 80).map(c => c.label).join(', ')}</strong>
                    </p>
                  </div>
                )}
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
