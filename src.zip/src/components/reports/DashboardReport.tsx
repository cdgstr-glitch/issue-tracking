import { useMemo } from 'react';
import { db } from '../../lib/mockDb/client'; // ✅ Use new DB client
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import { Ticket, CheckCircle2, Clock, TrendingUp, Calendar } from 'lucide-react';
import { formatDateTime, toDate } from '../../lib/date';

export default function DashboardReport() {
  // ✅ Fetch data from DB
  const mockTickets = db.tickets.getAll();
  const getUserById = (id: string) => db.users.getById(id);

  // Calculate statistics
  const stats = useMemo(() => {
    const total = mockTickets.length;
    const closed = mockTickets.filter((t) => t.status === 'closed').length;
    const inProgress = mockTickets.filter((t) => t.status === 'in_progress').length;
    const pending = mockTickets.filter(
      (t) => t.status === 'open' || t.status === 'new' || t.status === 'on_hold'
    ).length;

    // Calculate average resolution time (in hours)
    const resolvedTickets = mockTickets.filter((t) => t.resolvedAt && t.createdAt);
    const avgResolutionTime =
      resolvedTickets.length > 0
        ? resolvedTickets.reduce((sum, t) => {
            const diff = new Date(t.resolvedAt!).getTime() - new Date(t.createdAt).getTime();
            return sum + diff / (1000 * 60 * 60); // Convert to hours
          }, 0) / resolvedTickets.length
        : 0;

    return {
      total,
      closed,
      inProgress,
      pending,
      avgResolutionTime: avgResolutionTime.toFixed(1),
      closedPercentage: total > 0 ? ((closed / total) * 100).toFixed(1) : '0',
    };
  }, []);

  // Top 10 organizations
  const orgData = useMemo(() => {
    const orgCount: Record<string, number> = {};
    mockTickets.forEach((ticket) => {
      const org = ticket.projectShortName || 'ไม่ระบุ';
      orgCount[org] = (orgCount[org] || 0) + 1;
    });

    return Object.entries(orgCount)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, []);

  // Channel distribution
  const channelData = useMemo(() => {
    const channelCount: Record<string, number> = {};
    const channelLabels: Record<string, string> = {
      line: 'Line',
      web: 'เว็บไซต์',
      email: 'อีเมล',
      phone: 'โทรศัพท์',
      in_person: 'On-site',
    };

    mockTickets.forEach((ticket) => {
      const channel = ticket.channel || 'other';
      channelCount[channel] = (channelCount[channel] || 0) + 1;
    });

    return Object.entries(channelCount)
      .map(([channel, value]) => ({
        name: channelLabels[channel] || channel,
        value,
      }))
      .sort((a, b) => b.value - a.value);
  }, []);

  // Daily trend (last 7 days)
  const dailyTrend = useMemo(() => {
    const days: Record<string, number> = {};
    const today = new Date();

    // Initialize last 7 days
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toLocaleDateString('th-TH', { day: 'numeric', month: 'short' });
      days[dateStr] = 0;
    }

    // Count tickets per day (safe for backend strings/null)
    mockTickets.forEach((ticket) => {
      const createdDate = toDate(ticket.createdAt);
      if (!createdDate) return;

      const dateStr = createdDate.toLocaleDateString('th-TH', { day: 'numeric', month: 'short' });
      if (days[dateStr] !== undefined) {
        days[dateStr]++;
      }
    });

    return Object.entries(days).map(([date, count]) => ({ date, count }));
  }, []);

  // Recent activities (last 10 tickets)
  const recentTickets = useMemo(() => {
    return [...mockTickets]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);
  }, [mockTickets]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  const statusColors: Record<string, string> = {
    new: 'bg-blue-100 text-blue-700',
    open: 'bg-yellow-100 text-yellow-700',
    in_progress: 'bg-purple-100 text-purple-700',
  on_hold: 'bg-orange-100 text-orange-700',
    closed: 'bg-green-100 text-green-700',
  };

  const statusLabels: Record<string, string> = {
    new: 'ใหม่',
    open: 'เปิด',
    in_progress: 'กำลังดำเนินการ',
  on_hold: 'รอดำเนินการ',
    closed: 'ปิด',
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">เคสทั้งหมด</CardTitle>
            <Ticket className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-gray-500 mt-1">เคส</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">แก้เสร็จแล้ว</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.closed}</div>
            <p className="text-xs text-gray-500 mt-1">{stats.closedPercentage}% ของทั้งหมด</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">กำลังดำเนินการ</CardTitle>
            <Clock className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.inProgress}</div>
            <p className="text-xs text-gray-500 mt-1">เคสที่กำลังทำ</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">เวลาเฉลี่ย</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgResolutionTime}</div>
            <p className="text-xs text-gray-500 mt-1">ชั่วโมงต่อเคส</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top 10 Organizations */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Top 10 หน่วยงานที่แจ้งมากสุด</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={orgData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={80} style={{ fontSize: '12px' }} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Channel Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">สัดส่วนช่องทางการแจ้ง</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={channelData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {channelData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Daily Trend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Trend รายวัน (7 วันล่าสุด)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={dailyTrend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="count"
                stroke="#3b82f6"
                strokeWidth={2}
                name="จำนวนเคส"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Recent Activities */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">เคสล่าสุด (10 เคสล่าสุด)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">เวลา</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">หน่วยงาน</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">หัวเรื่อง</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">สถานะ</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500">
                    ผู้รับผิดชอบ
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {recentTickets.map((ticket) => {
                  const created = toDate(ticket.createdAt);

                  return (
                    <tr key={ticket.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm text-gray-900 whitespace-nowrap">
                        {created
                          ? created.toLocaleDateString('th-TH', {
                              day: 'numeric',
                              month: 'short',
                              hour: '2-digit',
                              minute: '2-digit',
                            })
                          : '-'}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">{ticket.projectShortName || '-'}</td>
                      <td className="px-4 py-3 text-sm text-gray-900 max-w-xs truncate">{ticket.title}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[ticket.status]}`}
                        >
                          {statusLabels[ticket.status] || ticket.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">
                        {ticket.assignedTo ? getUserById(ticket.assignedTo)?.fullName : '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
