import { Button } from './ui/button';
import { Info, AlertTriangle, UserX } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { useAuth } from '../contexts/AuthContext';
import { TicketStatus } from '../types';

interface ReadOnlyModeBannerProps {
  ticketAssignedTo: string;
  currentUserId: string;
  ticketStatus: TicketStatus; // ✅ เพิ่ม prop สำหรับเช็ค status
  onTakeover: () => void;
}

export function ReadOnlyModeBanner({ ticketAssignedTo, currentUserId, ticketStatus, onTakeover }: ReadOnlyModeBannerProps) {
  const owner = db.users.getById(ticketAssignedTo);
  const { user } = useAuth();
  
  // ✅ Check if Pure Admin (admin role without any tier role)
  const hasTierRole = user?.roles?.some(role => 
    ['tier1', 'tier2', 'tier3'].includes(role)
  ) || false;
  const isPureAdmin = user?.role === 'admin' && !hasTierRole;
  
  // ✅ เคสที่ปิดแล้วหรือแก้ไขแล้ว → ไม่แสดง Banner เลย
  const isClosedOrResolved = ticketStatus === 'closed' || ticketStatus === 'resolved';
  if (isClosedOrResolved) return null;
  
  if (!owner) return null;

  return (
    <div className="bg-blue-50 border-l-4 border-blue-500 p-4 md:p-6 mb-6 rounded-r-lg shadow-sm">
      <div className="flex items-start gap-3 md:gap-4">
        <div className="flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-full bg-blue-500 text-white shrink-0">
          <Info className="h-5 w-5 md:h-6 md:w-6" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-base md:text-lg font-semibold text-blue-900 m-0">
              ℹ️ {isPureAdmin ? 'คุณกำลังดูเคส (Admin - Monitor Mode)' : 'คุณกำลังดูเคสของคนอื่น (โหมดอ่านอย่างเดียว)'}
            </h3>
          </div>
          
          {/* Owner Info */}
          <div className="rounded-lg border border-blue-200 bg-blue-100/50 p-3 md:p-4 mb-3 space-y-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div>
                <p className="text-xs text-blue-700 mb-0.5">เจ้าของเคส</p>
                <p className="text-sm font-medium text-blue-900">{owner.fullName}</p>
              </div>
              <div>
                <p className="text-xs text-blue-700 mb-0.5">ตำแหน่ง</p>
                <p className="text-sm font-medium text-blue-900">
                  {owner.tier ? `Tier ${owner.tier}` : owner.role === 'admin' ? 'Admin' : owner.role}
                </p>
              </div>
            </div>
          </div>

          {/* Permissions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 mb-4">
            <div className="rounded-lg border border-green-200 bg-green-50 p-3">
              <p className="text-xs font-medium text-green-800 mb-2">คุณสามารถ:</p>
              <ul className="text-sm text-green-700 space-y-1 m-0 pl-4">
                <li>✅ ดูรายละเอียดเคส</li>
                <li>✅ แสดงความเห็น (Comment)</li>
                <li>✅ ดู Timeline</li>
              </ul>
            </div>
            <div className="rounded-lg border border-red-200 bg-red-50 p-3">
              <p className="text-xs font-medium text-red-800 mb-2">ไม่สามารถ:</p>
              <ul className="text-sm text-red-700 space-y-1 m-0 pl-4">
                <li>❌ แก้ไขรายละเอียดเคส</li>
                <li>❌ เปลี่ยนสถานะ</li>
                <li>❌ ส่งต่อเคส</li>
                <li>❌ รับเคส</li>
              </ul>
            </div>
          </div>

          {/* Takeover Button - ซ่อนสำหรับ Pure Admin */}
          {!isPureAdmin && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 md:p-4">
              <p className="text-sm text-amber-900 mb-3">
                <strong>ต้องการดำเนินการเคสนี้ต่อหรือไม่?</strong>
              </p>
              <Button 
                onClick={onTakeover}
                className="bg-amber-600 hover:bg-amber-700 text-white w-full md:w-auto"
                size="lg"
              >
                <UserX className="mr-2 h-5 w-5" />
                Takeover เคสนี้
              </Button>
              <p className="text-xs text-amber-700 mt-2 mb-0">
                💡 เมื่อ Takeover คุณจะกลายเป็นผู้รับผิดชอบใหม่ และสามารถแก้ไขเคสได้
              </p>
            </div>
          )}
          
          {/* Pure Admin Note */}
          {isPureAdmin && (
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-3 md:p-4">
              <p className="text-sm text-gray-700 mb-0">
                <strong>📊 Admin Monitor Mode:</strong> คุณกำลังดูเคสในโหมด Monitor เท่านั้น ไม่สามารถ Takeover หรือแก้ไขเคสได้
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
