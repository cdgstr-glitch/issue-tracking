import { TimelineEvent } from '../types';
import { formatDate } from '../lib/utils';
import { db } from '../lib/mockDb/client';
import {
  filterTimelineByRole,
  sanitizeTimelineForCustomer,
  UserRole
} from '../lib/timelineUtils';
import {
  CheckCircle,
  MessageSquare,
  ArrowUpCircle,
  UserPlus,
  Paperclip,
  FileCheck
} from 'lucide-react';

interface TicketTimelineProps {
  events: TimelineEvent[];
  userRole?: any; // ✅ รับกว้างไว้ก่อน กัน tier/admin
  ticket?: any;
}

function normalizeRole(role: any): UserRole {
  // รองรับ role ที่มาจากระบบจริง (tier1/tier2/tier3/admin)
  if (role === 'customer') return 'customer';
  // ทุก role ที่ไม่ใช่ customer ให้ถือเป็น staff เพื่อให้ timeline แสดง
  return 'staff';
}

export function TicketTimeline({ events, userRole = 'staff', ticket }: TicketTimelineProps) {
  const roleForTimeline = normalizeRole(userRole);

  // 1) filter ตาม role ที่ normalize แล้ว
  let filteredEvents = filterTimelineByRole(events || [], roleForTimeline);

  // 2) ถ้าเป็นลูกค้า sanitize ข้อความ
  if (roleForTimeline === 'customer') {
    filteredEvents = sanitizeTimelineForCustomer(filteredEvents, ticket?.customerName);
  }

  // ✅ ถ้าไม่มี timeline จริง ๆ ให้มี empty state
  if (!filteredEvents || filteredEvents.length === 0) {
    return (
      <div className="text-sm text-gray-500">
        ยังไม่มีเหตุการณ์ในไทม์ไลน์
      </div>
    );
  }

  const getIcon = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'created':
        return FileCheck;
      case 'status_change':
        return CheckCircle;
      case 'comment':
        return MessageSquare;
      case 'escalation':
        return ArrowUpCircle;
      case 'assignment':
        return UserPlus;
      case 'attachment':
        return Paperclip;
      default:
        return CheckCircle;
    }
  };

  const getIconColor = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'created':
        return 'bg-green-100 text-green-600';
      case 'status_change':
        return 'bg-blue-100 text-blue-600';
      case 'comment':
        return 'bg-gray-100 text-gray-600';
      case 'escalation':
        return 'bg-orange-100 text-orange-600';
      case 'assignment':
        return 'bg-green-100 text-green-600';
      case 'attachment':
        return 'bg-purple-100 text-purple-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="space-y-4">
      {filteredEvents.map((event, index) => {
        const Icon = getIcon(event.type);
        const isLast = index === filteredEvents.length - 1;

        // ✅ แก้ action ให้ถูกกับ data ของเรา
        const isCreatedEvent =
          event.type === 'created' ||
          event.action === 'case_created';

        // ✅ trust DB first
        let displayDescription = event.description;

        // ✅ SSoT: resolve actor name จาก FK โดยตรง
        // actorUserId → db.users (staff/tier actions)
        // actorCustomerId → db.customers (customer actions)
        // ไม่มี event.user / event.userName ใน TimelineEvent schema
        let actorName: string;
        if (event.actorUserId) {
          const actorUser = db.users.getById(event.actorUserId);
          actorName = actorUser?.fullName ?? 'ระบบ';
        } else if (event.actorCustomerId) {
          const actorCustomer = db.customers.getById(event.actorCustomerId);
          actorName = actorCustomer?.fullName ?? 'ลูกค้า';
        } else {
          actorName = 'ระบบ';
        }

        // Override created description เฉพาะกรณีชัดเจนเท่านั้น
        if (isCreatedEvent && ticket) {
          if (ticket.createdByType === 'staff_on_behalf' && ticket.customerName) {
            displayDescription = `เจ้าหน้าที่บันทึกเคสแทน ลูกค้าชื่อ ${ticket.customerName}`;
          } else if (ticket.createdByType === 'customer_self') {
            displayDescription = 'ลูกค้าแจ้งเคสเอง';
          }
        }

        return (
          <div key={event.id} className="relative flex gap-4">
            {!isLast && (
              <div className="absolute left-4 top-8 h-full w-0.5 bg-gray-200" />
            )}

            <div
              className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${getIconColor(
                event.type
              )}`}
            >
              <Icon className="h-4 w-4" />
            </div>

            <div className="flex-1 pb-4">
              <div className="flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
                <p className="text-sm font-medium text-gray-900">{displayDescription}</p>
                <p className="text-xs text-gray-500">{formatDate(event.timestamp)}</p>
              </div>

              {(event.type === 'escalation' || event.type === 'assignment') && (event as any).assignedToUser ? (
                <p className="mt-1 text-xs text-gray-600">
                  by <span className="text-blue-600">{actorName}</span> → ไปให้{' '}
                  <span className="font-medium text-blue-600">{(event as any).assignedToUser}</span>
                </p>
              ) : (
                <p className="mt-1 text-xs text-gray-600">
                  by <span className="text-blue-600">{actorName}</span>
                </p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
