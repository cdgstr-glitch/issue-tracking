import { TicketPriority } from '../types';
import { getPriorityColor, getPriorityLabel, getPriorityLabelForCustomer } from '../lib/utils';
import { AlertCircle, AlertTriangle, Info, TrendingUp } from 'lucide-react';
import type { UserRole } from '../contexts/AuthContext';

interface PriorityBadgeProps {
  priority: TicketPriority;
  showIcon?: boolean;
  userRole?: UserRole; // เพิ่ม: แสดงข้อความต่างกันตาม role
}

export function PriorityBadge({ priority, showIcon = true, userRole }: PriorityBadgeProps) {
  // ✅ Defensive check for invalid/missing priority (e.g. from Triage tickets)
  if (!priority) {
     return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs bg-gray-100 text-gray-500">
          {showIcon && <Info className="w-3 h-3" />}
          <span>รอระบุ</span>
        </span>
     );
  }

  const icons: Record<string, any> = {
    low: Info,
    medium: TrendingUp,
    high: AlertTriangle,
    critical: AlertCircle
  };

  // Fallback icon if priority string exists but doesn't match keys
  // Use Info as a safe fallback that is guaranteed to be imported
  const Icon = icons[priority] || Info;

  // ใช้ customer-friendly label ถ้าเป็น customer
  const isCustomer = userRole === 'customer';
  const label = isCustomer ? getPriorityLabelForCustomer(priority) : getPriorityLabel(priority);

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs ${getPriorityColor(priority)}`}>
      {showIcon && <Icon className="w-3 h-3" />}
      {label || priority}
    </span>
  );
}
