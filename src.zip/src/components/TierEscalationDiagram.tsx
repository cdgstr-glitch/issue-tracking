import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowRight, User, Users, ShieldCheck, Phone, Mail, MessageSquare, ArrowUpRight } from 'lucide-react';

interface TierEscalationDiagramProps {
  currentTier?: 1 | 2 | 3;
}

export const TierEscalationDiagram: React.FC<TierEscalationDiagramProps> = ({ currentTier }) => {
  const tiers = [
    {
      number: 1,
      name: 'Tier 1',
      role: 'First Contact',
      description: 'รับเคสและคัดกรอง',
      icon: User,
      color: 'blue',
      bgGradient: 'from-blue-500 to-blue-600',
      responsibilities: [
        'รับเคสจากช่องทาง',
        'คัดกรองและจัดหมวดหมู่',
        'แก้ไขปัญหาพื้นฐาน'
      ],
      channels: ['โทรศัพท์', 'Email', 'Line', 'Web'],
      sla: '2-4 ชั่วโมง'
    },
    {
      number: 2,
      name: 'Tier 2',
      role: 'System Admin',
      description: 'วิเคราะห์และแก้ไขเทคนิค',
      icon: Users,
      color: 'orange',
      bgGradient: 'from-orange-500 to-orange-600',
      responsibilities: [
        'วิเคราะห์ทางเทคนิค',
        'แก้ไข Code/Config',
        'จัดการ Database'
      ],
      channels: ['จาก Tier 1'],
      sla: '1-2 วัน'
    },
    {
      number: 3,
      name: 'Tier 3',
      role: 'Specialist',
      description: 'จัดการวิกฤติและซับซ้อน',
      icon: ShieldCheck,
      color: 'red',
      bgGradient: 'from-red-500 to-red-600',
      responsibilities: [
        'จัดการเหตุการณ์วิกฤติ',
        'ติดต่อ Vendor/Provider',
        'แก้ไข Infrastructure'
      ],
      channels: ['จาก Tier 2'],
      sla: '3-5 วัน'
    }
  ];

  return (
    <div className="w-full">
      {/* Header */}
      <div className="text-center mb-8">
        <h3 className="text-gray-900 mb-2">โครงสร้างการส่งต่อเคส (Escalation Flow)</h3>
        <p className="text-gray-600 text-sm">
          เคสจะถูกส่งต่อจาก Tier 1 → Tier 2 → Tier 3 ตามความซับซ้อน
        </p>
      </div>

      {/* Desktop View - Horizontal */}
      <div className="hidden lg:block">
        <div className="relative">
          {/* Connection Line */}
          <div className="absolute top-24 left-0 right-0 h-1 bg-gradient-to-r from-blue-300 via-orange-300 to-red-300" 
               style={{ left: '15%', right: '15%', top: '6rem' }} />

          <div className="grid grid-cols-3 gap-8 relative">
            {tiers.map((tier, index) => {
              const Icon = tier.icon;
              const isActive = currentTier === tier.number;
              
              return (
                <div key={tier.number} className="relative">
                  {/* Tier Card */}
                  <Card className={`
                    border-3 transition-all duration-300
                    ${isActive 
                      ? `border-${tier.color}-500 shadow-2xl ring-4 ring-${tier.color}-200 scale-105` 
                      : `border-${tier.color}-300 shadow-lg hover:shadow-xl`
                    }
                  `}>
                    {/* Header with Icon */}
                    <div className={`bg-gradient-to-r ${tier.bgGradient} p-6 text-white rounded-t-lg relative`}>
                      {isActive && (
                        <div className="absolute -top-3 -right-3 bg-yellow-400 text-yellow-900 rounded-full px-3 py-1 text-xs shadow-lg animate-pulse">
                          คุณอยู่ที่นี่
                        </div>
                      )}
                      
                      <div className="flex items-center justify-center mb-4">
                        <div className="bg-white rounded-full p-4 shadow-lg">
                          <Icon className="h-12 w-12 text-gray-400" />
                        </div>
                      </div>
                      
                      <h3 className="text-center text-white m-0 mb-2">{tier.name}</h3>
                      <p className="text-center text-sm text-white opacity-90 m-0">{tier.role}</p>
                    </div>

                    {/* Content */}
                    <div className="p-6 space-y-4">
                      <p className="text-center text-gray-700">
                        {tier.description}
                      </p>

                      {/* SLA Badge */}
                      <div className="flex justify-center">
                        <Badge variant="outline" className={`border-${tier.color}-500 text-${tier.color}-700`}>
                          SLA: {tier.sla}
                        </Badge>
                      </div>

                      {/* Responsibilities */}
                      <div className="bg-gray-50 rounded-lg p-4">
                        <p className="text-sm text-gray-900 mb-2 m-0"><strong>ความรับผิดชอบ:</strong></p>
                        <ul className="space-y-1">
                          {tier.responsibilities.map((resp, idx) => (
                            <li key={idx} className="flex items-start text-sm text-gray-700">
                              <span className={`text-${tier.color}-600 mr-2`}>•</span>
                              <span>{resp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Channels */}
                      <div className={`bg-${tier.color}-50 rounded-lg p-4`}>
                        <p className="text-sm text-gray-900 mb-2 m-0"><strong>รับเคสจาก:</strong></p>
                        <div className="flex flex-wrap gap-2">
                          {tier.channels.map((channel, idx) => (
                            <span key={idx} className={`text-xs bg-white border border-${tier.color}-300 text-${tier.color}-700 px-2 py-1 rounded`}>
                              {channel}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>

                  {/* Arrow to next tier */}
                  {index < tiers.length - 1 && (
                    <div className="absolute top-24 -right-4 z-20">
                      <div className="flex flex-col items-center">
                        <div className="bg-white rounded-full p-3 shadow-xl border-2 border-gray-300">
                          <ArrowRight className="h-6 w-6 text-gray-600" />
                        </div>
                        <div className="mt-2 bg-purple-100 border border-purple-300 rounded-lg px-3 py-1">
                          <p className="text-xs text-purple-900 m-0">ส่งต่อ</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="mt-12 grid grid-cols-3 gap-4">
          <Card className="bg-green-50 border-green-300">
            <div className="p-4 text-center">
              <p className="text-green-900 m-0"><strong>✅ แก้ไขได้</strong></p>
              <p className="text-sm text-gray-700 mt-2 m-0">ไม่ต้องส่งต่อ ปิดเคสได้เลย</p>
            </div>
          </Card>
          <Card className="bg-orange-50 border-orange-300">
            <div className="p-4 text-center">
              <p className="text-orange-900 m-0"><strong>🔄 ส่งต่อ</strong></p>
              <p className="text-sm text-gray-700 mt-2 m-0">ส่งไปยัง Tier ถัดไป</p>
            </div>
          </Card>
          <Card className="bg-yellow-50 border-yellow-300">
            <div className="p-4 text-center">
              <p className="text-yellow-900 m-0"><strong>⏸️ ระงับ</strong></p>
              <p className="text-sm text-gray-700 mt-2 m-0">รอข้อมูลเพิ่มเติม</p>
            </div>
          </Card>
        </div>
      </div>

      {/* Mobile/Tablet View - Vertical */}
      <div className="lg:hidden space-y-8">
        {tiers.map((tier, index) => {
          const Icon = tier.icon;
          const isActive = currentTier === tier.number;
          
          return (
            <div key={tier.number}>
              <Card className={`
                border-3 transition-all
                ${isActive 
                  ? `border-${tier.color}-500 shadow-2xl ring-4 ring-${tier.color}-200` 
                  : `border-${tier.color}-300 shadow-lg`
                }
              `}>
                <div className={`bg-gradient-to-r ${tier.bgGradient} p-6 text-white rounded-t-lg relative`}>
                  {isActive && (
                    <div className="absolute -top-2 -right-2 bg-yellow-400 text-yellow-900 rounded-full px-3 py-1 text-xs shadow-lg">
                      คุณอยู่ที่นี่
                    </div>
                  )}
                  
                  <div className="flex items-center gap-4">
                    <div className="bg-white rounded-full p-3 shadow-lg">
                      <Icon className="h-10 w-10 text-gray-400" />
                    </div>
                    <div>
                      <h3 className="text-white m-0">{tier.name}</h3>
                      <p className="text-sm text-white opacity-90 m-0">{tier.role}</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <p className="text-gray-700">{tier.description}</p>

                  <Badge variant="outline" className={`border-${tier.color}-500 text-${tier.color}-700`}>
                    SLA: {tier.sla}
                  </Badge>

                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-900 mb-2 m-0"><strong>ความรับผิดชอบ:</strong></p>
                    <ul className="space-y-1">
                      {tier.responsibilities.map((resp, idx) => (
                        <li key={idx} className="flex items-start text-sm text-gray-700">
                          <span className={`text-${tier.color}-600 mr-2`}>•</span>
                          <span>{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className={`bg-${tier.color}-50 rounded-lg p-4`}>
                    <p className="text-sm text-gray-900 mb-2 m-0"><strong>รับเคสจาก:</strong></p>
                    <div className="flex flex-wrap gap-2">
                      {tier.channels.map((channel, idx) => (
                        <span key={idx} className={`text-xs bg-white border border-${tier.color}-300 text-${tier.color}-700 px-2 py-1 rounded`}>
                          {channel}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>

              {index < tiers.length - 1 && (
                <div className="flex justify-center py-4">
                  <div className="flex flex-col items-center">
                    <div className="bg-white rounded-full p-3 shadow-lg border-2 border-gray-300">
                      <ArrowRight className="h-6 w-6 rotate-90 text-gray-600" />
                    </div>
                    <div className="mt-2 bg-purple-100 border border-purple-300 rounded-lg px-3 py-1">
                      <p className="text-xs text-purple-900 m-0">ส่งต่อ</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Mobile Legend */}
        <div className="space-y-3 mt-8">
          <Card className="bg-green-50 border-green-300 p-4">
            <p className="text-green-900 text-center m-0"><strong>✅ แก้ไขได้</strong> - ไม่ต้องส่งต่อ</p>
          </Card>
          <Card className="bg-orange-50 border-orange-300 p-4">
            <p className="text-orange-900 text-center m-0"><strong>🔄 ส่งต่อ</strong> - ส่งไปยัง Tier ถัดไป</p>
          </Card>
          <Card className="bg-yellow-50 border-yellow-300 p-4">
            <p className="text-yellow-900 text-center m-0"><strong>⏸️ ระงับ</strong> - รอข้อมูลเพิ่มเติม</p>
          </Card>
        </div>
      </div>

      {/* Escalation Rules */}
      <Card className="mt-8 border-purple-300 bg-gradient-to-r from-purple-50 to-pink-50">
        <div className="p-6">
          <h4 className="text-purple-900 mb-4 flex items-center gap-2">
            <ArrowUpRight className="h-5 w-5" />
            กฎการส่งต่อเคส
          </h4>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 border border-blue-200">
              <p className="text-blue-900 mb-2 m-0"><strong>Tier 1 → Tier 2</strong></p>
              <p className="text-sm text-gray-700 m-0">เมื่อต้องการ: การวิเคราะห์ล็อก, แก้ไข code/config, จัดการ database</p>
            </div>
            <div className="bg-white rounded-lg p-4 border border-orange-200">
              <p className="text-orange-900 mb-2 m-0"><strong>Tier 2 → Tier 3</strong></p>
              <p className="text-sm text-gray-700 m-0">เมื่อพบ: เหตุการณ์วิกฤติ, ต้องติดต่อ vendor, ปัญหา infrastructure</p>
            </div>
            <div className="bg-white rounded-lg p-4 border border-red-200">
              <p className="text-red-900 mb-2 m-0"><strong>Tier 3 → External</strong></p>
              <p className="text-sm text-gray-700 m-0">เมื่อต้องการ: Cloud provider, software vendor, ผู้เชี่ยวชาญพิเศษ</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};