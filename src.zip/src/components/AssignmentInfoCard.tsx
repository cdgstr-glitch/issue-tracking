import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { User, ArrowRight, Clock, UserX } from 'lucide-react';
import { Ticket } from '../types';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { formatDate } from '../lib/utils';
import { useState, useEffect } from 'react';

interface AssignmentInfoCardProps {
  ticket: Ticket;
}

export function AssignmentInfoCard({ ticket }: AssignmentInfoCardProps) {
  // Check for takeover info
  const [takeoverInfo, setTakeoverInfo] = useState<{
    previousViewer: string;
    previousAssignee: string;
  } | null>(null);

  useEffect(() => {
    const takeoverData = localStorage.getItem('takeoverTicket');
    if (takeoverData) {
      try {
        const data = JSON.parse(takeoverData);
        if (data.ticketId === ticket.id && data.previousViewer) {
          setTakeoverInfo({
            previousViewer: data.previousViewer,
            previousAssignee: data.previousAssignee
          });
        }
      } catch (e) {
        console.error('Failed to parse takeover data:', e);
      }
    }
  }, [ticket.id]);

  // ✅ ซ่อนเมื่อเคสปิดแล้วหรือแก้ไขแล้ว
  const isClosedOrResolved = ticket.status === 'closed' || ticket.status === 'resolved';
  if (isClosedOrResolved) return null;

  // Only show if ticket has been assigned
  if (!ticket.assignedTo && !ticket.assignedBy) return null;

  const assignedTo = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;
  const assignedBy = ticket.assignedBy ? db.users.getById(ticket.assignedBy) : null;
  
  // Check if this is an escalation or initial assignment
  const isEscalation = ticket.previousAssignee !== undefined;
  const isSelfAssignment = ticket.assignedBy === ticket.assignedTo;

  const getTierLabel = (status: string) => {
    if (status === 'tier1' || status === 'new') return 'Tier 1';
    if (status === 'tier2') return 'Tier 2';
    if (status === 'tier3') return 'Tier 3';
    if (status === 'in_progress') return assignedTo?.tier ? `Tier ${assignedTo.tier}` : 'กำลังดำเนินการ';
    return status;
  };

  const getStatusText = (status: string) => {
    if (['tier1', 'tier2', 'tier3'].includes(status)) {
      return 'รอการรับเคส';
    }
    if (status === 'in_progress') {
      return 'กำลังดำเนินการ';
    }
    if (status === 'resolved') {
      return 'แก้ไขเสร็จสิ้น';
    }
    return status;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">ข้อมูลการมอบหมาย</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Case 1: Self-assignment (เพิ่งรับเคส) - แสดงแค่ผู้รับเคสเท่านั้น */}
        {isSelfAssignment && !isEscalation ? (
          <>
            {/* Assigned To/By (same person) */}
            {assignedTo && (
              <div className="flex items-start gap-3">
                <User className="mt-0.5 h-4 w-4 text-blue-600" />
                <div className="flex-1">
                  <p className="text-xs text-gray-600">รับเคสโดย</p>
                  <p className="text-sm">
                    <strong>{assignedTo.fullName}</strong>
                    {assignedTo.tier && ` (${getTierLabel(ticket.status)})`}
                  </p>
                </div>
              </div>
            )}

            {/* Assignment Date */}
            {ticket.assignedAt && (
              <div className="flex items-start gap-3">
                <Clock className="mt-0.5 h-4 w-4 text-gray-400" />
                <div className="flex-1">
                  <p className="text-xs text-gray-600">วันที่รับเคส</p>
                  <p className="text-sm">{formatDate(ticket.assignedAt)}</p>
                </div>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Case 2: Escalation (มีการส่งต่อ) - แสดงผู้ส่งและผู้รับ */}

            {/* Assigned To */}
            {assignedTo && (
              <div className="flex items-start gap-3">
                <User className="mt-0.5 h-4 w-4 text-blue-600" />
                <div className="flex-1">
                  <p className="text-xs text-gray-600">
                    {assignedBy ? `${assignedBy.fullName} ส่งต่อไปยัง` : 'ส่งต่อไปยัง'}
                  </p>
                  <p className="text-sm">
                    <strong>{assignedTo.fullName}</strong>
                    {assignedTo.tier && ` (Tier ${assignedTo.tier})`}
                  </p>
                </div>
              </div>
            )}

            {/* Assignment Date */}
            {ticket.assignedAt && (
              <div className="flex items-start gap-3">
                <Clock className="mt-0.5 h-4 w-4 text-gray-400" />
                <div className="flex-1">
                  <p className="text-xs text-gray-600">วันที่ส่งต่อ</p>
                  <p className="text-sm">{formatDate(ticket.assignedAt)}</p>
                </div>
              </div>
            )}
          </>
        )}

        {/* Status */}
        <div className="pt-3 border-t">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-600">สถานะปัจจุบัน</span>
            <span 
              className={`text-sm px-2 py-1 rounded ${
                ['tier1', 'tier2', 'tier3'].includes(ticket.stage as any)
                  ? 'bg-yellow-100 text-yellow-800'
                  : ticket.status === 'in_progress'
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              {getStatusText(ticket.status)}
            </span>
          </div>
        </div>

        {/* Takeover Info */}
        {takeoverInfo && takeoverInfo.previousViewer && (
          <div className="pt-3 border-t">
            <div className="flex items-start gap-3">
              <UserX className="mt-0.5 h-4 w-4 text-amber-600" />
              <div className="flex-1">
                <p className="text-xs text-gray-600">รับเคสแทน (Takeover)</p>
                <p className="text-sm text-amber-700">
                  {takeoverInfo.previousViewer}
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
