import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { X } from 'lucide-react';
import { Button } from './ui/button';
import { Ticket, User } from '../types';

interface EmailPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'customer' | 'staff' | 'assignment' | 'reminder';
  ticket: Ticket;
  assignedBy?: User;
  assignedTo?: User;
}

export function EmailPreviewModal({ 
  isOpen, 
  onClose, 
  type, 
  ticket,
  assignedBy,
  assignedTo
}: EmailPreviewModalProps) {
  
  const sampleReplyMessage = "ขอบคุณที่ติดต่อกลับมาครับ ผมได้รับข้อมูลเพิ่มเติมแล้ว กรุณาช่วยตรวจสอบอีกครั้งครับ";
  
  if (type === 'customer') {
    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>ตัวอย่างอีเมลแจ้งลูกค้า</DialogTitle>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <DialogDescription>
              ตัวอย่างอีเมลยืนยันที่ลูกค้าจะได้รับเมื่อส่งข้อความตอบกลับเคส
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Email Header Info */}
            <div className="space-y-2 border-b pb-4">
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">ถึง:</span>
                <span className="text-sm">{ticket.customerName} ({ticket.customerEmail || 'siriporn.a@example.com'})</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">จาก:</span>
                <span className="text-sm">CDGS Support (noreply@cdgs.co.th)</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">หัวเรื่อง:</span>
                <span className="text-sm">ยืนยันการส่งข้อความตอบกลับ - {ticket.ticketNumber}</span>
              </div>
            </div>

            {/* Email Body */}
            <Card className="border-2 border-blue-100">
              <CardContent className="p-6 space-y-4">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                    <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h2 className="text-xl mb-2">ส่งข้อความตอบกลับสำเร็จ</h2>
                  <p className="text-gray-600">เคส {ticket.ticketNumber}</p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 border">
                  <p className="text-sm mb-2">สวัสดีคุณ {ticket.customerName},</p>
                  <p className="text-sm mb-4">
                    ขอบคุณที่ส่งข้อความตอบกลับเพิ่มเติม ระบบได้รับข้อความของคุณเรียบร้อยแล้ว 
                    และได้ส่งต่อไปยังเจ้าหน้าที่ผู้รับผิดชอบเคสนี้แล้ว
                  </p>
                  
                  <div className="bg-white rounded border-l-4 border-blue-500 p-3 mb-4">
                    <p className="text-xs text-gray-600 mb-1">ข้อความของคุณ:</p>
                    <p className="text-sm">{sampleReplyMessage}</p>
                  </div>

                  <p className="text-sm mb-2">
                    เจ้าหน้าที่จะตรวจสอบและตอบกลับคุณโดยเร็วที่สุด 
                    คุณสามารถติดตามสถานะเคสได้ตลอดเวลาผ่านระบบ
                  </p>

                  <div className="text-center mt-6">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      ดูรายละเอียดเคส
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-4 text-xs text-gray-500 text-center">
                  <p>อีเมลนี้ถูกส่งอัตโนมัติ กรุณาอย่าตอบกลับที่อีเมลนี้</p>
                  <p className="mt-1">© 2024 CDGS Application Support Center. All rights reserved.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Staff Email
  if (type === 'staff') {
    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>ตัวอย่างอีเมลแจ้งเจ้าหน้าที่</DialogTitle>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <DialogDescription>
              ตัวอย่างอีเมลแจ้งเตือนที่เจ้าหน้าที่จะได้รับเมื่อลูกค้าตอบกลับเคส
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Email Header Info */}
            <div className="space-y-2 border-b pb-4">
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">ถึง:</span>
                <span className="text-sm">Support Team Tier 1 (tier1@cdgs.co.th)</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">จาก:</span>
                <span className="text-sm">CDGS System (system@cdgs.co.th)</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">หัวเรื่อง:</span>
                <span className="text-sm">🔔 ลูกค้าตอบกลับเคส - {ticket.ticketNumber}</span>
              </div>
            </div>

            {/* Email Body */}
            <Card className="border-2 border-orange-100">
              <CardContent className="p-6 space-y-4">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-100 rounded-full mb-4">
                    <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                  </div>
                  <h2 className="text-xl mb-2">มีข้อความตอบกลับใหม่</h2>
                  <p className="text-gray-600">เคส {ticket.ticketNumber}</p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 border">
                  <p className="text-sm mb-4">สวัสดีทีมสนับสนุน,</p>
                  <p className="text-sm mb-4">
                    ลูกค้า <strong>{ticket.customerName}</strong> ได้ส่งข้อความตอบกลับเพิ่มเติมในเคส {ticket.ticketNumber}
                  </p>
                  
                  <div className="bg-white rounded border-l-4 border-orange-500 p-3 mb-4">
                    <p className="text-xs text-gray-600 mb-1">ข้อความจากลูกค้า:</p>
                    <p className="text-sm">{sampleReplyMessage}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      ส่งเมื่อ: {new Date().toLocaleDateString('th-TH', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>

                  <div className="bg-blue-50 rounded p-3 mb-4">
                    <p className="text-xs mb-1">ข้อมูลเคส:</p>
                    <ul className="text-sm space-y-1">
                      <li>• หมายเลขเคส: <strong>{ticket.ticketNumber}</strong></li>
                      <li>• ลูกค้า: {ticket.customerName}</li>
                      <li>• สถานะ: กำลังดำเนินการ</li>
                      <li>• ลำดับความสำคัญ: ปานกลาง</li>
                    </ul>
                  </div>

                  <p className="text-sm mb-2">
                    กรุณาตรวจสอบและตอบกลับลูกค้าโดยเร็วที่สุดตาม SLA ที่กำหนด
                  </p>

                  <div className="text-center mt-6">
                    <Button className="bg-orange-600 hover:bg-orange-700">
                      ตอบกลับเคสนี้
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-4 text-xs text-gray-500 text-center">
                  <p>อีเมลแจ้งเตือนอัตโนมัติจากระบบ CDGS Issue Tracking Platform</p>
                  <p className="mt-1">© 2024 CDGS. All rights reserved.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Assignment Email
  if (type === 'assignment') {
    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>ตัวอย่างอีเมลแจ้งการมอบหมายงาน</DialogTitle>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <DialogDescription>
              ตัวอย่างอีเมลแจ้งเตือนที่เจ้าหน้าที่จะได้รับเมื่อถูกมอบหมายงานใหม่
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Email Header Info */}
            <div className="space-y-2 border-b pb-4">
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">ถึง:</span>
                <span className="text-sm">{assignedTo?.email}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">จาก:</span>
                <span className="text-sm">CDGS System (system@cdgs.co.th)</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">หัวเรื่อง:</span>
                <span className="text-sm">🔔 คุณได้รับการมอบหมายงานใหม่ - {ticket.ticketNumber}</span>
              </div>
            </div>

            {/* Email Body */}
            <Card className="border-2 border-orange-100">
              <CardContent className="p-6 space-y-4">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-100 rounded-full mb-4">
                    <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                  </div>
                  <h2 className="text-xl mb-2">คุณได้รับการมอบหมายงานใหม่</h2>
                  <p className="text-gray-600">เคส {ticket.ticketNumber}</p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 border">
                  <p className="text-sm mb-4">สวัสดี {assignedTo?.fullName},</p>
                  <p className="text-sm mb-4">
                    คุณได้รับการมอบหมายงานใหม่จาก {assignedBy?.fullName} ในเคส {ticket.ticketNumber}
                  </p>
                  
                  <div className="bg-white rounded border-l-4 border-orange-500 p-3 mb-4">
                    <p className="text-xs text-gray-600 mb-1">รายละเอียดเคส:</p>
                    <p className="text-sm">{ticket.description}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      มอบหมายเมื่อ: {new Date().toLocaleDateString('th-TH', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>

                  <div className="bg-blue-50 rounded p-3 mb-4">
                    <p className="text-xs mb-1">ข้อมูลเคส:</p>
                    <ul className="text-sm space-y-1">
                      <li>• หมายเลขเคส: <strong>{ticket.ticketNumber}</strong></li>
                      <li>• ลูกค้า: {ticket.customerName}</li>
                      <li>• สถานะ: กำลังดำเนินการ</li>
                      <li>• ลำดับความสำคัญ: ปานกลาง</li>
                    </ul>
                  </div>

                  <p className="text-sm mb-2">
                    กรุณาตรวจสอบและดำเนินการตาม SLA ที่กำหนด
                  </p>

                  <div className="text-center mt-6">
                    <Button className="bg-orange-600 hover:bg-orange-700">
                      ดำเนินการเคสนี้
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-4 text-xs text-gray-500 text-center">
                  <p>อีเมลแจ้งเตือนอัตโนมัติจากระบบ CDGS Issue Tracking Platform</p>
                  <p className="mt-1">© 2024 CDGS. All rights reserved.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Reminder Email
  if (type === 'reminder') {
    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>ตัวอย่างอีเมลแจ้งเตือนการจัดการเคส</DialogTitle>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <DialogDescription>
              ตัวอย่างอีเมลแจ้งเตือนที่เจ้าหน้าที่จะได้รับเมื่อถึงเวลาจัดการเคส
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Email Header Info */}
            <div className="space-y-2 border-b pb-4">
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">ถึง:</span>
                <span className="text-sm">{assignedTo?.email}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">จาก:</span>
                <span className="text-sm">CDGS System (system@cdgs.co.th)</span>
              </div>
              <div className="flex gap-2">
                <span className="text-sm text-gray-600">หัวเรื่อง:</span>
                <span className="text-sm">🔔 แจ้งเตือนการจัดการเคส - {ticket.ticketNumber}</span>
              </div>
            </div>

            {/* Email Body */}
            <Card className="border-2 border-orange-100">
              <CardContent className="p-6 space-y-4">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-100 rounded-full mb-4">
                    <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                  </div>
                  <h2 className="text-xl mb-2">แจ้งเตือนการจัดการเคส</h2>
                  <p className="text-gray-600">เคส {ticket.ticketNumber}</p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 border">
                  <p className="text-sm mb-4">สวัสดี {assignedTo?.fullName},</p>
                  <p className="text-sm mb-4">
                    คุณได้รับแจ้งเตือนการจัดการเคสจาก {assignedBy?.fullName} ในเคส {ticket.ticketNumber}
                  </p>
                  
                  <div className="bg-white rounded border-l-4 border-orange-500 p-3 mb-4">
                    <p className="text-xs text-gray-600 mb-1">รายละเอียดเคส:</p>
                    <p className="text-sm">{ticket.description}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      แจ้งเตือนเมื่อ: {new Date().toLocaleDateString('th-TH', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>

                  <div className="bg-blue-50 rounded p-3 mb-4">
                    <p className="text-xs mb-1">ข้อมูลเคส:</p>
                    <ul className="text-sm space-y-1">
                      <li>• หมายเลขเคส: <strong>{ticket.ticketNumber}</strong></li>
                      <li>• ลูกค้า: {ticket.customerName}</li>
                      <li>• สถานะ: กำลังดำเนินการ</li>
                      <li>• ลำดับความสำคัญ: ปานกลาง</li>
                    </ul>
                  </div>

                  <p className="text-sm mb-2">
                    กรุณาตรวจสอบและดำเนินการตาม SLA ที่กำหนด
                  </p>

                  <div className="text-center mt-6">
                    <Button className="bg-orange-600 hover:bg-orange-700">
                      ดำเนินการเคสนี้
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-4 text-xs text-gray-500 text-center">
                  <p>อีเมลแจ้งเตือนอัตโนมัติจากระบบ CDGS Issue Tracking Platform</p>
                  <p className="mt-1">© 2024 CDGS. All rights reserved.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return null;
}
