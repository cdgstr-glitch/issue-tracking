import { useState, KeyboardEvent } from 'react';
import { X, Hash } from 'lucide-react';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

// Define locally instead of importing from mockData
const predefinedHashtags = [
  'Login', 'Network', 'Printer', 'Software', 'Hardware', 'Email', 'VPN', 'Security', 'Permission', 'Data',
  'Report', 'Database', 'Server', 'Cloud', 'Meeting', 'Urgent', 'Bug', 'Feature', 'Support', 'Maintenance'
];

interface TagInputProps {
  value: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
}

export function TagInput({ value = [], onChange, placeholder = 'พิมพ์ป้ายกำกับและกด Enter...' }: TagInputProps) {
  const [inputValue, setInputValue] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputValue(val);

    // Show suggestions if typing
    if (val.trim()) {
      const filtered = predefinedHashtags.filter(
        tag => tag.toLowerCase().includes(val.toLowerCase()) && !value.includes(tag)
      );
      setSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const addTag = (tag: string) => {
    const trimmedTag = tag.trim();
    if (trimmedTag && !value.includes(trimmedTag)) {
      onChange([...value, trimmedTag]);
    }
    setInputValue('');
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (inputValue.trim()) {
        addTag(inputValue);
      }
    } else if (e.key === 'Backspace' && !inputValue && value.length > 0) {
      // Remove last tag on backspace if input is empty
      onChange(value.slice(0, -1));
    }
  };

  const removeTag = (tagToRemove: string) => {
    onChange(value.filter(tag => tag !== tagToRemove));
  };

  const selectSuggestion = (tag: string) => {
    addTag(tag);
  };

  return (
    <div className="relative">
      <div className="min-h-[42px] rounded-md border border-input bg-background px-3 py-2 text-sm focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2">
        <div className="flex flex-wrap gap-2">
          {value.map((tag) => (
            <Badge
              key={tag}
              variant="secondary"
              className="bg-gray-100 text-gray-700 hover:bg-gray-200 px-2 py-1 gap-1"
            >
              <Hash className="h-3 w-3" />
              {tag}
              <button
                type="button"
                onClick={() => removeTag(tag)}
                className="ml-1 hover:bg-blue-300 rounded-full p-0.5"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
          <Input
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            onFocus={() => {
              if (inputValue && suggestions.length > 0) {
                setShowSuggestions(true);
              }
            }}
            placeholder={value.length === 0 ? placeholder : ''}
            className="border-0 p-0 h-auto focus-visible:ring-0 focus-visible:ring-offset-0 flex-1 min-w-[120px]"
          />
        </div>
      </div>

      {/* Suggestions Dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover shadow-lg">
          <div className="max-h-60 overflow-y-auto p-1">
            <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
              แนะนำ
            </div>
            {suggestions.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => selectSuggestion(tag)}
                className="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-accent cursor-pointer"
              >
                <Hash className="h-3 w-3 text-blue-600" />
                <span className="text-blue-700">{tag}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Quick Add Suggestions */}
      {value.length === 0 && !inputValue && (
        <div className="mt-2 flex flex-wrap gap-2">
          <span className="text-xs text-gray-500">แนะนำ:</span>
          {predefinedHashtags.slice(0, 5).map((tag) => (
            <button
              key={tag}
              type="button"
              onClick={() => addTag(tag)}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors"
            >
              <Hash className="h-3 w-3" />
              {tag}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
