import { FileText } from 'lucide-react';
import { db } from '../lib/mockDb/client';
import { getRoleDisplayName } from '../lib/utils';
import { Ticket, UserRole } from '../types';

interface AssignedBadgeProps {
  ticket: Ticket;
  size?: 'sm' | 'md';
}

// ✅ SSoT: รับ ticket แล้ว lookup assignee เองภายใน
// ไม่ให้ parent hydrate ก่อนส่ง — ลดการ coupling
export function AssignedBadge({ ticket, size = 'sm' }: AssignedBadgeProps) {
  const assignee = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;

  if (!assignee) return null;

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-3.5 w-3.5',
  };

  const roleDisplayName = assignee.primaryRole
    ? getRoleDisplayName(assignee.primaryRole as UserRole)
    : '';

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full bg-blue-100 text-blue-700 ${sizeClasses[size]}`}
      title={`มอบหมายให้ ${assignee.fullName}${roleDisplayName ? ` (${roleDisplayName})` : ''}`}
    >
      <FileText className={iconSizes[size]} />
      <span className="font-medium">{assignee.fullName}</span>
      {roleDisplayName && (
        <span className="text-blue-600/80">({roleDisplayName})</span>
      )}
    </span>
  );
}
