import { useState, useRef } from 'react';
import { Paperclip, X, Upload, FileText, File, Image as ImageIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Attachment } from '../types';
import { formatFileSize } from '../lib/utils'; // Use utils instead of mockData

interface AttachmentUploadProps {
  value: File[];
  onChange: (files: File[]) => void;
  maxFiles?: number;
  maxFileSize?: number; // in bytes
  acceptedFileTypes?: string[]; // e.g., ['image/*', 'application/pdf']
  disabled?: boolean;
}

export function AttachmentUpload({
  value = [],
  onChange,
  maxFiles = 10,
  maxFileSize = 10 * 1024 * 1024, // 10 MB
  acceptedFileTypes = ['image/*', 'application/pdf', 'text/*', '.doc', '.docx', '.xls', '.xlsx'],
  disabled = false,
}: AttachmentUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string>('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const validateFiles = (files: FileList | File[]): File[] => {
    const fileArray = Array.from(files);
    const validFiles: File[] = [];
    let errorMessage = '';

    // Check total count
    if (value.length + fileArray.length > maxFiles) {
      errorMessage = `สามารถแนบไฟล์ได้สูงสุด ${maxFiles} ไฟล์`;
      setError(errorMessage);
      return [];
    }

    // Validate each file
    for (const file of fileArray) {
      // Check file size
      if (file.size > maxFileSize) {
        errorMessage = `ไฟล์ "${file.name}" มีขนาดเกิน ${formatFileSize(maxFileSize)}`;
        setError(errorMessage);
        continue;
      }

      // Check file type
      const isAccepted = acceptedFileTypes.some((type) => {
        if (type.includes('*')) {
          const prefix = type.split('/')[0];
          return file.type.startsWith(prefix);
        }
        if (type.startsWith('.')) {
          return file.name.toLowerCase().endsWith(type.toLowerCase());
        }
        return file.type === type;
      });

      if (!isAccepted) {
        errorMessage = `ไฟล์ "${file.name}" ไม่รองรับ`;
        setError(errorMessage);
        continue;
      }

      validFiles.push(file);
    }

    if (errorMessage) {
      setTimeout(() => setError(''), 5000); // Clear error after 5 seconds
    }

    return validFiles;
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (disabled) return;

    const { files } = e.dataTransfer;
    const validFiles = validateFiles(files);
    
    if (validFiles.length > 0) {
      onChange([...value, ...validFiles]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (disabled) return;

    if (e.target.files && e.target.files.length > 0) {
      const validFiles = validateFiles(e.target.files);
      
      if (validFiles.length > 0) {
        onChange([...value, ...validFiles]);
      }
    }
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = value.filter((_, i) => i !== index);
    onChange(newFiles);
    setError('');
  };

  const handleClick = () => {
    if (!disabled) {
      inputRef.current?.click();
    }
  };

  const getFileTypeIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <ImageIcon className="w-5 h-5 text-blue-500" />;
    if (file.type === 'application/pdf') return <FileText className="w-5 h-5 text-red-500" />;
    if (file.type.startsWith('text/')) return <FileText className="w-5 h-5 text-gray-500" />;
    return <File className="w-5 h-5 text-gray-500" />;
  };

  return (
    <div className="space-y-3">
      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
          dragActive
            ? 'border-blue-500 bg-blue-50'
            : disabled
            ? 'border-gray-300 bg-gray-50 cursor-not-allowed'
            : 'border-gray-300 hover:border-gray-400 cursor-pointer'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={handleClick}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={acceptedFileTypes.join(',')}
          onChange={handleChange}
          disabled={disabled}
          className="hidden"
        />
        
        <div className="flex flex-col items-center gap-2">
          <Upload className={`w-10 h-10 ${disabled ? 'text-gray-300' : 'text-gray-400'}`} />
          <div className={disabled ? 'text-gray-400' : 'text-gray-700'}>
            <p className="font-medium">
              คลิกหรือลากไฟล์มาวางที่นี่
            </p>
            <p className="text-sm text-gray-500 mt-1">
              รองรับ: PNG, JPG, PDF, DOC, XLS, TXT
            </p>
            <p className="text-xs text-gray-400 mt-1">
              ขนาดสูงสุด {formatFileSize(maxFileSize)} ต่อไฟล์ | สูงสุด {maxFiles} ไฟล์
            </p>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      {/* File List */}
      {value.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-700">
            ไฟล์ที่เลือก ({value.length}/{maxFiles}):
          </p>
          <div className="space-y-2">
            {value.map((file, index) => (
              <div
                key={`${file.name}-${index}`}
                className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-lg p-3 group hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  {getFileTypeIcon(file)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {file.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatFileSize(file.size)}
                    </p>
                  </div>
                </div>
                {!disabled && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveFile(index);
                    }}
                    className="ml-2 p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                    aria-label="ลบไฟล์"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
