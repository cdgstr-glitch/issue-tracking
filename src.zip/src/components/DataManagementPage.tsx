import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Download, 
  Upload, 
  FileDown, 
  FileJson, 
  FileSpreadsheet,
  ArrowLeft,
  Building2,
  FolderOpen,
  AlertCircle,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { 
  exportOrganizations, 
  exportProjects, 
  exportCombinedData 
} from '../lib/utils/dataExport';
import { 
  importOrganizations, 
  importProjects, 
  validateImportedData 
} from '../lib/utils/dataImport';
import { toast } from 'sonner@2.0.3';
import { OrganizationStatsCard } from './OrganizationStatsCard';

interface DataManagementPageProps {
  onNavigate: (path: string) => void;
}

export function DataManagementPage({ onNavigate }: DataManagementPageProps) {
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    type: 'organizations' | 'projects';
    success: number;
    duplicates: number;
    errors: string[];
  } | null>(null);

  // ✅ Fetch data from DB
  const organizations = db.organizations.getAll();
  const projects = db.projects.getAll();
  const tickets = db.tickets.getAll();

  // Export handlers
  const handleExportOrganizations = (format: 'csv' | 'json') => {
    exportOrganizations(organizations, format);
    toast.success(`ส่งออกข้อมูลหน่วยงาน (${format.toUpperCase()}) สำเร็จ`);
  };

  const handleExportProjects = (format: 'csv' | 'json') => {
    exportProjects(projects, organizations, format);
    toast.success(`ส่งออกข้อมูลโครงการ (${format.toUpperCase()}) สำเร็จ`);
  };

  const handleExportAll = () => {
    exportCombinedData(organizations, projects);
    toast.success('ส่งออกข้อมูลทั้งหมด (JSON) สำเร็จ');
  };

  // Import handlers
  const handleImportOrganizations = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResult(null);

    try {
      const imported = await importOrganizations(file);
      const validation = validateImportedData(imported, organizations);

      setImportResult({
        type: 'organizations',
        success: validation.valid.length,
        duplicates: validation.duplicates.length,
        errors: validation.errors
      });

      if (validation.valid.length > 0) {
        // TODO: Save to backend (e.g., db.organizations.add(item))
        // For now, we are just mocking the import validation and result display
        toast.success(`นำเข้าข้อมูล ${validation.valid.length} หน่วยงานสำเร็จ`);
      }

      if (validation.duplicates.length > 0) {
        toast.warning(`พบข้อมูลซ้ำ ${validation.duplicates.length} รายการ`);
      }
    } catch (error: any) {
      toast.error(`เกิดข้อผิดพลาด: ${error.message}`);
    } finally {
      setImporting(false);
      e.target.value = ''; // Reset input
    }
  };

  const handleImportProjects = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResult(null);

    try {
      const imported = await importProjects(file);
      const validation = validateImportedData(imported, projects);

      setImportResult({
        type: 'projects',
        success: validation.valid.length,
        duplicates: validation.duplicates.length,
        errors: validation.errors
      });

      if (validation.valid.length > 0) {
        // TODO: Save to backend
        toast.success(`นำเข้าข้อมูล ${validation.valid.length} โครงการสำเร็จ`);
      }

      if (validation.duplicates.length > 0) {
        toast.warning(`พบข้อมูลซ้ำ ${validation.duplicates.length} รายการ`);
      }
    } catch (error: any) {
      toast.error(`เกิดข้อผิดพลาด: ${error.message}`);
    } finally {
      setImporting(false);
      e.target.value = ''; // Reset input
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => onNavigate('/admin/dashboard')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            กลับ
          </Button>
          <div>
            <h1 className="text-3xl mb-2">จัดการข้อมูล</h1>
            <p className="text-gray-600">นำเข้า/ส่งออกข้อมูลหน่วยงานและโครงการ</p>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                หน่วยงานทั้งหมด
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold">{organizations.length}</div>
                <Building2 className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                โครงการทั้งหมด
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold">{projects.length}</div>
                <FolderOpen className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                โครงการที่ใช้งานอยู่
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold">
                  {projects.filter(p => p.projectStatus === 'active').length}
                </div>
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Export Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" />
              ส่งออกข้อมูล
            </CardTitle>
            <CardDescription>
              ดาวน์โหลดข้อมูลหน่วยงานและโครงการในรูปแบบ CSV หรือ JSON
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Organizations Export */}
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium mb-1">ข้อมูลหน่วยงาน</h3>
                <p className="text-sm text-gray-600">
                  {organizations.length} หน่วยงาน
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExportOrganizations('csv')}
                  className="gap-2"
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExportOrganizations('json')}
                  className="gap-2"
                >
                  <FileJson className="h-4 w-4" />
                  JSON
                </Button>
              </div>
            </div>

            {/* Projects Export */}
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium mb-1">ข้อมูลโครงการ</h3>
                <p className="text-sm text-gray-600">
                  {projects.length} โครงการ
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExportProjects('csv')}
                  className="gap-2"
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExportProjects('json')}
                  className="gap-2"
                >
                  <FileJson className="h-4 w-4" />
                  JSON
                </Button>
              </div>
            </div>

            {/* Combined Export */}
            <div className="flex items-center justify-between p-4 border rounded-lg bg-blue-50">
              <div>
                <h3 className="font-medium mb-1">ข้อมูลทั้งหมด (รวม)</h3>
                <p className="text-sm text-gray-600">
                  หน่วยงาน + โครงการ (JSON รวมสถิติ)
                </p>
              </div>
              <Button
                onClick={handleExportAll}
                className="gap-2 bg-blue-600 hover:bg-blue-700"
              >
                <FileDown className="h-4 w-4" />
                ดาวน์โหลด
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Import Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              นำเข้าข้อมูล
            </CardTitle>
            <CardDescription>
              อัพโหลดไฟล์ CSV หรือ JSON เพื่อนำเข้าข้อมูลหน่วยงานและโครงการ
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Organizations Import */}
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium mb-1">นำเข้าข้อมูลหน่วยงาน</h3>
                <p className="text-sm text-gray-600">
                  รองรับไฟล์ .csv และ .json
                </p>
              </div>
              <label>
                <input
                  type="file"
                  accept=".csv,.json"
                  onChange={handleImportOrganizations}
                  disabled={importing}
                  className="hidden"
                />
                <Button
                  variant="outline"
                  size="sm"
                  disabled={importing}
                  className="gap-2 cursor-pointer"
                  onClick={(e) => {
                    (e.currentTarget.previousElementSibling as HTMLInputElement)?.click();
                  }}
                >
                  <Upload className="h-4 w-4" />
                  เลือกไฟล์
                </Button>
              </label>
            </div>

            {/* Projects Import */}
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium mb-1">นำเข้าข้อมูลโครงการ</h3>
                <p className="text-sm text-gray-600">
                  รองรับไฟล์ .csv และ .json
                </p>
              </div>
              <label>
                <input
                  type="file"
                  accept=".csv,.json"
                  onChange={handleImportProjects}
                  disabled={importing}
                  className="hidden"
                />
                <Button
                  variant="outline"
                  size="sm"
                  disabled={importing}
                  className="gap-2 cursor-pointer"
                  onClick={(e) => {
                    (e.currentTarget.previousElementSibling as HTMLInputElement)?.click();
                  }}
                >
                  <Upload className="h-4 w-4" />
                  เลือกไฟล์
                </Button>
              </label>
            </div>

            {/* Import Result */}
            {importResult && (
              <div className={`p-4 border rounded-lg ${
                importResult.errors.length > 0 
                  ? 'bg-yellow-50 border-yellow-200' 
                  : 'bg-green-50 border-green-200'
              }`}>
                <div className="flex items-start gap-3">
                  {importResult.errors.length > 0 ? (
                    <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  ) : (
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <h3 className="font-medium mb-2">
                      ผลการนำเข้าข้อมูล{importResult.type === 'organizations' ? 'หน่วยงาน' : 'โครงการ'}
                    </h3>
                    <div className="space-y-1 text-sm">
                      <p className="text-green-700">
                        ✅ นำเข้าสำเร็จ: {importResult.success} รายการ
                      </p>
                      {importResult.duplicates > 0 && (
                        <p className="text-yellow-700">
                          ⚠️ ข้อมูลซ้ำ: {importResult.duplicates} รายการ
                        </p>
                      )}
                      {importResult.errors.length > 0 && (
                        <div className="mt-2">
                          <p className="font-medium text-yellow-800 mb-1">
                            ข้อผิดพลาด:
                          </p>
                          <ul className="list-disc list-inside text-yellow-700 space-y-0.5">
                            {importResult.errors.slice(0, 5).map((err, i) => (
                              <li key={i}>{err}</li>
                            ))}
                            {importResult.errors.length > 5 && (
                              <li>... และอีก {importResult.errors.length - 5} รายการ</li>
                            )}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => setImportResult(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <XCircle className="h-5 w-5" />
                  </button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Organization Stats Grid */}
        <div>
          <h2 className="text-xl font-semibold mb-4">หน่วยงานทั้งหมด</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {organizations.map(org => (
              <OrganizationStatsCard
                key={org.id}
                organization={org}
                projects={projects}
                tickets={tickets}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
