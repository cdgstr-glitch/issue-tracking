import { useState } from 'react';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { AlertTriangle, UserX, Info } from 'lucide-react';
import { Ticket } from '../types';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { StatusBadge } from './StatusBadge';
import { PriorityBadge } from './PriorityBadge';
import { removeHashtags } from '../lib/hashtagUtils';
import { formatRelativeTime } from '../lib/utils';

interface TakeoverConfirmationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ticket: Ticket;
  currentUserId: string;
  currentUserName: string;
  onConfirm: (reason?: string) => void;
}

export function TakeoverConfirmationModal({ 
  open, 
  onOpenChange, 
  ticket, 
  currentUserId,
  currentUserName,
  onConfirm 
}: TakeoverConfirmationModalProps) {
  const [reason, setReason] = useState('');
  const owner = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;

  const handleConfirm = () => {
    onConfirm(reason.trim() || undefined);
    setReason(''); // Reset
  };

  const handleCancel = () => {
    setReason(''); // Reset
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 shrink-0">
              <AlertTriangle className="h-6 w-6 text-amber-600" />
            </div>
            <div className="flex-1">
              <DialogTitle className="text-xl">⚠️ ยืนยันการรับเคสต่อ (Takeover)</DialogTitle>
              <DialogDescription className="mt-1">
                คุณต้องการรับเคสนี้ต่อจากเจ้าของเดิมหรือไม่?
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {/* Ticket Info */}
          <div className="rounded-lg border bg-gray-50 p-4 space-y-3">
            <div>
              <p className="text-xs text-gray-500 mb-1">📋 รายละเอียดเคส</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-gray-500 mb-1">เลขที่เคส</p>
                <p className="font-medium text-gray-900">{ticket.ticketNumber}</p>
              </div>
              <div className="md:col-span-2">
                <p className="text-xs text-gray-500 mb-1">หัวเรื่อง</p>
                <p className="text-sm text-gray-900 line-clamp-2">{removeHashtags(ticket.title)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 pt-2 border-t">
              <StatusBadge status={ticket.status} size="sm" />
              <PriorityBadge priority={ticket.priority} />
            </div>
          </div>

          {/* Current Owner Info */}
          {owner && (
            <div className="rounded-lg border border-blue-200 bg-blue-50 p-4">
              <p className="text-xs font-medium text-blue-700 mb-2">👤 เจ้าของเดิม</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-blue-600 mb-0.5">ชื่อ</p>
                  <p className="text-sm font-medium text-blue-900">{owner.fullName}</p>
                </div>
                <div>
                  <p className="text-xs text-blue-600 mb-0.5">ตำแหน่ง</p>
                  <p className="text-sm font-medium text-blue-900">
                    {owner.tier ? `Tier ${owner.tier}` : owner.role === 'admin' ? 'Admin' : owner.role}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Reason Input */}
          <div className="space-y-2">
            <Label htmlFor="takeover-reason" className="text-sm font-medium">
              📝 เหตุผลในการ Takeover (ไม่บังคับ)
            </Label>
            <Textarea
              id="takeover-reason"
              placeholder={`เช่น: ${owner?.fullName || 'เจ้าของเดิม'}ลางาน ฉันจะช่วยทำต่อให้`}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              className="resize-none"
            />
            <p className="text-xs text-gray-500">
              เหตุผลนี้จะถูกบันทึกใน Timeline และส่งในอีเมลแจ้งเตือน
            </p>
          </div>

          {/* Info Box */}
          <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 space-y-2">
            <div className="flex items-start gap-2">
              <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
              <div className="flex-1">
                <p className="text-xs font-medium text-blue-900 mb-1">💡 หมายเหตุ</p>
                <p className="text-xs text-blue-800 mb-0">เมื่อคุณ Takeover เคสนี้:</p>
              </div>
            </div>
            <ul className="text-xs text-blue-800 space-y-1 ml-6 mb-0 pl-0">
              <li>• คุณจะกลายเป็นผู้รับผิดชอบใหม่</li>
              <li>• {owner?.fullName || 'เจ้าของเดิม'} จะได้รับอีเมลแจ้งเตือน</li>
              <li>• เคสจะย้ายไปอยู่ใน "งานของฉัน" ของคุณ</li>
              <li>• Timeline จะบันทึกการ Takeover</li>
            </ul>
          </div>

          {/* Warning Box */}
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
              <div className="flex-1">
                <p className="text-xs font-medium text-amber-900 mb-1">⚠️ คำเตือน</p>
                <p className="text-xs text-amber-800 mb-0">
                  การ Takeover ไม่สามารถยกเลิกได้โดยอัตโนมัติ 
                  หากต้องการคืนเคสให้เจ้าของเดิม ต้องใช้ฟีเจอร์ "ส่งต่อ" เพื่อมอบหมายกลับ
                </p>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-3 sm:gap-3">
          <Button 
            variant="outline" 
            onClick={handleCancel}
            className="sm:w-auto"
          >
            ยกเลิก
          </Button>
          <Button 
            onClick={handleConfirm}
            className="bg-amber-600 hover:bg-amber-700 sm:w-auto"
          >
            <UserX className="mr-2 h-4 w-4" />
            Takeover เคสนี้
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
