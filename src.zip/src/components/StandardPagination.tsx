import { Button } from './ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface StandardPaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function StandardPagination({ 
  currentPage, 
  totalPages, 
  onPageChange 
}: StandardPaginationProps) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
      >
        <ChevronLeft className="h-4 w-4" />
        ก่อนหน้า
      </Button>

      <div className="flex items-center gap-1">
        {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => {
          // Show first page, last page, current page, and pages around current
          const showPage = 
            page === 1 || 
            page === totalPages || 
            Math.abs(page - currentPage) <= 1;

          if (!showPage && page === 2) {
            return <span key={page} className="px-2 text-gray-400">...</span>;
          }

          if (!showPage && page === totalPages - 1) {
            return <span key={page} className="px-2 text-gray-400">...</span>;
          }

          if (!showPage) return null;

          return (
            <Button
              key={page}
              variant={currentPage === page ? "default" : "outline"}
              size="sm"
              onClick={() => onPageChange(page)}
              className="min-w-[40px]"
            >
              {page}
            </Button>
          );
        })}
      </div>

      <Button
        variant="outline"
        size="sm"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
      >
        ถัดไป
        <ChevronRight className="h-4 w-4" />
      </Button>
    </div>
  );
}
