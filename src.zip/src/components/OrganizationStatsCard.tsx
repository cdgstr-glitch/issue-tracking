/**
 * 📊 Organization Stats Card Component
 * 
 * @description แสดงสถิติของ Organization แบบสรุป
 * @version 1.0 - Phase 4
 */

import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Building2, FolderOpen, Ticket, CheckCircle } from 'lucide-react';
import { Organization, Project, Ticket as TicketType } from '../types';
import { getProjectsByOrganization } from '../lib/utils/projectUtils';

interface OrganizationStatsCardProps {
  organization: Organization;
  projects: Project[];
  tickets: TicketType[];
}

export function OrganizationStatsCard({
  organization,
  projects,
  tickets
}: OrganizationStatsCardProps) {
  // นับโครงการ
  const orgProjects = getProjectsByOrganization(organization.id, projects);
  const activeProjects = orgProjects.filter(p => p.projectStatus === 'active');
  
  // หา projectIds ของ organization นี้
  const projectIds = orgProjects.map(p => p.id);
  
  // นับเคสที่เกี่ยวข้องกับโครงการในองค์กรนี้
  const orgTickets = tickets.filter(t => projectIds.includes(t.projectId || ''));
  const openTickets = orgTickets.filter(t => 
    !['closed', 'resolved'].includes(t.status)
  );
  const closedTickets = orgTickets.filter(t => t.status === 'closed');

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="h-5 w-5 text-blue-600" />
              <Badge variant="outline" className="text-xs">
                {organization.organizationShortName}
              </Badge>
            </div>
            <CardTitle className="text-base">
              {organization.organizationName}
            </CardTitle>
            {organization.department && (
              <p className="text-xs text-gray-500 mt-1">
                {organization.department}
              </p>
            )}
          </div>
          <Badge 
            variant="outline" 
            className="text-xs bg-blue-50 text-blue-700 border-blue-200"
          >
            {organization.organizationType === 'university' && 'มหาวิทยาลัย'}
            {organization.organizationType === 'government' && 'ท้องถิ่น'}
            {organization.organizationType === 'enterprise' && 'รัฐวิสาหกิจ'}
            {organization.organizationType === 'public_sector' && 'ภาครัฐ'}
            {organization.organizationType === 'private_sector' && 'เอกชน'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4">
          {/* โครงการ */}
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <FolderOpen className="h-4 w-4 text-orange-600" />
            </div>
            <p className="text-2xl font-bold text-orange-600">
              {activeProjects.length}
            </p>
            <p className="text-xs text-gray-600">โครงการ</p>
          </div>

          {/* เคสทั้งหมด */}
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Ticket className="h-4 w-4 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">
              {openTickets.length}
            </p>
            <p className="text-xs text-gray-600">เคสเปิด</p>
          </div>

          {/* เคสปิด */}
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <CheckCircle className="h-4 w-4 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">
              {closedTickets.length}
            </p>
            <p className="text-xs text-gray-600">เคสปิด</p>
          </div>
        </div>

        {/* Contact */}
        {organization.contactPerson && (
          <div className="mt-4 pt-4 border-t">
            <p className="text-xs text-gray-600">
              👤 {organization.contactPerson}
            </p>
            {organization.contactEmail && (
              <p className="text-xs text-gray-500 mt-0.5">
                ✉️ {organization.contactEmail}
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
