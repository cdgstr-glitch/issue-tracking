import { Eye } from 'lucide-react';
import { getRoleDisplayName } from '../lib/utils';
import { UserRole } from '../types';

interface ViewerBadgeProps {
  viewerName: string;
  viewerRole?: string;
  size?: 'sm' | 'md';
}

export function ViewerBadge({ viewerName, viewerRole, size = 'sm' }: ViewerBadgeProps) {
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm'
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-3.5 w-3.5'
  };

  // ✅ แปลง role เป็นภาษาไทย
  const roleDisplayName = viewerRole ? getRoleDisplayName(viewerRole as UserRole) : '';

  return (
    <span 
      className={`inline-flex items-center gap-1 rounded-full bg-purple-100 text-purple-700 ${sizeClasses[size]}`}
      title={`${viewerName}${roleDisplayName ? ` (${roleDisplayName})` : ''} กำลังดูเคสนี้อยู่`}
    >
      <Eye className={iconSizes[size]} />
      <span className="font-medium">{viewerName}</span>
      {roleDisplayName && (
        <span className="text-purple-600/80">({roleDisplayName})</span>
      )}
    </span>
  );
}