import React, { useState, useEffect } from 'react'

const ERROR_IMG_SRC =
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODgiIGhlaWdodD0iODgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBvcGFjaXR5PSIuMyIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIzLjciPjxyZWN0IHg9IjE2IiB5PSIxNiIgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iNiIvPjxwYXRoIGQ9Im0xNiA1OCAxNi0xOCAzMiAzMiIvPjxjaXJjbGUgY3g9IjUzIiBjeT0iMzUiIHI9IjciLz48L3N2Zz4KCg=='

// Cache สำหรับเก็บ thumbnails ที่สร้างแล้ว
const thumbnailCache = new Map<string, string>()

/**
 * ลดขนาดรูปภาพและแปลงเป็น Data URL
 * @param blobUrl - Blob URL ต้นฉบับ
 * @param maxWidth - ความกว้างสูงสุด (default: 800px)
 * @param quality - คุณภาพภาพ 0-1 (default: 0.8)
 */
async function createThumbnail(
  blobUrl: string,
  maxWidth: number = 800,
  quality: number = 0.8
): Promise<string> {
  // เช็ค cache ก่อน
  const cacheKey = `${blobUrl}_${maxWidth}_${quality}`
  if (thumbnailCache.has(cacheKey)) {
    return thumbnailCache.get(cacheKey)!
  }

  try {
    // 1. Fetch blob
    const response = await fetch(blobUrl)
    const blob = await response.blob()
    
    // 2. สร้าง object URL ชั่วคราว
    const objectUrl = URL.createObjectURL(blob)
    
    // 3. โหลดรูปเข้า Image element
    const img = new Image()
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve()
      img.onerror = reject
      img.src = objectUrl
    })
    
    // 4. คำนวณขนาดใหม่ (รักษาอัตราส่วน)
    let width = img.width
    let height = img.height
    
    if (width > maxWidth) {
      height = (height * maxWidth) / width
      width = maxWidth
    }
    
    // 5. สร้าง Canvas และวาดรูปที่ลดขนาดแล้ว
    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('Cannot get canvas context')
    
    // เพิ่มคุณภาพการ resize
    ctx.imageSmoothingEnabled = true
    ctx.imageSmoothingQuality = 'high'
    
    ctx.drawImage(img, 0, 0, width, height)
    
    // 6. แปลงเป็น data URL
    const dataUrl = canvas.toDataURL('image/jpeg', quality)
    
    // 7. ทำความสะอาด
    URL.revokeObjectURL(objectUrl)
    
    // 8. เก็บใน cache
    thumbnailCache.set(cacheKey, dataUrl)
    
    console.log(`✅ Thumbnail created: ${width}x${height}, original: ${img.width}x${img.height}`)
    
    return dataUrl
  } catch (error) {
    console.error('❌ Failed to create thumbnail:', blobUrl, error)
    throw error
  }
}

export function ImageWithFallback(props: React.ImgHTMLAttributes<HTMLImageElement>) {
  const [didError, setDidError] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [resolvedSrc, setResolvedSrc] = useState<string | undefined>(props.src)

  useEffect(() => {
    let isMounted = true
    
    // Reset states
    setDidError(false)
    setIsLoading(true)
    
    const loadImage = async () => {
      if (!props.src) {
        setDidError(true)
        setIsLoading(false)
        return
      }

      try {
        // ถ้าเป็น blob URL ให้สร้าง thumbnail ก่อน
        if (props.src.startsWith('blob:')) {
          const thumbnail = await createThumbnail(props.src, 800, 0.7)
          if (isMounted) {
            setResolvedSrc(thumbnail)
          }
        } else {
          setResolvedSrc(props.src)
        }
      } catch (error) {
        console.error('❌ Image load error:', props.src, error)
        if (isMounted) {
          setDidError(true)
          setIsLoading(false)
        }
      }
    }

    loadImage()

    return () => {
      isMounted = false
    }
  }, [props.src])

  const handleError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    console.error('❌ Image render error:', resolvedSrc, e)
    setDidError(true)
    setIsLoading(false)
  }

  const handleLoad = () => {
    console.log('✅ Image loaded successfully')
    setIsLoading(false)
  }

  const { src, alt, style, className, ...rest } = props

  return (
    <div className="relative w-full h-full">
      {/* Loading Skeleton */}
      {isLoading && !didError && (
        <div
          className={`absolute inset-0 bg-gradient-to-br from-gray-200 to-gray-300 animate-pulse ${className ?? ''}`}
          style={style}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-gray-400 border-t-transparent rounded-full animate-spin" />
          </div>
        </div>
      )}
      
      {/* Error State */}
      {didError ? (
        <div
          className={`flex items-center justify-center bg-gray-100 border-2 border-dashed border-gray-300 ${className ?? ''}`}
          style={style}
        >
          <div className="text-center p-4">
            <img src={ERROR_IMG_SRC} alt="Error loading image" className="mx-auto mb-2 opacity-50" style={{ width: '48px', height: '48px' }} />
            <p className="text-xs text-gray-400 font-medium">ไม่สามารถโหลดรูปภาพ</p>
          </div>
        </div>
      ) : (
        /* Image */
        <img
          src={resolvedSrc}
          alt={alt}
          className={className ?? ''}
          style={style}
          {...rest}
          onError={handleError}
          onLoad={handleLoad}
        />
      )}
    </div>
  )
}