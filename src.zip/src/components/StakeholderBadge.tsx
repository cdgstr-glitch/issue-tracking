import { Ticket } from '../types';
import { getUserRole, getRoleDescription, getStakeholderStatusMessage } from '../lib/stakeholderUtils';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { ArrowUpRight, User, UserPlus } from 'lucide-react';

interface StakeholderBadgeProps {
  ticket: Ticket;
  userId: string;
  size?: 'sm' | 'md';
}

export function StakeholderBadge({ ticket, userId, size = 'sm' }: StakeholderBadgeProps) {
  const role = getUserRole(ticket, userId);
  
  // ไม่แสดง badge ถ้าเป็น current owner
  if (role === 'owner' || role === 'none') {
    return null;
  }
  
  const roleDescription = getRoleDescription(ticket, userId);
  
  // สำหรับ escalator (ผู้ส่งต่อ)
  if (role === 'escalator') {
    // หาว่าส่งต่อไป tier ไหน
    const lastEscalation = ticket.escalationChain?.[ticket.escalationChain.length - 1];
    const toTier = lastEscalation?.toTier.replace('tier', 'Tier') || 'Tier';
    
    return (
      <div className={`inline-flex items-center gap-1.5 rounded-md border ${
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm'
      } bg-indigo-50 text-indigo-700 border-indigo-200 whitespace-nowrap`}>
        <ArrowUpRight className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} />
        <span>ส่งต่อไป {toTier}</span>
      </div>
    );
  }
  
  // สำหรับ creator (ผู้เปิดเคส)
  if (role === 'creator') {
    return (
      <div className={`inline-flex items-center gap-1.5 rounded-md border ${
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm'
      } bg-blue-50 text-blue-700 border-blue-200 whitespace-nowrap`}>
        <UserPlus className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} />
        <span>ผู้เปิดเคส</span>
      </div>
    );
  }
  
  // สำหรับ stakeholder อื่น ๆ
  return (
    <div className={`inline-flex items-center gap-1.5 rounded-md border ${
      size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm'
    } bg-gray-50 text-gray-700 border-gray-200 whitespace-nowrap`}>
      <User className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} />
      <span>{roleDescription}</span>
    </div>
  );
}

/**
 * Component สำหรับแสดงรายละเอียด stakeholder แบบเต็ม
 */
interface StakeholderDetailBadgeProps {
  ticket: Ticket;
  userId: string;
}

export function StakeholderDetailBadge({ ticket, userId }: StakeholderDetailBadgeProps) {
  const role = getUserRole(ticket, userId);
  
  if (role === 'owner' || role === 'none') {
    return null;
  }
  
  const statusMessage = getStakeholderStatusMessage(ticket, userId);
  
  // หาข้อมูล assignee ปัจจุบัน
  const currentAssignee = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;
  const assigneeName = currentAssignee?.fullName || 'ไม่ระบุ';
  const assigneeTier = currentAssignee?.role === 'tier1' ? 'Tier1' : 
                        currentAssignee?.role === 'tier2' ? 'Tier2' : 
                        currentAssignee?.role === 'tier3' ? 'Tier3' : 
                        currentAssignee?.role?.toUpperCase();
  
  return (
    <div className="rounded-lg border border-indigo-200 bg-indigo-50 p-3">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-600 text-white shrink-0">
          <ArrowUpRight className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <p className="text-sm text-indigo-900 mb-1">💼 บทบาทของคุณในเคสนี้</p>
          <p className="text-indigo-900">{statusMessage}</p>
          <div className="mt-2 pt-2 border-t border-indigo-200">
            <p className="text-xs text-indigo-700">
              👤 ผู้รับผิดชอบปัจจุบัน: <strong>{assigneeTier} - {assigneeName}</strong>
            </p>
            {ticket.escalationChain && ticket.escalationChain.length > 0 && (
              <p className="text-xs text-indigo-700 mt-1">
                📅 ส่งต่อเมื่อ: {new Date(ticket.escalationChain[ticket.escalationChain.length - 1].escalatedAt).toLocaleString('th-TH', {
                  dateStyle: 'medium',
                  timeStyle: 'short'
                })}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
