import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { ExternalLink, Mail, Shield, Clock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext'; // 🆕 Import useAuth

/**
 * 📧 Email Preview Component
 * 
 * แสดงตัวอย่างอีเมล Magic Link ที่ส่งให้ลูกค้า
 * - UI สวยงาม เหมือนอีเมลจริง
 * - มีปุ่มคลิกไปหน้าแจ้งเคสได้เลย
 * - รองรับการส่งข้อมูลลูกค้า (name, email) ไปด้วย
 * 
 * 🔧 TODO: เปิดใช้งาน Magic Link Verification ตอนเชื่อม API Laravel จริงๆ
 */

interface EmailPreviewProps {
  customerName: string;
  customerEmail: string;
  magicLinkURL: string;
  trigger?: React.ReactNode;
  onNavigate?: (path: string, ticketId?: string, sourcePath?: string, magicToken?: string) => void;
  mode?: 'register' | 'login'; // 🆕 เพิ่ม mode เพื่อกำหนด destination
}

export function EmailPreview({ 
  customerName, 
  customerEmail, 
  magicLinkURL,
  trigger,
  onNavigate,
  mode = 'register' // 🆕 Default เป็น register
}: EmailPreviewProps) {
  const [open, setOpen] = useState(false);
  const { loginWithMagicLink } = useAuth(); // 🆕 ดึง loginWithMagicLink

  const handleNavigate = async () => {
    console.log('🎯 [EmailPreview] handleNavigate called');
    console.log('📧 Customer:', customerName, customerEmail);
    console.log('🔗 Magic Link URL:', magicLinkURL);
    console.log('📍 Mode:', mode);
    
    // 🔧 [DEMO MODE] Auto-login ลูกค้าโดยไม่ต้อง verify token
    // TODO: ตอนเชื่อม API Laravel จริงๆ ให้ใช้ magic token แทน
    console.log('🔓 [DEMO] Auto-logging in customer:', customerEmail);
    
    try {
      // Extract token from URL for future use
      const url = new URL(magicLinkURL);
      const token = url.searchParams.get('token');
      console.log('🎫 Extracted token:', token);
      
      // Auto-login using mock magic link
      const loginSuccess = await loginWithMagicLink(token || '');
      
      if (loginSuccess) {
        console.log('✅ Auto-login successful!');
        
        // Close dialog first
        console.log('🚪 Closing dialog...');
        setOpen(false);
        
        // Navigate based on mode
        setTimeout(() => {
          if (onNavigate) {
            if (mode === 'register') {
              // ลงทะเบียนใหม่ → ไปหน้าแจ้งเคส
              console.log('🚀 [EmailPreview] Register mode: Navigating to /create');
              onNavigate('/create');
            } else {
              // ขอลิงค์เข้าระบบ → ไปหน้าติดตามเคส
              console.log('🚀 [EmailPreview] Login mode: Navigating to /track');
              onNavigate('/track');
            }
          }
          console.log('✅ Navigation command executed');
        }, 200);
      } else {
        console.error('❌ Auto-login failed');
        alert('เกิดข้อผิดพลาดในการเข้าสู่ระบบ กรุณาลองใหม่อีกครั้ง');
      }
    } catch (error) {
      console.error('❌ Error during auto-login:', error);
      alert('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="w-full">
            <ExternalLink className="w-4 h-4 mr-2" />
            ดูตัวอย่างอีเมล
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto p-0">
        <DialogHeader className="px-6 pt-6 pb-0">
          <DialogTitle>ตัวอย่างอีเมลที่ส่งให้ลูกค้า</DialogTitle>
          <DialogDescription>
            นี่คือตัวอย่างอีเมลที่ส่งไปยังลูกค้าเพื่อให้เข้าสู่ระบบ Application Support Center
          </DialogDescription>
        </DialogHeader>
        
        {/* Email Preview */}
        <div className="px-6 pb-6">
          <div className="bg-gray-100 border border-gray-300 rounded-lg p-1 mt-4">
            {/* Email Header */}
            <div className="bg-white border-b border-gray-200 px-4 py-3 rounded-t-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs text-gray-600">จาก:</div>
                <div className="text-xs text-gray-500">วันนี้ 12:34 น.</div>
              </div>
              <div className="text-sm font-medium mb-1">
                Application Support Center &lt;noreply@cdgs.co.th&gt;
              </div>
              <div className="text-xs text-gray-600 mb-1">
                ถึง: {customerEmail}
              </div>
              <div className="text-sm font-medium text-gray-900 mt-2">
                🔐 ลิงก์เข้าสู่ระบบของคุณพร้อมแล้ว
              </div>
            </div>

            {/* Email Body */}
            <div className="bg-white px-6 py-8 rounded-b-lg">
              {/* Greeting */}
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                สวัสดีคุณ {customerName}
              </h2>

              {mode === 'register' ? (
                // ✅ สำหรับลูกค้าที่ลงทะเบียนใหม่
                <>
                  <p className="text-gray-700 mb-4 leading-relaxed">
                    ยินดีต้อนรับสู่ <strong>Application Support Center</strong>
                  </p>

                  <p className="text-gray-700 mb-6 leading-relaxed">
                    คลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบและเริ่มแจ้งปัญหาหรือติดตามสถานะเคสของคุณ
                  </p>
                </>
              ) : (
                // ✅ สำหรับลูกค้าที่ขอ Magic Link เพื่อ Login
                <>
                  <p className="text-gray-700 mb-4 leading-relaxed">
                    คุณได้ขอลิงก์เข้าสู่ระบบ <strong>Application Support Center</strong>
                  </p>

                  <p className="text-gray-700 mb-6 leading-relaxed">
                    คลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบและติดตามสถานะเคสของคุณ
                  </p>
                </>
              )}

              {/* CTA Button */}
              <div className="text-center my-8">
                <Button
                  onClick={handleNavigate}
                  className="bg-gradient-to-r from-blue-600 to-purple-700 hover:from-blue-700 hover:to-purple-800 text-white px-8 py-6 text-lg rounded-lg shadow-lg hover:shadow-xl transition-all"
                >
                  {mode === 'register' ? '🚀 เข้าสู่ระบบและแจ้งเคส' : '🔐 เข้าสู่ระบบ'}
                </Button>
              </div>

              {/* Alternative Link */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
                <p className="text-xs text-gray-600 mb-2">
                  หรือคัดลอกลิงก์นี้ไปวางในเบราว์เซอร์:
                </p>
                <div className="text-xs text-blue-600 break-all font-mono bg-white border border-gray-200 rounded px-3 py-2">
                  {magicLinkURL}
                </div>
              </div>

              {/* Info Box */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-yellow-800">
                  <strong>⏰ หมายเหตุ:</strong> ลิงก์นี้จะหมดอายุใน 30 นาที เพื่อความปลอดภัยของคุณ
                </p>
              </div>

              {/* Divider */}
              <div className="border-t border-gray-200 my-6"></div>

              {/* Footer Info */}
              <div className="text-sm text-gray-600 space-y-2">
                <p>
                  <strong>ความสามารถของระบบ:</strong>
                </p>
                <ul className="list-disc list-inside space-y-1 ml-2 text-sm">
                  <li>แจ้งปัญหาระบบงานได้ทุกโครงการ</li>
                  <li>ติดตามสถานะเคสแบบเรียลไทม์</li>
                  <li>ดูประวัติการแจ้งเคสทั้งหมด</li>
                  <li>ทีมงานพร้อมช่วยเหลือตลอด 24/7</li>
                </ul>
              </div>

              {/* Footer */}
              <div className="border-t border-gray-200 mt-8 pt-6 text-center">
                <p className="text-xs text-gray-500 mb-2">
                  อีเมลนี้ส่งถึงคุณเนื่องจากคุณได้ลงทะเบียนในระบบ Application Support Center
                </p>
                <p className="text-xs text-gray-500 mb-2">
                  หากคุณไม่ได้ทำการลงทะเบียน กรุณาเพิกเฉยอีเมลนี้
                </p>
                <p className="text-xs text-gray-400 mt-4">
                  © 2025 CDGS. All rights reserved.
                </p>
                <p className="text-xs text-gray-400">
                  Application Support Center
                </p>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>💡 สำหรับการทดสอบ:</strong> คลิกปุ่ม "เข้าสู่ระบบและแจ้งเคส" ในตัวอย่างนี้
              จะพาคุณไปยังหน้าแจ้งเคสโดยตรง พร้อมกรอกข้อมูลของคุณไว้แล้ว
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}