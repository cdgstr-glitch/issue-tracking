/**
 * Magic Link Verification Component
 * 
 * หน้าสำหรับ verify Magic Link token
 * - รับ token จาก URL query parameter
 * - ตรวจสอบความถูกต้อง
 * - Login อัตโนมัติถ้า token ถูกต้อง
 */

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { CheckCircle, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import { validateMagicLinkToken } from '../../lib/magicLink';
import { useAuth } from '../../contexts/AuthContext';

interface MagicLinkVerificationProps {
  token: string;
  onSuccess: () => void;
  onError: () => void;
}

type VerificationState = 'verifying' | 'success' | 'error';

export function MagicLinkVerification({ token, onSuccess, onError }: MagicLinkVerificationProps) {
  const [state, setState] = useState<VerificationState>('verifying');
  const [errorMessage, setErrorMessage] = useState('');
  const { loginWithMagicLink } = useAuth();

  useEffect(() => {
    const verifyToken = async () => {
      console.log('🔐 [MagicLinkVerification] Starting verification...');
      console.log('🎫 Token:', token);
      
      // Simulate verification delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      console.log('🔍 Validating token...');
      // Verify token
      const result = validateMagicLinkToken(token);
      console.log('📊 Validation result:', result);

      if (result.isValid && result.userId) {
        console.log('✅ Token valid! User ID:', result.userId);
        console.log('📧 Email:', result.email);
        
        // Login with magic link
        console.log('🔑 Attempting login with magic link...');
        const loginSuccess = await loginWithMagicLink(token);
        console.log('🔑 Login result:', loginSuccess);

        if (loginSuccess) {
          console.log('✅ Login successful!');
          setState('success');
          // Redirect after 2 seconds
          setTimeout(() => {
            console.log('🚀 Redirecting to home...');
            onSuccess();
          }, 2000);
        } else {
          console.error('❌ Login failed');
          setState('error');
          setErrorMessage('เกิดข้อผิดพลาดในการเข้าสู่ระบบ');
        }
      } else {
        console.error('❌ Token invalid:', result.error);
        setState('error');
        setErrorMessage(result.error || 'ลิงก์ไม่ถูกต้อง');
      }
    };

    verifyToken();
  }, [token, loginWithMagicLink, onSuccess]);

  // Verifying state
  if (state === 'verifying') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full shadow-lg">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
            </div>
            <CardTitle className="text-2xl">กำลังตรวจสอบ...</CardTitle>
            <CardDescription className="text-base">
              กรุณารอสักครู่ ระบบกำลังยืนยันตัวตนของคุณ
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-gray-600 text-center">
              <p>⏳ กำลังตรวจสอบลิงก์</p>
              <p>🔐 กำลังยืนยันตัวตน</p>
              <p>🚀 เตรียมพาคุณเข้าสู่ระบบ</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Success state
  if (state === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full border-2 border-green-200 shadow-lg">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-green-900">ยืนยันสำเร็จ!</CardTitle>
            <CardDescription className="text-base">
              ระบบกำลังพาคุณเข้าสู่หน้าหลัก...
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                เข้าสู่ระบบสำเร็จ! กำลังโหลดข้อมูลของคุณ
              </AlertDescription>
            </Alert>
            
            <div className="mt-6 text-center">
              <Loader2 className="w-8 h-8 text-green-600 animate-spin mx-auto" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Error state
  if (state === 'error') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full border-2 border-red-200 shadow-lg">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-10 h-10 text-red-600" />
            </div>
            <CardTitle className="text-2xl text-red-900">เกิดข้อผิดพลาด</CardTitle>
            <CardDescription className="text-base">
              ไม่สามารถยืนยันตัวตนได้
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{errorMessage}</AlertDescription>
            </Alert>

            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm text-gray-700">
              <p className="font-medium mb-2">เหตุผลที่อาจเกิดข้อผิดพลาด:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>ลิงก์หมดอายุแล้ว (หมดอายุใน 30 นาที)</li>
                <li>ลิงก์ถูกใช้งานไปแล้ว</li>
                <li>ลิงก์ไม่ถูกต้อง</li>
              </ul>
            </div>

            <Button
              className="w-full"
              onClick={onError}
            >
              <ArrowRight className="w-4 h-4 mr-2" />
              ขอลิงก์ใหม่
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}