/**
 * 🏢 Organization Selector Component
 * 
 * @description Component สำหรับเลือกหน่วยงาน/องค์กร (Step 1 ของ Project Selector)
 * @version 2.0 - Phase 2 (Removed Pagination, Inline Short Name + Full Name)
 */

import { useState, useMemo } from 'react';
import { Organization } from '../types';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Building2, FolderOpen } from 'lucide-react';
import { searchOrganizations, sortOrganizationsByShortName } from '../lib/utils/organizationUtils';
import { countProjectsByOrganization } from '../lib/utils/projectUtils';
import { Project } from '../types';

interface OrganizationSelectorProps {
  organizations: Organization[];
  projects: Project[];
  selectedOrganizationId?: string;
  onSelectOrganization: (organizationId: string) => void;
}

export function OrganizationSelector({
  organizations,
  projects,
  selectedOrganizationId,
  onSelectOrganization
}: OrganizationSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');

  // ค้นหาและเรียงลำดับ
  const filteredOrganizations = useMemo(() => {
    const searched = searchOrganizations(searchTerm, organizations);
    return sortOrganizationsByShortName(searched, 'asc');
  }, [searchTerm, organizations]);

  // นับจำนวนโครงการของแต่ละ organization
  const getProjectCount = (orgId: string) => {
    return countProjectsByOrganization(orgId, projects);
  };

  return (
    <div className="flex flex-col" style={{ maxHeight: 'calc(90vh - 300px)' }}>
      {/* Search - ไม่ scroll */}
      <div className="flex-shrink-0 mb-4">
        <div className="text-sm text-gray-600 mb-2">
          เลือกหน่วยงานที่ต้องการบันทึกเคส ({filteredOrganizations.length} รายการ)
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="ค้นหาชื่อหน่วยงาน, ชื่อย่อ, หรือรหัส..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {/* Organization List - scroll ได้ */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-2" style={{ minHeight: '200px', maxHeight: '500px' }}>
        {filteredOrganizations.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Building2 className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p>ไม่พบหน่วยงานที่ค้นหา</p>
            <p className="text-sm mt-1">ลองค้นหาด้วยคำอื่น</p>
          </div>
        ) : (
          filteredOrganizations.map((org) => {
            const projectCount = getProjectCount(org.id);
            const isSelected = selectedOrganizationId === org.id;

            return (
              <button
                key={org.id}
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  console.log('🔍 [OrganizationSelector] Selected org:', org.id, org.organizationName);
                  onSelectOrganization(org.id);
                }}
                className={`
                  w-full text-left p-4 rounded-lg border-2 transition-all
                  hover:border-blue-300 hover:bg-blue-50
                  ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50 shadow-md'
                      : 'border-gray-200 bg-white'
                  }
                `}
              >
                {/* Organization Name: Short Name - Full Name (Single Line) */}
                <div className="flex items-center gap-2 mb-2">
                  <h4 className={`text-sm font-semibold ${
                    isSelected ? 'text-blue-900' : 'text-gray-900'
                  }`}>
                    {org.organizationShortName} - {org.organizationName}
                  </h4>
                </div>

                {/* Project Count */}
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <FolderOpen className="h-3.5 w-3.5" />
                  <span>
                    {projectCount === 0 && 'ไม่มีโครงการ'}
                    {projectCount === 1 && '1 โครงการ'}
                    {projectCount > 1 && `${projectCount} โครงการ`}
                  </span>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}