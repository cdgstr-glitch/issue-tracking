import { Ticket } from '../types';
import { getAssigneeDisplayName } from '../lib/ticketUtils';
import { Badge } from './ui/badge';
import { formatDistanceToNow } from 'date-fns';
import { th } from 'date-fns/locale';
import { getPriorityColor, getStatusColor, getStatusLabel, getPriorityLabel } from '../lib/utils';
import { Clock, User, Paperclip, Eye } from 'lucide-react';
import { constants } from '../lib/mockDb/data/constants';

interface TicketTableProps {
  tickets: Ticket[];
  onNavigate: (path: string, ticketId?: string, sourcePath?: string) => void;
  sourcePath?: string;
}

export function TicketTable({ tickets, onNavigate, sourcePath }: TicketTableProps) {
  // Config from constants (prepared for Admin setting)
  const badgeMode = constants.UI_CONFIG.TICKET_TABLE_BADGE_MODE; // 'view' | 'assignee'

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b bg-gray-50">
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 w-[100px]">รหัสเคส</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 min-w-[300px]">หัวเรื่อง</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 w-[140px]">สถานะ</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 w-[120px]">ระดับความสำคัญ</th>
            <th className="px-4 py-3 text-center text-sm font-medium text-gray-700 w-[80px]">
              <div className="flex items-center justify-center gap-1">
                <Paperclip className="h-4 w-4" />
                <span>ไฟล์</span>
              </div>
            </th>
            {/* Assignee Column Removed as requested */}
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 w-[150px]">อัปเดตล่าสุด</th>
          </tr>
        </thead>
        <tbody>
          {tickets.map((ticket) => (
            <tr
              key={ticket.id}
              onClick={() => onNavigate('/admin/ticket', ticket.id, sourcePath)}
              className="cursor-pointer border-b hover:bg-gray-50 transition-colors"
            >
              <td className="px-4 py-3 align-top">
                <span className="font-mono text-sm text-blue-600">{ticket.id}</span>
              </td>
              <td className="px-4 py-3 align-top">
                <div className="max-w-md">
                  {/* Title & Badge Row */}
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="font-medium text-sm line-clamp-2 text-gray-900">{ticket.title}</p>
                    
                    {/* Badge Area (Configurable) */}
                    <div className="shrink-0">
                      {badgeMode === 'view' ? (
                        <Badge variant="outline" className="text-[10px] px-1.5 h-5 gap-1 font-normal text-gray-500 hover:text-gray-700 bg-white">
                          <Eye className="h-3 w-3" />
                          View
                        </Badge>
                      ) : (
                        // Assignee Badge
                        <div 
                          className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-gray-100 border border-gray-200 max-w-[140px]"
                          title={`ผู้รับผิดชอบ: ${getAssigneeDisplayName(ticket)}`}
                        >
                          <User className="h-3 w-3 text-gray-500 shrink-0" />
                          <span className="text-xs text-gray-700 font-medium truncate">
                            {getAssigneeDisplayName(ticket)}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Description */}
                  <p className="text-xs text-gray-500 line-clamp-1">{ticket.description}</p>
                </div>
              </td>
              <td className="px-4 py-3 align-top">
                <Badge className={getStatusColor(ticket.status)}>
                  {getStatusLabel(ticket.status)}
                </Badge>
              </td>
              <td className="px-4 py-3 align-top">
                <Badge className={getPriorityColor(ticket.priority)}>
                  {getPriorityLabel(ticket.priority)}
                </Badge>
              </td>
              <td className="px-4 py-3 align-top text-center">
                {ticket.attachments && ticket.attachments.length > 0 ? (
                  <div className="inline-flex items-center gap-1.5 px-2 py-1 bg-gray-100 rounded-md text-xs font-medium text-gray-700">
                    <Paperclip className="h-3.5 w-3.5" />
                    <span>{ticket.attachments.length}</span>
                  </div>
                ) : (
                  <span className="text-xs text-gray-400">-</span>
                )}
              </td>
              {/* Assignee Column Data Removed */}
              <td className="px-4 py-3 align-top">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4" />
                  {formatDistanceToNow(new Date(ticket.updatedAt), {
                    addSuffix: true,
                    locale: th
                  })}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {tickets.length === 0 && (
        <div className="py-12 text-center text-gray-500">
          <p>ไม่มีข้อมูล</p>
        </div>
      )}
    </div>
  );
}
