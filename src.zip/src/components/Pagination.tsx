import { Button } from './ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  totalItems: number;
  itemsPerPage: number;
}

export function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  totalItems,
  itemsPerPage
}: PaginationProps) {
  // ===== SANITIZE (กัน NaN/undefined/0) =====
  const safeTotalItems = Number.isFinite(totalItems) && totalItems > 0 ? totalItems : 0;
  const safeItemsPerPage = Number.isFinite(itemsPerPage) && itemsPerPage > 0 ? itemsPerPage : 10;

  const safeTotalPages =
    Number.isFinite(totalPages) && totalPages > 0
      ? totalPages
      : safeTotalItems === 0
        ? 0
        : Math.max(1, Math.ceil(safeTotalItems / safeItemsPerPage));

  const safeCurrentPageRaw = Number.isFinite(currentPage) && currentPage > 0 ? currentPage : 1;

  // clamp currentPage ไม่ให้เกิน totalPages
  const safeCurrentPage =
    safeTotalPages === 0 ? 1 : Math.min(safeCurrentPageRaw, safeTotalPages);

  // ===== DISPLAY RANGE =====
  const startItem =
    safeTotalItems === 0 ? 0 : (safeCurrentPage - 1) * safeItemsPerPage + 1;

  const endItem =
    safeTotalItems === 0 ? 0 : Math.min(safeCurrentPage * safeItemsPerPage, safeTotalItems);

  // จำกัดจำนวนหมายเลขหน้าที่แสดง
  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisible = 5;

    if (safeTotalPages <= maxVisible) {
      for (let i = 1; i <= safeTotalPages; i++) pages.push(i);
    } else {
      pages.push(1);

      if (safeCurrentPage > 3) pages.push('...');

      const start = Math.max(2, safeCurrentPage - 1);
      const end = Math.min(safeTotalPages - 1, safeCurrentPage + 1);

      for (let i = start; i <= end; i++) pages.push(i);

      if (safeCurrentPage < safeTotalPages - 2) pages.push('...');

      pages.push(safeTotalPages);
    }

    return pages;
  };

  return (
    <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 border-t pt-4">
      {/* แสดงจำนวนรายการ */}
      <div className="text-sm text-gray-600">
        แสดง {startItem}-{endItem} จาก {safeTotalItems} เคส
      </div>

      {/* ปุ่ม Pagination */}
      <div className="flex items-center gap-2">
        {/* ปุ่มย้อนกลับ */}
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(safeCurrentPage - 1)}
          disabled={safeCurrentPage === 1 || safeTotalPages === 0}
          className="gap-1"
        >
          <ChevronLeft className="h-4 w-4" />
          ย้อนกลับ
        </Button>

        {/* หมายเลขหน้า */}
        <div className="hidden sm:flex items-center gap-1">
          {getPageNumbers().map((page, index) =>
            page === '...' ? (
              <span key={`ellipsis-${index}`} className="px-2 text-gray-400">
                ...
              </span>
            ) : (
              <Button
                key={page}
                variant={page === safeCurrentPage ? 'default' : 'outline'}
                size="sm"
                onClick={() => onPageChange(page as number)}
                className="min-w-[2.5rem]"
              >
                {page}
              </Button>
            )
          )}
        </div>

        {/* แสดงหน้าปัจจุบันในมือถือ */}
        <div className="sm:hidden text-sm text-gray-600">
          หน้า {safeCurrentPage}/{safeTotalPages}
        </div>

        {/* ปุ่มถัดไป */}
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(safeCurrentPage + 1)}
          disabled={safeTotalPages === 0 || safeCurrentPage === safeTotalPages}
          className="gap-1"
        >
          ถัดไป
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

