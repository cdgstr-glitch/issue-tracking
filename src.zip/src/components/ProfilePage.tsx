import { useState } from 'react';
import { Label } from './ui/label';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { 
  User, Mail, Phone, Building2, Shield, Briefcase, 
  Eye, EyeOff, Lock, KeyRound, AlertCircle, CheckCircle2,
  ArrowLeft, Loader2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Header } from './Header'; // 🆕 Import Header component
import { getRoleDisplayName } from '../lib/utils'; // 🆕 Import utility function

/**
 * 👤 Profile Page - Unified for All Roles
 * 
 * แสดงและจัดการข้อมูลโปรไฟล์สำหรับทุก Role:
 * - Customer: ชื่อ-นามสกุล, อีเมล, รหัสผ่าน (optional)
 * - Staff: + เบอร์โทร, หน่วยงาน
 * - Tier1-3: + Tier, โครงการที่รับผิดชอบ
 * - Admin: + สิทธิ์พิเศษ
 * 
 * จุดเด่น:
 * - Customer ใหม่ (ผ่าน Magic Link) สามารถตั้งรหัสผ่านได้
 * - ถ้ามีรหัสผ่านแล้ว สามารถเปลี่ยนได้
 * - ลืมรหัสผ่าน → ส่งลิงก์รีเซ็ตทางอีเมล
 */

interface ProfilePageProps {
  onBack: () => void;
}

export function ProfilePage({ onBack }: ProfilePageProps) {
  const { user, customer, logout, activeRole } = useAuth();
  
  // States for Password Management
  const [showSetPasswordDialog, setShowSetPasswordDialog] = useState(false);
  const [showChangePasswordDialog, setShowChangePasswordDialog] = useState(false);
  const [showResetPasswordDialog, setShowResetPasswordDialog] = useState(false);
  
  // Password form states
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  
  // Reset password email state
  const [resetEmail, setResetEmail] = useState('');
  
  // Loading & Success states
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  
  // 🆕 Edit Profile States
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    fullName: '',
    phone: '',
    department: ''
  });
  
  // Check if user has password (mock - in real app, check from backend)
  const hasPassword = user ? true : false; // Staff/Tier มีรหัสผ่านเสมอ
  
  // Get current profile data
  const profileData = customer || user;
  
  if (!profileData) {
    return null;
  }

  // Determine if this is a customer
  const isCustomer = !!customer;
  
  // 🔍 Debug log - ตรวจสอบว่า isCustomer ถูกต้องหรือไม่
  console.log('🔍 ProfilePage Debug:', {
    hasCustomer: !!customer,
    hasUser: !!user,
    isCustomer,
    customerEmail: customer?.email,
    userEmail: user?.email,
    profileEmail: profileData.email
  });

  // Handle Set Password (for new customers)
  const handleSetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (newPassword.length < 6) {
      setError('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('รหัสผ่านไม่ตรงกัน');
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // TODO: Call API to set password
      console.log('🔐 Setting password for:', profileData.email);
      
      setSuccessMessage('ตั้งรหัสผ่านสำเร็จ! คุณสามารถเข้าสู่ระบบด้วยอีเมลและรหัสผ่านได้แล้ว');
      setShowSetPasswordDialog(false);
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (!currentPassword) {
      setError('กรุณากรอกรหัสผ่านปัจจุบัน');
      return;
    }

    if (newPassword.length < 6) {
      setError('รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('รหัสผ่านใหม่ไม่ตรงกัน');
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // TODO: Call API to change password
      console.log('🔐 Changing password for:', profileData.email);
      
      setSuccessMessage('เปลี่ยนรหัสผ่านสำเร็จ!');
      setShowChangePasswordDialog(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setError('รหัสผ่านปัจจุบันไม่ถูกต้อง');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Reset Password (send email)
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (!resetEmail) {
      setError('กรุณากรอกอีเมล');
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // TODO: Call API to send reset password email
      console.log('📧 Sending password reset email to:', resetEmail);
      
      setSuccessMessage('ส่งลิงก์รีเซ็ตรหัสผ่านไปยังอีเมลของคุณแล้ว');
      setShowResetPasswordDialog(false);
      setResetEmail('');
    } catch (err) {
      setError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsLoading(false);
    }
  };

  // 🆕 Handle Edit Profile
  const handleEditProfile = () => {
    setIsEditing(true);
    setEditForm({
      fullName: profileData.fullName,
      phone: user?.phone || '',
      department: user?.department || ''
    });
  };

  // 🆕 Handle Save Profile
  const handleSaveProfile = async () => {
    setError('');
    setSuccessMessage('');
    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // TODO: Call API to update profile
      console.log('💾 Updating profile:', editForm);
      
      // Update local state (in real app, this would come from API response)
      // For now, just show success message
      setSuccessMessage('บันทึกข้อมูลสำเร็จ!');
      setIsEditing(false);
    } catch (err) {
      setError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setIsLoading(false);
    }
  };

  // 🆕 Handle Cancel Edit
  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditForm({
      fullName: '',
      phone: '',
      department: ''
    });
  };

  // Get projects (for Staff/Tier)
  const getProjectNames = () => {
    if (!user?.projectIds || user.projectIds.length === 0) {
      return 'ไม่ได้กำหนด';
    }
    return user.projectIds.join(', ');
  };

  return (
    <div className="min-h-screen bg-[#fafbff]">
      {/* Header - ใช้ Header component ปกติ */}
      <Header 
        showSearch={false}
        user={{
          fullName: profileData.fullName,
          role: isCustomer ? 'customer' : activeRole
        }}
        onNavigate={(path) => {
          if (path === '/profile') return; // Already on profile
          onBack(); // Go back for other paths
        }}
      />

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Button 
          variant="ghost" 
          onClick={onBack}
          className="gap-2 mb-4"
        >
          <ArrowLeft className="h-4 w-4" />
          กลับ
        </Button>

        {/* Page Header */}
        <div className="mb-6">
          <h1 className="mb-2">
            โปรไฟล์
          </h1>
          <p className="text-gray-600">
            จัดการข้อมูลส่วนตัวและการตั้งค่าบัญชี
          </p>
        </div>

        <div className="space-y-6">
          {/* Success Message */}
          {successMessage && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                {successMessage}
              </AlertDescription>
            </Alert>
          )}

          {/* Profile Information Card */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  <div>
                    <CardTitle>ข้อมูลส่วนตัว</CardTitle>
                    <CardDescription>
                      ข้อมูลพื้นฐานของคุณในระบบ
                    </CardDescription>
                  </div>
                </div>
                {/* Edit / Save / Cancel Buttons */}
                <div className="flex gap-2">
                  {!isEditing ? (
                    <Button
                      onClick={handleEditProfile}
                      variant="outline"
                      size="sm"
                    >
                      <User className="w-4 h-4 mr-2" />
                      แก้ไข
                    </Button>
                  ) : (
                    <>
                      <Button
                        onClick={handleCancelEdit}
                        variant="outline"
                        size="sm"
                        disabled={isLoading}
                      >
                        ยกเลิก
                      </Button>
                      <Button
                        onClick={handleSaveProfile}
                        size="sm"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            กำลังบันทึก...
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            บันทึก
                          </>
                        )}
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Basic Information Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Full Name */}
                <div className="space-y-2">
                  <Label className="text-sm text-gray-600 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    ชื่อ-นามสกุล
                  </Label>
                  {!isEditing ? (
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">{profileData.fullName}</p>
                    </div>
                  ) : (
                    <Input
                      value={editForm.fullName}
                      onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                      placeholder="ชื่อ-นามสกุล"
                      className="border-blue-300 focus:border-blue-500"
                    />
                  )}
                </div>

                {/* Email (Key field - cannot duplicate) */}
                <div className="space-y-2">
                  <Label className="text-sm text-gray-600 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    อีเมล
                    <span className="text-xs text-blue-600 font-medium">(คีย์หลัก)</span>
                  </Label>
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <p className="text-neutral-950">{profileData.email}</p>
                  </div>
                </div>

                {/* Phone - แสดงทั้งลูกค้าและเจ้าหน้าที่ */}
                <div className="space-y-2">
                  <Label className="text-sm text-gray-600 flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    เบอร์โทรศัพท์
                  </Label>
                  {!isEditing ? (
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">{user?.phone || editForm.phone || '-'}</p>
                    </div>
                  ) : (
                    <Input
                      value={editForm.phone}
                      onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      placeholder="เบอร์โทรศัพท์"
                      className="border-blue-300 focus:border-blue-500"
                    />
                  )}
                </div>

                {/* Department - แสดงทั้งลูกค้าและเจ้าหน้าที่ */}
                <div className="space-y-2">
                  <Label className="text-sm text-gray-600 flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    หน่วยงาน/สังกัด
                  </Label>
                  {!isEditing ? (
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">{user?.department || editForm.department || '-'}</p>
                    </div>
                  ) : (
                    <Input
                      value={editForm.department}
                      onChange={(e) => setEditForm({ ...editForm, department: e.target.value })}
                      placeholder="หน่วยงาน/สังกัด"
                      className="border-blue-300 focus:border-blue-500"
                    />
                  )}
                </div>

                {/* Tier Level (for Tier1-3 only) */}
                {user?.tier && (
                  <div className="space-y-2">
                    <Label className="text-sm text-gray-600 flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      ระดับ Support
                    </Label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">Tier {user.tier}</p>
                    </div>
                  </div>
                )}

                {/* Projects (for Staff/Tier with project access) - NOT for customers */}
                {/* ✅ ต้องไม่ใช่ลูกค้า (customer) และต้องมี user object และ user ต้องไม่ใช่ role customer */}
                {!isCustomer && user && user.role !== 'customer' && (
                  <div className={`space-y-2 ${!user.tier ? 'md:col-span-2' : ''}`}>
                    <Label className="text-sm text-gray-600 flex items-center gap-2">
                      <Briefcase className="w-4 h-4" />
                      โครงการที่รับผิดชอบ
                    </Label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="text-neutral-950">{getProjectNames()}</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Password Management Card (only for customers or users who want to manage password) */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5" />
                จัดการรหัสผ่าน
              </CardTitle>
              <CardDescription>
                {isCustomer && !hasPassword
                  ? 'ตั้งรหัสผ่านเพื่อเข้าสู่ระบบโดยไม่ต้องใช้ลิงก์ทางอีเมล'
                  : 'เปลี่ยนรหัสผ่านหรือรีเซ็ตรหัสผ่านผ่านทางอีเมล'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Customer without password */}
              {isCustomer && !hasPassword && (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <KeyRound className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-blue-900 mb-1">
                        คุณยังไม่ได้ตั้งรหัสผ่าน
                      </p>
                      <p className="text-sm text-blue-700 mb-3">
                        ปัจจุบันคุณเข้าสู่ระบบผ่าน Magic Link ทางอีเมล 
                        หากต้องการเข้าสู่ระบบด้วยรหัสผ่าน คุณสามารถตั้งรหัสผ่านได้ที่นี่
                      </p>
                      <Button
                        onClick={() => setShowSetPasswordDialog(true)}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <KeyRound className="w-4 h-4 mr-2" />
                        ตั้งรหัสผ่าน
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* User with password */}
              {(hasPassword || !isCustomer) && (
                <div className="space-y-3">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 text-green-800">
                      <CheckCircle2 className="w-4 h-4" />
                      <span className="text-sm font-medium">คุณมีรหัสผ่านแล้ว</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      onClick={() => setShowChangePasswordDialog(true)}
                      variant="outline"
                      className="flex-1"
                    >
                      <Lock className="w-4 h-4 mr-2" />
                      เปลี่ยนรหัสผ่าน
                    </Button>
                    <Button
                      onClick={() => {
                        setResetEmail(profileData.email || '');
                        setShowResetPasswordDialog(true);
                      }}
                      variant="outline"
                      className="flex-1 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      ลืมรหัสผ่าน? รีเซ็ตทางอีเมล
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Logout Card */}
          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="text-red-900">ออกจากระบบ</CardTitle>
              <CardDescription>
                ออกจากระบบและกลับสู่หน้าเข้าสู่ระบบ
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={logout}
                variant="destructive"
                className="w-full sm:w-auto"
              >
                ออกจากระบบ
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Set Password Dialog */}
      <Dialog open={showSetPasswordDialog} onOpenChange={setShowSetPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ตั้งรหัสผ่าน</DialogTitle>
            <DialogDescription>
              สร้างรหัสผ่านเพื่อเข้าสู่ระบบด้วยอีเมลและรหัสผ่าน
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSetPassword}>
            <div className="space-y-4 py-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="newPassword">รหัสผ่านใหม่</Label>
                <div className="relative">
                  <Input
                    id="newPassword"
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="อย่างน้อย 6 ตัวอักษร"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">ยืนยันรหัสผ่าน</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านอีกครั้ง"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowSetPasswordDialog(false)}
                disabled={isLoading}
              >
                ยกเลิก
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังบันทึก...
                  </>
                ) : (
                  'ตั้งรหัสผ่าน'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Change Password Dialog */}
      <Dialog open={showChangePasswordDialog} onOpenChange={setShowChangePasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>เปลี่ยนรหัสผ่าน</DialogTitle>
            <DialogDescription>
              กรอกรหัสผ่านปัจจุบันและรหัสผ่านใหม่
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleChangePassword}>
            <div className="space-y-4 py-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="currentPassword">รหัสผ่านปัจจุบัน</Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    type={showCurrentPassword ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านปัจจุบัน"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPasswordChange">รหัสผ่านใหม่</Label>
                <div className="relative">
                  <Input
                    id="newPasswordChange"
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="อย่างน้อย 6 ตัวอักษร"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPasswordChange">ยืนยันรหัสผ่านใหม่</Label>
                <div className="relative">
                  <Input
                    id="confirmPasswordChange"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านอีกครั้ง"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowChangePasswordDialog(false)}
                disabled={isLoading}
              >
                ยกเลิก
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังบันทึก...
                  </>
                ) : (
                  'เปลี่ยนรหัสผ่าน'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={showResetPasswordDialog} onOpenChange={setShowResetPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>รีเซ็ตรหัสผ่าน</DialogTitle>
            <DialogDescription>
              เราจะส่งลิงก์รีเซ็ตรหัสผ่านไปยังอีเมลของคุณ
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleResetPassword}>
            <div className="space-y-4 py-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="resetEmail">อีเมล</Label>
                <Input
                  id="resetEmail"
                  type="email"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  placeholder="example@company.com"
                  required
                  disabled
                  className="bg-gray-50"
                />
                <p className="text-xs text-gray-500">
                  ลิงก์รีเซ็ตรหัสผ่านจะส่งไปยังอีเมลนี้
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowResetPasswordDialog(false)}
                disabled={isLoading}
              >
                ยกเลิก
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังส่ง...
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4 mr-2" />
                    ส่งลิงก์รีเซ็ต
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}