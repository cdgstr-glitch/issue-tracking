import { useState, useEffect } from 'react';
import { Star } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { db } from '../lib/mockDb/client';
import { toast } from 'sonner@2.0.3';
import { RawSatisfactionSurvey } from '../lib/mockDb/types';
import { useAuth } from '../contexts/AuthContext';
import { can, CAPABILITIES } from '../lib/permissions';

interface SatisfactionSurveyProps {
  ticketId: string;
  status?: string;
}

export function SatisfactionSurvey({ ticketId, status }: SatisfactionSurveyProps) {
  const { user, customer } = useAuth();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [existingSurvey, setExistingSurvey] = useState<RawSatisfactionSurvey | null>(null);

  // ✅ 1. Check permissions (Support both User and CustomerUser)
  const canSubmit = !!customer || (user ? can(user, CAPABILITIES.SUBMIT_SATISFACTION_SURVEY) : false);
  
  // ✅ 2. Read-only mode logic
  // If status is 'closed', it is ALWAYS read-only regardless of submission status
  const isReadOnly = !canSubmit || isSubmitted || status === 'closed';

  useEffect(() => {
    // Check if survey already exists
    const survey = db.satisfactionSurveys.getByTicketId(ticketId);
    if (survey) {
      setExistingSurvey(survey);
      setRating(survey.rating);
      setComment(survey.comment || '');
      setIsSubmitted(true);
    }
  }, [ticketId]);

  const handleSubmit = () => {
    if (!canSubmit) {
      toast.error('คุณไม่มีสิทธิ์ในการประเมิน');
      return;
    }

    if (rating === 0) {
      toast.error('กรุณาให้คะแนนความพึงพอใจ');
      return;
    }

    try {
      db.satisfactionSurveys.add({
        ticketId,
        rating,
        comment,
        userId: user?.id || customer?.id
      });
      
      setIsSubmitted(true);
      toast.success('ขอบคุณสำหรับการประเมินครับ');
    } catch (error) {
      console.error(error);
      toast.error('เกิดข้อผิดพลาดในการบันทึก');
    }
  };

  // ✅ 3. Visibility Logic
  if (!existingSurvey && !canSubmit) {
    return null;
  }

  const getRatingLabel = (r: number) => {
    switch (r) {
      case 1: return 'ต้องปรับปรุง';
      case 2: return 'พอใช้';
      case 3: return 'ปานกลาง';
      case 4: return 'ดี';
      case 5: return 'ดีมาก';
      default: return '';
    }
  };

  return (
    <div className="mt-8 pt-6 border-t border-gray-100 flex flex-col items-center text-center">
      <div className="w-full max-w-lg">
        <div className="mb-4">
          <h3 className="text-base font-medium text-gray-900 mb-1">
            {isSubmitted ? 'คะแนนความพึงพอใจ' : 'ประเมินการให้บริการ'}
          </h3>
          <p className="text-sm text-gray-500 h-5">
            {rating > 0 ? (
              <span className="text-blue-600 font-medium animate-in fade-in">
                {getRatingLabel(rating)}
              </span>
            ) : (
              !isSubmitted && 'เลือกดาวเพื่อประเมินความพึงพอใจ'
            )}
          </p>
        </div>

        {/* Stars */}
        <div className="flex items-center justify-center gap-3 mb-4">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              disabled={isReadOnly}
              className={`transition-all focus:outline-none ${
                isReadOnly ? 'cursor-default' : 'cursor-pointer hover:scale-110 hover:-translate-y-1'
              }`}
              onMouseEnter={() => !isReadOnly && setHoverRating(star)}
              onMouseLeave={() => !isReadOnly && setHoverRating(0)}
              onClick={() => !isReadOnly && setRating(star)}
            >
              <Star
                className={`h-8 w-8 transition-colors ${
                  star <= (hoverRating || rating)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-200'
                }`}
              />
            </button>
          ))}
        </div>

        {/* Interaction Area */}
        {!isSubmitted && !isReadOnly && (
          <div className={`overflow-hidden transition-all duration-300 ease-in-out ${rating > 0 ? 'max-h-[200px] opacity-100' : 'max-h-0 opacity-0'}`}>
            <div className="space-y-3 pt-2 px-4 sm:px-0">
              <Textarea
                placeholder="ข้อเสนอแนะเพิ่มเติม (ไม่บังคับ)..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="min-h-[80px] text-sm bg-white resize-none"
              />
              <div className="flex justify-center">
                <Button 
                  onClick={handleSubmit} 
                  className="bg-blue-600 hover:bg-blue-700 text-white min-w-[120px]"
                >
                  ส่งแบบประเมิน
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Read Only Comment View */}
        {isSubmitted && (comment || existingSurvey?.comment) && (
          <div className="bg-gray-50 p-4 rounded-md text-sm text-gray-600 border border-gray-100 mt-2 mx-auto inline-block italic">
            "{comment || existingSurvey?.comment}"
          </div>
        )}
      </div>
    </div>
  );
}
