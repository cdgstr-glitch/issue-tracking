import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { TicketCard } from './TicketCard';
import { TicketTable } from './TicketTable';
import { Pagination } from './Pagination';
import { Ticket } from '../types';

type ViewMode = 'cards' | 'table';
type TierColor = 'blue' | 'orange' | 'red' | 'green';

interface ColorConfig {
  bg: string;
  text: string;
}

const tierColors: Record<TierColor, ColorConfig> = {
  blue: { bg: 'bg-blue-50', text: 'text-blue-900' },
  orange: { bg: 'bg-orange-50', text: 'text-orange-900' },
  red: { bg: 'bg-red-50', text: 'text-red-900' },
  green: { bg: 'bg-green-50', text: 'text-green-900' }
};

interface EscalatedSectionProps {
  title: string;
  tickets: Ticket[];
  tierColor: TierColor;
  viewMode: ViewMode;
  onNavigate: (path: string, ticketId?: string, sourcePath?: string) => void;
  sourcePath?: string;
  itemsPerPageCards?: number;
  itemsPerPageTable?: number;
  showPaginationAlways?: boolean;
}

export function EscalatedSection({
  title,
  tickets,
  tierColor,
  viewMode,
  onNavigate,
  sourcePath = '/admin/escalated',
  itemsPerPageCards = 9,
  itemsPerPageTable = 10,
  showPaginationAlways = true
}: EscalatedSectionProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = viewMode === 'cards' ? itemsPerPageCards : itemsPerPageTable;
  
  // คำนวณ pagination
  const totalPages = Math.ceil(tickets.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentTickets = tickets.slice(startIndex, endIndex);
  
  // Reset page เมื่อ tickets เปลี่ยนหรือ viewMode เปลี่ยน
  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(totalPages);
    }
  }, [tickets.length, currentPage, totalPages]);
  
  // Reset เมื่อ viewMode เปลี่ยน (optional - ขึ้นอยู่กับ UX ที่ต้องการ)
  useEffect(() => {
    setCurrentPage(1);
  }, [viewMode]);
  
  const colors = tierColors[tierColor];
  const shouldShowPagination = showPaginationAlways || totalPages > 1;
  
  return (
    <Card>
      <CardHeader className={colors.bg}>
        <CardTitle className={colors.text}>
          {title} ({tickets.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        {/* แสดง Cards หรือ Table */}
        {viewMode === 'cards' ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {currentTickets.map((ticket) => (
              <TicketCard
                key={ticket.id}
                ticket={ticket}
                onClick={() => onNavigate('/admin/ticket', ticket.id, sourcePath)}
              />
            ))}
          </div>
        ) : (
          <TicketTable
            tickets={currentTickets}
            onNavigate={onNavigate}
            sourcePath={sourcePath}
          />
        )}
        
        {/* Empty State */}
        {tickets.length === 0 && (
          <div className="py-12 text-center text-gray-500">
            <p>ไม่มีเคสในหมวดนี้</p>
          </div>
        )}
        
        {/* Pagination - แสดงเสมอถ้า showPaginationAlways = true */}
        {tickets.length > 0 && shouldShowPagination && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            totalItems={tickets.length}
            itemsPerPage={itemsPerPage}
          />
        )}
      </CardContent>
    </Card>
  );
}
