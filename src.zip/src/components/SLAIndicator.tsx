import { Clock, AlertTriangle, CheckCircle, HelpCircle } from 'lucide-react';
import { calculateSLAStatus } from '../lib/utils';
import type { Ticket, TicketStatus } from '../types';

type DateLike = Date | string | null | undefined;

interface SLAIndicatorProps {
  /** New style: pass the whole ticket */
  ticket?: Ticket;

  /** Legacy style: pass fields directly (used in some pages/components) */
  createdAt?: DateLike;
  dueDate?: DateLike;
  status?: TicketStatus;
  resolvedAt?: DateLike;
  closedAt?: DateLike;

  /** Some pages pass this; keep for compatibility even if unused */
  slaStatus?: unknown;

  showLabel?: boolean;
}

function toDate(value: DateLike, fallback?: Date): Date | null {
  if (!value) return fallback ?? null;
  if (value instanceof Date) return value;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? (fallback ?? null) : d;
}

export function SLAIndicator({
  ticket,
  createdAt,
  dueDate,
  status,
  resolvedAt,
  closedAt,
  showLabel = true
}: SLAIndicatorProps) {
  const due = ticket?.dueDate ?? dueDate;

  // ✅ Safe check - if no dueDate, show "N/A"
  if (!due) {
    return (
      <div className="inline-flex items-center gap-1.5 rounded-md bg-gray-50 px-2.5 py-1 text-xs text-gray-500">
        <HelpCircle className="h-3.5 w-3.5" />
        {showLabel && <span>N/A</span>}
      </div>
    );
  }

  const created = toDate(ticket?.createdAt ?? createdAt, new Date())!;
  const dueD = toDate(due)!;
  const st: TicketStatus = (ticket?.status ?? status ?? 'new') as TicketStatus;

  const resolved = toDate(ticket?.resolvedAt ?? resolvedAt);
  const closed = toDate(ticket?.closedAt ?? closedAt);

  const slaStatus = calculateSLAStatus(created, dueD, st, resolved, closed);

  const config = {
    ok: { icon: CheckCircle, color: 'text-green-600 bg-green-50', label: 'On Track' },
    warning: { icon: Clock, color: 'text-orange-600 bg-orange-50', label: 'Due Soon' },
    breached: { icon: AlertTriangle, color: 'text-red-600 bg-red-50', label: 'Overdue' }
  } as const;

  const { icon: Icon, color, label } = config[slaStatus];

  return (
    <div className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs ${color}`}>
      <Icon className="h-3.5 w-3.5" />
      {showLabel && <span>{label}</span>}
    </div>
  );
}
