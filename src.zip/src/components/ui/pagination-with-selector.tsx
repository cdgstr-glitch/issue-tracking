/**
 * 📄 Pagination with Items Per Page Selector
 *
 * @description Standard pagination component ที่รวม items per page selector
 * @version 1.1 - Harden against NaN/undefined + safe ranges + reset page on per-page change
 */

import { Button } from './button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationWithSelectorProps {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  itemsPerPageOptions?: number[];
  onPageChange: (page: number) => void;
  onItemsPerPageChange: (itemsPerPage: number) => void;
  startIndex: number;
  endIndex: number;
  showItemsInfo?: boolean; // แสดงข้อมูล "แสดง 1-10 จาก 125"
  className?: string;
}

export function PaginationWithSelector({
  currentPage,
  totalPages,
  totalItems,
  itemsPerPage,
  itemsPerPageOptions = [10, 25, 50, 100],
  onPageChange,
  onItemsPerPageChange,
  startIndex,
  endIndex,
  showItemsInfo = true,
  className = '',
}: PaginationWithSelectorProps) {
  // =========================
  // ✅ SANITIZE (กัน NaN/undefined/ติดลบ)
  // =========================
  const safeTotalItems = Number.isFinite(totalItems) && totalItems > 0 ? totalItems : 0;

  const safeItemsPerPage = Number.isFinite(itemsPerPage) && itemsPerPage > 0 ? itemsPerPage : 10;

  // ใช้ totalPages จาก props ถ้ามาเป็นตัวเลขที่ถูกต้อง ไม่งั้นคำนวณเองจาก totalItems/itemsPerPage
  const safeTotalPages =
    Number.isFinite(totalPages) && totalPages > 0
      ? totalPages
      : safeTotalItems === 0
        ? 0
        : Math.max(1, Math.ceil(safeTotalItems / safeItemsPerPage));

  const safeCurrentPageRaw = Number.isFinite(currentPage) && currentPage > 0 ? currentPage : 1;

  // clamp currentPage ไม่ให้หลุดช่วง
  const safeCurrentPage =
    safeTotalPages === 0 ? 1 : Math.min(safeCurrentPageRaw, safeTotalPages);

  // startIndex/endIndex ที่ส่งมาบางทีอาจหลุด/NaN → คำนวณใหม่แบบปลอดภัยเป็น source of truth สำหรับ display
  const safeStartIndex =
    safeTotalItems === 0 ? 0 : (safeCurrentPage - 1) * safeItemsPerPage;

  const safeEndIndex =
    safeTotalItems === 0 ? 0 : safeStartIndex + safeItemsPerPage;

  // ✅ display range
  const startDisplay = safeTotalItems === 0 ? 0 : safeStartIndex + 1;
  const endDisplay = safeTotalItems === 0 ? 0 : Math.min(safeEndIndex, safeTotalItems);

  // =========================
  // Handlers
  // =========================
  const handlePrev = () => {
    if (safeTotalPages === 0) return;
    onPageChange(Math.max(1, safeCurrentPage - 1));
  };

  const handleNext = () => {
    if (safeTotalPages === 0) return;
    onPageChange(Math.min(safeTotalPages, safeCurrentPage + 1));
  };

  const handlePerPageChange = (rawValue: string) => {
    const n = Number(rawValue);
    const nextPerPage = Number.isFinite(n) && n > 0 ? n : 10;

    onItemsPerPageChange(nextPerPage);

    // ✅ สำคัญ: เปลี่ยนต่อหน้าแล้วกลับไปหน้า 1 กันหลุดช่วง start/end
    onPageChange(1);
  };

  return (
    <div className={`flex items-center justify-between gap-4 ${className}`}>
      {/* Left: Items info + Per page selector */}
      <div className="flex items-center gap-4">
        {/* Items info */}
        {showItemsInfo && (
          <span className="text-sm text-gray-600">
            แสดง <span className="font-semibold">{startDisplay}</span>-
            <span className="font-semibold">{endDisplay}</span> จาก{' '}
            <span className="font-semibold">{safeTotalItems}</span> รายการ
          </span>
        )}

        {/* Items per page selector */}
        <div className="flex items-center gap-2">
          <label htmlFor="items-per-page" className="text-sm text-gray-600 whitespace-nowrap">
            แสดงต่อหน้า:
          </label>
          <select
            id="items-per-page"
            value={safeItemsPerPage}
            onChange={(e) => handlePerPageChange(e.target.value)}
            className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          >
            {itemsPerPageOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Right: Pagination buttons */}
      {safeTotalPages > 1 && (
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrev}
            disabled={safeCurrentPage === 1}
            className="gap-1"
          >
            <ChevronLeft className="h-4 w-4" />
            ก่อนหน้า
          </Button>

          <span className="text-sm text-gray-600 px-2">
            หน้า <span className="font-semibold">{safeCurrentPage}</span> / {safeTotalPages}
          </span>

          <Button
            variant="outline"
            size="sm"
            onClick={handleNext}
            disabled={safeCurrentPage === safeTotalPages}
            className="gap-1"
          >
            ถัดไป
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}
