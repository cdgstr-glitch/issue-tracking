import { Badge } from './badge';
import { Phone, Mail, MessageCircle, Globe, AlertCircle } from 'lucide-react';
import { buildStatusResolver } from '../../lib/mockDb/data/statusService';

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  // ✅ ใช้ resolver เดียวกับ dropdown เพื่อให้ label ตรงกัน
  const resolver = buildStatusResolver('staff');
  const normalized = resolver.normalize(status);
  const meta = resolver.getMeta(normalized);

  const variantToClass: Record<string, string> = {
    gray: 'bg-gray-100 text-gray-800 hover:bg-gray-100',
    blue: 'bg-blue-100 text-blue-800 hover:bg-blue-100',
    green: 'bg-green-100 text-green-800 hover:bg-green-100',
    yellow: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100',
    orange: 'bg-orange-100 text-orange-800 hover:bg-orange-100',
    red: 'bg-red-100 text-red-800 hover:bg-red-100',
    purple: 'bg-purple-100 text-purple-800 hover:bg-purple-100',
    indigo: 'bg-indigo-100 text-indigo-800 hover:bg-indigo-100',
  };

  const className = variantToClass[meta.variant] || variantToClass.gray;

  return (
    <Badge variant="secondary" className={className}>
      {meta.label}
    </Badge>
  );
}

interface PriorityBadgeProps {
  priority: string;
}

export function PriorityBadge({ priority }: PriorityBadgeProps) {
  const variants: Record<string, { label: string; className: string }> = {
    low: { label: 'ต่ำ', className: 'bg-green-100 text-green-800 hover:bg-green-100' },
    medium: { label: 'ปานกลาง', className: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100' },
    high: { label: 'สูง', className: 'bg-orange-100 text-orange-800 hover:bg-orange-100' },
    urgent: { label: 'ด่วนมาก', className: 'bg-red-100 text-red-800 hover:bg-red-100' },
  };

  const variant = variants[priority] || { label: priority, className: 'bg-gray-100 text-gray-800 hover:bg-gray-100' };

  return (
    <Badge variant="secondary" className={variant.className}>
      {variant.label}
    </Badge>
  );
}

interface ChannelBadgeProps {
  channel: string;
}

export function ChannelBadge({ channel }: ChannelBadgeProps) {
  const variants: Record<string, { label: string; icon: any; className: string }> = {
    web: {
      label: 'เว็บไซต์',
      icon: Globe,
      className: 'bg-blue-100 text-blue-800 hover:bg-blue-100'
    },
    phone: {
      label: 'โทรศัพท์',
      icon: Phone,
      className: 'bg-green-100 text-green-800 hover:bg-green-100'
    },
    email: {
      label: 'อีเมล',
      icon: Mail,
      className: 'bg-purple-100 text-purple-800 hover:bg-purple-100'
    },
    line: {
      label: 'Line',
      icon: MessageCircle,
      className: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100'
    },
  };

  const variant = variants[channel] || {
    label: channel,
    icon: AlertCircle,
    className: 'bg-gray-100 text-gray-800 hover:bg-gray-100'
  };

  const Icon = variant.icon;

  return (
    <Badge variant="secondary" className={variant.className}>
      <Icon className="mr-1 h-3 w-3" />
      {variant.label}
    </Badge>
  );
}
