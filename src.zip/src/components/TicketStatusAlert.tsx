import { Info, Bell, Undo2, CheckCircle, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Alert } from './ui/alert';
import { Ticket } from '../types';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client
import { formatDate } from '../lib/utils';
import { toast } from 'sonner@2.0.3';
import { EmailPreviewModal } from './EmailPreviewModal';
import { useState } from 'react';

interface TicketStatusAlertProps {
  ticket: Ticket;
  currentUserId?: string;
  onUpdate: (updates: Partial<Ticket>) => void;
}

export function TicketStatusAlert({ ticket, currentUserId, onUpdate }: TicketStatusAlertProps) {
  const [showEmailPreview, setShowEmailPreview] = useState(false);
  
  // Check if ticket is escalated/assigned but not yet accepted
  const isWaitingAcceptance = ['tier1', 'tier2', 'tier3'].includes(ticket.stage as any);
  const isClosed = ticket.status === 'closed';
  const wasAssignedByCurrentUser = ticket.assignedBy === currentUserId;
  
  if (!isWaitingAcceptance && !isClosed) return null;

  // Get assignee information
  const assignee = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;
  const assignedBy = ticket.assignedBy ? db.users.getById(ticket.assignedBy) : null;
  
  // Determine tier name
  const getTierName = (status: string) => {
    if (status === 'tier1') return 'Tier 1';
    if (status === 'tier2') return 'Tier 2';
    if (status === 'tier3') return 'Tier 3';
    return status;
  };

  const tierName = getTierName(ticket.status);

  // Handle remind assignee
  const handleRemind = () => {
    setShowEmailPreview(true);
    toast.success(`ส่งการแจ้งเตือนไปยัง ${assignee?.fullName || 'ผู้รับผิดชอบ'} แล้ว`);
  };

  // Handle cancel escalation
  const handleCancel = () => {
    const previousAssignee = ticket.previousAssignee || ticket.assignedBy;
    
    toast.success('ยกเลิกการส่งต่อเคสแล้ว');
    onUpdate({
      status: 'in_progress',
      assignedTo: previousAssignee || currentUserId,
      assignedBy: currentUserId,
      assignedAt: new Date(),
    });
  };

  // Render for closed status
  if (isClosed) {
    const closedBy = ticket.closedBy ? db.users.getById(ticket.closedBy) : null;
    return (
      <div className="mb-6 rounded-lg border border-gray-300 bg-gray-50 p-4">
        <div className="flex items-start gap-3">
          <XCircle className="h-5 w-5 text-gray-600 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="space-y-1">
              <p className="text-sm text-gray-900">
                <strong>เคสนี้ได้ปิดแล้ว</strong>
              </p>
              <p className="text-sm text-gray-700">
                ตรวจสอบและปิดเคสเรียบร้อยแล้ว
                {ticket.closedAt && ` • ปิดเมื่อ ${formatDate(ticket.closedAt)}`}
                {closedBy && ` • ปิดโดย ${closedBy.fullName}`}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render for tier1/tier2/tier3 waiting acceptance
  return (
    <>
      <div className="mb-6 rounded-lg border border-blue-200 bg-blue-50 p-4">
        <div className="flex items-start gap-3">
          <Info className="h-5 w-5 text-blue-600 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="space-y-1">
              <p className="text-sm text-blue-900">
                {(() => {
                  // ✅ ใช้ previousAssignee ก่อน (คนที่ส่งเคสมา) ถ้าไม่มีค่อยใช้ assignedBy
                  const sender = (ticket.previousAssignee ? db.users.getById(ticket.previousAssignee) : null) || assignedBy;
                  const senderTier = sender?.role === 'tier1' ? 'Tier 1' :
                                    sender?.role === 'tier2' ? 'Tier 2' :
                                    sender?.role === 'tier3' ? 'Tier 3' :
                                    sender?.role === 'admin' ? 'Admin' :
                                    tierName;
                  
                  return (
                    <>
                      <strong>เคสนี้มาจาก {sender?.fullName || 'ผู้รับผิดชอบ'} ({senderTier})</strong>
                    </>
                  );
                })()}
              </p>
              <p className="text-sm text-blue-700">
                รอการรับเคส
                {ticket.assignedAt && ` • ส่งเมื่อ ${formatDate(ticket.assignedAt)}`}
                {assignee && assignee.id !== currentUserId && ` • มอบหมายให้ ${assignee.fullName}`}
              </p>
            </div>

            {/* Action buttons - only show if current user is the one who escalated */}
            {wasAssignedByCurrentUser && (
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRemind}
                  className="gap-2 bg-white hover:bg-blue-50 border-blue-300"
                >
                  <Bell className="h-4 w-4" />
                  เตือนผู้รับเคส
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCancel}
                  className="gap-2 bg-white hover:bg-blue-50 border-blue-300"
                >
                  <Undo2 className="h-4 w-4" />
                  ยกเลิกการส่งต่อ
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Email Preview Modal */}
      {showEmailPreview && assignee && assignedBy && (
        <EmailPreviewModal
          isOpen={showEmailPreview}
          onClose={() => setShowEmailPreview(false)}
          type="reminder"
          ticket={ticket}
          assignedBy={assignedBy}
          assignedTo={assignee}
        />
      )}
    </>
  );
}
