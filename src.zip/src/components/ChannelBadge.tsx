import { TicketChannel } from '../types';
import { Globe, Mail, MessageCircle, Phone, Building2 } from 'lucide-react';
import { db } from '../lib/mockDb/client';

interface ChannelBadgeProps {
  channel: TicketChannel;
}

const iconMap: Record<string, any> = {
  Globe,
  Mail,
  MessageCircle,
  Phone,
  Building2
};

export function ChannelBadge({ channel }: ChannelBadgeProps) {
  const channels = db.master.getChannels();
  // @ts-ignore - access by key
  const config = channels[channel];

  // Fallback for unknown channels to prevent crashes
  if (!config) {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs bg-gray-100 text-gray-500">
        <Globe className="w-3 h-3" />
        {channel || 'Unknown'}
      </span>
    );
  }

  const Icon = iconMap[config.icon] || Globe;

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs ${config.color}`}>
      <Icon className="w-3 h-3" />
      {config.label}
    </span>
  );
}
