import { Card } from './ui/card';
import { CheckCircle2, ArrowUpRight, CirclePause, ArrowDown } from 'lucide-react';

interface DecisionFlowchartProps {
  tier: 1 | 2 | 3;
}

export const DecisionFlowchart: React.FC<DecisionFlowchartProps> = ({ tier }) => {
  const getTierConfig = () => {
    if (tier === 1) {
      return {
        color: 'blue',
        decisions: [
          {
            type: 'resolve',
            label: 'แก้ไขได้เลย',
            icon: CheckCircle2,
            conditions: [
              'ปัญหาง่าย เข้าใจดี',
              'มีวิธีแก้ไขในมือ',
              'ไม่ต้องใช้ความรู้เทคนิค'
            ],
            action: 'แก้ไขแล้ว',
            color: 'green'
          },
          {
            type: 'escalate',
            label: 'ซับซ้อน',
            icon: ArrowUpRight,
            conditions: [
              'ต้องเข้าถึง Database/Logs',
              'ต้องแก้ไข Code/Config',
              'Bug ในระบบ'
            ],
            action: 'ส่งต่อ Tier 2',
            color: 'orange'
          },
          {
            type: 'hold',
            label: 'ขาดข้อมูล',
            icon: CirclePause,
            conditions: [
              'รอ Screenshot',
              'รอการอนุมัติ',
              'รอข้อมูลจากลูกค้า'
            ],
            action: 'ระงับเคส',
            color: 'yellow'
          }
        ]
      };
    } else if (tier === 2) {
      return {
        color: 'orange',
        decisions: [
          {
            type: 'resolve',
            label: 'แก้ไขได้',
            icon: CheckCircle2,
            conditions: [
              'หาสาเหตุได้แล้ว',
              'มี Access แก้ไข',
              'ทดสอบได้'
            ],
            action: 'แก้ไขแล้ว',
            color: 'green'
          },
          {
            type: 'escalate',
            label: 'วิกฤติ/ซับซ้อน',
            icon: ArrowUpRight,
            conditions: [
              'System Down',
              'ต้องติดต่อ Vendor',
              'Security Issue'
            ],
            action: 'ส่งต่อ Tier 3',
            color: 'red'
          },
          {
            type: 'hold',
            label: 'รออนุมัติ',
            icon: CirclePause,
            conditions: [
              'รอผู้บริหารอนุมัติ',
              'รอทีมพัฒนา',
              'รอการทดสอบ UAT'
            ],
            action: 'ระงับเคส',
            color: 'yellow'
          }
        ]
      };
    } else {
      return {
        color: 'red',
        decisions: [
          {
            type: 'resolve',
            label: 'จัดการได้',
            icon: CheckCircle2,
            conditions: [
              'ประสานงาน Vendor สำเร็จ',
              'แก้ไข Infrastructure แล้ว',
              'แก้วิกฤติเสร็จ'
            ],
            action: 'แก้ไขแล้ว',
            color: 'green'
          },
          {
            type: 'escalate',
            label: 'ต้องการผู้เชี่ยวชาญพิเศษ',
            icon: ArrowUpRight,
            conditions: [
              'ต้องการ Cloud Provider',
              'ปัญหาระดับ Architecture',
              'Compliance Issue'
            ],
            action: 'ส่งต่อ External',
            color: 'purple'
          },
          {
            type: 'hold',
            label: 'รอ Vendor',
            icon: CirclePause,
            conditions: [
              'รอการตอบกลับจาก Vendor',
              'รอ Patch/Update',
              'รอการอนุมัติระดับสูง'
            ],
            action: 'ระงับเคส',
            color: 'yellow'
          }
        ]
      };
    }
  };

  const config = getTierConfig();
  const colorMap: Record<string, { bg: string; border: string; text: string; shadow: string }> = {
    blue: { bg: 'bg-blue-50', border: 'border-blue-500', text: 'text-blue-900', shadow: 'shadow-blue-200' },
    orange: { bg: 'bg-orange-50', border: 'border-orange-500', text: 'text-orange-900', shadow: 'shadow-orange-200' },
    red: { bg: 'bg-red-50', border: 'border-red-500', text: 'text-red-900', shadow: 'shadow-red-200' },
    green: { bg: 'bg-green-50', border: 'border-green-500', text: 'text-green-900', shadow: 'shadow-green-200' },
    yellow: { bg: 'bg-yellow-50', border: 'border-yellow-500', text: 'text-yellow-900', shadow: 'shadow-yellow-200' },
    purple: { bg: 'bg-purple-50', border: 'border-purple-500', text: 'text-purple-900', shadow: 'shadow-purple-200' }
  };

  return (
    <div className="w-full">
      {/* Start Node */}
      <div className="flex justify-center mb-6">
        <div className={`${colorMap[config.color].bg} ${colorMap[config.color].border} border-4 rounded-2xl px-8 py-6 shadow-lg ${colorMap[config.color].shadow}`}>
          <p className={`text-center ${colorMap[config.color].text} m-0`}>
            <strong>📥 รับเคส{tier === 1 ? 'ใหม่' : `จาก Tier ${tier - 1}`}</strong>
          </p>
          <p className="text-center text-gray-600 text-sm mt-2 m-0">
            อ่านรายละเอียด → วิเคราะห์ปัญหา
          </p>
        </div>
      </div>

      {/* Arrow Down */}
      <div className="flex justify-center mb-6">
        <ArrowDown className={`h-8 w-8 ${colorMap[config.color].text}`} />
      </div>

      {/* Decision Node */}
      <div className="flex justify-center mb-8">
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-2xl px-8 py-6 shadow-xl relative">
          <div className="absolute -top-3 -right-3 bg-yellow-400 text-yellow-900 rounded-full w-8 h-8 flex items-center justify-center shadow-md">
            ?
          </div>
          <p className="text-center m-0">
            <strong>🤔 ตัดสินใจ: ควรทำอย่างไร?</strong>
          </p>
        </div>
      </div>

      {/* Arrows to 3 paths */}
      <div className="relative mb-6">
        <svg className="w-full h-20" viewBox="0 0 800 80" preserveAspectRatio="xMidYMid meet">
          {/* Left arrow */}
          <path
            d="M 400 10 Q 200 40 100 80"
            fill="none"
            stroke="#22c55e"
            strokeWidth="3"
            markerEnd="url(#arrowGreen)"
          />
          {/* Center arrow */}
          <path
            d="M 400 10 L 400 80"
            fill="none"
            stroke={tier === 3 ? '#a855f7' : tier === 2 ? '#ef4444' : '#f97316'}
            strokeWidth="3"
            markerEnd={tier === 3 ? 'url(#arrowPurple)' : tier === 2 ? 'url(#arrowRed)' : 'url(#arrowOrange)'}
          />
          {/* Right arrow */}
          <path
            d="M 400 10 Q 600 40 700 80"
            fill="none"
            stroke="#eab308"
            strokeWidth="3"
            markerEnd="url(#arrowYellow)"
          />
          
          {/* Arrow markers */}
          <defs>
            <marker id="arrowGreen" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L0,6 L9,3 z" fill="#22c55e" />
            </marker>
            <marker id="arrowOrange" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L0,6 L9,3 z" fill="#f97316" />
            </marker>
            <marker id="arrowRed" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L0,6 L9,3 z" fill="#ef4444" />
            </marker>
            <marker id="arrowYellow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L0,6 L9,3 z" fill="#eab308" />
            </marker>
            <marker id="arrowPurple" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L0,6 L9,3 z" fill="#a855f7" />
            </marker>
          </defs>
        </svg>
      </div>

      {/* Three Decision Paths */}
      <div className="grid md:grid-cols-3 gap-6">
        {config.decisions.map((decision, index) => {
          const Icon = decision.icon;
          const colors = colorMap[decision.color];
          
          return (
            <div key={index} className="flex flex-col">
              {/* Decision Card */}
              <Card className={`${colors.bg} border-2 ${colors.border} shadow-lg hover:shadow-xl transition-shadow flex-1`}>
                <div className="p-6">
                  <div className="flex items-center justify-center mb-4">
                    <div className={`${colors.bg} border-2 ${colors.border} rounded-full p-4 shadow-md`}>
                      <Icon className={`h-8 w-8 ${colors.text}`} />
                    </div>
                  </div>
                  
                  <h3 className={`text-center mb-4 ${colors.text}`}>
                    {decision.label}
                  </h3>

                  <div className="space-y-2 mb-4">
                    <p className="text-sm text-gray-700"><strong>เงื่อนไข:</strong></p>
                    {decision.conditions.map((condition, idx) => (
                      <div key={idx} className="flex items-start text-sm text-gray-700">
                        <span className={`mr-2 ${colors.text}`}>✓</span>
                        <span>{condition}</span>
                      </div>
                    ))}
                  </div>

                  {/* Action */}
                  <div className={`bg-white rounded-lg p-3 border-2 ${colors.border} text-center`}>
                    <p className="text-sm text-gray-600 mb-1 m-0">คลิกปุ่ม:</p>
                    <p className={`m-0 ${colors.text}`}>
                      <strong>{decision.action}</strong>
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-8 bg-gray-100 rounded-lg p-4">
        <p className="text-center text-gray-700 text-sm m-0">
          💡 <strong>วิธีใช้:</strong> อ่านเงื่อนไขแต่ละทาง → เลือกทางที่ตรงกับสถานการณ์ → คลิกปุ่มตามที่แนะนำ
        </p>
      </div>
    </div>
  );
};
