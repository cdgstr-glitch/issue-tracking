import { ReactNode } from 'react';
import { useAuth, UserRole } from '../contexts/AuthContext';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Button } from './ui/button';
import { ShieldAlert } from 'lucide-react';

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles?: UserRole[];
  requireAuth?: boolean;
}

export function ProtectedRoute({ 
  children, 
  allowedRoles,
  requireAuth = true 
}: ProtectedRouteProps) {
  const { user, isAuthenticated, isLoading, logout, activeRole } = useAuth();

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">กำลังโหลด...</p>
        </div>
      </div>
    );
  }

  // Check authentication
  if (requireAuth && !isAuthenticated) {
    return null; // Will be handled by App.tsx routing
  }

  // Check role permissions
  // ✅ Update: Check activeRole instead of user.role to support Role Switching and Customer
  if (allowedRoles && !allowedRoles.includes(activeRole)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="max-w-md w-full">
          <Alert variant="destructive" className="mb-4">
            <ShieldAlert className="h-5 w-5" />
            <AlertTitle>ไม่มีสิทธิ์เข้าถึง</AlertTitle>
            <AlertDescription>
              คุณไม่มีสิทธิ์เข้าถึงส่วนนี้ของระบบ
              <br />
              <span className="text-sm mt-2 block">
                บทบาทของคุณ: <strong>{activeRole}</strong>
              </span>
            </AlertDescription>
          </Alert>
          <div className="flex gap-2">
            <Button
              onClick={() => window.history.back()}
              variant="outline"
              className="flex-1"
            >
              ย้อนกลับ
            </Button>
            <Button
              onClick={logout}
              variant="default"
              className="flex-1"
            >
              ออกจากระบบ
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
