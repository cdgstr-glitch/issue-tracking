import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { User } from 'lucide-react';
import { db } from '../lib/mockDb/client'; // ✅ Use DB client

interface AssigneeSelectorProps {
  tier: 1 | 2 | 3;
  projectId?: string;
  value: string; // userId หรือ "auto"
  onChange: (value: string) => void;
  disabled?: boolean;
  label?: string;
  currentUserId?: string; // เพิ่ม prop สำหรับกรองตัวเองออก
}

export function AssigneeSelector({
  tier,
  projectId,
  value,
  onChange,
  disabled = false,
  label = 'มอบหมายให้',
  currentUserId,
}: AssigneeSelectorProps) {
  // Get users based on tier and project
  // In real implementation, we might filter by project too if users are assigned to projects.
  // For now, we filter by tier.
  let users = db.users.getAll().filter(u => u.tier === tier);

  console.log('🔍 [AssigneeSelector Debug]', {
    tier,
    projectId,
    totalUsers: users.length,
    userNames: users.map(u => u.fullName),
    currentUserId
  });

  // Filter out current user from the list
  if (currentUserId) {
    users = users.filter(user => user.id !== currentUserId);
    console.log('✅ After filtering currentUser:', users.length, 'users remaining');
  }

  // Filter out Admin users (primaryRole = 'admin') when escalating to same tier
  // เพื่อป้องกันส่งงานให้ Admin เมื่อส่งให้เพื่อนร่วมทีม
  users = users.filter(user => user.role !== 'admin'); // Assuming 'role' is the field for primaryRole
  console.log('✅ After filtering Admin:', users.length, 'users remaining');

  const tierLabel = tier === 1 ? 'Tier 1' : tier === 2 ? 'Tier 2 (SA)' : 'Tier 3 (Specialist)';

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-gray-700 flex items-center gap-2">
        <User className="h-4 w-4" />
        {label}
      </label>
      
      <Select value={value} onValueChange={onChange} disabled={disabled}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder={`เลือกผู้รับผิดชอบ ${tierLabel}`} />
        </SelectTrigger>
        <SelectContent>
          {/* Auto-assign option */}
          <SelectItem value="auto">
            <div className="flex items-center gap-2">
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs">
                ✨
              </div>
              <div>
                <div className="font-medium">มอบหมายอัตโนมัติ</div>
                <div className="text-xs text-gray-500">ระบบเลือกผู้รับผิดชอบให้อัตโนมัติ</div>
              </div>
            </div>
          </SelectItem>

          {/* Divider */}
          {users.length > 0 && (
            <div className="border-t my-1"></div>
          )}

          {/* User list */}
          {users.length > 0 ? (
            users.map((user) => (
              <SelectItem key={user.id} value={user.id}>
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gray-200 text-gray-700 text-xs font-medium">
                    {user.fullName.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium">{user.fullName}</div>
                    <div className="text-xs text-gray-500">{user.email}</div>
                  </div>
                </div>
              </SelectItem>
            ))
          ) : (
            <SelectItem value="no-users" disabled>
              <div className="text-sm text-gray-500">
                ไม่พบผู้ใช้งานใน {tierLabel}
              </div>
            </SelectItem>
          )}
        </SelectContent>
      </Select>

      {/* Helper text */}
      <p className="text-xs text-gray-500">
        {value === 'auto' 
          ? 'ระบบจะเลือกผู้ที่มีงานน้อยที่สุดใน ' + tierLabel
          : users.find(u => u.id === value)
          ? `จะมอบหมายให้: ${users.find(u => u.id === value)?.fullName}`
          : `เลือกผู้รับผิดชอบใน ${tierLabel}`
        }
      </p>
    </div>
  );
}
