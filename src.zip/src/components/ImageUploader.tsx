import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Upload, X, File, Image as ImageIcon } from 'lucide-react';
import { Attachment } from '../types';

interface ImageUploaderProps {
  onUpload: (files: Attachment[]) => void;
  existingFiles?: Attachment[];
  maxFiles?: number;
  maxSizeMB?: number;
}

export function ImageUploader({ 
  onUpload, 
  existingFiles = [], 
  maxFiles = 5,
  maxSizeMB = 10 
}: ImageUploaderProps) {
  const [files, setFiles] = useState<Attachment[]>(existingFiles);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (uploadedFiles: FileList | null) => {
    if (!uploadedFiles) return;

    const maxSizeBytes = maxSizeMB * 1024 * 1024;
    const newFiles: Attachment[] = [];

    for (let i = 0; i < uploadedFiles.length && files.length + newFiles.length < maxFiles; i++) {
      const file = uploadedFiles[i];
      
      // Check file size
      if (file.size > maxSizeBytes) {
        alert(`ไฟล์ ${file.name} มีขนาดใหญ่เกิน ${maxSizeMB}MB`);
        continue;
      }

      // Convert to data URL
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.readAsDataURL(file);
      });

      const attachment: Attachment = {
        id: `file-${Date.now()}-${i}`,
        filename: file.name,
        fileSize: file.size,
        fileType: file.type,
        uploadedBy: 'current-user', // Replace with actual user ID
        uploadedAt: new Date(),
        url: dataUrl,
      };

      newFiles.push(attachment);
    }

    const updatedFiles = [...files, ...newFiles];
    setFiles(updatedFiles);
    onUpload(updatedFiles);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files);
  };

  const removeFile = (fileId: string) => {
    const updatedFiles = files.filter(f => f.id !== fileId);
    setFiles(updatedFiles);
    onUpload(updatedFiles);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const isImage = (fileType: string) => fileType.startsWith('image/');

  return (
    <div className="space-y-3">
      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
          dragActive 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*,.pdf,.doc,.docx,.txt"
          onChange={handleChange}
          className="hidden"
        />
        
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-3" />
        <p className="text-sm text-gray-700 mb-2">
          ลากไฟล์มาวางที่นี่ หรือ{' '}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-blue-600 hover:text-blue-700 underline"
          >
            เลือกไฟล์
          </button>
        </p>
        <p className="text-xs text-gray-500">
          รองรับ: รูปภาพ, PDF, DOC, TXT (สูงสุด {maxSizeMB}MB ต่อไฟล์, {maxFiles} ไฟล์สูงสุด)
        </p>
        {files.length >= maxFiles && (
          <p className="text-xs text-red-600 mt-2">
            อัพโหลดได้สูงสุด {maxFiles} ไฟล์เท่านั้น
          </p>
        )}
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm text-gray-600">
            ไฟล์ที่อัพโหลด ({files.length}/{maxFiles})
          </p>
          <div className="space-y-2">
            {files.map((file) => (
              <div
                key={file.id}
                className="flex items-center gap-3 p-3 border rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                {/* File Icon/Preview */}
                {isImage(file.fileType) ? (
                  <div className="relative w-12 h-12 rounded overflow-hidden bg-gray-200 shrink-0">
                    <img
                      src={file.url}
                      alt={file.filename}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded bg-gray-200 flex items-center justify-center shrink-0">
                    <File className="h-6 w-6 text-gray-500" />
                  </div>
                )}

                {/* File Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900 truncate">
                    {file.filename}
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatFileSize(file.fileSize)}
                  </p>
                </div>

                {/* Remove Button */}
                <button
                  type="button"
                  onClick={() => removeFile(file.id)}
                  className="p-1 hover:bg-red-100 rounded transition-colors shrink-0"
                >
                  <X className="h-4 w-4 text-red-600" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Component สำหรับแสดงรูปภาพที่อัพโหลดแล้ว (ใช้ในหน้า Detail)
export function AttachmentDisplay({ attachments }: { attachments: Attachment[] }) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  if (attachments.length === 0) return null;

  const images = attachments.filter(a => a.fileType.startsWith('image/'));
  const otherFiles = attachments.filter(a => !a.fileType.startsWith('image/'));

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <File className="h-4 w-4 text-gray-500" />
        <h3 className="text-sm">
          ไฟล์แนบ ({attachments.length})
        </h3>
      </div>

      {/* Images */}
      {images.length > 0 && (
        <div>
          <p className="text-xs text-gray-500 mb-2">รูปภาพ ({images.length})</p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {images.map((attachment) => (
              <div
                key={attachment.id}
                className="relative aspect-square rounded-lg overflow-hidden bg-gray-100 cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => setSelectedImage(attachment.url)}
              >
                <img
                  src={attachment.url}
                  alt={attachment.filename}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 truncate">
                  {attachment.filename}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Other Files */}
      {otherFiles.length > 0 && (
        <div>
          <p className="text-xs text-gray-500 mb-2">ไฟล์เอกสาร ({otherFiles.length})</p>
          <div className="space-y-2">
            {otherFiles.map((attachment) => (
              <a
                key={attachment.id}
                href={attachment.url}
                download={attachment.filename}
                className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 rounded bg-gray-100 flex items-center justify-center shrink-0">
                  <File className="h-5 w-5 text-gray-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900 truncate">
                    {attachment.filename}
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatFileSize(attachment.fileSize)}
                  </p>
                </div>
                <Upload className="h-4 w-4 text-gray-400 transform rotate-180" />
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Image Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            onClick={() => setSelectedImage(null)}
            className="absolute top-4 right-4 text-white hover:text-gray-300 z-10"
          >
            <X className="h-8 w-8" />
          </button>
          <img
            src={selectedImage}
            alt="Preview"
            className="max-w-[90vw] max-h-[90vh] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}