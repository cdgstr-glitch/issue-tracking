/**
 * 📁 Project Selector Component
 *
 * @description Component สำหรับเลือกโครงการ (ไม่ใช่ Modal)
 * @version 1.1 - Laravel-ready: projectStatus + correct effects
 */

import { useState, useMemo, useEffect } from 'react';
import { Project } from '../types';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Folder } from 'lucide-react';
import { getProjectsByOrganization } from '../lib/utils/projectUtils';
import { PaginationWithSelector } from './ui/pagination-with-selector';

interface ProjectSelectorProps {
  organizationId: string;
  projects: Project[];
  value: string;
  onChange: (projectId: string) => void;
  placeholder?: string;
}

export function ProjectSelector({
  organizationId,
  projects,
  value,
  onChange,
  placeholder = 'เลือกโครงการ...'
}: ProjectSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // กรองโครงการตาม organizationId และ search
  const filteredProjects = useMemo(() => {
    const orgProjects = getProjectsByOrganization(organizationId, projects);

    if (!searchTerm.trim()) return orgProjects;

    const search = searchTerm.toLowerCase();
    return orgProjects.filter(project =>
      project.projectName.toLowerCase().includes(search) ||
      project.projectCode.toLowerCase().includes(search) ||
      (project.description?.toLowerCase().includes(search) ?? false)
    );
  }, [organizationId, projects, searchTerm]);

  // Reset to page 1 when search changes (✅ must be useEffect)
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  // Pagination
  const safeItemsPerPage = Number.isFinite(itemsPerPage) && itemsPerPage > 0 ? itemsPerPage : 10;
  const totalPages = Math.max(1, Math.ceil(filteredProjects.length / safeItemsPerPage));
  const safeCurrentPage = Math.min(Math.max(1, currentPage), totalPages);

  const startIndex = (safeCurrentPage - 1) * safeItemsPerPage;
  const endIndex = startIndex + safeItemsPerPage;
  const paginatedProjects = filteredProjects.slice(startIndex, endIndex);

  // Reset to page 1 when items per page changes
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    const n = Number(newItemsPerPage);
    setItemsPerPage(Number.isFinite(n) && n > 0 ? n : 10);
    setCurrentPage(1);
  };

  const getStatusBadgeColor = (projectStatus: string) => {
    switch (projectStatus) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'on_hold':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusLabel = (projectStatus: string) => {
    const labels: Record<string, string> = {
      active: 'ดำเนินการ',
      on_hold: 'พักชั่วคราว',
      completed: 'เสร็จสิ้น',
      cancelled: 'ยกเลิก'
    };
    return labels[projectStatus] || projectStatus;
  };

  return (
    <div className="flex flex-col" style={{ maxHeight: 'calc(90vh - 400px)' }}>
      {/* Header */}
      <div className="flex-shrink-0 mb-4">
        <div className="text-sm text-gray-600 mb-2">
          เลือกโครงการที่ต้องการบันทึกเคส ({filteredProjects.length} รายการ)
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder={placeholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {/* Project List - scroll ได้ */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-2 mb-4" style={{ minHeight: '200px', maxHeight: '400px' }}>
        {paginatedProjects.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Folder className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p>ไม่พบโครงการที่ค้นหา</p>
            <p className="text-sm mt-1">ลองค้นหาด้วยคำอื่น</p>
          </div>
        ) : (
          paginatedProjects.map((project) => {
            const isSelected = value === project.id;

            return (
              <button
                key={project.id}
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onChange(project.id);
                }}
                className={`
                  w-full text-left p-4 rounded-lg border-2 transition-all
                  hover:border-blue-300 hover:bg-blue-50
                  ${isSelected ? 'border-blue-500 bg-blue-50 shadow-md' : 'border-gray-200 bg-white'}
                `}
              >
                {/* Header: Code + Status */}
                <div className="flex items-center gap-2 mb-2">
                  <Badge
                    variant="outline"
                    className={`text-xs font-semibold ${isSelected ? 'bg-blue-600 text-white border-blue-600' : 'bg-white'}`}
                  >
                    {project.projectCode}
                  </Badge>

                  <Badge
                    variant="outline"
                    className={`text-xs ${getStatusBadgeColor(project.projectStatus)}`}
                  >
                    {getStatusLabel(project.projectStatus)}
                  </Badge>
                </div>

                {/* Project Name */}
                <h4 className={`text-sm font-medium mb-1 ${isSelected ? 'text-blue-900' : 'text-gray-900'}`}>
                  {project.projectName}
                </h4>

                {/* Description */}
                {project.description && (
                  <p className="text-xs text-gray-500 line-clamp-2">
                    {project.description}
                  </p>
                )}
              </button>
            );
          })
        )}
      </div>

      {/* Pagination */}
      <div className="flex-shrink-0 mt-4 pt-4 border-t">
        {Math.ceil(filteredProjects.length / safeItemsPerPage) > 1 && (
          <PaginationWithSelector
            currentPage={safeCurrentPage}
            totalPages={Math.ceil(filteredProjects.length / safeItemsPerPage)}
            totalItems={filteredProjects.length}
            itemsPerPage={safeItemsPerPage}
            onPageChange={setCurrentPage}
            onItemsPerPageChange={handleItemsPerPageChange}
            startIndex={startIndex}
            endIndex={endIndex}
          />
        )}
      </div>
    </div>
  );
}
