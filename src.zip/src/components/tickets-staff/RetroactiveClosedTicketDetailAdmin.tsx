import { can, CAPABILITIES, isTier1 } from '../../lib/permissions';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '../ui/breadcrumb';
import type { HydratedTicket } from '../../lib/mockDb/client';
import { User as UserType } from '../../types';
import { RetroactiveClosedTicketDetailContent } from './RetroactiveClosedTicketDetailContent';

interface RetroactiveClosedTicketDetailAdminProps {
  ticket: HydratedTicket | null;
  user: UserType | null;
  onNavigate: (path: string, ticketId?: string) => void;
}

export function RetroactiveClosedTicketDetailAdmin({ ticket, user, onNavigate }: RetroactiveClosedTicketDetailAdminProps) {
  
  if (!ticket) {
    return (
      <div className="p-6 text-sm text-gray-600">ไม่พบข้อมูลเคส</div>
    );
  }
return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink 
                onClick={() => onNavigate('/admin')}
                className="cursor-pointer"
              >
                Dashboard
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink 
                onClick={() => {
                  const userRoles = user?.roles || [];
                  if (isTier1(user) || userRoles.includes('tier2') || userRoles.includes('tier3') || can(user, CAPABILITIES.MANAGE_USERS)) {
                    onNavigate('/admin/staff-closed-tickets');
                  } else {
                    onNavigate('/closed-tickets');
                  }
                }}
                className="cursor-pointer"
              >
                เคสที่ปิดย้อนหลัง
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>#{ticket.ticketNumber}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      <RetroactiveClosedTicketDetailContent ticket={ticket} />
    </div>
  );
}
