import { Header } from '../layout/Header';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '../ui/breadcrumb';
import type { HydratedTicket } from '../../lib/mockDb/client';
import { User as UserType } from '../../types';
import { RetroactiveClosedTicketDetailContent } from './RetroactiveClosedTicketDetailContent';

interface RetroactiveClosedTicketDetailStaffProps {
  ticket: HydratedTicket | null;
  user: UserType | null;
  onNavigate: (path: string, ticketId?: string) => void;
}

export function RetroactiveClosedTicketDetailStaff({ ticket, user, onNavigate }: RetroactiveClosedTicketDetailStaffProps) {
  
  if (!ticket) {
    return (
      <div className="p-6 text-sm text-gray-600">ไม่พบข้อมูลเคส</div>
    );
  }
return (
    <div className="min-h-screen bg-gray-50">
      <Header
        user={{
          fullName: user?.fullName || '',
          role: user?.role || 'staff'
        }}
        onNavigate={onNavigate}
        currentPath="/closed-tickets/detail"
        showSearch={false}
      />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink 
                  onClick={() => onNavigate('/')}
                  className="cursor-pointer"
                >
                  หน้าแรก
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink 
                  onClick={() => onNavigate('/closed-tickets')}
                  className="cursor-pointer"
                >
                  เคสที่ปิดย้อนหลัง
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>#{ticket.ticketNumber}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>

        <RetroactiveClosedTicketDetailContent ticket={ticket} />
      </div>
    </div>
  );
}
