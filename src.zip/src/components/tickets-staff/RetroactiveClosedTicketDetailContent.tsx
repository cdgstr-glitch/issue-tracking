import { formatDate } from '../../lib/utils';
import { extractHashtags, removeHashtags } from '../../lib/hashtagUtils';
import {
  User,
  Mail,
  Phone,
  Calendar,
  Clock,
  MessageSquare,
  Paperclip,
  Briefcase,
  FileText,
  Building2,
  Package,
  ShieldCheck,
} from 'lucide-react';
import { Badge } from '../ui/badge';
import { SLAIndicator } from '../SLAIndicator';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { db } from '../../lib/mockDb/client';
import { StatusBadge } from '../StatusBadge';
import { PriorityBadge } from '../PriorityBadge';
import { ChannelBadge } from '../ChannelBadge';
import { TicketTimeline } from '../TicketTimeline';
import type { HydratedTicket } from '../../lib/mockDb/client';

interface RetroactiveClosedTicketDetailContentProps {
  ticket: HydratedTicket;
}

export function RetroactiveClosedTicketDetailContent({ ticket }: RetroactiveClosedTicketDetailContentProps) {
  const customerData = ticket.customerName
    ? {
        name: ticket.customerName,
        email: ticket.customerEmail,
        phone: ticket.customerPhone,
        company: ticket.department,
      }
    : null;

  const createdByUser = ticket.createdBy ? db.users.getById(ticket.createdBy) : null;
  const closedByUser = ticket.closedBy ? db.users.getById(ticket.closedBy) : null;
  const resolvedByUser = ticket.resolvedBy ? db.users.getById(ticket.resolvedBy) : null;
  const assignedToUser = ticket.assignedTo ? db.users.getById(ticket.assignedTo) : null;

  const hashtags = extractHashtags(ticket.title);
  const titleWithoutHashtags = removeHashtags(ticket.title);
  const ticketTimeline = db.timeline.getByTicketId(ticket.id);

  return (
    <>
      <div className="mb-6">
        <div className="rounded-lg bg-gray-50 border border-gray-200 p-4 mb-4">
          <div className="flex items-start gap-3">
            <FileText className="h-5 w-5 text-gray-600 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-medium text-gray-900">เคสที่ปิดย้อนหลัง (Read-only)</h3>
              <p className="text-sm text-gray-600 mt-1">
                เคสนี้เป็นการบันทึกย้อนหลังเพื่อเก็บประวัติ ไม่สามารถแก้ไข รับเคส หรือส่งต่อได้
              </p>
            </div>
          </div>
        </div>

        <h1 className="text-2xl sm:text-3xl mb-2">เคส #{ticket.ticketNumber}</h1>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={ticket.status} />
          <PriorityBadge priority={ticket.priority} />
          <ChannelBadge channel={ticket.channel} />
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            บันทึกย้อนหลัง
          </Badge>
          {ticket.type && (
            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
              {ticket.type === 'incident'
                ? 'Incident'
                : ticket.type === 'service_request'
                  ? 'Service Request'
                  : 'Security Incident'}
            </Badge>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>รายละเอียดเคส</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">หัวเรื่อง</h3>
                <div className="flex flex-wrap items-baseline gap-2">
                  <p className="text-base m-0">{titleWithoutHashtags}</p>
                  {hashtags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {hashtags.map((tag, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="bg-blue-100 text-blue-800 hover:bg-blue-200 text-xs font-normal"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">คำอธิบาย</h3>
                <p className="whitespace-pre-wrap text-gray-700">{ticket.description}</p>
              </div>

              {/* ถ้า attachments ใน HydratedTicket รับประกันเป็น [] เสมอ คุณสามารถตัด ticket.attachments && ได้เช่นกัน */}
              {ticket.attachments && ticket.attachments.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2 flex items-center gap-2">
                    <Paperclip className="h-4 w-4" />
                    ไฟล์แนบ ({ticket.attachments.length})
                  </h3>
                  <div className="space-y-2">
                    {ticket.attachments.map((file: any, index: number) => (
                      <div
                        key={index}
                        className="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 p-3"
                      >
                        <Paperclip className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-700">{typeof file === 'string' ? file : file.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {(ticket.solution || ticket.closureNotes) && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-green-600" />
                  วิธีแก้ไขและการปิดเคส
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {ticket.solution && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">วิธีแก้ไข</h3>
                    <div className="rounded-lg bg-green-50 p-4 border border-green-200">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{ticket.solution}</p>
                    </div>
                  </div>
                )}

                {ticket.closureNotes && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">บันทึกการปิดเคส</h3>
                    <div className="rounded-lg bg-blue-50 p-4 border border-blue-200">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{ticket.closureNotes}</p>
                    </div>
                  </div>
                )}

                {resolvedByUser && (
                  <div className="flex items-center gap-2 text-sm text-gray-600 border-b border-gray-100 pb-3 mb-3">
                    <User className="h-4 w-4 text-green-600" />
                    <span>
                      แก้ไขโดย: <strong>{resolvedByUser.fullName}</strong>
                    </span>
                    {ticket.resolvedAt && (
                      <>
                        <span className="mx-1">•</span>
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span>{formatDate(ticket.resolvedAt)}</span>
                      </>
                    )}
                  </div>
                )}

                {closedByUser && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <User className="h-4 w-4 text-gray-500" />
                    <span>
                      ปิดโดย: <strong>{closedByUser.fullName}</strong>
                    </span>
                    {ticket.closedAt && (
                      <>
                        <span className="mx-1">•</span>
                        <Calendar className="h-4 w-4" />
                        <span>{formatDate(ticket.closedAt)}</span>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {ticketTimeline.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>ประวัติการดำเนินการ</CardTitle>
              </CardHeader>
              <CardContent>
                <TicketTimeline events={ticketTimeline} />
              </CardContent>
            </Card>
          )}

          {/* ✅ Laravel-ready semantics: comments = [] always */}
          {ticket.comments.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  ความคิดเห็น ({ticket.comments.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {ticket.comments.map((comment: any) => (
                    <div
                      key={comment.id}
                      className={`rounded-lg p-4 ${
                        comment.isInternal ? 'bg-yellow-50 border border-yellow-200' : 'bg-gray-50 border border-gray-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <span className="text-sm font-medium">{comment.author}</span>
                          <Badge variant="outline" className="text-xs">
                            {comment.authorRole}
                          </Badge>
                          {comment.isInternal && (
                            <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 text-xs">
                              Internal
                            </Badge>
                          )}
                        </div>
                        <span className="text-xs text-gray-500">{formatDate(comment.createdAt)}</span>
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{comment.content}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-6">
          {ticket.dueDate && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  SLA Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <SLAIndicator
                  createdAt={ticket.createdAt}
                  dueDate={ticket.dueDate}
                  status={ticket.status}
                  resolvedAt={ticket.resolvedAt}
                  closedAt={ticket.closedAt}
                />
              </CardContent>
            </Card>
          )}

          {customerData && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  ข้อมูลลูกค้า
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <User className="h-4 w-4 text-gray-400 mt-1" />
                  <div>
                    <p className="text-sm font-medium text-gray-500">ชื่อ</p>
                    <p className="text-sm">{customerData.name}</p>
                  </div>
                </div>

                {customerData.email && (
                  <div className="flex items-start gap-3">
                    <Mail className="h-4 w-4 text-gray-400 mt-1" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">อีเมล</p>
                      <p className="text-sm">{customerData.email}</p>
                    </div>
                  </div>
                )}

                {customerData.phone && (
                  <div className="flex items-start gap-3">
                    <Phone className="h-4 w-4 text-gray-400 mt-1" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">เบอร์โทร</p>
                      <p className="text-sm">{customerData.phone}</p>
                    </div>
                  </div>
                )}

                {customerData.company && (
                  <div className="flex items-start gap-3">
                    <Briefcase className="h-4 w-4 text-gray-400 mt-1" />
                    <div>
                      <p className="text-sm font-medium text-gray-500">หน่วยงาน</p>
                      <p className="text-sm">{customerData.company}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {(ticket.projectName || ticket.projectCode) && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  โครงการ
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {ticket.projectCode && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">รหัสโครงการ</p>
                    <Badge variant="outline" className="mt-1">
                      {ticket.projectCode}
                    </Badge>
                  </div>
                )}
                {ticket.projectName && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">ชื่อโครงการ</p>
                    <p className="text-sm">{ticket.projectName}</p>
                  </div>
                )}
                {ticket.projectShortName && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">ชื่อย่อ</p>
                    <Badge variant="secondary">{ticket.projectShortName}</Badge>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {(createdByUser || assignedToUser) && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  ผู้เกี่ยวข้อง
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {createdByUser && (
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-2">บันทึกโดย</p>
                    <div className="flex items-center gap-2 rounded-lg bg-gray-50 p-3">
                      <User className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm font-medium">{createdByUser.fullName}</p>
                        <p className="text-xs text-gray-500">{createdByUser.email}</p>
                      </div>
                    </div>
                  </div>
                )}

                {assignedToUser && (
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-2">ได้รับมอบหมาย</p>
                    <div className="flex items-center gap-2 rounded-lg bg-blue-50 p-3">
                      <User className="h-4 w-4 text-blue-600" />
                      <div>
                        <p className="text-sm font-medium">{assignedToUser.fullName}</p>
                        <p className="text-xs text-gray-500">{assignedToUser.email}</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                ข้อมูลเคส
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <p className="font-medium text-gray-500 mb-1">วันที่สร้าง</p>
                <p>{formatDate(ticket.createdAt)}</p>
              </div>

              {ticket.resolvedAt && (
                <div>
                  <p className="font-medium text-gray-500 mb-1">วันที่แก้ไขเสร็จสิ้น</p>
                  <p>{formatDate(ticket.resolvedAt)}</p>
                </div>
              )}

              {ticket.closedAt && (
                <div>
                  <p className="font-medium text-gray-500 mb-1">วันที่ปิด</p>
                  <p>{formatDate(ticket.closedAt)}</p>
                </div>
              )}

              {ticket.category && (
                <div>
                  <p className="font-medium text-gray-500 mb-1">หมวดหมู่</p>
                  <Badge variant="outline">{ticket.category}</Badge>
                </div>
              )}

              {(ticket.productName || ticket.product) && (
                <div>
                  <p className="font-medium text-gray-500 mb-1 flex items-center gap-1">
                    <Package className="h-3 w-3" />
                    ผลิตภัณฑ์
                  </p>
                  <Badge variant="secondary">{ticket.productName || ticket.product}</Badge>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
