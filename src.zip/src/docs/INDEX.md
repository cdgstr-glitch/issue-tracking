# 📚 CDGS Issue Tracking Platform - Documentation Index

**Last Updated:** 2026-01-27  
**Total Documents:** 80+ files

---

## 🎯 เอกสารหลัก (Core Documentation)

### 📖 เอกสารสำคัญที่ควรอ่าน:

1. [**PROJECT_OVERVIEW.md**](features/PROJECT_OVERVIEW.md) - ภาพรวมโปรเจค
2. [**PERMISSION_MATRIX.md**](technical/PERMISSION_MATRIX.md) - สิทธิ์การใช้งานทั้งหมด
3. [**WORKFLOW.md**](features/WORKFLOW.md) - ขั้นตอนการทำงานของระบบ
4. [**NAVIGATION_MENU.md**](features/NAVIGATION_MENU.md) - เมนูสำหรับแต่ละ Role
5. [**ROLE_SYSTEM_ACTIVE_ROLE_SWITCHING.md**](features/ROLE_SYSTEM_ACTIVE_ROLE_SWITCHING.md) - ⭐ **กฎเหล็ก** ระบบบทบาทและการสลับบทบาท

---

## 🗂️ หมวดหมู่เอกสาร

### 1. 🔐 **Permissions & Roles** (`/docs/features/`, `/docs/technical/`)

| Document | Description | Status |
|----------|-------------|--------|
| [**ROLE_SYSTEM_ACTIVE_ROLE_SWITCHING.md**](features/ROLE_SYSTEM_ACTIVE_ROLE_SWITCHING.md) | ⚠️ **กฎเหล็ก** - Role System & Active Role Switching | ✅ **สำคัญ!** |
| [PERMISSION_MATRIX.md](technical/PERMISSION_MATRIX.md) | Permission Matrix ทั้งระบบ | ✅ |
| [STAFF_ROLE_DOCUMENTATION.md](features/STAFF_ROLE_DOCUMENTATION.md) | เอกสาร Staff Role | ✅ |
| [TIER1_STAFF_MULTI_ROLE_UPDATE.md](features/TIER1_STAFF_MULTI_ROLE_UPDATE.md) | Update for Tier1 & Staff roles | ✅ |

### 2. ⚙️ **Features** (`/docs/features/`)

| Document | Description | Status |
|----------|-------------|--------|
| [EMAIL_TEMPLATES.md](features/EMAIL_TEMPLATES.md) | Email Templates ทั้ง 6 ฉบับ | ✅ |
| [PRODUCT_FILTERING_BY_PROJECT.md](features/PRODUCT_FILTERING_BY_PROJECT.md) | Dynamic Product Selection | ✅ |
| [COMMENT_SYSTEM_UPDATE.md](features/COMMENT_SYSTEM_UPDATE.md) | ระบบความคิดเห็น | ✅ |
| [ASSIGNEE_FILTER_FEATURE.md](features/ASSIGNEE_FILTER_FEATURE.md) | ฟีเจอร์ Assignee Filter | ✅ |
| [ASSIGNEE_FILTER_PENDING_PAGE.md](features/ASSIGNEE_FILTER_PENDING_PAGE.md) | Filter หน้า Pending | ✅ |
| [CUSTOMER_ACCOUNTS_MAGIC_LINK.md](features/CUSTOMER_ACCOUNTS_MAGIC_LINK.md) | Magic Link Login | ✅ |
| [CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md](features/CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md) | Customer Workflow | ✅ |
| [PRODUCT_MANAGEMENT.md](features/PRODUCT_MANAGEMENT.md) | จัดการผลิตภัณฑ์ | ✅ |
| [PROJECT_SELECTION_FEATURES.md](features/PROJECT_SELECTION_FEATURES.md) | การเลือก Project | ✅ |
| [REPORTS_ACCESS_CONTROL.md](features/REPORTS_ACCESS_CONTROL.md) | สิทธิ์เข้าถึงรายงาน | ✅ |
| [ticket-creation-timeline.md](features/ticket-creation-timeline.md) | Ticket Timeline | ✅ |

### 3. 🔧 **Technical** (`/docs/technical/`)

| Document | Description | Status |
|----------|-------------|--------|
| [ADMIN_ACCESS_CONTROL.md](technical/ADMIN_ACCESS_CONTROL.md) | การตรวจสอบสิทธิ์ Admin | ✅ |
| [PROJECT_CODE_CONSISTENCY_CHECK.md](technical/PROJECT_CODE_CONSISTENCY_CHECK.md) | ตรวจสอบรูปแบบรหัสโครงการ | ✅ |
| [PROJECT_CODE_FORMAT.md](technical/PROJECT_CODE_FORMAT.md) | รูปแบบรหัสโครงการ | ✅ |
| [PROJECT_CODE_FIX_REPORT.md](technical/PROJECT_CODE_FIX_REPORT.md) | รายงานแก้ไข Project Code | ✅ |
| [ORGANIZATION_STRUCTURE.md](technical/ORGANIZATION_STRUCTURE.md) | โครงสร้าง Organization | ✅ |
| [ORGANIZATION_STATUS.md](technical/ORGANIZATION_STATUS.md) | สถานะ Organization | ✅ |
| [DATA_CONSISTENCY_REPORT.md](technical/DATA_CONSISTENCY_REPORT.md) | รายงานความสอดคล้องข้อมูล | ✅ |
| [SYSTEM_ARCHITECTURE.md](technical/SYSTEM_ARCHITECTURE.md) | สถาปัตยกรรมระบบ | ✅ |
| [SYSTEM_ORGANIZATION_PLAN.md](technical/SYSTEM_ORGANIZATION_PLAN.md) | แผนจัดระเบียบระบบ | ✅ |
| [REFACTORING_PLAN.md](technical/REFACTORING_PLAN.md) | แผน Refactoring | ✅ |
| [TODO_IMPROVEMENTS.md](technical/TODO_IMPROVEMENTS.md) | รายการที่ต้องปรับปรุง | 🔄 |

### 4. 📊 **Mock Data** (`/docs/mock-data/`)

| Document | Description | Status |
|----------|-------------|--------|
| [MOCK_DATA_INVENTORY.md](mock-data/MOCK_DATA_INVENTORY.md) | สารบบข้อมูล Mock | ✅ |
| [MOCK_DATA_RULES.md](mock-data/MOCK_DATA_RULES.md) | 🚨 **กฎเหล็ก Mock Data** | ✅ **สำคัญ!** |
| [MOCK_DATA_GUIDE.md](technical/MOCK_DATA_GUIDE.md) | คู่มือ Mock Data (Technical) | ✅ |
| [MOCK_DATA_CLOSED_BY_FIX.md](mock-data/MOCK_DATA_CLOSED_BY_FIX.md) | แก้ไข Closed By | ✅ |
| [MOCK_DATA_STATUS_FINAL.md](mock-data/MOCK_DATA_STATUS_FINAL.md) | สถานะ Mock Data | ✅ |
| [STAFF_002_MOCK_DATA.md](mock-data/STAFF_002_MOCK_DATA.md) | ข้อมูล Staff-002 | ✅ |

### 5. 👥 **Team & Users** (`/docs/`)

| Document | Description | Status |
|----------|-------------|--------|
| [TEAM_MEMBERS.md](TEAM_MEMBERS.md) | รายชื่อสมาชิกทีม | ✅ |

### 6. 🎨 **Components** (`/docs/technical/`)

| Document | Description | Status |
|----------|-------------|--------|
| [COMMON_COMPONENTS_GUIDE.md](technical/COMMON_COMPONENTS_GUIDE.md) | คู่มือ Components ร่วม | ✅ |
| [COMPONENT_REFACTORING_PLAN.md](technical/COMPONENT_REFACTORING_PLAN.md) | แผน Refactoring Components | ✅ |

---

## 🔍 Quick Find

### ตามหัวข้อ:

- **หาข้อมูล Permissions?** → [PERMISSION_MATRIX.md](technical/PERMISSION_MATRIX.md)
- **หาวิธีใช้งาน?** → [WORKFLOW.md](features/WORKFLOW.md)
- **หาโครงสร้าง Database?** → [MOCK_DATA_INVENTORY.md](mock-data/MOCK_DATA_INVENTORY.md)
- **หาโครงสร้าง Project Code?** → [ORGANIZATION_STRUCTURE.md](technical/ORGANIZATION_STRUCTURE.md)

### ตาม Role:

- **Admin** → [PERMISSION_MATRIX.md](technical/PERMISSION_MATRIX.md)
- **Tier1** → [WORKFLOW.md](features/WORKFLOW.md)
- **Tier2/Tier3** → [WORKFLOW.md](features/WORKFLOW.md)
- **Staff** → [STAFF_ROLE_DOCUMENTATION.md](features/STAFF_ROLE_DOCUMENTATION.md)
- **Customer** → [CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md](features/CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md)

---

## 📝 **Summary**

เอกสารทั้งหมดถูกจัดเก็บเป็นหมวดหมู่ใน:
- `/docs/features/`
- `/docs/technical/`
- `/docs/mock-data/`

เพื่อให้ง่ายต่อการค้นหาและบำรุงรักษา

---

**Last Updated:** 2026-01-27  
**Prepared By:** CDGS Development Team
