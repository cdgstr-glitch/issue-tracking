# 📊 Table Structures - รายการเคส

**Last Updated:** 2025-01-27  
**Version:** 1.1

---

## 📋 สารบัญ

1. [ภาพรวม](#ภาพรวม)
2. [TicketListPage (Staff/Tier/Admin)](#ticketlistpage-stafftieradmin)
3. [CustomerTrackTicketPage (ลูกค้า)](#customertrackticketpage-ลูกค้า)
4. [StaffTrackTicketPage (Staff)](#stafftrackticketpage-staff)
5. [เปรียบเทียบทั้ง 3 แบบ](#เปรียบเทียบทั้ง-3-แบบ)

---

## ภาพรวม

ระบบมี **3 แบบ Table** สำหรับแสดงรายการเคส แยกตาม Role และ Use Case:

| Component | ใช้สำหรับ | Columns | Row Structure |
|-----------|----------|---------|---------------|
| **TicketListPage** | Staff, Tier1-3, Admin | 9 | 2 Rows |
| **CustomerTrackTicketPage** | Customer (ลูกค้า) | 8 | 1 Row |
| **StaffTrackTicketPage** | Staff (เคสที่ตัวเองแจ้ง) | 8 | 1 Row |

---

## TicketListPage (Staff/Tier/Admin)

### 📍 ไฟล์:
`/components/TicketListPage.tsx`

### 🎯 ใช้สำหรับ:
- Staff (เจ้าหน้าที่)
- Tier1, Tier2, Tier3
- Admin

### 📊 Table Structure:

**9 Columns + 2 Rows per Ticket**

```
Row 1 (Full Width):
┌─────────────────────────────────────────────────────────────────────────────┐
│ หัวเรื่อง: [Title] #hashtag1 #hashtag2                                     │
└─────────────────────────────────────────────────────────────────────────────┘

Row 2 (9 Columns):
┌──────────┬──────────┬────────┬──────────┬─────────┬────────┬─────┬─────────┬─────────┐
│ Ticket   │ Customer │ Status │ Priority │ Channel │ ไฟล์   │ SLA │ Updated │ Actions │
└──────────┴──────────┴────────┴──────────┴─────────┴────────┴─────┴─────────┴─────────┘
```

### 📝 Column Details:

| # | Column | Description | Component | Notes |
|---|--------|-------------|-----------|-------|
| 1 | **Ticket** | หมายเลขเคส + ไอคอน | Text + Icon | คลิกเพื่อดูรายละเอียด |
| 2 | **Customer** | ชื่อลูกค้า | Text | Full Name |
| 3 | **Status** | สถานะเคส | `StatusBadge` | new, in_progress, waiting, resolved, closed |
| 4 | **Priority** | ความสำคัญ | `PriorityBadge` | critical, high, medium, low |
| 5 | **Channel** | ช่องทาง | `ChannelBadge` | email, line, phone, web |
| 6 | **ไฟล์** | จำนวนไฟล์แนบ | Icon + Number | Paperclip icon |
| 7 | **SLA** | สถานะ SLA | `SLAIndicator` | เขียว/เหลือง/แดง |
| 8 | **Updated** | เวลาอัพเดต | Relative Time | "2 hours ago" |
| 9 | **Actions** | ดำเนินการ | Dropdown Menu | รายละเอียด, มอบหมาย, ฯลฯ |

### 🎨 Features:

- ✅ **2-Row Structure:** หัวเรื่องแยก row เพื่อแสดงได้ชัดเจน
- ✅ **Actions Dropdown:** ดำเนินการได้เร็ว
- ✅ **Full Data:** แสดงข้อมูลครบถ้วน
- ✅ **Hashtag Display:** แสดงแฮชแท็กใน Row 1
- ✅ **Click to View:** คลิก row ไปหน้ารายละเอียด

### 📱 Responsive:

- **Desktop (≥ md):** Table View
- **Mobile (< md):** Card View

---

## CustomerTrackTicketPage (ลูกค้า)

### 📍 ไฟล์:
`/components/CustomerTrackTicketPage.tsx`

### 🎯 ใช้สำหรับ:
- Customer (ลูกค้า)

### 📊 Table Structure:

**7 Columns + 1 Row per Ticket**

```
┌──────────┬───────────────────┬─────────┬────────┴────────┴─────┴─────────┐
│ หมายเลข  │ หัวเรื่อง         │ ช่องทาง │ สถานะ  │ ไฟล์   │ SLA │ Updated │
│          │ + แฮชแท็ก         │         │        │        │     │         │
└──────────┴───────────────────┴─────────┴────────┴────────┴─────┴─────────┘
```

### 📝 Column Details:

| # | Column | Description | Component | Notes |
|---|--------|-------------|-----------|-------|
| 1 | **หมายเลขเคส** | หมายเลขเคส | Text | คลิกเพื่อดูรายละเอียด |
| 2 | **หัวเรื่อง** | หัวเรื่อง + แฮชแท็ก + หมวดหมู่ | Text + Badges | แสดงแยก row |
| 3 | **ช่องทาง** | ช่องทางการแจ้ง | `ChannelBadge` | web, email, line, phone |
| 4 | **สถานะ** | สถานะเคส | `StatusBadge` | new, in_progress, waiting, resolved, closed |
| 5 | **ไฟล์แนบ** | จำนวนไฟล์แนบ | Icon + Number | Paperclip icon |
| 6 | **SLA** | สถานะ SLA | `SLAIndicator` | เขียว/เหลือง/แดง |
| 7 | **อัปเดตล่าสุด** | เวลาอัพเดต | Relative Time | "2 hours ago" |

### 🎨 Features:

- ✅ **1-Row Structure:** เรียบง่าย ไม่ซับซ้อน
- ❌ **ไม่มี Actions Column:** คลิก row เพื่อดูรายละเอียด
- ❌ **ไม่มี Customer Column:** เห็นเฉพาะเคสตัวเอง
- ❌ **ไม่มี Priority Column:** ไม่จำเป็นสำหรับลูกค้า
- ❌ **ไม่มี "แจ้งโดยเจ้าหน้าที่" Column:** ลูกค้าแจ้งเคสเองทั้งหมด (ผ่าน Web)

### 📱 Responsive:

- **Desktop (≥ md):** Table View
- **Mobile (< md):** Card View

---

## StaffTrackTicketPage (Staff)

### 📍 ไฟล์:
`/components/StaffTrackTicketPage.tsx`

### 🎯 ใช้สำหรับ:
- Staff (เจ้าหน้าที่ที่แจ้งเคสแทนลูกค้า)

### 📊 Table Structure:

**ใช้ `TicketListPage` component แบบเดียวกับ Tier/Admin**

**🔄 เปลี่ยนแปลงล่าสุด (v1.1):**
- ✅ ใช้ `TicketListPage` แทนการสร้างตารางเอง
- ✅ รองรับ Filters (Status, Tier, Priority, Channel, Hashtag)
- ✅ รองรับ View Toggle (Table/Cards)
- ✅ รองรับ Card Views (Desktop & Mobile)
- ❌ ซ่อน Header (ใช้ของ StaffTrackTicketPage แทน)

### 🎨 Features:

- ✅ **Filters:** กรองตาม Status, Priority, Channel, Hashtag เหมือน Admin/Tier
- ✅ **View Toggle:** สลับระหว่าง Table และ Cards ได้
- ✅ **Table View:** แสดงแบบตาราง (Desktop)
- ✅ **Card Views:** แสดงแบบการ์ด (Desktop & Mobile)
- ✅ **Results Summary:** แสดงจำนวนเคส
- ✅ **Pagination:** แบ่งหน้า
- ❌ **ไม่มี Export Buttons:** ซ่อนไว้
- ❌ **ไม่มี Actions Column:** คลิก row เพื่อดูรายละเอียด

### 📱 Responsive:

- **Desktop (≥ md):** Table View
- **Mobile (< md):** Card View

---

## เปรียบเทียบทั้ง 3 แบบ

### 📊 Columns Comparison:

| Feature | TicketListPage | CustomerTrackTicketPage | StaffTrackTicketPage |
|---------|----------------|------------------------|---------------------|
| **Total Columns** | 9 | 8 | 8 |
| **Row Structure** | 2 Rows | 1 Row | 1 Row |
| **Ticket Number** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Title** | ✅ Separate Row | ✅ Column 2 | ✅ Column 2 |
| **Hashtags** | ✅ Row 1 | ✅ Row 1 | ✅ Row 1 |
| **Category** | ❌ No | ❌ No | ✅ Yes (ใต้หัวเรื่อง) |
| **Customer** | ✅ Yes | ❌ No | ✅ Yes |
| **Channel** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Status** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Priority** | ✅ Yes | ❌ No | ✅ Yes |
| **Attachments** | ✅ Yes | ✅ Yes | ✅ Yes |
| **SLA** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Updated** | ✅ Yes | ✅ Yes | ✅ Yes |
| **แจ้งโดยเจ้าหน้าที่** | ❌ No | ✅ Yes | ❌ No |
| **Actions** | ✅ Yes | ❌ No | ❌ No |

### 🎯 Use Cases:

| Component | Role | Use Case | Key Features |
|-----------|------|----------|--------------|
| **TicketListPage** | Staff/Tier/Admin | จัดการเคสทั้งหมด | Full data, Actions dropdown |
| **CustomerTrackTicketPage** | Customer | ติดตามเคสของตัวเอง | Simple, No priority |
| **StaffTrackTicketPage** | Staff | ติดตามเคสที่ตัวเองแจ้ง | Show customer, Show category |

### 📱 Responsive Behavior:

**ทั้ง 3 Component:**
- Desktop (≥ md): Table View
- Mobile (< md): Card View (อัตโนมัติ)

---

## 🔧 Technical Notes

### 📦 Dependencies:

```typescript
// Badge Components
import { StatusBadge } from './StatusBadge';
import { PriorityBadge } from './PriorityBadge';
import { ChannelBadge } from './ChannelBadge';
import { SLAIndicator } from './SLAIndicator';

// Utils
import { formatRelativeTime } from '../lib/utils';
import { extractHashtags, removeHashtags } from '../lib/hashtagUtils';
```

### 🎨 Styling:

- **Table:** Tailwind CSS classes
- **Hover:** `hover:bg-gray-50`
- **Click:** `cursor-pointer`
- **Text Colors:** `text-blue-600` สำหรับ ticket number

### 🔐 Permissions:

- **TicketListPage:** ใช้ `can()` helper
- **CustomerTrackTicketPage:** Customer only
- **StaffTrackTicketPage:** Staff only

---

## 📚 Related Documentation

- [Badge System](../BADGE_SYSTEM_DOCUMENTATION.md)
- [Permissions Guide](../PERMISSIONS_GUIDE.md)
- [Component Inventory](../COMPONENT_INVENTORY_AND_FULLNAME_SUMMARY.md)

---

## 📝 Changelog

| Date | Version | Changes |
|------|---------|------------|
| 2025-01-27 | 1.1 | ✅ Staff ใช้ `TicketListPage` component (รองรับ Filters & View Toggle) |
| 2025-01-22 | 1.0 | Initial documentation |

---

**สำหรับคำถามหรือข้อเสนอแนะ:** กรุณาติดต่อทีมพัฒนา