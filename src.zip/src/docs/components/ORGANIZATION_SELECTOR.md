# 🏢 Organization Selector Component

**Last Updated:** 2026-01-24  
**Version:** 2.0 - Removed Pagination, Inline Display  
**Component:** `/components/OrganizationSelector.tsx`

---

## 🎯 ภาพรวม

Organization Selector เป็น Component สำหรับเลือกหน่วยงาน/องค์กร ใช้เป็น **Step 1** ของ Project Selector Modal ใน CDGS Issue Tracking Platform

---

## 📍 ตำแหน่งการใช้งาน

### 1. Modal เลือกโครงการในปุ่ม "รับเคส" (Tier1)
- **ไฟล์:** `/components/ProjectSelectorModal.tsx`
- **ผู้ใช้:** Tier1 (รับเคสจาก Web ที่ไม่มี projectId)
- **Flow:** เลือกหน่วยงาน → เลือกโครงการ → รับเคส

### 2. Modal เลือกโครงการในหน้า Staff
- **ไฟล์:** `/components/ProjectSelectorModal.tsx`
- **ผู้ใช้:** Staff (บันทึกเคสแทนลูกค้า)
- **Flow:** เลือกหน่วยงาน → เลือกโครงการ → บันทึกเคส

---

## ✨ ฟีเจอร์หลัก

### 🔍 ระบบค้นหา (Real-time Search)

```typescript
// ค้นหาได้ทันทีขณะพิมพ์ ไม่ต้องกดปุ่ม
<Input
  placeholder="ค้นหาชื่อหน่วยงาน, ชื่อย่อ, หรือรหัส..."
  onChange={(e) => setSearchTerm(e.target.value)}
/>
```

**ค้นหาได้จาก 3 ฟิลด์:**
1. ชื่อย่อหน่วยงาน (organizationShortName) - เช่น "ERC", "DGA"
2. ชื่อเต็มหน่วยงาน (organizationName) - เช่น "สำนักงานคณะกรรมการ"
3. รหัสหน่วยงาน (organizationCode) - เช่น "ORG-001"

**ตัวอย่าง:**
- พิมพ์ "ERC" → แสดงหน่วยงานที่มี "ERC" ในชื่อ
- พิมพ์ "พัฒนา" → แสดงหน่วยงานที่มี "พัฒนา" ในชื่อ
- พิมพ์ "001" → แสดงหน่วยงานรหัส ORG-001

---

### 📊 การแสดงผล UI (Version 2.0)

#### **รูปแบบการแสดงรายการ (ใหม่)**

```
┌────────────────────────────────────────────────┐
│ ค้นหา: [_____________________________]        │
│ เลือกหน่วยงานที่ต้องการบันทึกเคส (50 รายการ)│
├────────────────────────────────────────────────┤
│                                                │
│ ┌────────────────────────────────────────────┐ │
│ │ ERC - สำนักงานคณะกรรมการกำกับกิจการพลังงาน│ │ ← บรรทัดเดียว
│ │ 📁 5 โครงการ                               │ │
│ └────────────────────────────────────────────┘ │
│                                                │
│ ┌────────────────────────────────────────────┐ │
│ │ DGA - สำนักงานพัฒนารัฐบาลดิจิทัล          │ │
│ │ 📁 3 โครงการ                               │ │
│ └────────────────────────────────────────────┘ │
│                                                │
│ ... (scroll ได้ทั้งหมด)                       │
│                                                │
└────────────────────────────────────────────────┘
```

#### **รูปแบบเดิม (Version 1.0) - เปลี่ยนแล้ว**

```
❌ เดิม (แยกบรรทัด + Badge):
┌────────────────────────────────────────┐
│ [ERC] 📁 5 โครงการ                     │
│ สำนักงานคณะกรรมการกำกับกิจการพลังงาน  │
└────────────────────────────────────────┘
```

---

### 🎨 UI States

#### **1. Default State (ยังไม่เลือก)**
```
┌──────────────────────────────────┐
│ ERC - สำนักงานคณะกรรมการ...     │
│ 📁 5 โครงการ                     │
└──────────────────────────────────┘
- พื้นหลัง: สีขาว (white)
- ขอบ: สีเทา (border-gray-200)
- ข้อความ: สีเทาเข้ม (text-gray-900)
```

#### **2. Hover State**
```
┌──────────────────────────────────┐
│ ERC - สำนักงานคณะกรรมการ...     │ ← เมาส์ชี้
│ 📁 5 โครงการ                     │
└──────────────────────────────────┘
- พื้นหลัง: สีฟ้าอ่อน (hover:bg-blue-50)
- ขอบ: สีฟ้า (hover:border-blue-300)
```

#### **3. Selected State (เลือกแล้ว)**
```
┌──────────────────────────────────┐
│ ERC - สำนักงานคณะกรรมการ...     │ ✅ เลือกแล้ว
│ 📁 5 โครงการ                     │
└──────────────────────────────────┘
- พื้นหลัง: สีฟ้าอ่อน (bg-blue-50)
- ขอบ: สีฟ้าเข้ม (border-blue-500)
- ข้อความ: สีน้ำเงินเข้ม (text-blue-900)
- เงา: shadow-md
```

#### **4. Empty State (ไม่พบผลลัพธ์)**
```
┌──────────────────────────────────┐
│                                  │
│        🏢                         │
│    ไม่พบหน่วยงานที่ค้นหา        │
│    ลองค้นหาด้วยคำอื่น           │
│                                  │
└──────────────────────────────────┘
```

---

## 🔄 การทำงาน (Flow)

```
User เข้า Modal เลือกโครงการ (Step 1)
  ↓
แสดงรายการหน่วยงานทั้งหมด (50 รายการ)
  ↓
[Option A] พิมพ์ค้นหา
  ↓
  แสดงผลลัพธ์ที่ตรงกับคำค้น
  ↓
[Option B] Scroll ดูรายการ
  ↓
  ดูหน่วยงานทั้งหมดโดย scroll
  ↓
คลิกเลือกหน่วยงาน
  ↓
✅ เก็บ organizationId ไว้ใน State
  ↓
ไปต่อที่ Step 2: เลือกโครงการ
```

---

## 🎛️ Props

```typescript
interface OrganizationSelectorProps {
  organizations: Organization[];        // รายการหน่วยงานทั้งหมด
  projects: Project[];                 // รายการโครงการทั้งหมด (ใช้นับจำนวน)
  selectedOrganizationId?: string;     // ID ของหน่วยงานที่เลือก (Optional)
  onSelectOrganization: (organizationId: string) => void; // Callback เมื่อเลือก
}
```

---

## 📐 การจัดการข้อมูล

### **1. การค้นหา (Search)**

```typescript
const filteredOrganizations = useMemo(() => {
  const searched = searchOrganizations(searchTerm, organizations);
  return sortOrganizationsByShortName(searched, 'asc');
}, [searchTerm, organizations]);
```

- ใช้ `searchOrganizations()` จาก `/lib/utils/organizationUtils.ts`
- เรียงลำดับตาม `organizationShortName` (A-Z)
- Auto-update เมื่อพิมพ์ (Real-time)

### **2. การนับโครงการ**

```typescript
const getProjectCount = (orgId: string) => {
  return countProjectsByOrganization(orgId, projects);
};
```

- ใช้ `countProjectsByOrganization()` จาก `/lib/utils/projectUtils.ts`
- นับโครงการที่ `organizationId` ตรงกับหน่วยงาน
- แสดงผลเป็น: "ไม่มีโครงการ" / "1 โครงการ" / "X โครงการ"

---

## 🚀 การปรับปรุงใหม่ (Version 2.0)

### ✅ **1. ลบ Pagination**

**เหตุผล:**
- ป้องกันปัญหา responsive บนหน้าจอขนาดเล็ก
- ลดความซับซ้อนของ UI
- ให้ผู้ใช้ scroll ดูรายการได้ทั้งหมด

**ก่อน (Version 1.0):**
```typescript
// ❌ มี pagination state
const [currentPage, setCurrentPage] = useState(1);
const [itemsPerPage, setItemsPerPage] = useState(10);

// ❌ แบ่งหน้า
const paginatedOrganizations = filteredOrganizations.slice(startIndex, endIndex);

// ❌ มี Pagination Component
<PaginationWithSelector ... />
```

**หลัง (Version 2.0):**
```typescript
// ✅ ไม่มี pagination state
// ✅ แสดงทั้งหมดและ scroll ได้

<div className="overflow-y-auto" style={{ maxHeight: '500px' }}>
  {filteredOrganizations.map(...)} // ← แสดงทั้งหมด
</div>
```

---

### ✅ **2. แสดงชื่อย่อและชื่อเต็มในบรรทัดเดียว**

**เหตุผล:**
- อ่านง่ายขึ้น ดูชื่อได้ครบในบรรทัดเดียว
- ประหยัดพื้นที่แนวตั้ง (Vertical Space)
- เป็นมาตรฐานของระบบทั่วไป

**ก่อน (Version 1.0):**
```jsx
// ❌ แยก Badge + ชื่อเต็ม
<Badge>{org.organizationShortName}</Badge>  // บรรทัด 1
<h4>{org.organizationName}</h4>            // บรรทัด 2
```

**หลัง (Version 2.0):**
```jsx
// ✅ รวมในบรรทัดเดียว
<h4>
  {org.organizationShortName} - {org.organizationName}
</h4>
```

**ตัวอย่าง:**
```
✅ ใหม่: ERC - สำนักงานคณะกรรมการกำกับกิจการพลังงาน

❌ เดิม: [ERC]
        สำนักงานคณะกรรมการกำกับกิจการพลังงาน
```

---

## 🧪 Test Cases

### **TC1: แสดงรายการหน่วยงานทั้งหมด**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
When: ยังไม่ได้ค้นหา
Then: 
  - แสดงหน่วยงานทั้งหมด 50 รายการ
  - เรียงตาม organizationShortName (A-Z)
  - แสดงข้อความ "เลือกหน่วยงานที่ต้องการบันทึกเคส (50 รายการ)"
```

### **TC2: ค้นหาหน่วยงานด้วยชื่อย่อ**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
When: พิมพ์ "ERC" ในช่องค้นหา
Then: 
  - แสดงเฉพาะหน่วยงานที่มี "ERC" ในชื่อย่อหรือชื่อเต็ม
  - อัปเดทจำนวนผลลัพธ์ เช่น "เลือกหน่วยงานที่ต้องการบันทึกเคส (3 รายการ)"
```

### **TC3: ค้นหาหน่วยงานด้วยชื่อเต็ม**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
When: พิมพ์ "พัฒนา" ในช่องค้นหา
Then: แสดงหน่วยงานที่มี "พัฒนา" ในชื่อเต็ม เช่น "สำนักงานพัฒนารัฐบาลดิจิทัล"
```

### **TC4: ค้นหาไม่พบผลลัพธ์**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
When: พิมพ์ "xyz123" (คำที่ไม่มีในระบบ)
Then: 
  - แสดง Empty State: 🏢 ไม่พบหน่วยงานที่ค้นหา
  - แสดงข้อความ "ลองค้นหาด้วยคำอื่น"
  - แสดงจำนวน "(0 รายการ)"
```

### **TC5: เลือกหน่วยงาน**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
When: คลิกที่ "ERC - สำนักงานคณะกรรมการกำกับกิจการพลังงาน"
Then: 
  - รายการที่เลือกเปลี่ยนสี (bg-blue-50, border-blue-500)
  - Callback onSelectOrganization() ถูกเรียกพร้อม organizationId
  - Console log: "🔍 [OrganizationSelector] Selected org: org-csv-001, สำนักงาน..."
```

### **TC6: Scroll รายการหน่วยงาน**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
And: มีหน่วยงาน 50 รายการ
When: Scroll ลงด้านล่าง
Then: 
  - แสดงหน่วยงานทั้งหมดได้โดย scroll (ไม่มี pagination)
  - Max height: 500px
  - Scrollbar แสดงอยู่ด้านขวา
```

### **TC7: แสดงจำนวนโครงการ**
```
Given: เปิด Modal เลือกโครงการ (Step 1)
When: ดูรายการหน่วยงาน "ERC" ที่มี 5 โครงการ
Then: 
  - แสดง "📁 5 โครงการ" ใต้ชื่อหน่วยงาน
  - ใช้ countProjectsByOrganization() นับจำนวน
```

### **TC8: แสดงผล Contact Person (ถ้ามี)**
```
Given: หน่วยงานมีข้อมูล contactPerson
When: แสดงรายการหน่วยงาน
Then: 
  - แสดง "👤 ชื่อผู้ติดต่อ" ใต้บรรทัดจำนวนโครงการ
  - มีเส้นคั่น (border-t) ด้านบน
```

---

## 📱 Responsive Design

### **Desktop (> 768px)**
```
- ความกว้างรายการ: 100%
- Max height: 500px
- Scrollbar: แสดงเป็น default scrollbar
```

### **Tablet (768px - 1024px)**
```
- ความกว้างรายการ: 100%
- Max height: 500px
- Font size: ยังคงเดิม
```

### **Mobile (< 768px)**
```
- ความกว้างรายการ: 100%
- Max height: 400px (ลดลงเล็กน้อย)
- Font size: ยังคงเดิม
- Scrollbar: แสดงเป็น mobile-friendly scrollbar
```

---

## 🎯 Performance Optimization

### **1. useMemo สำหรับการค้นหา**
```typescript
const filteredOrganizations = useMemo(() => {
  const searched = searchOrganizations(searchTerm, organizations);
  return sortOrganizationsByShortName(searched, 'asc');
}, [searchTerm, organizations]);
```
- หลีกเลี่ยงการคำนวณซ้ำเมื่อ searchTerm ไม่เปลี่ยน

### **2. การนับโครงการแบบ Efficient**
```typescript
const getProjectCount = (orgId: string) => {
  return countProjectsByOrganization(orgId, projects);
};
```
- ใช้ utility function ที่ optimize แล้ว

---

## 🔧 Technical Details

### **Files**
- **Component:** `/components/OrganizationSelector.tsx`
- **Utils:** `/lib/utils/organizationUtils.ts`, `/lib/utils/projectUtils.ts`
- **Types:** `/types.ts`

### **Dependencies**
```typescript
import { Input } from './ui/input';
import { Search, Building2, FolderOpen } from 'lucide-react';
```

---

## 📝 Notes

- ✅ ลบ pagination ออกแล้ว (Version 2.0)
- ✅ แสดงชื่อย่อและชื่อเต็มในบรรทัดเดียว
- ✅ Scroll ได้ทั้งหมดภายใน modal
- ✅ Real-time search ทำงานได้ดี
- ✅ รองรับ responsive design
- ⚠️ ในอนาคตอาจเพิ่มฟีเจอร์ "Favorite Organizations"

---

**Last Updated:** 2026-01-24  
**Version:** 2.0  
**Status:** ✅ Active
