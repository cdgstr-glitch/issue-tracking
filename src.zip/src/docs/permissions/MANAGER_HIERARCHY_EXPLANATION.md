# 🔍 Manager Hierarchy Field Explanation

**Field:** `senior_manager_id` ในตาราง `users`  
**วันที่:** 17 มกราคม 2026  
**Status:** ⚠️ Optional Field (ไม่บังคับใช้)

---

## ❓ **คำถาม: มี senior_manager_id ในระบบหรือไม่?**

### **คำตอบ: ✅ มี แต่เป็น Optional**

ผมได้ออกแบบใส่ไว้ในตาราง `users` ตามนี้ครับ:

```sql
CREATE TABLE users (
  id VARCHAR(36) PRIMARY KEY,
  username VARCHAR(100),
  full_name VARCHAR(255),
  
  -- Manager Hierarchy
  manager_id VARCHAR(36),              -- ✅ ผู้จัดการระดับ 1
  senior_manager_id VARCHAR(36),       -- ⚠️ ผู้จัดการระดับ 2 (Optional)
  manager_email VARCHAR(255),          -- Email สำหรับแจ้งเตือน
  
  FOREIGN KEY (manager_id) REFERENCES users(id),
  FOREIGN KEY (senior_manager_id) REFERENCES users(id)
);
```

---

## 🎯 **สาเหตุที่ออกแบบมา**

### **1️⃣ Organizational Hierarchy (โครงสร้างองค์กร)**

ในองค์กรขนาดใหญ่มักมี **Management Hierarchy หลายระดับ**:

```
┌─────────────────────────────────────────────────────────┐
│                 ORGANIZATIONAL STRUCTURE                │
├─────────────────────────────────────────────────────────┤
│                                                         │
│                  ┌──────────────────┐                   │
│                  │ Senior Manager   │ (Level 2)        │
│                  │ (ผู้อำนวยการ)    │                   │
│                  └────────┬─────────┘                   │
│                           │                             │
│              ┌────────────┼────────────┐                │
│              ▼            ▼            ▼                │
│         ┌─────────┐  ┌─────────┐  ┌─────────┐          │
│         │ Manager │  │ Manager │  │ Manager │ (Level 1)│
│         │ (หัวหน้า)│  │ (หัวหน้า)│  │ (หัวหน้า)│          │
│         └────┬────┘  └────┬────┘  └────┬────┘          │
│              │            │            │                │
│      ┌───────┼───┐    ┌───┼───┐    ┌───┼───┐          │
│      ▼       ▼   ▼    ▼   ▼   ▼    ▼   ▼   ▼          │
│   ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐           │
│   │Tier│ │Tier│ │Tier│ │Tier│ │Tier│ │Tier│ (Staff)  │
│   │ 1  │ │ 2  │ │ 3  │ │ 1  │ │ 2  │ │ 3  │           │
│   └────┘ └────┘ └────┘ └────┘ └────┘ └────┘           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**ตัวอย่างข้อมูล:**

```sql
-- Senior Manager (ผู้อำนวยการ)
INSERT INTO users (id, full_name, primary_role, manager_id, senior_manager_id) VALUES
('director-001', 'นายประสิทธิ์ ศรีสุข', 'admin', NULL, NULL);

-- Manager (หัวหน้าทีม)
INSERT INTO users (id, full_name, primary_role, manager_id, senior_manager_id) VALUES
('manager-001', 'นางสาววิไล จันทร์ดี', 'admin', 'director-001', NULL);

-- Tier1 Staff
INSERT INTO users (id, full_name, primary_role, manager_id, senior_manager_id) VALUES
('tier1-001', 'อภิญญา ทองชัย', 'tier1', 'manager-001', 'director-001');
                                                          ↑              ↑
                                                    หัวหน้าโดยตรง    ผู้อำนวยการ
```

---

## 📋 **Use Cases (กรณีการใช้งาน)**

### **Use Case 1: Escalation Notification (การแจ้งเตือนเมื่อส่งต่อ)**

**Scenario:** เคสที่มีปัญหาร้ายแรงต้องแจ้งผู้บริหารระดับสูง

```
เคส: CDGS-2025-0001 (Priority: CRITICAL)
Status: Tier2 → Tier3 (Escalated)

📧 Notification Flow:
1. ส่งอีเมลถึง assigned_to (Tier3)           ← ผู้รับงาน
2. ส่งอีเมลถึง manager_id (Manager)          ← หัวหน้าทีม
3. ส่งอีเมลถึง senior_manager_id (Director)  ← ผู้อำนวยการ ⚠️
```

**Code Example:**

```php
// เมื่อมีการ escalate ไป Tier3 และเป็น Critical
if ($ticket->status == 'tier3' && $ticket->priority == 'critical') {
    $assignedUser = User::find($ticket->assigned_to);
    
    // แจ้งเตือนหัวหน้าทีม
    if ($assignedUser->manager_id) {
        $manager = User::find($assignedUser->manager_id);
        Mail::to($manager->email)->send(new CriticalTicketAlert($ticket));
    }
    
    // แจ้งเตือนผู้อำนวยการ (senior_manager_id)
    if ($assignedUser->senior_manager_id) {
        $seniorManager = User::find($assignedUser->senior_manager_id);
        Mail::to($seniorManager->email)->send(new CriticalTicketAlert($ticket));
    }
}
```

---

### **Use Case 2: SLA Breach Alert (แจ้งเตือนเมื่อเกิน SLA)**

**Scenario:** เคสเกิน SLA ต้องแจ้งผู้บริหาร

```
เคส: CDGS-2025-0050 
SLA: 24 ชั่วโมง
Current: 30 ชั่วโมง (เกิน 6 ชั่วโมง) ⚠️

📧 Escalation Email:
├─ Level 1: แจ้ง Tier1 (assigned_to)
├─ Level 2: แจ้ง Manager (manager_id)           ← หัวหน้าทีม
└─ Level 3: แจ้ง Senior Manager (senior_manager_id) ← ผู้อำนวยการ
```

**Code Example:**

```php
// ตรวจสอบ SLA ทุกชั่วโมง
if ($ticket->isOverdue()) {
    $overdueHours = $ticket->getOverdueHours();
    
    if ($overdueHours > 24) {
        // เกิน 24 ชม. = แจ้งผู้อำนวยการ
        if ($assignedUser->senior_manager_id) {
            $seniorManager = User::find($assignedUser->senior_manager_id);
            Mail::to($seniorManager->email)->send(
                new SLABreachAlert($ticket, $overdueHours)
            );
        }
    } elseif ($overdueHours > 6) {
        // เกิน 6 ชม. = แจ้งหัวหน้าทีม
        if ($assignedUser->manager_id) {
            $manager = User::find($assignedUser->manager_id);
            Mail::to($manager->email)->send(
                new SLAWarningAlert($ticket, $overdueHours)
            );
        }
    }
}
```

---

### **Use Case 3: Permission Delegation (มอบอำนาจ)**

**Scenario:** หัวหน้าทีมลาป่วย ผู้อำนวยการต้องจัดการแทน

```
manager-001 (หัวหน้าทีม) → ลาป่วย 3 วัน

Action:
1. ระบบหา senior_manager_id ของ manager-001
2. Delegate permissions ให้ director-001 ชั่วคราว
3. Notify ทีมว่าผู้อำนวยการจัดการแทน
```

**Code Example:**

```php
// เมื่อ Manager ลาป่วย
if ($manager->isOnLeave()) {
    // หา Senior Manager
    if ($manager->senior_manager_id) {
        $seniorManager = User::find($manager->senior_manager_id);
        
        // Delegate permissions
        $tickets = Ticket::where('assigned_to', $manager->id)->get();
        foreach ($tickets as $ticket) {
            $ticket->update([
                'assigned_to' => $seniorManager->id,
                'delegated_from' => $manager->id,
            ]);
        }
    }
}
```

---

### **Use Case 4: Approval Workflow (การอนุมัติ)**

**Scenario:** เคสบางประเภทต้องได้รับการอนุมัติจากผู้บริหาร

```
เคส: ขอเพิ่ม Feature ใหม่ (Service Request)
Cost: > 100,000 บาท

Approval Chain:
1. Tier1 รับเคส → แก้ไข
2. Tier1 ส่งขออนุมัติ → Manager (manager_id)
3. Manager อนุมัติ → Senior Manager (senior_manager_id) ← ต้องมี!
4. Senior Manager อนุมัติ → ดำเนินการ
```

**Code Example:**

```php
// Service Request ที่ต้องอนุมัติ
if ($ticket->type == 'service_request' && $ticket->estimated_cost > 100000) {
    $approvalChain = [
        'tier1' => $ticket->assigned_to,
        'manager' => $assignedUser->manager_id,        // ระดับ 1
        'senior_manager' => $assignedUser->senior_manager_id, // ระดับ 2
    ];
    
    // สร้าง approval workflow
    ApprovalWorkflow::create([
        'ticket_id' => $ticket->id,
        'approval_chain' => json_encode($approvalChain),
        'current_step' => 'manager',
    ]);
}
```

---

### **Use Case 5: Reporting & Analytics (รายงานและสถิติ)**

**Scenario:** รายงานประสิทธิภาพของทีมแต่ละฝ่าย

```sql
-- รายงานจำนวนเคสแยกตามผู้อำนวยการ
SELECT 
    sm.full_name AS senior_manager_name,
    COUNT(t.id) AS total_tickets,
    AVG(TIMESTAMPDIFF(HOUR, t.created_at, t.closed_at)) AS avg_resolution_hours
FROM tickets t
JOIN users u ON t.assigned_to = u.id
LEFT JOIN users sm ON u.senior_manager_id = sm.id
WHERE t.status = 'closed'
GROUP BY sm.id, sm.full_name
ORDER BY total_tickets DESC;

-- ผลลัพธ์:
┌────────────────────────┬───────────────┬──────────────────────┐
│ senior_manager_name    │ total_tickets │ avg_resolution_hours │
├────────────────────────┼───────────────┼──────────────────────┤
│ นายประสิทธิ์ ศรีสุข    │ 450           │ 18.5                 │
│ นางสมหมาย ใจดี         │ 320           │ 22.3                 │
│ นายวิชัย ทองคำ         │ 280           │ 16.8                 │
└────────────────────────┴───────────────┴──────────────────────┘
```

---

## ⚖️ **ข้อดี-ข้อเสีย**

### **✅ ข้อดี:**

1. **Flexible Escalation** - แจ้งเตือนได้หลายระดับ
2. **Better Governance** - ผู้บริหารติดตามได้
3. **Delegation Support** - มอบหมายงานได้ลำดับชั้น
4. **Clear Responsibility** - ระบุผู้รับผิดชอบชัดเจน
5. **Better Reporting** - รายงานตามโครงสร้างองค์กร

### **❌ ข้อเสีย:**

1. **Complexity** - โครงสร้างซับซ้อนขึ้น
2. **Maintenance** - ต้องอัพเดทเมื่อเปลี่ยนโครงสร้าง
3. **Optional Use** - ถ้าไม่ใช้ก็เป็น NULL (waste space)

---

## 🔧 **การใช้งานจริง**

### **Option 1: ใช้งานเต็มรูปแบบ (Recommended สำหรับองค์กรใหญ่)**

```sql
-- ตั้งค่า Manager Hierarchy ครบ
UPDATE users SET 
  manager_id = 'manager-001',
  senior_manager_id = 'director-001'
WHERE id = 'tier1-001';
```

### **Option 2: ใช้แค่ Manager ระดับเดียว**

```sql
-- ใช้แค่ manager_id (senior_manager_id = NULL)
UPDATE users SET 
  manager_id = 'manager-001',
  senior_manager_id = NULL  -- ไม่ใช้
WHERE id = 'tier1-001';
```

### **Option 3: ไม่ใช้เลย (สำหรับองค์กรเล็ก)**

```sql
-- ไม่ใช้ Manager Hierarchy
UPDATE users SET 
  manager_id = NULL,
  senior_manager_id = NULL
WHERE id = 'tier1-001';
```

---

## 🗑️ **ถ้าไม่ต้องการใช้ senior_manager_id**

### **วิธีลบออก:**

```sql
-- ลบ Foreign Key ก่อน
ALTER TABLE users DROP FOREIGN KEY fk_users_senior_manager;

-- ลบ Column
ALTER TABLE users DROP COLUMN senior_manager_id;
```

### **หรือปรับ Migration (Laravel):**

```php
// ใน migration file
Schema::table('users', function (Blueprint $table) {
    $table->dropForeign(['senior_manager_id']);
    $table->dropColumn('senior_manager_id');
});
```

---

## 📊 **Comparison Matrix**

```
┌──────────────────┬──────────────┬──────────────┬──────────────┐
│ Feature          │ No Hierarchy │ 1 Level      │ 2 Levels     │
│                  │ (ไม่มี)      │ (manager_id) │ (+senior_id) │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│ Complexity       │ ⭐           │ ⭐⭐         │ ⭐⭐⭐       │
│ Flexibility      │ ❌           │ ✅           │ ✅✅         │
│ Notification     │ 1 level      │ 2 levels     │ 3 levels     │
│ Approval         │ None         │ Basic        │ Advanced     │
│ Reporting        │ Simple       │ Medium       │ Detailed     │
│ Suitable For     │ Small team   │ Medium org   │ Large org    │
└──────────────────┴──────────────┴──────────────┴──────────────┘
```

---

## 🎯 **คำแนะนำ**

### **ใช้ senior_manager_id เมื่อ:**

✅ องค์กรมีโครงสร้างลำดับชั้นมากกว่า 2 ระดับ  
✅ ต้องการ Escalation แบบหลายระดับ  
✅ มี Approval Workflow ที่ซับซ้อน  
✅ ต้องการรายงานตามสายงาน  
✅ มีเคส Critical ที่ต้องแจ้งผู้บริหารระดับสูง

### **ไม่จำเป็นต้องใช้เมื่อ:**

❌ องค์กรเล็ก (< 20 คน)  
❌ โครงสร้างแบน (Flat Organization)  
❌ ไม่มี Approval Workflow  
❌ ต้องการความเรียบง่าย  
❌ Manager = Admin (บทบาทเดียวกัน)

---

## 📝 **สรุป**

### **คำตอบคำถาม:**

1. **มี senior_manager_id ในระบบหรือไม่?**  
   → ✅ **มี** (ออกแบบไว้แล้ว แต่เป็น Optional)

2. **ออกแบบเพื่ออะไร?**  
   → 🎯 **Manager Hierarchy 2 ระดับ:**
   - Notification Escalation
   - Approval Workflow
   - Permission Delegation
   - Reporting & Analytics

3. **ใช้กับเคสใด?**  
   → 📋 **Use Cases:**
   - เคส Critical ที่ต้องแจ้งผู้อำนวยการ
   - เคสเกิน SLA
   - Service Request ที่ต้องอนุมัติ
   - Delegation เมื่อหัวหน้าลา
   - รายงานตามสายงาน

### **คำแนะนำสุดท้าย:**

```
ถ้าระบบของคุณ:
├─ องค์กรขนาดใหญ่ → ✅ ใช้ senior_manager_id
├─ มี Approval Workflow → ✅ ใช้ senior_manager_id
├─ ต้องการ 3-level escalation → ✅ ใช้ senior_manager_id
└─ องค์กรเล็ก/กลาง → ⚠️ ใช้แค่ manager_id ก็พอ
```

---

**สรุป:** Field นี้ออกแบบไว้เผื่อใช้ในอนาคต (Future-proof) แต่ไม่บังคับ  
**Decision:** คุณสามารถเลือกใช้หรือไม่ใช้ก็ได้ตาม Business needs ครับ

---

**สร้างโดย:** Database Design Team  
**วันที่:** 17 มกราคม 2026
