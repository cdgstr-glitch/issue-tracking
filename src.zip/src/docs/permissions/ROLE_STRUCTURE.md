# 📋 โครงสร้าง Role และกฎการใช้งาน CDGS Issue Tracking Platform

**เอกสารเวอร์ชัน:** 3.0  
**วันที่อัปเดต:** 22 มกราคม 2025  
**สถานะ:** ✅ Active (ใช้งานจริง)

---

## 🎯 กฎใหม่: Role Structure (มีผลตั้งแต่ 22 ม.ค. 2025)

### **✅ โครงสร้างบทบาทใหม่ - แยกชัดเจน ไม่ซ้ำซ้อน**

**หลักการ:**
- ❌ **เลิกใช้:** Tier1 ไม่มี 'staff' role อีกต่อไปแล้ว
- ✅ **ใช้แทน:** Permissions System จัดการ capabilities
- ✅ **แต่ละ Role มีหน้าที่ชัดเจน:** ไม่ต้องรวม role หลายตัว

---

## 👥 ผู้ใช้ทั้งหมดในระบบ (12 คน + 1 ซ่อนไว้)

### **สรุปจำนวนตามบทบาท**

| บทบาท | จำนวน | รายชื่อ (ID) |
|--------|-------|-------------|
| **Admin + Tier1** | 2 คน | user-001, user-002 |
| **Tier1** | 3 คน | user-003, user-004, user-005 |
| **Tier2** | 2 คน | user-006, user-008 |
| **Tier2 + Tier3** | 1 คน | user-007 |
| **Tier3** | 2 คน | user-009, user-010 |
| **Admin** | 1 คน | user-011 |
| **Staff** | 1 คน | staff-001 |
| **Customer** | 1 คน | test-001 |
| **Tier0 (ซ่อน)** | 1 คน | user-012 |
| **รวม (ใช้งานได้)** | **12 คน** | ไม่นับ user-012 |

---

## 📊 รายละเอียดผู้ใช้แต่ละบทบาท

### **1. Admin + Tier1 (2 คน)** ⭐

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `user-001` | ธิราภรณ์ รุ่งวิรัตน์กุล | `thiraporn.r` | `['admin', 'tier1']` | `admin` |
| `user-002` | สาริน ช่อพะยอม | `sarin.c` | `['admin', 'tier1']` | `admin` |

**Capabilities:**
```typescript
{
  // จาก admin
  manage_users: true,
  manage_projects: true,
  manage_settings: true,
  view_all_tickets: true,
  add_comment: true,
  
  // จาก tier1
  create_ticket_for_customer: true,
  accept_ticket: true,
  close_ticket: true,
  escalate_ticket: true,
  assign_ticket: true,
  update_ticket: true,
}
```

---

### **2. Tier1 (3 คน)** ✅

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `user-003` | วรรณภา แซ่ด่าง | `wannapa.s` | `['tier1']` | `tier1` |
| `user-004` | เขมิกา แซ่ตั้ง | `khemika.s` | `['tier1']` | `tier1` |
| `user-005` | ธัญญาพร ทองแก้ว | `thanyaporn.t` | `['tier1']` | `tier1` |

**Capabilities:**
```typescript
{
  create_ticket_for_customer: true,  // ✅ มีอยู่แล้ว (ไม่ต้องมี staff)
  accept_ticket: true,
  close_ticket: true,                // ✅ เฉพาะ Tier1 เท่านั้น
  escalate_ticket: true,
  assign_ticket: true,
  update_ticket: true,
  view_all_tickets: true,
  add_comment: true,
}
```

**หมายเหตุ:**
- ✅ Tier1 มีสิทธิ์ **บันทึกเคสแทนลูกค้า** โดยไม่ต้องมี 'staff' role
- ✅ Tier1 มีสิทธิ์ **ปิดเคส** (เฉพาะ Tier1 เท่านั้น)

---

### **3. Tier2 (2 คน)**

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `user-006` | ยุทธนา คณามิ่งมงคล | `yuttana.k` | `['tier2']` | `tier2` |
| `user-008` | ประวิช จินทนากร | `pravich.j` | `['tier2']` | `tier2` |

**Capabilities:**
```typescript
{
  accept_ticket: true,
  escalate_ticket: true,
  update_ticket: true,
  view_all_tickets: true,
  add_comment: true,
}
```

---

### **4. Tier2 + Tier3 (1 คน)** ⭐ มี Dropdown สลับ Role

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `user-007` | ประกาศิต ประคองเพ็ชร | `prakasit.p` | `['tier2', 'tier3']` | `tier2` |

**UI Behavior:**
- ✅ แสดง Dropdown "สลับบทบาท" ใน Header
- ✅ สลับระหว่าง Tier2 ↔️ Tier3 ได้
- ✅ Auto-redirect ไปยัง Dashboard ที่ถูกต้อง

---

### **5. Tier3 (2 คน)**

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `user-009` | พุทธจักษ์ วงค์พันธ์ | `puttajak.w` | `['tier3']` | `tier3` |
| `user-010` | วีระกร เยือกเย็น | `wirakorn.y` | `['tier3']` | `tier3` |

**Capabilities:**
```typescript
{
  accept_ticket: true,
  escalate_ticket: true,
  update_ticket: true,
  view_all_tickets: true,
  add_comment: true,
}
```

---

### **6. Admin (1 คน)** 

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `user-011` | ประอรรัตน์ กีรติผจญ | `pra-onrat.k` | `['admin']` | `admin` |

**Capabilities:**
```typescript
{
  manage_users: true,
  manage_projects: true,
  manage_settings: true,
  view_all_tickets: true,      // Read-only
  add_comment: true,            // ให้คำแนะนำได้
}
```

**หมายเหตุ:**
- ❌ **ไม่มี Tier1** → ไม่สามารถปิดเคสได้
- ❌ **ไม่มี ASSIGN_TICKET** → ไม่แทรกแซง workflow
- ✅ **ดูเคสแบบ Read-only** → เพื่อภาพรวมระบบ

---

### **7. Staff (1 คน)** 

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `staff-001` | สมชาย ใจดี | `staff` | `['staff']` | `staff` |

**Capabilities:**
```typescript
{
  create_ticket_for_customer: true,    // ✅ บันทึกเคสแทนลูกค้า
  view_own_created_tickets: true,      // ✅ ดูเฉพาะที่ตัวเองบันทึก
}
```

**หมายเหตุ:**
- ✅ **บันทึกเคสแทนลูกค้าเท่านั้น**
- ✅ **ดูเฉพาะเคสที่ตัวเองบันทึก** (ไม่เห็นเคสทั้งหมด)
- ❌ **ไม่สามารถ:** รับเคส, แก้ไขเคส, ปิดเคส, ตอบกลับ Comment

---

### **8. Customer (1 คน)**

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role |
|----|--------------|----------|-------|--------------|
| `test-001` | ศิริพร อารีมิตร | `customer1` | `['customer']` | `customer` |

**Capabilities:**
```typescript
{
  create_own_ticket: true,     // ✅ แจ้งเคส
  view_own_tickets: true,      // ✅ ดูเคสของตัวเอง
  add_comment: true,           // ✅ ตอบกลับเคส (Public Comment อัตโนมัติ)
}
```

---

### **9. Tier0 (1 คน - ซ่อนไว้)** 🔒

| ID | ชื่อ-นามสกุล | Username | Roles | Primary Role | สถานะ |
|----|--------------|----------|-------|--------------|-------|
| `user-012` | อภิญญา ทองชัย | `apinya.t` | `['tier1']` | `tier1` | ❌ ซ่อนไว้ |

**หมายเหตุ:**
- 🔒 **ไม่สามารถ Login ได้** (ถูก comment ออกใน `/lib/mockData/users.ts`)
- 🔮 **สงวนไว้สำหรับอนาคต**
- 📝 **ไม่ใช้งานในระบบปัจจุบัน**

---

## 🔍 กฎการตรวจสอบ Role (ใหม่)

### **✅ ใช้ Permissions System แทน hasRole**

```typescript
import { can, CAPABILITIES, isTier1, isPureStaff, isCustomer } from '../lib/permissions';

// ✅ แบบใหม่ - ชัดเจน
const canCloseTicket = can(user, CAPABILITIES.CLOSE_TICKET);
const isUserTier1 = isTier1(user);
const isUserStaff = isPureStaff(user);

// ❌ แบบเก่า - อย่าใช้แล้ว
const isTier1 = hasRole(user, 'tier1') && hasRole(user, 'staff');
```

---

## 🎨 UI/UX ตาม Role

### **1. Tier1 (3 คน) + Admin + Tier1 (2 คน)**

**หน้า CreateTicketPage:**
- ✅ แสดงฟอร์มกรอกข้อมูลลูกค้า (ชื่อ, อีเมล, เบอร์, หน่วยงาน)
- ✅ แสดงช่องทางการติดต่อ (Line, Phone, Email)
- ✅ แสดงประเภทปัญหา (Incident, Service Request, Security Incident)
- ✅ แสดงความสำคัญ (Low, Medium, High, Critical)
- ✅ แสดงวันที่เกิดเหตุ (Backdate ได้)
- ✅ แสดงโครงการ (Required)
- ✅ มีปุ่ม: **"แก้ไขและปิดเคส"** + **"บันทึกและรับเคส"** + **"ส่งงาน"**

**หน้า Dashboard:**
- ✅ เห็นเคสทั้งหมด (All Tickets)
- ✅ เห็นงานของฉัน (My Tickets)
- ✅ เห็นรอดำเนินการ (Pending)
- ✅ เห็นแก้ไขแล้ว (Resolved)

---

### **2. Staff (1 คน)**

**หน้า CreateTicketPage:**
- ✅ แสดงฟอร์มกรอกข้อมูลลูกค้า (เหมือน Tier1)
- ✅ มีปุ่มเดียว: **"ส่งงาน"** (ส่งไป Tier1 queue)
- ❌ **ไม่มีปุ่ม:** "บันทึกและรับเคส", "แก้ไขและปิดเคส"

**หน้า Dashboard:**
- ✅ ดูเฉพาะเคสที่ตัวเองบันทึก (VIEW_OWN_CREATED_TICKETS)
- ❌ ไม่เห็นเคสทั้งหมด

---

### **3. Customer (1 คน)**

**หน้า CreateTicketPage:**
- ✅ แสดงข้อมูลตัวเอง (Auto-filled)
- ✅ มีปุ่ม: **"แจ้งเคส"**
- ✅ ตอบกลับเคสได้ (Public Comment เท่านั้น)

---

### **4. Admin (1 คน)**

**หน้า Dashboard:**
- ✅ ดูเคสทั้งหมด (Read-only)
- ✅ ตอบกลับ Comment ได้ (ให้คำแนะนำ)
- ✅ จัดการผู้ใช้, โครงการ, ตั้งค่าระบบ
- ❌ **ไม่มีปุ่ม:** รับเคส, แก้ไขเคส, ปิดเคส, มอบหมายเคส

---

## 🛠️ Code Guidelines

### **1. ใช้ Permissions System**

```typescript
// ✅ ถูกต้อง - ใช้ Permissions
import { can, CAPABILITIES, isTier1, isPureStaff } from '../lib/permissions';

const canCreateForCustomer = can(user, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER);
const canCloseTicket = can(user, CAPABILITIES.CLOSE_TICKET);
const isUserTier1 = isTier1(user);

// ✅ ใช้ใน Component
{canCreateForCustomer && <CustomerInfoForm />}
{canCloseTicket && <CloseButton />}
```

---

### **2. อย่าใช้ hasRole ซ้ำซ้อน**

```typescript
// ❌ ผิด - ซับซ้อน
{hasRole(user, 'tier1') && hasRole(user, 'staff') && <CloseButton />}

// ✅ ถูก - ง่ายและชัดเจน
{isTier1(user) && <CloseButton />}
```

---

### **3. Component ที่ต้องตรวจสอบ**

| Component | Path | ต้องแก้ไข |
|-----------|------|-----------|
| CreateTicketPage | `/components/CreateTicketPage.tsx` | ✅ ใช้ Permissions แทน hasRole |
| TicketActions | `/components/TicketActions.tsx` | ✅ ใช้ Permissions |
| TicketDetailPage | `/components/TicketDetailPage.tsx` | ✅ ใช้ Permissions |
| Header | `/components/Header.tsx` | ✅ แสดงชื่อ role ที่ถูกต้อง |
| Sidebar | `/components/Sidebar.tsx` | ✅ แสดง menu ที่ถูกต้อง |

---

## 📝 Checklist การแก้ไข

เมื่อแก้ไขโค้ดที่เกี่ยวข้องกับ Role ต้องตรวจสอบ:

- [x] ✅ ใช้ Permissions System แทน hasRole
- [x] ✅ Tier1 = `['tier1']` เท่านั้น (ไม่มี staff)
- [x] ✅ Staff = `['staff']` เท่านั้น
- [x] ✅ Admin + Tier1 = `['admin', 'tier1']` (ไม่มี staff)
- [x] ✅ Tier1 มี CREATE_TICKET_FOR_CUSTOMER อยู่แล้ว
- [x] ✅ Admin ไม่สามารถปิดเคสได้ (ถ้าไม่มี tier1)
- [x] ✅ Staff ดูเฉพาะเคสที่ตัวเองบันทึก
- [x] ✅ ทดสอบทุก role ทุก scenario

---

## 🚨 ข้อควรระวัง

### **1. อย่าใช้ `user.role` เช็ค (เลิกใช้แล้ว)**

```typescript
// ❌ ผิด - Backward compatibility เท่านั้น
if (user.role === 'tier1') { ... }

// ✅ ถูก - ใช้ Permissions
if (isTier1(user)) { ... }
```

---

### **2. Tier1 ไม่มี Staff role**

```typescript
// ❌ ผิด - ยุคเก่า
const isTier1 = hasRole(user, 'tier1') && hasRole(user, 'staff');

// ✅ ถูก - ยุคใหม่
const isTier1 = can(user, CAPABILITIES.CLOSE_TICKET);
// หรือ
const isTier1 = isTier1(user);
```

---

### **3. Admin ไม่ใช่ Tier1**

```typescript
// Pure Admin (user-011)
{
  roles: ['admin'],  // ❌ ไม่มี tier1 → ไม่สามารถปิดเคสได้
}

// Admin + Tier1 (user-001, user-002)
{
  roles: ['admin', 'tier1'],  // ✅ มี tier1 → ปิดเคสได้
}
```

---

## 📚 เอกสารที่เกี่ยวข้อง

- **PERMISSIONS_REVIEW.md** - ตารางเปรียบเทียบ Permissions
- **PERMISSIONS_GUIDE.md** - คู่มือการใช้งาน Permissions
- **PERMISSIONS_EXAMPLES.md** - ตัวอย่างการใช้งาน
- **/lib/permissions.ts** - Source code ระบบ Permissions
- **/lib/mockData/users.ts** - ข้อมูล Mock Users ทั้งหมด
- **/contexts/AuthContext.tsx** - Authentication context

---

## 🔄 ประวัติการเปลี่ยนแปลง

| วันที่ | เวอร์ชัน | การเปลี่ยนแปลง |
|--------|---------|---------------|
| 2025-01-22 | 3.0 | ✅ แยกบทบาทชัดเจน: Tier1 ไม่มี staff role, ใช้ Permissions System |
| 2025-01-22 | 2.0 | กำหนดกฎใหม่: Tier1 = มีทั้ง tier1 และ staff |
| 2025-01-21 | 1.5 | ซ่อน user-012 (อภิญญา ทองชัย) ออกจากระบบ |
| 2025-01-20 | 1.0 | เวอร์ชันแรก - Multi-role support |

---

**สร้างโดย:** CDGS Development Team  
**ติดต่อ:** dev@cdgs.co.th  
**อัปเดตล่าสุด:** 22 มกราคม 2025 (v3.0)
