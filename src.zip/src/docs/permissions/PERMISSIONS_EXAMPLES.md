# 📘 Permissions System - ตัวอย่างการใช้งาน

**วันที่:** 22 มกราคม 2025

---

## 🧪 ทดสอบระบบ Permissions

### **ตัวอย่างที่ 1: ทดสอบกับ Mock Users**

```typescript
import { can, CAPABILITIES, getUserCapabilities, isTier1, isPureStaff } from './lib/permissions';
import { mockUsers } from './lib/mockData/users';

// ดึง user จาก mockUsers
const user001 = mockUsers.find(u => u.user.id === 'user-001')?.user; // Admin + Tier1
const user003 = mockUsers.find(u => u.user.id === 'user-003')?.user; // Tier1
const staff001 = mockUsers.find(u => u.user.id === 'staff-001')?.user; // Pure Staff
const user011 = mockUsers.find(u => u.user.id === 'user-011')?.user; // Pure Admin

// ทดสอบ user-001 (Admin + Tier1)
console.log('=== user-001 (ธิราภรณ์ - Admin + Tier1) ===');
console.log('Can close ticket?', can(user001, CAPABILITIES.CLOSE_TICKET)); // true
console.log('Can manage users?', can(user001, CAPABILITIES.MANAGE_USERS)); // true
console.log('Is Tier1?', isTier1(user001)); // true
console.log('Capabilities:', getUserCapabilities(user001));

// ทดสอบ user-003 (Tier1)
console.log('\n=== user-003 (วรรณภา - Tier1) ===');
console.log('Can close ticket?', can(user003, CAPABILITIES.CLOSE_TICKET)); // true
console.log('Can manage users?', can(user003, CAPABILITIES.MANAGE_USERS)); // false
console.log('Is Tier1?', isTier1(user003)); // true

// ทดสอบ staff-001 (Pure Staff)
console.log('\n=== staff-001 (สมชาย - Pure Staff) ===');
console.log('Can create for customer?', can(staff001, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER)); // true
console.log('Can close ticket?', can(staff001, CAPABILITIES.CLOSE_TICKET)); // false
console.log('Is Pure Staff?', isPureStaff(staff001)); // true

// ทดสอบ user-011 (Pure Admin)
console.log('\n=== user-011 (ประอรรัตน์ - Pure Admin) ===');
console.log('Can manage users?', can(user011, CAPABILITIES.MANAGE_USERS)); // true
console.log('Can close ticket?', can(user011, CAPABILITIES.CLOSE_TICKET)); // false ⭐
console.log('Is Tier1?', isTier1(user011)); // false
```

---

### **ตัวอย่างที่ 2: ใช้ใน Component (CreateTicketPage)**

```typescript
// components/CreateTicketPage.tsx

import { can, CAPABILITIES, isTier1, isPureStaff } from '../lib/permissions';

export function CreateTicketPage({ onNavigate }: CreateTicketPageProps) {
  const { user, customer } = useAuth();
  const currentUser = customer || user;
  
  // ✅ เช็คความสามารถแทน role
  const canCreateForCustomer = can(currentUser, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER);
  const canAcceptTicket = can(currentUser, CAPABILITIES.ACCEPT_TICKET);
  const canCloseTicket = can(currentUser, CAPABILITIES.CLOSE_TICKET);
  
  // ✅ หรือใช้ helper functions
  const isUserTier1 = isTier1(currentUser);
  const isUserPureStaff = isPureStaff(currentUser);
  const isUserCustomer = isCustomer(currentUser);
  
  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>
            {canCreateForCustomer ? 'ข้อมูลงานลูกค้า' : 'ข้อมูลงาน'}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* แสดงฟอร์มกรอกข้อมูลลูกค้า (Staff & Tier1) */}
          {canCreateForCustomer && (
            <CustomerInfoForm />
          )}
          
          {/* แสดงช่องทางการติดต่อ (Staff & Tier1) */}
          {canCreateForCustomer && (
            <ChannelSelector />
          )}
          
          {/* แสดงโครงการ (Staff & Tier1) */}
          {canCreateForCustomer && (
            <ProjectSelector />
          )}
        </CardContent>
      </Card>
      
      {/* ปุ่มต่างๆ */}
      <div className="flex gap-3 mt-6">
        {/* ปุ่มสำหรับ Customer */}
        {isUserCustomer && (
          <Button type="submit" size="lg">
            แจ้งเคส
          </Button>
        )}
        
        {/* ปุ่มสำหรับ Pure Staff */}
        {isUserPureStaff && (
          <Button type="submit" size="lg">
            ส่งงาน
          </Button>
        )}
        
        {/* ปุ่มสำหรับ Tier1 */}
        {isUserTier1 && (
          <>
            {/* ปิดเคสทันที */}
            {canCloseTicket && (
              <Button 
                type="button" 
                onClick={handleSolveAndClose}
                className="bg-green-600"
              >
                ✅ แก้ไขและปิดเคส
              </Button>
            )}
            
            {/* บันทึกและรับเคส */}
            {canAcceptTicket && (
              <Button 
                type="button" 
                onClick={handleSaveAndAccept}
                className="bg-blue-600"
              >
                📥 บันทึกและรับเคส
              </Button>
            )}
            
            {/* บันทึกเคส */}
            <Button type="submit" size="lg">
              ส่งงาน
            </Button>
          </>
        )}
      </div>
    </form>
  );
}
```

---

### **ตัวอย่างที่ 3: ใช้ใน TicketActions**

```typescript
// components/TicketActions.tsx

import { can, CAPABILITIES } from '../lib/permissions';

export function TicketActions({ ticket, user, onUpdate }: TicketActionsProps) {
  // ✅ เช็คความสามารถ
  const canAccept = can(user, CAPABILITIES.ACCEPT_TICKET);
  const canClose = can(user, CAPABILITIES.CLOSE_TICKET);
  const canEscalate = can(user, CAPABILITIES.ESCALATE_TICKET);
  
  // เงื่อนไขการแสดงปุ่ม
  const showAcceptButton = canAccept && ticket.status === 'new' && !ticket.assignedTo;
  const showCloseButton = canClose && ticket.status === 'resolved';
  const showEscalateButton = canEscalate && ticket.assignedTo === user.id;
  
  return (
    <div className="flex gap-2">
      {/* ปุ่มรับเคส */}
      {showAcceptButton && (
        <Button onClick={handleAccept}>
          รับเคส
        </Button>
      )}
      
      {/* ปุ่มปิดเคส (เฉพาะ Tier1) */}
      {showCloseButton && (
        <Button onClick={handleClose} className="bg-green-600">
          ปิดเคส
        </Button>
      )}
      
      {/* ปุ่มส่งต่อ */}
      {showEscalateButton && (
        <Button onClick={handleEscalate}>
          ส่งต่อเคส
        </Button>
      )}
    </div>
  );
}
```

---

### **ตัวอย่างที่ 4: Protected Routes**

```typescript
// App.tsx

import { can, CAPABILITIES } from './lib/permissions';

function App() {
  const { user } = useAuth();
  
  return (
    <Routes>
      {/* หน้าสำหรับ Customer */}
      {can(user, CAPABILITIES.CREATE_OWN_TICKET) && (
        <Route path="/create" element={<CreateTicketPage />} />
      )}
      
      {/* หน้าสำหรับ Admin */}
      {can(user, CAPABILITIES.MANAGE_USERS) && (
        <Route path="/admin/users" element={<ManageUsersPage />} />
      )}
      
      {/* หน้าสำหรับ Tier */}
      {can(user, CAPABILITIES.VIEW_ALL_TICKETS) && (
        <Route path="/admin/tickets" element={<TicketListPage />} />
      )}
    </Routes>
  );
}
```

---

### **ตัวอย่างที่ 5: Conditional Rendering**

```typescript
// components/Header.tsx

import { can, CAPABILITIES } from '../lib/permissions';

export function Header({ user }: HeaderProps) {
  const canManageSystem = can(user, CAPABILITIES.MANAGE_USERS);
  const canCreateForCustomer = can(user, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER);
  
  return (
    <header>
      <nav>
        {/* แสดงเมนู Admin */}
        {canManageSystem && (
          <NavLink to="/admin/users">จัดการผู้ใช้</NavLink>
        )}
        
        {/* แสดงปุ่มแจ้งเคส (Staff/Tier1) */}
        {canCreateForCustomer && (
          <Button onClick={() => navigate('/create')}>
            แจ้งเคสใหม่
          </Button>
        )}
      </nav>
    </header>
  );
}
```

---

## 🔄 สถานการณ์จริง

### **Scenario 1: Tier2 ต้องปิดเคสได้**

**Before (ต้องแก้ทุก Component):**
```typescript
// ❌ ต้องหาและแก้ทุกจุด
{(hasRole(user, 'tier1') || hasRole(user, 'tier2')) && <CloseButton />}
{(hasRole(user, 'tier1') || hasRole(user, 'tier2')) && <CloseModal />}
{(hasRole(user, 'tier1') || hasRole(user, 'tier2')) && <CloseForm />}
```

**After (แก้ที่เดียว):**
```typescript
// ✅ แก้แค่ permissions.ts
ROLE_CAPABILITIES.tier2 = [
  'accept_ticket',
  'close_ticket', // ← เพิ่มบรรทัดเดียว
  'escalate_ticket',
];

// Component ไม่ต้องแก้!
{can(user, CAPABILITIES.CLOSE_TICKET) && <CloseButton />}
{can(user, CAPABILITIES.CLOSE_TICKET) && <CloseModal />}
{can(user, CAPABILITIES.CLOSE_TICKET) && <CloseForm />}
```

---

### **Scenario 2: เพิ่ม Role ใหม่ "Supervisor"**

```typescript
// ✅ เพิ่มใน permissions.ts
export type UserRole = 
  | 'customer' 
  | 'staff' 
  | 'tier1' 
  | 'tier2' 
  | 'tier3' 
  | 'supervisor' // ← เพิ่มใหม่
  | 'admin';

ROLE_CAPABILITIES.supervisor = [
  'view_all_tickets',
  'assign_ticket',
  'manage_projects',
];

// ✅ Component ทำงานอัตโนมัติ
{can(user, CAPABILITIES.ASSIGN_TICKET) && <AssignButton />}
// ↑ Supervisor เห็นปุ่มนี้อัตโนมัติ!
```

---

### **Scenario 3: Admin บางคนปิดเคสได้**

```typescript
// ✅ Admin ที่มี tier1 ด้วย
const adminTier1 = {
  id: 'user-001',
  roles: ['admin', 'tier1', 'staff']
};

can(adminTier1, CAPABILITIES.CLOSE_TICKET); // true ✅

// ✅ Admin ธรรมดา
const pureAdmin = {
  id: 'user-011',
  roles: ['admin']
};

can(pureAdmin, CAPABILITIES.CLOSE_TICKET); // false ❌
```

---

## ✅ สรุปข้อดี

1. ✅ **อ่านง่าย** - `can(user, 'closeTicket')` ชัดเจนกว่า `hasRole(user, 'tier1') && hasRole(user, 'staff')`
2. ✅ **แก้ไขง่าย** - แก้ที่เดียว (permissions.ts) ใช้ได้ทั้งระบบ
3. ✅ **ยืดหยุ่น** - เพิ่ม role ใหม่หรือเปลี่ยนกฎได้ง่าย
4. ✅ **ปลอดภัย** - ลดโอกาสพิมพ์ผิด/ลืมเช็ค
5. ✅ **Testable** - Test ได้ง่าย ชัดเจน
6. ✅ **Scalable** - รองรับระบบที่ใหญ่ขึ้นในอนาคต

---

**สร้างโดย:** CDGS Development Team  
**วันที่:** 22 มกราคม 2025
