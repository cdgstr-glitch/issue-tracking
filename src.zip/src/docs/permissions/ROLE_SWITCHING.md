# 🔄 เอกสารการสลับบทบาท (Role Switching)

**CDGS Issue Tracking Platform**

อัปเดตล่าสุด: 21 มกราคม 2026

---

## 📋 สารบัญ

1. [ภาพรวม](#ภาพรวม)
2. [กฎการสลับบทบาท](#กฎการสลับบทบาท)
3. [ผู้ใช้งานที่สามารถสลับบทบาทได้](#ผู้ใช้งานที่สามารถสลับบทบาทได้)
4. [วิธีการสลับบทบาท](#วิธีการสลับบทบาท)
5. [ตัวอย่างการใช้งาน](#ตัวอย่างการใช้งาน)
6. [Technical Implementation](#technical-implementation)

---

## 📌 ภาพรวม

ระบบ CDGS Issue Tracking Platform รองรับ **Multi-Role System** ที่ผู้ใช้งานคนเดียวสามารถมีหลายบทบาทพร้อมกันได้ และสามารถสลับบทบาทในการทำงานได้ตามความจำเป็น

### 🎯 วัตถุประสงค์
- ลดความซับซ้อนในการจัดการผู้ใช้งาน
- เพิ่มความยืดหยุ่นในการทำงาน
- รองรับการทำงานข้ามทีม (Cross-functional)

---

## ⚙️ กฎการสลับบทบาท

### ✅ บทบาทที่สามารถสลับได้

| บทบาท | สลับได้หรือไม่ | เหตุผล |
|--------|---------------|--------|
| **Tier 2** | ✅ **ได้** | สามารถสลับระหว่าง Tier 2 และ Tier 3 |
| **Tier 3** | ✅ **ได้** | สามารถสลับระหว่าง Tier 2 และ Tier 3 |

### ❌ บทบาทที่ไม่สามารถสลับได้

| บทบาท | สลับได้หรือไม่ | เหตุผล |
|--------|---------------|--------|
| **Tier 1** | ❌ **ไม่ได้** | Tier 1 เป็นบทบาทหลักในการจัดการเคส ไม่มีการสลับบทบาท |
| **Admin** | ❌ **ไม่ได้** | Admin เป็นบทบาทเฉพาะ ไม่มีการสลับบทบาท |
| **Staff** | ❌ **ไม่ได้** | Staff เป็นบทบาทเฉพาะ ไม่มีการสลับบทบาท |
| **Customer** | ❌ **ไม่ได้** | Customer เป็นบทบาทเฉพาะ ไม่มีการสลับบทบาท |

### 🔑 เงื่อนไขการสลับบทบาท

1. ✅ **ต้องมีหลายบทบาท**: ผู้ใช้งานต้องมีบทบาท `tier2` และ `tier3` พร้อมกัน
2. ✅ **เฉพาะ Tier 2 และ Tier 3**: สลับได้เฉพาะระหว่าง 2 บทบาทนี้เท่านั้น
3. ✅ **UI จะแสดงปุ่มสลับอัตโนมัติ**: เมื่อผู้ใช้งานมีคุณสมบัติตามข้อ 1

---

## 👥 ผู้ใช้งานที่สามารถสลับบทบาทได้

จากฐานข้อมูลผู้ใช้งานในระบบ ปัจจุบันมี **1 คน** ที่สามารถสลับบทบาทได้:

### 🔄 Multi-Role Users

| User ID | ชื่อ-นามสกุล | Username | บทบาท | Primary Role | สามารถสลับ |
|---------|-------------|----------|-------|--------------|-----------|
| user-007 | **ประกาศิต ประคองเพ็ชร** | `prakasit.p` | Tier 2 + Tier 3 | Tier 2 | ✅ **ได้** |

#### รายละเอียด: ประกาศิต ประคองเพ็ชร
- **Username:** `prakasit.p`
- **Password:** `prakasit.p123`
- **Email:** prakasit.p@cdg.co.th
- **แผนก:** ฝ่ายเทคนิคและพัฒนา
- **ตำแหน่ง:** วิศวกรระบบระดับ 2
- **บทบาท:** `['tier2', 'tier3']`
- **Primary Role:** `tier2`
- **โครงการที่รับผิดชอบ:** 10 โครงการ (ทุกโครงการ)
- **สามารถสลับ:** ✅ ระหว่าง Tier 2 ⇄ Tier 3

---

### ❌ Single-Role Users (ไม่สามารถสลับบทบาท)

#### Tier 1 เพียวๆ (4 คน)
| User ID | ชื่อ-นามสกุล | Username | บทบาท | สามารถสลับ |
|---------|-------------|----------|-------|-----------|
| user-tier1-001 | สาริน | `sarin.t` | Tier 1 | ❌ ไม่ได้ |
| user-tier1-002 | ธัญญาพร | `thanyaporn.k` | Tier 1 | ❌ ไม่ได้ |
| user-tier1-003 | วรรณภา | `wannapa.s` | Tier 1 | ❌ ไม่ได้ |
| user-tier1-004 | ธิราภรณ์ | `thiraporn.m` | Tier 1 | ❌ ไม่ได้ |

#### Tier 2 เพียวๆ (2 คน)
| User ID | ชื่อ-นามสกุล | Username | บทบาท | สามารถสลับ |
|---------|-------------|----------|-------|-----------|
| user-tier2-001 | ยุทธนา | `yutthana.p` | Tier 2 | ❌ ไม่ได้ |
| user-tier2-003 | ปิยะมาศ | `piyamas.n` | Tier 2 | ❌ ไม่ได้ |

#### Tier 3 เพียวๆ (2 คน)
| User ID | ชื่อ-นามสกุล | Username | บทบาท | สามารถสลับ |
|---------|-------------|----------|-------|-----------|
| user-009 | พุทธจักษ์ วงค์พันธ์ | `puttajak.w` | Tier 3 | ❌ ไม่ได้ |
| user-010 | วีระกร เยือกเย็น | `wirakorn.y` | Tier 3 | ❌ ไม่ได้ |

#### Admin เพียวๆ (1 คน)
| User ID | ชื่อ-นามสกุล | Username | บทบาท | สามารถสลับ |
|---------|-------------|----------|-------|-----------|
| user-011 | ประอรรัตน์ กีรติผจญ | `pra-onrat.k` | Admin | ❌ ไม่ได้ |

---

## 🔧 วิธีการสลับบทบาท

### ขั้นตอนการสลับบทบาท

1. **Login เข้าระบบ** ด้วย username และ password
   ```
   Username: prakasit.p
   Password: prakasit.p123
   ```

2. **คลิกที่ชื่อผู้ใช้งาน** ที่มุมขวาบนของหน้าจอ

3. **เลือกบทบาท** จาก Dropdown Menu
   - แสดงบทบาทที่มีอยู่ทั้งหมด
   - บทบาทปัจจุบันจะมีเครื่องหมาย ✓ สีเขียว

4. **คลิกเลือกบทบาท** ที่ต้องการสลับ
   - เช่น: สลับจาก "เทียร์ 2" → "เทียร์ 3"

5. **ระบบจะ Refresh** และเปลี่ยนมุมมองตามบทบาทใหม่ทันที

---

## 📱 ตัวอย่างการใช้งาน

### สถานการณ์ที่ 1: ทำงานแทนทีม Tier 3

**สถานการณ์:**
- ประกาศิต (Tier 2) ต้องช่วยทีม Tier 3 แก้ปัญหาด่วน
- มีเคสที่ส่งต่อมาที่ Tier 3 แต่ยังไม่มีใครรับ

**วิธีดำเนินการ:**
1. ✅ Login เข้าระบบ (`prakasit.p` / `prakasit.p123`)
2. ✅ คลิกที่ชื่อ "ประกาศิต ประคองเพ็ชร" มุมขวาบน
3. ✅ เลือก **"เทียร์ 3"** จาก Dropdown
4. ✅ ระบบจะแสดงเคสของ Tier 3
5. ✅ รับเคสและดำเนินการแก้ไข
6. ✅ เมื่อเสร็จแล้ว สลับกลับเป็น **"เทียร์ 2"**

---

### สถานการณ์ที่ 2: ตรวจสอบเคสข้ามทีม

**สถานการณ์:**
- ประกาศิตต้องการตรวจสอบเคสที่ส่งต่อจาก Tier 2 ไป Tier 3
- ต้องการดูว่าเคสถูกดำเนินการหรือยัง

**วิธีดำเนินการ:**
1. ✅ Login ในฐานะ Tier 2 (Primary Role)
2. ✅ ดูเคสที่ส่งต่อจากเมนู **"เคสที่ฉันส่งต่อ"**
3. ✅ สลับเป็น **Tier 3** เพื่อดูรายละเอียดเคสจากมุมมองของ Tier 3
4. ✅ ตรวจสอบสถานะและความคืบหน้า

---

## 💻 Technical Implementation

### 1. ฟังก์ชันตรวจสอบสิทธิ์การสลับบทบาท

**ไฟล์:** `/lib/utils.ts`

```typescript
/**
 * Get user's tier roles only (tier2, tier3) สำหรับสลับบทบาท
 * ⚠️ IMPORTANT: tier1 ไม่มีการสลับบทบาท - ใช้ได้เฉพาะ tier2 และ tier3
 * @param user - User object
 * @returns array of tier roles (tier2, tier3 only)
 */
export function getTierRoles(user: User | null | undefined): UserRole[] {
  const allRoles = getAllRoles(user);
  // ✅ สลับบทบาทได้เฉพาะ tier2 และ tier3 เท่านั้น (ไม่รวม tier1 และ admin)
  return allRoles.filter(role => 
    ['tier2', 'tier3'].includes(role)
  );
}

/**
 * Check if user needs role selector (has multiple tier roles)
 * @param user - User object
 * @returns true if user has more than 1 tier role
 */
export function needsRoleSelector(user: User | null | undefined): boolean {
  const tierRoles = getTierRoles(user);
  return tierRoles.length > 1;
}
```

---

### 2. การใช้งานใน Component

**ไฟล์:** `/components/Header.tsx`

```typescript
import { needsRoleSelector, getTierRoles } from '../lib/utils';

// ตรวจสอบว่าต้องแสดงปุ่มสลับบทบาทหรือไม่
const showRoleSelector = needsRoleSelector(authUser);
const tierRoles = getTierRoles(authUser);

// แสดง Dropdown เฉพาะเมื่อ showRoleSelector = true
{showRoleSelector && (
  <DropdownMenu>
    <DropdownMenuTrigger>
      <Button variant="ghost">
        {getRoleDisplayName(activeRole)}
      </Button>
    </DropdownMenuTrigger>
    <DropdownMenuContent>
      {tierRoles.map(role => (
        <DropdownMenuItem
          key={role}
          onClick={() => setActiveRole(role)}
        >
          {getRoleDisplayName(role)}
          {role === activeRole && <Check />}
        </DropdownMenuItem>
      ))}
    </DropdownMenuContent>
  </DropdownMenu>
)}
```

---

### 3. State Management

**ไฟล์:** `/contexts/AuthContext.tsx`

```typescript
export interface User {
  id: string;
  username: string;
  fullName: string;
  role: UserRole; // Legacy - for backward compatibility
  roles: UserRole[]; // NEW: Array of all roles
  primaryRole: UserRole; // NEW: Default role on login
  // ... other fields
}

interface AuthContextType {
  user: User | null;
  activeRole: UserRole; // 🆕 บทบาทที่กำลังใช้งาน
  setActiveRole: (role: UserRole) => void; // 🆕 ฟังก์ชันสลับบทบาท
  // ... other methods
}

// ฟังก์ชันสลับบทบาท
const setActiveRole = (role: UserRole) => {
  if (!user) return;
  
  // ตรวจสอบว่า user มี role นี้หรือไม่
  if (!user.roles?.includes(role)) {
    console.warn(`User does not have role: ${role}`);
    return;
  }
  
  setActiveRoleState(role);
  sessionStorage.setItem('cdgs_active_role', role);
};
```

---

### 4. Mock Data Structure

**ไฟล์:** `/lib/mock-users.ts`

```typescript
// ตัวอย่าง: ผู้ใช้งานที่มีหลายบทบาท
{
  username: 'prakasit.p',
  password: 'prakasit.p123',
  description: 'Tier2 + Tier3 - ประกาศิต ประคองเพ็ชร',
  user: {
    id: 'user-007',
    username: 'prakasit.p',
    fullName: 'ประกาศิต ประคองเพ็ชร',
    role: 'tier2', // Backward compatibility
    roles: ['tier2', 'tier3'], // ✅ Multi-role support
    primaryRole: 'tier2', // ✅ บทบาทหลัก
    email: 'prakasit.p@cdg.co.th',
    tier: 2,
    projectIds: ['proj-001', 'proj-002', ...], // รับผิดชอบทุกโครงการ
    managerId: 'user-006',
    managerEmail: 'yuttana.k@cdg.co.th'
  }
}
```

---

## 📊 สถิติการใช้งาน

| เงื่อนไข | จำนวน | เปอร์เซ็นต์ |
|---------|-------|------------|
| **ผู้ใช้งานทั้งหมด** | 11 คน | 100% |
| **สามารถสลับบทบาท** | 1 คน | 9.09% |
| **ไม่สามารถสลับบทบาท** | 10 คน | 90.91% |

---

## ⚠️ ข้อควรระวัง

### 1. **การเห็นเคส (Visibility)**
- เมื่อสลับบทบาท ระบบจะแสดงเคสตาม **Inverted Visibility Model**
- Tier 2 → เห็นเคสมากกว่า Tier 3
- Tier 3 → เห็นเฉพาะเคสที่ส่งต่อมาที่ Tier 3 เท่านั้น

### 2. **การรับเคส**
- เมื่อสลับเป็น Tier 3 และรับเคส → เคสจะถูก assign ให้กับ user ในฐานะ Tier 3
- เมื่อสลับกลับมาเป็น Tier 2 → เคสที่รับในฐานะ Tier 3 จะยังคงอยู่

### 3. **การส่งต่อเคส**
- เมื่ออยู่ในบทบาท Tier 2 → สามารถส่งต่อไปยัง Tier 1, Tier 2 (คนอื่น), Tier 3 ได้
- เมื่ออยู่ในบทบาท Tier 3 → สามารถส่งต่อไปยัง Tier 1, Tier 2, Tier 3 (คนอื่น) ได้

### 4. **การปิดเคส**
- ⚠️ **Tier 2 และ Tier 3 ไม่สามารถปิดเคสได้โดยตรง**
- ต้องส่งกลับไปที่ Tier 1 เพื่อปิดเคสเท่านั้น
- ดูรายละเอียดเพิ่มเติมที่ [CLOSE_TICKET_LOGIC.md](features/CLOSE_TICKET_LOGIC.md)

### 5. **การกรองเคสตาม activeRole (🆕 Fixed)**
- ✅ **ระบบกรองเคสอัตโนมัติตาม activeRole**
- เมื่อสลับเป็น Tier 2 → เห็นเฉพาะเคส Tier 2 (ไม่เห็น Tier 3)
- เมื่อสลับเป็น Tier 3 → เห็นเฉพาะเคส Tier 3 (ไม่เห็น Tier 2)
- 🐛 **Bug ที่แก้ไขแล้ว (21 ม.ค. 2026):**
  - ก่อนแก้ไข: สลับเป็น Tier 2 แต่ยังเห็นเคส Tier 3 ❌
  - หลังแก้ไข: สลับเป็น Tier 2 → เห็นเฉพาะ Tier 2 ✅
  - รายละเอียด: ดูที่ [AUTO_ASSIGN_AND_ACCEPT_BUTTON_RULES.md](features/AUTO_ASSIGN_AND_ACCEPT_BUTTON_RULES.md) - Bug #4

---

## 📚 เอกสารอ้างอิง

- **[USER_LIST.md](../team/USER_LIST.md)** - รายชื่อผู้ใช้งานทั้งหมด
- **[CLOSE_TICKET_LOGIC.md](features/CLOSE_TICKET_LOGIC.md)** - กฎการปิดเคส
- **[docs/PROJECT_OVERVIEW.md](features/PROJECT_OVERVIEW.md)** - ภาพรวมระบบ
- **[docs/PERMISSION_MATRIX.md](technical/PERMISSION_MATRIX.md)** - ตารางสิทธิ์การเข้าถึง
- **[docs/NAVIGATION_MENU.md](features/NAVIGATION_MENU.md)** - โครงสร้างเมนู

---

## 🔄 ประวัติการอัปเดต

| วันที่ | รายละเอียด | ผู้อัปเดต |
|-------|-----------|----------|
| 16 มกราคม 2026 | สร้างเอกสารฉบับแรก | CDGS Development Team |
| 16 มกราคม 2026 | แก้ไข `getTierRoles()` ให้สลับได้เฉพาะ tier2 และ tier3 | CDGS Development Team |
| 16 มกราคม 2026 | แก้ไขการแสดงชื่อใน Header จาก `user.name` เป็น `user.fullName` | CDGS Development Team |
| 21 มกราคม 2026 | แก้ไข Bug #4: Multi-Role กรองเคสตาม activeRole | CDGS Development Team |

---

## 💡 คำถามที่พบบ่อย (FAQ)

### Q1: ทำไม Tier 1 ไม่สามารถสลับบทบาทได้?
**A:** Tier 1 เป็นบทบาทหลักในการจัดการและปิดเคส ถ้ามีการสลับบทบาทจะทำให้เกิดความสับสนในการจัดการเคส และอาจส่งผลต่อเวิร์กโฟลว์การปิดเคสที่ต้องผ่าน Tier 1 เท่านั้น

### Q2: ถ้าผู้ใช้งานมี 3 บทบาท (Tier 1 + Tier 2 + Tier 3) จะสลับได้หรือไม่?
**A:** ไม่ได้ เพราะ Tier 1 ไม่สามารถสลับบทบาทได้ ระบบจะตรวจสอบว่ามีเฉพาะ Tier 2 และ Tier 3 เท่านั้น จึงจะแสดงปุ่มสลับบทบาท

### Q3: ถ้าสลับบทบาทแล้วลืม login ออก จะเกิดอะไรขึ้น?
**A:** ระบบจะบันทึก `activeRole` ไว้ใน `sessionStorage` เมื่อ login ใหม่จะกู้คืนบทบาทล่าสุดที่ใช้งาน

### Q4: Admin สามารถสลับบทบาทได้หรือไม่?
**A:** ไม่ได้ Admin เป็นบทบาทเฉพาะสำหรับจัดการระบบ ไม่สามารถสลับบทบาทได้

### Q5: ถ้าต้องการเพิ่มผู้ใช้งานที่สลับบทบาทได้ ต้องทำอย่างไร?
**A:** แก้ไขไฟล์ `/lib/mock-users.ts` โดยเพิ่ม `roles: ['tier2', 'tier3']` ให้กับผู้ใช้งานที่ต้องการ

---

**สถานะเอกสาร:** ✅ เอกสารครบถ้วน  
**ผู้จัดทำ:** CDGS Development Team  
**อัปเดตล่าสุด:** 21 มกราคม 2026
