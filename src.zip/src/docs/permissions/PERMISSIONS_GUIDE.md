# 🔐 Permissions & Capabilities System Guide

**เวอร์ชัน:** 2.0  
**วันที่:** 22 มกราคม 2025  
**ไฟล์:** `/lib/permissions.ts`

---

## 🎯 ทำไมต้องใช้ Capability-based System?

### **ปัญหาของ Role-based (แบบเก่า)**

```typescript
// ❌ ต้องเช็ค role ซ้ำๆ ทั่วทั้งระบบ
{hasRole(user, 'tier1') && hasRole(user, 'staff') && <Button>ปิดเคส</Button>}

// ❌ ถ้าเปลี่ยนกฎ → ต้องแก้ทุกจุด
{(hasRole(user, 'tier1') || hasRole(user, 'tier2')) && <Button>ปิดเคส</Button>}

// ❌ ไม่รู้ว่า role นี้ทำอะไรได้บ้าง
hasRole(user, 'tier1') // ปิดเคสได้ไหม? รับเคสได้ไหม?
```

### **ข้อดีของ Capability-based (แบบใหม่)**

```typescript
// ✅ อ่านแล้วเข้าใจทันที
{can(user, CAPABILITIES.CLOSE_TICKET) && <Button>ปิดเคส</Button>}

// ✅ เปลี่ยนกฎ → แก้ที่เดียว (ใน permissions.ts)
// Component ไม่ต้องแก้เลย!

// ✅ รู้ชัดเจนว่าทำอะไรได้
const caps = getUserCapabilities(user);
// ['create_ticket_for_customer', 'accept_ticket', 'close_ticket']
```

---

## 📋 Capabilities ทั้งหมด

| Capability | คำอธิบาย | ใช้ได้กับ Role |
|------------|----------|---------------|
| **CREATE_TICKET_FOR_CUSTOMER** | บันทึกเคสแทนลูกค้า | Staff, Tier1 |
| **ACCEPT_TICKET** | รับเคส | Tier1, Tier2, Tier3 |
| **CLOSE_TICKET** | ปิดเคส | Tier1 เท่านั้น |
| **ESCALATE_TICKET** | ส่งต่อเคส | Tier1, Tier2, Tier3 |
| **ASSIGN_TICKET** | มอบหมายเคส | Tier1, Admin |
| **UPDATE_TICKET** | แก้ไขเคส | Tier1, Tier2, Tier3 |
| **VIEW_ALL_TICKETS** | ดูเคสทั้งหมด | Staff, Tier1, Tier2, Tier3, Admin |
| **CREATE_OWN_TICKET** | แจ้งเคสของตัวเอง | Customer |
| **VIEW_OWN_TICKETS** | ดูเคสของตัวเอง | Customer |
| **MANAGE_USERS** | จัดการผู้ใช้ | Admin |
| **MANAGE_PROJECTS** | จัดการโครงการ | Admin |
| **MANAGE_SETTINGS** | ตั้งค่าระบบ | Admin |

---

## 👥 Role → Capabilities Mapping

### **Customer**
```typescript
ROLE_CAPABILITIES.customer = [
  'create_own_ticket',      // แจ้งเคส
  'view_own_tickets',       // ดูเคสของตัวเอง
];
```

### **Staff (บันทึกเคสแทนลูกค้าเท่านั้น)**
```typescript
ROLE_CAPABILITIES.staff = [
  'create_ticket_for_customer', // บันทึกเคสแทนลูกค้า
  'view_all_tickets',           // ดูเคสทั้งหมด
];
```

### **Tier1 (มีสิทธิ์เต็มรูปแบบ)**
```typescript
ROLE_CAPABILITIES.tier1 = [
  'create_ticket_for_customer', // บันทึกเคสแทนลูกค้า
  'accept_ticket',              // รับเคส
  'close_ticket',               // ปิดเคส ⭐
  'escalate_ticket',            // ส่งต่อเคส
  'assign_ticket',              // มอบหมายเคส
  'update_ticket',              // แก้ไขเคส
  'view_all_tickets',           // ดูเคสทั้งหมด
];
```

### **Tier2**
```typescript
ROLE_CAPABILITIES.tier2 = [
  'accept_ticket',     // รับเคส
  'escalate_ticket',   // ส่งต่อเคส
  'update_ticket',     // แก้ไขเคส
  'view_all_tickets',  // ดูเคสทั้งหมด
];
```

### **Tier3**
```typescript
ROLE_CAPABILITIES.tier3 = [
  'accept_ticket',     // รับเคส
  'escalate_ticket',   // ส่งต่อเคส
  'update_ticket',     // แก้ไขเคส
  'view_all_tickets',  // ดูเคสทั้งหมด
];
```

### **Admin**
```typescript
ROLE_CAPABILITIES.admin = [
  'manage_users',      // จัดการผู้ใช้
  'manage_projects',   // จัดการโครงการ
  'manage_settings',   // ตั้งค่าระบบ
  'view_all_tickets',  // ดูเคสทั้งหมด
  'assign_ticket',     // มอบหมายเคส
];
```

**หมายเหตุ:** Admin ที่ไม่มี tier1 **ไม่สามารถปิดเคส**ได้

---

## 🔧 การใช้งาน

### **1. Import**

```typescript
import { can, CAPABILITIES, getUserCapabilities } from '../lib/permissions';
```

---

### **2. เช็คความสามารถเดี่ยว**

```typescript
// เช็คว่าปิดเคสได้ไหม
if (can(user, CAPABILITIES.CLOSE_TICKET)) {
  // แสดงปุ่มปิดเคส
}

// เช็คว่ารับเคสได้ไหม
if (can(user, CAPABILITIES.ACCEPT_TICKET)) {
  // แสดงปุ่มรับเคส
}
```

---

### **3. เช็คหลายความสามารถ**

```typescript
import { canAll, canAny } from '../lib/permissions';

// ต้องมีทั้งหมด (AND)
if (canAll(user, [
  CAPABILITIES.ACCEPT_TICKET,
  CAPABILITIES.CLOSE_TICKET
])) {
  // แสดงปุ่มพิเศษ
}

// มีอย่างน้อย 1 อย่าง (OR)
if (canAny(user, [
  CAPABILITIES.ACCEPT_TICKET,
  CAPABILITIES.ESCALATE_TICKET
])) {
  // แสดงเมนู Tier
}
```

---

### **4. ดูความสามารถทั้งหมด**

```typescript
const capabilities = getUserCapabilities(user);
console.log('User can:', capabilities);
// ['create_ticket_for_customer', 'accept_ticket', 'close_ticket', ...]
```

---

### **5. ใช้ใน Component**

```typescript
export function CreateTicketPage() {
  const { user } = useAuth();
  
  // ✅ เช็คความสามารถแทน role
  const canCreateForCustomer = can(user, CAPABILITIES.CREATE_TICKET_FOR_CUSTOMER);
  const canAcceptTicket = can(user, CAPABILITIES.ACCEPT_TICKET);
  const canCloseTicket = can(user, CAPABILITIES.CLOSE_TICKET);
  
  return (
    <form>
      {/* แสดงฟอร์ม Staff */}
      {canCreateForCustomer && (
        <CustomerInfoForm />
      )}
      
      {/* ปุ่มรับเคส */}
      {canAcceptTicket && (
        <Button>รับเคส</Button>
      )}
      
      {/* ปุ่มปิดเคส */}
      {canCloseTicket && (
        <Button>ปิดเคส</Button>
      )}
    </form>
  );
}
```

---

### **6. Helper Functions (Backward Compatibility)**

```typescript
import { isTier1, isPureStaff, isCustomer, isAdmin } from '../lib/permissions';

// เช็คว่าเป็น Tier1
if (isTier1(user)) {
  // Tier1 = คนที่ปิดเคสได้
}

// เช็คว่าเป็น Pure Staff
if (isPureStaff(user)) {
  // Pure Staff = บันทึกเคสได้ แต่ไม่รับเคส
}
```

---

## 📊 ตัวอย่างการใช้งานจริง

### **ตัวอย่างที่ 1: CreateTicketPage - ปุ่มต่างๆ**

**Before (แบบเก่า):**
```typescript
{/* Pure Staff */}
{hasRole(user, 'staff') && !hasRole(user, 'tier1') && (
  <Button>ส่งงาน</Button>
)}

{/* Tier1 */}
{hasRole(user, 'staff') && hasRole(user, 'tier1') && (
  <>
    <Button>แก้ไขและปิดเคส</Button>
    <Button>บันทึกและรับเคส</Button>
  </>
)}
```

**After (แบบใหม่):**
```typescript
{/* Pure Staff */}
{isPureStaff(user) && (
  <Button>ส่งงาน</Button>
)}

{/* Tier1 */}
{isTier1(user) && (
  <>
    <Button>แก้ไขและปิดเคส</Button>
    <Button>บันทึกและรับเคส</Button>
  </>
)}
```

---

### **ตัวอย่างที่ 2: TicketActions - ปุ่มปิดเคส**

**Before (แบบเก่า):**
```typescript
const hasTier1Role = userRole === 'tier1' && 
                     user?.roles?.includes('tier1') && 
                     user?.roles?.includes('staff');

const canClose = hasTier1Role && isResolved;
```

**After (แบบใหม่):**
```typescript
const canClose = can(user, CAPABILITIES.CLOSE_TICKET) && isResolved;
```

---

### **ตัวอย่างที่ 3: เพิ่ม Feature ใหม่**

**Requirement:** Tier2 ต้องสามารถปิดเคสได้ด้วย

**Before (แบบเก่า - ต้องแก้ทุกจุด):**
```typescript
// ❌ ต้องไปแก้ทุกที่
{(hasRole(user, 'tier1') || hasRole(user, 'tier2')) && <CloseButton />}
{(hasRole(user, 'tier1') || hasRole(user, 'tier2')) && <CloseModal />}
// ... ต้องหาและแก้ทุกจุด
```

**After (แบบใหม่ - แก้ที่เดียว):**
```typescript
// ✅ แก้แค่ permissions.ts
ROLE_CAPABILITIES.tier2 = [
  'accept_ticket',
  'close_ticket', // ← เพิ่มบรรทัดเดียว
  'escalate_ticket',
];

// Component ไม่ต้องแก้เลย!
{can(user, CAPABILITIES.CLOSE_TICKET) && <CloseButton />}
{can(user, CAPABILITIES.CLOSE_TICKET) && <CloseModal />}
```

---

## 🔄 Multi-role Support

ระบบรองรับ Multi-role โดยอัตโนมัติ:

```typescript
// ตัวอย่าง: Admin + Tier1
const user = {
  roles: ['admin', 'tier1', 'staff']
};

// ได้ capabilities รวมกัน
getUserCapabilities(user);
// [
//   'manage_users',              // จาก admin
//   'manage_projects',           // จาก admin
//   'create_ticket_for_customer', // จาก tier1
//   'accept_ticket',             // จาก tier1
//   'close_ticket',              // จาก tier1
//   ...
// ]

// เช็คได้ทุก capability
can(user, CAPABILITIES.MANAGE_USERS);  // true (จาก admin)
can(user, CAPABILITIES.CLOSE_TICKET);  // true (จาก tier1)
```

---

## ✅ Best Practices

### **1. ใช้ CAPABILITIES constants เสมอ**
```typescript
// ✅ ถูก
can(user, CAPABILITIES.CLOSE_TICKET)

// ❌ ผิด - อย่าใช้ string โดยตรง
can(user, 'close_ticket')
```

### **2. อธิบายเหตุผล**
```typescript
// ✅ ดี - มี comment อธิบาย
// แสดงปุ่มปิดเคสเฉพาะ Tier1 และเคสต้อง resolved แล้ว
{can(user, CAPABILITIES.CLOSE_TICKET) && isResolved && (
  <CloseButton />
)}
```

### **3. ใช้ Helper Functions**
```typescript
// ✅ ดี - ใช้ helper ที่มีชื่อชัดเจน
if (isTier1(user)) { ... }

// ⚠️ OK - แต่ไม่ค่อยชัดเจน
if (can(user, CAPABILITIES.CLOSE_TICKET)) { ... }
```

### **4. Test Capabilities ไม่ใช่ Roles**
```typescript
// ✅ ถูก
test('user can close ticket', () => {
  expect(can(user, CAPABILITIES.CLOSE_TICKET)).toBe(true);
});

// ❌ ผิด
test('user is tier1', () => {
  expect(user.roles.includes('tier1')).toBe(true);
});
```

---

## 🚨 Migration Guide

### **ขั้นตอนการแปลง Component เก่า → ใหม่**

#### **Step 1: Import**
```typescript
import { can, CAPABILITIES, isTier1, isPureStaff } from '../lib/permissions';
```

#### **Step 2: แทนที่การเช็ค**
```typescript
// เก่า
hasRole(user, 'tier1') && hasRole(user, 'staff')
// ใหม่
isTier1(user)
// หรือ
can(user, CAPABILITIES.CLOSE_TICKET)
```

#### **Step 3: ลบโค้ดซ้ำซ้อน**
```typescript
// เก่า (ซ้ำ 5 จุด)
{hasRole(user, 'tier1') && <Button1 />}
{hasRole(user, 'tier1') && <Button2 />}
{hasRole(user, 'tier1') && <Button3 />}

// ใหม่ (เช็คครั้งเดียว)
const showTier1Features = isTier1(user);

{showTier1Features && <Button1 />}
{showTier1Features && <Button2 />}
{showTier1Features && <Button3 />}
```

---

## 📚 เอกสารที่เกี่ยวข้อง

- **ROLE_STRUCTURE.md** - โครงสร้าง Role และผู้ใช้ทั้งหมด
- **MIGRATION_CHECKLIST.md** - Checklist การแก้ไข Components
- **/lib/permissions.ts** - Source code ระบบ Permissions

---

**สร้างโดย:** CDGS Development Team  
**วันที่สร้าง:** 22 มกราคม 2025  
**อัปเดตล่าสุด:** 22 มกราคม 2025
