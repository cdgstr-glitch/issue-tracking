# 📏 Mock Data Rules & Guidelines (กฎเหล็กการจำลองข้อมูล)

**Last Updated:** 27 มกราคม 2026
**Status:** ✅ Active

เอกสารนี้รวบรวม "กฎเหล็ก" (Iron Rules) สำหรับการสร้างและจัดการ Mock Data ในระบบ CDGS Issue Tracking Platform เพื่อให้ข้อมูลมีความถูกต้องและสอดคล้องกับ Logic การทำงานจริงของระบบ

---

## 🚨 Iron Rules (กฎเหล็ก)

### 1. New Customer Web Tickets (เคสใหม่ที่ลูกค้าแจ้งผ่านเว็บ)

สำหรับ Ticket ที่มีเงื่อนไขดังนี้:
- `channel`: `'web'`
- `createdByType`: `'customer_self'`
- `status`: `'new'`

**ข้อกำหนด:** ต้องปล่อยฟิลด์ต่อไปนี้ให้เป็น **ค่าว่าง** (Empty String) เสมอ ห้ามใส่ข้อมูล Mock มาล่วงหน้า เพราะตาม Flow จริง ข้อมูลเหล่านี้ต้องรอการ Triage (คัดกรอง) จากเจ้าหน้าที่ Tier 1 หรือ Staff

| Field | Required Value | เหตุผล (Reason) |
|-------|----------------|----------------|
| **`category`** | `''` (Empty) | ลูกค้าทั่วไปมักเลือกหมวดหมู่ทางเทคนิคไม่ถูกต้อง รอเจ้าหน้าที่จัดกลุ่ม |
| **`priority`** | `''` (Empty) | ความเร่งด่วนต้องถูกประเมินโดยเจ้าหน้าที่ตาม SLA ไม่ใช่ความรู้สึกของลูกค้า |
| **`type`** | `''` (Empty) | ลูกค้าแยกแยะ Incident (แจ้งซ่อม) กับ Request (คำขอ) ได้ยาก รอเจ้าหน้าที่ระบุ |
| **`projectId`** | `''` (Empty) | ลูกค้าไม่ทราบ Project Code ภายใน หรือสัญญาที่ถูกต้อง รอเจ้าหน้าที่ตรวจสอบและเลือกให้ |

**✅ ตัวอย่างที่ถูกต้อง (Correct Mock Data):**

```typescript
{
  id: 'c-new-example',
  ticketNumber: 'CDGS-2026-C999',
  title: 'ขอคู่มือการใช้งาน',
  description: 'หาเมนูไม่เจอครับ',
  status: 'new',
  channel: 'web', 
  createdByType: 'customer_self',
  
  // ✅ ต้องว่างไว้สำหรับ Triage
  category: '',
  priority: '',
  type: '',
  projectId: '', 

  // ข้อมูลที่ลูกค้ากรอกได้
  product: 'e-saraban',
  customerName: 'Somchai',
  // ...
}
```

**❌ ตัวอย่างที่ผิด (Incorrect Mock Data):**

```typescript
{
  ...
  channel: 'web',
  status: 'new',
  
  // ❌ ห้ามระบุข้อมูลเหล่านี้ในเคสใหม่จากเว็บ
  category: 'Documentation', 
  priority: 'low',
  type: 'question',
  projectId: 'proj-csv-002' 
}
```

---

### 2. Staff & Tier 1 Actions

- **Staff:** ทำหน้าที่รับเรื่องและบันทึกข้อมูลแทนลูกค้า (On Behalf Of) แต่ **ห้ามปิดเคส** ทันที ต้องส่งต่อให้ Tier 1 เสมอ
- **Tier 1:** เป็นผู้เดียวที่มีสิทธิ์ **ปิดเคส** (Close Ticket) และเป็นผู้ตรวจสอบความถูกต้องของข้อมูล (Triage) จาก Web Ticket

---

### 3. Project & Organization Codes

- **Organization Code:** ต้องขึ้นต้นด้วย `ORG-{NNN}` เช่น `ORG-001`
- **Project Code:** ต้องขึ้นต้นด้วย `D{YY}-{XXXX}` เช่น `D26-0001`

---

## 🛠️ การตรวจสอบความถูกต้อง (Validation)

ก่อนการ Merge หรือ Deploy Mock Data ใหม่ ให้ตรวจสอบว่าข้อมูลเป็นไปตามกฎข้างต้นเสมอ เพื่อป้องกัน Logic Error ในหน้า Frontend (เช่น หน้า Triage ที่คาดหวังค่าว่าง)
