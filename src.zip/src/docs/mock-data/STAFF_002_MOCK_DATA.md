# 📞 Staff-002 Mock Data Documentation
## เอกชัย เบ็นเจ๊ะอาหวัง - Digital & SaaS Project Support

**วันที่:** 26 มกราคม 2026  
**สถานะ:** ✅ เสร็จสมบูรณ์

---

## 👤 ข้อมูล Staff-002

| ฟิลด์ | ค่า |
|------|-----|
| **ชื่อ-นามสกุล** | เอกชัย เบ็นเจ๊ะอาหวัง |
| **Username** | `eakkachai.b` |
| **Password** | `eakkachai.b123` |
| **User ID** | `staff-002` |
| **Email** | eakkachai.b@cdg.co.th |
| **เบอร์โทร** | +66-82-456-7890 |
| **ตำแหน่ง** | Digital & SaaS Project Support |
| **Role** | `staff` |
| **โครงการที่รับผิดชอบ** | proj-001, proj-002, proj-003, proj-004, proj-005 (5 โครงการ) |

---

## 📊 สรุปเคสตัวอย่าง

| สถิติ | จำนวน |
|-------|-------|
| **รวมทั้งหมด** | 5 เคส |
| **Active** | 4 เคส |
| **Closed** | 1 เคส |
| **Channel: Email** | 3 เคส |
| **Channel: Line** | 1 เคส |
| **Channel: Phone** | 1 เคส |

### สถานะเคส

| Status | จำนวน | Ticket Numbers |
|--------|-------|----------------|
| `new` | 1 | CDGS-2026-E001 |
| `tier1` | 2 | CDGS-2026-E002, CDGS-2026-E003 |
| `tier2` | 1 | CDGS-2026-E005 |
| `closed` | 1 | CDGS-2026-E004 |

---

## 📋 รายละเอียดเคสทั้งหมด

### เคส 1: ขอคำปรึกษาการใช้งาน SaaS Platform ✨

**Ticket Number:** `CDGS-2026-E001`  
**Status:** `new` (รอ Tier1 รับ)  
**Channel:** Email  
**Priority:** Medium  
**Category:** Technical Support

**ลูกค้า:**
- ชื่อ: นายพิชัย สุขสวัสดิ์
- Email: pichai.s@company.com
- โทร: +66-92-345-6789

**โครงการ:** proj-004 (สำนักงานพัฒนาวิทยาศาสตร์และเทคโนโลยีแห่งชาติ - NSTDA)

**รายละเอียด:** ลูกค้าส่งอีเมลสอบถามเรื่องการติดตั้งและใช้งาน SaaS Platform - ต้องการความช่วยเหลือในการ Configure ระบบ

**Timeline:**
1. 26 ม.ค. 2026 09:30 - เอกชัย เบ็นเจ๊ะอาหวัง บันทึกเคส

---

### เคส 2: ปัญหาการเชื่อมต่อ API ระหว่างระบบ 🔴

**Ticket Number:** `CDGS-2026-E002`  
**Status:** `tier1` (กำลังดำเนินการ)  
**Channel:** Line  
**Priority:** High ⚠️  
**Category:** Technical Support

**ลูกค้า:**
- ชื่อ: คุณวิไลวรรณ ศรีสวัสดิ์
- Email: wilaiwan.s@enterprise.co.th
- โทร: +66-81-987-6543
- Line ID: @wilaiwan_api

**โครงการ:** proj-005 (การประปานครหลวง - MWA)

**รายละเอียด:** ลูกค้า Line มาแจ้งว่ามีปัญหาการเชื่อมต่อ API ระหว่างระบบหลักกับ SaaS Platform ได้รับ Error 503

**ผู้รับผิดชอบ:** ธิราภรณ์ รุ่งวิรัตน์กุล (user-001)

**Timeline:**
1. 25 ม.ค. 2026 14:00 - เอกชัย เบ็นเจ๊ะอาหวัง บันทึกเคส
2. 25 ม.ค. 2026 14:15 - ธิราภรณ์ รุ่งวิรัตน์กุล รับเคส
3. 25 ม.ค. 2026 16:30 - กำลังตรวจสอบ Log ของระบบ

**SLA:** At Risk ⚠️

---

### เคส 3: ขอข้อมูล Product Specification สำหรับโครงการใหม่ 📄

**Ticket Number:** `CDGS-2026-E003`  
**Status:** `tier1` (กำลังดำเนินการ)  
**Channel:** Phone  
**Priority:** Medium  
**Category:** Product Information

**ลูกค้า:**
- ชื่อ: นางสาวอรพิมล จันทร์แจ่ม
- Email: orapin.c@government.go.th
- โทร: +66-82-111-2233

**โครงการ:** proj-003 (กรมการปกครอง - DRT)

**รายละเอียด:** ลูกค้าโทรมาสอบถามข้อมูล Technical Specification ของ SaaS Platform สำหรับนำเสนอโครงการใหม่

**ผู้รับผิดชอบ:** สาริน ช่อพะยอม (user-002)

**Timeline:**
1. 24 ม.ค. 2026 10:00 - เอกชัย เบ็นเจ๊ะอาหวัง บันทึกเคส
2. 24 ม.ค. 2026 10:20 - สาริน ช่อพะยอม รับเคส
3. 24 ม.ค. 2026 11:45 - ส่งเอกสาร Product Specification ทาง Email แล้ว

---

### เคส 4: ขอ License Key เพิ่มเติมสำหรับ User ใหม่ ✅ #แก้ไขแล้ว

**Ticket Number:** `CDGS-2026-E004`  
**Status:** `closed` ✅  
**Channel:** Email  
**Priority:** Low  
**Category:** License Management

**ลูกค้า:**
- ชื่อ: นายสุรชัย ประดิษฐ์
- Email: surachai.p@company.co.th
- โทร: +66-91-444-5555

**โครงการ:** proj-002 (กรมพัฒนาธุรกิจการค้า - DBD)

**รายละเอียด:** ลูกค้าส่งอีเมลขอ License Key เพิ่มอีก 5 Users สำหรับทีมใหม่

**ผู้รับผิดชอบ:** วรรณภา แซ่ด่าง (user-003)

**วิธีแก้ไข:** ได้ออก License Key จำนวน 5 ชุดและส่งไปทาง Email แล้ว พร้อมคู่มือการติดตั้งและใช้งาน

**หมายเหตุ:** ลูกค้าได้รับ License Key และสามารถเปิดใช้งานได้สำเร็จ

**Timeline:**
1. 23 ม.ค. 2026 09:00 - เอกชัย เบ็นเจ๊ะอาหวัง บันทึกเคส
2. 23 ม.ค. 2026 09:30 - วรรณภา แซ่ด่าง รับเคส
3. 23 ม.ค. 2026 15:30 - ออก License Key เสร็จสิ้น
4. 23 ม.ค. 2026 15:45 - วรรณภา แซ่ด่าง ปิดเคส ✅

**SLA:** Met ✅

---

### เคส 5: ปัญหา Performance ของระบบช้าในช่วงเวลา Peak 🔴

**Ticket Number:** `CDGS-2026-E005`  
**Status:** `tier2` (Escalated)  
**Channel:** Phone  
**Priority:** High ⚠️  
**Category:** Performance

**ลูกค้า:**
- ชื่อ: นางวิภาดา สุขใจ
- Email: vipada.s@company.co.th
- โทร: +66-85-666-7777

**โครงการ:** proj-001 (ระบบสารบรรณ - DMS)

**รายละเอียด:** ลูกค้าโทรมาร้องเรียนว่าระบบทำงานช้ามากในช่วง 13:00-15:00 น. ต้องการตรวจสอบและแก้ไข

**ผู้รับผิดชอบ:** ยุทธนา คณามิ่งมงคล (user-007) - Tier2

**Escalation Reason:** ปัญหาด้าน Performance ต้องให้ทีม Infrastructure ตรวจสอบ

**Timeline:**
1. 22 ม.ค. 2026 13:45 - เอกชัย เบ็นเจ๊ะอาหวัง บันทึกเคส
2. 22 ม.ค. 2026 14:00 - ธิราภรณ์ รุ่งวิรัตน์กุล รับเคส (Tier1)
3. 22 ม.ค. 2026 14:30 - Escalate ไป Tier2 → ยุทธนา คณามิ่งมงคล
4. 22 ม.ค. 2026 16:00 - กำลังวิเคราะห์ Query Performance และ Server Load

**SLA:** At Risk ⚠️

---

## 📁 โครงสร้างไฟล์

```
/lib/mockData/
│
├── users.ts                              # เพิ่ม Staff-002 account
│
├── tickets/
│   └── staff/
│       ├── staff-002-tickets.ts          # ✅ ไฟล์ใหม่ - เคสของเอกชัย (5 เคส)
│       └── index.ts                      # Export staff002Tickets
│
└── mockData.ts                           # รวม staff002Tickets เข้า allTickets
```

---

## 🔧 การใช้งาน

### Import เคสของ Staff-002

```typescript
// Import เฉพาะเคสของ Staff-002
import { staff002Tickets } from '@/lib/mockData/tickets/staff/staff-002-tickets';

console.log(staff002Tickets.length); // 5

// หรือ import จาก index
import { staff002Tickets } from '@/lib/mockData/tickets/staff';

// หรือ import เคส Staff ทั้งหมด (staff-001 + staff-002)
import { allStaffTickets } from '@/lib/mockData/tickets/staff';

console.log(allStaffTickets.length); // ~48 (43 + 5)
```

### Filter เคสตาม Creator

```typescript
import { allTickets } from '@/lib/mockData';

// เคสของ Staff-002 เท่านั้น
const staff002Cases = allTickets.filter(t => t.createdBy === 'staff-002');

console.log(staff002Cases.length); // 5
```

### Login เป็น Staff-002

```typescript
// Login
const result = await login('eakkachai.b', 'eakkachai.b123');

// User Object
{
  id: 'staff-002',
  username: 'eakkachai.b',
  fullName: 'เอกชัย เบ็นเจ๊ะอาหวัง',
  role: 'staff',
  roles: ['staff'],
  primaryRole: 'staff',
  email: 'eakkachai.b@cdg.co.th',
  phone: '+66-82-456-7890',
  department: 'Digital & SaaS Project Support',
  projectIds: ['proj-001', 'proj-002', 'proj-003', 'proj-004', 'proj-005']
}
```

---

## ✅ Validation Rules

เคสทั้ง 5 เคสผ่านการตรวจสอบตามกฎต่อไปนี้:

### 1. ✅ Channel ไม่ใช่ Web
```typescript
// ✅ Valid channels
'email'  // 3 เคส
'line'   // 1 เคส
'phone'  // 1 เคส

// ❌ Not allowed
'web'    // 0 เคส (ถูกต้อง!)
```

### 2. ✅ CreatedBy เป็น staff-002
```typescript
createdBy: 'staff-002'                          // ✅ ทุกเคส
createdByType: 'staff_on_behalf'                // ✅ ทุกเคส
createdByStaffName: 'เอกชัย เบ็นเจ๊ะอาหวัง'      // ✅ ทุกเคส
```

### 3. ✅ OnBehalfOf มีข้อมูลครบ
```typescript
// ทุกเคสมี onBehalfOf ตรงกับ customerName
onBehalfOf: 'นายพิชัย สุขสวัสดิ์'        // ✅
onBehalfOf: 'คุณวิไลวรรณ ศรีสวัสดิ์'    // ✅
// ... และต่อไป
```

### 4. ✅ Staff ไม่ปิดเคสเอง
```typescript
// เคสที่ปิดแล้ว
{
  status: 'closed',
  closedBy: 'user-003',     // ✅ Tier1 ปิด (วรรณภา แซ่ด่าง)
  createdBy: 'staff-002'    // ✅ Staff-002 สร้าง
}
```

---

## 📊 Statistics

### Channel Distribution

```
Email:  60% (3/5 เคส)
Line:   20% (1/5 เคส)
Phone:  20% (1/5 เคส)
```

### Priority Distribution

```
High:   40% (2/5 เคส)
Medium: 40% (2/5 เคส)
Low:    20% (1/5 เคส)
```

### Status Distribution

```
new:    20% (1/5 เคส)
tier1:  40% (2/5 เคส)
tier2:  20% (1/5 เคส)
closed: 20% (1/5 เคส)
```

### Project Distribution

```
proj-001: 1 เคส (DMS)
proj-002: 1 เคส (DBD)
proj-003: 1 เคส (DRT)
proj-004: 1 เคส (NSTDA)
proj-005: 1 เคส (MWA)
```

---

## 🔗 เอกสารที่เกี่ยวข้อง

- [Team Members](/docs/TEAM_MEMBERS.md) - รายชื่อพนักงานทั้งหมด (รวม Staff-002)
- [Role System & Active Role Switching](/docs/ROLE_SYSTEM_ACTIVE_ROLE_SWITCHING.md) - ระบบบทบาท (อัพเดทรวม Staff-002)
- [Staff Role Documentation](/docs/STAFF_ROLE_DOCUMENTATION.md) - บทบาท Staff
- [Staff Tickets README](/lib/mockData/tickets/staff/README.md) - เอกสารโครงสร้าง Staff Tickets

---

**สร้างโดย:** AI Assistant  
**วันที่:** 26 มกราคม 2026  
**Version:** 1.0  
**Status:** ✅ Production Ready
