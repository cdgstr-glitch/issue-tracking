# 📊 Mock Data Inventory - สารบบข้อมูล Mock ทั้งหมด

**Last Updated:** 26 มกราคม 2026  
**Version:** 1.0  
**Status:** 🔄 In Progress

---

## 📋 สารบัญ

1. [ภาพรวมข้อมูล](#ภาพรวมข้อมูล)
2. [Users (ผู้ใช้)](#users-ผู้ใช้)
3. [Projects (โครงการ)](#projects-โครงการ)
4. [Tickets (เคส)](#tickets-เคส)
5. [Organizations (หน่วยงาน)](#organizations-หน่วยงาน)
6. [Products (ผลิตภัณฑ์)](#products-ผลิตภัณฑ์)
7. [Attachments (ไฟล์แนบ)](#attachments-ไฟล์แนบ)
8. [ไฟล์และโครงสร้าง](#ไฟล์และโครงสร้าง)

---

## 🎯 ภาพรวมข้อมูล

### **สถิติรวม**

| ประเภท | จำนวน | ไฟล์หลัก | สถานะ |
|--------|-------|----------|-------|
| **Users** | 13 | `/lib/mockData/users.ts` | ✅ Organized |
| **Projects** | 73 | `/lib/mockData/projects.ts` | ✅ Organized |
| **Organizations** | 5 | `/lib/mockData/organizations.ts` | ✅ Organized |
| **Products** | 15 | `/lib/mockData/products.ts` | ✅ Organized |
| **Tickets** | 200+ | `/lib/mockData.ts` | ⚠️ Needs Migration |
| **Attachments** | ~20 | `/lib/mockData/helpers/attachments.ts` | ✅ Organized |

---

## 👥 Users (ผู้ใช้)

### **Total: 13 users**

#### **Breakdown by Role:**

| Role | จำนวน | User IDs |
|------|-------|----------|
| **Admin** | 1 | admin-001 |
| **Staff** | 3 | staff-001, user-003, user-004, user-005 |
| **Tier1** | 3 | user-001, user-002, user-003, user-004, user-005 |
| **Tier2** | 3 | user-006, user-007, user-008 |
| **Tier3** | 2 | user-009, user-010 |
| **Manager** | 1 | user-011 |
| **Customer** | 1 | customer-001 |

**หมายเหตุ:** 
- บางคนมี Multi-role (เช่น user-003 มีทั้ง Staff และ Tier1)
- ระบบใช้ Permission System แทน Multi-role แล้ว

#### **Staff List (4 คน):**
1. **staff-001** - สมชาย ใจดี (Staff เพียวๆ)
2. **user-003** - วรรณภา แซ่ด่าง (Staff + Tier1)
3. **user-004** - เขมิกา แซ่ตั้ง (Staff + Tier1)
4. **user-005** - ธัญญาพร ทองแก้ว (Staff + Tier1)

#### **Tier1 List (5 คน):**
1. **user-001** - ไพรวัลย์ คำดี (Tier1 Lead)
2. **user-002** - สาริน ช่อพะยอม (Tier1)
3. **user-003** - วรรณภา แซ่ด่าง (Tier1 + Staff)
4. **user-004** - เขมิกา แซ่ตั้ง (Tier1 + Staff)
5. **user-005** - ธัญญาพร ทองแก้ว (Tier1 + Staff)

---

## 📁 Projects (โครงการ)

### **Total: 73 projects**

#### **Breakdown by Source:**

| ประเภท | จำนวน | ไฟล์ |
|--------|-------|------|
| **CSV Projects** | 23 | `csvProjects` |
| **Legacy Projects** | 50 | `legacyProjects` |

#### **Project Code Format:**
- **Pattern:** `D{YY}-{XXXX}`
- **ตัวอย่าง:** D24-6067, D25-1001, D26-1001
- **หมายเหตุ:** ไม่จำเป็นต้องเรียงลำดับต่อเนื่อง

#### **Popular Projects (ตัวอย่าง):**
1. **D24-6067** - กระทรวงคมนาคม (MOT)
2. **D25-1001** - สำนักงาน ก.พ. (OCSC)
3. **D26-1001** - สำนักงานรัฐบาลอิเล็กทรอนิกส์ (EGA)
4. **D24-5012** - กรมการขนส่งทางบก (DLT)
5. **D24-5013** - กรมการขนส่งทางน้ำและพาณิชยนาวี (DMT)

---

## 🎫 Tickets (เคส)

### **Total: ~200+ tickets**

#### **⚠️ ปัญหาปัจจุบัน:**
- ข้อมูลกระจัดกระจายใน **หลายไฟล์**
- ไฟล์ใหญ่มาก (3000+ บรรทัด)
- ยากต่อการบำรุงรักษา

#### **Breakdown by File:**

| ไฟล์ | จำนวน (โดยประมาณ) | ประเภท |
|------|-------------------|--------|
| `/lib/mockData.ts` | 150+ | เคสหลัก (Customer + Staff) |
| `/lib/mockDataStaffClosed.ts` | 3 | เคสที่ Staff สร้างและปิดแล้ว |
| `/lib/mockDataCSVTickets.ts` | 20+ | เคสจาก CSV |
| `/lib/mockDataExtra.ts` | 10+ | เคสเพิ่มเติม |
| `/lib/mockDataTier23More.ts` | 10+ | เคส Tier2/3 |
| `/lib/mockDataTier23Resolved.ts` | 10+ | เคส Tier2/3 ที่แก้ไขแล้ว |

#### **Breakdown by Creator:**

| Creator Type | จำนวน | หมายเหตุ |
|-------------|-------|----------|
| **Customer-created** | ~100 | `createdByType: 'customer'` |
| **Staff-created** | ~100 | `createdByType: 'staff'` |

#### **Breakdown by Status:**

| Status | จำนวน | คำอธิบาย |
|--------|-------|----------|
| **new** | ~30 | รอดำเนินการ |
| **tier1** | ~40 | Tier1 รับแล้ว |
| **tier2** | ~20 | ส่งต่อ Tier2 |
| **tier3** | ~10 | ส่งต่อ Tier3 |
| **in_progress** | ~30 | กำลังดำเนินการ |
| **waiting** | ~10 | หยุดชั่วคราว |
| **resolved** | ~20 | แก้ไขแล้ว (รอปิด) |
| **closed** | ~40 | ปิดแล้ว |

#### **Breakdown by Channel:**

| Channel | จำนวน | คำอธิบาย |
|---------|-------|----------|
| **web** | ~100 | ลูกค้าแจ้งผ่านเว็บ |
| **phone** | ~50 | Staff บันทึกจากโทรศัพท์ |
| **email** | ~30 | Staff บันทึกจากอีเมล |
| **line** | ~20 | Staff บันทึกจาก Line |

#### **Staff Closed Tickets (เคสพิเศษ):**

**ไฟล์:** `/lib/mockDataStaffClosed.ts`

| Ticket Number | สร้างโดย | ปิดโดย | วันที่ปิด |
|---------------|---------|--------|----------|
| CDGS-2024-SC001 | user-003 (Staff) | user-001 (Tier1) | 2024-11-28 |
| CDGS-2024-SC002 | user-004 (Staff) | user-003 (Tier1) | 2024-11-28 |
| CDGS-2024-SC003 | user-005 (Staff) | user-001 (Tier1) | 2024-11-28 |

**หมายเหตุ:** 
- ✅ เฉพาะ Tier1 เท่านั้นที่สามารถปิดเคสได้
- ❌ ไม่มีเคสที่ `closedBy: 'staff-001'` อีกแล้ว (แก้ไขเรียบร้อย)

---

## 🏢 Organizations (หน่วยงาน)

### **Total: 5 organizations**

| Organization Code | Organization Name | Short Name |
|------------------|-------------------|------------|
| **ORG-001** | สำนักงานรัฐบาลอิเล็กทรอนิกส์ (องค์การมหาชน) | EGA |
| **ORG-002** | กระทรวงคมนาคม | MOT |
| **ORG-003** | กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม | MDES |
| **ORG-004** | กรุงเทพมหานคร | BMA |
| **ORG-005** | สำนักงาน ก.พ. | OCSC |

**Organization Code Format:**
- **Pattern:** `ORG-{NNN}`
- **ตัวอย่าง:** ORG-001, ORG-002, ORG-003

---

## 🛍️ Products (ผลิตภัณฑ์)

### **Total: 15 products**

#### **Active Products (13):**
1. Payroll System
2. HRIS
3. ERP
4. Smart City Platform
5. Document Management System
6. E-Office
7. Saraban
8. E-Learning
9. GPS Tracking
10. E-Payment
11. CRM
12. Inventory Management
13. Asset Management

#### **Deprecated Products (2):**
1. Old ERP (deprecated) → ย้ายไป ERP
2. Legacy Payroll (deprecated) → ย้ายไป Payroll System

**Product Deprecation:**
- ระบบจะ migrate ข้อมูลเก่าไปยังผลิตภัณฑ์ใหม่โดยอัตโนมัติ
- เคสเก่าจะยังแสดง Product เดิม แต่มี Badge "Deprecated"

---

## 📎 Attachments (ไฟล์แนบ)

### **Total: ~20 attachments**

#### **Breakdown by Type:**

| Type | จำนวน | Extension |
|------|-------|-----------|
| **Images** | ~10 | .png, .jpg |
| **Documents** | ~5 | .pdf |
| **Excel** | ~3 | .xlsx |
| **Videos** | ~2 | .mp4 |

#### **Popular Attachments:**
1. `error-screenshot.png` - ภาพ Error
2. `log-file.txt` - Log ระบบ
3. `report.pdf` - รายงาน
4. `data-export.xlsx` - ข้อมูล Export

---

## 📂 ไฟล์และโครงสร้าง

### **Current Structure (ปัจจุบัน):**

```
/lib/
├── mockData.ts                    # ⚠️ ใหญ่มาก 3000+ บรรทัด
├── mockDataStaffClosed.ts         # เคส Staff (3 เคส)
├── mockDataCSV.ts                 # เคสจาก CSV
├── mockDataExtra.ts               # เคสเพิ่มเติม
├── mockDataTier23More.ts          # เคส Tier2/3
├── mockDataTier23Resolved.ts      # เคส Tier2/3 ปิดแล้ว
├── mockDataProducts.ts            # ผลิตภัณฑ์
├── mockDataReports.ts             # รายงาน
│
├── mockData/                      # ✅ โครงสร้างใหม่ (ใช้แล้วบางส่วน)
│   ├── index.ts                   # Main export hub
│   ├── users.ts                   # ✅ Users (13)
│   ├── projects.ts                # ✅ Projects (73)
│   ├── organizations.ts           # ✅ Organizations (5)
│   ├── products.ts                # ✅ Products (15)
│   └── helpers/
│       └── attachments.ts         # ✅ Attachments
│
└── mock-users.ts                  # ⚠️ Legacy (รองรับ backward compat)
```

### **Recommended Structure (แนะนำ):**

```
/lib/mockData/
├── index.ts                       # 🎯 Main export hub
│
├── users.ts                       # ✅ Users (13)
├── projects.ts                    # ✅ Projects (73)
├── organizations.ts               # ✅ Organizations (5)
├── products.ts                    # ✅ Products (15)
│
├── tickets/                       # 📦 NEW: Tickets Module
│   ├── index.ts                   # Export ทั้งหมด
│   ├── customer-tickets.ts        # เคสที่ลูกค้าสร้าง (~100)
│   ├── staff-tickets.ts           # เคสที่ Staff สร้าง (~100)
│   ├── closed-tickets.ts          # เคสปิดแล้ว (~40)
│   ├── tier2-tickets.ts           # เคส Tier2 (~20)
│   └── tier3-tickets.ts           # เคส Tier3 (~10)
│
└── helpers/
    ├── attachments.ts             # ✅ Attachments
    ├── timeline.ts                # Timeline helpers
    └── validation.ts              # Data validation
```

---

## 🚀 Migration Plan

### **Phase 1: ✅ Completed**
- [x] Migrate Users → `/lib/mockData/users.ts`
- [x] Migrate Projects → `/lib/mockData/projects.ts`
- [x] Migrate Organizations → `/lib/mockData/organizations.ts`
- [x] Migrate Products → `/lib/mockData/products.ts`
- [x] Migrate Attachments → `/lib/mockData/helpers/attachments.ts`

### **Phase 2: ⏳ Pending**
- [ ] Create `/lib/mockData/tickets/` folder
- [ ] Migrate Customer Tickets → `customer-tickets.ts`
- [ ] Migrate Staff Tickets → `staff-tickets.ts`
- [ ] Migrate Closed Tickets → `closed-tickets.ts`
- [ ] Migrate Tier2/3 Tickets → `tier2-tickets.ts`, `tier3-tickets.ts`
- [ ] Create validation script

### **Phase 3: 📋 Future**
- [ ] Create Mock Data Generator
- [ ] Create Data Seeding Script
- [ ] Automated Testing

---

## ✅ Validation Rules

### **กฎที่ต้องตรวจสอบ:**

#### **1. Closed Cases:**
```typescript
// ✅ เฉพาะ Tier1 เท่านั้นที่ปิดเคสได้
import { validateClosedCases } from '@/lib/mockData';

const result = validateClosedCases(allTickets);
if (!result.valid) {
  console.error('Invalid closed cases:', result.errors);
}
```

#### **2. Staff Created Cases:**
```typescript
// ✅ Staff ต้องเลือกช่องทาง (phone/email/line)
import { validateStaffCases } from '@/lib/mockData';

const result = validateStaffCases(allTickets);
if (!result.valid) {
  console.error('Invalid staff cases:', result.errors);
}
```

#### **3. Project Code Format:**
```typescript
// ✅ Project Code ต้องตรงรูปแบบ D{YY}-{XXXX}
import { validateProjectCodes } from '@/lib/mockData';

const result = validateProjectCodes(allProjects);
if (!result.valid) {
  console.error('Invalid project codes:', result.errors);
}
```

#### **4. Organization Code Format:**
```typescript
// ✅ Organization Code ต้องตรงรูปแบบ ORG-{NNN}
import { validateOrganizationCodes } from '@/lib/mockData';

const result = validateOrganizationCodes(allOrganizations);
if (!result.valid) {
  console.error('Invalid organization codes:', result.errors);
}
```

### **Validation Script:**

รัน validation ทั้งหมดในคำสั่งเดียว:

```bash
npm run validate-mockdata
```

หรือ:

```bash
tsx scripts/validate-mockdata.ts
```

---

## 📊 Quick Stats

### **สรุปตัวเลข:**

```typescript
Total Users:         13
  - Admin:           1
  - Staff:           4 (1 pure staff + 3 multi-role)
  - Tier1:           5
  - Tier2:           3
  - Tier3:           2
  - Manager:         1
  - Customer:        1

Total Projects:      73
  - CSV Projects:    23
  - Legacy:          50

Total Organizations: 5
Total Products:      15 (13 active + 2 deprecated)
Total Tickets:       200+
Total Attachments:   ~20
```

---

## 📚 เอกสารที่เกี่ยวข้อง

- [/lib/mockData/README.md](/lib/mockData/README.md) - โครงสร้างข้อมูล
- [MOCK_DATA_RULES.md](/docs/mock-data/MOCK_DATA_RULES.md) - 🚨 กฎเหล็กการจำลองข้อมูล (Iron Rules)
- [MOCK_DATA_CLOSED_BY_FIX.md](/docs/mock-data/MOCK_DATA_CLOSED_BY_FIX.md) - การแก้ไข closedBy
- [STAFF_ROLE_DOCUMENTATION.md](/docs/STAFF_ROLE_DOCUMENTATION.md) - บทบาท Staff
- [PROJECT_OVERVIEW.md](/docs/PROJECT_OVERVIEW.md) - ภาพรวมโปรเจค

---

**เอกสารนี้อัพเดทล่าสุด:** 26 มกราคม 2026  
**สถานะ:** 🔄 In Progress  
**ผู้รับผิดชอบ:** Development Team
