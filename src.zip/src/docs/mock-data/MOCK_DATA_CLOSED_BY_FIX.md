# 🔧 Mock Data Cleanup: ลบเคส closedBy: 'staff-001'

**Last Updated:** 26 มกราคม 2026  
**Version:** 1.0  
**Status:** ✅ แก้ไขเสร็จสิ้น

---

## 📋 สรุปการแก้ไข

### **ปัญหาที่พบ:**
- มีเคสที่ `closedBy: 'staff-001'` อยู่ 8 เคสใน `/lib/mockData.ts`
- ขัดแย้งกับกฎที่ว่า **เฉพาะ Tier1 เท่านั้นที่สามารถปิดเคสได้**
- Staff มีหน้าที่เพียง: **รับเรื่อง → บันทึก → ส่งต่อ Tier1** เท่านั้น

### **สาเหตุ:**
- เคสเหล่านี้ถูกสร้างก่อนหน้าที่จะมีกฎ Permission System ใหม่
- ยุคแรกอาจมีการทดสอบว่า Staff สามารถปิดเคสได้
- ข้อมูลเก่าที่ยังไม่ได้ cleanup

---

## ✅ การแก้ไข

### **เคสที่แก้ไข (8 เคส):**

| เคส | Ticket Number | เดิม closedBy | แก้ไขเป็น | หมายเหตุ |
|-----|---------------|---------------|-----------|----------|
| 1 | CDGS-2024-CL001 | staff-001 | user-002 | Sarin Chorphayorm (Tier1) |
| 2 | CDGS-2024-SC001 | staff-001 | user-003 | Wannapa Sae-dang (Tier1) |
| 3 | CDGS-2024-SC002 | staff-001 | user-004 | Khemika Saetang (Tier1) |
| 4 | CDGS-2024-SC003 | staff-001 | user-005 | Thanyaporn Thongkaew (Tier1) |
| 5 | CDGS-2025-SC004 | staff-001 | user-003 | Wannapa Sae-dang (Tier1) |
| 6 | CDGS-2025-SC005 | staff-001 | user-004 | Khemika Saetang (Tier1) |
| 7 | CDGS-2025-SC006 | staff-001 | user-003 | Wannapa Sae-dang (Tier1) |
| 8 | CDGS-2025-SC007 | staff-001 | user-005 | Thanyaporn Thongkaew (Tier1) |

### **หลักการแก้ไข:**
1. เปลี่ยน `closedBy` จาก `staff-001` → Tier1 user ID
2. เลือก Tier1 ที่เหมาะสมกับโครงการนั้นๆ
3. ให้สอดคล้องกับ `createdBy` (Staff ที่สร้างเคส) เพื่อความเป็นธรรมชาติ

---

## 📊 สถิติหลังแก้ไข

### **Before:**
```
closedBy: 'staff-001' → 8 เคส ❌
closedBy: 'user-002'  → 1 เคส ✅
closedBy: 'user-003'  → 0 เคส
closedBy: 'user-004'  → 0 เคส
closedBy: 'user-005'  → 0 เคส
```

### **After:**
```
closedBy: 'staff-001' → 0 เคส ✅ (ลบหมดแล้ว)
closedBy: 'user-002'  → 2 เคส ✅ (Tier1 - Sarin)
closedBy: 'user-003'  → 4 เคส ✅ (Tier1 - Wannapa)
closedBy: 'user-004'  → 3 เคส ✅ (Tier1 - Khemika)
closedBy: 'user-005'  → 2 เคส ✅ (Tier1 - Thanyaporn)
```

---

## 🎯 ผลลัพธ์

### **✅ ข้อดี:**
1. **ข้อมูลสอดคล้องกับกฎ** - เฉพาะ Tier1 เท่านั้นที่ปิดเคสได้
2. **ไม่มีความขัดแย้ง** - ระหว่าง Permission System กับข้อมูล
3. **Staff เห็นเคสที่ถูกต้อง** - ใน "ดูเคสที่ปิดย้อนหลัง" จะเห็นเฉพาะเคสที่ Tier1 ปิดให้

### **⚠️ ข้อควรระวัง:**
- ถ้ามีการ reference เคสเหล่านี้ในที่อื่น อาจต้องตรวจสอบ
- UI ที่แสดง "ปิดโดย" ควรแสดงชื่อ Tier1 ที่ถูกต้อง

---

## 🔍 วิธีตรวจสอบ

### **ค้นหาเคสที่ Staff ปิด (ควรไม่มี):**
```bash
grep -r "closedBy: 'staff-001'" lib/
```

**ผลลัพธ์ควรเป็น:** `Found 0 matches` ✅

### **ตรวจสอบใน Code:**
```typescript
const staffClosedCases = allTickets.filter(
  t => t.status === 'closed' && t.closedBy === 'staff-001'
);
console.log(staffClosedCases.length); // ควรเป็น 0
```

---

## 📚 เอกสารที่เกี่ยวข้อง

- [STAFF_ROLE_DOCUMENTATION.md](/docs/STAFF_ROLE_DOCUMENTATION.md) - บทบาทของ Staff
- [CASE_CLOSURE_WORKFLOW.md](/CASE_CLOSURE_WORKFLOW.md) - กฎการปิดเคส
- [PERMISSIONS_GUIDE.md](/PERMISSIONS_GUIDE.md) - Permission System

---

## 🚀 Next Steps (แนะนำ)

### **1. สร้างเอกสาร Mock Data Inventory**
- บอกว่ามีเคสอะไรบ้าง กี่เคส แยกตามประเภท
- อธิบายว่า Staff closed tickets ควรมีลักษณะอย่างไร

### **2. Migrate Mock Data ให้เป็นระบบ**
```
/lib/mockData/
  ├── tickets/
  │   ├── customer-tickets.ts    # เคสที่ลูกค้าสร้าง
  │   ├── staff-tickets.ts       # เคสที่ Staff สร้าง
  │   ├── closed-tickets.ts      # เคสที่ปิดแล้ว
  │   └── index.ts               # รวมทั้งหมด
```

### **3. สร้าง Validation Script**
```typescript
// validateMockData.ts
function validateClosedCases() {
  const invalidCases = allTickets.filter(t => 
    t.status === 'closed' && 
    !['user-001', 'user-002', ...].includes(t.closedBy)
  );
  
  if (invalidCases.length > 0) {
    throw new Error('Found closed cases by non-Tier1 users!');
  }
}
```

---

## ✅ Checklist

- [x] ค้นหาเคสที่ `closedBy: 'staff-001'`
- [x] แก้ไขทั้ง 8 เคส
- [x] ตรวจสอบว่าไม่มีเคสเหลือ
- [x] บันทึกเอกสาร
- [ ] อัพเดท STAFF_ROLE_DOCUMENTATION.md (ถ้าจำเป็น)
- [ ] สร้าง Mock Data Inventory
- [ ] สร้าง Validation Script
- [ ] Migrate Mock Data ให้เป็นระบบ

---

**เอกสารนี้อัพเดทล่าสุด:** 26 มกราคม 2026  
**สถานะ:** ✅ แก้ไขเสร็จสิ้น  
**ผู้รับผิดชอบ:** Development Team
