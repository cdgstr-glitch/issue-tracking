# 📊 Mock Data Status Report - Final

**Date:** 2026-01-23  
**Checked By:** System Audit  
**Status:** ⚠️ Needs Fix

---

## ✅ **ส่วนที่ถูกต้อง**

### 1. **Projects** `/lib/mockData/projects.ts`
✅ **Status:** ถูกต้องทั้งหมด

```typescript
// ตัวอย่าง:
{
  id: 'proj-csv-001',
  organizationId: 'org-csv-001',
  projectCode: 'D26-0001', // ✅ ถูกต้อง
  projectName: 'โครงการหลัก - สำนักงานคณะกรรมการกำกับกิจการพลังงาน',
  projectStatus: 'active'
}
```

**จำนวน:** 24 โครงการ (D26-0001 ถึง D26-0024)

---

## ❌ **ส่วนที่ผิด**

### 1. **CSV Tickets** `/lib/mockDataCSVTickets.ts`

❌ **Status:** ใช้ Project Code ผิด

**ตัวอย่างที่ผิด:**
```typescript
projectCode: 'D26-2001', // ❌ ผิด → ควรเป็น D26-0002
projectCode: 'D26-3001', // ❌ ผิด → ควรเป็น D26-0005
projectCode: 'D26-4001', // ❌ ผิด → ควรเป็น D26-0007
projectCode: 'D26-5001', // ❌ ผิด → ควรเป็น D26-0008
```

**ที่ต้องแก้ไข:**
| ตำแหน่ง | เดิม (ผิด) | ใหม่ (ถูก) |
|---------|-----------|-----------|
| proj-csv-003 | D26-2002 | D26-0003 |
| proj-csv-004 | D26-3001 | D26-0005 |
| proj-csv-005 | D26-3002 | D26-0006 |
| proj-csv-006 | D26-4001 | D26-0007 |
| proj-csv-007 | D26-5001 | D26-0008 |

**สถานะการแก้ไข:**
- [x] D26-0001 (แก้แล้ว)
- [x] D26-0002 (แก้แล้ว)
- [x] D26-0003 (แก้แล้ว)
- [ ] D26-0005 (ยังเป็น D26-3001)
- [ ] D26-0006 (ยังเป็น D26-3002)
- [ ] D26-0007 (ยังเป็น D26-4001)
- [ ] D26-0008 (ยังเป็น D26-5001)

---

### 2. **CSV Tickets Part 2** `/lib/mockDataCSVTicketsPart2.ts`

❌ **Status:** ใช้ Project Code ผิดทั้งหมด (~40 จุด)

**ตัวอย่าง:**
```typescript
projectCode: 'D26-5001', // ❌ → D26-0008
projectCode: 'D26-6001', // ❌ → D26-0009
projectCode: 'D26-7001', // ❌ → D26-0010
projectCode: 'D26-8001', // ❌ → D26-0011
projectCode: 'D26-1001', // ❌ → D26-0001
```

**ตาราง Mapping ทั้งหมด:**

| Project ID | รหัสปัจจุบัน (ผิด) | รหัสที่ถูก | Org |
|-----------|-------------------|-----------|-----|
| proj-csv-001 | D26-1001 | D26-0001 | ERC |
| proj-csv-002 | D26-2001 | D26-0002 | RMUTP |
| proj-csv-003 | D26-2002 | D26-0003 | VRU |
| proj-csv-004 | D26-3001 | D26-0005 | GPO |
| proj-csv-005 | D26-3002 | D26-0006 | FIO |
| proj-csv-006 | D26-4001 | D26-0007 | AMLO |
| proj-csv-007 | D26-5001 | D26-0008 | DOH |
| proj-csv-008 | D26-6001 | D26-0009 | ACFS |
| proj-csv-009 | D26-7001 | D26-0010 | DLPW |
| proj-csv-010 | D26-8001 | D26-0011 | DGA |
| proj-csv-011 | D26-9001 | D26-0012 | SUANLUANG |
| proj-csv-012 | D26-1002 | D26-0013 | OPM |
| proj-csv-013 | D26-2003 | D26-0014 | RMUTK |
| proj-csv-014 | D26-9002 | D26-0015 | KORATPAO |
| proj-csv-015 | D26-5002 | D26-0016 | LDD |
| proj-csv-016 | D26-3003 | D26-0017 | GIF |
| proj-csv-017 | D26-1003 | D26-0018 | NESDC |
| proj-csv-018 | D26-5003 | D26-0019 | DOT |
| proj-csv-019 | D26-1004 | D26-0020 | OTEP |
| proj-csv-020 | D26-6002 | D26-0021 | HSS |
| proj-csv-021 | D26-2004 | D26-0022 | DRU |
| proj-csv-022 | D26-5004 | D26-0023 | MOT |

---

### 3. **Organizations** `/lib/mockData/organizations.ts`

⚠️ **Status:** ใช้ `organizationCode` ผิดรูปแบบ

**ปัญหา:**
```typescript
{
  id: 'org-csv-001',
  organizationCode: 'D26-1001', // ❌ ผิด! ใช้รูปแบบ Project Code
  organizationName: 'สำนักงานคณะกรรมการกำกับกิจการพลังงาน',
  organizationShortName: 'ERC'
}
```

**คำถาม:** `organizationCode` ควรเป็นอะไร?

**ตัวเลือก:**

**A. ใช้รหัสองค์กรแบบง่าย (แนะนำ)**
```typescript
organizationCode: 'ORG-001',  // ✅ Sequential
organizationCode: 'ORG-002',
organizationCode: 'ORG-003',
```

**B. ใช้ชื่อย่อ (Short Name)**
```typescript
organizationCode: 'ERC',      // ✅ ซ้ำกับ organizationShortName
organizationCode: 'RMUTP',
organizationCode: 'VRU',
```

**C. ไม่ต้องมี Code (Optional)**
```typescript
organizationCode: '',         // ✅ ทำให้ Optional ในtype
// หรือลบฟิลด์นี้ออก
```

**D. ใช้รหัสตามจริง (ถ้ามี)**
```typescript
organizationCode: 'GOV-ERC-001',  // ✅ รหัสจริงของหน่วยงาน
```

---

## 🎯 **คำแนะนำ**

### **Priority 1: แก้ไข Project Codes ใน Tickets**

**ไฟล์:**
- `/lib/mockDataCSVTickets.ts` (4 จุดที่เหลือ)
- `/lib/mockDataCSVTicketsPart2.ts` (~40 จุด)

**วิธีแก้:**
ใช้ Find & Replace ใน VS Code:
```
Ctrl+H
Find: D26-2002    Replace: D26-0003
Find: D26-3001    Replace: D26-0005
Find: D26-3002    Replace: D26-0006
Find: D26-4001    Replace: D26-0007
Find: D26-5001    Replace: D26-0008
Find: D26-6001    Replace: D26-0009
Find: D26-7001    Replace: D26-0010
Find: D26-8001    Replace: D26-0011
Find: D26-9001    Replace: D26-0012
Find: D26-1002    Replace: D26-0013
Find: D26-2003    Replace: D26-0014
Find: D26-9002    Replace: D26-0015
Find: D26-5002    Replace: D26-0016
Find: D26-3003    Replace: D26-0017
Find: D26-1003    Replace: D26-0018
Find: D26-5003    Replace: D26-0019
Find: D26-1004    Replace: D26-0020
Find: D26-6002    Replace: D26-0021
Find: D26-2004    Replace: D26-0022
Find: D26-5004    Replace: D26-0023
Find: D26-1001    Replace: D26-0001 (ตัวสุดท้าย)
```

### **Priority 2: แก้ไข Organization Codes**

**ไฟล์:**
- `/lib/mockData/organizations.ts`

**วิธีแก้:**
ตัดสินใจเลือกรูปแบบ (A, B, C, หรือ D) แล้วแก้ไขทั้งหมด

**แนะนำ:** Option A (`ORG-001`, `ORG-002`, ...) เพราะง่ายและไม่ซ้ำกับ Project Code

---

## 🔍 **Verification Checklist**

หลังแก้ไขเสร็จ ให้ตรวจสอบ:

### **1. Import & Compile**
- [ ] ไม่มี TypeScript Error
- [ ] Import ทุกไฟล์สำเร็จ
- [ ] npm run dev ทำงานได้

### **2. Data Display**
- [ ] หน้า Ticket Details แสดง Project Code ถูกต้อง
- [ ] Format: `[ORG_SHORT] D26-XXXX` (เช่น "DLPW D26-0010")
- [ ] ไม่มีรหัสแปลกๆ แสดง (เช่น D26-7001)

### **3. Search & Filter**
- [ ] Search โครงการทำงานได้
- [ ] Filter โดยองค์กรทำงานได้
- [ ] Project Selector แสดงรหัสถูกต้อง

### **4. Join Operations**
- [ ] Ticket → Project join ได้ (ผ่าน projectId)
- [ ] Project → Organization join ได้ (ผ่าน organizationId)
- [ ] ข้อมูลแสดงผลครบถ้วน

---

## 📋 **Summary**

| Item | Status | Priority |
|------|--------|----------|
| **Projects** | ✅ ถูกต้อง | - |
| **CSV Tickets (Part 1)** | 🟡 แก้ไขแล้ว 30% | 🔴 High |
| **CSV Tickets (Part 2)** | ❌ ยังไม่แก้ไข | 🔴 High |
| **Organizations** | ⚠️ รูปแบบผิด | 🟡 Medium |
| **Other Mock Data** | ✅ ถูกต้อง | - |

**Overall Status:** 🟡 Needs Fix (70% Complete)

---

## 📚 **Related Documents**

- [PROJECT_CODE_FORMAT.md](/docs/PROJECT_CODE_FORMAT.md) - รูปแบบมาตรฐาน
- [PROJECT_CODE_FIX_REPORT.md](/docs/PROJECT_CODE_FIX_REPORT.md) - รายงานการแก้ไข
- [PROJECT_CODE_CONSISTENCY_CHECK.md](/docs/technical/PROJECT_CODE_CONSISTENCY_CHECK.md) - การตรวจสอบ

---

**Last Updated:** 2026-01-23  
**Next Action:** แก้ไข CSV Tickets ทั้งหมดด้วย Find & Replace  
**Estimated Time:** 15-20 นาที
