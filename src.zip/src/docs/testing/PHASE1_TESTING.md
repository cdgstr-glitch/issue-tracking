# 🧪 Phase 1: Testing Guide

## ⚠️ หลักการสำคัญ: ไม่มีการรับเคสอัตโนมัติ

**ระบบไม่มี auto-accept feature - ทุกคนต้องกด "รับเคส" เองทุกครั้ง**

---

## 🎭 Role Matrix - ภาพรวมบทบาททั้งหมด

| Role | รับเคส | บันทึกเคส | ส่งต่อ | ปิดเคส | หมายเหตุ |
|------|--------|----------|--------|--------|---------|
| **customer** | ❌ | ✅ (ตัวเอง) | ❌ | ❌ | ส่งเคสและดูเคสของตัวเองเท่านั้น |
| **staff** | ❌ | ✅ (แทนลูกค้า) | ❌ | ✅ (เคสเล็กๆ) | บันทึกเคสจากช่องทางอื่น, เลือก "แก้ไขและปิดเคส" หรือ "ส่งงาน" |
| **tier1** | ✅ | ✅ (แทนลูกค้า) | ✅ | ✅ | รับเคสใหม่ (new) และเคสส่งกลับมา (tier1) |
| **tier2** | ✅ | ❌ | ✅ | ❌ | รับเคสส่งต่อจาก T1 (tier2), ส่งกลับ T1 เพื่อปิด |
| **tier3** | ✅ | ❌ | ✅ | ❌ | รับเคสส่งต่อจาก T2 (tier3), ส่งกลับ T1 เพื่อปิด |
| **admin (Pure)** | ❌ | ❌ | ❌ | ❌ | **Monitor Only** - ไม่มีสิทธิ์ทำ Action ใด ๆ |
| **admin + tier1** | ✅ | ✅ | ✅ | ✅ | Admin ที่มี tier1 role (เหมือน Tier1) |
| **admin + tier2** | ✅ | ❌ | ✅ | ❌ | Admin ที่มี tier2 role (เหมือน Tier2) |
| **admin + tier3** | ✅ | ❌ | ✅ | ❌ | Admin ที่มี tier3 role (เหมือน Tier3) |

### **🔑 Key Points:**
1. **Pure Admin (user-011: ประอรรัตน์ กีรติผจญ)** = `roles: ['admin']` (ไม่มี tier)
   - ✅ ดูเคสทั้งหมดได้ (Monitor All)
   - ❌ **ไม่แสดงปุ่ม Action ใด ๆ** (TicketActions return null)
   - ℹ️ แสดง Banner: "คุณกำลังดูเคส (Admin - Monitor Mode)"

2. **Admin + Tier1 (user-001, user-002)** = `roles: ['admin', 'tier1', 'staff']` + `tier: 1`
   - ✅ ทำงานเหมือน Tier1 ทุกอย่าง
   - ✅ รับเคสได้, ส่งต่อได้, ปิดเคสได้

3. **Staff** = บันทึกเคสแทนลูกค้า, เลือก:
   - ✅ **"แก้ไขและปิดเคส"** → status = `closed` ทันที (เคสเล็กๆ น้อยๆ ที่ตอบได้เลย)
   - ✅ **"ส่งงาน"** → status = `new` ส่งต่อ Tier1

---

## ✅ TODO 4-8 Completed

### TODO 4: ✅ AssigneeSelector Component
**ไฟล์:** `/components/AssigneeSelector.tsx`

**Features:**
- เลือก tier (1, 2, 3)
- filter ตาม projectId
- option "มอบหมายอัตโนมัติ" (auto-assign: เลือกคนที่มีงานน้อยสุดให้อัตโนมัติ)
- แสดงรายชื่อผู้ใช้ พร้อม avatar และ email
- ⚠️ **หมายเหตุ:** auto-assign ≠ auto-accept (ผู้รับยังต้องกด "รับเคส" เอง)

---

### TODO 5: ❌ ~~Auto-accept Logic~~ (ถูกลบออกแล้ว)
**สถานะ:** ระบบไม่มี auto-accept feature
- ❌ ไม่มี `autoAcceptEnabled` field
- ❌ ไม่มี auto-accept toggle ใน Settings
- ✅ ทุกคนต้องกด "รับเคส" เองทุกครั้ง

---

### TODO 6: ✅ Closure Flow (T2/T3 → T1)
**ไฟล์:**
- `/lib/mock-users.ts` - เพิ่ม `getTier1ForProject()` function
- `/types/index.ts` - เพิ่ม `projectId` field ใน Ticket

**Flow:**
1. T2/T3 แก้ไขเคสเสร็จ
2. กดปุ่ม "ส่งกลับ T1 เพื่อปิด"
3. Status → `resolved` (แสดงในเมนู "แก้ไขแล้ว" สีเขียว 🟢)
4. assignedTo → T1 ของโครงการนั้น
5. T1 ตรวจสอบและกด "ปิดเคส"
6. Status → `closed`

---

### TODO 7: ✅ TicketActions Component
**ไฟล์:** `/components/TicketActions.tsx`

**Actions:**
1. **รับเคส (Accept)** - แสดงเมื่อถูก assign แต่ยังไม่ได้รับ
2. **ส่งต่อ (Escalate)** - เลือก tier + assignee
3. **ส่งกลับ T1 เพื่อปิด** - T2/T3 only
4. **ปิดเคส (Close)** - T1 only, เมื่อ status = resolved

---

## 🔑 Logic การแสดงปุ่ม "รับเคส" (Accept Button Logic)

### **เงื่อนไขการแสดงปุ่ม "รับเคส":**

#### **Tier 1:**
```javascript
// กรณีที่ 1: เคสใหม่ (new) ยังไม่มี projectId
needsProjectSelection = ticket.status === 'new' && !ticket.projectId
→ แสดง Dialog เลือกโครงการ + หมวดหมู่ + ประเภทปัญหา + ความสำคัญ

// กรณีที่ 2: เคสส่งกลับมา (tier1) มี projectId แล้ว
canAcceptDirectly = ticket.status === 'tier1' && isAssignedToMe && ticket.projectId
→ รับเคสตรงๆ ไม่ต้อง Dialog (เหมือน Tier2/3)
```

#### **Tier 2:**
```javascript
canAccept = (
  ticket.status === 'tier2' && isAssignedToMe
)
→ รับเคสตรงๆ ไม่ต้อง Dialog
```

#### **Tier 3:**
```javascript
canAccept = (
  ticket.status === 'tier3' && isAssignedToMe
)
→ รับเคสตรงๆ ไม่ต้อง Dialog
```

### **สถานการณ์ต่างๆ:**

| สถานการณ์ | Status | AssignedTo | ใครเห็นปุ่ม "รับเคส" |
|-----------|--------|------------|----------------------|
| เคสใหม่จากลูกค้า/Staff | `new` | null | **Tier1 ทุกคน** |
| ส่งต่อไป Tier2 | `tier2` | userId | **Tier2 คนที่ถูก assign** |
| ส่งต่อไป Tier3 | `tier3` | userId | **Tier3 คนที่ถูก assign** |
| ส่งกลับมาที่ Tier1 | `tier1` | userId | **Tier1 คนที่ถูก assign** |
| ส่งกลับจาก T2 → T1 | `tier1` | userId | **Tier1 คนที่ถูก assign** |
| ส่งกลับจาก T3 → T1 | `tier1` | userId | **Tier1 คนที่ถูก assign** |
| ส่งกลับจาก T3 → T2 | `tier2` | userId | **Tier2 คนที่ถูก assign** |

### **หมายเหตุสำคัญ:**
- ⚠️ **ไม่มี auto-accept** - ทุกคนต้องกด "รับเคส" เองทุกครั้ง
- ⚠️ **Tier1 กรณีพิเศษ** - Tier1 รับเคส `new` ได้โดยไม่ต้อง assigned, แต่ต้อง assigned สำหรับ status `tier1`
- ✅ **Tier2/3** - ต้อง assigned ให้ตัวเองเท่านั้น ถึงจะเห็นปุ่ม "รับเคส"

---

## 📋 Manual Testing Checklist

### Test 1: Login & Logout
```
[ ] 1. Login tier1 → Logout
[ ] 2. Login tier2 → Logout  
[ ] 3. Login tier3 → Logout
[ ] 4. ข้อมูลไม่ค้างระหว่าง user (ต้อง refresh หรือไม่?)
```

**Expected:** ✅ ไม่ต้อง refresh, state ถูก reset อัตโนมัติ

---

### Test 2: AssigneeSelector
```
[ ] 1. Login tier1
[ ] 2. ไปที่ TicketDetailPage
[ ] 3. กดปุ่ม "ส่งต่อ"
[ ] 4. เลือก Tier 2
[ ] 5. ดู AssigneeSelector แสดงผู้ใช้ Tier 2
[ ] 6. มี option "มอบหมายอัตโนมัติ"
```

**Expected:** 
- ✅ แสดง dropdown ด้วย tier2 users
- ✅ มี option "มอบหมายอัตโนมัติ" ที่ด้านบน (เลือกคนที่มีงานน้อยสุด - **ไม่ auto-accept**)
- ✅ แสดง avatar, ชื่อ, email ของแต่ละคน

---

### Test 3: Manual Accept - ทุกคนต้องรับเคสเอง
```
[ ] 1. Login tier1
[ ] 2. สร้างเคสใหม่ หรือมอบหมายเคสให้ tier1 คนอื่น
[ ] 3. Logout → Login เป็นคนที่ถูก assign
[ ] 4. เปิดเคสนั้น
[ ] 5. ดูว่ามีปุ่ม "รับเคส" หรือไม่
[ ] 6. กดปุ่ม "รับเคส"
```

**Expected:**
- ✅ มีปุ่ม "รับเคส" **ทุกกรณี** (ไม่มี auto-accept)
- ✅ กดแล้ว status → `in_progress`
- ✅ แสดง toast "รับเคสสำเร็จ"

---

### Test 4: Escalate with Specific Assignee
```
[ ] 1. Login tier1
[ ] 2. รับเคส (status = in_progress)
[ ] 3. กดปุ่ม "ส่งต่อ"
[ ] 4. เลือก Tier 2
[ ] 5. เลือกคน "วิชัย เทคนิค" (tier2-2)
[ ] 6. กด "ส่งต่อเคส"
```

**Expected:**
- ✅ Status → `tier2` (รอรับเคส - **ไม่ auto-accept**)
- ✅ assignedTo → "7" (id ของ วิชัย)
- ✅ assignedBy → tier1 user id
- ✅ แสดง toast "ส่งต่อเคสไปยัง Tier 2 สำเร็จ"
- ⚠️ วิชัยต้องเข้ามากด "รับเคส" เองก่อนถึงจะทำงานได้

---

### Test 5: Escalate with "มอบหมายอัตโนมัติ"
```
[ ] 1. Login tier1
[ ] 2. รับเคส (status = in_progress)
[ ] 3. กดปุ่ม "ส่งต่อ"
[ ] 4. เลือก Tier 3
[ ] 5. เลือก "มอบหมายอัตโนมัติ" (เลือกคนที่มีงานน้อยสุด)
[ ] 6. กด "ส่งต่อเคส"
```

**Expected:**
- ✅ ระบบเลือก tier3 user ที่มีงานน้อยสุดให้อัตโนมัติ
- ✅ Status → `tier3` (รอรับเคส - **ไม่ auto-accept**)
- ✅ assignedTo → tier3 คนที่มีงานน้อยสุด
- ✅ แสดง toast "ส่งต่อเคสไปยัง Tier 3 สำเร็จ"
- ⚠️ ผู้รับต้องเข้ามากด "รับเคส" เองก่อนถึงจะทำงานได้

---

### Test 6: Return to T1 for Closure (T2)
```
[ ] 1. Login tier2
[ ] 2. รับเคส (status = in_progress)
[ ] 3. กดปุ่ม "ส่งกลับ T1 เพื่อปิด"
[ ] 4. กรอก "สรุปการแก้ไข"
[ ] 5. กด "ส่งกลับ T1"
```

**Expected:**
- ✅ Status → `pending_closure`
- ✅ assignedTo → tier1 user (id = "2")
- ✅ previousAssignee → tier2 user id
- ✅ แสดง toast "ส่งกลับไปยัง สมศรี ช่วยเหลือ (T1) เพื่อปิดเคส"

---

### Test 7: Return to T1 for Closure (T3)
```
[ ] 1. Login tier3
[ ] 2. รับเคส (status = in_progress)
[ ] 3. กดปุ่ม "ส่งกลับ T1 เพื่อปิด"
[ ] 4. กด "ส่งกลับ T1"
```

**Expected:**
- ✅ Status → `pending_closure`
- ✅ assignedTo → tier1 user
- ✅ แสดงปุ่ม "ส่งกลับ T1 เพื่อปิด" (สีเขียว)

---

### Test 8: Close Ticket (T1 only)
```
[ ] 1. สร้างเคส status = pending_closure
[ ] 2. Login tier1
[ ] 3. เปิดเคสนั้น
[ ] 4. ดูว่ามีปุ่ม "ปิดเคส" หรือไม่
[ ] 5. กดปุ่ม "ปิดเคส"
[ ] 6. ยืนยัน
```

**Expected:**
- ✅ มีปุ่ม "ปิดเคส" (สีน้ำเงิน)
- ✅ กดแล้ว status → `closed`
- ✅ closedAt → วันที่ปัจจุบัน
- ✅ แสดง toast "ปิดเคสสำเร็จ"

---

### Test 9: T2/T3 Cannot Close Directly
```
[ ] 1. Login tier2
[ ] 2. เปิดเคส status = resolved
[ ] 3. ดูว่ามีปุ่ม "ปิดเคส" หรือไม่
```

**Expected:**
- ❌ **ไม่มีปุ่ม "ปิดเคส"**
- ✅ มีเฉพาะปุ่ม "ส่งกลับ T1 เพื่อปิด"

---

### Test 10: Status Badge Colors
```
[ ] 1. Login tier1
[ ] 2. ไปที่ /admin/tickets
[ ] 3. เช็ค status badge colors
```

**Expected Status Colors:**
- `new` → 🔵 Blue
- `tier1` → 🟣 Indigo (รอรับเคส)
- `tier2` → 🟣 Purple (รอรับเคส)
- `tier3` → 🌸 Pink (รอรับเคส)
- `in_progress` → 🟡 Amber
- `waiting` → 🟠 Orange
- `pending_closure` → 🟣 Violet (ใหม่!)
- `resolved` → 🟢 Green
- `closed` → ⚪ Gray

---

### Test 11: Manual Accept Required - All Tiers
```
[ ] 1. Login tier1
[ ] 2. ส่งต่อเคสไป tier2 (เลือกคน)
[ ] 3. Logout → Login tier2
[ ] 4. เปิดเคสนั้น → ต้องเห็นปุ่ม "รับเคส"
[ ] 5. กดรับเคส → status เปลี่ยนเป็น "in_progress"
[ ] 6. ส่งต่อไป tier3 (เลือกคน)
[ ] 7. Logout → Login tier3
[ ] 8. เปิดเคสนั้น → ต้องเห็นปุ่ม "รับเคส"
[ ] 9. กดรับเคส → status เปลี่ยนเป็น "in_progress"
```

**Expected:**
- ✅ **ทุก Tier** ต้องมีปุ่ม "รับเคส"
- ✅ ไม่มีการรับเคสอัตโนมัติเลย
- ✅ Status ต้องเป็น `tier1/tier2/tier3` จนกว่าจะกด "รับเคส"

---

### Test 12: 🎯 Pure Admin - Monitor Only (สำคัญมาก!)
```
[ ] 1. Login Pure Admin (username: pra-onrat.k, password: pra-onrat.k123)
[ ] 2. ตรวจสอบ user role = 'admin', roles = ['admin'], tier = undefined
[ ] 3. ไปที่ /admin/tickets
[ ] 4. ดูรายการเคสทั้งหมด (ต้องเห็นเคสของ Tier1/2/3 ทั้งหมด)
[ ] 5. คลิกเปิดเคสใด ๆ
[ ] 6. ตรวจสอบว่า **ไม่มีปุ่ม Action ใด ๆ** (รับเคส, ส่งต่อ, ปิดเคส, หยุดชั่วคราว)
[ ] 7. ตรวจสอบว่ามี Banner "คุณกำลังดูเคส (Admin - Monitor Mode)"
[ ] 8. ทดสอบเปิดหลาย ๆ เคส ต้องไม่เห็นปุ่มเลย
```

**Expected:**
- ✅ ดูเคสทั้งหมดได้ (Monitor All)
- ❌ **ไม่มีปุ่ม Action ใด ๆ** (TicketActions return null)
- ✅ แสดง Banner: "คุณกำลังดูเคส (Admin - Monitor Mode)"
- ✅ สามารถดูรายละเอียดเคส, Timeline, Comments ได้
- ❌ ไม่สามารถแก้ไข, รับเคส, ส่งต่อ, หรือปิดเคสได้

---

### Test 13: 🎯 Admin + Tier1 - Full Access (เทียบกับ Pure Admin)
```
[ ] 1. Login Admin+Tier1 (username: thiraporn.r, password: thiraporn.r123)
[ ] 2. ตรวจสอบ user role = 'admin', roles = ['admin', 'tier1', 'staff'], tier = 1
[ ] 3. ไปที่ /admin/tickets
[ ] 4. เปิดเคสใหม่ (status = 'new')
[ ] 5. ✅ ต้องเห็นปุ่ม "รับเคส" (เหมือน Tier1)
[ ] 6. กดปุ่ม "รับเคส" → เลือกโครงการ → รับเคสสำเร็จ
[ ] 7. ✅ ต้องเห็นปุ่ม "ส่งต่อ", "ปิดเคส", "หยุดชั่วคราว"
```

**Expected:**
- ✅ Admin+Tier1 ทำงานเหมือน Tier1 ทุกอย่าง
- ✅ มีปุ่ม Action ครบทุกปุ่ม
- ✅ สามารถรับเคส, ส่งต่อ, ปิดเคสได้

**Comparison Table:**

| ฟีเจอร์ | Pure Admin | Admin + Tier1 |
|--------|-----------|--------------|
| ดูเคสทั้งหมด | ✅ | ✅ |
| ปุ่ม "รับเคส" | ❌ | ✅ |
| ปุ่ม "ส่งต่อ" | ❌ | ✅ |
| ปุ่ม "ปิดเคส" | ❌ | ✅ |
| ปุ่ม "หยุดชั่วคราว" | ❌ | ✅ |
| Monitor Mode Banner | ✅ | ❌ |

---

### Test 14: 🎯 Staff - บันทึกและปิดเคสเล็กๆ เอง (สำคัญ!)
```
[ ] 1. Login Staff (username: staff, password: staff123)
[ ] 2. ไปที่ "บันทึกเคสแทนลูกค้า" (/create)
[ ] 3. ❌ **ทดสอบ validation ก่อน:** กดปุ่ม "✅ แก้ไขและปิดเคส" โดยไม่กรอกข้อมูล
[ ] 4. ✅ ต้องแสดงข้อความ validation error (required fields)
[ ] 5. กรอกข้อมูลลูกค้า (ชื่อ, อีเมล, เบอร์โทร)
[ ] 6. เลือกช่องทาง (Line/โทรศัพท์/Email)
[ ] 7. กรอกหัวเรื่อง, รายละเอียด
[ ] 8. กรอกหมวดหมู่, ผลิตภัณฑ์, ประเภทปัญหา, ความสำคัญ
[ ] 9. ✅ กดปุ่ม "✅ แก้ไขและปิดเคส"
[ ] 10. กรอกสรุปการแก้ไข (Solution) ใน Modal
[ ] 11. กด "ยืนยันการปิดเคส"
[ ] 12. ✅ **ตรวจสอบหน้า Success:**
      - หัวข้อ: "✅ บันทึกและปิดเคสสำเร็จ!"
      - ข้อความ: "เคสได้ถูกบันทึกและปิดเรียบร้อยแล้ว คุณสามารถดูย้อนหลังได้ที่เมนู 'เคสที่ปิดย้อนหลัง'"
      - ปุ่ม: "📋 เคสที่ปิดย้อนหลัง" และ "กลับหน้าหลัก"
[ ] 13. กดปุ่ม "📋 เคสที่ปิดย้อนหลัง"
[ ] 14. ตรวจสอบว่า navigate ไปที่ /closed-tickets (ไม่ใช่ /track)
[ ] 15. ตรวจสอบว่าเห็นเคสที่เพิ่งสร้าง ในหมวด "Staff ปิดเอง"
```

**Expected:**
- ✅ **Validation ทำงานเหมือนปุ่ม "ส่งงาน"** - ต้องกรอกข้อมูลครบก่อนถึงจะดำเนินการต่อได้
- ✅ แสดง browser validation error สำหรับ required fields
- ✅ ไม่สามารถกดปุ่ม "แก้ไขและปิดเคส" ได้ถ้ากรอกข้อมูลไม่ครบ
- ✅ **หน้า Success แตกต่างจาก "ส่งงาน":**
  - หัวข้อ: "✅ บันทึกและปิดเคสสำเร็จ!" (ไม่ใช่ "แจ้งเคสสำเร็จ!")
  - ข้อความ: บอกว่าเคส**ปิด**แล้ว (ไม่ใช่ **ส่ง**แล้ว)
  - ปุ่ม: "📋 เคสที่ปิดย้อนหลัง" → `/closed-tickets` (ไม่ใช่ "ติดตามเคส" → `/track`)
- ✅ Staff สามารถสร้างเคสและปิดทันที (status = 'closed')
- ✅ closedBy = Staff user ID
- ✅ createdBy = Staff user ID
- ✅ ปรากฏใน "เคสที่ปิดย้อนหลัง" (StaffClosedTicketsPage)
- ✅ แสดงใน section "Staff ปิดเอง" (ไม่ใช่ "Tier ปิดให้")

---

### Test 15: 🎯 Staff - บันทึกและส่งงาน (เทียบกับ Test 14)
```
[ ] 1. Login Staff (username: staff, password: staff123)
[ ] 2. ไปที่ "บันทึกเคสแทนลูกค้า" (/create)
[ ] 3. กรอกข้อมูลลูกค้า
[ ] 4. กรอกหัวเรื่อง, รายละเอียด
[ ] 5. ✅ เลือก "ส่งงาน" (แทนที่จะเลือก "แก้ไขและปิดเคส")
[ ] 6. กด "บันทึก"
[ ] 7. ตรวจสอบว่าเคสถูกสร้างด้วย status = 'new'
[ ] 8. ไปที่ "ติดตามเคสลูกค้า" (/track)
[ ] 9. ตรวจสอบว่าเห็นเคสที่เพิ่งสร้าง (status = 'new')
[ ] 10. Logout → Login Tier1
[ ] 11. ไปที่ /admin/tickets → เห็นเคสใหม่ พร้อมปุ่ม "รับเคส"
```

**Expected:**
- ✅ Staff สร้างเคส status = 'new' (รอ Tier1 รับ)
- ✅ createdBy = Staff user ID
- ✅ assignedTo = null (ยังไม่มีใครรับ)
- ✅ ปรากฏใน "ติดตามเคสลูกค้า" (TrackTicketPage)
- ✅ Tier1 เห็นเคสและมีปุ่ม "รับเคส"

**Comparison Table (Test 14 vs Test 15):**

| ฟีเจอร์ | "แก้ไขและปิดเคส" | "ส่งงาน" |
|--------|-----------------|------------|
| Status หลังสร้าง | `closed` | `new` |
| closedBy | Staff ID | null |
| assignedTo | null | null |
| ปรากฏใน "ติดตามเคส" | ❌ (ไม่รวม closed) | ✅ |
| ปรากฏใน "เคสที่ปิดย้อนหลัง" | ✅ | ❌ |
| Tier1 เห็นปุ่ม "รับเคส" | ❌ (เคสปิดแล้ว) | ✅ |

**Success Page Comparison:**

| Element | "แก้ไขและปิดเคส" (ticketClosed) | "ส่งงาน" (submitted) |
|---------|--------------------------------|---------------------|
| 🎨 **Icon Color** | 🟢 Green | 🟢 Green |
| 📝 **หัวข้อ** | "✅ บันทึกและปิดเคสสำเร็จ!" | "แจ้งเคสสำเร็จ!" |
| 💬 **ข้อความหลัก** | "เคสได้ถูกบันทึกและ**ปิด**เรียบร้อยแล้ว" | "งานของคุณได้ถูก**ส่ง**แล้ว" |
| ✅ **ข้อความย่อย** | "เคสถูกบันทึกพร้อมสถานะ 'ปิดแล้ว'" | "อีเมลยืนยันถูกส่งไปยังกล่องจดหมาย" |
| 🔘 **ปุ่มหลัก** | "📋 เคสที่ปิดย้อนหลัง" → `/closed-tickets` | "ติดตามเคสของฉัน" → `/track` |
| 🔘 **ปุ่มรอง** | "กลับหน้าหลัก" → `/` | "กลับหน้าหลัก" → `/` |

---

### Test 16: 🎯 Staff - Navigation หลังสร้างเคส (Bug Fix!)
```
[ ] 1. Login Staff (username: staff, password: staff123)
[ ] 2. ไปที่ "บันทึกเคสแทนลูกค้า" (/create)
[ ] 3. กรอกข้อมูลครบ, เลือก "ส่งงาน"
[ ] 4. กด "บันทึก" → เห็นหน้า Success
[ ] 5. ✅ กดปุ่ม "ติดตามเคสของฉัน"
[ ] 6. ตรวจสอบว่า navigate ไปที่ /track (ไม่ใช่ /admin/tickets)
[ ] 7. ตรวจสอบว่าไม่มี error "ไม่มีสิทธิ์เข้าถึง"
[ ] 8. เห็นเคสที่เพิ่งสร้างในรายการ
[ ] 9. ย้อนกลับ → กดปุ่ม "กลับหน้าหลัก"
[ ] 10. ตรวจสอบว่า navigate ไปที่ / (Staff HomePage)
```

**Expected:**
- ✅ Staff กดปุ่ม "ติดตามเคสของฉัน" → ไปที่ `/track` (ไม่ใช่ `/admin/tickets`)
- ✅ ไม่มี error "ไม่มีสิทธิ์เข้าถึง"
- ✅ Staff กดปุ่ม "กลับหน้าหลัก" → ไปที่ `/` (Staff HomePage)
- ❌ ไม่มีสิทธิ์เข้า `/admin/*` routes (เฉพาะ tier1/tier2/tier3/admin)

**Navigation Matrix:**

| Role | หลังสร้างเคส "ติดตามเคส" | หลังสร้างเคส "กลับหน้าหลัก" |
|------|------------------------|---------------------------|
| **Staff** | `/track` | `/` |
| **Tier1/2/3/Admin** | `/admin/tickets` | `/admin` |
| **Customer** | `/track` | `/` |

---

## 🐛 Known Issues

### Issue 1: TicketActions ยังไม่ integrate กับ TicketDetailPage
**Status:** ✅ แก้ไขแล้ว (26 ธ.ค. 2568)

**Solution:** เพิ่ม `<TicketActions>` ใน StaffTicketDetailPage

```tsx
// ใน StaffTicketDetailPage.tsx
import { TicketActions } from './TicketActions';

// เพิ่ม state
const [currentTicket, setCurrentTicket] = useState(ticket);

// แสดง TicketActions หลัง Ticket Info Card
<TicketActions
  ticket={currentTicket}
  userRole={user.role as 'tier1' | 'tier2' | 'tier3' | 'staff' | 'admin'}
  userId={user.id}
  onUpdate={(updates) => {
    setCurrentTicket({ ...currentTicket, ...updates });
    toast.success('อัปเดตเคสสำเร็จ');
  }}
/>
```

---

### Issue 2: Mock Data ยังไม่มี projectId
**Status:** ⚠️ ต้องอัพเดท

**Solution:** เพิ่ม `projectId` ใน mockTickets

```tsx
// ใน mockData.ts
{
  id: '1',
  ...
  projectId: 'proj-001', // MRTA Project
  ...
}
```

---

### Issue 3: Status Badge ยัง pending_closure แสดงผิด
**Status:** ⚠️ ต้องตรวจสอบ

**Solution:** อัพเดท StatusBadge.tsx ให้รองรับ `pending_closure`

---

## ✅ Checklist สรุป

### Components Created:
- [x] AssigneeSelector.tsx
- [x] TicketActions.tsx
- [ ] ~~SettingsPage.tsx (auto-accept toggle)~~ - ไม่มีแล้ว

### Types Updated:
- [x] Ticket.projectId
- [ ] ~~User.autoAcceptEnabled~~ - ลบออกแล้ว
- [x] TicketStatus includes 'pending_closure'

### Functions Added:
- [x] getUsersByTier()
- [x] getUsersByTierAndProject()
- [x] getTier1ForProject()
- [x] getUserById()

### Routes Added:
- [x] /admin/settings (สำหรับ settings อื่น ๆ - ไม่มี auto-accept)

### Logic Implemented:
- [ ] ~~Auto-accept~~ - ไม่มี feature นี้
- [x] Manual accept (ทุกคนต้องกด "รับเคส" เอง)
- [x] Specific assignee selection
- [x] Return to T1 flow (pending_closure)
- [x] T1-only close permission

---

## 🚀 Next Steps (Phase 2?)

1. **Integrate TicketActions** กับ TicketDetailPage
2. **อัพเดท mockData** เพิ่ม projectId
3. **ทดสอบ Full Workflow** end-to-end
4. **เพิ่ม Timeline Events** สำหรับ actions ใหม่
5. **เพิ่ม UI สร้างคอมเมนต์ internal/public** (เร่งด่วน)
6. **กรอง Timeline events** สำหรับลูกค้า (เร่งด่วน)
7. **เปลี่ยนคำศัพท์** ไม่ใช้ "Tier" กับลูกค้า (เร่งด่วน)

---

**Generated:** Phase 1 - TODO 4-8 Completed  
**Updated:** 9 ธันวาคม 2025 - ลบ auto-accept features ออกแล้ว  
**Note:** ระบบไม่มีการรับเคสอัตโนมัติ - ทุกคนต้องกด "รับเคส" เองทุกครั้ง
