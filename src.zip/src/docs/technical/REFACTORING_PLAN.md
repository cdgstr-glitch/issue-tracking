# 🔧 Refactoring Plan - CDGS Issue Tracking Platform

**Created:** 2026-01-23  
**Status:** 🟢 In Progress  
**Priority:** High

---

## 📋 **Overview**

แผนการจัดระเบียบโครงสร้างไฟล์และเอกสารของระบบ CDGS Issue Tracking Platform เพื่อให้:
- ✅ หาเอกสารได้ง่ายขึ้น
- ✅ Maintenance ง่ายขึ้น
- ✅ เป็นมาตรฐานสำหรับ Production
- ✅ พร้อมนำเสนอหัวหน้า

---

## 🎯 **Phase 1: Documentation Restructuring**

### **เป้าหมาย:**
จัดระเบียบเอกสาร `/docs/` ให้เป็นหมวดหมู่ชัดเจน

### **โครงสร้างใหม่:**

```
/docs/
├── features/           # Feature Documentation
├── technical/          # Technical Specifications
├── changelog/          # Updates & Bug Fixes
├── requirements/       # Requirements & Planning
├── team/              # Team & User Information
├── components/         # Component Documentation
├── INDEX.md           # Main Index (สารบัญหลัก)
├── PROJECT_OVERVIEW.md
├── PERMISSION_MATRIX.md
└── WORKFLOW.md
```

### **การย้ายไฟล์:**

| ไฟล์เดิม | ที่ใหม่ | เหตุผล |
|---------|---------|--------|
| `ASSIGNEE_FILTER_FEATURE.md` | `/features/` | Feature doc |
| `COMMENT_SYSTEM_UPDATE.md` | `/features/` | Feature update |
| `CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md` | `/features/` | Feature workflow |
| `PROJECT_SELECTION_FEATURES.md` | `/features/` | Feature doc |
| `NAVIGATION_MENU.md` | `/technical/` | Technical spec |
| `TIER1_STAFF_MULTI_ROLE_UPDATE.md` | `/changelog/` | Update log |
| `TODO_IMPROVEMENTS.md` | `/requirements/` | Planning doc |
| `REPORTS_ACCESS_CONTROL.md` | `/requirements/` | Requirements |
| `COMMON_COMPONENTS_GUIDE.md` | `/components/` | Component guide |

### **ไฟล์ที่ต้องลบ (Duplicates/Outdated):**

| ไฟล์ | เหตุผล |
|-----|--------|
| `NAVIGATION_MENU_BACKUP.md` | Backup ไม่จำเป็น |
| `COMPONENT_REFACTORING_PLAN.md` | รวมเข้า REFACTORING_PLAN.md แล้ว |

### **สถานะ:**

- [x] สร้าง REFACTORING_PLAN.md
- [ ] ย้ายไฟล์ไป `/features/`
- [ ] ย้ายไฟล์ไป `/technical/`
- [ ] ย้ายไฟล์ไป `/changelog/`
- [ ] ย้ายไฟล์ไป `/requirements/`
- [ ] ย้ายไฟล์ไป `/team/`
- [ ] ลบไฟล์ที่ไม่จำเป็น
- [ ] อัพเดท INDEX.md

---

## 🎯 **Phase 2: Component Restructuring (ทำภายหลัง)**

### **เป้าหมาย:**
จัดระเบียบ Components ให้เป็นหมวดหมู่

### **โครงสร้างที่เสนอ:**

```
/components/
├── pages/
│   ├── auth/           # Login, Register, ForgotPassword
│   ├── dashboards/     # AdminDashboard, SADashboard, SpecialistDashboard
│   ├── tickets/        # Ticket-related pages
│   └── settings/       # Settings, Team, Profile
│
├── features/
│   ├── assignee/       # AssigneeSelector, AssignmentInfoCard
│   ├── escalation/     # EscalatedSection, TierEscalationDiagram
│   ├── analytics/      # Charts, Stats
│   └── export/         # Export features
│
├── shared/
│   ├── badges/         # StatusBadge, PriorityBadge, etc.
│   ├── cards/          # StatsCard, CustomerInfoCard, etc.
│   ├── modals/         # EmailPreviewModal, TakeoverConfirmationModal
│   └── selectors/      # OrganizationSelector, ProjectSelector
│
├── ui/                # ✅ อยู่แล้ว
├── comments/          # ✅ อยู่แล้ว
├── customer/          # ✅ อยู่แล้ว
├── reports/           # ✅ อยู่แล้ว
└── figma/             # ✅ อยู่แล้ว
```

### **การย้าย Components:**

**จำนวนไฟล์ที่ต้องย้าย:** ~50 files

**ตัวอย่าง:**
```
AdminDashboard.tsx → /pages/dashboards/AdminDashboard.tsx
SADashboard.tsx → /pages/dashboards/SADashboard.tsx
LoginPage.tsx → /pages/auth/LoginPage.tsx
StatusBadge.tsx → /shared/badges/StatusBadge.tsx
```

### **สถานะ:**

- [ ] วางแผนการย้าย
- [ ] สร้าง folders
- [ ] ย้ายไฟล์
- [ ] อัพเดท import paths
- [ ] Test ระบบ

---

## 📊 **ผลกระทบและความเสี่ยง**

### **Phase 1 (Documentation):**
- ✅ **ความเสี่ยง:** ต่ำมาก
- ✅ **ผลกระทบ:** ไม่กระทบโค้ด
- ✅ **เวลา:** ~30 นาที

### **Phase 2 (Components):**
- ⚠️ **ความเสี่ยง:** ปานกลาง
- ⚠️ **ผลกระทบ:** ต้องอัพเดท import ทั้งหมด
- ⚠️ **เวลา:** ~2-3 ชั่วโมง

---

## 🎯 **Timeline**

| Phase | งาน | ระยะเวลา | สถานะ |
|-------|-----|----------|-------|
| **Phase 1** | Documentation | 30 นาที | 🟢 In Progress |
| **Phase 2** | Components | 2-3 ชั่วโมง | 🔴 Pending |

---

## ✅ **Checklist**

### **ก่อนเริ่ม:**
- [x] Backup โปรเจค
- [x] สร้างแผน Refactoring
- [x] ทำความเข้าใจโครงสร้างปัจจุบัน

### **Phase 1:**
- [x] สร้าง REFACTORING_PLAN.md
- [ ] ย้ายเอกสารทั้งหมด
- [ ] อัพเดท INDEX.md
- [ ] ตรวจสอบ links

### **Phase 2:**
- [ ] สร้าง folder structure
- [ ] ย้าย components
- [ ] อัพเดท imports
- [ ] Test ทุก page
- [ ] Fix bugs (ถ้ามี)

---

## 📝 **Notes**

- เอกสารทุกไฟล์ต้องมี header ชัดเจน (Title, Date, Status)
- Components ทุกตัวต้องมี comment อธิบายการใช้งาน
- ใช้ชื่อไฟล์แบบ PascalCase สำหรับ Components
- ใช้ชื่อไฟล์แบบ UPPER_CASE.md สำหรับเอกสาร

---

**Last Updated:** 2026-01-23  
**Updated By:** System Refactoring Team
