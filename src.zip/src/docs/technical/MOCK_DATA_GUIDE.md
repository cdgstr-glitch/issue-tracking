# 📦 Mock Data Guide - CDGS Issue Tracking Platform

**Last Updated:** 2025-01-22  
**Version:** 2.0 (Consolidated)

> คู่มือข้อมูล Mock Data ทั้งหมดในระบบ - รวมจาก 10 เอกสารเดิม

---

## 📋 สารบัญ

1. [Import Guide](#import-guide)
2. [Quick Reference](#quick-reference)
3. [โครงสร้างไฟล์](#โครงสร้างไฟล์)
4. [Helper Functions](#helper-functions)
5. [Migration Notes](#migration-notes)

---

## Import Guide

### ✅ Single Import (แนะนำ)

```typescript
import { 
  // Users
  mockUsers,
  getUserById,
  getUsersByTier,
  getUserByCredentials,
  
  // Projects  
  mockProjects,
  getProjectById,
  getProjectByCode,
  
  // Tickets
  allTickets,
  mockTickets,
  customerTickets,
  staffTickets,
  
  // Attachments
  mockAttachments,
  getAttachmentsByTicketId,
  
  // Customers
  mockCustomers,
  createCustomer,
} from '@/lib/mockData';
```

### ❌ หลีกเลี่ยง

```typescript
// ❌ อย่า import จากไฟล์ย่อย
import { mockUsers } from '@/lib/mock-users';
import { csvProjects } from '@/lib/mockDataCSV';

// ✅ ใช้แบบนี้แทน
import { mockUsers, mockProjects } from '@/lib/mockData';
```

---

## Quick Reference

### 👥 Users (13 total)

| User ID | Name | Role | Tier | Projects |
|---------|------|------|------|----------|
| `user-001` | ธิราภรณ์ รุ่งวิรัตน์กุล | Admin + Tier1 | 1 | All (73) |
| `user-002` | สาริน ช่อพะยอม | Admin + Tier1 | 1 | All (73) |
| `user-003` | วรรณภา แซ่ด่าง | Tier1 + Staff | 1 | 9 projects |
| `user-004` | เขมิกา แซ่ตั้ง | Tier1 + Staff | 1 | 5 projects |
| `user-005` | ธัญญาพร ทองแก้ว | Tier1 + Staff | 1 | 5 projects |
| `user-006` | ยุทธนา คณามิ่งมงคล | Tier2 | 2 | All (73) |
| `user-007` | ประกาศิต ประคองเพ็ชร | Tier2 + Tier3 | 2 | All (73) |
| `user-008` | ประวิช จินทนากร | Tier2 | 2 | 8 projects |
| `user-009` | พุทธจักษ์ วงค์พันธ์ | Tier3 | 3 | 6 projects |
| `user-010` | วีระกร เยือกเย็น | Tier3 | 3 | 5 projects |
| `user-011` | ประอรรัตน์ กีรติผจญ | Admin (Pure) | - | 3 projects |
| `user-012` | อภิญญา ทองชัย | Tier1 (Pure) | 1 | 3 projects |
| `staff-001` | สมชาย ใจดี | Staff (Pure) | - | 3 projects |

### 🔑 Test Accounts

```typescript
// Admin + Tier1
Username: thiraporn.r
Password: thiraporn.r123

// Tier2 + Tier3
Username: prakasit.p
Password: prakasit.p123

// Tier1 (Pure)
Username: aphinya.t
Password: aphinya.t123

// Staff (Pure)
Username: somchai.j
Password: somchai.j123

// Customer
Username: customer1
Password: customer1123
```

---

### 🏢 Projects (73 total)

#### CSV Projects (23)
Recent projects from CSV import (D26-xxxx codes)

**ตัวอย่าง:**
- `D26-0001` - ERC (สำนักงานคณะกรรมการกำกับกิจการพลังงาน)
- `D26-0002` - RMUTP (มหาวิทยาลัยเทคโนโลยีราชมงคลพระนคร)
- `D26-0003` - DOC (กรมป้องกันและบรรเทาสาธารณภัย)

#### Legacy Projects (50)
Older projects (D24-xxxx, PD25-xxxx codes)

**ตัวอย่าง:**
- `D24-0001` - MRTA (การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย)
- `D24-0002` - DOT (กรมการขนส่งทางบก)
- `PD25-0010` - BMA (กรุงเทพมหานคร)

---

### 🎫 Tickets (200+ total)

| ประเภท | จำนวน | สถานะ | Source |
|--------|-------|-------|--------|
| **Customer Tickets** | ~50 | needsTriage: true | Web Form |
| **Staff Tickets** | ~100 | needsTriage: false | Phone, Email, Line |
| **Tier2-3 Tickets** | ~35 | In Progress | mockDataTier23* |
| **CSV Tickets** | ~100 | Various | CSV Import |
| **Read-Only Tickets** | ~10 | Testing | mockDataReadOnly |

---

## โครงสร้างไฟล์

### 📁 Main Files

```
/lib/
├── mockData.ts              ✅ Main Entry Point (6000+ lines)
│   ├── mockUsers            (13 users)
│   ├── mockProjects         (73 projects)
│   ├── allTickets           (200+ tickets)
│   ├── mockAttachments      (~50 attachments)
│   └── Helper Functions
│
├── mock-users.ts            ✅ Login Credentials + User Profiles
│   ├── mockUsers[]          (Login data)
│   └── getUserByCredentials()
│
└── mockData/                ✅ Modular Structure (NEW)
    ├── index.ts
    ├── users.ts
    ├── projects.ts
    └── helpers/
        └── attachments.ts
```

### 📁 Ticket Files

```
/lib/
├── mockDataExtra.ts         (~50 tickets)
├── mockDataReadOnly.ts      (~10 tickets)
├── mockDataReports.ts       (~20 tickets)
├── mockDataCSVTickets.ts    (50 tickets - Part 1)
├── mockDataCSVTicketsPart2.ts (50+ tickets - Part 2)
├── mockDataTier23Resolved.ts (~15 tickets)
└── mockDataTier23More.ts    (~20 tickets)
```

### 📁 Project Files

```
/lib/
├── mockDataCSV.ts           (CSV Projects)
├── mockDataCSVProjects.ts   (CSV Projects Import)
└── mockDataCSVUsers.ts      (CSV Users Import)
```

---

## Helper Functions

### 👥 User Functions

```typescript
// ค้นหา User จาก ID
const user = getUserById('user-001');

// ค้นหา User จาก Username + Password
const user = getUserByCredentials('thiraporn.r', 'thiraporn.r123');

// ดึง Users ตาม Tier
const tier1Users = getUsersByTier(1);
const tier2Users = getUsersByTier(2);
const tier3Users = getUsersByTier(3);
```

### 🏢 Project Functions

```typescript
// ค้นหา Project จาก ID
const project = getProjectById('D26-0001');

// ค้นหา Project จาก Project Code
const project = getProjectByCode('ERC');
```

### 🎫 Ticket Functions

```typescript
// ดึง Tickets ทั้งหมด
const tickets = allTickets; // 200+ tickets

// ดึง Tickets ตาม Category
const customerTickets = allTickets.filter(t => t.channel === 'web');
const staffTickets = allTickets.filter(t => t.channel !== 'web');
```

### 📎 Attachment Functions

```typescript
// ดึง Attachments ของ Ticket
const attachments = getAttachmentsByTicketId('ticket-id');
```

### 👤 Customer Functions

```typescript
// สร้าง Customer ใหม่
const customer = createCustomer('ชื่อเต็ม', 'email@example.com');

// อัพเดท Last Login
updateCustomerLastLogin('customer-id');
```

---

## Migration Notes

### ✅ Migration เสร็จแล้ว (Completed)

| Item | Status | Date | Notes |
|------|--------|------|-------|
| User fullName | ✅ | 2025-01-15 | เปลี่ยนจาก `name` → `fullName` |
| creatorType | ✅ | 2025-01-18 | เพิ่ม field `creatorType` |
| Multi-role Support | ✅ | 2025-01-20 | roles: string[] |
| Modular Structure | 🔄 | In Progress | /lib/mockData/ |

### 🔄 ขั้นตอนการ Migrate

**1. Users Migration:**
```typescript
// เก่า
user.name → user.fullName

// ใหม่
user.fullName ✅ (ใช้ทุกที่แล้ว)
```

**2. Roles Migration:**
```typescript
// เก่า
user.role = 'admin'

// ใหม่
user.roles = ['admin', 'tier1']
user.primaryRole = 'admin'
```

**3. CreatorType Migration:**
```typescript
// เพิ่ม field ใหม่
ticket.creatorType = 'customer' | 'staff'
```

---

## 📊 Data Statistics

### Users
- **Total:** 13 users
- **Admin:** 3 users (user-001, 002, 011)
- **Tier1:** 6 users
- **Tier2:** 3 users
- **Tier3:** 3 users
- **Staff:** 4 users
- **Customer:** 2 test accounts

### Projects
- **Total:** 73 projects
- **CSV Projects:** 23 (D26-xxxx)
- **Legacy Projects:** 50 (D24-xxxx, PD25-xxxx)
- **Active:** ~60
- **Inactive:** ~13

### Tickets
- **Total:** 200+ tickets
- **Customer Tickets:** ~50 (needsTriage: true)
- **Staff Tickets:** ~150 (needsTriage: false)
- **Status Distribution:**
  - New: ~30
  - In Progress: ~80
  - Waiting: ~20
  - Resolved: ~50
  - Closed: ~20

### Attachments
- **Total:** ~50 attachments
- **Per Ticket:** 0-5 files
- **File Types:** Images, PDFs, Documents

---

## 🔧 Common Patterns

### Pattern 1: Get User by Role

```typescript
import { mockUsers, isTier1, isPureStaff } from '@/lib/mockData';

// ดึง Tier1 ทั้งหมด
const tier1Users = mockUsers.filter(u => isTier1(u.user));

// ดึง Pure Staff
const staffUsers = mockUsers.filter(u => isPureStaff(u.user));
```

### Pattern 2: Filter Tickets by User

```typescript
import { allTickets } from '@/lib/mockData';

// เคสที่ user รับผิดชอบ
const myTickets = allTickets.filter(t => t.assignedTo === user.id);

// เคสที่ user สร้าง
const createdByMe = allTickets.filter(t => t.createdBy === user.id);
```

### Pattern 3: Get Project Info

```typescript
import { getProjectById } from '@/lib/mockData';

const project = getProjectById(ticket.projectId);
console.log(project.organizationName); // ชื่อหน่วยงาน
console.log(project.projectCode);      // รหัสโครงการ
```

---

## 🚨 Known Issues (Fixed)

### ✅ Issue 1: Character Encoding
**ปัญหา:** ชื่อภาษาไทยเป็น � (mojibake)  
**แก้ไข:** แก้ encoding เป็น UTF-8  
**Status:** ✅ Fixed (2025-01-15)

### ✅ Issue 2: creatorType Missing
**ปัญหา:** ไม่สามารถแยก Customer/Staff tickets  
**แก้ไข:** เพิ่ม field `creatorType`  
**Status:** ✅ Fixed (2025-01-18)

### ✅ Issue 3: fullName vs name
**ปัญหา:** ใช้ `name` และ `fullName` สับสน  
**แก้ไข:** ใช้ `fullName` ทั้งระบบ  
**Status:** ✅ Fixed (2025-01-20)

### ✅ Issue 4: Data Consistency
**ปัญหา:** Customer name ไม่ตรงกัน  
**แก้ไข:** Normalize ชื่อลูกค้าทั้งหมด  
**Status:** ✅ Fixed (2025-01-21)

---

## 📚 Related Documentation

- [Database Schema](DATABASE_SCHEMA.md)
- [User List](../team/USER_LIST.md)
- [Team Members](../team/TEAM_MEMBERS.md)
- [Permissions Guide](../PERMISSIONS_GUIDE.md)

---

## 📝 Changelog

| Date | Version | Changes |
|------|---------|---------|
| 2025-01-22 | 2.0 | รวมเอกสาร 10 ไฟล์เป็นไฟล์เดียว |
| 2025-01-20 | 1.5 | อัพเดท fullName ทั้งระบบ |
| 2025-01-18 | 1.4 | เพิ่ม creatorType |
| 2025-01-15 | 1.3 | แก้ไข character encoding |

---

**Consolidated from:**
- MOCKDATA_COMPLETE_FIX_SUMMARY.md
- MOCKDATA_CREATOR_TYPE_UPDATE.md
- MOCKDATA_FIX_REPORT.md
- MOCKUP_DATA_MAP.md
- MOCK_DATA_MAP.md
- MOCK_DATA_MIGRATION_CHECKLIST.md
- MOCK_DATA_QUICK_REF.md
- MOCK_DATA_REFACTORING.md
- MOCK_DATA_STRUCTURE.md
- MOCK_DATA_SUMMARY.md
