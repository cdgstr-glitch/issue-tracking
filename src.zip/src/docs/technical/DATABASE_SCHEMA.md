# 🗄️ CDGS Issue Tracking Platform - Database Schema Design

**วันที่:** 17 มกราคม 2026  
**ผู้จัดทำ:** Database Architecture Team  
**เวอร์ชัน:** 1.0

---

## 📋 **สารบัญ**

1. [ภาพรวมระบบ](#overview)
2. [โครงสร้างตาราง (Tables)](#tables)
3. [ความสัมพันธ์ (Relationships)](#relationships)
4. [Indexes และ Performance](#indexes)
5. [Data Dictionary](#dictionary)
6. [SQL Schema](#sql-schema)

---

<a name="overview"></a>
## 1️⃣ **ภาพรวมระบบ**

### **ลักษณะของระบบ:**
- **ประเภท:** Enterprise Issue Tracking System
- **รูปแบบ:** Multi-tenant, Multi-project, Multi-role
- **Workflow:** 3-Tier Escalation System (Tier1 → Tier2 → Tier3)
- **Channels:** Web, Email, LINE, Phone
- **Features:** 
  - Ticket Management
  - User Management (Multi-role)
  - Project Management
  - Escalation Chain
  - Timeline & Comments
  - Attachments
  - Reports & Analytics

---

<a name="tables"></a>
## 2️⃣ **โครงสร้างตาราง (Tables)**

### **สรุปตารางทั้งหมด: 11 ตาราง**

| # | ตาราง | จำนวน Fields | ความสำคัญ | หมายเหตุ |
|---|--------|--------------|-----------|----------|
| 1 | **users** | 14 | ⭐⭐⭐ | ผู้ใช้งานและ Multi-role |
| 2 | **projects** | 7 | ⭐⭐⭐ | โครงการ (Multi-project) |
| 3 | **tickets** | 35 | ⭐⭐⭐⭐⭐ | ตั๋วเคส (Core Table) |
| 4 | **ticket_timeline** | 12 | ⭐⭐⭐⭐ | ประวัติเคส |
| 5 | **ticket_comments** | 9 | ⭐⭐⭐ | ความคิดเห็น |
| 6 | **ticket_attachments** | 10 | ⭐⭐⭐ | ไฟล์แนบ |
| 7 | **escalation_chain** | 7 | ⭐⭐⭐⭐ | ประวัติการส่งต่อ |
| 8 | **ticket_stakeholders** | 6 | ⭐⭐⭐ | ผู้เกี่ยวข้อง |
| 9 | **ticket_viewers** | 5 | ⭐⭐ | ผู้ดูแบบ Read-only |
| 10 | **user_roles** | 4 | ⭐⭐⭐⭐ | Multi-role Mapping |
| 11 | **user_projects** | 4 | ⭐⭐⭐ | Multi-project Mapping |

---

### **📊 Table 1: users**

**คำอธิบาย:** เก็บข้อมูลผู้ใช้งานทั้งหมด (Customer, Staff, Tier1-3, Admin)

```sql
CREATE TABLE users (
  -- Primary Key
  id                VARCHAR(36) PRIMARY KEY,        -- UUID
  
  -- Authentication
  username          VARCHAR(100) UNIQUE NOT NULL,   -- Username สำหรับ Login
  password_hash     VARCHAR(255) NOT NULL,          -- bcrypt hash
  email             VARCHAR(255) UNIQUE NOT NULL,   -- อีเมล (unique)
  
  -- Personal Info
  full_name         VARCHAR(255) NOT NULL,          -- ชื่อ-สกุล เต็ม
  phone             VARCHAR(20),                    -- เบอร์โทรศัพท์
  department        VARCHAR(255),                   -- หน่วยงาน/สังกัด
  
  -- Role & Tier (Legacy - keep for backward compatibility)
  primary_role      ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  tier              TINYINT,                        -- 1, 2, 3 (for tier users)
  
  -- Manager Hierarchy
  manager_id        VARCHAR(36),                    -- หัวหน้าคนที่ 1
  senior_manager_id VARCHAR(36),                    -- หัวหน้าคนที่ 2
  manager_email     VARCHAR(255),                   -- อีเมลหัวหน้า
  
  -- Metadata
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  -- Foreign Keys
  FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (senior_manager_id) REFERENCES users(id) ON DELETE SET NULL,
  
  -- Indexes
  INDEX idx_username (username),
  INDEX idx_email (email),
  INDEX idx_primary_role (primary_role),
  INDEX idx_manager (manager_id)
);
```

**ตัวอย่างข้อมูล:**
```sql
INSERT INTO users VALUES (
  'user-001',
  'aphiya.t',
  '$2b$10$...',  -- hashed password
  'aphiya.t@cdgs.co.th',
  'อภิญญา ทองชัย',
  '081-234-5678',
  'Customer Service',
  'tier1',
  1,
  'user-999',  -- manager
  NULL,
  'manager@cdgs.co.th',
  NOW(),
  NOW()
);
```

---

### **📊 Table 2: user_roles**

**คำอธิบาย:** Multi-role mapping (1 user สามารถมีหลาย role)

```sql
CREATE TABLE user_roles (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    VARCHAR(36) NOT NULL,
  role       ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_role (user_id, role),
  INDEX idx_user_id (user_id),
  INDEX idx_role (role)
);
```

**ตัวอย่างข้อมูล:**
```sql
-- User ที่เป็นทั้ง tier1 และ staff
INSERT INTO user_roles (user_id, role) VALUES 
  ('user-001', 'tier1'),
  ('user-001', 'staff');
```

---

### **📊 Table 3: projects**

**คำอธิบาย:** โครงการทั้งหมด (Multi-project Support)

```sql
CREATE TABLE projects (
  id          VARCHAR(36) PRIMARY KEY,
  code        VARCHAR(50) UNIQUE NOT NULL,   -- เช่น D24-6061, PD250020
  name        VARCHAR(500) NOT NULL,         -- ชื่อเต็ม
  short_name  VARCHAR(100) NOT NULL,         -- ชื่อย่อ เช่น MRTA, DOT
  department  VARCHAR(255),                  -- หน่วยงาน
  description TEXT,                          -- รายละเอียด
  
  -- Metadata
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_code (code),
  INDEX idx_short_name (short_name)
);
```

**ตัวอย่างข้อมูล:**
```sql
INSERT INTO projects VALUES (
  'proj-001',
  'D24-6061',
  'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
  'MRTA',
  'กระทรวงคมนาคม',
  'ระบบจองห้องประชุมออนไลน์',
  NOW(),
  NOW()
);
```

---

### **📊 Table 4: user_projects**

**คำอธิบาย:** Multi-project mapping (1 user ทำงานได้หลายโครงการ)

```sql
CREATE TABLE user_projects (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    VARCHAR(36) NOT NULL,
  project_id VARCHAR(36) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_project (user_id, project_id),
  INDEX idx_user_id (user_id),
  INDEX idx_project_id (project_id)
);
```

---

### **📊 Table 5: tickets** ⭐⭐⭐⭐⭐

**คำอธิบาย:** ตั๋วเคสหลัก (Core Table)

```sql
CREATE TABLE tickets (
  -- Primary Key
  id              VARCHAR(36) PRIMARY KEY,
  ticket_number   VARCHAR(50) UNIQUE NOT NULL,      -- เช่น CDGS-2025-0001
  
  -- Basic Info
  title           VARCHAR(500) NOT NULL,
  description     TEXT NOT NULL,
  status          ENUM('new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed') NOT NULL,
  type            ENUM('incident', 'service_request', 'security_incident') NOT NULL,
  channel         ENUM('web', 'email', 'line', 'phone') NOT NULL,
  priority        ENUM('low', 'medium', 'high', 'critical') NOT NULL,
  category        VARCHAR(100) NOT NULL,            -- account, system, technical, etc.
  
  -- Product & Department
  product         VARCHAR(255),                     -- ผลิตภัณฑ์ เช่น Asset Management, e-Booking
  department      VARCHAR(255),                     -- หน่วยงาน
  
  -- Customer Info
  customer_name   VARCHAR(255) NOT NULL,
  customer_email  VARCHAR(255) NOT NULL,
  customer_phone  VARCHAR(20),
  
  -- Assignment
  assigned_to     VARCHAR(36),                      -- User ID ของผู้รับผิดชอบ
  assigned_by     VARCHAR(36),                      -- User ID ของผู้มอบหมาย
  assigned_at     TIMESTAMP,
  previous_assignee VARCHAR(36),                    -- สำหรับ Takeover
  
  -- Project
  project_id      VARCHAR(36),
  project_code    VARCHAR(50),
  project_name    VARCHAR(500),
  project_short_name VARCHAR(100),
  
  -- Creator Info
  created_by      VARCHAR(36),                      -- User ID ของผู้สร้าง
  created_by_name VARCHAR(255),                     -- ชื่อผู้สร้าง
  created_by_type ENUM('customer_self', 'staff_on_behalf'),  -- ประเภทการสร้าง
  created_by_staff_name VARCHAR(255),               -- ชื่อ staff ที่บันทึกแทน
  
  -- Timestamps
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  due_date        TIMESTAMP NOT NULL,
  
  -- Resolution
  resolved_at     TIMESTAMP,
  resolved_by     VARCHAR(36),                      -- User ID ของผู้แก้ไข
  closed_at       TIMESTAMP,
  closed_by       VARCHAR(36),                      -- User ID ของผู้ปิด
  solution        TEXT,                             -- วิธีแก้ไข
  closure_notes   TEXT,                             -- หมายเหตุการปิด
  
  -- Foreign Keys
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (previous_assignee) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (closed_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
  
  -- Indexes
  INDEX idx_ticket_number (ticket_number),
  INDEX idx_status (status),
  INDEX idx_priority (priority),
  INDEX idx_channel (channel),
  INDEX idx_assigned_to (assigned_to),
  INDEX idx_project_id (project_id),
  INDEX idx_created_at (created_at),
  INDEX idx_customer_email (customer_email),
  INDEX idx_status_assigned (status, assigned_to),  -- Composite index
  FULLTEXT INDEX ft_title_description (title, description)  -- Full-text search
);
```

---

### **📊 Table 6: ticket_timeline**

**คำอธิบาย:** ประวัติการเปลี่ยนแปลงของเคส

```sql
CREATE TABLE ticket_timeline (
  id            VARCHAR(36) PRIMARY KEY,
  ticket_id     VARCHAR(36) NOT NULL,
  timestamp     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  event_type    ENUM('status_change', 'comment', 'escalation', 'assignment', 'attachment', 'created', 'resolved', 'closed') NOT NULL,
  action        VARCHAR(100),                       -- เช่น 'create_ticket'
  description   TEXT NOT NULL,
  
  -- User Info
  user_id       VARCHAR(36),                        -- ผู้กระทำ
  user_name     VARCHAR(255),                       -- ชื่อผู้กระทำ
  assigned_to_user_id VARCHAR(36),                  -- ผู้รับ (สำหรับ escalation/assignment)
  assigned_to_user_name VARCHAR(255),               -- ชื่อผู้รับ
  
  -- Additional
  status        VARCHAR(50),                        -- สถานะใหม่
  is_internal   BOOLEAN DEFAULT FALSE,              -- ซ่อนจากลูกค้า
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_to_user_id) REFERENCES users(id) ON DELETE SET NULL,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_timestamp (timestamp),
  INDEX idx_event_type (event_type)
);
```

---

### **📊 Table 7: ticket_comments**

**คำอธิบาย:** ความคิดเห็น/การตอบกลับในเคส

```sql
CREATE TABLE ticket_comments (
  id          VARCHAR(36) PRIMARY KEY,
  ticket_id   VARCHAR(36) NOT NULL,
  author_id   VARCHAR(36) NOT NULL,               -- User ID ของผู้เขียน
  author_name VARCHAR(255) NOT NULL,              -- ชื่อผู้เขียน
  author_role ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  content     TEXT NOT NULL,
  is_internal BOOLEAN DEFAULT FALSE,              -- ซ่อนจากลูกค้า
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_author_id (author_id),
  INDEX idx_created_at (created_at)
);
```

---

### **📊 Table 8: ticket_attachments**

**คำอธิบาย:** ไฟล์แนบ

```sql
CREATE TABLE ticket_attachments (
  id            VARCHAR(36) PRIMARY KEY,
  ticket_id     VARCHAR(36),                      -- NULL = แนบกับ comment
  comment_id    VARCHAR(36),                      -- NULL = แนบกับ ticket
  filename      VARCHAR(255) NOT NULL,
  file_size     BIGINT NOT NULL,                  -- bytes
  file_type     VARCHAR(100) NOT NULL,            -- MIME type
  file_url      VARCHAR(500) NOT NULL,            -- S3/Cloud storage URL
  uploaded_by   VARCHAR(36) NOT NULL,
  uploaded_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (comment_id) REFERENCES ticket_comments(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_comment_id (comment_id),
  INDEX idx_uploaded_by (uploaded_by)
);
```

---

### **📊 Table 9: escalation_chain**

**คำอธิบาย:** ประวัติการส่งต่อเคส (Tier1 → Tier2 → Tier3)

```sql
CREATE TABLE escalation_chain (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id           VARCHAR(36) NOT NULL,
  from_tier           ENUM('tier1', 'tier2', 'tier3') NOT NULL,
  to_tier             ENUM('tier1', 'tier2', 'tier3') NOT NULL,
  escalated_by        VARCHAR(36) NOT NULL,           -- User ID
  escalated_by_name   VARCHAR(255) NOT NULL,          -- ชื่อเต็ม
  escalated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reason              TEXT,                           -- เหตุผลในการส่งต่อ
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (escalated_by) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_escalated_at (escalated_at)
);
```

---

### **📊 Table 10: ticket_stakeholders**

**คำอธิบาย:** ผู้เกี่ยวข้องกับเคส (creator, escalator, current_owner)

```sql
CREATE TABLE ticket_stakeholders (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id VARCHAR(36) NOT NULL,
  user_id   VARCHAR(36) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role      ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  tier      TINYINT,
  type      ENUM('creator', 'escalator', 'current_owner') NOT NULL,
  added_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_ticket_user_type (ticket_id, user_id, type),
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_user_id (user_id),
  INDEX idx_type (type)
);
```

---

### **📊 Table 11: ticket_viewers**

**คำอธิบาย:** ผู้ดูเคสแบบ Read-only (ไม่ใช่เจ้าของ)

```sql
CREATE TABLE ticket_viewers (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id     VARCHAR(36) NOT NULL,
  user_id       VARCHAR(36) NOT NULL,
  full_name     VARCHAR(255) NOT NULL,
  role          VARCHAR(50) NOT NULL,
  viewing_since TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_ticket_viewer (ticket_id, user_id),
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_user_id (user_id)
);
```

---

<a name="relationships"></a>
## 3️⃣ **ความสัมพันธ์ (Relationships)**

### **📐 ER Diagram (Text Format)**

```
┌─────────────┐
│   USERS     │◄──┐
└──────┬──────┘   │
       │          │
       │ 1        │ N
       │          │
       ▼          │
┌─────────────┐  │
│ USER_ROLES  │  │
└─────────────┘  │
                 │
┌─────────────┐  │
│  PROJECTS   │  │
└──────┬──────┘  │
       │         │
       │ 1       │ N
       │         │
       ▼         │
┌──────────────┐ │
│USER_PROJECTS │ │
└──────────────┘ │
                 │
       ┌─────────┴──────────┐
       │                    │
       │ 1                  │ N
       ▼                    │
┌─────────────┐             │
│   TICKETS   │◄────────────┤
└──────┬──────┘             │
       │                    │
       │ 1                  │
       │                    │
       ├────────────────────┼─────► TICKET_TIMELINE (N)
       │                    │
       ├────────────────────┼─────► TICKET_COMMENTS (N)
       │                    │
       ├────────────────────┼─────► TICKET_ATTACHMENTS (N)
       │                    │
       ├────────────────────┼─────► ESCALATION_CHAIN (N)
       │                    │
       ├────────────────────┼─────► TICKET_STAKEHOLDERS (N)
       │                    │
       └────────────────────┴─────► TICKET_VIEWERS (N)
```

---

### **📊 Relationship Matrix**

| From Table | To Table | Type | Cardinality | FK Column |
|------------|----------|------|-------------|-----------|
| users | users | Self-reference | 1:N | manager_id |
| user_roles | users | Many-to-One | N:1 | user_id |
| user_projects | users | Many-to-One | N:1 | user_id |
| user_projects | projects | Many-to-One | N:1 | project_id |
| tickets | users | Many-to-One | N:1 | assigned_to |
| tickets | users | Many-to-One | N:1 | created_by |
| tickets | users | Many-to-One | N:1 | closed_by |
| tickets | projects | Many-to-One | N:1 | project_id |
| ticket_timeline | tickets | Many-to-One | N:1 | ticket_id |
| ticket_timeline | users | Many-to-One | N:1 | user_id |
| ticket_comments | tickets | Many-to-One | N:1 | ticket_id |
| ticket_comments | users | Many-to-One | N:1 | author_id |
| ticket_attachments | tickets | Many-to-One | N:1 | ticket_id |
| ticket_attachments | ticket_comments | Many-to-One | N:1 | comment_id |
| escalation_chain | tickets | Many-to-One | N:1 | ticket_id |
| escalation_chain | users | Many-to-One | N:1 | escalated_by |
| ticket_stakeholders | tickets | Many-to-One | N:1 | ticket_id |
| ticket_stakeholders | users | Many-to-One | N:1 | user_id |
| ticket_viewers | tickets | Many-to-One | N:1 | ticket_id |
| ticket_viewers | users | Many-to-One | N:1 | user_id |

---

<a name="indexes"></a>
## 4️⃣ **Indexes และ Performance**

### **📈 Primary Indexes**

| ตาราง | Index Name | Columns | Purpose |
|-------|------------|---------|---------|
| users | PRIMARY | id | PK |
| users | idx_username | username | Login |
| users | idx_email | email | Search |
| tickets | PRIMARY | id | PK |
| tickets | idx_ticket_number | ticket_number | Search |
| tickets | idx_status_assigned | status, assigned_to | Dashboard filter |

---

### **📊 Composite Indexes (สำคัญ!)**

```sql
-- Dashboard: แสดงเคสตามสถานะและผู้รับผิดชอบ
CREATE INDEX idx_status_assigned ON tickets(status, assigned_to);

-- Search: ค้นหาเคสตามโครงการและสถานะ
CREATE INDEX idx_project_status ON tickets(project_id, status);

-- Timeline: ดึง timeline ตามเคสและเรียงตามเวลา
CREATE INDEX idx_ticket_timestamp ON ticket_timeline(ticket_id, timestamp DESC);

-- Reports: รายงานตาม channel และช่วงเวลา
CREATE INDEX idx_channel_created ON tickets(channel, created_at);
```

---

### **🔍 Full-Text Search**

```sql
-- Search tickets by title and description
CREATE FULLTEXT INDEX ft_title_description ON tickets(title, description);

-- Usage:
SELECT * FROM tickets 
WHERE MATCH(title, description) AGAINST('ระบบล่ม' IN NATURAL LANGUAGE MODE);
```

---

<a name="dictionary"></a>
## 5️⃣ **Data Dictionary**

### **🔤 Enums และ Constants**

#### **Ticket Status:**
```sql
ENUM('new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed')
```

| Value | ภาษาไทย | คำอธิบาย |
|-------|---------|----------|
| new | เคสใหม่ | รอ Tier1 รับเคส |
| tier1 | Tier1 | อยู่ที่ Tier1 |
| tier2 | Tier2 | ส่งต่อไป Tier2 |
| tier3 | Tier3 | ส่งต่อไป Tier3 |
| in_progress | กำลังดำเนินการ | Tier รับเคสแล้ว |
| waiting | หยุดชั่วคราว | รอข้อมูลเพิ่มเติม |
| resolved | แก้ไขแล้ว | แก้ไขเสร็จ รอ Tier1 ปิด |
| closed | ปิดแล้ว | Tier1 ปิดเคส |

---

#### **Ticket Type:**
```sql
ENUM('incident', 'service_request', 'security_incident')
```

| Value | ภาษาไทย | Priority Default |
|-------|---------|------------------|
| incident | เหตุการณ์/ปัญหา | medium |
| service_request | คำขอบริการ | low |
| security_incident | เหตุการณ์ความปลอดภัย | critical |

---

#### **Channel:**
```sql
ENUM('web', 'email', 'line', 'phone')
```

| Value | ภาษาไทย | Icon |
|-------|---------|------|
| web | เว็บไซต์ | 🌐 |
| email | อีเมล | 📧 |
| line | LINE | 💬 |
| phone | โทรศัพท์ | ☎️ |

---

#### **Priority:**
```sql
ENUM('low', 'medium', 'high', 'critical')
```

| Value | ภาษาไทย | SLA (hours) | Color |
|-------|---------|-------------|-------|
| low | น้อย | 72 | 🟢 Green |
| medium | ปานกลาง | 48 | 🟡 Yellow |
| high | สูง | 24 | 🟠 Orange |
| critical | วิกฤต | 4 | 🔴 Red |

---

#### **User Role:**
```sql
ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin')
```

| Value | ภาษาไทย | Permissions |
|-------|---------|-------------|
| customer | ลูกค้า | ดูเคสของตัวเอง |
| staff | เจ้าหน้าที่ | บันทึกเคสแทนลูกค้า |
| tier1 | Tier 1 | รับ/ส่งต่อ/ปิดเคส |
| tier2 | Tier 2 | รับ/ส่งต่อเคส |
| tier3 | Tier 3 | รับ/แก้ไขเคส |
| admin | ผู้ดูแลระบบ | ทุกอย่าง |

---

<a name="sql-schema"></a>
## 6️⃣ **SQL Schema (Full)**

### **🗄️ MySQL/MariaDB**

```sql
-- ====================================
-- CDGS Issue Tracking Platform
-- Database Schema v1.0
-- ====================================

-- Set charset
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- Create database
CREATE DATABASE IF NOT EXISTS cdgs_issue_tracking
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE cdgs_issue_tracking;

-- ====================================
-- Table 1: users
-- ====================================
CREATE TABLE users (
  id                VARCHAR(36) PRIMARY KEY,
  username          VARCHAR(100) UNIQUE NOT NULL,
  password_hash     VARCHAR(255) NOT NULL,
  email             VARCHAR(255) UNIQUE NOT NULL,
  full_name         VARCHAR(255) NOT NULL,
  phone             VARCHAR(20),
  department        VARCHAR(255),
  primary_role      ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  tier              TINYINT,
  manager_id        VARCHAR(36),
  senior_manager_id VARCHAR(36),
  manager_email     VARCHAR(255),
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (senior_manager_id) REFERENCES users(id) ON DELETE SET NULL,
  
  INDEX idx_username (username),
  INDEX idx_email (email),
  INDEX idx_primary_role (primary_role),
  INDEX idx_manager (manager_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 2: user_roles
-- ====================================
CREATE TABLE user_roles (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    VARCHAR(36) NOT NULL,
  role       ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_role (user_id, role),
  INDEX idx_user_id (user_id),
  INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 3: projects
-- ====================================
CREATE TABLE projects (
  id          VARCHAR(36) PRIMARY KEY,
  code        VARCHAR(50) UNIQUE NOT NULL,
  name        VARCHAR(500) NOT NULL,
  short_name  VARCHAR(100) NOT NULL,
  department  VARCHAR(255),
  description TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  INDEX idx_code (code),
  INDEX idx_short_name (short_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 4: user_projects
-- ====================================
CREATE TABLE user_projects (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    VARCHAR(36) NOT NULL,
  project_id VARCHAR(36) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_project (user_id, project_id),
  INDEX idx_user_id (user_id),
  INDEX idx_project_id (project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 5: tickets (Core Table)
-- ====================================
CREATE TABLE tickets (
  id                    VARCHAR(36) PRIMARY KEY,
  ticket_number         VARCHAR(50) UNIQUE NOT NULL,
  title                 VARCHAR(500) NOT NULL,
  description           TEXT NOT NULL,
  status                ENUM('new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed') NOT NULL,
  type                  ENUM('incident', 'service_request', 'security_incident') NOT NULL,
  channel               ENUM('web', 'email', 'line', 'phone') NOT NULL,
  priority              ENUM('low', 'medium', 'high', 'critical') NOT NULL,
  category              VARCHAR(100) NOT NULL,
  product               VARCHAR(255),
  department            VARCHAR(255),
  customer_name         VARCHAR(255) NOT NULL,
  customer_email        VARCHAR(255) NOT NULL,
  customer_phone        VARCHAR(20),
  assigned_to           VARCHAR(36),
  assigned_by           VARCHAR(36),
  assigned_at           TIMESTAMP,
  previous_assignee     VARCHAR(36),
  project_id            VARCHAR(36),
  project_code          VARCHAR(50),
  project_name          VARCHAR(500),
  project_short_name    VARCHAR(100),
  created_by            VARCHAR(36),
  created_by_name       VARCHAR(255),
  created_by_type       ENUM('customer_self', 'staff_on_behalf'),
  created_by_staff_name VARCHAR(255),
  created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  due_date              TIMESTAMP NOT NULL,
  resolved_at           TIMESTAMP,
  resolved_by           VARCHAR(36),
  closed_at             TIMESTAMP,
  closed_by             VARCHAR(36),
  solution              TEXT,
  closure_notes         TEXT,
  
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (previous_assignee) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (closed_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
  
  INDEX idx_ticket_number (ticket_number),
  INDEX idx_status (status),
  INDEX idx_priority (priority),
  INDEX idx_channel (channel),
  INDEX idx_assigned_to (assigned_to),
  INDEX idx_project_id (project_id),
  INDEX idx_created_at (created_at),
  INDEX idx_customer_email (customer_email),
  INDEX idx_status_assigned (status, assigned_to),
  INDEX idx_project_status (project_id, status),
  INDEX idx_channel_created (channel, created_at),
  FULLTEXT INDEX ft_title_description (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 6: ticket_timeline
-- ====================================
CREATE TABLE ticket_timeline (
  id            VARCHAR(36) PRIMARY KEY,
  ticket_id     VARCHAR(36) NOT NULL,
  timestamp     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  event_type    ENUM('status_change', 'comment', 'escalation', 'assignment', 'attachment', 'created', 'resolved', 'closed') NOT NULL,
  action        VARCHAR(100),
  description   TEXT NOT NULL,
  user_id       VARCHAR(36),
  user_name     VARCHAR(255),
  assigned_to_user_id VARCHAR(36),
  assigned_to_user_name VARCHAR(255),
  status        VARCHAR(50),
  is_internal   BOOLEAN DEFAULT FALSE,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_to_user_id) REFERENCES users(id) ON DELETE SET NULL,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_timestamp (timestamp),
  INDEX idx_event_type (event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 7: ticket_comments
-- ====================================
CREATE TABLE ticket_comments (
  id          VARCHAR(36) PRIMARY KEY,
  ticket_id   VARCHAR(36) NOT NULL,
  author_id   VARCHAR(36) NOT NULL,
  author_name VARCHAR(255) NOT NULL,
  author_role ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  content     TEXT NOT NULL,
  is_internal BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_author_id (author_id),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 8: ticket_attachments
-- ====================================
CREATE TABLE ticket_attachments (
  id            VARCHAR(36) PRIMARY KEY,
  ticket_id     VARCHAR(36),
  comment_id    VARCHAR(36),
  filename      VARCHAR(255) NOT NULL,
  file_size     BIGINT NOT NULL,
  file_type     VARCHAR(100) NOT NULL,
  file_url      VARCHAR(500) NOT NULL,
  uploaded_by   VARCHAR(36) NOT NULL,
  uploaded_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (comment_id) REFERENCES ticket_comments(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_comment_id (comment_id),
  INDEX idx_uploaded_by (uploaded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 9: escalation_chain
-- ====================================
CREATE TABLE escalation_chain (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id           VARCHAR(36) NOT NULL,
  from_tier           ENUM('tier1', 'tier2', 'tier3') NOT NULL,
  to_tier             ENUM('tier1', 'tier2', 'tier3') NOT NULL,
  escalated_by        VARCHAR(36) NOT NULL,
  escalated_by_name   VARCHAR(255) NOT NULL,
  escalated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reason              TEXT,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (escalated_by) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_escalated_at (escalated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 10: ticket_stakeholders
-- ====================================
CREATE TABLE ticket_stakeholders (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id VARCHAR(36) NOT NULL,
  user_id   VARCHAR(36) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role      ENUM('customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin') NOT NULL,
  tier      TINYINT,
  type      ENUM('creator', 'escalator', 'current_owner') NOT NULL,
  added_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_ticket_user_type (ticket_id, user_id, type),
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_user_id (user_id),
  INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table 11: ticket_viewers
-- ====================================
CREATE TABLE ticket_viewers (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id     VARCHAR(36) NOT NULL,
  user_id       VARCHAR(36) NOT NULL,
  full_name     VARCHAR(255) NOT NULL,
  role          VARCHAR(50) NOT NULL,
  viewing_since TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_ticket_viewer (ticket_id, user_id),
  INDEX idx_ticket_id (ticket_id),
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

**สร้างโดย:** Database Architecture Team  
**วันที่:** 17 มกราคม 2026  
**เวอร์ชัน:** 1.0
