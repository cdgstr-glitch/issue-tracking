# 🔐 Permission Matrix

## สิทธิ์การเข้าถึงแต่ละเมนู

---

## 📊 ตารางสรุป Permission

| เมนู | Pure Admin | Admin+Tier1 | Tier1 | Tier2 | Tier3 | Staff | Customer |
|------|-----------|------------|-------|-------|-------|-------|----------|
| **Dashboard** | ✅ Read-only | ✅ Read/Write | ✅ R/W | ✅ R/W | ✅ R/W | ❌ | ❌ |
| **เคสทั้งหมด** | ✅ Read-only | ✅ Read/Write | ✅ R/W | ✅ R/W (Limited) | ✅ R/W (Limited) | ❌ | ❌ |
| **งานของฉัน** | ❌ | ✅ Read/Write | ✅ R/W | ✅ R/W | ✅ R/W | ❌ | ✅ R/W |
| **เคสที่ฉันส่งต่อ** | ❌ | ✅ Read-only | ✅ Read-only | ✅ Read-only | ✅ Read-only | ❌ | ❌ |
| **รอดำเนินการ (Action)** | ❌ | ✅ Read/Write | ✅ R/W | ✅ R/W | ✅ R/W | ❌ | ❌ |
| **รอดำเนินการ (Monitor)** | ✅ Read-only | ✅ Both | - | - | - | ❌ | ❌ |
| **แก้ไขแล้ว (Personal)** | ❌ | ✅ Read/Write | ✅ R/W | ✅ R/W | ✅ R/W | ❌ | ❌ |
| **แก้ไขแล้ว (Monitor)** | ✅ Read-only | ✅ Both | - | - | - | ❌ | ❌ |
| **เคสที่ปิดย้อนหลัง** | ✅ Read-only | ✅ Read-only | ✅ Read-only | ❌ | ❌ | ❌ | ❌ |
| **บันทึกเคสแทนลูกค้า** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ Create | ❌ |
| **ติดตามเคส** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ Read-only | ❌ |
| **ดูเคสที่ปิดแล้ว (Staff)** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ Read-only | ❌ |
| **แจ้งเคสใหม่** | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ Create |
| **ติดตามเคสของฉัน** | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ Read/Write |
| **Reports** | ✅ Read/Write | ✅ R/W | ✅ R/W (Limited) | ❌ | ❌ | ❌ | ❌ |
| **Users** | ✅ Read/Write | ✅ R/W | ✅ R/W (Limited) | ❌ | ❌ | ❌ | ❌ |
| **Projects** | ✅ Read/Write | ✅ R/W | ✅ R/W (Limited) | ❌ | ❌ | ❌ | ❌ |
| **Settings** | ✅ Read/Write | ✅ R/W | ✅ R/W (Limited) | ✅ Personal Only | ✅ Personal Only | ❌ | ✅ Personal Only |

---

## 🔍 รายละเอียด Permission แต่ละเมนู

### 1. Dashboard

| Role | Permission | สามารถทำอะไร |
|------|-----------|-------------|
| **Pure Admin** | Read-only | ดูสถิติ, Metrics (ไม่สามารถแก้ไข) |
| **Admin+Tier1** | Read/Write | ดูสถิติ + แก้ไขเคส |
| **Tier1/2/3** | Read/Write | ดูสถิติ + แก้ไขเคส |
| **Staff** | ❌ | ไม่มี Dashboard |
| **Customer** | ❌ | ไม่มี Dashboard |

---

### 2. เคสทั้งหมด

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Pure Admin** | Read-only | เคสทั้งหมด (ทุก status) | ดูอย่างเดียว, ไม่แก้ไข |
| **Admin+Tier1** | Read/Write | เคสทั้งหมด | ดู + แก้ไข + ส่งต่อ + ปิด |
| **Tier1** | Read/Write | เคสทั้งหมด (Inverted Visibility) | ดู + แก้ไข + ส่งต่อ + ปิด |
| **Tier2** | Read/Write | เคส tier2, tier3, in_progress, etc. | ดู + แก้ไข + ส่งต่อ + ปิด |
| **Tier3** | Read/Write | เคส tier3, in_progress, etc. | ดู + แก้ไข + ส่งต่อ + ปิด |
| **Staff** | ❌ | - | - |
| **Customer** | ❌ | - | - |

**Inverted Visibility Model:**
- **Tier1:** เห็น `new`, `tier1`, `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `closed`
- **Tier2:** เห็น `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `closed` (ไม่เห็น `new`, `tier1`)
- **Tier3:** เห็น `tier3`, `in_progress`, `waiting`, `resolved`, `closed` (ไม่เห็น `new`, `tier1`, `tier2`)

---

### 3. งานของฉัน

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Pure Admin** | ❌ | - | ไม่รับเคส → ไม่มีเมนูนี้ |
| **Admin+Tier1** | Read/Write | assigned to me, status: in_progress, waiting, resolved, pending_closure | ดู + แก้ไข + ส่งต่อ + ปิด |
| **Tier1/2/3** | Read/Write | assigned to me, ไม่รวม closed | ดู + แก้ไข + ส่งต่อ + ปิด |
| **Staff** | ❌ | - | ไม่รับเคส → ไม่มีเมนูนี้ |
| **Customer** | Read/Write | เคสที่ตัวเองสร้าง (ทุก status) | ดู + แก้ไข + เพิ่มความคิดเห็น |

**ไม่รวม Status:**
- ❌ `new`, `tier1`, `tier2`, `tier3` (ยังไม่ได้รับเคส)
- ❌ `closed` (ปิดแล้ว → ไปอยู่ "แก้ไขแล้ว")

---

### 4. เคสที่ฉันส่งต่อ

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Pure Admin** | ❌ | - | ไม่รับเคส → ไม่ส่งต่อ → ไม่มีเมนูนี้ |
| **Admin+Tier1** | Read-only | เคสที่ส่งต่อไปคนอื่น | ดูอย่างเดียว, ติดตามสถานะ |
| **Tier1/2/3** | Read-only | เคสที่ส่งต่อไปคนอื่น | ดูอย่างเดียว, ติดตามสถานะ |
| **Staff** | ❌ | - | ไม่ได้อยู่ใน Tier workflow → ไม่มีเมนูนี้ |
| **Customer** | ❌ | - | - |

**ตัวอย่างเคสที่เห็น:**
- Tier1: ส่งต่อไป Tier2, Tier3, Tier1 อื่น
- Tier2: ส่งต่อไป Tier3, Tier1, Tier2 อื่น
- Tier3: ส่งต่อไป Tier2, Tier1, Tier3 อื่น

---

### 5. รอดำเนินการ (Action - มีปุ่ม "รับเคส")

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Tier1** | Read/Write | status: `new`, `tier1` (assignedTo = null หรือ me) | กด "รับเคส" → assigned to me |
| **Tier2** | Read/Write | status: `tier2` (assignedTo = null หรือ me) | กด "รับเคส" → assigned to me |
| **Tier3** | Read/Write | status: `tier3` (assignedTo = null หรือ me) | กด "รับเคส" → assigned to me |

**Flow:**
```
เคส status = 'tier1', assignedTo = null
  ↓ Tier1 กด "รับเคส"
เคส status = 'in_progress', assignedTo = Tier1.id
  ↓ ย้ายไปเมนู "งานของฉัน"
```

---

### 6. รอดำเนินการ (Monitor - Read-only)

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Pure Admin** | Read-only | status: `new`, `tier1`, `tier2`, `tier3` (assignedTo = null) | ดูอย่างเดียว, Monitor bottleneck |

**ไม่มีปุ่ม:** "รับเคส" (เพราะไม่รับเคส)

---

### 7. แก้ไขแล้ว (Personal - ของตัวเอง)

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Tier1/2/3** | Read/Write | resolvedBy = me หรือ closedBy = me | ดู + แก้ไข (บางกรณี) + Re-open |

**Status ที่แสดง:**
- ✅ `resolved` (แก้ไขแล้ว - รอลูกค้าตรวจสอบ)
- ✅ `pending_closure` (รอปิด)
- ✅ `closed` (ปิดแล้ว)

**ทุก Channel:** web, phone, email, line

---

### 8. แก้ไขแล้ว (Monitor All - ของทุกคน)

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Pure Admin** | Read-only | เคสของ **ทุกคน** (Tier1/2/3) | ดูอย่างเดียว, Monitor performance |

**Status ที่แสดง:**
- ✅ `resolved`, `pending_closure`, `closed`

**ทุก Channel:** web, phone, email, line

---

### 9. เคสที่ปิดย้อนหลัง

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Pure Admin** | Read-only | เคสของ **Staff ทุกคน** | ดู + กรองตาม Staff + Monitor performance |
| **Admin+Tier1** | Read-only | เคสของ **Staff ทุกคน** | ดู + กรองตาม Staff |
| **Tier1** | Read-only | เคสของ **Staff ทุกคน** | ดู + กรองตาม Staff |

**Status ที่แสดง:**
- ✅ `closed` เท่านั้น

**Channel ที่แสดง:**
- ✅ `phone`, `email`, `line` (ไม่รวม `web`)

**ฟีเจอร์:**
- แสดงคอลัมน์ "ปิดโดย" (Closed By)
- กรอตาม Staff แต่ละคน
- แบ่งประเภท:
  - "Staff ปิดเอง" (closedBy = Staff.id)
  - "ผ่าน Tier System" (closedBy = Tier1/2/3.id)

---

### 10. บันทึกเคสแทนลูกค้า

| Role | Permission | สามารถทำอะไร |
|------|-----------|-------------|
| **Staff** | Create | สร้างเคส → เลือก \"แก้ไขและปิดเคส\" หรือ \"ส่งงาน\" |

**Channel ที่รองรับ:**
- ✅ `phone`, `email`, `line`

**2 ทางเลือก:**
1. **\"แก้ไขและปิดเคส\"**: status = `closed`, closedBy = Staff.id
2. **\"ส่งงาน\"**: status = `new`, ส่งต่อ Tier1

**ฟีลด์พิเศษที่ Staff มี (เท่านั้น):**

#### ✅ **1. ช่องทางการติดต่อ (Channel Selection)** *
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 212-230)
- **ตัวเลือก:** Line, โทรศัพท์, Email
- **Purpose:** เลือกช่องทางที่ลูกค้าติดต่อเข้ามา
- **Required:** ใช่

#### ✅ **2. Line ID** (Conditional)
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 232-245)
- **แสดงเมื่อ:** เลือก Channel = "Line"
- **Format:** @example หรือ user123
- **Required:** ใช่ (ถ้าเลือก Line)

#### ✅ **3. ประเภทปัญหา (Issue Type)** *
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 290-309)
- **ตัวเลือก:** 
  - `incident` - Incident
  - `service_request` - Service Request
  - `security_incident` - 🔒 Security Incident
- **Required:** ใช่

#### ✅ **4. ความสำคัญ (Priority)** *
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 311-324)
- **ตัวเลือก:**
  - `low` - น้อย - รอได้
  - `medium` - ปานกลาง - ความสำคัญปกติ
  - `high` - สูง - ส่งผลกระทบต่อการทำงาน
  - `critical` - วิกฤติ - ระบบหยุดการทำงาน
- **Required:** ใช่

#### ✅ **5. วันที่เกิดเหตุ (Incident Date)** - บันทึกย้อนหลัง
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 354-368)
- **Type:** `datetime-local`
- **Default:** วันเวลาปัจจุบัน (Auto-fill)
- **Purpose:** บันทึกเคสย้อนหลังเพื่อเก็บประวัติ
- **Required:** ไม่ (ถ้าไม่ระบุจะใช้วันเวลาปัจจุบัน)

#### ✅ **6. Security Incident Warning**
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 327-350)
- **แสดงเมื่อ:** เลือก Issue Type = "Security Incident"
- **ฟีเจอร์:**
  - แสดงคำเตือนสีแดง
  - แจ้งว่าจะส่งต่อทีมความปลอดภัยทันที
  - แสดงตัวอย่างเคส Security Incident

**UI Flow สำหรับ Staff:**

```
┌─────────────────────────────────────────────────────────────┐
│  บันทึกเคสแทนลูกค้า - CreateTicketPage                      │
├─────────────────────────────────────────────────────────────┤
│  📋 ข้อมูลลูกค้า (Customer Info)                            │
│  • ชื่อ-นามสกุล                                             │
│  • อีเมล                                                    │
│  • เบอร์โทรศัพท์                                            │
│  • หน่วยงาน/สังกัด                                          │
│                                                             │
│  📞 ช่องทางการติดต่อ * (Staff only)                         │
│  [เลือกช่องทาง: Line / โทรศัพท์ / Email ▼]                 │
│                                                             │
│  💬 Line ID * (แสดงเฉพาะถ้าเลือก Line)                      │
│  [@example หรือ user123]                                    │
│                                                             │
│  📋 รายละเอียดปัญหา                                         │
│  • หมวดหมู่ *                                               │
│  • ผลิตภัณฑ์ที่ใช้งาน *                                     │
│                                                             │
│  🏷️ ประเภทปัญหา * (Staff only)                             │
│  [Incident / Service Request / 🔒 Security Incident ▼]     │
│                                                             │
│  ⚠️ ความสำคัญ * (Staff only)                                │
│  [น้อย / ปานกลาง / สูง / วิกฤติ ▼]                         │
│                                                             │
│  📅 วันที่เกิดเหตุ (Staff only - backdate)                  │
│  [📅 26/12/2025  ⏰ 14:30]                                 │
│  💡 ระบุวันที่และเวลาที่เกิดปัญหาจริง                       │
│                                                             │
│  📝 หัวข้อปัญหา *                                           │
│  [คำอธิบายสั้นๆ เกี่ยวกับปัญหา]                             │
│                                                             │
│  📄 รายละเอียดแบบละเอียด *                                  │
│  [Rich Text Editor...]                                      │
│                                                             │
│  🏷️ แฮชแท็ก                                                 │
│  📎 แนบไฟล์                                                 │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [ยกเลิก]  [✅ แก้ไขและปิดเคส]  [ส่งงาน]                  │
└─────────────────────────────────────────────────────────────┘
```

**Modal: "แก้ไขและปิดเคส"**
- **ไฟล์:** `/components/CreateTicketPage.tsx` (บรรทัด 980-1086)
- **Function:** `handleSolveAndClose()` (บรรทัด 60-63)
- **เมื่อกด:** แสดง Modal กรอกข้อมูลการปิดเคส

```
┌───────────────────────────────────────────────────────┐
│  แก้ไขและปิดเคส                                       │
├───────────────────────────────────────────────────────┤
│  ℹ️ การแก้ไขและปิดเคสทันที                            │
│  ใช้สำหรับเคสที่แก้ไขเล็กน้อยได้ทันที เช่น           │
│  • Reset Password                                     │
│  • การแนะนำวิธีใช้งาน                                 │
│  • แก้ไข Configuration ง่ายๆ                          │
│                                                       │
│  เคสจะถูกปิดทันที และจะไม่ส่งต่อไปยัง Tier 1         │
│                                                       │
│  📝 วิธีแก้ไข / Solution *                            │
│  [Rich Text Editor]                                   │
│  💡 ระบุรายละเอียดวิธีแก้ไขให้ชัดเจน                 │
│                                                       │
│  📝 หมายเหตุการปิดเคส                                │
│  [หมายเหตุเพิ่มเติม (ถ้ามี)]                          │
│  เช่น ลูกค้าพอใจ, ทดสอบแล้วใช้งานได้, ฯลฯ            │
│                                                       │
│  ✅ ข้อมูลการปิดเคส:                                 │
│  • ปิดเคสโดย: [ชื่อ Staff]                           │
│  • วันที่ปิดเคส: [วันที่ปัจจุบัน]                    │
│  • สถานะ: ✅ ปิดเคส (Closed)                         │
│                                                       │
├───────────────────────────────────────────────────────┤
│  [ยกเลิก]  [บันทึกและปิดเคส]                         │
└───────────────────────────────────────────────────────┘
```

**การทำงานของปุ่ม:**

| ปุ่ม | Function | Status | closedBy | ส่งต่อ? |
|------|----------|--------|----------|---------|
| **✅ แก้ไขและปิดเคส** | `handleSolveAndClose()` | `closed` | `Staff.id` | ❌ ไม่ส่ง |
| **ส่งงาน** | `handleSubmit()` | `new` | `null` | ✅ ส่ง Tier1 |

**Use Cases:**
- ✅ **แก้ไขและปิดเคส**: Reset Password, แนะนำการใช้งาน, Configuration ง่ายๆ
- ✅ **ส่งงาน**: ปัญหาซับซ้อน ต้องการ Tier1/2/3 แก้ไข
- ✅ **บันทึกย้อนหลัง**: เคสจากโทรศัพท์ที่แก้ไขไปแล้ว เก็บเป็นประวัติ

**Code Reference:**
```typescript
// State สำหรับ Staff features
const [selectedChannel, setSelectedChannel] = useState('');
const [selectedType, setSelectedType] = useState('');
const [incidentDate, setIncidentDate] = useState('');
const [solution, setSolution] = useState('');
const [closureNotes, setClosureNotes] = useState('');
const [showCloseTicketModal, setShowCloseTicketModal] = useState(false);

// Auto-fill incident date (บรรทัด 40-51)
useEffect(() => {
  if (hasRole(user, 'staff')) {
    const now = new Date();
    setIncidentDate(`${year}-${month}-${day}T${hours}:${minutes}`);
  }
}, [user]);

// Function แก้ไขและปิดเคส (บรรทัด 60-63)
const handleSolveAndClose = (e: React.FormEvent) => {
  e.preventDefault();
  setShowCloseTicketModal(true);
};

// Confirm close (บรรทัด 65-70)
const handleConfirmClose = () => {
  const newTicketNumber = `CDGS-2024-${...}`;
  setTicketNumber(newTicketNumber);
  setShowCloseTicketModal(false);
  setSubmitted(true);
};
```

---

### 11. ติดตามเคสลูกค้าทั้งหมด (Staff)

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Staff** | Read-only | เคสที่ตัวเองสร้าง, ไม่รวม `closed` | ดูอย่างเดียว, ติดตามสถานะ |

**Status ที่แสดง:**
- ✅ `new`, `in_progress`, `waiting`, `resolved`, `pending_closure`
- ❌ `closed` (ไปอยู่ "เคสที่ปิดย้อนหลัง")

---

### 12. เคสที่ปิดย้อนหลัง (Staff)

| Role | Permission | เห็นเคสอะไร | สามารถทำอะไร |
|------|-----------|----------|-------------|
| **Staff** | Read-only | เคสที่ตัวเองสร้าง, status = `closed` | ดูอย่างเดียว, ดูประวัติ |

**Status ที่แสดง:**
- ✅ `closed` เท่านั้น

**Channel:**
- ✅ `phone`, `email`, `line`

**แสดง 2 ประเภท:**
1. Staff ปิดเอง (closedBy = Staff.id)
2. Tier1 ปิดให้ (closedBy = Tier1.id)

---

### 13. Reports / Users / Projects / Settings

| Role | Permission | สามารถทำอะไร |
|------|-----------|-------------|
| **Pure Admin** | Read/Write | ดู + แก้ไข + สร้าง + ลบ (Full access) |
| **Admin+Tier1** | Read/Write | ดู + แก้ไข + สร้าง + ลบ (Full access) |
| **Tier1** | Read/Write (Limited) | ดู + แก้ไขบางส่วน (ตามสิทธิ์ที่ได้รับ) |
| **Tier2/3** | ❌ | ไม่มีสิทธิ์ |
| **Staff** | ❌ | ไม่มีสิทธิ์ |
| **Customer** | ❌ | ไม่มีสิทธิ์ |

---

### 13A. Settings (การตั้งค่า) - รายละเอียด

**Settings แบ่งเป็น 2 ระดับ:**

#### **📱 Personal Settings (การตั้งค่าส่วนตัว) - ทุก Tier เห็น**

| Role | Permission | สามารถทำอะไร |
|------|-----------|-------------|
| **Pure Admin** | Read/Write | แก้ไขการตั้งค่าส่วนตัวของตัวเอง |
| **Admin+Tier1** | Read/Write | แก้ไขการตั้งค่าส่วนตัวของตัวเอง |
| **Tier1** | Read/Write | แก้ไขการตั้งค่าส่วนตัวของตัวเอง |
| **Tier2** | Read/Write | แก้ไขการตั้งค่าส่วนตัวของตัวเอง |
| **Tier3** | Read/Write | แก้ไขการตั้งค่าส่วนตัวของตัวเอง |

**ฟีเจอร์ใน Personal Settings:**
- 👤 **โปรไฟล์ (Profile)**
  - ชื่อ-นามสกุล
  - อีเมล
  - เบอร์โทร
  - รูปโปรไฟล์
- 🔔 **การแจ้งเตือน (Notifications)**
  - แจ้งเตือนแคสใหม่
  - แจ้งเตือน SLA
  - แจ้งเตือนทางอีเมล
  - แจ้งเตือนทางบราวเซอร์
- 🌍 **ภาษาและหน่วย (Locale)**
  - ภาษา (ไทย/อังกฤษ)
  - เขตเวลา (Asia/Bangkok)
  - รูปแบบวันที่
- 🎨 **ธีม (Theme)**
  - สว่าง (Light)
  - มืด (Dark)
  - อัตโนมัติ (Auto)

---

#### **⚙️ Advanced Settings (การตั้งค่าขั้นสูง) - Admin only 🔒**

| Role | Permission | สามารถทำอะไร |
|------|-----------|-------------|
| **Pure Admin** | Read/Write | ดู + แก้ไข + สร้าง + ลบ (Full access) |
| **Admin+Tier1** | Read/Write | ดู + แก้ไข + สร้าง + ลบ (Full access) |
| **Tier1** | Read/Write (Limited) | ดู + แก้ไขบางส่วน (ตามสิทธิ์ที่ได้รับ) |
| **Tier2/3** | ❌ Hidden | ไม่เห็น Section นี้ |

**ฟีเจอร์ใน Advanced Settings:**
- 👥 **จัดการผู้ใช้ (Users)**
  - เพิ่ม/ลบผู้ใช้
  - กำหนด Role
  - จัดการ Permission
- 📁 **จัดการโครงการ (Projects)**
  - สร้างโครงการใหม่
  - กำหนด SLA
  - จัดการทีม
- 📊 **รายงาน (Reports)**
  - ตั้งค่า Dashboard
  - กำหนด Metrics
  - Export Settings
- ⚙️ **ตั้งค่าระบบ (System)**
  - Email Server
  - Webhook
  - Integration
- 🔐 **ความปลอดภัย (Security)**
  - Password Policy
  - Session Timeout
  - 2FA Settings

---

**UI/UX ของหน้า Settings:**

**สำหรับ Tier2/3 (เห็นแค่ Personal):**
```
┌─────────────────────────────────────┐
│  การตั้งค่า                          │
├─────────────────────────────────────┤
│  📱 การตั้งค่าส่วนตัว               │
│  ├── 👤 โปรไฟล์                     │
│  ├── 🔔 การแจ้งเตือน                 │
│  ├── 🌍 ภาษาและหน่วย                │
│  └── 🎨 ธีม                         │
└─────────────────────────────────────┘
```

**สำหรับ Admin (เห็นทั้ง Personal + Advanced):**
```
┌─────────────────────────────────────┐
│  การตั้งค่า                          │
├─────────────────────────────────────┤
│  📱 การตั้งค่าส่วนตัว               │
│  ├── 👤 โปรไฟล์                     │
│  ├── 🔔 การแจ้งเตือน                 │
│  ├── 🌍 ภาษาและหน่วย                │
│  └── 🎨 ธีม                         │
│                                     │
│  ──────────────────────────────     │
│                                     │
│  ⚙️ การตั้งค่าขั้นสูง (Admin only) │
│  ├── 👥 จัดการผู้ใช้                │
│  ├── 📁 จัดการโครงการ               │
│  ├── 📊 รายงาน                      │
│  ├── ⚙️ ตั้งค่าระบบ                 │
│  └── 🔐 ความปลอดภัย                 │
└─────────────────────────────────────┘
```

---

## 🔍 สรุป Permission แต่ละ Role

### Pure Admin
- **จุดเด่น:** Monitor ทุกอย่าง (Read-only)
- **ข้อจำกัด:** แก้ไขเคสไม่ได้, ไม่รับเคส, ไม่ส่งต่อ
- **Use Case:** ผู้บริหารที่ต้องการดูภาพรวม ไม่ทำงานจริง

### Admin + Tier1
- **จุดเด่น:** ทำได้ทุกอย่าง (Monitor + Work)
- **ข้อจำกัด:** ไม่มี
- **Use Case:** Team Lead ที่ทั้ง Monitor และทำงานจริง

### Tier1
- **จุดเด่น:** เห็นเคสมากสุด, รับเคสใหม่ทั้งหมด
- **ข้อจำกัด:** ไม่มี Admin features (ถ้าไม่มี role admin)
- **Use Case:** Front-line support

### Tier2
- **จุดเด่น:** รับเคสที่ซับซ้อนกว่า
- **ข้อจำกัด:** เห็นเคสน้อยกว่า Tier1 (Inverted Visibility)
- **Use Case:** Specialist support

### Tier3
- **จุดเด่น:** Expert level
- **ข้อจำกัด:** เห็นเคสน้อยสุด
- **Use Case:** Expert support

### Staff
- **จุดเด่น:** บันทึกเคสแทนลูกค้า, ปิดเคสได้ทันที
- **ข้อจำกัด:** ไม่รับเคสจากระบบ, Read-only tracking
- **Use Case:** Call center, Email support

### Customer
- **จุดเด่น:** แจ้งเคสใหม่ผ่าน Web App, ติดตามเคสของตัวเอง, เพิ่มความคิดเห็น
- **ข้อจำกัด:** เห็นแค่เคสของตัวเอง, ไม่สามารถปิดเคสได้, ไม่มี Dashboard
- **Use Case:** End user (ลูกค้าภายนอก/ภายใน)

**ฟีเจอร์ที่ Customer สามารถใช้ได้:**
1. ✅ **แจ้งเคสใหม่** (`/create`) - สร้างเคสผ่าน Web App
   - กรอกข้อมูลปัญหา: หัวเรื่อง, รายละเอียด, หมวดหมู่, ผลิตภัณฑ์
   - แนบไฟล์ประกอบ (รูปภาพ, เอกสาร)
   - เพิ่มป้ายกำกับ (Tags/Hashtags)
   - ระบุข้อมูลติดต่อ: ชื่อ, อีเมล, โทรศัพท์, หน่วยงาน
   - ❌ **ไม่สามารถเลือกโครงการได้** - Customer แจ้งเคสแบบทั่วไป ระบบจะจัดการเอง

2. ✅ **ติดตามเคส** (`/track`) - ดูสถานะเคสทั้งหมดที่ตัวเองสร้าง
   - เห็นเคสทุกสถานะ: `new`, `tier1`, `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `closed`
   - ค้นหาเคสด้วย: หมายเลขเคส, หัวเรื่อง, สถานะ
   - กรองตามโครงการ

3. ✅ **ดูรายละเอียดเคส** (`/track-ticket-detail/:id`)
   - ดูข้อมูลเคสแบบละเอียด
   - ติดตามความคืบหน้า (Timeline)
   - อ่านและเพิ่มความคิดเห็น (Comments) **พร้อมแนบไฟล์** 📎
   - แนบไฟล์ประกอบเมื่อตอบกลับ (รองรับหลายไฟล์)
   - ยืนยันการแก้ไขปัญหา (แต่ไม่สามารถปิดเคสเอง)

4. ✅ **FAQ** (`/faq`) - ดูคำถามที่พบบ่อย
   - ค้นหาคำตอบ
   - กรองตามหมวดหมู่
   - แสดง 12+ คำถามที่พบบ่อย

5. ✅ **Notifications** (`/admin/notifications`) - ดูการแจ้งเตือน
   - รับแจ้งเตือนเมื่อเคสมีการอัพเดท
   - แจ้งเตือนเมื่อเจ้าหน้าที่ตอบกลับ
   - แจ้งเตือนเมื่อเคสถูกส่งต่อหรือปิด

**Channel ที่ Customer ใช้:**
- ✅ `web` (Web App) เท่านั้น

**สิทธิ์ที่ Customer ไม่มี:**
- ❌ ไม่มี Dashboard
- ❌ ไม่มี Sidebar
- ❌ ไม่สามารถปิดเคสเอง (เฉพาะ Tier1 ปิดได้)
- ❌ ไม่เห็นเคสของคนอื่น
- ❌ ไม่สามารถรับเคสหรือส่งต่อเคส
- ❌ ไม่เข้าถึง Reports, Settings, Team Management

**UI/UX สำหรับ Customer:**
- Header แบบเรียบง่าย (ไม่มี Sidebar)
- ชื่อระบบแสดง: "Application Support Center"
- ใช้ Customer-friendly labels (สถานะ, ความสำคัญ)
- Landing Page สไตล์ Marketing พร้อม CTA ชัดเจน

---

## 🔒 Security Rules

### 1. **Row-Level Security (RLS)**
- Customer เห็นเฉพาะเคสของตัวเอง
- Staff เห็นเฉพาะเคสที่ตัวเองสร้าง
- Tier1/2/3 เห็นตาม Inverted Visibility Model
- Admin เห็นทุกอย่าง

### 2. **Action Permissions**
```typescript
// ตัวอย่าง Permission Check
canAcceptCase(user, ticket) {
  // Pure Admin ไม่สามารถรับเคส
  if (user.roles.includes('admin') && !hasTierRole(user)) {
    return false;
  }
  
  // Tier1 รับได้แค่ status = new, tier1
  if (user.roles.includes('tier1')) {
    return ['new', 'tier1'].includes(ticket.status);
  }
  
  // Tier2 รับได้แค่ status = tier2
  if (user.roles.includes('tier2')) {
    return ticket.status === 'tier2';
  }
  
  // Tier3 รับได้แค่ status = tier3
  if (user.roles.includes('tier3')) {
    return ticket.status === 'tier3';
  }
  
  return false;
}

canEditTicket(user, ticket) {
  // Pure Admin ไม่สามารถแก้ไข
  if (user.roles.includes('admin') && !hasTierRole(user)) {
    return false;
  }
  
  // Staff แก้ไขไม่ได้ (Read-only)
  if (user.roles.includes('staff')) {
    return false;
  }
  
  // Tier1/2/3 แก้ไขได้เฉพาะเคสที่ assigned ให้ตัวเอง
  if (hasTierRole(user)) {
    return ticket.assignedTo === user.id;
  }
  
  // Customer แก้ไขได้เฉพาะเคสของตัวเอง
  if (user.roles.includes('customer')) {
    return ticket.createdBy === user.id;
  }
  
  return false;
}

canCloseTicket(user, ticket) {
  // Staff ปิดได้เฉพาะเคสที่ตัวเองสร้าง + เลือก "แก้ไขและปิดเคส"
  if (user.roles.includes('staff')) {
    return ticket.createdBy === user.id && ticket.status === 'new';
  }
  
  // Tier1/2/3 ปิดได้เฉพาะเคสที่ assigned ให้ตัวเอง
  if (hasTierRole(user)) {
    return ticket.assignedTo === user.id;
  }
  
  return false;
}
```

### 3. **Inverted Visibility Implementation**
```typescript
function getVisibleTickets(user) {
  if (user.roles.includes('admin') && !hasTierRole(user)) {
    // Pure Admin เห็นทุกอย่าง
    return getAllTickets();
  }
  
  if (user.roles.includes('tier1')) {
    // Tier1 เห็นมากสุด
    return getTickets({
      status: ['new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed']
    });
  }
  
  if (user.roles.includes('tier2')) {
    // Tier2 เห็นน้อยกว่า
    return getTickets({
      status: ['tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed']
    });
  }
  
  if (user.roles.includes('tier3')) {
    // Tier3 เห็นน้อยสุด
    return getTickets({
      status: ['tier3', 'in_progress', 'waiting', 'resolved', 'closed']
    });
  }
  
  if (user.roles.includes('staff')) {
    // Staff เห็นเฉพาะที่ตัวเองสร้าง
    return getTickets({
      createdBy: user.id
    });
  }
  
  if (user.roles.includes('customer')) {
    // Customer เห็นเฉพาะตัวเอง
    return getTickets({
      createdBy: user.id
    });
  }
  
  return [];
}
```

---

**อ่านเอกสารอื่น:**
- [Project Overview](/docs/features/PROJECT_OVERVIEW.md)
- [Navigation Menu](/docs/features/NAVIGATION_MENU.md)
- [Workflow](/docs/features/WORKFLOW.md)
