# 📋 รายการสิ่งที่ต้องปรับปรุง - CDGS Issue Tracking Platform

## ✅ สิ่งที่ทำเสร็จแล้ว (ตรงกับเอกสาร .md)

### 1. **เมนู "ทีม" (Team Management)**
- ✅ Tier2/3 มีเมนู "ทีม" แล้ว
- ✅ Permission แบบ Layered:
  - Admin (Pure/Admin+Tier) = **Read/Write**
  - Tier1/2/3 (Pure) = **Read-only**
- ✅ มี Read-only Banner (กล่องสีเหลือง 🔒)

### 2. **Navigation Menu (Sidebar.tsx)**
- ✅ Tier1 มี "เคสที่ปิดย้อนหลัง"
- ✅ Tier2/3 **ไม่มี** "เคสที่ปิดย้อนหลัง" (ถูกต้อง)
- ✅ ทุก Tier มีเมนู "ทีม"

### 3. **Status Lifecycle**
- ✅ มี Status ครบ: `new`, `tier1`, `tier2`, `tier3`, `in_progress`, `waiting`, `pending_closure`, `resolved`, `closed`
- ✅ ตรงตามเอกสาร WORKFLOW.md

### 4. **Multi-Role Support**
- ✅ ระบบรองรับ `roles: ['admin', 'tier1', 'staff']`
- ✅ มี `primaryRole`
- ✅ ตรงตาม `/lib/mock-users.ts`

---

## ⚠️ สิ่งที่ต้องปรับปรุง (ไม่ตรงกับเอกสาร .md)

### 1. **🔴 Pure Admin Dashboard - ไม่มี Read-only Mode**

**ปัญหา:**
- Pure Admin ควรเป็น **Read-only** (Monitor เท่านั้น)
- ไม่ควรมีปุ่ม "แก้ไข", "ส่งต่อ", "ปิดเคส"

**ตามเอกสาร:**
- `/docs/PERMISSION_MATRIX.md`: Pure Admin = Read-only
- `/docs/PROJECT_OVERVIEW.md`: "Pure Admin: แก้ไขเคสไม่ได้, Monitor อย่างเดียว"

**แก้ไข:**
- AdminDashboard.tsx → ซ่อนปุ่ม Action สำหรับ Pure Admin
- AllTicketsPage.tsx → Read-only mode
- PendingTicketsPage.tsx → แสดง "Monitor" เท่านั้น (ไม่มีปุ่ม "รับเคส")

---

### 2. **🔴 Tier2/3 มีเมนู "การตั้งค่า" (Settings)**

**ปัญหา:**
- Tier2/3 ไม่ควรมีเมนู "การตั้งค่า"

**ตามเอกสาร:**
- `/docs/NAVIGATION_MENU.md`: เฉพาะ Pure Admin + Admin+Tier1 เท่านั้น
- `/docs/PERMISSION_MATRIX.md`: Tier2/3 = ❌

**แก้ไข:**
- `Sidebar.tsx` → ลบเมนู "การตั้งค่า" ออกจาก Tier2/3

---

### 3. **🔴 Tier2/3 มีเมนู "การวิเคราะห์" (Analytics)**

**ปัญหา:**
- เอกสารไม่ได้ระบุชัดเจนว่า Tier2/3 ควรมี Analytics หรือไม่

**ข้อเสนอแนะ:**
- **Option A:** ลบออก (เฉพาะ Admin + Tier1)
- **Option B:** เก็บไว้ แต่จำกัดข้อมูลที่แสดง (เห็นแค่ของตัวเอง)

**แนะนำ:** Option B - เพราะ Tier2/3 ควรเห็น Performance ของตัวเอง

---

### 4. **🟡 Staff Landing Page - ยังไม่มีหน้าจริง**

**ปัญหา:**
- Staff ควรมี **Landing Page** (3 ปุ่มหลัก)
- ปัจจุบันยังแสดงใน HomePage.tsx (ไม่ใช่ Landing Page แบบเต็มรูปแบบ)

**ตามเอกสาร:**
- `/docs/NAVIGATION_MENU.md`: Staff มี Landing Page (ไม่มี Sidebar)
- `/docs/PROJECT_OVERVIEW.md`: "UI: Landing Page (ไม่มี Sidebar)"

**แก้ไข:**
- สร้าง `StaffLandingPage.tsx` แยกต่างหาก
- มี 3 ปุ่มหลัก:
  1. ➕ บันทึกเคสแทนลูกค้า
  2. 🔍 ติดตามเคสลูกค้าทั้งหมด
  3. ✅ ดูเคสที่ปิดแล้ว
- **ไม่มี Sidebar**

---

### 5. **🟡 "บันทึกเคสแทนลูกค้า" - ยังไม่มี 2 ทางเลือก**

**ปัญหา:**
- Staff สร้างเคสควรมี **2 ทางเลือก:**
  1. ✅ "แก้ไขและปิดเคส" (ปิดทันที, status = `closed`)
  2. 📤 "ส่งงาน" (ส่งต่อ Tier1, status = `new`)

**ตามเอกสาร:**
- `/docs/WORKFLOW.md`: Staff Workflow แบ่ง 2 กรณี
- `/docs/PERMISSION_MATRIX.md`: "Staff: สร้างเคส → เลือก..."

**แก้ไข:**
- `CreateStaffTicketPage.tsx` → เพิ่มปุ่ม 2 ปุ่ม
- **ปุ่มเขียว:** "แก้ไขและปิดเคส" → status = `closed`
- **ปุ่มดำ:** "ส่งงาน" → status = `new`

---

### 6. **🟡 Inverted Visibility Model - ยังไม่ Implement**

**ปัญหา:**
- Tier2/3 ยังเห็นเคส `new`, `tier1` อยู่ (ไม่ตรงตาม Inverted Visibility)

**ตามเอกสาร:**
- `/docs/PERMISSION_MATRIX.md`: 
  - Tier1 เห็น: `new`, `tier1`, `tier2`, `tier3`, `in_progress`, ...
  - Tier2 เห็น: `tier2`, `tier3`, `in_progress`, ... (ไม่เห็น `new`, `tier1`)
  - Tier3 เห็น: `tier3`, `in_progress`, ... (ไม่เห็น `new`, `tier1`, `tier2`)

**แก้ไข:**
- `AllTicketsPage.tsx` → Filter ตาม role:
  ```typescript
  const getVisibleStatuses = (role: UserRole) => {
    if (role === 'tier1') return ['new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed'];
    if (role === 'tier2') return ['tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed'];
    if (role === 'tier3') return ['tier3', 'in_progress', 'waiting', 'resolved', 'closed'];
    return []; // admin เห็นทั้งหมด
  }
  ```

---

### 7. **🟡 Escalation Flow - ยังไม่เห็น UI การส่งต่อแบบ Symmetric**

**ปัญหา:**
- ไม่แน่ใจว่ามี UI สำหรับส่งต่อไปทุกทิศทางหรือไม่

**ตามเอกสาร:**
- `/docs/PROJECT_OVERVIEW.md`: "Symmetric Escalation - ส่งต่อได้ทุกทิศทาง"
- Tier1 → Tier2, Tier3, Tier1 อื่น
- Tier2 → Tier3, Tier1 (ส่งกลับ), Tier2 อื่น
- Tier3 → Tier2 (ส่งกลับ), Tier1 (ส่งกลับ), Tier3 อื่น

**ต้องตรวจสอบ:**
- `TicketDetailPage.tsx` → ปุ่ม "ส่งต่อ" มีตัวเลือกครบหรือไม่

---

### 8. **🟢 ปุ่ม "หยุดชั่วคราว" - น่าจะมีแล้ว แต่ต้องตรวจสอบ**

**ต้องมี:**
- ปุ่ม "หยุดชั่วคราว" → เปลี่ยน status เป็น `waiting`
- ปุ่ม "ดำเนินการต่อ" → เปลี่ยนกลับเป็น `in_progress`

**ตามเอกสาร:**
- `/docs/PROJECT_OVERVIEW.md`: "Pause Feature - มีปุ่ม หยุดชั่วคราว"

---

### 9. **🟢 Reports/Users/Projects/Settings - Permission ต้องตรวจสอบ**

**ตามเอกสาร:**
- Pure Admin: **Full Access**
- Admin+Tier1: **Full Access**
- Tier1 (Pure): **Limited Access** (บางส่วน)
- Tier2/3: **ไม่มีสิทธิ์**

**ต้องตรวจสอบ:**
- Tier1 (Pure) มีสิทธิ์อะไรบ้าง?
- ต้องแยก Permission ใน Component

---

### 10. **🟡 "เคสที่ฉันส่งต่อ" - ยังไม่แน่ใจว่ามี**

**ตามเอกสาร:**
- `/docs/NAVIGATION_MENU.md`: มีเมนู "เคสที่ฉันส่งต่อ" สำหรับ Tier1/2/3
- Permission: **Read-only**
- แสดง: เคสที่ตัวเองเคยรับ → แล้วส่งต่อไปคนอื่น

**ต้องตรวจสอบ:**
- Sidebar.tsx → มีเมนูนี้แล้ว (บรรทัด 48, 64, 79)
- ต้องมี `EscalatedTicketsPage.tsx`

---

## 📊 สรุป Priority

| Priority | จำนวน | รายการ |
|----------|-------|--------|
| **🔴 สูง (ต้องแก้ด่วน)** | 2 | 1. Pure Admin Read-only Mode<br>2. Tier2/3 ลบเมนู "การตั้งค่า" |
| **🟡 กลาง (ควรแก้)** | 5 | 3. Staff Landing Page<br>4. "บันทึกเคสแทนลูกค้า" 2 ทางเลือก<br>5. Inverted Visibility Model<br>6. Escalation Flow (Symmetric)<br>9. Reports/Users Permission |
| **🟢 ต่ำ (ตรวจสอบ)** | 3 | 7. ปุ่ม "หยุดชั่วคราว"<br>8. Tier2/3 Analytics<br>10. "เคสที่ฉันส่งต่อ" |

---

## 🎯 แนะนำลำดับการแก้ไข

### **Phase 1: ปรับ Permission (สำคัญที่สุด)**
1. ✅ Pure Admin Read-only Mode
2. ✅ Tier2/3 ลบเมนู "การตั้งค่า"
3. ✅ Inverted Visibility Model

### **Phase 2: Staff Workflow**
4. ✅ Staff Landing Page
5. ✅ "บันทึกเคสแทนลูกค้า" 2 ทางเลือก

### **Phase 3: Escalation & Features**
6. ✅ Escalation Flow (Symmetric)
7. ✅ ปุ่ม "หยุดชั่วคราว"
8. ✅ Reports/Users Permission

### **Phase 4: Optional**
9. ✅ Tier2/3 Analytics (ตัดสินใจว่าจะเก็บหรือลบ)
10. ✅ ตรวจสอบ "เคสที่ฉันส่งต่อ"

---

## 💬 คำถามที่ต้องตอบก่อนเริ่มแก้

### 1. **Tier1 (Pure) ควรมีสิทธิ์ใน Reports/Users/Settings แค่ไหน?**
- **Option A:** Read-only ทุกอย่าง
- **Option B:** แก้ไขได้เฉพาะข้อมูลตัวเอง
- **Option C:** ไม่มีสิทธิ์เลย (เหมือน Tier2/3)

### 2. **Tier2/3 ควรมี Analytics หรือไม่?**
- **Option A:** มี (แต่เห็นแค่ของตัวเอง)
- **Option B:** ไม่มี (เฉพาะ Admin + Tier1)

### 3. **Pure Admin Dashboard ควรแสดงอะไร?**
- **Option A:** แดชบอร์ดเดียวกับ Admin+Tier1 แต่ไม่มีปุ่ม Action
- **Option B:** แดชบอร์ดแยก (Monitor Dashboard) ที่ไม่มี Action Cards เลย

---

**📅 สร้างเมื่อ:** 2024-12-25  
**📝 สร้างโดย:** วิเคราะห์จากเอกสาร .md ทั้ง 5 ไฟล์

---

**อ่านเอกสารอื่น:**
- [Navigation Menu](/docs/features/NAVIGATION_MENU.md)
- [Permission Matrix](/docs/technical/PERMISSION_MATRIX.md)
- [Project Overview](/docs/features/PROJECT_OVERVIEW.md)
- [Workflow](/docs/features/WORKFLOW.md)
- [Team Members](/docs/TEAM_MEMBERS.md)
