# 🛡️ วิธีป้องกันการใช้ `.name` แทน `.fullName` (TypeScript Best Practices)

**วันที่สร้าง:** 17 มกราคม 2026  
**วันที่อัพเดทล่าสุด:** 17 มกราคม 2026 (เพิ่ม Checklist ไฟล์ที่ต้องเปลี่ยน)  
**ปัญหา:** Developer ใช้ `user.name` แทน `user.fullName` โดยไม่รู้ตัว → แสดง `undefined`  
**ผลกระทบ:** UX แย่ (แสดง "มอบหมายให้ undefined"), Bug ที่หาได้ยาก

---

## 📋 **สารบัญ**

1. [ทำไมเกิดปัญหานี้](#ทำไมเกิดปัญหานี้)
2. [วิธีแก้ปัญหาถาวร 4 วิธี](#วิธีแก้ปัญหาถาวร)
3. [ตัวอย่างการใช้งาน](#ตัวอย่างการใช้งาน)
4. [Migration Guide](#migration-guide)
5. [📝 Checklist: ไฟล์ที่ใช้ `.fullName` (ต้องตรวจสอบทุกครั้งเมื่อพัฒนา)](#checklist-fullname) ⭐ **ใหม่!**

---

<a name="ทำไมเกิดปัญหานี้"></a>
## ⚠️ **ทำไมเกิดปัญหานี้?**

### **ปัญหาหลัก:**
TypeScript ใช้ **Structural Typing** (Duck Typing) ไม่ใช่ Nominal Typing

```typescript
// ❌ TypeScript ไม่ error แม้ว่า User interface ไม่มี property 'name'
interface User {
  id: string;
  fullName: string;
  email: string;
}

const user = getUserById('user-006');
console.log(user.name); // ❌ TypeScript ไม่ error! (แต่ได้ undefined)
console.log(user.fullName); // ✅ Works
```

**เหตุผล:**
- TypeScript compiler ไม่รู้ว่า `user` มาจาก `User` interface
- มองว่า `user` เป็น object ทั่วไป → อาจมี property อะไรก็ได้
- ไม่มี **Runtime Type Checking** → จะรู้ว่าผิดตอน Runtime เท่านั้น

---

### **ตัวอย่างที่เกิดปัญหาจริง:**

**ไฟล์:** `/components/TicketStatusAlert.tsx`
```typescript
// ❌ Before (ผิด)
const assignee = ticket.assignedTo ? getUserById(ticket.assignedTo) : null;
{assignee && assignee.id !== currentUserId && ` • มอบหมายให้ ${assignee.name}`}
//                                                                    ^^^^^ undefined!

// ✅ After (ถูก)
{assignee && assignee.id !== currentUserId && ` • มอบหมายให้ ${assignee.fullName}`}
//                                                                    ^^^^^^^^ Works!
```

**ผลลัพธ์:**
```
❌ Before: "มอบหมายให้ undefined"
✅ After:  "มอบหมายให้ ยุทธนา คณามิ่งมงคล"
```

---

<a name="วิธีแก้ปัญหาถาวร"></a>
## 🛡️ **วิธีแก้ปัญหาถาวร (4 วิธี)**

---

## **วิธีที่ 1: TypeScript `never` Type (แนะนำที่สุด! ⭐)**

### **ทำอย่างไร:**
เพิ่ม `name?: never` ใน User interface

**แก้ไข:** `/contexts/AuthContext.tsx`
```typescript
export interface User {
  id: string;
  username: string;
  fullName: string; // ✅ ใช้ตัวนี้
  
  // ❌ บังคับให้ compiler error ถ้าเรียกใช้ .name
  name?: never; // 🚀 TypeScript จะ error ทันที!
  
  role: UserRole;
  roles: UserRole[];
  primaryRole: UserRole;
  email?: string;
  phone?: string;
  department?: string;
  tier?: 1 | 2 | 3;
  projectIds?: string[];
  managerId?: string;
  seniorManagerId?: string;
  managerEmail?: string;
}
```

### **ผลลัพธ์:**
```typescript
const user = getUserById('user-006');

console.log(user.name);     // ❌ TypeScript Error: Type 'never' cannot be assigned to type 'string'
console.log(user.fullName); // ✅ Works!

// VSCode จะแสดง Error แบบนี้:
// ~~~~~~~~~~
// Property 'name' does not exist on type 'User'. 
// Did you mean 'fullName'?
```

### **ข้อดี:**
- ✅ **Compile-time error** (รู้ทันทีก่อน deploy)
- ✅ **VSCode IntelliSense** แสดง error ตอนพิมพ์
- ✅ **Suggestion:** VSCode แนะนำให้ใช้ `fullName`
- ✅ **Zero runtime cost** (ไม่มีผลต่อ performance)

### **ข้อเสีย:**
- ⚠️ Breaking change (ต้อง migration ทั้งหมด)
- ⚠️ ถ้ามี legacy code จะ error หมด

---

## **วิธีที่ 2: ESLint Rule (เสริม วิธีที่ 1)**

### **ทำอย่างไร:**
สร้าง ESLint rule ห้ามใช้ `.name` property

**สร้างไฟล์:** `.eslintrc.json`
```json
{
  "extends": ["eslint:recommended"],
  "rules": {
    "no-restricted-properties": [
      "error",
      {
        "object": "user",
        "property": "name",
        "message": "❌ ห้ามใช้ user.name - ใช้ user.fullName แทน (ดู /PROPERTY_NAME_PREVENTION.md)"
      },
      {
        "object": "assignee",
        "property": "name",
        "message": "❌ ห้ามใช้ assignee.name - ใช้ assignee.fullName แทน"
      },
      {
        "object": "assignedBy",
        "property": "name",
        "message": "❌ ห้ามใช้ assignedBy.name - ใช้ assignedBy.fullName แทน"
      },
      {
        "object": "closedBy",
        "property": "name",
        "message": "❌ ห้ามใช้ closedBy.name - ใช้ closedBy.fullName แทน"
      }
    ],
    
    // 🆕 ห้าม destructure { name } จาก user
    "no-restricted-syntax": [
      "error",
      {
        "selector": "ObjectPattern > Property[key.name='name'][value.type='Identifier']",
        "message": "❌ ห้าม destructure { name } - ใช้ { fullName } แทน"
      }
    ]
  }
}
```

**ติดตั้ง:**
```bash
npm install --save-dev eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin
```

**เพิ่มใน `package.json`:**
```json
{
  "scripts": {
    "lint": "eslint . --ext .ts,.tsx",
    "lint:fix": "eslint . --ext .ts,.tsx --fix"
  }
}
```

### **ผลลัพธ์:**
```typescript
const user = getUserById('user-006');
console.log(user.name); // ❌ ESLint Error: ห้ามใช้ user.name - ใช้ user.fullName แทน

const { name } = user;  // ❌ ESLint Error: ห้าม destructure { name }
const { fullName } = user; // ✅ OK
```

### **ข้อดี:**
- ✅ **IDE integration** (error แสดงใน VSCode)
- ✅ **CI/CD ตรวจสอบได้** (`npm run lint`)
- ✅ **Custom error message** (บอกทางแก้ชัดเจน)

### **ข้อเสีย:**
- ⚠️ ต้องติดตั้ง ESLint + Config
- ⚠️ ไม่ครอบคลุม 100% (เช่น `user['name']`)

---

## **วิธีที่ 3: Pre-commit Hook (Git)**

### **ทำอย่างไร:**
ใช้ **Husky** ตรวจสอบก่อน commit

**ติดตั้ง:**
```bash
npm install --save-dev husky
npx husky install
npx husky add .husky/pre-commit "npm run lint:name"
```

**เพิ่มใน `package.json`:**
```json
{
  "scripts": {
    "lint:name": "! git diff --cached --name-only | grep -E '\\.(tsx|ts)$' | xargs grep -n '\\.name(?!:)' 2>/dev/null || true"
  }
}
```

**สร้างไฟล์:** `.husky/pre-commit`
```bash
#!/bin/sh
. "$(dirname "$0")/_/husky.sh"

# ตรวจสอบว่ามีการใช้ .name หรือไม่
echo "🔍 Checking for .name property usage..."

if git diff --cached --name-only | grep -E '\.(tsx|ts)$' | xargs grep -n '\.name(?!:)' 2>/dev/null; then
  echo "❌ Error: Found usage of .name property"
  echo "✅ Please use .fullName instead"
  echo "📖 See: /PROPERTY_NAME_PREVENTION.md"
  exit 1
fi

echo "✅ No .name usage found. Committing..."
```

### **ผลลัพธ์:**
```bash
$ git commit -m "Add feature"

🔍 Checking for .name property usage...
components/TicketStatusAlert.tsx:112: • มอบหมายให้ ${assignee.name}
❌ Error: Found usage of .name property
✅ Please use .fullName instead
📖 See: /PROPERTY_NAME_PREVENTION.md
```

### **ข้อดี:**
- ✅ **ป้องกันตั้งแต่ commit** (ไม่ให้ code ผิดเข้า repo)
- ✅ **Team-wide enforcement** (ทุกคนต้องผ่าน hook)
- ✅ **Automation** (ไม่ต้องคิดเอง)

### **ข้อเสีย:**
- ⚠️ ต้องติดตั้ง Husky
- ⚠️ Developer สามารถ `--no-verify` ได้

---

## **วิธีที่ 4: VSCode Snippets (Developer Experience)**

### **ทำอย่างไร:**
สร้าง shortcuts สำหรับ `.fullName`

**สร้างไฟล์:** `.vscode/typescript.code-snippets`
```json
{
  "User Full Name": {
    "prefix": "ufn",
    "body": ["${1:user}.fullName"],
    "description": "✅ User fullName (ใช้แทน .name)"
  },
  
  "Assignee Full Name": {
    "prefix": "afn",
    "body": ["${1:assignee}.fullName"],
    "description": "✅ Assignee fullName"
  },
  
  "Get User By ID": {
    "prefix": "getuser",
    "body": [
      "const ${1:user} = getUserById(${2:userId});",
      "const ${3:name} = ${1:user}?.fullName || '${4:Unknown}';"
    ],
    "description": "✅ Get user and extract fullName safely"
  }
}
```

**วิธีใช้:**
```typescript
// พิมพ์: ufn [Tab]
user.fullName

// พิมพ์: afn [Tab]
assignee.fullName

// พิมพ์: getuser [Tab]
const user = getUserById(userId);
const name = user?.fullName || 'Unknown';
```

### **ข้อดี:**
- ✅ **Developer-friendly** (พิมพ์สั้น ได้ถูก)
- ✅ **IDE hints** (แสดงคำแนะนำใน autocomplete)
- ✅ **Consistency** (ทุกคนใช้ pattern เดียวกัน)

### **ข้อเสีย:**
- ⚠️ ไม่ได้บังคับ (แค่ช่วยให้พิมพ์ง่ายขึ้น)
- ⚠️ ต้อง setup ใน VSCode

---

<a name="ตัวอย่างการใช้งาน"></a>
## 💡 **ตัวอย่างการใช้งาน**

### **✅ ถูกต้อง:**

```typescript
// 1. Direct property access
const userName = user.fullName;

// 2. Optional chaining
const userName = user?.fullName || 'Unknown';

// 3. Template literal
const message = `User: ${user.fullName}`;

// 4. Destructuring
const { fullName } = user;
const message = `User: ${fullName}`;

// 5. Function parameter
function greet(user: User) {
  return `Hello, ${user.fullName}!`;
}
```

---

### **❌ ผิด (จะ error หลังใช้ วิธีที่ 1-2):**

```typescript
// 1. Direct property access
const userName = user.name; // ❌ Error: Type 'never' ...

// 2. Template literal
const message = `User: ${user.name}`; // ❌ Error

// 3. Destructuring
const { name } = user; // ❌ ESLint Error

// 4. Optional chaining (ยังผิดอยู่ดี)
const userName = user?.name || 'Unknown'; // ❌ Error
```

---

<a name="migration-guide"></a>
## 🔄 **Migration Guide (ย้ายจาก .name → .fullName)**

### **ขั้นตอนที่ 1: หา .name ทั้งหมด**

**คำสั่ง:**
```bash
# หาไฟล์ที่ใช้ .name
grep -rn "\.name" --include="*.tsx" --include="*.ts" .

# หาเฉพาะ user.name, assignee.name
grep -rn "\(user\|assignee\|assignedBy\|closedBy\)\.name" --include="*.tsx" --include="*.ts" .
```

**ผลลัพธ์:**
```
./components/TicketStatusAlert.tsx:75:  {closedBy && ` • ปิดโดย ${closedBy.name}`}
./components/TicketStatusAlert.tsx:112: {assignee && ` • มอบหมายให้ ${assignee.name}`}
./App.tsx:510: <StaffJourneyPage username={user?.name || 'Staff'} />
```

---

### **ขั้นตอนที่ 2: แทนที่ด้วย Script**

**สร้างไฟล์:** `fix-name-to-fullname.sh`
```bash
#!/bin/bash

# Find and replace .name with .fullName in all TypeScript files
find . -type f \( -name "*.tsx" -o -name "*.ts" \) \
  ! -path "./node_modules/*" \
  ! -path "./dist/*" \
  -exec sed -i '' 's/\(user\|assignee\|assignedBy\|closedBy\)\.name/\1.fullName/g' {} +

echo "✅ Migration complete!"
echo "📊 Files changed:"
git diff --stat
```

**รัน:**
```bash
chmod +x fix-name-to-fullname.sh
./fix-name-to-fullname.sh
```

---

### **ขั้นตอนที่ 3: เพิ่ม `name?: never`**

**แก้ไข:** `/contexts/AuthContext.tsx`
```typescript
export interface User {
  id: string;
  username: string;
  fullName: string;
  name?: never; // ✅ เพิ่มบรรทัดนี้
  // ... rest
}
```

**แก้ไข:** `/types/index.ts`
```typescript
export interface Stakeholder {
  userId: string;
  fullName: string;
  name?: never; // ✅ เพิ่มบรรทัดนี้
  role: UserRole;
  tier?: 1 | 2 | 3;
  type: 'creator' | 'escalator' | 'current_owner';
  addedAt: Date;
}
```

---

### **ขั้นตอนที่ 4: ตรวจสอบ TypeScript Errors**

**คำสั่ง:**
```bash
npm run build
# หรือ
npx tsc --noEmit
```

**แก้ errors ที่เหลือ:**
```typescript
// ❌ Error: Type 'never' is not assignable to type 'string'
const userName = user.name;

// ✅ แก้เป็น:
const userName = user.fullName;
```

---

### **ขั้นตอนที่ 5: ทดสอบ**

**Test Cases:**
```typescript
describe('User property access', () => {
  it('should use fullName instead of name', () => {
    const user = getUserById('user-006');
    
    // ✅ Should work
    expect(user.fullName).toBe('ยุทธนา คณามิ่งมงคล');
    
    // ❌ Should not compile (if using name?: never)
    // expect(user.name).toBe('...');
  });
});
```

---

## 📊 **ตารางสรุป Properties**

| Property | Status | ใช้ใน Context | TypeScript Type | ESLint Rule | Example |
|----------|--------|--------------|-----------------|-------------|---------|
| `fullName` | ✅ **ใช้** | User, Stakeholder | `string` | ✅ Allowed | `user.fullName` |
| `name` | ❌ **ห้ามใช้** | - | `never` | ❌ Blocked | ~~`user.name`~~ |
| `username` | ✅ ใช้ | User (login) | `string` | ✅ Allowed | `user.username` |
| `email` | ✅ ใช้ | User | `string?` | ✅ Allowed | `user.email` |

---

## 🎯 **Best Practices**

### ✅ **DO:**

```typescript
// 1. ใช้ fullName เสมอ
const name = user.fullName;

// 2. ใช้ Optional chaining
const name = user?.fullName || 'Unknown';

// 3. ใช้ Destructuring
const { fullName, email } = user;

// 4. ใช้ Type annotation
function greet(user: User): string {
  return `Hello, ${user.fullName}!`;
}
```

---

### ❌ **DON'T:**

```typescript
// 1. ห้ามใช้ .name
const name = user.name; // ❌

// 2. ห้าม Destructure name
const { name } = user; // ❌

// 3. ห้าม fallback ไปที่ name
const name = user.fullName || user.name; // ❌

// 4. ห้ามใช้ bracket notation หลบ check
const name = user['name']; // ❌ (ESLint ไม่จับ แต่ runtime ได้ undefined)
```

---

<a name="checklist-fullname"></a>
## 📋 **Checklist: ไฟล์ที่ใช้ `.fullName` (ต้องตรวจสอบทุกครั้งเมื่อพัฒนา)** ⭐ **ใหม่!**

- [ ] เพิ่ม `name?: never` ใน User interface
- [ ] เพิ่ม `name?: never` ใน Stakeholder interface
- [ ] ติดตั้ง ESLint + rule `no-restricted-properties`
- [ ] ติดตั้ง Husky + pre-commit hook
- [ ] Migration `.name` → `.fullName` ทั้งหมด
- [ ] ตรวจสอบ TypeScript errors (`npx tsc --noEmit`)
- [ ] ทดสอบ UI ทุกหน้า (ตรวจชื่อแสดงถูกต้อง)
- [ ] สร้าง VSCode snippets (optional)
- [ ] Update documentation

---

## 🔗 **เอกสารที่เกี่ยวข้อง**

- [FILTER_ISSUE_REPORT.md](./FILTER_ISSUE_REPORT.md) - รายงานปัญหา Filter และ Visibility
- [FULLNAME_USAGE_CHECKLIST.md](./FULLNAME_USAGE_CHECKLIST.md) ⭐ **ใหม่!** - รายการไฟล์ทั้งหมดที่ใช้ `.fullName` (ต้องตรวจสอบเมื่อพัฒนา)
- [TEAM_NAMES_DOCUMENTATION.md](./TEAM_NAMES_DOCUMENTATION.md) - รายชื่อทีมและ User IDs
- [USER_LIST.md](./USER_LIST.md) - รายการผู้ใช้ทั้งหมด

---

**ผู้สร้าง:** AI Assistant  
**วันที่:** 17 มกราคม 2026  
**เวอร์ชัน:** 1.1 (เพิ่มลิงก์ไปยัง FULLNAME_USAGE_CHECKLIST.md)  
**License:** MIT
