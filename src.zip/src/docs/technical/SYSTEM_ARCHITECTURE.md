# CDGS Issue Tracking Platform - System Architecture
## "Two-World Model" (Inverted Visibility Architecture)

This document describes the architectural separation between the **Service Portal** (Front Office) and the **Operations Console** (Back Office) used in the CDGS Issue Tracking Platform.

---

### 1. Conceptual Overview

The system is designed with a strict "Inverted Visibility Model" where high-privileged users (Resolvers) operate in a completely different interface environment than low-privileged users (Requesters).

- **Requesters (Customers & Staff)** live in the **Service Portal**. They see a simplified, user-friendly interface focused on creating and tracking their own tickets.
- **Resolvers (Tier 1, 2, 3 & Admin)** live in the **Operations Console**. They see a data-rich, complex interface focused on queue management, SLA monitoring, and ticket resolution.

### 2. User Groups (Actors)

#### Group A: Requesters (Service Portal Users)
- **Customer:** External or internal end-users who encounter issues.
  - *Capability:* Create Own Ticket, View Own Tickets.
  - *Home:* `/` (Customer Home Page).
- **Staff (Helpdesk/Middleman):** Support staff who receive issues from various channels (Line, Phone) and log them on behalf of customers.
  - *Capability:* Create Ticket For Customer, View Own Created Tickets.
  - *Home:* `/` (Staff Home Page).
  - *Note:* Staff are "Front Office" agents, not "Back Office" resolvers. They cannot close tickets.

#### Group B: Resolvers (Operations Console Users)
- **Tier 1 (Frontline Support):** The primary filter and resolution point.
  - *Capability:* Full Ticket Control (Accept, Edit, Close, Escalate).
  - *Home:* `/admin` (Main Dashboard).
- **Tier 2 (SA/Technical):** Technical specialists for complex issues.
  - *Capability:* Accept, Edit, Escalate (Cannot Close).
  - *Home:* `/admin/sa` (SA Dashboard).
- **Tier 3 (Vendor/Specialist):** Deep technical experts or external vendors.
  - *Capability:* Accept, Edit, Escalate (Cannot Close).
  - *Home:* `/admin/specialist` (Specialist Dashboard).
- **Admin (System Manager):** Manages users, projects, and settings.
  - *Capability:* Manage System.
  - *Home:* `/admin` (Main Dashboard).

---

### 3. Portal Separation & Routing Rules

The application enforces this separation via strict routing rules in `App.tsx` and `AuthContext`.

#### 3.1 Root Path (`/`) Behavior
The root path is exclusively for the **Service Portal**.
- **Customer/Staff:** Renders the `CustomerHomePage` or `StaffHomePage`.
- **Tier 1/2/3/Admin:** Triggers an **Automatic Redirect (Hard Redirect)** to their respective Dashboards. They never see the Service Portal home page.

| Actor | Redirect Target |
|-------|----------------|
| Customer | No Redirect (Stays at `/`) |
| Staff | No Redirect (Stays at `/`) |
| Tier 1 | `→ /admin` |
| Tier 2 | `→ /admin/sa` |
| Tier 3 | `→ /admin/specialist` |
| Admin | `→ /admin` |

#### 3.2 Ticket Creation (`/create`)
Both worlds share the `/create` route URL, but the **Layout** and **Form Logic** differ significantly:
- **Service Portal Context (Customer/Staff):** Renders with a simple Header-only layout. Focus on ease of use.
- **Operations Console Context (Tier 1+):** Renders with the Sidebar + Header (Admin Layout). Focus on data completeness (Project selection, Issue Type, Priority).

#### 3.3 Ticket Tracking
- **Service Portal:** Uses `/track` (Customer/Staff Track Ticket Page). Simple list, card view.
- **Operations Console:** Uses `/admin/tickets`, `/admin/pending`, `/admin/my-tickets`. Complex data tables with filtering and sorting.

---

### 4. Implementation Details

- **`App.tsx`**: Contains the central routing logic and "Safety Redirect" to ensure Tier users are ejected from the root path.
- **`lib/permissions.ts`**: Defines the Capability-Based Access Control (CBAC) system that powers these rules.
- **`components/Sidebar.tsx`**: Only visible in the Operations Console context.
- **`components/Header.tsx`**: Adapts its content (User Menu, Navigation) based on the user's context.

### 5. Summary Table

| Feature | Service Portal (Front Office) | Operations Console (Back Office) |
|---------|------------------------------|----------------------------------|
| **Primary Users** | Customer, Staff | Tier 1, Tier 2, Tier 3, Admin |
| **Main Interface** | Header Only | Sidebar + Header |
| **Home URL** | `/` | `/admin/*` |
| **Primary Goal** | Log & Track Issues | Resolve & Manage Issues |
| **Visibility** | Own Tickets Only | All Tickets (Permission based) |
