# 📚 คู่มือการติดตั้งและพัฒนา CDGS Issue Tracking Platform

## 📋 สารบัญ

1. [Technology Stack](#-technology-stack)
2. [การติดตั้ง Development Environment](#-การติดตั้ง-development-environment)
3. [การ Build และ Deploy Frontend](#-การ-build-และ-deploy-frontend)
4. [การเชื่อมต่อกับ Laravel Backend](#-การเชื่อมต่อกับ-laravel-backend)
5. [Authentication Flow](#-authentication-flow)
6. [Project Structure](#-project-structure)
7. [Common Issues และการแก้ไข](#-common-issues-และการแก้ไข)
8. [Roadmap สำหรับมือใหม่](#-roadmap-สำหรับมือใหม่)
9. [Resources](#-resources)

---

## 🎨 Technology Stack

### Frontend Technologies

```
┌─────────────────────────────────────────────┐
│  CDGS Issue Tracking Platform (Frontend)   │
├─────────────────────────────────────────────┤
│  ⚛️  React 18+ (JavaScript Library)        │
│  📘 TypeScript (Type Safety)               │
│  🎨 Tailwind CSS v4 (Styling)              │
│  🏗️  Vite (Build Tool & Dev Server)        │
│  🔄 React Router (Client-side Routing)     │
│  📦 npm/yarn (Package Manager)             │
└─────────────────────────────────────────────┘
```

### Key Libraries

| Library | จุดประสงค์ | ตัวอย่างการใช้งาน |
|---------|-----------|------------------|
| **React** | UI Framework หลัก | Components, Hooks (useState, useEffect) |
| **TypeScript** | Type checking | Interface, Type definitions |
| **Tailwind CSS** | Utility-first CSS | `className="bg-blue-500 text-white"` |
| **Lucide React** | Icon library | `<Mail />`, `<User />` |
| **Recharts** | Chart library | Dashboard charts |
| **Sonner** | Toast notifications | แจ้งเตือนสำเร็จ/ผิดพลาด |
| **React Hook Form** | Form management | จัดการ forms validation |

---

## 🚀 การติดตั้ง Development Environment

### ความต้องการของระบบ

- **Node.js**: v18.0+ หรือ v20 LTS (แนะนำ)
- **npm**: v9.0+ หรือ **yarn**: v1.22+
- **Git**: สำหรับ version control
- **Code Editor**: VS Code (แนะนำ)

### ขั้นตอนการติดตั้ง

#### 1. ตรวจสอบ Node.js

```bash
# ตรวจสอบเวอร์ชัน Node.js
node --version
# ควรแสดง v18.x.x หรือสูงกว่า

# ตรวจสอบ npm
npm --version
```

**หากยังไม่มี Node.js:**
- ดาวน์โหลดจาก: https://nodejs.org/
- เลือก LTS version (แนะนำ v20.x)

#### 2. Clone โปรเจค (ถ้ามี Git repository)

```bash
git clone https://github.com/your-org/cdgs-issue-tracking.git
cd cdgs-issue-tracking
```

#### 3. ติดตั้ง Dependencies

```bash
# ใช้ npm
npm install

# หรือใช้ yarn
yarn install
```

รอสักครู่ (ประมาณ 2-5 นาที) จนติดตั้งเสร็จ

#### 4. สร้างไฟล์ Environment Variables

สร้างไฟล์ `.env` ในโฟลเดอร์หลัก:

```bash
# .env
VITE_API_URL=http://localhost:8000/api/v1
VITE_APP_NAME=CDGS Issue Tracking Platform
```

#### 5. รัน Development Server

```bash
npm run dev
# หรือ
yarn dev
```

เปิดเบราว์เซอร์ที่: **http://localhost:5173**

---

## 📦 การ Build และ Deploy Frontend

### Build สำหรับ Production

```bash
# สร้างไฟล์ optimized สำหรับ production
npm run build

# ผลลัพธ์จะอยู่ในโฟลเดอร์ /dist
```

โครงสร้างไฟล์หลัง build:

```
dist/
├── index.html                 # HTML entry point
├── assets/
│   ├── index-abc123.js       # React code (minified)
│   ├── index-def456.css      # Tailwind CSS (minified)
│   └── logo-ghi789.png       # Images/Assets
└── favicon.ico
```

### ตัวเลือก Deployment

#### Option 1: Vercel (แนะนำ - ฟรีและง่ายที่สุด)

```bash
# 1. ติดตั้ง Vercel CLI
npm install -g vercel

# 2. Login
vercel login

# 3. Deploy
vercel

# 4. Deploy to production
vercel --prod
```

**ข้อดี:**
- ✅ ฟรี (Hobby plan)
- ✅ CI/CD อัตโนมัติ
- ✅ Custom domain ฟรี
- ✅ SSL certificate อัตโนมัติ

**เว็บไซต์:** https://vercel.com

---

#### Option 2: Netlify

```bash
# 1. ติดตั้ง Netlify CLI
npm install -g netlify-cli

# 2. Login
netlify login

# 3. Deploy
netlify deploy

# 4. Deploy to production
netlify deploy --prod
```

**ข้อดี:**
- ✅ ฟรี
- ✅ รองรับ SPA routing
- ✅ Form handling
- ✅ Serverless functions

**เว็บไซต์:** https://www.netlify.com

---

#### Option 3: AWS S3 + CloudFront

```bash
# 1. Build project
npm run build

# 2. Upload to S3 (ต้องติดตั้ง AWS CLI)
aws s3 sync dist/ s3://your-bucket-name --delete

# 3. Invalidate CloudFront cache
aws cloudfront create-invalidation --distribution-id YOUR_DIST_ID --paths "/*"
```

**ข้อดี:**
- ✅ Scalable มาก
- ✅ ราคาถูก (~$1-5/เดือน)
- ✅ CDN ทั่วโลก

**ข้อเสีย:**
- ❌ Setup ซับซ้อนกว่า
- ❌ ต้องจัดการ infrastructure เอง

---

#### Option 4: Nginx (VPS)

หลัง build แล้ว copy ไฟล์ไปยัง server:

```bash
# 1. Build
npm run build

# 2. Copy ไปยัง server
scp -r dist/* user@your-server.com:/var/www/cdgs-frontend/

# 3. Nginx configuration
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/cdgs-frontend;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

#### Option 5: Laravel (Same Server)

วาง React build ไว้ใน Laravel public folder:

```bash
# 1. Build React
npm run build

# 2. Copy ไปยัง Laravel public
cp -r dist/* ../laravel-backend/public/

# 3. Laravel จะ serve static files
```

---

## 🔗 การเชื่อมต่อกับ Laravel Backend

### Architecture Overview

```
┌──────────────────┐          ┌──────────────────┐
│   React Frontend │          │  Laravel Backend │
│   (Port 5173)    │◄────────►│   (Port 8000)    │
│                  │   HTTP   │                  │
│  - UI/UX         │   REST   │  - Database      │
│  - State Mgmt    │   JSON   │  - Business Logic│
│  - Validation    │          │  - Authentication│
└──────────────────┘          └──────────────────┘
```

---

### ขั้นตอนที่ 1: สร้าง API Service Layer (Frontend)

สร้างไฟล์ `/src/services/api.ts`:

```typescript
// src/services/api.ts
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

interface RequestOptions {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
}

class ApiClient {
  private baseURL: string;

  constructor(baseURL: string) {
    this.baseURL = baseURL;
  }

  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    const token = localStorage.getItem('auth_token');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    return headers;
  }

  async request(endpoint: string, options: RequestOptions = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config: RequestInit = {
      method: options.method || 'GET',
      headers: {
        ...this.getHeaders(),
        ...options.headers,
      },
    };

    if (options.body) {
      config.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, config);

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.message || `HTTP Error: ${response.status}`);
    }

    return response.json();
  }

  get(endpoint: string) {
    return this.request(endpoint, { method: 'GET' });
  }

  post(endpoint: string, data: any) {
    return this.request(endpoint, { method: 'POST', body: data });
  }

  put(endpoint: string, data: any) {
    return this.request(endpoint, { method: 'PUT', body: data });
  }

  patch(endpoint: string, data: any) {
    return this.request(endpoint, { method: 'PATCH', body: data });
  }

  delete(endpoint: string) {
    return this.request(endpoint, { method: 'DELETE' });
  }
}

export const apiClient = new ApiClient(API_BASE_URL);
```

---

### ขั้นตอนที่ 2: สร้าง Service Functions

สร้างไฟล์ `/src/services/ticketService.ts`:

```typescript
// src/services/ticketService.ts
import { apiClient } from './api';

export interface CreateTicketDTO {
  title: string;
  description: string;
  category: string;
  priority: string;
  project_id: number;
}

export interface Ticket {
  id: number;
  ticket_number: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  category: string;
  customer_name: string;
  customer_email: string;
  assigned_to?: string;
  created_at: string;
  updated_at: string;
}

export const ticketService = {
  // GET /api/v1/tickets
  async getAll(): Promise<Ticket[]> {
    const response = await apiClient.get('/tickets');
    return response.data;
  },

  // GET /api/v1/tickets/:id
  async getById(id: string | number): Promise<Ticket> {
    const response = await apiClient.get(`/tickets/${id}`);
    return response.data;
  },

  // POST /api/v1/tickets
  async create(data: CreateTicketDTO): Promise<Ticket> {
    const response = await apiClient.post('/tickets', data);
    return response.data;
  },

  // PATCH /api/v1/tickets/:id
  async update(id: string | number, data: Partial<Ticket>): Promise<Ticket> {
    const response = await apiClient.patch(`/tickets/${id}`, data);
    return response.data;
  },

  // POST /api/v1/tickets/:id/assign
  async assign(id: string | number, userId: number): Promise<Ticket> {
    const response = await apiClient.post(`/tickets/${id}/assign`, { user_id: userId });
    return response.data;
  },

  // POST /api/v1/tickets/:id/escalate
  async escalate(id: string | number, toTier: number): Promise<Ticket> {
    const response = await apiClient.post(`/tickets/${id}/escalate`, { tier: toTier });
    return response.data;
  },

  // POST /api/v1/tickets/:id/close
  async close(id: string | number): Promise<Ticket> {
    const response = await apiClient.post(`/tickets/${id}/close`, {});
    return response.data;
  },
};
```

---

### ขั้นตอนที่ 3: สร้าง Authentication Service

สร้างไฟล์ `/src/services/authService.ts`:

```typescript
// src/services/authService.ts
import { apiClient } from './api';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  password_confirmation: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  phone?: string;
  department?: string;
  created_at: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export const authService = {
  // POST /api/v1/auth/login
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await apiClient.post('/auth/login', credentials);
    
    // เก็บ token ใน localStorage
    if (response.token) {
      localStorage.setItem('auth_token', response.token);
    }
    
    return response;
  },

  // POST /api/v1/auth/register
  async register(data: RegisterData): Promise<AuthResponse> {
    const response = await apiClient.post('/auth/register', data);
    
    if (response.token) {
      localStorage.setItem('auth_token', response.token);
    }
    
    return response;
  },

  // POST /api/v1/auth/magic-link
  async sendMagicLink(email: string): Promise<{ message: string }> {
    return apiClient.post('/auth/magic-link', { email });
  },

  // POST /api/v1/auth/verify-magic-link
  async verifyMagicLink(token: string): Promise<AuthResponse> {
    const response = await apiClient.post('/auth/verify-magic-link', { token });
    
    if (response.token) {
      localStorage.setItem('auth_token', response.token);
    }
    
    return response;
  },

  // POST /api/v1/auth/logout
  async logout(): Promise<void> {
    try {
      await apiClient.post('/auth/logout', {});
    } finally {
      localStorage.removeItem('auth_token');
    }
  },

  // GET /api/v1/auth/me
  async getCurrentUser(): Promise<User> {
    const response = await apiClient.get('/auth/me');
    return response.data;
  },
};
```

---

### ขั้นตอนที่ 4: ตั้งค่า Laravel Backend

#### 4.1 สร้าง API Routes

```php
// routes/api.php
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\TicketController;
use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    
    // Public routes (ไม่ต้อง authentication)
    Route::prefix('auth')->group(function () {
        Route::post('login', [AuthController::class, 'login']);
        Route::post('register', [AuthController::class, 'register']);
        Route::post('magic-link', [AuthController::class, 'sendMagicLink']);
        Route::post('verify-magic-link', [AuthController::class, 'verifyMagicLink']);
    });
    
    // Protected routes (ต้อง authentication)
    Route::middleware('auth:sanctum')->group(function () {
        
        // Auth
        Route::prefix('auth')->group(function () {
            Route::get('me', [AuthController::class, 'me']);
            Route::post('logout', [AuthController::class, 'logout']);
        });
        
        // Tickets
        Route::prefix('tickets')->group(function () {
            Route::get('/', [TicketController::class, 'index']);
            Route::post('/', [TicketController::class, 'store']);
            Route::get('{id}', [TicketController::class, 'show']);
            Route::patch('{id}', [TicketController::class, 'update']);
            Route::delete('{id}', [TicketController::class, 'destroy']);
            
            // Actions
            Route::post('{id}/assign', [TicketController::class, 'assign']);
            Route::post('{id}/escalate', [TicketController::class, 'escalate']);
            Route::post('{id}/close', [TicketController::class, 'close']);
            Route::post('{id}/reopen', [TicketController::class, 'reopen']);
        });
        
        // Users
        Route::prefix('users')->group(function () {
            Route::get('/', [UserController::class, 'index']);
            Route::get('me', [UserController::class, 'me']);
            Route::patch('me', [UserController::class, 'updateProfile']);
        });
    });
});
```

---

#### 4.2 สร้าง Controllers

**AuthController.php:**

```php
<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        $token = $user->createToken('auth-token')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $user,
        ]);
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'customer', // default role
        ]);

        $token = $user->createToken('auth-token')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $user,
        ], 201);
    }

    public function me(Request $request)
    {
        return response()->json([
            'data' => $request->user(),
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Logged out successfully',
        ]);
    }

    public function sendMagicLink(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        // TODO: Implement magic link logic
        // 1. Generate unique token
        // 2. Save to database with expiration
        // 3. Send email with link

        return response()->json([
            'message' => 'Magic link sent to your email',
        ]);
    }

    public function verifyMagicLink(Request $request)
    {
        $request->validate([
            'token' => 'required|string',
        ]);

        // TODO: Implement verification logic
        // 1. Find token in database
        // 2. Check expiration
        // 3. Login user and delete token

        return response()->json([
            'token' => 'auth-token-here',
            'user' => [],
        ]);
    }
}
```

---

#### 4.3 ตั้งค่า CORS

```php
// config/cors.php
return [
    'paths' => ['api/*', 'sanctum/csrf-cookie'],
    
    'allowed_methods' => ['*'],
    
    'allowed_origins' => [
        'http://localhost:5173',      // Development
        'http://localhost:3000',      // Alternative dev port
        'https://yourdomain.com',     // Production
        'https://www.yourdomain.com', // Production with www
    ],
    
    'allowed_origins_patterns' => [],
    
    'allowed_headers' => ['*'],
    
    'exposed_headers' => [],
    
    'max_age' => 0,
    
    'supports_credentials' => true,
];
```

---

#### 4.4 ตั้งค่า Laravel Sanctum

```php
// config/sanctum.php
'stateful' => explode(',', env('SANCTUM_STATEFUL_DOMAINS', sprintf(
    '%s%s',
    'localhost,localhost:3000,localhost:5173,127.0.0.1,127.0.0.1:8000,::1',
    env('APP_URL') ? ','.parse_url(env('APP_URL'), PHP_URL_HOST) : ''
))),
```

```bash
# .env (Laravel)
APP_URL=http://localhost:8000
FRONTEND_URL=http://localhost:5173

SESSION_DRIVER=cookie
SANCTUM_STATEFUL_DOMAINS=localhost:5173,localhost:3000
```

---

### ขั้นตอนที่ 5: ใช้ Service ใน React Components

```typescript
// Example: CreateTicketPage.tsx
import { useState } from 'react';
import { ticketService } from '../services/ticketService';
import { toast } from 'sonner';

export function CreateTicketPage() {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (data: CreateTicketDTO) => {
    setLoading(true);
    
    try {
      const ticket = await ticketService.create(data);
      
      toast.success('เคสถูกสร้างเรียบร้อยแล้ว', {
        description: `หมายเลขเคส: ${ticket.ticket_number}`,
      });
      
      // Redirect to ticket detail
      navigate(`/tickets/${ticket.id}`);
      
    } catch (error) {
      toast.error('เกิดข้อผิดพลาด', {
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    // ... UI components
  );
}
```

---

## 🔐 Authentication Flow

### Token-based Authentication (Laravel Sanctum)

```typescript
// 1. Login Flow
import { authService } from './services/authService';

async function handleLogin(email: string, password: string) {
  try {
    // Call API
    const { token, user } = await authService.login({ email, password });
    
    // Token จะถูกเก็บใน localStorage โดยอัตโนมัติ
    console.log('Logged in as:', user.name);
    
    // Redirect to dashboard
    navigate('/dashboard');
    
  } catch (error) {
    console.error('Login failed:', error);
    alert('อีเมลหรือรหัสผ่านไม่ถูกต้อง');
  }
}

// 2. Authenticated Request
// ทุก request จะส่ง token ไปโดยอัตโนมัติผ่าน apiClient
const tickets = await ticketService.getAll();

// 3. Logout
async function handleLogout() {
  await authService.logout();
  navigate('/login');
}
```

### Protected Routes

```typescript
// src/components/ProtectedRoute.tsx
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

// Usage in App.tsx
<Route
  path="/dashboard"
  element={
    <ProtectedRoute>
      <DashboardPage />
    </ProtectedRoute>
  }
/>
```

---

## 📁 Project Structure

```
cdgs-frontend/
├── public/                      # Static files
│   ├── favicon.ico
│   └── logo.png
│
├── src/
│   ├── components/              # React Components
│   │   ├── ui/                  # Reusable UI components
│   │   │   ├── button.tsx
│   │   │   ├── dialog.tsx
│   │   │   └── input.tsx
│   │   ├── Header.tsx
│   │   ├── Sidebar.tsx
│   │   ├── LoginPage.tsx
│   │   ├── CreateTicketPage.tsx
│   │   └── TicketListPage.tsx
│   │
│   ├── contexts/                # React Context (State Management)
│   │   ├── AuthContext.tsx
│   │   └── TicketContext.tsx
│   │
│   ├── services/                # 🆕 API Services
│   │   ├── api.ts               # HTTP client base
│   │   ├── authService.ts       # Authentication APIs
│   │   ├── ticketService.ts     # Ticket APIs
│   │   └── userService.ts       # User APIs
│   │
│   ├── types/                   # 🆕 TypeScript Types
│   │   ├── ticket.ts
│   │   ├── user.ts
│   │   └── common.ts
│   │
│   ├── utils/                   # 🆕 Utility functions
│   │   ├── formatDate.ts
│   │   ├── constants.ts
│   │   └── validators.ts
│   │
│   ├── hooks/                   # 🆕 Custom Hooks
│   │   ├── useTickets.ts
│   │   ├── useAuth.ts
│   │   └── useDebounce.ts
│   │
│   ├── styles/                  # Global styles
│   │   └── globals.css
│   │
│   ├── App.tsx                  # Main component with routing
│   └── main.tsx                 # Entry point
│
├── .env                         # Environment variables
├── .env.example                 # Example env file
├── .gitignore                   # Git ignore rules
├── index.html                   # HTML template
├── package.json                 # Dependencies
├── tsconfig.json                # TypeScript config
├── vite.config.ts               # Vite config
├── tailwind.config.js           # Tailwind config (if needed)
└── README.md                    # Project documentation
```

---

## ⚠️ Common Issues และการแก้ไข

### 1. CORS Error

**อาการ:**
```
Access to fetch at 'http://localhost:8000/api/tickets' from origin 
'http://localhost:5173' has been blocked by CORS policy
```

**สาเหตุ:** Laravel ไม่อนุญาตให้ Frontend เข้าถึง API

**การแก้ไข:**

```php
// config/cors.php
'allowed_origins' => [
    'http://localhost:5173', // ✅ เพิ่ม frontend URL
],
'supports_credentials' => true, // ✅ อนุญาตให้ส่ง cookies
```

```bash
# ติดตั้ง CORS middleware (ถ้ายังไม่มี)
composer require fruitcake/laravel-cors

# Clear config cache
php artisan config:clear
```

---

### 2. 401 Unauthorized

**อาการ:**
```json
{ "message": "Unauthenticated." }
```

**สาเหตุ:** 
- ไม่ได้ส่ง token
- Token หมดอายุ
- Token ไม่ถูกต้อง

**การแก้ไข:**

```typescript
// ตรวจสอบว่ามี token ใน localStorage
const token = localStorage.getItem('auth_token');
console.log('Token:', token); // ต้องไม่เป็น null

// ตรวจสอบ request headers
// เปิด DevTools > Network > คลิกที่ request > Headers
// ต้องมี: Authorization: Bearer xxx
```

---

### 3. React State ไม่อัปเดต

**ปัญหา:**
```typescript
// ❌ ผิด: Mutate state โดยตรง
tickets.push(newTicket);
setTickets(tickets); // React จะไม่ re-render!
```

**แก้ไข:**
```typescript
// ✅ ถูก: สร้าง array ใหม่
setTickets([...tickets, newTicket]);

// หรือใช้ concat
setTickets(tickets.concat(newTicket));
```

---

### 4. Infinite Loop ใน useEffect

**ปัญหา:**
```typescript
// ❌ ผิด: ไม่มี dependency array
useEffect(() => {
  fetchTickets(); // เรียกทุกครั้งที่ component render
  // → fetch → update state → render → fetch → ...
});
```

**แก้ไข:**
```typescript
// ✅ ถูก: ระบุ dependencies
useEffect(() => {
  fetchTickets();
}, []); // เรียกแค่ครั้งเดียวตอน mount

// หรือระบุว่าต้อง re-run เมื่อ searchQuery เปลี่ยน
useEffect(() => {
  fetchTickets(searchQuery);
}, [searchQuery]);
```

---

### 5. Environment Variables ไม่ทำงาน

**ปัญหา:**
```typescript
console.log(process.env.VITE_API_URL); // undefined
```

**สาเหตุ:**
- ไฟล์ `.env` ไม่ได้อยู่ใน root folder
- ชื่อตัวแปรไม่ขึ้นต้นด้วย `VITE_`
- ไม่ได้ restart dev server หลังแก้ไข

**แก้ไข:**
```bash
# 1. ตรวจสอบว่าไฟล์ .env อยู่ใน root
ls -la .env

# 2. ตรวจสอบว่าขึ้นต้นด้วย VITE_
# ❌ ผิด: API_URL=http://localhost:8000
# ✅ ถูก: VITE_API_URL=http://localhost:8000

# 3. Restart dev server
npm run dev
```

---

### 6. Build Failed

**อาการ:**
```
error TS2304: Cannot find name 'process'
```

**แก้ไข:**
```bash
# ติดตั้ง @types/node
npm install -D @types/node

# เพิ่มใน tsconfig.json
{
  "compilerOptions": {
    "types": ["vite/client", "node"]
  }
}
```

---

### 7. Port Already in Use

**อาการ:**
```
Port 5173 is already in use
```

**แก้ไข:**
```bash
# หา process ที่ใช้ port
lsof -i :5173

# Kill process (Mac/Linux)
kill -9 <PID>

# หรือเปลี่ยน port ใน vite.config.ts
export default defineConfig({
  server: {
    port: 3000, // เปลี่ยนเป็น port อื่น
  },
});
```

---

## 🎯 Roadmap สำหรับมือใหม่

### สัปดาห์ที่ 1-2: พื้นฐาน JavaScript & React

#### เรียนรู้:
- ✅ JavaScript ES6+ (arrow functions, async/await, destructuring)
- ✅ React Basics (components, props, state)
- ✅ React Hooks (useState, useEffect, useContext)
- ✅ TypeScript Basics (interfaces, types)

#### ทำ:
- [ ] สร้าง Todo App เล็กๆ ด้วย React
- [ ] ทดลองใช้ useState และ useEffect
- [ ] เขียน TypeScript interface ส
