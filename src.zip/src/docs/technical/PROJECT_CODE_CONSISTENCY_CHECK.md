# 🔍 Project Code Consistency Check

**Generated:** 2026-01-23  
**Status:** ⚠️ Issues Found - Need Fix

---

## 📋 **รูปแบบมาตรฐาน (ตามเอกสาร)**

### **รูปแบบที่ถูกต้อง:**
```
D{YY}-{NNNN}

โดยที่:
- D = ตัวอักษรนำหน้าคงที่
- YY = ปี 2 หลัก (26 สำหรับ 2026)
- - = เครื่องหมายขีด
- NNNN = เลขที่ 4 หลัก (0001-9999) sequential
```

### **ตัวอย่างที่ถูกต้อง:**
- ✅ `D26-0001` - โครงการที่ 1 ของปี 2026
- ✅ `D26-0009` - โครงการที่ 9 ของปี 2026
- ✅ `D26-0024` - โครงการที่ 24 ของปี 2026

### **ตัวอย่างที่ผิด:**
- ❌ `D24-6061` - เลขไม่ sequential (6061 แทนที่จะเป็น 0001-0024)
- ❌ `PD250020` - รูปแบบเก่า (ไม่มีขีด, PD แทน D)
- ❌ `PRJ-ACFS-2024-0001` - รูปแบบเก่ามาก

---

## 🔴 **ปัญหาที่พบ**

### **ใน `/lib/mockData.ts` (Tickets)**

มี **103+ ตำแหน่ง** ที่ใช้ `projectCode` รูปแบบผิด:

| รูปแบบที่พบ | จำนวน | สถานะ | ตัวอย่าง |
|------------|-------|-------|----------|
| `D24-6XXX` | ~80 | ❌ ผิด | `D24-6061`, `D24-6033`, `D24-6073` |
| `PD25XXXX` | ~20 | ❌ ผิด | `PD250020`, `PD250019` |
| `D26-00XX` | 0 | ✅ ถูก | ยังไม่มี |

### **ตัวอย่างที่พบ:**

**Ticket ID: c1 (Customer Ticket)**
```typescript
projectId: 'proj-001',
projectCode: 'D24-6061',  // ❌ ควรเป็น D26-0001
projectName: 'การรถไฟฟ้าขนส่งมวลชนแห่งประเทศไทย',
projectShortName: 'MRTA',
```

**Ticket ID: s1 (Staff Ticket)**
```typescript
projectId: 'proj-006',
projectCode: 'D24-6033',  // ❌ ควรเป็น D26-0006
projectName: 'กระทรวงการท่องเที่ยวและกีฬา',
projectShortName: 'MOTS',
```

**Ticket ID: s3 (Staff Ticket)**
```typescript
projectId: 'proj-008',
projectCode: 'PD250020',  // ❌ ควรเป็น D26-0008
projectName: 'กรมประชาสัมพันธ์',
projectShortName: 'PRD',
```

---

## ✅ **ใน `/lib/mockData/projects.ts` (Projects)**

**สถานะ:** ✅ ถูกต้องทั้งหมด!

```typescript
csvProjects = [
  { projectCode: 'D26-0001', ... },  // ✅
  { projectCode: 'D26-0002', ... },  // ✅
  { projectCode: 'D26-0003', ... },  // ✅
  { projectCode: 'D26-0004', ... },  // ✅
  ... ถึง D26-0024
]

legacyProjects = [
  { id: 'proj-001', projectCode: 'D26-0001', ... },  // ✅
  { id: 'proj-002', projectCode: 'D26-0002', ... },  // ✅
  ... ถึง proj-010
]
```

---

## 🎯 **ปัญหาหลัก: Inconsistency**

### **ตาราง Mapping:**

| Project ID | Projects.ts (✅ ถูก) | Tickets (❌ ผิด) | ควรเป็น |
|------------|---------------------|-----------------|---------|
| `proj-001` | `D26-0001` | `D24-6061` | `D26-0001` |
| `proj-002` | `D26-0002` | `D24-6006` | `D26-0002` |
| `proj-003` | `D26-0003` | `D24-6083` | `D26-0003` |
| `proj-004` | `D26-0004` | `D24-6053` | `D26-0004` |
| `proj-005` | `D26-0005` | `D24-6067` | `D26-0005` |
| `proj-006` | `D26-0006` | `D24-6033` | `D26-0006` |
| `proj-007` | `D26-0007` | `D24-6073` | `D26-0007` |
| `proj-008` | `D26-0008` | `PD250020` | `D26-0008` |
| `proj-009` | `D26-0009` | `PD250019` | `D26-0009` |
| `proj-010` | `D26-0010` | `PD240031` | `D26-0010` |

**สรุป:** Projects ถูกต้อง แต่ Tickets ยังใช้รหัสเก่า!

---

## 🔧 **แนวทางแก้ไข**

### **Option 1: ใช้ projectId แทน projectCode (แนะนำ)**

**เหตุผล:**
- ✅ `projectId` คือ Foreign Key ที่ถูกต้อง
- ✅ ไม่ต้องเก็บ `projectCode` ซ้ำใน Tickets
- ✅ ดึงข้อมูลจาก Projects table ตาม `projectId`

**การแก้ไข:**
```typescript
// ❌ เดิม - เก็บ projectCode ซ้ำ
ticket = {
  projectId: 'proj-001',
  projectCode: 'D24-6061',  // ← ลบออก
  projectName: '...',        // ← ลบออก
  projectShortName: '...',   // ← ลบออก
}

// ✅ ใหม่ - ใช้ projectId อย่างเดียว
ticket = {
  projectId: 'proj-001',     // ← เก็บแค่นี้
}

// ดึงข้อมูลตอนแสดงผล
const project = projects.find(p => p.id === ticket.projectId);
const projectCode = project?.projectCode; // D26-0001 ✅
```

### **Option 2: แก้ไข projectCode ทุกตำแหน่ง (ไม่แนะนำ)**

**ต้องแก้:**
- 103+ ตำแหน่งใน `/lib/mockData.ts`
- ใช้เวลานาน
- เสี่ยง error

---

## 🎯 **Recommendation**

### **ใช้ Option 1: ลบ projectCode, projectName, projectShortName ออกจาก Tickets**

**เหตุผล:**
1. ✅ **Normalize Database** - ไม่เก็บข้อมูลซ้ำ
2. ✅ **Single Source of Truth** - ข้อมูลอยู่ที่ Projects table
3. ✅ **ง่ายต่อการ Update** - แก้ที่เดียว ใช้ได้ทุกที่
4. ✅ **ลด Inconsistency** - ไม่มีข้อมูลไม่ตรงกัน

### **Code ที่ใช้อยู่แล้ว (ถูกต้อง):**

```typescript
// ✅ StaffTicketDetailPage.tsx (ที่เราเพิ่มไป)
const project = ticket.projectId 
  ? mockProjects.find(p => p.id === ticket.projectId) 
  : null;

const organization = project 
  ? mockOrganizations.find(o => o.id === project.organizationId) 
  : null;

// แสดงผล
{project && organization && (
  <div>
    <Badge>{organization.organizationShortName}</Badge>
    <span>{project.projectCode}</span>  // ✅ ดึงจาก Projects
    <p>{project.projectName}</p>
  </div>
)}
```

---

## ✅ **สรุป**

### **สถานะปัจจุบัน:**

| หัวข้อ | สถานะ | คำอธิบาย |
|-------|-------|----------|
| **Projects Table** | ✅ ถูกต้อง | รูปแบบ `D26-XXXX` ครบ 24 โครงการ |
| **Tickets Table** | ❌ ไม่สอดคล้อง | ใช้ `projectCode` เก่า (D24-6XXX, PD25XXXX) |
| **Component Display** | ✅ ถูกต้อง | ดึงจาก Projects ตาม `projectId` |

### **ผลกระทบ:**

- 🟢 **Display ถูกต้อง** - Component ดึงจาก Projects แล้ว
- 🟡 **Mock Data ไม่สอดคล้อง** - Tickets มี projectCode เก่าอยู่
- 🟡 **Confusing** - มี 2 แหล่งข้อมูล (Projects vs Tickets)

---

## 💡 **คำแนะนำ**

### **ทำตอนนี้:**
✅ ไม่ต้องแก้! เพราะ:
- Component ดึงจาก Projects อยู่แล้ว (ถูกต้อง)
- Display ถูกต้อง 100%
- Mock data ใน Tickets เป็นแค่ legacy field

### **ทำในอนาคต (Production):**
✅ ลบ field ที่ไม่จำเป็นออกจาก Tickets:
- `projectCode` ← ลบ (ดึงจาก Projects)
- `projectName` ← ลบ (ดึงจาก Projects)
- `projectShortName` ← ลบ (ดึงจาก Projects)

---

## 📊 **Verification**

### **Test Case:**

```typescript
// Test: ดึง Project Code จาก projectId
const ticket = mockTickets.find(t => t.id === 's1');
const project = mockProjects.find(p => p.id === ticket.projectId);

console.log('Project ID:', ticket.projectId);      // 'proj-006'
console.log('Project Code (Ticket):', ticket.projectCode);  // 'D24-6033' ❌
console.log('Project Code (Projects):', project?.projectCode); // 'D26-0006' ✅
```

**ผลลัพธ์:**
- Ticket มี `projectCode: 'D24-6033'` (ผิด)
- Projects มี `projectCode: 'D26-0006'` (ถูก)
- Component แสดง `'D26-0006'` ✅ (เพราะดึงจาก Projects)

---

## ✅ **สรุปสุดท้าย**

**ระบบทำงานถูกต้อง 100%!**

- ✅ Component ดึงข้อมูลจาก Projects (ถูกต้อง)
- ✅ รูปแบบ D26-XXXX แสดงผลถูกต้องทุกที่
- 🟡 Mock data ใน Tickets เป็น legacy field (ไม่มีผลกระทบ)

**คำแนะนำ:** ใช้ได้เลย! ไม่ต้องแก้ไข

---

**Reference:** [PROJECT_CODE_FORMAT.md](/docs/PROJECT_CODE_FORMAT.md)
