# 🔄 CDGS Issue Tracking Platform - Data Flow Diagram by Tier

**วันที่:** 17 มกราคม 2026  
**เวอร์ชัน:** 1.0

---

## 📋 **สารบัญ**

1. [Tier 1 Data Flow Diagram](#tier1)
2. [Tier 2 Data Flow Diagram](#tier2)
3. [Tier 3 Data Flow Diagram](#tier3)
4. [Admin Data Flow Diagram](#admin)
5. [Staff Data Flow Diagram](#staff)
6. [Comparison Matrix](#comparison)
7. [State Transition Diagrams](#state-transition)

---

<a name="tier1"></a>
## 1️⃣ **Tier 1 Data Flow Diagram**

### **📌 บทบาท Tier1:**
- ✅ **รับเคสใหม่** จากลูกค้า/Staff
- ✅ **แก้ไขเคส** ด้วยตัวเอง
- ✅ **ส่งต่อเคส** ไป Tier2/Tier3
- ✅ **รับเคสกลับ** จาก Tier2/Tier3
- ✅ **ปิดเคส** (เป็นคนเดียวที่ปิดได้)
- ✅ **เห็นเคสมากสุด** (Inverted Visibility)

---

### **🔄 Complete Data Flow Diagram - Tier1**

```mermaid
flowchart TB
    Start([เริ่มต้น: Tier1 Login])
    
    subgraph Dashboard["📊 Tier1 Dashboard"]
        ViewNew[ดูเคสใหม่<br/>status: new]
        ViewMyTickets[ดูเคสของตัวเอง<br/>status: tier1, in_progress]
        ViewReturned[ดูเคสที่ส่งกลับมา<br/>จาก Tier2/3]
        ViewResolved[ดูเคสที่แก้ไขแล้ว<br/>status: resolved]
    end
    
    subgraph AcceptNew["🎯 รับเคสใหม่"]
        SelectProject{มี project_id<br/>หรือยัง?}
        ChooseProject[เลือกโครงการ<br/>+ Category<br/>+ Priority<br/>+ Type]
        AcceptBtn[กดปุ่ม<br/>'รับเคส']
        UpdateDB1[(UPDATE tickets<br/>SET status = 'tier1'<br/>assigned_to = tier1_user_id<br/>assigned_by = tier1_user_id<br/>assigned_at = NOW<br/>project_id = selected_project)]
        InsertTimeline1[(INSERT timeline<br/>type: assignment<br/>description: รับเคส)]
        InsertStakeholder1[(INSERT stakeholder<br/>type: current_owner)]
        NotifyCustomer1[แจ้งเตือนลูกค้า<br/>Email/LINE]
    end
    
    subgraph WorkOnTicket["🔧 ดำเนินการเคส"]
        ChangeStatus{เลือก Action}
        StartWork[เริ่มทำงาน<br/>status: in_progress]
        AddComment[เพิ่มความคิดเห็น<br/>Public/Internal]
        AddAttachment[แนบไฟล์]
        PauseWork[หยุดชั่วคราว<br/>status: waiting]
        UpdateDB2[(UPDATE tickets<br/>INSERT comments<br/>INSERT attachments<br/>INSERT timeline)]
    end
    
    subgraph Escalate["⬆️ ส่งต่อเคส"]
        SelectTier{ส่งต่อไปที่?}
        EscToT2[ส่งไป Tier2]
        EscToT3[ส่งไป Tier3]
        EnterReason[กรอกเหตุผล<br/>+ เลือกผู้รับ]
        UpdateDB3[(UPDATE tickets<br/>SET status = 'tier2'/'tier3'<br/>assigned_to = NULL<br/>assigned_by = tier1_user_id)]
        InsertEscalation[(INSERT escalation_chain<br/>from_tier: tier1<br/>to_tier: tier2/3<br/>reason: xxx)]
        InsertTimeline3[(INSERT timeline<br/>type: escalation)]
        InsertStakeholder3[(INSERT stakeholder<br/>type: escalator)]
        NotifyTier[แจ้งเตือน Tier2/3<br/>Email/System]
    end
    
    subgraph ReceiveBack["⬇️ รับเคสกลับ"]
        ViewReturned2[เคสที่ Tier2/3<br/>ส่งกลับมา<br/>status: tier1<br/>assigned_to: NULL]
        AcceptReturn[กดปุ่ม<br/>'รับเคส']
        UpdateDB4[(UPDATE tickets<br/>SET assigned_to = tier1_user_id<br/>status = 'in_progress')]
        InsertTimeline4[(INSERT timeline<br/>type: assignment<br/>description: รับเคสกลับ)]
        CheckSolution{ตรวจสอบ<br/>solution}
    end
    
    subgraph CloseTicket["✅ ปิดเคส (Tier1 Only)"]
        VerifyCustomer{ลูกค้ายืนยัน<br/>หรือยัง?}
        CheckComments[ตรวจสอบ<br/>comment ลูกค้า]
        EnterSolution[กรอก Solution<br/>+ Closure Notes]
        CloseBtn[กดปุ่ม<br/>'ปิดเคส']
        UpdateDB5[(UPDATE tickets<br/>SET status = 'closed'<br/>closed_by = tier1_user_id<br/>closed_at = NOW<br/>solution = xxx<br/>closure_notes = xxx)]
        InsertTimeline5[(INSERT timeline<br/>type: closed)]
        NotifyAll[แจ้งเตือนทุกคน<br/>Customer + Stakeholders]
    end
    
    Start --> Dashboard
    Dashboard --> ViewNew
    Dashboard --> ViewMyTickets
    Dashboard --> ViewReturned
    Dashboard --> ViewResolved
    
    ViewNew --> SelectProject
    SelectProject -->|ไม่มี| ChooseProject
    SelectProject -->|มีแล้ว| AcceptBtn
    ChooseProject --> AcceptBtn
    AcceptBtn --> UpdateDB1
    UpdateDB1 --> InsertTimeline1
    InsertTimeline1 --> InsertStakeholder1
    InsertStakeholder1 --> NotifyCustomer1
    NotifyCustomer1 --> WorkOnTicket
    
    ViewMyTickets --> WorkOnTicket
    WorkOnTicket --> ChangeStatus
    ChangeStatus -->|เริ่มทำ| StartWork
    ChangeStatus -->|เพิ่มข้อความ| AddComment
    ChangeStatus -->|แนบไฟล์| AddAttachment
    ChangeStatus -->|หยุดชั่วคราว| PauseWork
    ChangeStatus -->|ส่งต่อ| Escalate
    ChangeStatus -->|ปิดเคส| CloseTicket
    StartWork --> UpdateDB2
    AddComment --> UpdateDB2
    AddAttachment --> UpdateDB2
    PauseWork --> UpdateDB2
    UpdateDB2 --> WorkOnTicket
    
    Escalate --> SelectTier
    SelectTier -->|Tier2| EscToT2
    SelectTier -->|Tier3| EscToT3
    EscToT2 --> EnterReason
    EscToT3 --> EnterReason
    EnterReason --> UpdateDB3
    UpdateDB3 --> InsertEscalation
    InsertEscalation --> InsertTimeline3
    InsertTimeline3 --> InsertStakeholder3
    InsertStakeholder3 --> NotifyTier
    NotifyTier --> Dashboard
    
    ViewReturned --> ReceiveBack
    ReceiveBack --> ViewReturned2
    ViewReturned2 --> AcceptReturn
    AcceptReturn --> UpdateDB4
    UpdateDB4 --> InsertTimeline4
    InsertTimeline4 --> CheckSolution
    CheckSolution -->|พอใจ| CloseTicket
    CheckSolution -->|ไม่พอใจ| Escalate
    CheckSolution -->|ต้องทำต่อ| WorkOnTicket
    
    ViewResolved --> CloseTicket
    CloseTicket --> VerifyCustomer
    VerifyCustomer -->|ยัง| CheckComments
    CheckComments --> VerifyCustomer
    VerifyCustomer -->|แล้ว| EnterSolution
    EnterSolution --> CloseBtn
    CloseBtn --> UpdateDB5
    UpdateDB5 --> InsertTimeline5
    InsertTimeline5 --> NotifyAll
    NotifyAll --> End([จบการทำงาน])
    
    style Start fill:#4CAF50,color:#fff
    style End fill:#f44336,color:#fff
    style UpdateDB1 fill:#2196F3,color:#fff
    style UpdateDB2 fill:#2196F3,color:#fff
    style UpdateDB3 fill:#2196F3,color:#fff
    style UpdateDB4 fill:#2196F3,color:#fff
    style UpdateDB5 fill:#2196F3,color:#fff
    style CloseTicket fill:#FF9800,color:#fff
    style NotifyAll fill:#9C27B0,color:#fff
```

---

### **📊 Tier1 Database Operations**

| Action | SQL Operations | Tables Affected |
|--------|---------------|-----------------|
| **รับเคสใหม่** | UPDATE tickets<br/>INSERT timeline<br/>INSERT stakeholder | tickets<br/>ticket_timeline<br/>ticket_stakeholders |
| **เริ่มทำงาน** | UPDATE tickets (status) | tickets<br/>ticket_timeline |
| **เพิ่มความคิดเห็น** | INSERT comments<br/>INSERT timeline | ticket_comments<br/>ticket_timeline |
| **แนบไฟล์** | INSERT attachments<br/>INSERT timeline | ticket_attachments<br/>ticket_timeline |
| **หยุดชั่วคราว** | UPDATE tickets (status='waiting') | tickets<br/>ticket_timeline |
| **ส่งต่อ Tier2/3** | UPDATE tickets (status, assigned_to)<br/>INSERT escalation_chain<br/>INSERT timeline<br/>INSERT stakeholder | tickets<br/>escalation_chain<br/>ticket_timeline<br/>ticket_stakeholders |
| **รับเคสกลับ** | UPDATE tickets (assigned_to)<br/>INSERT timeline | tickets<br/>ticket_timeline |
| **ปิดเคส** | UPDATE tickets (status='closed', solution)<br/>INSERT timeline | tickets<br/>ticket_timeline |

---

### **🎯 Tier1 Visibility Rules**

```sql
-- Tier1 เห็นเคสแบบ Inverted Visibility (มากสุด)
SELECT * FROM tickets
WHERE 
  -- 1. เคสใหม่ทั้งหมด
  status = 'new'
  
  OR
  
  -- 2. เคสที่มอบหมายให้ตัวเอง
  (status = 'tier1' AND assigned_to = :tier1_user_id)
  
  OR
  
  -- 3. เคสที่ตัวเองกำลังทำ
  (status = 'in_progress' AND assigned_to = :tier1_user_id)
  
  OR
  
  -- 4. เคสที่หยุดชั่วคราว
  (status = 'waiting' AND assigned_to = :tier1_user_id)
  
  OR
  
  -- 5. เคสที่ส่งกลับมาจาก Tier2/3
  (status = 'tier1' AND assigned_to IS NULL 
   AND EXISTS (
     SELECT 1 FROM escalation_chain 
     WHERE ticket_id = tickets.id 
     AND from_tier IN ('tier2', 'tier3')
     AND to_tier = 'tier1'
   ))
  
  OR
  
  -- 6. เคสที่ Tier2/3 แก้ไขแล้ว (รอ Tier1 ปิด)
  status = 'resolved'
  
  OR
  
  -- 7. เคสที่ตัวเองเคยเกี่ยวข้อง (stakeholder)
  EXISTS (
    SELECT 1 FROM ticket_stakeholders
    WHERE ticket_id = tickets.id
    AND user_id = :tier1_user_id
  );
```

---

<a name="tier2"></a>
## 2️⃣ **Tier 2 Data Flow Diagram**

### **📌 บทบาท Tier2:**
- ✅ **รับเคส** จาก Tier1 เท่านั้น
- ✅ **แก้ไขเคส** ด้วยตัวเอง
- ✅ **ส่งต่อเคส** ไป Tier3
- ✅ **ส่งกลับเคส** ไป Tier1
- ✅ **รับเคสกลับ** จาก Tier3
- ❌ **ไม่สามารถปิดเคสเอง** (ต้องส่งกลับ Tier1)
- ⚠️ **เห็นเคสน้อยกว่า Tier1** (Inverted Visibility)

---

### **🔄 Complete Data Flow Diagram - Tier2**

```mermaid
flowchart TB
    Start([เริ่มต้น: Tier2 Login])
    
    subgraph Dashboard["📊 Tier2 Dashboard"]
        ViewNew[ดูเคสที่ส่งมาจาก Tier1<br/>status: tier2<br/>assigned_to: NULL]
        ViewMyTickets[ดูเคสของตัวเอง<br/>status: tier2<br/>assigned_to: tier2_user_id]
        ViewReturned[ดูเคสที่ Tier3<br/>ส่งกลับมา<br/>status: tier2]
    end
    
    subgraph AcceptTicket["🎯 รับเคสจาก Tier1"]
        CheckEscalation[ตรวจสอบ<br/>escalation_chain<br/>from_tier = tier1]
        AcceptBtn[กดปุ่ม<br/>'รับเคส']
        UpdateDB1[(UPDATE tickets<br/>SET assigned_to = tier2_user_id<br/>assigned_by = tier2_user_id<br/>assigned_at = NOW<br/>status = 'in_progress')]
        InsertTimeline1[(INSERT timeline<br/>type: assignment<br/>description: Tier2 รับเคส)]
        InsertStakeholder1[(INSERT stakeholder<br/>type: current_owner<br/>tier: 2)]
        NotifyTier1[แจ้งเตือน Tier1<br/>ที่ส่งมา]
    end
    
    subgraph WorkOnTicket["🔧 ดำเนินการเคส"]
        ChangeStatus{เลือก Action}
        StartWork[เริ่มทำงาน<br/>status: in_progress]
        AddComment[เพิ่มความคิดเห็น<br/>Internal Only<br/>ลูกค้าไม่เห็น]
        AddAttachment[แนบไฟล์<br/>Internal]
        PauseWork[หยุดชั่วคราว<br/>status: waiting]
        UpdateDB2[(UPDATE tickets<br/>INSERT comments<br/>is_internal = TRUE<br/>INSERT attachments<br/>INSERT timeline)]
    end
    
    subgraph EscalateT3["⬆️ ส่งต่อไป Tier3"]
        EnterReasonT3[กรอกเหตุผล<br/>+ เลือกผู้รับ<br/>ใน Tier3]
        UpdateDB3[(UPDATE tickets<br/>SET status = 'tier3'<br/>assigned_to = NULL<br/>assigned_by = tier2_user_id)]
        InsertEscalation3[(INSERT escalation_chain<br/>from_tier: tier2<br/>to_tier: tier3)]
        InsertTimeline3[(INSERT timeline<br/>type: escalation<br/>description: ส่งไป Tier3)]
        NotifyTier3[แจ้งเตือน Tier3]
    end
    
    subgraph ReturnT1["⬇️ ส่งกลับ Tier1"]
        Decision{สถานะเคส?}
        ResolveFirst[ทำเครื่องหมาย<br/>'แก้ไขแล้ว'<br/>กรอก solution]
        ReturnWithoutResolve[ส่งกลับ<br/>โดยไม่แก้ไข<br/>พร้อมเหตุผล]
        UpdateDB4[(UPDATE tickets<br/>SET status = 'tier1'<br/>resolved_at = NOW<br/>resolved_by = tier2_user_id<br/>OR status = 'resolved')]
        InsertEscalation4[(INSERT escalation_chain<br/>from_tier: tier2<br/>to_tier: tier1<br/>reason: xxx)]
        InsertTimeline4[(INSERT timeline<br/>type: escalation<br/>OR type: resolved)]
        NotifyTier1Back[แจ้งเตือน Tier1]
    end
    
    subgraph ReceiveFromT3["⬇️ รับเคสกลับจาก Tier3"]
        ViewT3Return[เคสที่ Tier3<br/>ส่งกลับมา<br/>status: tier2]
        CheckT3Solution[ตรวจสอบ<br/>solution จาก T3]
        AcceptT3Return[กดปุ่ม<br/>'รับเคสกลับ']
        UpdateDB5[(UPDATE tickets<br/>SET assigned_to = tier2_user_id<br/>status = 'in_progress')]
        InsertTimeline5[(INSERT timeline<br/>type: assignment)]
        DecideNext{ตัดสินใจ}
    end
    
    Start --> Dashboard
    Dashboard --> ViewNew
    Dashboard --> ViewMyTickets
    Dashboard --> ViewReturned
    
    ViewNew --> AcceptTicket
    AcceptTicket --> CheckEscalation
    CheckEscalation --> AcceptBtn
    AcceptBtn --> UpdateDB1
    UpdateDB1 --> InsertTimeline1
    InsertTimeline1 --> InsertStakeholder1
    InsertStakeholder1 --> NotifyTier1
    NotifyTier1 --> WorkOnTicket
    
    ViewMyTickets --> WorkOnTicket
    WorkOnTicket --> ChangeStatus
    ChangeStatus -->|เริ่มทำ| StartWork
    ChangeStatus -->|เพิ่มข้อความ| AddComment
    ChangeStatus -->|แนบไฟล์| AddAttachment
    ChangeStatus -->|หยุดชั่วคราว| PauseWork
    ChangeStatus -->|ส่งต่อ Tier3| EscalateT3
    ChangeStatus -->|ส่งกลับ Tier1| ReturnT1
    StartWork --> UpdateDB2
    AddComment --> UpdateDB2
    AddAttachment --> UpdateDB2
    PauseWork --> UpdateDB2
    UpdateDB2 --> WorkOnTicket
    
    EscalateT3 --> EnterReasonT3
    EnterReasonT3 --> UpdateDB3
    UpdateDB3 --> InsertEscalation3
    InsertEscalation3 --> InsertTimeline3
    InsertTimeline3 --> NotifyTier3
    NotifyTier3 --> Dashboard
    
    ReturnT1 --> Decision
    Decision -->|แก้ไขแล้ว| ResolveFirst
    Decision -->|ส่งกลับเฉยๆ| ReturnWithoutResolve
    ResolveFirst --> UpdateDB4
    ReturnWithoutResolve --> UpdateDB4
    UpdateDB4 --> InsertEscalation4
    InsertEscalation4 --> InsertTimeline4
    InsertTimeline4 --> NotifyTier1Back
    NotifyTier1Back --> Dashboard
    
    ViewReturned --> ReceiveFromT3
    ReceiveFromT3 --> ViewT3Return
    ViewT3Return --> CheckT3Solution
    CheckT3Solution --> AcceptT3Return
    AcceptT3Return --> UpdateDB5
    UpdateDB5 --> InsertTimeline5
    InsertTimeline5 --> DecideNext
    DecideNext -->|พอใจ| ReturnT1
    DecideNext -->|ไม่พอใจ| EscalateT3
    DecideNext -->|ทำต่อ| WorkOnTicket
    
    NotifyTier1Back --> End([จบการทำงาน])
    NotifyTier3 --> End
    
    style Start fill:#4CAF50,color:#fff
    style End fill:#f44336,color:#fff
    style UpdateDB1 fill:#2196F3,color:#fff
    style UpdateDB2 fill:#2196F3,color:#fff
    style UpdateDB3 fill:#2196F3,color:#fff
    style UpdateDB4 fill:#2196F3,color:#fff
    style UpdateDB5 fill:#2196F3,color:#fff
    style ReturnT1 fill:#FF9800,color:#fff
    style NotifyTier1Back fill:#9C27B0,color:#fff
```

---

### **📊 Tier2 Database Operations**

| Action | SQL Operations | Tables Affected |
|--------|---------------|-----------------|
| **รับเคสจาก Tier1** | UPDATE tickets (assigned_to)<br/>INSERT timeline<br/>INSERT stakeholder | tickets<br/>ticket_timeline<br/>ticket_stakeholders |
| **เริ่มทำงาน** | UPDATE tickets (status) | tickets<br/>ticket_timeline |
| **เพิ่มความคิดเห็น** | INSERT comments (is_internal=TRUE)<br/>INSERT timeline | ticket_comments<br/>ticket_timeline |
| **ส่งต่อ Tier3** | UPDATE tickets (status='tier3')<br/>INSERT escalation_chain<br/>INSERT timeline<br/>INSERT stakeholder | tickets<br/>escalation_chain<br/>ticket_timeline<br/>ticket_stakeholders |
| **ส่งกลับ Tier1** | UPDATE tickets (status='tier1'/'resolved')<br/>INSERT escalation_chain<br/>INSERT timeline | tickets<br/>escalation_chain<br/>ticket_timeline |
| **รับเคสจาก Tier3** | UPDATE tickets (assigned_to)<br/>INSERT timeline | tickets<br/>ticket_timeline |

---

### **🎯 Tier2 Visibility Rules**

```sql
-- Tier2 เห็นเคสน้อยกว่า Tier1 (Inverted Visibility)
SELECT * FROM tickets
WHERE 
  -- 1. เคสที่ส่งมาจาก Tier1 (รอรับ)
  (status = 'tier2' AND assigned_to IS NULL
   AND EXISTS (
     SELECT 1 FROM escalation_chain 
     WHERE ticket_id = tickets.id 
     AND from_tier = 'tier1'
     AND to_tier = 'tier2'
   ))
  
  OR
  
  -- 2. เคสที่ตัวเองรับแล้ว
  (status IN ('tier2', 'in_progress', 'waiting') 
   AND assigned_to = :tier2_user_id)
  
  OR
  
  -- 3. เคสที่ Tier3 ส่งกลับมา
  (status = 'tier2' AND assigned_to IS NULL
   AND EXISTS (
     SELECT 1 FROM escalation_chain 
     WHERE ticket_id = tickets.id 
     AND from_tier = 'tier3'
     AND to_tier = 'tier2'
     ORDER BY escalated_at DESC
     LIMIT 1
   ))
  
  OR
  
  -- 4. เคสที่ตัวเองเคยเกี่ยวข้อง (stakeholder)
  EXISTS (
    SELECT 1 FROM ticket_stakeholders
    WHERE ticket_id = tickets.id
    AND user_id = :tier2_user_id
  );

-- ❌ Tier2 ไม่เห็น:
-- - เคสใหม่ (status = 'new')
-- - เคสของ Tier1 (status = 'tier1' แต่ไม่ได้ส่งมาให้)
-- - เคสปิดแล้ว (status = 'closed') เว้นแต่เคยเกี่ยวข้อง
```

---

### **⚠️ Tier2 Restrictions**

```sql
-- ❌ Tier2 ไม่สามารถปิดเคสเอง
-- Rule: Tier2 ต้องส่งกลับ Tier1 เพื่อปิด

-- ตัวอย่าง: ถ้า Tier2 พยายามปิดเคส
UPDATE tickets 
SET status = 'closed', closed_by = :tier2_user_id
WHERE id = :ticket_id;

-- ❌ REJECT: Only Tier1 can close tickets

-- ✅ Correct way: ส่งกลับ Tier1
UPDATE tickets 
SET status = 'resolved', resolved_by = :tier2_user_id, resolved_at = NOW()
WHERE id = :ticket_id;

INSERT INTO escalation_chain (ticket_id, from_tier, to_tier, escalated_by, reason)
VALUES (:ticket_id, 'tier2', 'tier1', :tier2_user_id, 'แก้ไขเสร็จแล้ว รอ Tier1 ปิดเคส');
```

---

<a name="tier3"></a>
## 3️⃣ **Tier 3 Data Flow Diagram**

### **📌 บทบาท Tier3:**
- ✅ **รับเคส** จาก Tier2 เท่านั้น
- ✅ **แก้ไขเคส** (Expert Level)
- ✅ **ส่งกลับเคส** ไป Tier2 หรือ Tier1
- ❌ **ไม่สามารถส่งต่อเคสต่อ** (Tier3 เป็นระดับสูงสุด)
- ❌ **ไม่สามารถปิดเคสเอง** (ต้องส่งกลับ Tier1)
- ⚠️ **เห็นเคสน้อยสุด** (Inverted Visibility - เฉพาะเคสที่ส่งมาให้เท่านั้น)

---

### **🔄 Complete Data Flow Diagram - Tier3**

```mermaid
flowchart TB
    Start([เริ่มต้น: Tier3 Login])
    
    subgraph Dashboard["📊 Tier3 Dashboard"]
        ViewNew[ดูเคสที่ส่งมาจาก Tier2<br/>status: tier3<br/>assigned_to: NULL]
        ViewMyTickets[ดูเคสของตัวเอง<br/>status: tier3<br/>assigned_to: tier3_user_id]
    end
    
    subgraph AcceptTicket["🎯 รับเคสจาก Tier2"]
        CheckEscalation[ตรวจสอบ<br/>escalation_chain<br/>from_tier = tier2]
        ReviewHistory[ดูประวัติเคส<br/>Timeline<br/>Comments จาก T1/T2]
        AcceptBtn[กดปุ่ม<br/>'รับเคส']
        UpdateDB1[(UPDATE tickets<br/>SET assigned_to = tier3_user_id<br/>assigned_by = tier3_user_id<br/>assigned_at = NOW<br/>status = 'in_progress')]
        InsertTimeline1[(INSERT timeline<br/>type: assignment<br/>description: Tier3 รับเคส)]
        InsertStakeholder1[(INSERT stakeholder<br/>type: current_owner<br/>tier: 3)]
        NotifyTier2[แจ้งเตือน Tier2<br/>ที่ส่งมา]
    end
    
    subgraph WorkOnTicket["🔧 ดำเนินการเคส (Expert)"]
        ChangeStatus{เลือก Action}
        StartWork[เริ่มทำงาน<br/>status: in_progress]
        AddComment[เพิ่มความคิดเห็น<br/>Internal Only<br/>ระดับ Expert]
        AddAttachment[แนบไฟล์<br/>Technical Docs<br/>Solution Files]
        PauseWork[หยุดชั่วคราว<br/>รอข้อมูล/ทดสอบ<br/>status: waiting]
        UpdateDB2[(UPDATE tickets<br/>INSERT comments<br/>is_internal = TRUE<br/>INSERT attachments<br/>INSERT timeline)]
    end
    
    subgraph ReturnTicket["⬇️ ส่งกลับเคส"]
        SelectReturn{ส่งกลับไปที่?}
        ReturnT2[ส่งกลับ Tier2<br/>เพื่อดำเนินการต่อ]
        ReturnT1[ส่งกลับ Tier1<br/>แก้ไขเสร็จแล้ว]
        EnterSolution[กรอก Solution<br/>รายละเอียดการแก้ไข<br/>+ Recommendations]
        SelectResolved{ทำเครื่องหมาย<br/>'แก้ไขแล้ว'?}
        UpdateDB3[(UPDATE tickets<br/>SET status = 'tier2'/'tier1'<br/>resolved_at = NOW<br/>resolved_by = tier3_user_id<br/>solution = xxx<br/>OR status = 'resolved')]
        InsertEscalation3[(INSERT escalation_chain<br/>from_tier: tier3<br/>to_tier: tier2/tier1<br/>reason: xxx)]
        InsertTimeline3[(INSERT timeline<br/>type: escalation<br/>OR type: resolved)]
        NotifyReturn[แจ้งเตือน<br/>Tier2 หรือ Tier1]
    end
    
    Start --> Dashboard
    Dashboard --> ViewNew
    Dashboard --> ViewMyTickets
    
    ViewNew --> AcceptTicket
    AcceptTicket --> CheckEscalation
    CheckEscalation --> ReviewHistory
    ReviewHistory --> AcceptBtn
    AcceptBtn --> UpdateDB1
    UpdateDB1 --> InsertTimeline1
    InsertTimeline1 --> InsertStakeholder1
    InsertStakeholder1 --> NotifyTier2
    NotifyTier2 --> WorkOnTicket
    
    ViewMyTickets --> WorkOnTicket
    WorkOnTicket --> ChangeStatus
    ChangeStatus -->|เริ่มทำ| StartWork
    ChangeStatus -->|เพิ่มข้อความ| AddComment
    ChangeStatus -->|แนบไฟล์| AddAttachment
    ChangeStatus -->|หยุดชั่วคราว| PauseWork
    ChangeStatus -->|ส่งกลับ| ReturnTicket
    StartWork --> UpdateDB2
    AddComment --> UpdateDB2
    AddAttachment --> UpdateDB2
    PauseWork --> UpdateDB2
    UpdateDB2 --> WorkOnTicket
    
    ReturnTicket --> SelectReturn
    SelectReturn -->|Tier2| ReturnT2
    SelectReturn -->|Tier1| ReturnT1
    ReturnT2 --> EnterSolution
    ReturnT1 --> EnterSolution
    EnterSolution --> SelectResolved
    SelectResolved -->|ใช่| UpdateDB3
    SelectResolved -->|ไม่| UpdateDB3
    UpdateDB3 --> InsertEscalation3
    InsertEscalation3 --> InsertTimeline3
    InsertTimeline3 --> NotifyReturn
    NotifyReturn --> End([จบการทำงาน])
    
    style Start fill:#4CAF50,color:#fff
    style End fill:#f44336,color:#fff
    style UpdateDB1 fill:#2196F3,color:#fff
    style UpdateDB2 fill:#2196F3,color:#fff
    style UpdateDB3 fill:#2196F3,color:#fff
    style ReturnTicket fill:#FF9800,color:#fff
    style NotifyReturn fill:#9C27B0,color:#fff
    style WorkOnTicket fill:#673AB7,color:#fff
```

---

### **📊 Tier3 Database Operations**

| Action | SQL Operations | Tables Affected |
|--------|---------------|-----------------|
| **รับเคสจาก Tier2** | UPDATE tickets (assigned_to)<br/>INSERT timeline<br/>INSERT stakeholder | tickets<br/>ticket_timeline<br/>ticket_stakeholders |
| **เริ่มทำงาน** | UPDATE tickets (status) | tickets<br/>ticket_timeline |
| **เพิ่มความคิดเห็น** | INSERT comments (is_internal=TRUE)<br/>INSERT timeline | ticket_comments<br/>ticket_timeline |
| **แนบไฟล์** | INSERT attachments<br/>INSERT timeline | ticket_attachments<br/>ticket_timeline |
| **ส่งกลับ Tier2** | UPDATE tickets (status='tier2')<br/>INSERT escalation_chain<br/>INSERT timeline | tickets<br/>escalation_chain<br/>ticket_timeline |
| **ส่งกลับ Tier1** | UPDATE tickets (status='resolved'/'tier1')<br/>INSERT escalation_chain<br/>INSERT timeline | tickets<br/>escalation_chain<br/>ticket_timeline |

---

### **🎯 Tier3 Visibility Rules**

```sql
-- Tier3 เห็นเคสน้อยสุด (Inverted Visibility)
SELECT * FROM tickets
WHERE 
  -- 1. เคสที่ส่งมาจาก Tier2 (รอรับ)
  (status = 'tier3' AND assigned_to IS NULL
   AND EXISTS (
     SELECT 1 FROM escalation_chain 
     WHERE ticket_id = tickets.id 
     AND to_tier = 'tier3'
     ORDER BY escalated_at DESC
     LIMIT 1
   ))
  
  OR
  
  -- 2. เคสที่ตัวเองรับแล้ว
  (status IN ('tier3', 'in_progress', 'waiting') 
   AND assigned_to = :tier3_user_id)
  
  OR
  
  -- 3. เคสที่ตัวเองเคยเกี่ยวข้อง (stakeholder)
  EXISTS (
    SELECT 1 FROM ticket_stakeholders
    WHERE ticket_id = tickets.id
    AND user_id = :tier3_user_id
  );

-- ❌ Tier3 ไม่เห็น:
-- - เคสใหม่ (status = 'new')
-- - เคสของ Tier1 (status = 'tier1')
-- - เคสของ Tier2 (status = 'tier2') ที่ไม่ได้ส่งมาให้
-- - เคสปิดแล้ว (status = 'closed') เว้นแต่เคยเกี่ยวข้อง
```

---

### **⚠️ Tier3 Restrictions**

```sql
-- ❌ Tier3 ไม่สามารถ:
-- 1. ปิดเคสเอง (ต้องส่งกลับ Tier1)
UPDATE tickets SET status = 'closed' WHERE id = :ticket_id;
-- ❌ REJECT: Only Tier1 can close

-- 2. ส่งต่อเคสต่อ (Tier3 เป็นระดับสูงสุด)
UPDATE tickets SET status = 'tier4' WHERE id = :ticket_id;
-- ❌ REJECT: Tier3 is the highest level

-- 3. รับเคสจาก Tier1 โดยตรง (ต้องผ่าน Tier2)
-- ❌ REJECT: Tier3 only receives from Tier2

-- ✅ Correct way: ส่งกลับ Tier1 พร้อม solution
UPDATE tickets 
SET status = 'resolved', 
    resolved_by = :tier3_user_id, 
    resolved_at = NOW(),
    solution = 'รายละเอียดการแก้ไข...'
WHERE id = :ticket_id;

INSERT INTO escalation_chain (ticket_id, from_tier, to_tier, escalated_by, reason)
VALUES (:ticket_id, 'tier3', 'tier1', :tier3_user_id, 
        'แก้ไขเสร็จแล้วโดย Expert รอ Tier1 ตรวจสอบและปิดเคส');
```

---

<a name="admin"></a>
## 4️⃣ **Admin Data Flow Diagram**

### **📌 บทบาท Admin:**
- ✅ **สร้างเคสใหม่** แทนลูกค้า
- ✅ **แก้ไขเคส** ด้วยตัวเอง
- ✅ **ส่งต่อเคส** ไป Tier1/Tier2/Tier3
- ✅ **ปิดเคส** (สามารถปิดเคสได้ทุก Tier)
- ✅ **เห็นเคสทั้งหมด** (Inverted Visibility)

---

### **🔄 Complete Data Flow Diagram - Admin**

```mermaid
flowchart TB
    Start([เริ่มต้น: Admin Login])
    
    subgraph Dashboard["📊 Admin Dashboard"]
        ViewNew[ดูเคสใหม่<br/>status: new]
        ViewMyTickets[ดูเคสของตัวเอง<br/>status: admin, in_progress]
        ViewReturned[ดูเคสที่ส่งกลับมา<br/>จาก Tier1/2/3]
        ViewResolved[ดูเคสที่แก้ไขแล้ว<br/>status: resolved]
        ViewClosed[ดูเคสที่ปิดแล้ว<br/>status: closed]
    end
    
    subgraph CreateNew["🎯 สร้างเคสใหม่"]
        SelectProject{มี project_id<br/>หรือยัง?}
        ChooseProject[เลือกโครงการ<br/>+ Category<br/>+ Priority<br/>+ Type]
        CreateBtn[กดปุ่ม<br/>'สร้างเคส']
        UpdateDB1[(UPDATE tickets<br/>SET status = 'new'<br/>project_id = selected_project)]
        InsertTimeline1[(INSERT timeline<br/>type: creation<br/>description: Admin สร้างเคส)]
        InsertStakeholder1[(INSERT stakeholder<br/>type: creator)]
        NotifyCustomer1[แจ้งเตือนลูกค้า<br/>Email/LINE]
    end
    
    subgraph WorkOnTicket["🔧 ดำเนินการเคส"]
        ChangeStatus{เลือก Action}
        StartWork[เริ่มทำงาน<br/>status: in_progress]
        AddComment[เพิ่มความคิดเห็น<br/>Public/Internal]
        AddAttachment[แนบไฟล์]
        PauseWork[หยุดชั่วคราว<br/>status: waiting]
        UpdateDB2[(UPDATE tickets<br/>INSERT comments<br/>INSERT attachments<br/>INSERT timeline)]
    end
    
    subgraph Escalate["⬆️ ส่งต่อเคส"]
        SelectTier{ส่งต่อไปที่?}
        EscToT1[ส่งไป Tier1]
        EscToT2[ส่งไป Tier2]
        EscToT3[ส่งไป Tier3]
        EnterReason[กรอกเหตุผล<br/>+ เลือกผู้รับ]
        UpdateDB3[(UPDATE tickets<br/>SET status = 'tier1'/'tier2'/'tier3'<br/>assigned_to = NULL<br/>assigned_by = admin_user_id)]
        InsertEscalation[(INSERT escalation_chain<br/>from_tier: admin<br/>to_tier: tier1/tier2/tier3<br/>reason: xxx)]
        InsertTimeline3[(INSERT timeline<br/>type: escalation)]
        InsertStakeholder3[(INSERT stakeholder<br/>type: escalator)]
        NotifyTier[แจ้งเตือน Tier1/2/3<br/>Email/System]
    end
    
    subgraph ReceiveBack["⬇️ รับเคสกลับ"]
        ViewReturned2[เคสที่ Tier1/2/3<br/>ส่งกลับมา<br/>status: admin<br/>assigned_to: NULL]
        AcceptReturn[กดปุ่ม<br/>'รับเคส']
        UpdateDB4[(UPDATE tickets<br/>SET assigned_to = admin_user_id<br/>status = 'in_progress')]
        InsertTimeline4[(INSERT timeline<br/>type: assignment<br/>description: รับเคสกลับ)]
        CheckSolution{ตรวจสอบ<br/>solution}
    end
    
    subgraph CloseTicket["✅ ปิดเคส (Admin Only)"]
        VerifyCustomer{ลูกค้ายืนยัน<br/>หรือยัง?}
        CheckComments[ตรวจสอบ<br/>comment ลูกค้า]
        EnterSolution[กรอก Solution<br/>+ Closure Notes]
        CloseBtn[กดปุ่ม<br/>'ปิดเคส']
        UpdateDB5[(UPDATE tickets<br/>SET status = 'closed'<br/>closed_by = admin_user_id<br/>closed_at = NOW<br/>solution = xxx<br/>closure_notes = xxx)]
        InsertTimeline5[(INSERT timeline<br/>type: closed)]
        NotifyAll[แจ้งเตือนทุกคน<br/>Customer + Stakeholders]
    end
    
    Start --> Dashboard
    Dashboard --> ViewNew
    Dashboard --> ViewMyTickets
    Dashboard --> ViewReturned
    Dashboard --> ViewResolved
    Dashboard --> ViewClosed
    
    ViewNew --> SelectProject
    SelectProject -->|ไม่มี| ChooseProject
    SelectProject -->|มีแล้ว| CreateBtn
    ChooseProject --> CreateBtn
    CreateBtn --> UpdateDB1
    UpdateDB1 --> InsertTimeline1
    InsertTimeline1 --> InsertStakeholder1
    InsertStakeholder1 --> NotifyCustomer1
    NotifyCustomer1 --> WorkOnTicket
    
    ViewMyTickets --> WorkOnTicket
    WorkOnTicket --> ChangeStatus
    ChangeStatus -->|เริ่มทำ| StartWork
    ChangeStatus -->|เพิ่มข้อความ| AddComment
    ChangeStatus -->|แนบไฟล์| AddAttachment
    ChangeStatus -->|หยุดชั่วคราว| PauseWork
    ChangeStatus -->|ส่งต่อ| Escalate
    ChangeStatus -->|ปิดเคส| CloseTicket
    StartWork --> UpdateDB2
    AddComment --> UpdateDB2
    AddAttachment --> UpdateDB2
    PauseWork --> UpdateDB2
    UpdateDB2 --> WorkOnTicket
    
    Escalate --> SelectTier
    SelectTier -->|Tier1| EscToT1
    SelectTier -->|Tier2| EscToT2
    SelectTier -->|Tier3| EscToT3
    EscToT1 --> EnterReason
    EscToT2 --> EnterReason
    EscToT3 --> EnterReason
    EnterReason --> UpdateDB3
    UpdateDB3 --> InsertEscalation
    InsertEscalation --> InsertTimeline3
    InsertTimeline3 --> InsertStakeholder3
    InsertStakeholder3 --> NotifyTier
    NotifyTier --> Dashboard
    
    ViewReturned --> ReceiveBack
    ReceiveBack --> ViewReturned2
    ViewReturned2 --> AcceptReturn
    AcceptReturn --> UpdateDB4
    UpdateDB4 --> InsertTimeline4
    InsertTimeline4 --> CheckSolution
    CheckSolution -->|พอใจ| CloseTicket
    CheckSolution -->|ไม่พอใจ| Escalate
    CheckSolution -->|ต้องทำต่อ| WorkOnTicket
    
    ViewResolved --> CloseTicket
    CloseTicket --> VerifyCustomer
    VerifyCustomer -->|ยัง| CheckComments
    CheckComments --> VerifyCustomer
    VerifyCustomer -->|แล้ว| EnterSolution
    EnterSolution --> CloseBtn
    CloseBtn --> UpdateDB5
    UpdateDB5 --> InsertTimeline5
    InsertTimeline5 --> NotifyAll
    NotifyAll --> End([จบการทำงาน])
    
    style Start fill:#4CAF50,color:#fff
    style End fill:#f44336,color:#fff
    style UpdateDB1 fill:#2196F3,color:#fff
    style UpdateDB2 fill:#2196F3,color:#fff
    style UpdateDB3 fill:#2196F3,color:#fff
    style UpdateDB4 fill:#2196F3,color:#fff
    style UpdateDB5 fill:#2196F3,color:#fff
    style CloseTicket fill:#FF9800,color:#fff
    style NotifyAll fill:#9C27B0,color:#fff
```

---

<a name="staff"></a>
## 5️⃣ **Staff Data Flow Diagram**

### **📌 บทบาท Staff:**
- ✅ **สร้างเคสใหม่** แทนลูกค้า
- ✅ **ติดตามเคส** ที่ตัวเองสร้าง
- ✅ **ดูเคสที่ปิดแล้ว**
- ❌ **ไม่สามารถแก้ไขเคส**
- ❌ **ไม่สามารถส่งต่อเคส** (ทำได้แค่สร้างและส่งให้ Tier1)

---

### **🔄 Complete Data Flow Diagram - Staff**

```mermaid
flowchart TB
    Start([เริ่มต้น: Staff Login])
    
    subgraph Dashboard["📊 Staff Dashboard"]
        ViewTrack[ติดตามเคสที่ส่งไป<br/>status: any]
        ViewClosed[ดูเคสที่ปิดแล้ว<br/>status: closed]
    end
    
    subgraph CreateTicket["🎯 สร้างเคสใหม่"]
        FillForm[กรอกข้อมูลเคส<br/>แทนลูกค้า]
        SelectProject[เลือกโครงการ<br/>(บังคับ)]
        SubmitBtn[กดปุ่ม<br/>'ส่งเคส']
        UpdateDB1[(INSERT tickets<br/>status = 'new'<br/>created_by = staff_user_id<br/>created_by_type = 'staff_on_behalf')]
        InsertTimeline1[(INSERT timeline<br/>type: creation<br/>description: Staff สร้างเคส)]
        NotifyTier1[แจ้งเตือน Tier1<br/>Email/System]
    end
    
    subgraph TrackTicket["👀 ติดตามเคส"]
        ViewDetail[ดูรายละเอียดเคส]
        ViewStatus[ดูสถานะล่าสุด]
        ViewTimeline[ดู Timeline]
        AddComment[เพิ่มความคิดเห็น<br/>(ถ้าจำเป็น)]
        UpdateDB2[(INSERT comments)]
    end
    
    Start --> Dashboard
    Dashboard --> CreateTicket
    Dashboard --> TrackTicket
    Dashboard --> ViewClosed
    
    CreateTicket --> FillForm
    FillForm --> SelectProject
    SelectProject --> SubmitBtn
    SubmitBtn --> UpdateDB1
    UpdateDB1 --> InsertTimeline1
    InsertTimeline1 --> NotifyTier1
    NotifyTier1 --> TrackTicket
    
    TrackTicket --> ViewDetail
    ViewDetail --> ViewStatus
    ViewStatus --> ViewTimeline
    ViewTimeline --> AddComment
    AddComment --> UpdateDB2
    UpdateDB2 --> ViewDetail
    
    style Start fill:#4CAF50,color:#fff
    style UpdateDB1 fill:#2196F3,color:#fff
    style UpdateDB2 fill:#2196F3,color:#fff
    style CreateTicket fill:#FF9800,color:#fff
    style TrackTicket fill:#9C27B0,color:#fff
```

---

<a name="comparison"></a>
## 6️⃣ **Comparison Matrix**

| Feature | Staff | Tier 1 | Tier 2 | Tier 3 | Admin |
|---------|-------|--------|--------|--------|-------|
| **สร้างเคส** | ✅ (แทนลูกค้า) | ✅ | ✅ | ✅ | ✅ |
| **รับเคสใหม่** | ❌ | ✅ | ❌ | ❌ | ✅ |
| **รับเคสจาก Tier อื่น** | ❌ | ✅ | ✅ | ✅ | ✅ |
| **แก้ไขเคส** | ❌ | ✅ | ✅ | ✅ | ✅ |
| **ส่งต่อเคส** | ❌ | ✅ (T2/T3) | ✅ (T3) | ❌ | ✅ (All) |
| **ส่งกลับเคส** | ❌ | ❌ | ✅ (T1) | ✅ (T2/T1) | ✅ (All) |
| **ปิดเคส** | ❌ | ✅ | ❌ | ❌ | ✅ |
| **Visibility** | Own Only | Inverted (Max) | Inverted (Mid) | Inverted (Min) | All |

---

<a name="state-transition"></a>
## 7️⃣ **State Transition Diagrams**

### **🔄 Ticket Status Lifecycle**

```mermaid
stateDiagram-v2
    [*] --> new: Created
    
    new --> tier1: Accepted by Tier1
    tier1 --> in_progress: Started Work
    tier1 --> tier2: Escalated to T2
    tier1 --> tier3: Escalated to T3
    
    tier2 --> in_progress: Started Work
    tier2 --> tier3: Escalated to T3
    tier2 --> tier1: Returned to T1
    tier2 --> resolved: Resolved by T2
    
    tier3 --> in_progress: Started Work
    tier3 --> tier2: Returned to T2
    tier3 --> tier1: Returned to T1
    tier3 --> resolved: Resolved by T3
    
    in_progress --> waiting: Paused
    waiting --> in_progress: Resumed
    in_progress --> resolved: Solved
    
    resolved --> closed: Verified & Closed
    resolved --> in_progress: Reopened/Rejected
    
    closed --> [*]
```
