# 🔧 Project Code Fix Report

**Date:** 2026-01-23  
**Issue:** Incorrect Project Codes in CSV Tickets Mock Data  
**Status:** 🟡 Partially Fixed

---

## 🔍 **ปัญหาที่พบ:**

Mock Data ของ CSV Tickets ใช้รหัสโครงการ **ไม่ตรงกับมาตรฐาน** ที่กำหนดในเอกสาร `/docs/PROJECT_CODE_FORMAT.md`

### **มาตรฐานที่ถูกต้อง:**
```
รูปแบบ: D{YY}-{NNNN}
- D = ตัวอักษรนำหน้าคงที่
- YY = ปี 2 หลัก (26 = 2026)
- NNNN = เลขที่โครงการ 4 หลัก (0001-9999)
- Sequential ต่อเนื่องทั้งระบบ (ไม่แยกตาม Organization)
```

### **ตัวอย่างถูกต้อง:**
```
D26-0001, D26-0002, D26-0003, ..., D26-0024
```

---

## ❌ **รหัสที่ผิด (Before):**

| Project ID | รหัสเดิม (ผิด) | รหัสที่ถูกต้อง | ไฟล์ |
|-----------|---------------|---------------|------|
| proj-csv-001 | D26-1001 | D26-0001 | mockDataCSVTickets.ts |
| proj-csv-002 | D26-2001 | D26-0002 | mockDataCSVTickets.ts |
| proj-csv-003 | D26-2002 | D26-0003 | mockDataCSVTickets.ts |
| proj-csv-004 | D26-3001 | D26-0005 | mockDataCSVTickets.ts |
| proj-csv-005 | D26-3002 | D26-0006 | mockDataCSVTickets.ts |
| proj-csv-006 | D26-4001 | D26-0007 | mockDataCSVTickets.ts |
| proj-csv-007 | D26-5001 | D26-0008 | mockDataCSVTickets.ts + Part2 |
| proj-csv-008 | D26-6001 | D26-0009 | mockDataCSVTicketsPart2.ts |
| proj-csv-009 | D26-7001 | D26-0010 | mockDataCSVTicketsPart2.ts |
| proj-csv-010 | D26-8001 | D26-0011 | mockDataCSVTicketsPart2.ts |
| proj-csv-011 | D26-9001 | D26-0012 | mockDataCSVTicketsPart2.ts |
| proj-csv-012 | D26-1002 | D26-0013 | mockDataCSVTicketsPart2.ts |
| proj-csv-013 | D26-2003 | D26-0014 | mockDataCSVTicketsPart2.ts |
| proj-csv-014 | D26-9002 | D26-0015 | mockDataCSVTicketsPart2.ts |
| proj-csv-015 | D26-5002 | D26-0016 | mockDataCSVTicketsPart2.ts |
| proj-csv-016 | D26-3003 | D26-0017 | mockDataCSVTicketsPart2.ts |
| proj-csv-017 | D26-1003 | D26-0018 | mockDataCSVTicketsPart2.ts |
| proj-csv-018 | D26-5003 | D26-0019 | mockDataCSVTicketsPart2.ts |
| proj-csv-019 | D26-1004 | D26-0020 | mockDataCSVTicketsPart2.ts |
| proj-csv-020 | D26-6002 | D26-0021 | mockDataCSVTicketsPart2.ts |
| proj-csv-021 | D26-2004 | D26-0022 | mockDataCSVTicketsPart2.ts |
| proj-csv-022 | D26-5004 | D26-0023 | mockDataCSVTicketsPart2.ts |

---

## ✅ **การแก้ไข:**

### **ไฟล์ที่ต้องแก้ไข:**

1. `/lib/mockDataCSVTickets.ts` ✅ แก้ไขบางส่วนแล้ว (D26-0001, D26-0002)
2. `/lib/mockDataCSVTicketsPart2.ts` ❌ ยังต้องแก้ไขต่อ

### **วิธีแก้ไข:**

ใช้ Find & Replace ใน Code Editor:

```bash
# ไฟล์: mockDataCSVTickets.ts
D26-2001 → D26-0002  ✅ แก้แล้ว
D26-2002 → D26-0003
D26-3001 → D26-0005
D26-3002 → D26-0006
D26-4001 → D26-0007
D26-5001 → D26-0008

# ไฟล์: mockDataCSVTicketsPart2.ts
D26-5001 → D26-0008
D26-6001 → D26-0009
D26-7001 → D26-0010
D26-8001 → D26-0011
D26-9001 → D26-0012
D26-1002 → D26-0013
D26-2003 → D26-0014
D26-9002 → D26-0015
D26-5002 → D26-0016
D26-3003 → D26-0017
D26-1003 → D26-0018
D26-5003 → D26-0019
D26-1004 → D26-0020
D26-6002 → D26-0021
D26-2004 → D26-0022
D26-5004 → D26-0023
D26-1001 → D26-0001  (ตัวสุดท้ายในไฟล์)
```

---

## 📋 **Mapping Table (อ้างอิง):**

| Project ID | Organization | Project Code | จำนวน Tickets |
|-----------|-------------|-------------|--------------|
| proj-csv-001 | ERC | D26-0001 | 2 |
| proj-csv-002 | RMUTP | D26-0002 | 2 |
| proj-csv-003 | VRU | D26-0003 | 2 |
| proj-csv-004 | GPO | D26-0005 | 1 |
| proj-csv-005 | FIO | D26-0006 | 2 |
| proj-csv-006 | AMLO | D26-0007 | 3 |
| proj-csv-007 | DOH | D26-0008 | 6 |
| proj-csv-008 | ACFS | D26-0009 | 1 |
| proj-csv-009 | DLPW | D26-0010 | 7 |
| proj-csv-010 | DGA | D26-0011 | 2 |
| proj-csv-011 | SUANLUANG | D26-0012 | 1 |
| proj-csv-012 | OPM | D26-0013 | 4 |
| proj-csv-013 | RMUTK | D26-0014 | 1 |
| proj-csv-014 | KORATPAO | D26-0015 | 1 |
| proj-csv-015 | LDD | D26-0016 | 1 |
| proj-csv-016 | GIF | D26-0017 | 1 |
| proj-csv-017 | NESDC | D26-0018 | 1 |
| proj-csv-018 | DOT | D26-0019 | 2 |
| proj-csv-019 | OTEP | D26-0020 | 3 |
| proj-csv-020 | HSS | D26-0021 | 3 |
| proj-csv-021 | DRU | D26-0022 | 1 |
| proj-csv-022 | MOT | D26-0023 | 3 |

**รวม:** 50 tickets

---

## 🎯 **สถานะการแก้ไข:**

- [x] ตรวจสอบเอกสาร PROJECT_CODE_FORMAT.md
- [x] ตรวจสอบ `/lib/mockData/projects.ts` ✅ ถูกต้อง
- [x] แก้ไข `/lib/mockDataCSVTickets.ts` บางส่วน (2/6)
- [ ] แก้ไข `/lib/mockDataCSVTickets.ts` ให้ครบ (D26-2002, D26-3001, D26-3002, D26-4001, D26-5001)
- [ ] แก้ไข `/lib/mockDataCSVTicketsPart2.ts` ทั้งหมด (~40 จุด)

---

## 💡 **คำแนะนำ:**

### **วิธีที่ 1: ใช้ Code Editor (แนะนำ)**

1. เปิด VS Code
2. กด Ctrl+H (Find & Replace)
3. Replace ทีละรหัส ตามตารางข้างบน
4. ตรวจสอบให้แน่ใจว่าไม่มีรหัสซ้ำ

### **วิธีที่ 2: ใช้ AI Assistant**

1. ขอให้ AI แก้ไข fast_apply_tool ทีละไฟล์

---

## ✅ **Verification:**

หลังแก้ไขเสร็จ ให้ทดสอบ:

1. ✅ ตรวจสอบ Import ทั้งหมดทำงานได้
2. ✅ ไม่มี Error ใน Console
3. ✅ รหัสโครงการแสดงผลถูกต้องในหน้า Ticket Details
4. ✅ Search/Filter Project ทำงานปกติ

---

## 📚 **References:**

- [PROJECT_CODE_FORMAT.md](/docs/technical/PROJECT_CODE_FORMAT.md) - รูปแบบมาตรฐาน
- [/lib/mockData/projects.ts](/lib/mockData/projects.ts) - Projects Mock Data (ถูกต้องแล้ว)

---

**Last Updated:** 2026-01-23  
**Status:** 🟡 Needs Manual Fix  
**Priority:** Medium
