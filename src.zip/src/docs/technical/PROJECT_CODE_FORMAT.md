# 📋 รูปแบบรหัสโครงการ (Project Code Format)

**เอกสารฉบับนี้:** อธิบายรูปแบบรหัสโครงการที่ใช้ในระบบ CDGS Issue Tracking Platform  
**วันที่อัปเดต:** 23 มกราคม 2026  
**เวอร์ชัน:** 1.0

---

## 📌 ภาพรวม

ระบบใช้รูปแบบรหัสโครงการมาตรฐานที่กำหนดโดยบริษัท CDGS โดยมีโครงสร้างที่ชัดเจนและเป็นระเบียบ

---

## 🎯 รูปแบบรหัสโครงการ

### โครงสร้าง
```
D{YY}-{NNNN}
```

### ส่วนประกอบ

| ส่วน | คำอธิบาย | ตัวอย่าง |
|------|----------|----------|
| **D** | ตัวอักษรนำหน้าคงที่ (CDGS/Digital) | D |
| **YY** | ปีคศ. 2 หลักสุดท้าย | 26 (จาก 2026) |
| **-** | เครื่องหมายขีด | - |
| **NNNN** | เลขที่โครงการ 4 หลัก (sequential) | 0001-9999 |

### ตัวอย่าง
- `D26-0001` = โครงการแรกของปี 2026
- `D26-0024` = โครงการที่ 24 ของปี 2026
- `D27-0001` = โครงการแรกของปี 2027

---

## 📊 การแสดงผลในระบบ

### 1. ในรายการโครงการ (Project List)
แสดงรหัสโครงการอย่างเดียว:
```
D26-0003
```

### 2. ในรายละเอียดเคส (Ticket Details)
แสดงชื่อย่อองค์กร + รหัสโครงการ:
```
[ORG_SHORT_NAME] [PROJECT_CODE]

ตัวอย่าง:
- DLPW D26-0009   (กรมสวัสดิการและคุ้มครองแรงงาน)
- VRU D26-0003    (มหาวิทยาลัยราชภัฏวไลยอลงกรณ์)
- DGA D26-0011    (สำนักงานพัฒนารัฐบาลดิจิทัล)
```

### 3. ในรายงาน
แสดงรหัสพร้อมชื่อโครงการ:
```
D26-0003 - โครงการพัฒนาระบบสารบรรณอิเล็กทรอนิกส์
```

---

## 🔧 การสร้างรหัสโครงการใหม่

### ฟังก์ชัน: `generateProjectCode()`

**ที่ตั้ง:** `/lib/utils/projectUtils.ts`

**การทำงาน:**
1. รับ array ของโครงการทั้งหมด
2. รับปีที่ต้องการ (default = ปีปัจจุบัน)
3. นับจำนวนโครงการที่มีในปีนั้น
4. สร้างรหัสใหม่โดยเพิ่มเลขที่ต่อไป

**ตัวอย่างการใช้งาน:**
```typescript
import { generateProjectCode } from './lib/utils/projectUtils';

// สร้างรหัสโครงการใหม่สำหรับปี 2026
const newProjectCode = generateProjectCode(allProjects, 2026);
// ผลลัพธ์: "D26-0025" (ถ้ามี 24 โครงการในปี 2026 แล้ว)
```

**Algorithm:**
```typescript
export function generateProjectCode(
  projects: Project[],
  year: number = new Date().getFullYear()
): string {
  const yearShort = year.toString().slice(-2); // "2026" -> "26"
  const prefix = `D${yearShort}-`;              // "D26-"
  
  // นับโครงการที่มีรหัสขึ้นต้นด้วย prefix นี้
  const projectsInYear = projects.filter(p => 
    p.projectCode.startsWith(prefix)
  );
  const nextNumber = projectsInYear.length + 1;
  
  // Format เป็น 4 หลัก (0001, 0002, ...)
  const numberPadded = nextNumber.toString().padStart(4, '0');
  
  return `${prefix}${numberPadded}`; // "D26-0025"
}
```

---

## 📝 ข้อมูลเพิ่มเติม

### ข้อกำหนดสำคัญ
- ✅ รหัสโครงการต้องไม่ซ้ำกัน (Unique)
- ✅ เลขที่เป็น Sequential ต่อเนื่องตามปี
- ✅ ไม่แยกตาม Organization (เลขต่อเนื่องทั้งระบบ)
- ✅ เมื่อปีใหม่ เลขที่เริ่มต้นที่ 0001 ใหม่

### ข้อควรระวัง
- ⚠️ ห้ามสร้างรหัสโครงการด้วยตนเอง (Manual)
- ⚠️ ต้องใช้ฟังก์ชัน `generateProjectCode()` เสมอ
- ⚠️ ตรวจสอบว่าไม่มีรหัสซ้ำก่อนบันทึกลงฐานข้อมูล

---

## 🗂️ ตัวอย่าง Mock Data

**ที่ตั้ง:** `/lib/mockData/projects.ts`

```typescript
export const csvProjects: Project[] = [
  {
    id: 'proj-csv-001',
    organizationId: 'org-csv-001',
    projectCode: 'D26-0001', // ✅ รูปแบบใหม่
    projectName: 'โครงการหลัก - สำนักงานคณะกรรมการกำกับกิจการพลังงาน',
    projectStatus: 'active',
    startDate: new Date('2026-01-01'),
    createdAt: new Date('2026-01-01'),
    updatedAt: new Date('2026-01-01')
  },
  {
    id: 'proj-csv-002',
    organizationId: 'org-csv-002',
    projectCode: 'D26-0002', // ✅ รูปแบบใหม่
    projectName: 'โครงการหลัก - มหาวิทยาลัยเทคโนโลยีราชมงคลพระนคร',
    projectStatus: 'active',
    startDate: new Date('2026-01-01'),
    createdAt: new Date('2026-01-01'),
    updatedAt: new Date('2026-01-01')
  },
  // ... อีก 22 โครงการ
];
```

---

## 🔄 ประวัติการเปลี่ยนแปลง

### Version 1.0 (23 มกราคม 2026)
- ✅ กำหนดรูปแบบรหัสโครงการมาตรฐาน: `D{YY}-{NNNN}`
- ✅ แปลงรหัสโครงการเดิม `PRJ-{ORG}-{YYYY}-{NNN}` เป็นรูปแบบใหม่
- ✅ อัปเดต Mock Data ทั้ง 24 โครงการ
- ✅ สร้างฟังก์ชัน `generateProjectCode()` สำหรับสร้างรหัสใหม่
- ✅ อัปเดต Type Definition และ Utility Functions

---

## 📚 เอกสารที่เกี่ยวข้อง

- [Project Overview](/docs/features/PROJECT_OVERVIEW.md) - ภาพรวมโครงสร้างโปรเจกต์
- [Database Schema](/DATABASE_SCHEMA_DESIGN.md) - โครงสร้างฐานข้อมูล
- [Mock Data Guide](/docs/technical/MOCK_DATA_GUIDE.md) - คู่มือข้อมูลทดสอบ

---

## 👥 ผู้รับผิดชอบ

- **สร้างโดย:** CDGS Development Team
- **อนุมัติโดย:** Project Manager
- **ติดต่อ:** สอบถามเพิ่มเติมที่ทีม Development

---

**หมายเหตุ:** เอกสารนี้เป็นส่วนหนึ่งของ CDGS Issue Tracking Platform Documentation และต้องอัปเดตทุกครั้งที่มีการเปลี่ยนแปลงรูปแบบรหัสโครงการ
