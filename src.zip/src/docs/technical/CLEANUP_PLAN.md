# 🧹 Documentation Cleanup Plan

**Created:** 2025-01-22  
**Status:** Pending Approval  
**Total Files to Process:** 70+ files

---

## 📊 Summary

| Action | Files | Description |
|--------|-------|-------------|
| **ลบ** | 35 files | ไฟล์เก่า, ซ้ำซ้อน, ล้าสมัย |
| **รวม** | 25 files → 8 files | รวมเรื่องเดียวกัน |
| **ย้าย** | 10 files | ย้ายเข้า /docs/ ที่เหมาะสม |
| **เก็บ** | 10 files | เก็บไว้ที่ root (สำคัญ) |

---

## 🗂️ กลุ่มที่ 1: MOCKDATA FILES (10 files → 1 file)

### ✅ รวมเป็นไฟล์เดียว:
**ไฟล์ใหม่:** `/docs/technical/MOCK_DATA_GUIDE.md`

### 📄 ไฟล์ที่จะรวม:

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 1 | `MOCKDATA_COMPLETE_FIX_SUMMARY.md` | Fix report เก่า | ✅ รวม |
| 2 | `MOCKDATA_CREATOR_TYPE_UPDATE.md` | Fix report เก่า | ✅ รวม |
| 3 | `MOCKDATA_FIX_REPORT.md` | Fix report เก่า | ✅ รวม |
| 4 | `MOCKUP_DATA_MAP.md` | ชื่อผิด (ควรเป็น MOCKDATA) | ✅ รวม |
| 5 | `MOCK_DATA_MAP.md` | ซ้ำกับข้างบน | ✅ รวม |
| 6 | `MOCK_DATA_MIGRATION_CHECKLIST.md` | เสร็จแล้ว | ✅ รวม |
| 7 | `MOCK_DATA_QUICK_REF.md` | สำคัญ - เก็บไว้ | ✅ รวม |
| 8 | `MOCK_DATA_REFACTORING.md` | เสร็จแล้ว | ✅ รวม |
| 9 | `MOCK_DATA_STRUCTURE.md` | สำคัญ - เก็บไว้ | ✅ รวม |
| 10 | `MOCK_DATA_SUMMARY.md` | สำคัญ - เก็บไว้ | ✅ รวม |

**📌 เหตุผล:** ทั้งหมดพูดถึงเรื่อง Mock Data, รวมกันเป็น 1 ไฟล์จะหาง่ายกว่า

---

## 🗂️ กลุ่มที่ 2: CHARACTER ENCODING (2 files → 1 file)

### ❌ ลบไฟล์เก่า:

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 1 | `CHARACTER_ENCODING_FIX.md` | Version เก่า | ❌ ลบ |

### ✅ เก็บและย้าย:

| # | ไฟล์ | ย้ายไป | Action |
|---|------|---------|--------|
| 2 | `CHARACTER_ENCODING_FIX_V2.md` | `/docs/changelog/CHARACTER_ENCODING_FIX.md` | ✅ ย้าย |

**📌 เหตุผล:** มี V2 แล้ว, V1 ไม่จำเป็น

---

## 🗂️ กลุ่มที่ 3: LOGOUT BUG FIX (3 files → 1 file)

### ❌ ลบไฟล์เก่า:

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 1 | `LOGOUT_BUG_FIX.md` | Version เก่า | ❌ ลบ |

### ✅ รวมและย้าย:

| # | ไฟล์ | Action |
|---|------|--------|
| 2 | `LOGOUT_BUG_FIX_V2.md` | ✅ รวม |
| 3 | `LOGOUT_TEST_REPORT.md` | ✅ รวม |

**ไฟล์ใหม่:** `/docs/changelog/LOGOUT_BUG_FIX.md` (รวม V2 + Test Report)

**📌 เหตุผล:** Bug fix และ test report ควรอยู่ไฟล์เดียวกัน

---

## 🗂️ กลุ่มที่ 4: CUSTOMER/USER DATA (7 files → 2 files)

### ❌ ลบไฟล์เก่า/ซ้ำ:

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 1 | `CUSTOMER_NAME_FIX_FINAL.md` | Fix report เก่า | ❌ ลบ |
| 2 | `UPDATE_CUSTOMER_NAME.md` | ซ้ำกับข้างบน | ❌ ลบ |
| 3 | `USERS_FROM_LOGIN_PAGE.md` | ไม่ใช้แล้ว | ❌ ลบ |
| 4 | `USER_SUMMARY_001-012.md` | ข้อมูลเก่า | ❌ ลบ |
| 5 | `FULLNAME_USAGE_CHECKLIST.md` | เสร็จแล้ว | ❌ ลบ |
| 6 | `COMPONENT_INVENTORY_AND_FULLNAME_SUMMARY.md` | Component inventory แยกไฟล์แล้ว | ❌ ลบ |

### ✅ เก็บและย้าย:

| # | ไฟล์ | ย้ายไป | Action |
|---|------|---------|--------|
| 7 | `USER_LIST.md` | `/docs/team/USER_LIST.md` | ✅ ย้าย |

**📌 เหตุผล:** USER_LIST ยังใช้อยู่, ที่เหลือเป็น fix reports เก่า

---

## 🗂️ กลุ่มที่ 5: DATABASE (6 files → 2 files)

### ✅ เก็บและย้าย (ไฟล์หลัก):

| # | ไฟล์ | ย้ายไป | Action |
|---|------|---------|--------|
| 1 | `DATABASE_SCHEMA_DESIGN.md` | `/docs/technical/DATABASE_SCHEMA.md` | ✅ ย้าย |
| 2 | `ER_DIAGRAM.md` | `/docs/technical/ER_DIAGRAM.md` | ✅ ย้าย |

### ❌ ลบไฟล์ย่อย:

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 3 | `DATABASE_NORMALIZATION_ANALYSIS.md` | Analysis เก่า | ❌ ลบ |
| 4 | `DATABASE_TABLE_LAYOUTS.md` | มีใน SCHEMA แล้ว | ❌ ลบ |
| 5 | `ADDITIONAL_TABLES_ANALYSIS.md` | Analysis เก่า | ❌ ลบ |
| 6 | `TABLES_WITH_ASSIGNEE_COLUMN.md` | ไม่จำเป็น | ❌ ลบ |

**📌 เหตุผล:** ข้อมูล database หลักอยู่ใน SCHEMA และ ER_DIAGRAM แล้ว

---

## 🗂️ กลุ่มที่ 6: ATTACHMENT/FILES (2 files → 1 file)

### ✅ รวมและย้าย:

| # | ไฟล์ | Action |
|---|------|--------|
| 1 | `ATTACHMENT_FEATURE_REPORT.md` | ✅ รวม |
| 2 | `ATTACHMENT_UPDATE_V2.md` | ✅ รวม |

**ไฟล์ใหม่:** `/docs/features/ATTACHMENT_SYSTEM.md`

**📌 เหตุผล:** รวมเรื่อง Attachment เป็นเอกสารเดียว

---

## 🗂️ กลุ่มที่ 7: DATA FIX REPORTS (4 files → DELETE ALL)

### ❌ ลบทั้งหมด (Fix reports เก่า):

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 1 | `DATA_CONSISTENCY_REPORT.md` | Fix report เก่า | ❌ ลบ |
| 2 | `DATA_FIX_REPORT.md` | Fix report เก่า | ❌ ลบ |
| 3 | `EMAIL_MOCK_DATA_FIX.md` | Fix report เก่า | ❌ ลบ |
| 4 | `MAPPING_FIX_REPORT.md` | Fix report เก่า | ❌ ลบ |

**📌 เหตุผล:** แก้เสร็จแล้ว, ไม่ต้องเก็บ fix reports เก่า

---

## 🗂️ กลุ่มที่ 8: SUMMARY/IMPLEMENTATION (5 files → DELETE)

### ❌ ลบทั้งหมด (เอกสารระหว่างพัฒนา):

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 1 | `SUMMARY_CREATOR_TYPE_IMPLEMENTATION.md` | Implementation เสร็จแล้ว | ❌ ลบ |
| 2 | `SUMMARY_FULLNAME_AND_COMPONENTS.md` | Implementation เสร็จแล้ว | ❌ ลบ |
| 3 | `BACKLOG_FIX_SUMMARY.md` | เสร็จแล้ว | ❌ ลบ |
| 4 | `ADD_FILE_COLUMN_SUMMARY.md` | เสร็จแล้ว | ❌ ลบ |
| 5 | `FILTER_ISSUE_REPORT.md` | แก้เสร็จแล้ว | ❌ ลบ |

**📌 เหตุผล:** เป็นเอกสารระหว่างทำ, ทำเสร็จแล้วไม่จำเป็น

---

## 🗂️ กลุ่มที่ 9: UPDATE REPORTS (3 files → 1 file)

### ✅ รวมและย้าย:

| # | ไฟล์ | Action |
|---|------|--------|
| 1 | `CUSTOMER_REGISTRATION_TIER1_TRIAGE_UPDATE.md` | ✅ ย้ายไป /docs/ |
| 2 | `STAFF_ROLE_UPDATE_2026-01-21.md` | ✅ รวมใน CHANGELOG |

### ❌ ลบ:

| # | ไฟล์ | สาเหตุ | Action |
|---|------|--------|--------|
| 3 | `PROJECT_SELECTION_REQUIRED_UPDATE.md` | เสร็จแล้ว | ❌ ลบ |

**📌 เหตุผล:** Update reports ควรอยู่ใน CHANGELOG

---

## 🗂️ กลุ่มที่ 10: MENU/VISIBILITY (3 files → 1 file)

### ✅ รวมและย้าย:

| # | ไฟล์ | Action |
|---|------|--------|
| 1 | `VISIBILITY_AND_MENU_SUMMARY.md` | ✅ รวม |
| 2 | `VISIBILITY_MENU_COMPARISON.md` | ✅ รวม |
| 3 | `MENU_DESIGN_ANALYSIS.md` | ✅ รวม |

**ไฟล์ใหม่:** `/docs/design/MENU_AND_VISIBILITY.md`

**📌 เหตุผล:** ทั้งหมดพูดถึงเมนูและ visibility

---

## 🗂️ กลุ่มที่ 11: SPECIFIC FEATURES (ย้าย)

### ✅ ย้ายไป /docs/features/:

| # | ไฟล์ | ย้ายไป | Action |
|---|------|---------|--------|
| 1 | `PENDING_MENU_UPDATE.md` | `/docs/features/PENDING_MENU.md` | ✅ ย้าย |
| 2 | `RESOLVED_MENU_TIER2_TIER3.md` | `/docs/features/RESOLVED_MENU.md` | ✅ ย้าย |
| 3 | `TIMELINE_FILTER_IMPLEMENTATION.md` | `/docs/features/TIMELINE_FILTER.md` | ✅ ย้าย |
| 4 | `STEP1_CREATE_TICKET_CHANGES.md` | `/docs/features/CREATE_TICKET.md` | ✅ ย้าย |

**📌 เหตุผล:** เป็น feature documentation ควรอยู่ใน /docs/features/

---

## 🗂️ กลุ่มที่ 12: IMPORTANT DOCS (เก็บไว้ที่ root)

### ✅ เก็บไว้ (ไฟล์สำคัญ):

| # | ไฟล์ | สาเหตุ | Location |
|---|------|--------|----------|
| 1 | `README.md` | Main README | ✅ Root |
| 2 | `CHANGELOG.md` | Changelog หลัก | ✅ Root |
| 3 | `DEPLOYMENT_GUIDE.md` | ย้ายไป /docs/technical/ | ✅ ย้าย |
| 4 | `REQUIREMENT_CHECKLIST.md` | ย้ายไป /docs/requirements/ | ✅ ย้าย |

---

## 📋 สรุปแผนการดำเนินการ

### Phase 1: ลบไฟล์ (35 files)
```bash
# Fix Reports เก่า
rm CHARACTER_ENCODING_FIX.md
rm LOGOUT_BUG_FIX.md
rm DATA_CONSISTENCY_REPORT.md
rm DATA_FIX_REPORT.md
rm EMAIL_MOCK_DATA_FIX.md
rm MAPPING_FIX_REPORT.md

# Implementation Reports เก่า
rm SUMMARY_CREATOR_TYPE_IMPLEMENTATION.md
rm SUMMARY_FULLNAME_AND_COMPONENTS.md
rm BACKLOG_FIX_SUMMARY.md
rm ADD_FILE_COLUMN_SUMMARY.md
rm FILTER_ISSUE_REPORT.md

# Customer/User ไฟล์เก่า
rm CUSTOMER_NAME_FIX_FINAL.md
rm UPDATE_CUSTOMER_NAME.md
rm USERS_FROM_LOGIN_PAGE.md
rm USER_SUMMARY_001-012.md
rm FULLNAME_USAGE_CHECKLIST.md
rm COMPONENT_INVENTORY_AND_FULLNAME_SUMMARY.md

# Database ไฟล์ย่อย
rm DATABASE_NORMALIZATION_ANALYSIS.md
rm DATABASE_TABLE_LAYOUTS.md
rm ADDITIONAL_TABLES_ANALYSIS.md
rm TABLES_WITH_ASSIGNEE_COLUMN.md

# อื่นๆ
rm PROJECT_SELECTION_REQUIRED_UPDATE.md
```

### Phase 2: รวมไฟล์ (25 files → 8 files)

1. **MOCK_DATA_GUIDE.md** (รวม 10 files)
2. **LOGOUT_BUG_FIX.md** (รวม 2 files)
3. **ATTACHMENT_SYSTEM.md** (รวม 2 files)
4. **MENU_AND_VISIBILITY.md** (รวม 3 files)

### Phase 3: ย้ายไฟล์ (10 files)

```bash
# ย้ายไป /docs/technical/
mv DATABASE_SCHEMA_DESIGN.md docs/technical/DATABASE_SCHEMA.md
mv ER_DIAGRAM.md docs/technical/ER_DIAGRAM.md
mv DEPLOYMENT_GUIDE.md docs/technical/DEPLOYMENT_GUIDE.md
mv LARAVEL_MIGRATIONS_GUIDE.md docs/technical/LARAVEL_MIGRATIONS.md

# ย้ายไป /docs/team/
mv USER_LIST.md docs/team/USER_LIST.md

# ย้ายไป /docs/features/
mv PENDING_MENU_UPDATE.md docs/features/PENDING_MENU.md
mv RESOLVED_MENU_TIER2_TIER3.md docs/features/RESOLVED_MENU.md
mv TIMELINE_FILTER_IMPLEMENTATION.md docs/features/TIMELINE_FILTER.md
mv STEP1_CREATE_TICKET_CHANGES.md docs/features/CREATE_TICKET.md

# ย้ายไป /docs/changelog/
mv CHARACTER_ENCODING_FIX_V2.md docs/changelog/CHARACTER_ENCODING_FIX.md
```

---

## ✅ ผลลัพธ์ที่คาดหวัง

| Before | After | Reduction |
|--------|-------|-----------|
| 70+ files | ~25 files | **-64%** |
| ไม่เป็นระเบียบ | เป็นระบบ | ✅ |
| ยากหา | หาง่าย | ✅ |

---

## ⚠️ คำเตือน

**ก่อนดำเนินการ:**
1. ✅ Backup ทั้งหมดก่อน
2. ✅ Review แผนนี้อีกครั้ง
3. ✅ ขออนุมัติจากทีม

**หลังดำเนินการ:**
1. ✅ Update README.md
2. ✅ Update INDEX.md
3. ✅ Test ว่าลิงก์ทั้งหมดยังใช้งานได้

---

**ต้องการให้ดำเนินการหรือไม่?**
- ✅ ยืนยัน → เริ่มทำได้เลย
- ⏸️ Review → ตรวจสอบอีกครั้ง
- ❌ ยกเลิก → ไม่ทำ
