# 🗄️ CDGS Issue Tracking Platform - ER Diagram

**วันที่:** 17 มกราคม 2026  
**Database:** MySQL/MariaDB  
**ตาราง:** 11 ตาราง

---

## 📊 **ER Diagram แบบสมบูรณ์ (Complete)**

```mermaid
erDiagram
    USERS ||--o{ USER_ROLES : "has"
    USERS ||--o{ USER_PROJECTS : "assigned to"
    USERS ||--o{ TICKETS : "creates/assigned"
    USERS ||--o{ TICKET_COMMENTS : "writes"
    USERS ||--o{ TICKET_ATTACHMENTS : "uploads"
    USERS ||--o{ ESCALATION_CHAIN : "escalates"
    USERS ||--o{ TICKET_STAKEHOLDERS : "involved in"
    USERS ||--o{ TICKET_VIEWERS : "views"
    USERS ||--o{ TICKET_TIMELINE : "performs"
    USERS ||--o{ USERS : "manages (self-ref)"
    
    PROJECTS ||--o{ USER_PROJECTS : "has members"
    PROJECTS ||--o{ TICKETS : "contains"
    
    TICKETS ||--o{ TICKET_TIMELINE : "has history"
    TICKETS ||--o{ TICKET_COMMENTS : "has comments"
    TICKETS ||--o{ TICKET_ATTACHMENTS : "has files"
    TICKETS ||--o{ ESCALATION_CHAIN : "escalated"
    TICKETS ||--o{ TICKET_STAKEHOLDERS : "involves"
    TICKETS ||--o{ TICKET_VIEWERS : "viewed by"
    
    TICKET_COMMENTS ||--o{ TICKET_ATTACHMENTS : "has files"
    
    USERS {
        varchar id PK
        varchar username UK
        varchar email UK
        varchar full_name
        varchar phone
        varchar department
        enum primary_role
        tinyint tier
        varchar manager_id FK
        varchar senior_manager_id FK
        varchar manager_email
        timestamp created_at
        timestamp updated_at
    }
    
    USER_ROLES {
        int id PK
        varchar user_id FK
        enum role
        timestamp created_at
    }
    
    PROJECTS {
        varchar id PK
        varchar code UK
        varchar name
        varchar short_name
        varchar department
        text description
        timestamp created_at
        timestamp updated_at
    }
    
    USER_PROJECTS {
        int id PK
        varchar user_id FK
        varchar project_id FK
        timestamp created_at
    }
    
    TICKETS {
        varchar id PK
        varchar ticket_number UK
        varchar title
        text description
        enum status
        enum type
        enum channel
        enum priority
        varchar category
        varchar product
        varchar department
        varchar customer_name
        varchar customer_email
        varchar customer_phone
        varchar assigned_to FK
        varchar assigned_by FK
        timestamp assigned_at
        varchar previous_assignee FK
        varchar project_id FK
        varchar project_code
        varchar project_name
        varchar project_short_name
        varchar created_by FK
        varchar created_by_name
        enum created_by_type
        varchar created_by_staff_name
        timestamp created_at
        timestamp updated_at
        timestamp due_date
        timestamp resolved_at
        varchar resolved_by FK
        timestamp closed_at
        varchar closed_by FK
        text solution
        text closure_notes
    }
    
    TICKET_TIMELINE {
        varchar id PK
        varchar ticket_id FK
        timestamp timestamp
        enum event_type
        varchar action
        text description
        varchar user_id FK
        varchar user_name
        varchar assigned_to_user_id FK
        varchar assigned_to_user_name
        varchar status
        boolean is_internal
    }
    
    TICKET_COMMENTS {
        varchar id PK
        varchar ticket_id FK
        varchar author_id FK
        varchar author_name
        enum author_role
        text content
        boolean is_internal
        timestamp created_at
        timestamp updated_at
    }
    
    TICKET_ATTACHMENTS {
        varchar id PK
        varchar ticket_id FK
        varchar comment_id FK
        varchar filename
        bigint file_size
        varchar file_type
        varchar file_url
        varchar uploaded_by FK
        timestamp uploaded_at
    }
    
    ESCALATION_CHAIN {
        int id PK
        varchar ticket_id FK
        enum from_tier
        enum to_tier
        varchar escalated_by FK
        varchar escalated_by_name
        timestamp escalated_at
        text reason
    }
    
    TICKET_STAKEHOLDERS {
        int id PK
        varchar ticket_id FK
        varchar user_id FK
        varchar full_name
        enum role
        tinyint tier
        enum type
        timestamp added_at
    }
    
    TICKET_VIEWERS {
        int id PK
        varchar ticket_id FK
        varchar user_id FK
        varchar full_name
        varchar role
        timestamp viewing_since
    }
```

---

## 🔵 **ER Diagram แบบแยกส่วน (Modular)**

### **1️⃣ User Management System**

```mermaid
erDiagram
    USERS ||--o{ USER_ROLES : "1:N"
    USERS ||--o{ USER_PROJECTS : "1:N"
    USERS ||--o{ USERS : "manager (self-ref)"
    PROJECTS ||--o{ USER_PROJECTS : "1:N"
    
    USERS {
        varchar id PK "UUID"
        varchar username UK "Unique"
        varchar email UK "Unique"
        varchar full_name "ชื่อ-นามสกุล"
        varchar phone "เบอร์โทร"
        varchar department "หน่วยงาน"
        enum primary_role "บทบาทหลัก"
        tinyint tier "ระดับ 1-3"
        varchar manager_id FK "หัวหน้าระดับ 1"
        varchar senior_manager_id FK "หัวหน้าระดับ 2"
        varchar manager_email "อีเมลหัวหน้า"
    }
    
    USER_ROLES {
        int id PK
        varchar user_id FK
        enum role "customer|staff|tier1|tier2|tier3|admin"
    }
    
    PROJECTS {
        varchar id PK
        varchar code UK "รหัสโครงการ"
        varchar name "ชื่อเต็ม"
        varchar short_name "ชื่อย่อ"
        varchar department "หน่วยงาน"
    }
    
    USER_PROJECTS {
        int id PK
        varchar user_id FK
        varchar project_id FK
    }
```

**คำอธิบาย:**
- **USERS** ↔ **USERS**: Self-reference สำหรับ Manager Hierarchy
- **USERS** ↔ **USER_ROLES**: Multi-role (1 user → หลาย role)
- **USERS** ↔ **USER_PROJECTS**: Multi-project (1 user → หลายโครงการ)
- **PROJECTS** ↔ **USER_PROJECTS**: 1 โครงการมีหลายคน

---

### **2️⃣ Core Ticket System**

```mermaid
erDiagram
    USERS ||--o{ TICKETS : "creates/assigns"
    PROJECTS ||--o{ TICKETS : "contains"
    TICKETS ||--o{ TICKET_TIMELINE : "has history"
    TICKETS ||--o{ TICKET_COMMENTS : "has comments"
    TICKETS ||--o{ TICKET_ATTACHMENTS : "has files"
    
    USERS {
        varchar id PK
        varchar full_name
        enum primary_role
    }
    
    PROJECTS {
        varchar id PK
        varchar code
        varchar name
    }
    
    TICKETS {
        varchar id PK "UUID"
        varchar ticket_number UK "CDGS-2025-0001"
        varchar title "หัวเรื่อง"
        text description "รายละเอียด"
        enum status "new|tier1|tier2|tier3|in_progress|waiting|resolved|closed"
        enum type "incident|service_request|security_incident"
        enum channel "web|email|line|phone"
        enum priority "low|medium|high|critical"
        varchar category "หมวดหมู่"
        varchar customer_name "ชื่อลูกค้า"
        varchar customer_email "อีเมลลูกค้า"
        varchar assigned_to FK "ผู้รับผิดชอบ"
        varchar assigned_by FK "ผู้มอบหมาย"
        varchar project_id FK "โครงการ"
        varchar created_by FK "ผู้สร้าง"
        enum created_by_type "customer_self|staff_on_behalf"
        timestamp created_at "วันที่สร้าง"
        timestamp due_date "กำหนดเสร็จ SLA"
        varchar closed_by FK "ผู้ปิดเคส"
        text solution "วิธีแก้ไข"
    }
    
    TICKET_TIMELINE {
        varchar id PK
        varchar ticket_id FK
        enum event_type "created|status_change|comment|escalation|assignment|attachment|resolved|closed"
        text description "คำอธิบาย"
        varchar user_id FK "ผู้กระทำ"
        timestamp timestamp "เวลา"
        boolean is_internal "ซ่อนจากลูกค้า"
    }
    
    TICKET_COMMENTS {
        varchar id PK
        varchar ticket_id FK
        varchar author_id FK "ผู้เขียน"
        text content "เนื้อหา"
        boolean is_internal "ซ่อนจากลูกค้า"
        timestamp created_at
    }
    
    TICKET_ATTACHMENTS {
        varchar id PK
        varchar ticket_id FK
        varchar filename "ชื่อไฟล์"
        bigint file_size "ขนาด bytes"
        varchar file_type "MIME type"
        varchar file_url "URL S3"
        varchar uploaded_by FK
    }
```

**คำอธิบาย:**
- **TICKETS** เป็นตารางหลัก (Core Table)
- **TIMELINE** เก็บทุกการเปลี่ยนแปลง (Audit Trail)
- **COMMENTS** แยก Public/Internal
- **ATTACHMENTS** ไฟล์แนบ (เก็บ URL ใน S3/Cloud)

---

### **3️⃣ Escalation & Stakeholder System**

```mermaid
erDiagram
    TICKETS ||--o{ ESCALATION_CHAIN : "escalated"
    TICKETS ||--o{ TICKET_STAKEHOLDERS : "involves"
    TICKETS ||--o{ TICKET_VIEWERS : "viewed by"
    USERS ||--o{ ESCALATION_CHAIN : "escalates"
    USERS ||--o{ TICKET_STAKEHOLDERS : "is stakeholder"
    USERS ||--o{ TICKET_VIEWERS : "views"
    
    TICKETS {
        varchar id PK
        varchar ticket_number
        enum status
    }
    
    USERS {
        varchar id PK
        varchar full_name
        enum primary_role
    }
    
    ESCALATION_CHAIN {
        int id PK "Auto increment"
        varchar ticket_id FK
        enum from_tier "tier1|tier2|tier3"
        enum to_tier "tier1|tier2|tier3"
        varchar escalated_by FK "ผู้ส่งต่อ"
        varchar escalated_by_name "ชื่อผู้ส่งต่อ"
        timestamp escalated_at "เวลาส่งต่อ"
        text reason "เหตุผล"
    }
    
    TICKET_STAKEHOLDERS {
        int id PK
        varchar ticket_id FK
        varchar user_id FK
        varchar full_name
        enum type "creator|escalator|current_owner"
        timestamp added_at
    }
    
    TICKET_VIEWERS {
        int id PK
        varchar ticket_id FK
        varchar user_id FK
        varchar full_name "ชื่อผู้ดู"
        varchar role "บทบาท"
        timestamp viewing_since "เริ่มดูเมื่อ"
    }
```

**คำอธิบาย:**
- **ESCALATION_CHAIN**: เก็บประวัติการส่งต่อ (Tier1 → Tier2 → Tier3)
- **TICKET_STAKEHOLDERS**: ผู้เกี่ยวข้อง (creator, escalator, owner)
- **TICKET_VIEWERS**: ผู้ดูแบบ Read-only (ไม่ใช่เจ้าของ)

---

## 📐 **Cardinality Summary**

| From → To | Type | Cardinality | Description |
|-----------|------|-------------|-------------|
| **USERS** → **USER_ROLES** | One-to-Many | 1:N | 1 user มีหลาย role |
| **USERS** → **USER_PROJECTS** | One-to-Many | 1:N | 1 user ทำหลายโครงการ |
| **USERS** → **TICKETS** | One-to-Many | 1:N | 1 user สร้าง/รับหลายเคส |
| **PROJECTS** → **TICKETS** | One-to-Many | 1:N | 1 โครงการมีหลายเคส |
| **TICKETS** → **TICKET_TIMELINE** | One-to-Many | 1:N | 1 เคสมีหลาย event |
| **TICKETS** → **TICKET_COMMENTS** | One-to-Many | 1:N | 1 เคสมีหลาย comment |
| **TICKETS** → **TICKET_ATTACHMENTS** | One-to-Many | 1:N | 1 เคสมีหลายไฟล์ |
| **TICKETS** → **ESCALATION_CHAIN** | One-to-Many | 1:N | 1 เคสส่งต่อได้หลายครั้ง |
| **TICKETS** → **TICKET_STAKEHOLDERS** | One-to-Many | 1:N | 1 เคสมีหลายผู้เกี่ยวข้อง |
| **TICKETS** → **TICKET_VIEWERS** | One-to-Many | 1:N | 1 เคสมีหลายผู้ดู |

---

## 🔑 **Foreign Key Constraints**

### **Critical Foreign Keys:**

```sql
-- User Management
ALTER TABLE user_roles ADD FOREIGN KEY (user_id) 
    REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE user_projects ADD FOREIGN KEY (user_id) 
    REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE user_projects ADD FOREIGN KEY (project_id) 
    REFERENCES projects(id) ON DELETE CASCADE;

-- Ticket Assignment
ALTER TABLE tickets ADD FOREIGN KEY (assigned_to) 
    REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE tickets ADD FOREIGN KEY (created_by) 
    REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE tickets ADD FOREIGN KEY (project_id) 
    REFERENCES projects(id) ON DELETE SET NULL;

-- Timeline & Comments
ALTER TABLE ticket_timeline ADD FOREIGN KEY (ticket_id) 
    REFERENCES tickets(id) ON DELETE CASCADE;

ALTER TABLE ticket_comments ADD FOREIGN KEY (ticket_id) 
    REFERENCES tickets(id) ON DELETE CASCADE;

-- Escalation
ALTER TABLE escalation_chain ADD FOREIGN KEY (ticket_id) 
    REFERENCES tickets(id) ON DELETE CASCADE;
```

---

## 🎨 **Visual ER Diagram (Simplified)**

```
┌──────────────────────────────────────────────────────────────┐
│                      USER MANAGEMENT                          │
│                                                              │
│  ┌────────┐                                                  │
│  │ USERS  │◄──── (manager_id) Self-reference                │
│  └───┬────┘                                                  │
│      │                                                       │
│      ├──► USER_ROLES (N)     ← Multi-role                  │
│      │                                                       │
│      └──► USER_PROJECTS (N)  ← Multi-project               │
│              │                                                │
│              ▼                                                │
│          PROJECTS                                            │
└──────────────────────────────────────────────────────────────┘
                              │
                              │ (project_id)
                              ▼
┌──────────────────────────────────────────────────────────────┐
│                      TICKET SYSTEM                            │
│                                                              │
│              ┌─────────────┐                                 │
│              │   TICKETS   │ ◄── CORE TABLE                  │
│              └──────┬──────┘                                 │
│                     │                                         │
│    ┌────────────────┼────────────────────────┐              │
│    │                │                        │              │
│    ▼                ▼                        ▼              │
│  TIMELINE       COMMENTS                ATTACHMENTS          │
│  (History)      (Public/Internal)       (Files)             │
│                                                              │
│    ▼                ▼                        ▼              │
│  ESCALATION     STAKEHOLDERS            VIEWERS              │
│  (Tier Chain)   (Involved)              (Read-only)         │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔍 **Index Strategy**

### **Primary Indexes:**
```sql
-- Unique identifiers
tickets.ticket_number (UNIQUE)
users.username (UNIQUE)
users.email (UNIQUE)
projects.code (UNIQUE)

-- Foreign keys (auto-indexed)
tickets.assigned_to
tickets.project_id
ticket_timeline.ticket_id
ticket_comments.ticket_id
```

### **Composite Indexes:**
```sql
-- Dashboard filtering
idx_status_assigned (status, assigned_to)
idx_project_status (project_id, status)

-- Timeline queries
idx_ticket_timestamp (ticket_id, timestamp DESC)

-- Reports
idx_channel_created (channel, created_at)
```

### **Full-text Search:**
```sql
-- Search by title/description
FULLTEXT INDEX ft_title_description (title, description)
```

---

## 📊 **Data Flow Diagram**

```
                    ┌─────────────┐
                    │   CUSTOMER  │
                    │   or STAFF  │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │Create Ticket│
                    └──────┬──────┘
                           │
                           ▼
            ┌──────────────────────────────┐
            │        TICKETS (new)          │
            │  + Timeline: Created          │
            │  + Stakeholder: Creator       │
            └──────────────┬────────────────┘
                           │
                           ▼
            ┌──────────────────────────────┐
            │      Tier1 Accept             │
            │  + Status: tier1 → in_progress│
            │  + Timeline: Assignment       │
            │  + Stakeholder: Current Owner │
            └──────────────┬────────────────┘
                           │
            ┌──────────────┴──────────────┐
            │                             │
            ▼                             ▼
    ┌───────────────┐           ┌───────────────┐
    │ Resolve       │           │ Escalate      │
    │ + Comments    │           │ to Tier2/3    │
    │ + Solution    │           │ + Escalation  │
    │ + Timeline    │           │   Chain       │
    └───────┬───────┘           │ + Stakeholder │
            │                   └───────┬───────┘
            │                           │
            │                           ▼
            │                   ┌───────────────┐
            │                   │ Tier2/3 Work  │
            │                   │ + Timeline    │
            │                   │ + Comments    │
            │                   └───────┬───────┘
            │                           │
            │◄──────────────────────────┘
            │         Return
            ▼
    ┌───────────────┐
    │ Tier1 Close   │
    │ + Status:     │
    │   closed      │
    │ + Timeline:   │
    │   Closed      │
    └───────────────┘
```

---

## 🎯 **Key Design Principles**

### **1. Normalization**
- ✅ 3NF (Third Normal Form)
- ✅ Minimize data redundancy
- ✅ Separate concerns (Users, Projects, Tickets)

### **2. Denormalization (Strategic)**
- ✅ Store `project_code`, `project_name` in `tickets` (performance)
- ✅ Store `created_by_name` in `tickets` (avoid JOIN for display)
- ✅ Store `escalated_by_name` in `escalation_chain` (audit trail)

### **3. Multi-tenant Support**
- ✅ `user_projects` table for isolation
- ✅ Filter tickets by `project_id`
- ✅ Row-level security ready

### **4. Audit Trail**
- ✅ `ticket_timeline` captures all events
- ✅ Immutable records (INSERT only, no UPDATE/DELETE)
- ✅ Timestamps on all tables

### **5. Soft Delete**
- ✅ Use `ON DELETE SET NULL` for user references
- ✅ Preserve historical data
- ✅ Add `deleted_at` column if needed

---

**สร้างโดย:** Database Architecture Team  
**วันที่:** 17 มกราคม 2026  
**เวอร์ชัน:** 1.0
