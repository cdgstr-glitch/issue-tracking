# ✅ Checklist การตรวจสอบและแก้ไข Components (Tier1 Definition Update)

**วันที่:** 22 มกราคม 2025  
**เป้าหมาย:** ตรวจสอบและแก้ไขทุก Component ให้ใช้กฎใหม่ `Tier1 = มีทั้ง 'tier1' และ 'staff'`

---

## 🎯 กฎใหม่ที่ต้องใช้

```typescript
// ✅ Tier1 ใหม่
const isTier1 = user.roles?.includes('tier1') && user.roles?.includes('staff');

// ❌ เก่า (ห้ามใช้แล้ว)
const isTier1 = hasRole(user, 'tier1');
```

---

## 📂 Components ที่ต้องตรวจสอบ

### **🔴 Priority 1: Critical Components (ต้องแก้ก่อน)**

#### **1. CreateTicketPage.tsx** 🔥 สำคัญมาก

**Path:** `/components/CreateTicketPage.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 56-66:** เช็ค `hasRole(currentUser, 'staff')` สำหรับ incident date
- [ ] **Line 72:** Validate project selection สำหรับ Staff
- [ ] **Line 373-376:** เช็คว่าเป็น staff เพื่อแสดงหัวข้อหน้า
- [ ] **Line 388:** เช็คว่าเป็น staff เพื่อแสดงชื่อ Card
- [ ] **Line 392-432:** แสดงฟอร์มกรอกข้อมูลลูกค้า (Staff)
- [ ] **Line 435-468:** แสดงช่องทางการติดต่อ (Staff)
- [ ] **Line 515-576:** แสดง Issue Type, Priority (Staff)
- [ ] **Line 579-592:** แสดง Incident Date (Staff)
- [ ] **Line 595-648:** แสดง Project Selector (Staff - Required)
- [ ] **Line 698-703:** ปุ่ม "ส่งงาน" สำหรับ Pure Staff
- [ ] **Line 706-729:** ปุ่มสำหรับ Tier1+Staff (3 ปุ่ม)

**การแก้ไข:**
```typescript
// ✅ ใช้กฎใหม่
const isTier1 = hasRole(currentUser, 'tier1') && hasRole(currentUser, 'staff');
const isPureStaff = hasRole(currentUser, 'staff') && !hasRole(currentUser, 'tier1');

// แสดงปุ่มตาม role
{isPureStaff && (
  <Button type="submit">ส่งงาน</Button>
)}

{isTier1 && (
  <>
    <Button onClick={handleSolveAndClose}>บันทึกและแก้ปัญหาเลย</Button>
    <Button onClick={handleSaveAndAccept}>บันทึกและรับเคส</Button>
    <Button type="submit">บันทึกเคส</Button>
  </>
)}
```

**สถานะ:** ⬜ ยังไม่แก้

---

#### **2. TicketActions.tsx** 🔥 สำคัญมาก

**Path:** `/components/TicketActions.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 138-165:** เช็คสิทธิ์รับเคส (Tier1)
- [ ] **Line 185-192:** เช็คสิทธิ์ปิดเคส (เฉพาะ Tier1 ที่มี staff)
- [ ] **Line 193-201:** เช็คสิทธิ์ส่งต่อเคส
- [ ] **Line 253-290:** ปุ่ม "รับเคส" (Tier1 เท่านั้น)
- [ ] **Line 311-358:** ปุ่ม "ปิดเคส" (Tier1 เท่านั้น)

**การแก้ไข:**
```typescript
// ✅ ใช้กฎใหม่
const hasTier1Role = userRole === 'tier1' && 
                     user?.roles?.includes('tier1') && 
                     user?.roles?.includes('staff');

const canClose = (hasTier1Role && isResolved) || canStaffClose;
```

**สถานะ:** ⬜ ยังไม่แก้

---

#### **3. TicketDetailPage.tsx**

**Path:** `/components/TicketDetailPage.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 96:** เช็คว่าเป็น customer สำหรับ Takeover Banner
- [ ] **Line 154-162:** การรับเคสจาก Takeover Banner (Tier1)
- [ ] การแสดง TicketActions component

**สถานะ:** ⬜ ยังไม่แก้

---

#### **4. StaffTicketDetailPage.tsx**

**Path:** `/components/StaffTicketDetailPage.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 221:** ส่ง `userRole` ไปยัง TicketActions
- [ ] การแสดงปุ่มต่างๆ ตาม role

**สถานะ:** ⬜ ยังไม่แก้

---

### **🟡 Priority 2: UI Components**

#### **5. Header.tsx**

**Path:** `/components/Header.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 33:** ใช้ `activeRole` และ `setActiveRole`
- [ ] **Line 48-56:** เช็คว่าเป็น staff
- [ ] **Line 62:** แสดงชื่อแอปพลิเคชันตาม role
- [ ] **Line 80-95:** getNotifications ตาม role
- [ ] **Line 346-360:** แสดงปุ่ม "แจ้งเคสใหม่" (Staff/Tier1)
- [ ] **Line 458:** แสดงชื่อ role ที่ถูกต้อง
- [ ] **Line 475-485:** Dropdown สลับบทบาท (Tier2+Tier3 เท่านั้น)

**หมายเหตุ:**
- Tier1+Staff **ไม่มี** Dropdown สลับบทบาท
- แสดงเป็น "เทียร์ 1" เท่านั้น

**สถานะ:** ⬜ ยังไม่แก้

---

#### **6. Sidebar.tsx**

**Path:** `/components/Sidebar.tsx`

**จุดที่ต้องแก้:**
- [ ] แสดง menu ที่เหมาะสมตาม role
- [ ] ซ่อน menu "จัดการผู้ใช้" และ "จัดการโครงการ" (ยกเว้น Admin)

**สถานะ:** ⬜ ยังไม่แก้

---

### **🟢 Priority 3: Data & List Components**

#### **7. TicketListPage.tsx**

**Path:** `/components/TicketListPage.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 34-36:** ใช้ `activeRole`
- [ ] **Line 89-143:** getTierRoles สำหรับ filter
- [ ] **Line 389-395:** กรองเคสตาม role (Inverted Visibility)
- [ ] **Line 474-477:** กรอง Pending tickets ตาม role

**หมายเหตุ:**
- Tier1 เห็นเคสทั้งหมด (new, tier1, tier2, tier3)
- ไม่มี Dropdown สลับ role สำหรับ Tier1

**สถานะ:** ⬜ ยังไม่แก้

---

#### **8. StaffClosedTicketsPage.tsx**

**Path:** `/components/StaffClosedTicketsPage.tsx`

**จุดที่ต้องแก้:**
- [ ] **Line 345-357:** แสดง badge ของผู้ปิดเคส
- [ ] **Line 764-776:** แสดง badge ในตาราง
- [ ] ตรวจสอบว่า Staff ที่ปิดเคสเป็น Tier1 หรือไม่

**การแก้ไข:**
```typescript
// ✅ ตรวจสอบว่าเป็น Tier1 Staff
const isTier1Staff = closedByUser.roles?.includes('tier1') && 
                     closedByUser.roles?.includes('staff');

// แสดง badge
{isTier1Staff ? (
  <Badge>Tier 1</Badge>
) : closedByUser.roles?.includes('staff') ? (
  <Badge>Staff</Badge>
) : (
  <Badge>Tier {closedByUser.role.replace('tier', '')}</Badge>
)}
```

**สถานะ:** ⬜ ยังไม่แก้

---

### **🔵 Priority 4: Utility & Helper Functions**

#### **9. utils.ts**

**Path:** `/lib/utils.ts`

**จุดที่ต้องแก้:**
- [ ] **Line 21-31:** `hasRole()` function - ใช้งานได้แล้ว (ไม่ต้องแก้)
- [ ] **Line 127-133:** `getTierRoles()` - ตรวจสอบว่ารวม tier1 หรือไม่
- [ ] **Line 140-143:** `needsRoleSelector()` - Tier1 ไม่ควรมี selector

**หมายเหตุ:**
```typescript
// ✅ getTierRoles ปัจจุบันไม่รวม tier1
export function getTierRoles(user: User | null | undefined): UserRole[] {
  const allRoles = getAllRoles(user);
  // ✅ ถูกต้อง: สลับบทบาทได้เฉพาะ tier2 และ tier3 เท่านั้น
  return allRoles.filter(role => 
    ['tier2', 'tier3'].includes(role)
  );
}
```

**สถานะ:** ✅ ถูกต้องแล้ว (ไม่ต้องแก้)

---

#### **10. mockData/users.ts**

**Path:** `/lib/mockData/users.ts`

**จุดที่ต้องแก้:**
- [ ] **Line 239-258:** Uncomment user-012 (อภิญญา ทองชัย) และตั้งเป็น Tier0
- [ ] หรือเก็บไว้แบบ comment (ถ้าไม่ใช้งาน)

**ตัวเลือก:**
1. **ซ่อนไว้** (ปัจจุบัน - แนะนำ):
   ```typescript
   // user-012 ยังเป็น comment อยู่ → ไม่สามารถ login ได้
   ```

2. **เปลี่ยนเป็น Tier0** (อนาคต):
   ```typescript
   {
     id: 'user-012',
     roles: ['tier0'],
     primaryRole: 'tier0',
     isHidden: true,  // ป้องกัน login
   }
   ```

**สถานะ:** ⬜ รอการตัดสินใจ

---

### **🟣 Priority 5: Additional Components**

#### **11. CustomerInfoCard.tsx**

**Path:** `/components/CustomerInfoCard.tsx`

**จุดที่ต้องแก้:**
- [ ] เช็คว่าเป็น staff หรือไม่
- [ ] แสดงข้อมูลลูกค้าแบบ read-only (ถ้าเป็น customer)

**สถานะ:** ⬜ ยังไม่แก้

---

#### **12. LoginPage.tsx**

**Path:** `/components/LoginPage.tsx`

**จุดที่ต้องแก้:**
- [ ] ตรวจสอบว่า user-012 ถูกซ่อนหรือไม่
- [ ] ป้องกันไม่ให้ Tier0 login ได้

**การแก้ไข:**
```typescript
// ใน AuthContext.tsx
const login = async (username: string, password: string) => {
  const foundUser = mockUsers.find(...);
  
  // ป้องกัน Tier0 login
  if (foundUser?.isHidden) {
    console.warn('⚠️ Hidden users cannot login');
    return false;
  }
  
  // ...
};
```

**สถานะ:** ⬜ ยังไม่แก้

---

#### **13. ProfilePage.tsx**

**Path:** `/components/ProfilePage.tsx`

**จุดที่ต้องแก้:**
- [ ] แสดงชื่อ role ที่ถูกต้อง (Tier1 แทน Tier1+Staff)

**สถานะ:** ⬜ ยังไม่แก้

---

## 📝 Template การแก้ไข

### **Before (ผิด):**
```typescript
// ❌ เช็คแค่ tier1 อย่างเดียว
const isTier1 = hasRole(user, 'tier1');

if (isTier1) {
  // แสดงฟอร์ม Staff
}
```

### **After (ถูก):**
```typescript
// ✅ เช็คทั้ง tier1 และ staff
const isTier1 = hasRole(user, 'tier1') && hasRole(user, 'staff');
const isPureStaff = hasRole(user, 'staff') && !hasRole(user, 'tier1');

if (isTier1) {
  // แสดงฟอร์ม Tier1 (มีสิทธิ์เต็ม)
} else if (isPureStaff) {
  // แสดงฟอร์ม Staff (บันทึกเคสเท่านั้น)
}
```

---

## 🧪 Testing Checklist

### **Test Scenarios สำหรับแต่ละ Role:**

#### **1. Tier1 (user-001, 002, 003, 004, 005)**
- [ ] สามารถเข้าหน้าแจ้งเคสได้
- [ ] เห็นฟอร์มกรอกข้อมูลลูกค้า
- [ ] เห็นช่องทางการติดต่อ
- [ ] เห็นประเภทปัญหา
- [ ] เห็นความสำคัญ
- [ ] เห็นโครงการ (Required)
- [ ] มีปุ่ม "บันทึกเคส"
- [ ] มีปุ่ม "บันทึกและรับเคส" (user-003, 004, 005)
- [ ] มีปุ่ม "บันทึกและแก้ปัญหาเลย" (user-003, 004, 005)
- [ ] สามารถรับเคสได้
- [ ] สามารถปิดเคสได้
- [ ] เห็น Dashboard Tier1

#### **2. Pure Staff (staff-001)**
- [ ] สามารถเข้าหน้าแจ้งเคสได้
- [ ] เห็นฟอร์มกรอกข้อมูลลูกค้า
- [ ] มีปุ่ม "บันทึกเคส" เท่านั้น
- [ ] **ไม่มี**ปุ่ม "บันทึกและรับเคส"
- [ ] **ไม่สามารถ**รับเคสได้
- [ ] **ไม่สามารถ**ปิดเคสได้
- [ ] **ไม่เห็น** Dashboard

#### **3. Pure Admin (user-011)**
- [ ] เห็น Dashboard
- [ ] เห็นเมนู "จัดการผู้ใช้"
- [ ] เห็นเมนู "จัดการโครงการ"
- [ ] **ไม่สามารถ**ปิดเคสได้ (ไม่มี tier1)

#### **4. Tier2+Tier3 (user-007)**
- [ ] มี Dropdown สลับบทบาท
- [ ] สลับ Tier2 → redirect ไป `/admin/sa`
- [ ] สลับ Tier3 → redirect ไป `/admin/specialist`
- [ ] เห็นเคสตาม role ที่เลือก

---

## ✅ Progress Tracker

| Component | Priority | จำนวนจุดที่ต้องแก้ | สถานะ | ผู้รับผิดชอบ | วันที่เสร็จ |
|-----------|----------|------------------|-------|-------------|-----------|
| CreateTicketPage.tsx | 🔴 P1 | 11 จุด | ⬜ Todo | - | - |
| TicketActions.tsx | 🔴 P1 | 5 จุด | ⬜ Todo | - | - |
| TicketDetailPage.tsx | 🔴 P1 | 3 จุด | ⬜ Todo | - | - |
| StaffTicketDetailPage.tsx | 🔴 P1 | 2 จุด | ⬜ Todo | - | - |
| Header.tsx | 🟡 P2 | 7 จุด | ⬜ Todo | - | - |
| Sidebar.tsx | 🟡 P2 | 2 จุด | ⬜ Todo | - | - |
| TicketListPage.tsx | 🟢 P3 | 4 จุด | ⬜ Todo | - | - |
| StaffClosedTicketsPage.tsx | 🟢 P3 | 3 จุด | ⬜ Todo | - | - |
| utils.ts | 🔵 P4 | 0 จุด | ✅ Done | - | 2025-01-22 |
| mockData/users.ts | 🔵 P4 | 1 จุด | ⬜ Todo | - | - |
| CustomerInfoCard.tsx | 🟣 P5 | 2 จุด | ⬜ Todo | - | - |
| LoginPage.tsx | 🟣 P5 | 2 จุด | ⬜ Todo | - | - |
| ProfilePage.tsx | 🟣 P5 | 1 จุด | ⬜ Todo | - | - |

**รวม:** 43 จุดที่ต้องตรวจสอบ

---

## 📊 สรุป

- ✅ **เอกสารกฎใหม่:** ROLE_STRUCTURE.md
- ✅ **Checklist นี้:** MIGRATION_CHECKLIST.md
- ⬜ **การแก้ไขโค้ด:** 43 จุดที่ต้องตรวจสอบ
- ⬜ **การทดสอบ:** 4 scenarios x 13 test cases = 52 tests

---

**สร้างโดย:** CDGS Development Team  
**วันที่สร้าง:** 22 มกราคม 2025  
**อัปเดตล่าสุด:** 22 มกราคม 2025
