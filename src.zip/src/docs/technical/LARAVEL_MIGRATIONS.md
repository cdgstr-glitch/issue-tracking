# 🚀 Laravel Migration Guide - CDGS Issue Tracking Platform

**วันที่:** 17 มกราคม 2026  
**Laravel Version:** 10.x / 11.x  
**Database:** MySQL 8.0+ / MariaDB 10.5+

---

## 📋 **สารบัญ**

1. [วิธีใช้งาน SQL File](#sql-usage)
2. [Laravel Migration Files](#laravel-migrations)
3. [การ Run Migration](#run-migration)
4. [Laravel Eloquent Models](#eloquent-models)
5. [Seeder Files](#seeders)
6. [Testing](#testing)

---

<a name="sql-usage"></a>
## 1️⃣ **วิธีใช้งาน SQL File**

### **Option 1: Import ด้วย MySQL Command Line**

```bash
# 1. Login to MySQL
mysql -u root -p

# 2. Import SQL file
mysql -u root -p cdgs_issue_tracking < database_migrations.sql

# หรือ
mysql -u root -p < database_migrations.sql
```

### **Option 2: Import ด้วย phpMyAdmin**

1. เข้า phpMyAdmin
2. คลิก "Import"
3. เลือกไฟล์ `database_migrations.sql`
4. คลิก "Go"

### **Option 3: Import ด้วย Laravel Artisan**

```bash
# ใช้ DB::unprepared() ใน seeder หรือ migration
php artisan migrate:fresh --seed
```

---

<a name="laravel-migrations"></a>
## 2️⃣ **Laravel Migration Files**

### **📁 โครงสร้างไฟล์ Migration**

```
database/
├── migrations/
│   ├── 2024_01_01_000001_create_users_table.php
│   ├── 2024_01_01_000002_create_user_roles_table.php
│   ├── 2024_01_01_000003_create_projects_table.php
│   ├── 2024_01_01_000004_create_user_projects_table.php
│   ├── 2024_01_01_000005_create_tickets_table.php
│   ├── 2024_01_01_000006_create_ticket_timeline_table.php
│   ├── 2024_01_01_000007_create_ticket_comments_table.php
│   ├── 2024_01_01_000008_create_ticket_attachments_table.php
│   ├── 2024_01_01_000009_create_escalation_chain_table.php
│   ├── 2024_01_01_000010_create_ticket_stakeholders_table.php
│   └── 2024_01_01_000011_create_ticket_viewers_table.php
└── seeders/
    ├── DatabaseSeeder.php
    ├── UserSeeder.php
    ├── ProjectSeeder.php
    └── TicketSeeder.php
```

---

### **Migration 1: Create Users Table**

**File:** `database/migrations/2024_01_01_000001_create_users_table.php`

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            // Primary Key
            $table->uuid('id')->primary();
            
            // Authentication
            $table->string('username', 100)->unique();
            $table->string('password');
            $table->string('email', 255)->unique();
            
            // Personal Info
            $table->string('full_name');
            $table->string('phone', 20)->nullable();
            $table->string('department')->nullable();
            
            // Role & Tier
            $table->enum('primary_role', ['customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin']);
            $table->tinyInteger('tier')->nullable();
            
            // Manager Hierarchy
            $table->uuid('manager_id')->nullable();
            $table->uuid('senior_manager_id')->nullable();
            $table->string('manager_email')->nullable();
            
            // Timestamps
            $table->timestamps();
            
            // Indexes
            $table->index('username');
            $table->index('email');
            $table->index('primary_role');
            $table->index('manager_id');
            
            // Foreign Keys
            $table->foreign('manager_id')->references('id')->on('users')->nullOnDelete();
            $table->foreign('senior_manager_id')->references('id')->on('users')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
```

---

### **Migration 2: Create User Roles Table**

**File:** `database/migrations/2024_01_01_000002_create_user_roles_table.php`

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_roles', function (Blueprint $table) {
            $table->id();
            $table->uuid('user_id');
            $table->enum('role', ['customer', 'staff', 'tier1', 'tier2', 'tier3', 'admin']);
            $table->timestamp('created_at')->useCurrent();
            
            // Indexes
            $table->index('user_id');
            $table->index('role');
            $table->unique(['user_id', 'role']);
            
            // Foreign Keys
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_roles');
    }
};
```

---

### **Migration 3: Create Projects Table**

**File:** `database/migrations/2024_01_01_000003_create_projects_table.php`

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('code', 50)->unique();
            $table->string('name', 500);
            $table->string('short_name', 100);
            $table->string('department')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
            
            // Indexes
            $table->index('code');
            $table->index('short_name');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
```

---

### **Migration 4: Create User Projects Table**

**File:** `database/migrations/2024_01_01_000004_create_user_projects_table.php`

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_projects', function (Blueprint $table) {
            $table->id();
            $table->uuid('user_id');
            $table->uuid('project_id');
            $table->timestamp('created_at')->useCurrent();
            
            // Indexes
            $table->index('user_id');
            $table->index('project_id');
            $table->unique(['user_id', 'project_id']);
            
            // Foreign Keys
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
            $table->foreign('project_id')->references('id')->on('projects')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_projects');
    }
};
```

---

### **Migration 5: Create Tickets Table (CORE)**

**File:** `database/migrations/2024_01_01_000005_create_tickets_table.php`

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            // Primary Key
            $table->uuid('id')->primary();
            $table->string('ticket_number', 50)->unique();
            
            // Basic Info
            $table->string('title', 500);
            $table->text('description');
            $table->enum('status', ['new', 'tier1', 'tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed']);
            $table->enum('type', ['incident', 'service_request', 'security_incident']);
            $table->enum('channel', ['web', 'email', 'line', 'phone']);
            $table->enum('priority', ['low', 'medium', 'high', 'critical']);
            $table->string('category', 100);
            
            // Product & Department
            $table->string('product')->nullable();
            $table->string('department')->nullable();
            
            // Customer Info
            $table->string('customer_name');
            $table->string('customer_email');
            $table->string('customer_phone', 20)->nullable();
            
            // Assignment
            $table->uuid('assigned_to')->nullable();
            $table->uuid('assigned_by')->nullable();
            $table->timestamp('assigned_at')->nullable();
            $table->uuid('previous_assignee')->nullable();
            
            // Project
            $table->uuid('project_id')->nullable();
            $table->string('project_code', 50)->nullable();
            $table->string('project_name', 500)->nullable();
            $table->string('project_short_name', 100)->nullable();
            
            // Creator Info
            $table->uuid('created_by')->nullable();
            $table->string('created_by_name')->nullable();
            $table->enum('created_by_type', ['customer_self', 'staff_on_behalf'])->nullable();
            $table->string('created_by_staff_name')->nullable();
            
            // Timestamps
            $table->timestamps();
            $table->timestamp('due_date');
            
            // Resolution
            $table->timestamp('resolved_at')->nullable();
            $table->uuid('resolved_by')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->uuid('closed_by')->nullable();
            $table->text('solution')->nullable();
            $table->text('closure_notes')->nullable();
            
            // Indexes
            $table->index('ticket_number');
            $table->index('status');
            $table->index('priority');
            $table->index('channel');
            $table->index('assigned_to');
            $table->index('project_id');
            $table->index('created_at');
            $table->index('customer_email');
            $table->index(['status', 'assigned_to']);
            $table->index(['project_id', 'status']);
            $table->index(['channel', 'created_at']);
            $table->fullText(['title', 'description']);
            
            // Foreign Keys
            $table->foreign('assigned_to')->references('id')->on('users')->nullOnDelete();
            $table->foreign('assigned_by')->references('id')->on('users')->nullOnDelete();
            $table->foreign('previous_assignee')->references('id')->on('users')->nullOnDelete();
            $table->foreign('created_by')->references('id')->on('users')->nullOnDelete();
            $table->foreign('resolved_by')->references('id')->on('users')->nullOnDelete();
            $table->foreign('closed_by')->references('id')->on('users')->nullOnDelete();
            $table->foreign('project_id')->references('id')->on('projects')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
```

---

### **Migration 6-11: ตารางที่เหลือ**

เนื่องจากมีความยาวมาก ให้ใช้ไฟล์ SQL ที่สร้างไว้แล้ว หรือสร้างแบบเดียวกับตัวอย่างข้างต้น

---

<a name="run-migration"></a>
## 3️⃣ **การ Run Migration**

### **คำสั่ง Laravel Artisan**

```bash
# 1. สร้าง migration files ใหม่
php artisan make:migration create_users_table
php artisan make:migration create_tickets_table
# ... ฯลฯ

# 2. Run migrations
php artisan migrate

# 3. Rollback (undo)
php artisan migrate:rollback

# 4. Reset (rollback ทั้งหมด)
php artisan migrate:reset

# 5. Fresh (drop ทั้งหมดแล้ว migrate ใหม่)
php artisan migrate:fresh

# 6. Fresh with seeder
php artisan migrate:fresh --seed

# 7. Check migration status
php artisan migrate:status
```

---

<a name="eloquent-models"></a>
## 4️⃣ **Laravel Eloquent Models**

### **User Model**

**File:** `app/Models/User.php`

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasUuids;

    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'username',
        'email',
        'password',
        'full_name',
        'phone',
        'department',
        'primary_role',
        'tier',
        'manager_id',
        'senior_manager_id',
        'manager_email',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // Relationships
    public function roles()
    {
        return $this->hasMany(UserRole::class);
    }

    public function projects()
    {
        return $this->belongsToMany(Project::class, 'user_projects');
    }

    public function assignedTickets()
    {
        return $this->hasMany(Ticket::class, 'assigned_to');
    }

    public function createdTickets()
    {
        return $this->hasMany(Ticket::class, 'created_by');
    }

    public function manager()
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    public function subordinates()
    {
        return $this->hasMany(User::class, 'manager_id');
    }
}
```

---

### **Ticket Model**

**File:** `app/Models/Ticket.php`

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory, HasUuids;

    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'ticket_number',
        'title',
        'description',
        'status',
        'type',
        'channel',
        'priority',
        'category',
        'product',
        'department',
        'customer_name',
        'customer_email',
        'customer_phone',
        'assigned_to',
        'assigned_by',
        'assigned_at',
        'previous_assignee',
        'project_id',
        'project_code',
        'project_name',
        'project_short_name',
        'created_by',
        'created_by_name',
        'created_by_type',
        'created_by_staff_name',
        'due_date',
        'resolved_at',
        'resolved_by',
        'closed_at',
        'closed_by',
        'solution',
        'closure_notes',
    ];

    protected function casts(): array
    {
        return [
            'assigned_at' => 'datetime',
            'due_date' => 'datetime',
            'resolved_at' => 'datetime',
            'closed_at' => 'datetime',
        ];
    }

    // Relationships
    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function timeline()
    {
        return $this->hasMany(TicketTimeline::class);
    }

    public function comments()
    {
        return $this->hasMany(TicketComment::class);
    }

    public function attachments()
    {
        return $this->hasMany(TicketAttachment::class);
    }

    public function escalations()
    {
        return $this->hasMany(EscalationChain::class);
    }

    public function stakeholders()
    {
        return $this->hasMany(TicketStakeholder::class);
    }

    public function viewers()
    {
        return $this->hasMany(TicketViewer::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->whereNotIn('status', ['closed']);
    }

    public function scopeNew($query)
    {
        return $query->where('status', 'new');
    }

    public function scopeAssignedTo($query, $userId)
    {
        return $query->where('assigned_to', $userId);
    }

    public function scopeByProject($query, $projectId)
    {
        return $query->where('project_id', $projectId);
    }
}
```

---

### **Project Model**

**File:** `app/Models/Project.php`

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory, HasUuids;

    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'code',
        'name',
        'short_name',
        'department',
        'description',
    ];

    // Relationships
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_projects');
    }

    public function tickets()
    {
        return $this->hasMany(Ticket::class);
    }
}
```

---

<a name="seeders"></a>
## 5️⃣ **Seeder Files**

### **DatabaseSeeder**

**File:** `database/seeders/DatabaseSeeder.php`

```php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            ProjectSeeder::class,
            TicketSeeder::class,
        ]);
    }
}
```

---

### **UserSeeder**

**File:** `database/seeders/UserSeeder.php`

```php
<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\UserRole;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin User
        $admin = User::create([
            'id' => Str::uuid(),
            'username' => 'admin',
            'email' => 'admin@cdgs.co.th',
            'password' => bcrypt('password'),
            'full_name' => 'ผู้ดูแลระบบ',
            'primary_role' => 'admin',
        ]);
        
        UserRole::create([
            'user_id' => $admin->id,
            'role' => 'admin',
        ]);

        // Tier1 User
        $tier1 = User::create([
            'id' => Str::uuid(),
            'username' => 'aphiya.t',
            'email' => 'aphiya.t@cdgs.co.th',
            'password' => bcrypt('password'),
            'full_name' => 'อภิญญา ทองชัย',
            'phone' => '081-234-5678',
            'department' => 'Support',
            'primary_role' => 'tier1',
            'tier' => 1,
        ]);
        
        UserRole::create(['user_id' => $tier1->id, 'role' => 'tier1']);
        UserRole::create(['user_id' => $tier1->id, 'role' => 'staff']);

        // Customer User
        $customer = User::create([
            'id' => Str::uuid(),
            'username' => 'customer1',
            'email' => 'customer1@example.com',
            'password' => bcrypt('password'),
            'full_name' => 'ลูกค้า ทดสอบ',
            'phone' => '084-567-8901',
            'department' => 'MRTA',
            'primary_role' => 'customer',
        ]);
        
        UserRole::create(['user_id' => $customer->id, 'role' => 'customer']);
    }
}
```

---

<a name="testing"></a>
## 6️⃣ **Testing**

### **Feature Test Example**

**File:** `tests/Feature/TicketTest.php`

```php
<?php

namespace Tests\Feature;

use App\Models\Ticket;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TicketTest extends TestCase
{
    use RefreshDatabase;

    public function test_can_create_ticket(): void
    {
        $user = User::factory()->create(['primary_role' => 'customer']);

        $response = $this->actingAs($user)->post('/api/tickets', [
            'title' => 'Test Ticket',
            'description' => 'Test Description',
            'type' => 'incident',
            'channel' => 'web',
            'priority' => 'high',
            'category' => 'system',
        ]);

        $response->assertStatus(201);
        $this->assertDatabaseHas('tickets', [
            'title' => 'Test Ticket',
        ]);
    }

    public function test_tier1_can_accept_ticket(): void
    {
        $tier1 = User::factory()->create(['primary_role' => 'tier1', 'tier' => 1]);
        $ticket = Ticket::factory()->create(['status' => 'new']);

        $response = $this->actingAs($tier1)->post("/api/tickets/{$ticket->id}/accept");

        $response->assertStatus(200);
        $this->assertDatabaseHas('tickets', [
            'id' => $ticket->id,
            'status' => 'tier1',
            'assigned_to' => $tier1->id,
        ]);
    }
}
```

---

## 🎯 **สรุป**

### **✅ ไฟล์ที่ได้:**

1. ✅ **database_migrations.sql** - Pure SQL สำหรับ import ตรงๆ
2. ✅ **LARAVEL_MIGRATIONS_GUIDE.md** - คู่มือ Laravel Migration

### **✅ วิธีใช้:**

#### **Option 1: ใช้ SQL File (เร็วที่สุด)**
```bash
mysql -u root -p cdgs_issue_tracking < database_migrations.sql
```

#### **Option 2: ใช้ Laravel Migrations**
```bash
# สร้าง migration files ตามตัวอย่าง
php artisan make:migration create_tickets_table

# Run migrations
php artisan migrate

# Run seeders
php artisan db:seed
```

---

**สร้างโดย:** Laravel Development Team  
**วันที่:** 17 มกราคม 2026  
**สถานะ:** ✅ Ready for Production
