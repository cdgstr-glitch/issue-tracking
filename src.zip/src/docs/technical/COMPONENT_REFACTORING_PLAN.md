# 🔧 Component Refactoring Plan - CDGS Issue Tracking Platform

**วันที่:** 21 มกราคม 2026  
**สถานะ:** 📋 แผนการปรับปรุง  
**วัตถุประสงค์:** สร้างระบบ Component ที่มีมาตรฐาน ลดโค้ดซ้ำ และง่ายต่อการ maintain

---

## 📊 สรุปผลการวิเคราะห์

### **ปัญหาที่พบ:**

| ปัญหา | จำนวนที่พบ | Impact |
|-------|-----------|--------|
| **โค้ดซ้ำ - Back Button** | 8+ ไฟล์ | 🔴 สูง |
| **โค้ดซ้ำ - Page Header** | 10+ ไฟล์ | 🔴 สูง |
| **โค้ดซ้ำ - Empty State** | 12+ ไฟล์ | 🔴 สูง |
| **โค้ดซ้ำ - Success State** | 3 ไฟล์ (เหมือนกันทุกอย่าง) | 🟠 กลาง |
| **โค้ดซ้ำ - Container Layout** | 15+ ไฟล์ | 🔴 สูง |
| **โค้ดซ้ำ - Info Card** | 8+ ไฟล์ | 🟠 กลาง |
| **โค้ดซ้ำ - User Avatar** | 5+ ไฟล์ | 🟡 ต่ำ |

**สรุป:** พบโค้ดซ้ำ **1,500+ บรรทัด** ที่สามารถ refactor เป็น Component ได้

---

## 🎯 Components ที่แนะนำให้สร้าง

### **Priority 1: สูงมาก (ต้องทำทันที)**

#### **1. PageBackButton Component** 🔴

**ปัญหา:** โค้ดซ้ำ 8+ ไฟล์ ทุกไฟล์เขียนเหมือนกัน

**ก่อน (ซ้ำในทุกไฟล์):**
```tsx
// TicketDetailPage.tsx
<Button variant="ghost" size="sm" onClick={() => onNavigate(getBackPath())} className="shrink-0">
  <ArrowLeft className="h-4 w-4" />
  <span className="ml-2 hidden sm:inline">กลับ</span>
</Button>

// TrackTicketDetailPage.tsx
<Button 
  variant="ghost" 
  onClick={() => onNavigate('/track')}
  className="gap-2 mb-4"
>
  <ArrowLeft className="h-4 w-4" />
  กลับรายการเคส
</Button>

// StaffTicketDetailPage.tsx
<Button 
  variant="ghost" 
  onClick={() => onNavigate('/track')}
  className="gap-2 mb-4"
>
  <ArrowLeft className="h-4 w-4" />
  กลับรายการเคส
</Button>

// CustomerTrackTicketPage.tsx
<Button 
  variant="ghost" 
  onClick={() => onNavigate('/')}
  className="gap-2 mb-4"
>
  <ArrowLeft className="h-4 w-4" />
  กลับหน้าแรก
</Button>

// ... อีก 4+ ไฟล์
```

**หลัง (Component เดียว):**
```tsx
// ✅ /components/common/PageBackButton.tsx
interface PageBackButtonProps {
  onNavigate: (path: string) => void;
  backPath: string;
  label?: string;
  variant?: 'ghost' | 'outline';
  size?: 'sm' | 'default';
  className?: string;
  showIcon?: boolean;
}

export function PageBackButton({ 
  onNavigate, 
  backPath, 
  label = 'กลับ',
  variant = 'ghost',
  size = 'default',
  className = '',
  showIcon = true
}: PageBackButtonProps) {
  return (
    <Button 
      variant={variant} 
      size={size}
      onClick={() => onNavigate(backPath)}
      className={`gap-2 ${className}`}
    >
      {showIcon && <ArrowLeft className="h-4 w-4" />}
      <span className={size === 'sm' ? 'hidden sm:inline' : ''}>{label}</span>
    </Button>
  );
}
```

**การใช้งาน:**
```tsx
// ✅ TicketDetailPage.tsx
<PageBackButton 
  onNavigate={onNavigate} 
  backPath={getBackPath()} 
  size="sm"
/>

// ✅ TrackTicketDetailPage.tsx
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/track" 
  label="กลับรายการเคส"
/>

// ✅ CustomerTrackTicketPage.tsx
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/" 
  label="กลับหน้าแรก"
/>
```

**ประโยชน์:**
- ✅ ลดโค้ดซ้ำ 150+ บรรทัด
- ✅ เปลี่ยน style ที่เดียว ใช้ได้ทุกหน้า
- ✅ รองรับ responsive (sm:inline)

---

#### **2. PageHeader Component** 🔴

**ปัญหา:** ทุกหน้ามี Header ที่ structure คล้ายกัน

**ก่อน:**
```tsx
// CreateTicketPage.tsx
<div className=\"mb-6\">
  <h1 className=\"mb-2\">สร้างเคสใหม่</h1>
  <p className=\"text-gray-600\">กรอกรายละเอียดเคสของคุณ</p>
</div>

// TicketListPage.tsx
<div className="mb-6">
  <h1 className="mb-2">งานของฉัน</h1>
  <p className="text-gray-600">รายการงานที่คุณรับผิดชอบ</p>
</div>

// ... อีก 10+ ไฟล์
```

**หลัง:**
```tsx
// ✅ /components/common/PageHeader.tsx
interface PageHeaderProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}

export function PageHeader({ 
  title, 
  subtitle, 
  badge, 
  actions, 
  className = 'mb-6'
}: PageHeaderProps) {
  return (
    <div className={className}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="mb-0">{title}</h1>
          {badge && <div>{badge}</div>}
        </div>
        {actions && <div>{actions}</div>}
      </div>
      {subtitle && <p className="text-gray-600 mt-2">{subtitle}</p>}
    </div>
  );
}
```

**การใช้งาน:**
```tsx
// ✅ CreateTicketPage.tsx
<PageHeader 
  title="สร้างเคสใหม่" 
  subtitle="กรอกรายละเอียดเคสของคุณ" 
/>

// ✅ TicketListPage.tsx
<PageHeader 
  title="งานของฉัน" 
  subtitle="รายการงานที่คุณรับผิดชอบ"
  badge={<Badge>{ticketCount}</Badge>}
  actions={<Button>ส่งออกรายงาน</Button>}
/>
```

**ประโยชน์:**
- ✅ ลดโค้ดซ้ำ 200+ บรรทัด
- ✅ รองรับ Badge และ Actions
- ✅ Consistent styling

---

#### **3. EmptyState Component** 🔴

**ปัญหา:** โค้ดซ้ำ 12+ ไฟล์ เหมือนกันทุก pattern

**ก่อน:**
```tsx
// TicketListPage.tsx
{filteredTickets.length === 0 && (
  <Card>
    <CardContent className="py-16 text-center">
      <Inbox className="mx-auto h-16 w-16 text-gray-400 mb-4" />
      <h3 className="mb-2 text-gray-900">ไม่พบเคส</h3>
      <p className="text-gray-600 mb-4">ไม่มีเคสที่ตรงกับเงื่อนไข</p>
      <Button onClick={handleReset}>ล้างตัวกรอง</Button>
    </CardContent>
  </Card>
)}

// TeamManagementPage.tsx
{filteredMembers.length === 0 && (
  <Card>
    <CardContent className="py-16 text-center">
      <Users className="mx-auto h-16 w-16 text-gray-400 mb-4" />
      <h3 className="mb-2 text-gray-900">ไม่พบสมาชิกทีม</h3>
      <p className="text-gray-600">ลองค้นหาด้วยคำอื่น</p>
    </CardContent>
  </Card>
)}

// EscalatedPage.tsx
{escalatedTickets.length === 0 && (
  <Card>
    <CardContent className="py-12 text-center">
      <ArrowUpRight className="mx-auto mb-3 h-12 w-12 text-gray-400" />
      <p className="text-gray-600 mb-2">ยังไม่มีเคสที่ส่งต่อ</p>
      <p className="text-sm text-gray-500">เคสที่คุณส่งต่อให้ทีมอื่นจะแสดงที่นี่</p>
    </CardContent>
  </Card>
)}

// ... อีก 9+ ไฟล์
```

**หลัง:**
```tsx
// ✅ /components/common/EmptyState.tsx
import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  variant?: 'default' | 'info' | 'warning';
  size?: 'sm' | 'md' | 'lg';
  showCard?: boolean;
}

export function EmptyState({ 
  icon: Icon, 
  title, 
  description, 
  action, 
  variant = 'default', 
  size = 'md',
  showCard = true
}: EmptyStateProps) {
  const sizeClasses = {
    sm: 'py-8',
    md: 'py-12',
    lg: 'py-16'
  };

  const iconSizes = {
    sm: 'h-8 w-8',
    md: 'h-12 w-12',
    lg: 'h-16 w-16'
  };

  const variantClasses = {
    default: '',
    info: 'border-blue-200 bg-blue-50',
    warning: 'border-yellow-200 bg-yellow-50'
  };

  const content = (
    <div className={`text-center ${sizeClasses[size]}`}>
      {Icon && (
        <Icon className={`mx-auto mb-4 text-gray-400 ${iconSizes[size]}`} />
      )}
      <h3 className="mb-2 text-gray-900">{title}</h3>
      {description && (
        <p className="text-gray-600 mb-4">{description}</p>
      )}
      {action && (
        <Button onClick={action.onClick}>{action.label}</Button>
      )}
    </div>
  );

  if (!showCard) {
    return content;
  }

  return (
    <Card className={variantClasses[variant]}>
      <CardContent className="p-0">
        {content}
      </CardContent>
    </Card>
  );
}
```

**การใช้งาน:**
```tsx
// ✅ TicketListPage.tsx
{filteredTickets.length === 0 && (
  <EmptyState
    icon={Inbox}
    title="ไม่พบเคส"
    description="ไม่มีเคสที่ตรงกับเงื่อนไข"
    action={{
      label: 'ล้างตัวกรอง',
      onClick: handleReset
    }}
  />
)}

// ✅ TeamManagementPage.tsx
<EmptyState
  icon={Users}
  title="ไม่พบสมาชิกทีม"
  description="ลองค้นหาด้วยคำอื่น"
  size="md"
/>

// ✅ EscalatedPage.tsx
<EmptyState
  icon={ArrowUpRight}
  title="ยังไม่มีเคสที่ส่งต่อ"
  description="เคสที่คุณส่งต่อให้ทีมอื่นจะแสดงที่นี่"
  size="sm"
/>
```

**ประโยชน์:**
- ✅ ลดโค้ดซ้ำ 400+ บรรทัด
- ✅ รองรับ variants (default, info, warning)
- ✅ รองรับ sizes (sm, md, lg)
- ✅ Optional Card wrapper

---

#### **4. SuccessPage Component** 🔴

**ปัญหา:** โค้ดซ้ำใน CreateTicketPage.tsx 3 ที่ (เหมือนกันทุกอย่างยกเว้นสี/ข้อความ)

**ก่อน:**
```tsx
// CreateTicketPage.tsx - Success State (3 places)

// 1. submitted
if (submitted) {
  return (
    <div className="container mx-auto max-w-2xl px-4 py-12">
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-12 text-center">
          <div className="mb-6 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-600">
              <CheckCircle className="h-10 w-10 text-white" />
            </div>
          </div>
          <h2 className="mb-4">แจ้งเคสสำเร็จ!</h2>
          <p className="mb-6 text-gray-700">...</p>
          <div className="mb-6 rounded-lg bg-white p-6">...</div>
          <Button onClick={...}>กลับหน้าแรก</Button>
        </CardContent>
      </Card>
    </div>
  );
}

// 2. ticketAccepted
if (ticketAccepted) {
  return (
    <div className="container mx-auto max-w-2xl px-4 py-12">
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-12 text-center">
          <div className="mb-6 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-blue-600">
              <CheckCircle className="h-10 w-10 text-white" />
            </div>
          </div>
          <h2 className="mb-4">✅ บันทึกและรับเคสสำเร็จ!</h2>
          <p className="mb-6 text-gray-700">...</p>
          <div className="mb-6 rounded-lg bg-white p-6">...</div>
          <Button onClick={...}>ดูรายละเอียดเคส</Button>
        </CardContent>
      </Card>
    </div>
  );
}

// 3. ticketClosed
if (ticketClosed) {
  return (
    <div className="container mx-auto max-w-2xl px-4 py-12">
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-12 text-center">
          <div className="mb-6 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-600">
              <CheckCircle className="h-10 w-10 text-white" />
            </div>
          </div>
          <h2 className="mb-4">✅ บันทึกและปิดเคสสำเร็จ!</h2>
          <p className="mb-6 text-gray-700">...</p>
          <div className="mb-6 rounded-lg bg-white p-6">...</div>
          <Button onClick={...}>ดูเคสที่ปิดย้อนหลัง</Button>
        </CardContent>
      </Card>
    </div>
  );
}
```

**หลัง:**
```tsx
// ✅ /components/common/SuccessPage.tsx
import { LucideIcon, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';

interface SuccessPageProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  variant?: 'success' | 'info' | 'warning';
  ticketNumber?: string;
  details?: {
    label: string;
    value: string;
  }[];
  actions?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'outline';
  }[];
}

export function SuccessPage({
  title,
  description,
  icon: Icon = CheckCircle,
  variant = 'success',
  ticketNumber,
  details,
  actions
}: SuccessPageProps) {
  const variantConfig = {
    success: {
      cardClass: 'border-green-200 bg-green-50',
      iconBg: 'bg-green-600'
    },
    info: {
      cardClass: 'border-blue-200 bg-blue-50',
      iconBg: 'bg-blue-600'
    },
    warning: {
      cardClass: 'border-yellow-200 bg-yellow-50',
      iconBg: 'bg-yellow-600'
    }
  };

  const config = variantConfig[variant];

  return (
    <div className="container mx-auto max-w-2xl px-4 py-12">
      <Card className={config.cardClass}>
        <CardContent className="p-12 text-center">
          {/* Icon */}
          <div className="mb-6 flex justify-center">
            <div className={`flex h-20 w-20 items-center justify-center rounded-full ${config.iconBg}`}>
              <Icon className="h-10 w-10 text-white" />
            </div>
          </div>

          {/* Title */}
          <h2 className="mb-4">{title}</h2>

          {/* Description */}
          <p className="mb-6 text-gray-700">{description}</p>

          {/* Ticket Details */}
          {(ticketNumber || details) && (
            <div className="mb-6 rounded-lg bg-white p-6">
              {ticketNumber && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600">หมายเลขเคส</p>
                  <p className="font-medium text-blue-600">{ticketNumber}</p>
                </div>
              )}
              {details && details.map((detail, index) => (
                <div key={index} className={index > 0 ? 'mt-4' : ''}>
                  <p className="text-sm text-gray-600">{detail.label}</p>
                  <p className="font-medium">{detail.value}</p>
                </div>
              ))}
            </div>
          )}

          {/* Actions */}
          {actions && (
            <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
              {actions.map((action, index) => (
                <Button
                  key={index}
                  onClick={action.onClick}
                  variant={action.variant || 'default'}
                  className="w-full sm:w-auto"
                >
                  {action.label}
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
```

**การใช้งาน:**
```tsx
// ✅ CreateTicketPage.tsx - Success State
if (submitted) {
  return (
    <SuccessPage
      title="แจ้งเคสสำเร็จ!"
      description="งานของคุณได้ถูกส่งแล้ว และทีมสนับสนุนของเราจะตรวจสอบในไม่ช้า"
      variant="success"
      ticketNumber={lastTicketNumber}
      details={[
        { label: 'สถานะ', value: 'รอดำเนินการ' },
        { label: 'ประเภท', value: formData.type }
      ]}
      actions={[
        {
          label: 'กลับหน้าแรก',
          onClick: () => onNavigate('/')
        },
        {
          label: 'ติดตามสถานะ',
          onClick: () => onNavigate('/track'),
          variant: 'outline'
        }
      ]}
    />
  );
}

// ✅ CreateTicketPage.tsx - Accepted State
if (ticketAccepted) {
  return (
    <SuccessPage
      title="✅ บันทึกและรับเคสสำเร็จ!"
      description="เคสได้ถูกบันทึกและรับเข้าสู่งานของคุณแล้ว"
      variant="info"
      ticketNumber={lastTicketNumber}
      actions={[
        {
          label: 'ดูรายละเอียดเคส',
          onClick: () => onNavigate('/ticket', lastTicketId)
        },
        {
          label: 'กลับรายการงาน',
          onClick: () => onNavigate('/admin/my-tickets'),
          variant: 'outline'
        }
      ]}
    />
  );
}
```

**ประโยชน์:**
- ✅ ลดโค้ดซ้ำ 250+ บรรทัด
- ✅ รองรับ 3 variants (success, info, warning)
- ✅ รองรับ multiple actions
- ✅ Flexible details display

---

### **Priority 2: สูง (ควรทำ)**

#### **5. PageContainer Component** 🟠

**ปัญหา:** `className="container mx-auto px-4 py-8"` ซ้ำ 15+ ไฟล์

**ก่อน:**
```tsx
<div className="container mx-auto px-4 py-8">
  {children}
</div>

<div className="container mx-auto max-w-3xl px-4 py-8">
  {children}
</div>

<div className="container mx-auto max-w-2xl px-4 py-12">
  {children}
</div>
```

**หลัง:**
```tsx
// ✅ /components/common/PageContainer.tsx
interface PageContainerProps {
  children: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  className?: string;
  noPadding?: boolean;
}

export function PageContainer({ 
  children, 
  maxWidth = 'full',
  className = '',
  noPadding = false
}: PageContainerProps) {
  const maxWidthClasses = {
    sm: 'max-w-2xl',
    md: 'max-w-3xl',
    lg: 'max-w-5xl',
    xl: 'max-w-7xl',
    full: ''
  };

  return (
    <div className={`
      container mx-auto 
      ${maxWidthClasses[maxWidth]}
      ${noPadding ? '' : 'px-4 py-8'}
      ${className}
    `}>
      {children}
    </div>
  );
}
```

**การใช้งาน:**
```tsx
<PageContainer>
  <TicketList />
</PageContainer>

<PageContainer maxWidth="md">
  <CreateTicketForm />
</PageContainer>

<PageContainer maxWidth="sm" className="py-12">
  <SuccessMessage />
</PageContainer>
```

---

#### **6. InfoCard Component** 🟠

**ปัญหา:** Card ที่แสดงข้อมูลแบบ label-value ซ้ำหลายที่

**ก่อน:**
```tsx
<Card>
  <CardHeader>
    <CardTitle>ข้อมูลลูกค้า</CardTitle>
  </CardHeader>
  <CardContent className="space-y-4">
    <div>
      <p className="text-sm text-gray-600">ชื่อ</p>
      <p>{customer.name}</p>
    </div>
    <div>
      <p className="text-sm text-gray-600">อีเมล</p>
      <p>{customer.email}</p>
    </div>
  </CardContent>
</Card>
```

**หลัง:**
```tsx
// ✅ /components/common/InfoCard.tsx
interface InfoField {
  label: string;
  value: React.ReactNode;
  icon?: LucideIcon;
}

interface InfoCardProps {
  title: string;
  fields: InfoField[];
  className?: string;
}

export function InfoCard({ title, fields, className }: InfoCardProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {fields.map((field, index) => (
          <div key={index}>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              {field.icon && <field.icon className="h-4 w-4" />}
              <span>{field.label}</span>
            </div>
            <div className="mt-1">{field.value}</div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
```

**การใช้งาน:**
```tsx
<InfoCard
  title="ข้อมูลลูกค้า"
  fields={[
    { label: 'ชื่อ', value: customer.name, icon: User },
    { label: 'อีเมล', value: customer.email, icon: Mail },
    { label: 'เบอร์โทร', value: customer.phone, icon: Phone }
  ]}
/>
```

---

#### **7. UserAvatar Component** 🟡

**ปัญหา:** โค้ดแสดง Avatar ซ้ำ 5+ ไฟล์

**ก่อน:**
```tsx
<div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white text-sm">
  {user.name?.charAt(0) || '?'}
</div>
```

**หลัง:**
```tsx
// ✅ /components/common/UserAvatar.tsx
interface UserAvatarProps {
  name: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'blue' | 'green' | 'purple' | 'gray';
  className?: string;
}

export function UserAvatar({ 
  name, 
  size = 'md',
  variant = 'blue',
  className = ''
}: UserAvatarProps) {
  const sizeClasses = {
    sm: 'h-6 w-6 text-xs',
    md: 'h-8 w-8 text-sm',
    lg: 'h-10 w-10 text-base'
  };

  const variantClasses = {
    blue: 'bg-blue-600 text-white',
    green: 'bg-green-600 text-white',
    purple: 'bg-purple-600 text-white',
    gray: 'bg-gray-600 text-white'
  };

  return (
    <div className={`
      flex items-center justify-center rounded-full 
      ${sizeClasses[size]} 
      ${variantClasses[variant]}
      ${className}
    `}>
      {name?.charAt(0)?.toUpperCase() || '?'}
    </div>
  );
}
```

**การใช้งาน:**
```tsx
<UserAvatar name={user.name} size="md" variant="blue" />
<UserAvatar name={comment.author} size="sm" variant="green" />
```

---

#### **8. LoadingState Component** 🟡

**ก่อน:**
```tsx
{isLoading && (
  <div className="flex items-center justify-center py-8">
    <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full" />
  </div>
)}
```

**หลัง:**
```tsx
// ✅ /components/common/LoadingState.tsx
interface LoadingStateProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
}

export function LoadingState({ 
  message = 'กำลังโหลด...', 
  size = 'md',
  fullScreen = false
}: LoadingStateProps) {
  const sizeClasses = {
    sm: 'h-6 w-6 border-2',
    md: 'h-8 w-8 border-4',
    lg: 'h-12 w-12 border-4'
  };

  const content = (
    <div className="flex flex-col items-center justify-center gap-3">
      <div className={`
        animate-spin rounded-full border-blue-500 border-t-transparent
        ${sizeClasses[size]}
      `} />
      {message && <p className="text-sm text-gray-600">{message}</p>}
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-white/80 flex items-center justify-center z-50">
        {content}
      </div>
    );
  }

  return (
    <div className="py-8">
      {content}
    </div>
  );
}
```

---

## 📁 โครงสร้าง Folder ใหม่

```
📁 components/
  ├── 📁 common/                    ← ✨ ใหม่! Common reusable components
  │   ├── PageBackButton.tsx        ← Priority 1 🔴
  │   ├── PageHeader.tsx            ← Priority 1 🔴
  │   ├── EmptyState.tsx            ← Priority 1 🔴
  │   ├── SuccessPage.tsx           ← Priority 1 🔴
  │   ├── PageContainer.tsx         ← Priority 2 🟠
  │   ├── InfoCard.tsx              ← Priority 2 🟠
  │   ├── UserAvatar.tsx            ← Priority 2 🟡
  │   ├── LoadingState.tsx          ← Priority 2 🟡
  │   └── index.ts                  ← Export all
  │
  ├── 📁 comments/                  ← ✅ มีอยู่แล้ว
  │   ├── CommentSection.tsx
  │   ├── CommentItem.tsx
  │   ├── CommentForm.tsx
  │   └── PublicCommentConfirmDialog.tsx
  │
  ├── 📁 ui/                        ← Shadcn UI components
  ├── 📁 figma/                     ← Figma imports
  └── ... (other components)
```

---

## 📊 ผลลัพธ์ที่คาดหวัง

### **Before Refactoring:**
- โค้ดซ้ำ: **1,500+ บรรทัด**
- ไฟล์ที่มีโค้ดซ้ำ: **25+ ไฟล์**
- Maintenance: **ยาก** (ต้องแก้หลายที่)

### **After Refactoring:**
- โค้ดซ้ำ: **0 บรรทัด** ✅
- Components ใหม่: **8 components**
- บรรทัดโค้ดที่เพิ่ม: **~600 บรรทัด** (components)
- บรรทัดโค้ดที่ลด: **~1,500 บรรทัด** (ลบโค้ดซ้ำ)
- **Net savings: ~900 บรรทัด** ✅
- Maintenance: **ง่าย** (แก้ที่เดียว) ✅

---

## 🚀 แผนการดำเนินการ

### **Phase 1: Priority 1 Components (Week 1)**
- [ ] สร้าง `PageBackButton.tsx`
- [ ] สร้าง `PageHeader.tsx`
- [ ] สร้าง `EmptyState.tsx`
- [ ] สร้าง `SuccessPage.tsx`
- [ ] Refactor ไฟล์ที่ใช้ทั้ง 4 components
- [ ] Testing

### **Phase 2: Priority 2 Components (Week 2)**
- [ ] สร้าง `PageContainer.tsx`
- [ ] สร้าง `InfoCard.tsx`
- [ ] สร้าง `UserAvatar.tsx`
- [ ] สร้าง `LoadingState.tsx`
- [ ] Refactor ไฟล์ที่ใช้ทั้ง 4 components
- [ ] Testing

### **Phase 3: Documentation (Week 3)**
- [ ] สร้างเอกสาร usage guide
- [ ] สร้าง Storybook (optional)
- [ ] Code review
- [ ] Final testing

---

## ✅ Checklist การ Refactor แต่ละไฟล์

### **TicketDetailPage.tsx:**
- [ ] ใช้ `PageBackButton` แทน Back button
- [ ] ใช้ `PageContainer` แทน container div
- [ ] ใช้ `InfoCard` สำหรับ Customer Info / Ticket Details
- [ ] ใช้ `UserAvatar` ใน Timeline

### **CreateTicketPage.tsx:**
- [ ] ใช้ `PageBackButton` แทน Back button
- [ ] ใช้ `SuccessPage` แทน success states (3 ที่)
- [ ] ใช้ `PageHeader` สำหรับ title
- [ ] ใช้ `PageContainer` แทน container div

### **TicketListPage.tsx:**
- [ ] ใช้ `PageHeader` แทน header section
- [ ] ใช้ `EmptyState` แทน empty state
- [ ] ใช้ `LoadingState` สำหรับ loading

### **... (ไฟล์อื่นๆ)**

---

## 📚 Best Practices

### **1. Component Naming Convention:**
```
✅ Good: PageBackButton, EmptyState, SuccessPage
❌ Bad: BackBtn, Empty, Success
```

### **2. Props Interface:**
```tsx
// ✅ Good: Explicit and typed
interface PageHeaderProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
}

// ❌ Bad: any types
interface Props {
  data: any;
  config: any;
}
```

### **3. Default Props:**
```tsx
// ✅ Good: Use default parameters
function EmptyState({ 
  size = 'md',
  showCard = true
}: EmptyStateProps) { ... }

// ❌ Bad: No defaults
function EmptyState(props: EmptyStateProps) { ... }
```

### **4. File Organization:**
```tsx
// ✅ Good: One component per file
// /components/common/PageBackButton.tsx
export function PageBackButton() { ... }

// ❌ Bad: Multiple components in one file
// /components/common/Buttons.tsx
export function BackButton() { ... }
export function NextButton() { ... }
export function CancelButton() { ... }
```

---

## 🎯 สรุป

การ Refactor นี้จะช่วย:

1. ✅ **ลดโค้ดซ้ำ 1,500+ บรรทัด**
2. ✅ **สร้างมาตรฐานให้ระบบ** - ทุก component มี pattern เดียวกัน
3. ✅ **ง่ายต่อการ maintain** - แก้ไขครั้งเดียว ใช้ได้ทุกหน้า
4. ✅ **Consistent UI/UX** - ทุกหน้ามี look & feel เหมือนกัน
5. ✅ **Developer Experience ดีขึ้น** - เขียนโค้ดเร็วขึ้น
6. ✅ **Testable** - Component เล็กๆ ทดสอบง่าย

---

**Next Steps:**
1. Review แผนนี้
2. เลือก Priority ที่จะทำก่อน
3. เริ่ม implement Phase 1
4. Test และ Review
5. Deploy

---

**เอกสารนี้สร้างเมื่อ:** 21 มกราคม 2026  
**โดย:** System Analysis  
**สถานะ:** 📋 รออนุมัติ
