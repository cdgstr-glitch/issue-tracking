# คำแนะนำในการแก้ไขชื่อใน mockData.ts

เนื่องจากมีชื่อที่ต้องแก้ไขจำนวนมาก (52 จุด) ใน `/lib/mockData.ts` 

## ชื่อที่ต้องแก้ไข:

1. **ธีรพร รุ่งวิรัติกุล** → **ธิราภรณ์ รุ่งวิรัตน์กุล** (39 จุด)
2. **ธัญพร ทองแก้ว** → **ธัญญาพร ทองแก้ว** (1 จุด)
3. **ประกาศิต ประกอบเพชร** → **ประกาศิต ประคองเพ็ชร** (12 จุด)

## วิธีแก้ไขด้วย Text Editor:

### วิธีที่ 1: ใช้ Find & Replace ใน VS Code หรือ Text Editor
1. เปิดไฟล์ `/lib/mockData.ts`
2. กด Ctrl+H (Windows/Linux) หรือ Cmd+H (Mac) เพื่อเปิด Find & Replace
3. แก้ทีละชื่อ:
   - Find: `ธีรพร รุ่งวิรัติกุล` → Replace: `ธิราภรณ์ รุ่งวิรัตน์กุล` → Replace All
   - Find: `ธัญพร ทองแก้ว` → Replace: `ธัญญาพร ทองแก้ว` → Replace All
   - Find: `ประกาศิต ประกอบเพชร` → Replace: `ประกาศิต ประคองเพ็ชร` → Replace All

### วิธีที่ 2: ใช้คำสั่ง sed (สำหรับ Mac/Linux)
```bash
cd /path/to/project

# Backup original file
cp lib/mockData.ts lib/mockData.ts.backup

# Replace names
sed -i '' 's/ธีรพร รุ่งวิรัติกุล/ธิราภรณ์ รุ่งวิรัตน์กุล/g' lib/mockData.ts
sed -i '' 's/ธัญพร ทองแก้ว/ธัญญาพร ทองแก้ว/g' lib/mockData.ts
sed -i '' 's/ประกาศิต ประกอบเพชร/ประกาศิต ประคองเพ็ชร/g' lib/mockData.ts
```

### วิธีที่ 3: ใช้ Python Script
```python
# Save this as fix_names.py and run: python fix_names.py
with open('lib/mockData.ts', 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace('ธีรพร รุ่งวิรัติกุล', 'ธิราภรณ์ รุ่งวิรัตน์กุล')
content = content.replace('ธัญพร ทองแก้ว', 'ธัญญาพร ทองแก้ว')
content = content.replace('ประกาศิต ประกอบเพชร', 'ประกาศิต ประคองเพ็ชร')

with open('lib/mockData.ts', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Fixed all names successfully!")
```

## ตรวจสอบหลังแก้ไข:

หลังจากแก้ไขแล้ว ตรวจสอบว่าไม่มีชื่อเก่าเหลืออยู่:
```bash
# ตรวจสอบว่ายังมีชื่อเก่าหรือไม่
grep "ธีรพร รุ่งวิรัติกุล" lib/mockData.ts
grep "ธัญพร ทองแก้ว" lib/mockData.ts
grep "ประกาศิต ประกอบเพชร" lib/mockData.ts

# ถ้าไม่มีผลลัพธ์ แสดงว่าแก้เสร็จสมบูรณ์
```
