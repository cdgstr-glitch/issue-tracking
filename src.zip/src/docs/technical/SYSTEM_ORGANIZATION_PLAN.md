# 🗂️ System Organization Plan - แผนจัดระเบียบระบบ

**Created:** 26 มกราคม 2026  
**Version:** 1.0  
**Status:** 📋 Planning Phase

---

## 🎯 วัตถุประสงค์

จัดระเบียบโครงสร้างโปรเจค CDGS Issue Tracking Platform ให้:
1. **เอกสารครบถ้วน** - อัพเดทและสอดคล้องกับโค้ดจริง
2. **Mock Data เป็นระบบ** - แยกไฟล์ชัดเจน ง่ายต่อการบำรุงรักษา
3. **Components เป็นหมวดหมู่** - จัดกลุ่มตามหน้าที่

---

## 📋 สารบัญ

1. [Documentation Organization](#1-documentation-organization)
2. [Mock Data Organization](#2-mock-data-organization)
3. [Component Organization](#3-component-organization)
4. [Migration Roadmap](#4-migration-roadmap)
5. [Validation & Testing](#5-validation--testing)

---

## 1. 📚 Documentation Organization

### **ปัญหาปัจจุบัน:**
- ✅ มีเอกสารมากมาย (60+ ไฟล์)
- ⚠️ บางไฟล์ไม่ได้อัพเดท
- ⚠️ กระจัดกระจายไม่มีหมวดหมู่ชัดเจน
- ⚠️ ไม่มี Index หลักที่รวบรวมทุกอย่าง

### **โครงสร้างแนะนำ:**

```
/docs/
│
├── INDEX.md                           # 🎯 Main Index (อัพเดทแล้ว)
│
├── 00-overview/                       # 📖 ภาพรวมระบบ
│   ├── PROJECT_OVERVIEW.md            # ภาพรวมโปรเจค
│   ├── ROLE_STRUCTURE.md              # โครงสร้างบทบาท
│   ├── WORKFLOW.md                    # เวิร์กโฟลว์
│   └── PERMISSIONS_GUIDE.md           # คู่มือ Permission
│
├── 01-roles/                          # 👥 บทบาทผู้ใช้
│   ├── STAFF_ROLE_DOCUMENTATION.md    # บทบาท Staff
│   ├── TIER1_WORKFLOW.md              # Tier1
│   ├── TIER2_WORKFLOW.md              # Tier2
│   ├── TIER3_WORKFLOW.md              # Tier3
│   └── CUSTOMER_WORKFLOW.md           # ลูกค้า
│
├── 02-features/                       # 🎨 ฟีเจอร์
│   ├── COMMENT_SYSTEM.md              # ระบบ Comment
│   ├── ATTACHMENT_FEATURE.md          # ระบบแนบไฟล์
│   ├── PRODUCT_FILTERING.md           # Product Filtering
│   ├── ESCALATION_WORKFLOW.md         # การส่งต่อเคส
│   └── CASE_CLOSURE_WORKFLOW.md       # การปิดเคส
│
├── 03-technical/                      # 🔧 เทคนิค
│   ├── DATABASE_SCHEMA.md             # โครงสร้างฐานข้อมูล
│   ├── MOCK_DATA_INVENTORY.md         # 📊 NEW: สารบบข้อมูล Mock
│   ├── MOCK_DATA_CLOSED_BY_FIX.md     # 🔧 NEW: การแก้ไขข้อมูล
│   ├── PERMISSIONS_MATRIX.md          # ตาราง Permission
│   └── API_ENDPOINTS.md               # (Future) API Docs
│
├── 04-ui-ux/                          # 🎨 UI/UX
│   ├── UI_UX_POLICY.md                # นโยบาย UI/UX
│   ├── BADGE_SYSTEM.md                # ระบบ Badge
│   ├── NAVIGATION_MENU.md             # โครงสร้างเมนู
│   └── CUSTOMER_FRIENDLY_BADGES.md    # Badge สำหรับลูกค้า
│
├── 05-components/                     # 🧩 Components
│   ├── COMMON_COMPONENTS_GUIDE.md     # คู่มือ Common Components
│   ├── TABLE_STRUCTURES.md            # โครงสร้างตาราง
│   └── ORGANIZATION_SELECTOR.md       # Component Selector
│
├── 06-data/                           # 💾 ข้อมูล
│   ├── USER_LIST.md                   # รายชื่อผู้ใช้
│   ├── TEAM_MEMBERS.md                # สมาชิกทีม
│   ├── ORGANIZATION_STRUCTURE.md      # โครงสร้างหน่วยงาน
│   └── PROJECT_CODE_FORMAT.md         # รูปแบบ Project Code
│
├── 07-deployment/                     # 🚀 Deployment
│   ├── DEPLOYMENT_GUIDE.md            # คู่มือติดตั้ง
│   ├── MIGRATION_CHECKLIST.md         # Checklist Migration
│   └── LARAVEL_MIGRATIONS_GUIDE.md    # Laravel Migrations
│
└── 99-changelog/                      # 📝 บันทึกการเปลี่ยนแปลง
    ├── CHANGELOG.md                   # ประวัติการอัพเดท
    ├── MOCK_DATA_CLOSED_BY_FIX.md     # 🔧 NEW: Fix Log
    └── LOGOUT_BUG_FIX.md              # Bug Fix Log
```

### **Action Items:**

- [ ] สร้างโฟลเดอร์ตามโครงสร้างด้านบน
- [ ] ย้ายไฟล์ไปยังโฟลเดอร์ที่เหมาะสม
- [ ] อัพเดท INDEX.md ให้ครบถ้วน
- [ ] ลบไฟล์ซ้ำซ้อน (เช่น BACKUP files)
- [ ] เพิ่ม Table of Contents ในแต่ละหมวด

---

## 2. 💾 Mock Data Organization

### **ปัญหาปัจจุบัน:**
- ⚠️ ข้อมูลกระจัดกระจายใน 10+ ไฟล์
- ⚠️ `/lib/mockData.ts` ใหญ่มาก (3000+ บรรทัด)
- ⚠️ ยากต่อการหา/แก้ไขข้อมูล
- ⚠️ ไม่มี validation

### **Current State:**

```
/lib/
├── mockData.ts                    # ⚠️ ใหญ่มาก 3000+ บรรทัด
├── mockDataStaffClosed.ts         # 3 เคส
├── mockDataCSV.ts                 # CSV data
├── mockDataCSVTickets.ts          # CSV tickets
├── mockDataExtra.ts               # เพิ่มเติม
├── mockDataTier23More.ts          # Tier2/3
├── mockDataTier23Resolved.ts      # Tier2/3 ปิดแล้ว
├── mockDataProducts.ts            # Products
└── mockDataReports.ts             # Reports
```

### **Recommended Structure:**

```
/lib/mockData/
│
├── index.ts                       # 🎯 Main export hub
│
├── users.ts                       # ✅ Users (13)
├── projects.ts                    # ✅ Projects (73)
├── organizations.ts               # ✅ Organizations (5)
├── products.ts                    # ✅ Products (15)
│
├── tickets/                       # 📦 Tickets Module
│   ├── index.ts                   # Export all tickets
│   │
│   ├── customer-created/          # เคสที่ลูกค้าสร้าง
│   │   ├── active.ts              # เคส Active (~60)
│   │   └── closed.ts              # เคสปิดแล้ว (~40)
│   │
│   ├── staff-created/             # เคสที่ Staff สร้าง
│   │   ├── active.ts              # เคส Active (~60)
│   │   ├── closed.ts              # เคสปิดแล้ว (~40)
│   │   └── backlog.ts             # เคสย้อนหลัง (3 เคส)
│   │
│   ├── tier2/                     # เคส Tier2
│   │   ├── active.ts              # Active (~15)
│   │   └── resolved.ts            # Resolved (~5)
│   │
│   └── tier3/                     # เคส Tier3
│       ├── active.ts              # Active (~5)
│       └── resolved.ts            # Resolved (~5)
│
├── helpers/                       # 🔧 Helpers
│   ├── attachments.ts             # ✅ Attachments
│   ├── timeline.ts                # Timeline generators
│   ├── validation.ts              # Data validation
│   └── generators.ts              # Mock data generators
│
└── README.md                      # ✅ Documentation
```

### **Migration Plan:**

#### **Phase 1: Prepare Structure ✅**
- [x] Create `/lib/mockData/` folder
- [x] Migrate Users
- [x] Migrate Projects
- [x] Migrate Organizations
- [x] Migrate Products

#### **Phase 2: Migrate Tickets 📋**
- [x] Create `tickets/` folder structure
- [x] Create README.md
- [x] Migrate Staff Closed tickets → `staff-closed.ts`
- [x] Create validation helpers → `helpers/validation.ts`
- [x] Create validation script → `scripts/validate-mockdata.ts`
- [x] Setup CSV tickets module → `csv/`
- [x] Setup Customer tickets module → `customer/`
- [x] Setup Staff tickets module → `staff/`
- [x] Setup Tier2 tickets module → `tier2/`
- [x] Setup Tier3 tickets module → `tier3/`
- [x] Setup Other tickets module → `other/`
- [ ] Migrate CSV tickets data → `csv/part1.ts`, `csv/part2.ts`
- [ ] Migrate Customer Active tickets → `customer/active.ts`
- [ ] Migrate Customer Closed tickets → `customer/closed.ts`
- [ ] Migrate Staff Active tickets → `staff/active.ts`
- [ ] Migrate Tier2/3 active data
- [ ] Migrate Other tickets data

#### **Phase 3: Validation 🧪**
- [x] Create validation script
- [ ] Validate all tickets
- [ ] Fix data inconsistencies
- [ ] Run automated tests

#### **Phase 4: Cleanup 🧹**
- [ ] Delete old files
- [ ] Update imports
- [ ] Update documentation
- [ ] Test thoroughly

### **Benefits:**
1. **แยกไฟล์ชัดเจน** - หาง่าย แก้ไขง่าย
2. **ขนาดไฟล์เล็กลง** - แต่ละไฟล์ไม่เกิน 500 บรรทัด
3. **Parallel Development** - หลายคนแก้พร้อมกันได้
4. **Type Safety** - Type checking ทำงานเร็วขึ้น
5. **Version Control** - Git diff ชัดเจน

---

## 3. 🧩 Component Organization

### **ปัญหาปัจจุบัน:**
- ✅ มี 70+ components
- ⚠️ ไม่มีการจัดกลุ่ม (ยกเว้น ui/, comments/, reports/)
- ⚠️ ยากต่อการหา component

### **Current Structure:**

```
/components/
├── ui/                            # ✅ UI Components (30+)
├── comments/                      # ✅ Comment System (4)
├── reports/                       # ✅ Reports (5)
├── common/                        # ✅ Common Components (4)
├── customer/                      # ✅ Customer (2)
└── figma/                         # ✅ Figma (1)
└── [60+ other components]         # ⚠️ Flat structure
```

### **Recommended Structure:**

```
/components/
│
├── ui/                            # ✅ Base UI Components
│   ├── button.tsx
│   ├── card.tsx
│   └── ... (30+ files)
│
├── common/                        # ✅ Shared Components
│   ├── EmptyState.tsx
│   ├── PageHeader.tsx
│   ├── PageBackButton.tsx
│   └── SuccessPage.tsx
│
├── layout/                        # 🆕 Layout Components
│   ├── Header.tsx
│   ├── Sidebar.tsx
│   ├── ProtectedRoute.tsx
│   └── ReadOnlyModeBanner.tsx
│
├── auth/                          # 🆕 Authentication
│   ├── LoginPage.tsx
│   ├── RegisterPage.tsx
│   ├── ForgotPasswordPage.tsx
│   └── ProfilePage.tsx
│
├── dashboard/                     # 🆕 Dashboard Pages
│   ├── AdminDashboard.tsx
│   ├── AnalyticsDashboard.tsx
│   ├── SADashboard.tsx
│   └── SpecialistDashboard.tsx
│
├── tickets/                       # 🆕 Ticket Management
│   ├── CreateTicketPage.tsx
│   ├── TicketListPage.tsx
│   ├── TicketDetailPage.tsx
│   ├── TicketCard.tsx
│   ├── TicketTable.tsx
│   ├── TicketTimeline.tsx
│   ├── TicketActions.tsx
│   └── TicketStatusAlert.tsx
│
├── tickets-staff/                 # 🆕 Staff Ticket Pages
│   ├── StaffHomePage.tsx
│   ├── StaffTrackTicketPage.tsx
│   ├── StaffTicketDetailPage.tsx
│   ├── StaffClosedTicketsPage.tsx
│   ├── StaffClosedTicketDetailPage.tsx
│   └── StaffJourneyPage.tsx
│
├── tickets-customer/              # 🆕 Customer Pages
│   ├── CustomerHomePage.tsx
│   ├── CustomerTrackTicketPage.tsx
│   ├── CustomerFAQPage.tsx
│   ├── CustomerJourneyPage.tsx
│   ├── TrackTicketDetailPage.tsx
│   ├── EmailPreview.tsx
│   └── MagicLinkVerification.tsx
│
├── journey/                       # 🆕 Journey Pages
│   ├── Tier1JourneyPage.tsx
│   ├── Tier2JourneyPage.tsx
│   ├── Tier3JourneyPage.tsx
│   ├── UserJourneyDiagram.tsx
│   ├── TierEscalationDiagram.tsx
│   └── DecisionFlowchart.tsx
│
├── escalation/                    # 🆕 Escalation
│   ├── EscalatedPage.tsx
│   └── EscalatedSection.tsx
│
├── admin/                         # 🆕 Admin Pages
│   ├── SettingsPage.tsx
│   ├── TeamManagementPage.tsx
│   ├── ProjectSettingsPage.tsx
│   ├── ProductManagementPage.tsx
│   └── DataManagementPage.tsx
│
├── reports/                       # ✅ Reports
│   ├── ReportsPage.tsx
│   ├── DashboardReport.tsx
│   ├── ChannelReport.tsx
│   ├── OrganizationReport.tsx
│   ├── SLAReport.tsx
│   └── StaffReport.tsx
│
├── comments/                      # ✅ Comment System
│   ├── CommentSection.tsx
│   ├── CommentForm.tsx
│   ├── CommentItem.tsx
│   └── PublicCommentConfirmDialog.tsx
│
├── badges/                        # 🆕 Badge Components
│   ├── StatusBadge.tsx
│   ├── PriorityBadge.tsx
│   ├── ChannelBadge.tsx
│   ├── AssignedBadge.tsx
│   ├── StakeholderBadge.tsx
│   └── ViewerBadge.tsx
│
├── selectors/                     # 🆕 Selector Components
│   ├── AssigneeSelector.tsx
│   ├── OrganizationSelector.tsx
│   ├── ProjectSelector.tsx
│   ├── ProjectSelectorModal.tsx
│   └── HashtagDropdown.tsx
│
├── forms/                         # 🆕 Form Components
│   ├── RichTextEditor.tsx
│   ├── TagInput.tsx
│   ├── AttachmentUpload.tsx
│   ├── AttachmentGallery.tsx
│   └── ImageUploader.tsx
│
├── cards/                         # 🆕 Card Components
│   ├── CustomerInfoCard.tsx
│   ├── AssignmentInfoCard.tsx
│   ├── StatsCard.tsx
│   ├── OrganizationStatsCard.tsx
│   └── SLAIndicator.tsx
│
├── modals/                        # 🆕 Modals
│   ├── EmailPreviewModal.tsx
│   ├── ExportReportModal.tsx
│   └── TakeoverConfirmationModal.tsx
│
├── pagination/                    # 🆕 Pagination
│   ├── Pagination.tsx
│   └── StandardPagination.tsx
│
├── notifications/                 # 🆕 Notifications
│   └── NotificationsPage.tsx
│
└── error/                         # 🆕 Error Handling
    └── ErrorBoundary.tsx
```

### **Migration Strategy:**

#### **Option A: Gradual (แนะนำ) ⭐**
- ไม่ย้าย component จนกว่าจะต้องแก้ไข
- เมื่อแก้ไข component ให้ย้ายไปยังโฟลเดอร์ที่เหมาะสม
- Update imports
- ใช้เวลา 2-3 สัปดาห์

#### **Option B: Big Bang**
- ย้ายทั้งหมดพร้อมกัน
- ต้อง update imports ทั้งหมด
- ใช้เวลา 1-2 วัน
- เสี่ยงต่อ breaking changes

### **Benefits:**
1. **หาง่าย** - รู้ว่า component อยู่ที่ไหน
2. **Scalable** - เพิ่ม component ใหม่ง่าย
3. **Maintainable** - แยกหน้าที่ชัดเจน
4. **Developer Experience** - ทำงานง่ายขึ้น

---

## 4. 🗺️ Migration Roadmap

### **Week 1: Documentation (ปัจจุบัน)**
- [x] สร้าง MOCK_DATA_INVENTORY.md
- [x] สร้าง MOCK_DATA_CLOSED_BY_FIX.md
- [x] สร้าง SYSTEM_ORGANIZATION_PLAN.md
- [ ] สร้างโฟลเดอร์ตาม Documentation Structure
- [ ] ย้ายเอกสารไปยังโฟลเดอร์ที่เหมาะสม
- [ ] อัพเดท INDEX.md

### **Week 2: Mock Data Structure**
- [ ] สร้างโครงสร้าง `tickets/` folder
- [ ] แยก Customer tickets
- [ ] แยก Staff tickets
- [ ] แยก Tier2/3 tickets
- [ ] สร้าง validation script

### **Week 3: Mock Data Migration**
- [ ] Migrate Customer Active tickets
- [ ] Migrate Customer Closed tickets
- [ ] Migrate Staff Active tickets
- [ ] Migrate Staff Closed tickets
- [ ] Migrate Tier2/3 tickets

### **Week 4: Validation & Testing**
- [ ] Run validation script
- [ ] Fix data inconsistencies
- [ ] Test all features
- [ ] Update documentation

### **Week 5-6: Component Organization**
- [ ] Create folder structure
- [ ] Migrate components (gradual)
- [ ] Update imports
- [ ] Test thoroughly

### **Week 7: Cleanup**
- [ ] Delete old files
- [ ] Remove deprecated code
- [ ] Final testing
- [ ] Deploy

---

## 5. ✅ Validation & Testing

### **Validation Scripts:**

#### **1. Data Validation**
```typescript
// /lib/mockData/helpers/validation.ts

export function validateClosedCases() {
  const invalidCases = allTickets.filter(t =>
    t.status === 'closed' && 
    !isTier1User(t.closedBy)
  );
  
  if (invalidCases.length > 0) {
    console.error('❌ Found invalid closed cases:', invalidCases);
    throw new Error(`Found ${invalidCases.length} cases closed by non-Tier1 users`);
  }
  
  console.log('✅ All closed cases are valid');
}

export function validateStaffCases() {
  const invalidCases = allTickets.filter(t =>
    t.createdByType === 'staff' && 
    !['phone', 'email', 'line'].includes(t.channel)
  );
  
  if (invalidCases.length > 0) {
    console.error('❌ Found invalid staff cases:', invalidCases);
    throw new Error(`Found ${invalidCases.length} staff cases with invalid channel`);
  }
  
  console.log('✅ All staff cases are valid');
}

export function validateProjectCodes() {
  const invalidCodes = allProjects.filter(p =>
    !/^D\d{2}-\d{4}$/.test(p.code)
  );
  
  if (invalidCodes.length > 0) {
    console.error('❌ Found invalid project codes:', invalidCodes);
    throw new Error(`Found ${invalidCodes.length} projects with invalid code format`);
  }
  
  console.log('✅ All project codes are valid');
}

export function validateAll() {
  console.log('🔍 Running validation...\n');
  
  validateClosedCases();
  validateStaffCases();
  validateProjectCodes();
  
  console.log('\n✅ All validations passed!');
}
```

#### **2. Testing Checklist**
```markdown
## Pre-Migration Testing
- [ ] All features work correctly
- [ ] No console errors
- [ ] All pages load
- [ ] Authentication works
- [ ] Data displays correctly

## Post-Migration Testing
- [ ] All features still work
- [ ] No broken imports
- [ ] No console errors
- [ ] All pages load
- [ ] Data matches original
- [ ] Performance unchanged

## Regression Testing
- [ ] Login/Logout
- [ ] Create Ticket
- [ ] View Ticket
- [ ] Comment on Ticket
- [ ] Close Ticket
- [ ] Escalate Ticket
- [ ] View Reports
- [ ] Admin Functions
```

---

## 📊 Progress Tracking

### **Overall Progress:**

```
Documentation:   [####------] 40%
Mock Data:       [###-------] 30%
Components:      [#---------] 10%
Validation:      [----------] 0%
Overall:         [##--------] 20%
```

### **Detailed Progress:**

| Phase | Status | Progress | ETA |
|-------|--------|----------|-----|
| **Documentation** | 🟡 In Progress | 40% | Week 1 |
| **Mock Data Structure** | 🟡 In Progress | 30% | Week 2 |
| **Mock Data Migration** | ⚪ Not Started | 0% | Week 3-4 |
| **Component Organization** | ⚪ Not Started | 0% | Week 5-6 |
| **Validation & Testing** | ⚪ Not Started | 0% | Week 7 |

---

## 🎯 Success Criteria

### **Documentation:**
- [x] มีเอกสารครบถ้วน
- [x] จัดหมวดหมู่ชัดเจน
- [x] อัพเดทตรงกับโค้ดจริง
- [ ] มี Index หลักที่ครบถ้วน

### **Mock Data:**
- [x] แยกไฟล์ชัดเจน
- [x] ขนาดไฟล์เหมาะสม (<500 บรรทัด/ไฟล์)
- [ ] มี validation
- [ ] มี automated tests

### **Components:**
- [ ] จัดกลุ่มตามหน้าที่
- [ ] หาง่าย
- [ ] ไม่มี breaking changes

---

## 📚 เอกสารที่เกี่ยวข้อง

- [MOCK_DATA_INVENTORY.md](/docs/MOCK_DATA_INVENTORY.md) - สารบบข้อมูล Mock
- [MOCK_DATA_CLOSED_BY_FIX.md](/docs/MOCK_DATA_CLOSED_BY_FIX.md) - การแก้ไขข้อมูล
- [/lib/mockData/README.md](/lib/mockData/README.md) - โครงสร้างข้อมูล
- [INDEX.md](/docs/INDEX.md) - Index หลัก

---

**เอกสารนี้อัพเดทล่าสุด:** 26 มกราคม 2026  
**สถานะ:** 📋 Planning Phase  
**ผู้รับผิดชอบ:** Development Team