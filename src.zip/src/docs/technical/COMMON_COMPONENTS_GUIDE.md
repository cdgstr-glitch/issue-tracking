# 🧩 Common Components Usage Guide

**วันที่:** 21 มกราคม 2026  
**เวอร์ชัน:** 1.0.0  
**สถานะ:** ✅ พร้อมใช้งาน

---

## 📚 สารบัญ

1. [ภาพรวม](#ภาพรวม)
2. [การติดตั้ง](#การติดตั้ง)
3. [Components](#components)
   - [PageBackButton](#pagebackbutton)
   - [PageHeader](#pageheader)
   - [EmptyState](#emptystate)
   - [SuccessPage](#successpage)
4. [ตัวอย่างการใช้งานจริง](#ตัวอย่างการใช้งานจริง)
5. [Best Practices](#best-practices)

---

## 🎯 ภาพรวม

Common Components คือชุด Component ที่ออกแบบมาเพื่อ:

- ✅ **ลดโค้ดซ้ำ** - เขียนครั้งเดียว ใช้ได้ทุกที่
- ✅ **สร้างมาตรฐาน** - UI สม่ำเสมอทั้งระบบ
- ✅ **ง่ายต่อการ maintain** - แก้ไขที่เดียว อัปเดตทุกหน้า
- ✅ **Developer-friendly** - API ง่าย ใช้งานสะดวก

---

## 📦 การติดตั้ง

Components อยู่ที่ `/components/common/`

**Import แบบ named import:**
```tsx
import { PageBackButton, PageHeader, EmptyState, SuccessPage } from '../components/common';
```

**Import แยกไฟล์:**
```tsx
import { PageBackButton } from '../components/common/PageBackButton';
import { PageHeader } from '../components/common/PageHeader';
```

---

## 🧩 Components

### **1. PageBackButton**

ปุ่มกลับที่ใช้ร่วมกันทั้งระบบ

#### **Props:**

| Prop | Type | Default | Required | Description |
|------|------|---------|----------|-------------|
| `onNavigate` | `(path: string) => void` | - | ✅ | Function สำหรับนำทาง |
| `backPath` | `string` | - | ✅ | Path ที่จะกลับไป |
| `label` | `string` | `'กลับ'` | ❌ | ข้อความบนปุ่ม |
| `variant` | `'ghost' \| 'outline' \| 'default'` | `'ghost'` | ❌ | รูปแบบปุ่ม |
| `size` | `'sm' \| 'default' \| 'lg'` | `'default'` | ❌ | ขนาดปุ่ม |
| `className` | `string` | `''` | ❌ | CSS classes เพิ่มเติม |
| `showIcon` | `boolean` | `true` | ❌ | แสดงไอคอนลูกศร |
| `hideTextOnMobile` | `boolean` | `false` | ❌ | ซ่อนข้อความบน mobile |

#### **ตัวอย่างการใช้งาน:**

```tsx
// ✅ พื้นฐาน - กลับหน้าแรก
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/" 
/>

// ✅ กลับพร้อมข้อความ
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/track" 
  label="กลับรายการเคส"
/>

// ✅ ขนาดเล็ก ซ่อนข้อความบน mobile
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/admin" 
  size="sm"
  hideTextOnMobile
/>

// ✅ Variant outline
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/dashboard" 
  label="กลับแดชบอร์ด"
  variant="outline"
/>
```

---

### **2. PageHeader**

Header หน้าที่ใช้ร่วมกันทั้งระบบ

#### **Props:**

| Prop | Type | Default | Required | Description |
|------|------|---------|----------|-------------|
| `title` | `string` | - | ✅ | หัวข้อหน้า |
| `subtitle` | `string` | `undefined` | ❌ | คำอธิบายใต้หัวข้อ |
| `badge` | `React.ReactNode` | `undefined` | ❌ | Badge หรือ tag |
| `actions` | `React.ReactNode` | `undefined` | ❌ | ปุ่ม actions |
| `className` | `string` | `'mb-6'` | ❌ | CSS classes เพิ่มเติม |

#### **ตัวอย่างการใช้งาน:**

```tsx
// ✅ พื้นฐาน - เฉพาะ title
<PageHeader title="งานของฉัน" />

// ✅ Title + Subtitle
<PageHeader 
  title="รายการเคสทั้งหมด" 
  subtitle="จัดการและติดตามเคสของคุณ" 
/>

// ✅ Title + Badge
<PageHeader 
  title="งานของฉัน" 
  subtitle="รายการงานที่คุณรับผิดชอบ"
  badge={<Badge variant="secondary">{ticketCount} เคส</Badge>}
/>

// ✅ Title + Actions
<PageHeader 
  title="รายการเคส" 
  subtitle="ติดตามและจัดการเคสทั้งหมด"
  actions={
    <div className="flex gap-2">
      <Button variant="outline">ส่งออก</Button>
      <Button>สร้างเคสใหม่</Button>
    </div>
  }
/>

// ✅ Full - Title + Subtitle + Badge + Actions
<PageHeader 
  title="งานที่ส่งต่อ" 
  subtitle="เคสที่คุณส่งต่อให้ทีมอื่น"
  badge={<Badge variant="destructive">{escalatedCount} เคส</Badge>}
  actions={
    <Button onClick={handleRefresh}>
      <RefreshCw className="h-4 w-4 mr-2" />
      รีเฟรช
    </Button>
  }
/>
```

---

### **3. EmptyState**

แสดงสถานะว่างเปล่าที่ใช้ร่วมกันทั้งระบบ

#### **Props:**

| Prop | Type | Default | Required | Description |
|------|------|---------|----------|-------------|
| `title` | `string` | - | ✅ | หัวข้อ |
| `description` | `string` | `undefined` | ❌ | คำอธิบาย |
| `icon` | `LucideIcon` | `undefined` | ❌ | ไอคอน |
| `action` | `{ label, onClick, variant? }` | `undefined` | ❌ | ปุ่ม action |
| `variant` | `'default' \| 'info' \| 'warning'` | `'default'` | ❌ | รูปแบบ |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | ❌ | ขนาด |
| `showCard` | `boolean` | `true` | ❌ | แสดง Card wrapper |
| `className` | `string` | `''` | ❌ | CSS classes เพิ่มเติม |

#### **ตัวอย่างการใช้งาน:**

```tsx
import { Inbox, Users, FolderOpen, Search } from 'lucide-react';

// ✅ พื้นฐาน
<EmptyState
  icon={Inbox}
  title="ไม่พบเคส"
  description="ไม่มีเคสที่ตรงกับเงื่อนไข"
/>

// ✅ พร้อม action button
<EmptyState
  icon={Users}
  title="ไม่พบสมาชิกทีม"
  description="ลองค้นหาด้วยคำอื่น"
  action={{
    label: 'ล้างการค้นหา',
    onClick: () => setSearchQuery('')
  }}
/>

// ✅ Variant info
<EmptyState
  icon={FolderOpen}
  title="ยังไม่มีโครงการ"
  description="สร้างโครงการแรกของคุณเพื่อเริ่มต้น"
  variant="info"
  action={{
    label: 'สร้างโครงการใหม่',
    onClick: () => setShowCreateModal(true)
  }}
/>

// ✅ ขนาดเล็ก ไม่มี card
<EmptyState
  icon={Search}
  title="ไม่พบผลการค้นหา"
  size="sm"
  showCard={false}
/>

// ✅ Conditional rendering
{filteredTickets.length === 0 && (
  <EmptyState
    icon={Inbox}
    title="ไม่พบเคส"
    description="ไม่มีเคสที่ตรงกับตัวกรองที่เลือก"
    action={{
      label: 'ล้างตัวกรอง',
      onClick: handleResetFilters,
      variant: 'outline'
    }}
    size="md"
  />
)}
```

---

### **4. SuccessPage**

หน้าแสดงผลสำเร็จที่ใช้ร่วมกันทั้งระบบ

#### **Props:**

| Prop | Type | Default | Required | Description |
|------|------|---------|----------|-------------|
| `title` | `string` | - | ✅ | หัวข้อ |
| `description` | `string` | - | ✅ | คำอธิบาย |
| `icon` | `LucideIcon` | `CheckCircle` | ❌ | ไอคอน |
| `variant` | `'success' \| 'info' \| 'warning'` | `'success'` | ❌ | รูปแบบ |
| `ticketNumber` | `string` | `undefined` | ❌ | หมายเลขเคส |
| `details` | `{ label, value }[]` | `undefined` | ❌ | รายละเอียดเพิ่มเติม |
| `actions` | `{ label, onClick, variant? }[]` | `undefined` | ❌ | ปุ่ม actions |
| `className` | `string` | `''` | ❌ | CSS classes เพิ่มเติม |

#### **ตัวอย่างการใช้งาน:**

```tsx
// ✅ พื้นฐาน - Success
<SuccessPage
  title="แจ้งเคสสำเร็จ!"
  description="งานของคุณได้ถูกส่งแล้ว และทีมสนับสนุนของเราจะตรวจสอบในไม่ช้า"
  variant="success"
  ticketNumber="TK-2026-001"
  actions={[
    {
      label: 'กลับหน้าแรก',
      onClick: () => onNavigate('/')
    }
  ]}
/>

// ✅ พร้อม details
<SuccessPage
  title="✅ บันทึกและรับเคสสำเร็จ!"
  description="เคสได้ถูกบันทึกและรับเข้าสู่งานของคุณแล้ว คุณสามารถดำเนินการต่อได้ทันที"
  variant="info"
  ticketNumber="TK-2026-002"
  details={[
    { label: 'สถานะ', value: 'กำลังดำเนินการ' },
    { label: 'ผู้รับผิดชอบ', value: 'คุณ (Tier 1)' },
    { label: 'ประเภท', value: 'ปัญหาทางเทคนิค' }
  ]}
  actions={[
    {
      label: 'ดูรายละเอียดเคส',
      onClick: () => onNavigate('/ticket', ticketId)
    },
    {
      label: 'กลับรายการงาน',
      onClick: () => onNavigate('/admin/my-tickets'),
      variant: 'outline'
    }
  ]}
/>

// ✅ Multiple actions
<SuccessPage
  title="✅ บันทึกและปิดเคสสำเร็จ!"
  description="เคสได้ถูกบันทึกและปิดเรียบร้อยแล้ว คุณสามารถดูย้อนหลังได้ที่เมนู \"เคสที่ปิดย้อนหลัง\""
  variant="success"
  ticketNumber="TK-2026-003"
  details={[
    { label: 'สถานะ', value: 'ปิดเรียบร้อย' },
    { label: 'วันที่ปิด', value: formatDate(new Date()) }
  ]}
  actions={[
    {
      label: 'ดูเคสที่ปิดย้อนหลัง',
      onClick: () => onNavigate('/closed-tickets')
    },
    {
      label: 'สร้างเคสใหม่',
      onClick: () => onNavigate('/create'),
      variant: 'outline'
    },
    {
      label: 'กลับหน้าแรก',
      onClick: () => onNavigate('/'),
      variant: 'secondary'
    }
  ]}
/>

// ✅ Custom icon + warning variant
import { AlertTriangle } from 'lucide-react';

<SuccessPage
  title="⚠️ เคสถูกระงับชั่วคราว"
  description="เคสของคุณถูกระงับชั่วคราวเนื่องจากรอข้อมูลเพิ่มเติมจากลูกค้า"
  icon={AlertTriangle}
  variant="warning"
  ticketNumber="TK-2026-004"
  details={[
    { label: 'สถานะ', value: 'ระงับชั่วคราว' },
    { label: 'เหตุผล', value: 'รอข้อมูลเพิ่มเติมจากลูกค้า' }
  ]}
  actions={[
    {
      label: 'ดูรายละเอียด',
      onClick: () => onNavigate('/ticket', ticketId)
    }
  ]}
/>
```

---

## 💡 ตัวอย่างการใช้งานจริง

### **หน้า Ticket List:**

```tsx
import { PageBackButton, PageHeader, EmptyState } from '../components/common';
import { Inbox } from 'lucide-react';

export function TicketListPage({ onNavigate }) {
  const [tickets, setTickets] = useState([]);
  const [ticketCount, setTicketCount] = useState(0);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <PageBackButton 
        onNavigate={onNavigate} 
        backPath="/dashboard" 
        label="กลับแดชบอร์ด"
        className="mb-4"
      />

      {/* Header */}
      <PageHeader 
        title="งานของฉัน" 
        subtitle="รายการงานที่คุณรับผิดชอบ"
        badge={<Badge variant="secondary">{ticketCount} เคส</Badge>}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleExport}>
              ส่งออก
            </Button>
            <Button onClick={() => onNavigate('/create')}>
              สร้างเคสใหม่
            </Button>
          </div>
        }
      />

      {/* Content */}
      {tickets.length === 0 ? (
        <EmptyState
          icon={Inbox}
          title="ไม่มีเคสในขณะนี้"
          description="คุณยังไม่มีเคสที่รับผิดชอบ"
          action={{
            label: 'สร้างเคสใหม่',
            onClick: () => onNavigate('/create')
          }}
        />
      ) : (
        <TicketTable tickets={tickets} />
      )}
    </div>
  );
}
```

---

### **หน้า Create Ticket (Success State):**

```tsx
import { SuccessPage } from '../components/common';

export function CreateTicketPage({ onNavigate }) {
  const [submitted, setSubmitted] = useState(false);
  const [lastTicketNumber, setLastTicketNumber] = useState('');
  const [lastTicketId, setLastTicketId] = useState('');

  if (submitted) {
    return (
      <SuccessPage
        title="แจ้งเคสสำเร็จ!"
        description="งานของคุณได้ถูกส่งแล้ว และทีมสนับสนุนของเราจะตรวจสอบในไม่ช้า"
        variant="success"
        ticketNumber={lastTicketNumber}
        details={[
          { label: 'สถานะ', value: 'รอดำเนินการ' },
          { label: 'ประเภท', value: formData.type }
        ]}
        actions={[
          {
            label: 'กลับหน้าแรก',
            onClick: () => onNavigate('/')
          },
          {
            label: 'ติดตามสถานะ',
            onClick: () => onNavigate('/track'),
            variant: 'outline'
          }
        ]}
      />
    );
  }

  return (
    <div>
      {/* Form content */}
    </div>
  );
}
```

---

## ✅ Best Practices

### **1. ใช้ Named Imports**

```tsx
// ✅ Good
import { PageBackButton, PageHeader } from '../components/common';

// ❌ Avoid
import * as Common from '../components/common';
```

---

### **2. ใช้ Props ที่จำเป็นเท่านั้น**

```tsx
// ✅ Good - ใช้ props ที่จำเป็น
<PageBackButton onNavigate={onNavigate} backPath="/" />

// ❌ Bad - ส่ง props ที่ไม่จำเป็น
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/" 
  variant="ghost" // default อยู่แล้ว
  showIcon={true} // default อยู่แล้ว
/>
```

---

### **3. Consistent Styling**

```tsx
// ✅ Good - ใช้ variant ที่มี
<EmptyState variant="info" ... />

// ❌ Bad - custom class ทับ
<EmptyState className="bg-blue-100" ... /> // ใช้ variant แทน
```

---

### **4. Conditional Rendering**

```tsx
// ✅ Good
{tickets.length === 0 && (
  <EmptyState icon={Inbox} title="ไม่มีเคส" />
)}

// ✅ Also Good
{!isLoading && tickets.length === 0 && (
  <EmptyState icon={Inbox} title="ไม่มีเคส" />
)}
```

---

### **5. Responsive Design**

```tsx
// ✅ Good - hideTextOnMobile สำหรับปุ่มเล็ก
<PageBackButton 
  onNavigate={onNavigate} 
  backPath="/" 
  size="sm"
  hideTextOnMobile // ซ่อนข้อความบน mobile
/>

// ✅ Good - Actions responsive
<PageHeader 
  actions={
    <div className="flex flex-col gap-2 sm:flex-row">
      <Button>Action 1</Button>
      <Button>Action 2</Button>
    </div>
  }
/>
```

---

## 📝 สรุป

Common Components ช่วยให้:

1. ✅ **โค้ดสะอาด** - ไม่มีโค้ดซ้ำ
2. ✅ **UI สม่ำเสมอ** - ทุกหน้ามี look & feel เดียวกัน
3. ✅ **Maintain ง่าย** - แก้ไขที่เดียว อัปเดตทุกหน้า
4. ✅ **Developer-friendly** - API ง่าย เรียนรู้เร็ว
5. ✅ **Responsive** - รองรับ mobile และ desktop

---

**เอกสารนี้สร้างเมื่อ:** 21 มกราคม 2026  
**โดย:** Development Team  
**เวอร์ชัน:** 1.0.0
