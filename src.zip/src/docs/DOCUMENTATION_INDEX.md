# 📚 CDGS Issue Tracking Platform - Documentation Index

**ศูนย์รวมเอกสารนโยบายและคู่มือการใช้งานระบบ CDGS Issue Tracking Platform**

---

## 📖 สารบัญเอกสาร

### 🎯 **นโยบายหลัก (Core Policies)**

| เอกสาร | หัวข้อ | คำอธิบาย | อัปเดตล่าสุด |
|--------|--------|----------|--------------|
| [MANUAL_ACCEPT_POLICY.md](./features/MANUAL_ACCEPT_POLICY.md) | นโยบายการรับเคสแบบ Manual | อธิบายกฎการรับเคสที่ต้องกดปุ่มเองทุกครั้ง (ไม่มี auto-accept) | 23 ม.ค. 2026 |
| [COMMENT_POLICY.md](./features/COMMENT_POLICY.md) | นโยบายการแสดงความคิดเห็น | กฎการ Comment และการซ่อนกล่อง Comment เมื่อเคสปิดแล้ว | 23 ม.ค. 2026 |
| [MULTI_ROLE_ACCEPT_BUTTON_POLICY.md](./features/MULTI_ROLE_ACCEPT_BUTTON_POLICY.md) | นโยบายการแสดงปุ่ม "รับเคส" สำหรับ Multi-Role | อธิบายกลไกการแสดงปุ่มรับเคสสำหรับผู้ใช้ที่มีหลาย Role | 23 ม.ค. 2026 |
| [FILTER_DISPLAY_POLICY.md](./features/FILTER_DISPLAY_POLICY.md) | นโยบายการแสดงตัวกรอง | กฎการแสดงผลตัวกรอง (Filters) แบบ Default Show | 22 ม.ค. 2026 |
| [UI_UX_POLICY.md](./design/UI_UX_POLICY.md) | นโยบาย UI/UX | กฎการออกแบบ UI/UX เช่น Filters Default State, Button Labels, Color System | 23 ม.ค. 2026 |

---

## 🔑 Key Concepts

### 1. **Manual Accept Policy** 🚫 ไม่มี Auto-Accept

```
✅ ผู้รับเคสต้องกดปุ่ม "รับเคส" เองทุกครั้ง
❌ ไม่มีการรับเคสอัตโนมัติ
🎯 เพื่อความรับผิดชอบและความโปร่งใส
```

**ขั้นตอนการรับเคส:**
1. Tier1-3 เห็นเคสที่ส่งมาในหน้า "รอดำเนินการ"
2. คลิกเข้าไปอ่านรายละเอียดเคส
3. **กดปุ่ม "รับเคส"** เพื่อเริ่มดำเนินการ
4. สถานะเคสเปลี่ยนเป็น `in_progress`

---

### 2. **Comment Policy** 💬 เคสปิดแล้วไม่แสดงกล่อง Comment

```
✅ เคสที่ยังไม่ปิด → แสดงกล่อง "ความคิดเห็นและกิจกรรม"
❌ เคสที่ปิดแล้ว → ซ่อนกล่องทั้งหมด
📋 ต้องการดู comments → ดูใน Timeline แทน
```

**กฎการ Comment:**
- **ลูกค้า:** เห็นเฉพาะ Public Comments
- **Staff/Tier/Admin:** เห็นทั้ง Public และ Internal Comments
- **เคสปิดแล้ว (status = 'closed'):** ทุกคนไม่เห็นกล่อง Comment

---

### 3. **Multi-Role Accept Button** 🎭 ต้องสลับ Role ให้ตรงก่อน

```
✅ activeRole ต้องตรงกับ ticket.status
✅ user.roles[] ต้องมี role นั้นอยู่จริง
✅ ticket.assignedTo ต้องตรงกับ user.id
```

**ตัวอย่าง:**
- ประกาศิต: `roles: ['tier2', 'tier3']`
- สลับเป็น Tier3 → เห็นปุ่ม "รับเคส" สำหรับเคส Tier3 ✅
- สลับเป็น Tier2 → **ไม่เห็น**ปุ่ม "รับเคส" สำหรับเคส Tier3 ❌

---

### 4. **Filter Display Policy** 🔍 ตัวกรองแสดงโดย Default

```
✅ ตัวกรองเปิดอยู่เมื่อเข้าหน้าใหม่
✅ ผู้ใช้ใช้งานได้ทันทีโดยไม่ต้องกดปุ่มเพิ่มเติม
✅ สามารถซ่อนได้ตามต้องการ
```

**เหตุผล:**
- ลดขั้นตอนการใช้งาน (ไม่ต้องกดปุ่ม "ตัวกรอง" ทุกครั้ง)
- มองเห็นตัวเลือกทันที
- ประสบการณ์ผู้ใช้ดีขึ้น

---

## 📂 โครงสร้างเอกสาร

```
/docs
├── DOCUMENTATION_INDEX.md          ← คุณอยู่ที่นี่
├── features/
│   ├── MANUAL_ACCEPT_POLICY.md         ← นโยบายการรับเคส
│   ├── COMMENT_POLICY.md               ← นโยบายการ Comment
│   ├── MULTI_ROLE_ACCEPT_BUTTON_POLICY.md  ← นโยบาย Multi-Role
│   └── FILTER_DISPLAY_POLICY.md        ← นโยบายการแสดงตัวกรอง
└── design/
    └── UI_UX_POLICY.md                 ← นโยบาย UI/UX
```

---

## 🎯 Quick Links

### สำหรับ Tier1-3
- [วิธีรับเคส](./features/MANUAL_ACCEPT_POLICY.md#-ขั้นตอนการรับเคส)
- [กฎการ Comment](./features/COMMENT_POLICY.md#-กฎการ-comment-ตามสถานะเคส)
- [Multi-Role: วิธีสลับบทบาท](./features/MULTI_ROLE_ACCEPT_BUTTON_POLICY.md#-use-case-ประกาศิต-tier2tier3)
- [วิธีใช้ตัวกรอง](./features/FILTER_DISPLAY_POLICY.md#-นโยบายหลัก)

### สำหรับ Admin
- [นโยบายทั้งหมด](#-สารบัญเอกสาร)
- [ประวัติการเปลี่ยนแปลง](#-changelog)

---

## 📅 Changelog

| วันที่ | เอกสาร | การเปลี่ยนแปลง |
|-------|--------|----------------|
| 23 ม.ค. 2026 | DOCUMENTATION_INDEX.md | สร้างไฟล์ Index หลัก |
| 23 ม.ค. 2026 | MULTI_ROLE_ACCEPT_BUTTON_POLICY.md | สร้างนโยบาย Multi-Role Accept Button |
| 23 ม.ค. 2026 | COMMENT_POLICY.md | อัปเดต: ซ่อนกล่อง Comment ทั้งหมดเมื่อเคสปิด |
| 23 ม.ค. 2026 | MANUAL_ACCEPT_POLICY.md | สร้างนโยบายการรับเคสแบบ Manual |
| 22 ม.ค. 2026 | FILTER_DISPLAY_POLICY.md | สร้างนโยบายการแสดงตัวกรอง |
| 23 ม.ค. 2026 | UI_UX_POLICY.md | สร้างนโยบาย UI/UX |

---

## 🆘 ต้องการความช่วยเหลือ?

- **ปัญหาการใช้งาน:** ดูเอกสารที่เกี่ยวข้องในตารางด้านบน
- **พบ Bug:** แจ้งทีมพัฒนา
- **ข้อเสนอแนะ:** ติดต่อ support@cdg.co.th

---

**หมายเหตุ:** เอกสารทั้งหมดอยู่ในรูปแบบ Markdown (.md) และอัปเดตเป็นประจำตามการพัฒนาระบบ