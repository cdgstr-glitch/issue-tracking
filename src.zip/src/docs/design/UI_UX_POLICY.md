# 🎨 นโยบาย UI/UX (User Interface & User Experience Policy)

**เอกสารนี้อธิบายนโยบายการออกแบบ UI/UX ของระบบ CDGS Issue Tracking Platform**

> 📌 **[← กลับไปหน้าแรก](../DOCUMENTATION_INDEX.md)**

---

## 📖 สารบัญ

1. [Filters Default State](#-filters-default-state)
2. [Button Labels](#-button-labels)
3. [Color System](#-color-system)
4. [Typography](#-typography)

---

## 🔍 Filters Default State

### นโยบาย: **Filters เปิดเป็น Default**

**หลักการ:**
- ✅ Filters แสดงอยู่ตลอดเวลา (Default: `showFilters = true`)
- ✅ ผู้ใช้สามารถกดปุ่ม "ซ่อน Filters" เพื่อซ่อนได้
- ✅ ช่วยให้ผู้ใช้เข้าถึงการกรองได้ง่ายและรวดเร็ว

---

### เหตุผล:

1. **🎯 Accessibility (เข้าถึงได้ง่าย)**
   - ผู้ใช้ไม่ต้องหาว่าปุ่ม Filter อยู่ที่ไหน
   - ลด Click ที่ไม่จำเป็น (1 click → 0 click)

2. **⚡ Efficiency (ประสิทธิภาพ)**
   - เหมาะกับระบบที่มีข้อมูลเยอะ (Issue Tracking)
   - ผู้ใช้ส่วนใหญ่ต้องการกรองข้อมูลทันที

3. **👁️ Visibility (มองเห็นได้ชัดเจน)**
   - ผู้ใช้รู้ทันทีว่ามี Filter อะไรบ้างที่ใช้ได้
   - ลดการสับสน (Reduce Cognitive Load)

---

### Implementation

#### 1. **TicketListPage.tsx** (สำหรับ Staff/Tier1-3/Admin)

```typescript
// ✅ Default: เปิดอยู่
const [showFilters, setShowFilters] = useState(true);
```

**Filters ที่มี:**
- 📊 สถานะ (Status)
- 🎚️ Tier
- ⚠️ ความสำคัญ (Priority)
- 📢 ช่องทาง (Channel)
- 🏷️ Hashtags
- 📅 ช่วงวันที่ (Date Range)

---

#### 2. **CustomerTrackTicketPage.tsx** (สำหรับ Customer)

```typescript
// ✅ Default: เปิดอยู่
const [showFilters, setShowFilters] = useState(true);
```

**Filters ที่มี:**
- 📊 สถานะ (Status)
- 📢 ช่องทาง (Channel)
- ⏱️ สถานะ SLA
- 🔢 การเรียงลำดับ (Sort)

---

### UI Behavior

#### **Toggle Button:**
```typescript
<Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
  <Filter className="mr-2 h-4 w-4" />
  {showFilters ? 'ซ่อน Filters' : 'แสดง Filters'}
</Button>
```

**สถานะปุ่ม:**
- เมื่อ Filters **แสดง**: ปุ่มจะเขียนว่า **"ซ่อน Filters"**
- เมื่อ Filters **ซ่อน**: ปุ่มจะเขียนว่า **"แสดง Filters"**

---

### Active Filters Indicator

**Customer Track Ticket Page มี Badge นับจำนวน Filter ที่เปิดอยู่:**

```typescript
{hasActiveFilters && (
  <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-xs text-white">
    {[filterStatus, filterChannel, filterSLA].filter(f => f !== 'all').length}
  </span>
)}
```

**ตัวอย่าง:**
- ถ้ากรอง Status = "เปิด" + Channel = "Email" → Badge แสดง **"2"**

---

## 🎨 Button Labels

### นโยบาย: **ใช้ภาษาไทยที่เข้าใจง่าย**

| ภาษาอังกฤษ | ภาษาไทย | ใช้กับ |
|-----------|---------|--------|
| Filter | ตัวกรอง / Filters | Customer |
| Show Filters | แสดง Filters | Staff/Tier |
| Hide Filters | ซ่อน Filters | Staff/Tier |
| Show Filters | แสดงตัวกรอง | Customer |
| Hide Filters | ซ่อนตัวกรอง | Customer |

---

## 🎨 Color System

### สี Badge ตามสถานะ

| สถานะ | สี | Class |
|------|-----|-------|
| Active Filters | Blue | `bg-blue-600 text-white` |
| New Ticket | Red | `bg-red-500 text-white` |
| In Progress | Blue | `bg-blue-500 text-white` |
| Resolved | Green | `bg-green-500 text-white` |
| Closed | Gray | `bg-gray-500 text-white` |

---

## 📐 Layout Guidelines

### Filters Section

**Desktop:**
```
Grid: 4 columns (Status | Tier | Priority | Channel)
Gap: 4 (1rem)
```

**Tablet:**
```
Grid: 2 columns
Gap: 3 (0.75rem)
```

**Mobile:**
```
Grid: 1 column
Gap: 3 (0.75rem)
```

---

## ✨ Animation & Transitions

### Filters Toggle

```typescript
// Collapse/Expand Animation
transition: all 200ms ease-in-out
```

**Behavior:**
- Smooth fade-in/fade-out
- No jarring jumps
- Maintain scroll position

---

## 📱 Responsive Design

### Breakpoints

| Device | Breakpoint | Filters Layout |
|--------|-----------|----------------|
| Mobile | < 640px | 1 column |
| Tablet | 640px - 1024px | 2 columns |
| Desktop | > 1024px | 4 columns |

---

## ⚠️ ข้อควรระวัง

### ❌ สิ่งที่ไม่ควรทำ:
1. ❌ **ห้ามซ่อน Filters เป็น Default** → ผู้ใช้จะหาไม่เจอ
2. ❌ **ห้ามใช้ชื่อภาษาอังกฤษล้วน** → ผู้ใช้ไทยอ่านยาก
3. ❌ **ห้ามใช้สีที่คล้ายกันเกินไป** → สับสน

### ✅ สิ่งที่ควรทำ:
1. ✅ **แสดง Filters เป็น Default** → เข้าถึงได้ง่าย
2. ✅ **ใช้ Badge นับจำนวน Active Filters** → เห็นว่ากรองอะไรบ้าง
3. ✅ **ให้ปุ่ม Toggle ชัดเจน** → ผู้ใช้รู้ว่าสามารถซ่อนได้

---

## 🧪 Testing Checklist

### Desktop
- [ ] Filters แสดงเป็น Default เมื่อเข้าหน้าครั้งแรก
- [ ] กดปุ่ม "ซ่อน Filters" → Filters หายไป
- [ ] กดปุ่ม "แสดง Filters" → Filters กลับมา
- [ ] Grid แสดง 4 columns

### Mobile
- [ ] Filters แสดงเป็น Default
- [ ] Grid แสดง 1 column
- [ ] Touch target ของปุ่มใหญ่พอ (min 44x44px)

---

## 📅 ประวัติการเปลี่ยนแปลง

| วันที่ | การเปลี่ยนแปลง | ผู้แก้ไข |
|-------|---------------|---------|
| 23 ม.ค. 2026 | สร้างเอกสารนโยบาย UI/UX | System |
| 23 ม.ค. 2026 | เปลี่ยน Filters Default จาก false → true | System |

---

## 📚 เอกสารอ้างอิง

- `/components/TicketListPage.tsx` - Filter Section (Staff/Tier)
- `/components/CustomerTrackTicketPage.tsx` - Filter Section (Customer)
- [Material Design Guidelines - Filters](https://material.io/components/chips#action-chips)
- [Nielsen Norman Group - Filters Design](https://www.nngroup.com/articles/filters-vs-facets/)

---

**หมายเหตุ:** นโยบายนี้อาจมีการปรับปรุงตามข้อเสนอแนะจากผู้ใช้งาน
