# 👥 รายชื่อทีมงานและผู้ใช้งานระบบ (User List)

**วันที่:** 17 มกราคม 2026

---

## 📋 **1. Internal Users (เจ้าหน้าที่)**

### **Tier 1 (Helpdesk & Support)**
รับเรื่อง, คัดกรอง, แก้ไขเบื้องต้น, ส่งต่อ

| ID | ชื่อ-นามสกุล | Username | Password | Role | หมายเหตุ |
|----|--------------|----------|----------|------|----------|
| `user-001` | ธิราภรณ์ รุ่งวิรัตน์กุล | `thiraporn.r` | `thiraporn.r123` | **Admin + Tier1** | Head of Support |
| `user-002` | สาริน ช่อพะยอม | `sarin.c` | `sarin.c123` | **Admin + Tier1** | Senior Support |
| `user-003` | วรรณภา แซ่ด่าง | `wannapa.s` | `wannapa.s123` | **Tier1** | Support Agent |
| `user-004` | เขมิกา แซ่ตั้ง | `khemika.s` | `khemika.s123` | **Tier1** | Support Agent |
| `user-005` | ธัญญาพร ทองแก้ว | `thanyaporn.t` | `thanyaporn.t123` | **Tier1** | Support Agent |

### **Tier 2 (System Analyst - SA)**
วิเคราะห์ระบบ, แก้ไขทางเทคนิค

| ID | ชื่อ-นามสกุล | Username | Password | Role | หมายเหตุ |
|----|--------------|----------|----------|------|----------|
| `user-006` | ยุทธนา คณามิ่งมงคล | `yuttana.k` | `yuttana.k123` | **Tier2** | Senior SA |
| `user-007` | ประกาศิต ประคองเพ็ชร | `prakasit.p` | `prakasit.p123` | **Tier2 + Tier3** | Expert SA |
| `user-008` | ประวิช จินทนากร | `pravich.j` | `pravich.j123` | **Tier2** | SA |

### **Tier 3 (Developer / Specialist)**
แก้ไข Code, Database, Server

| ID | ชื่อ-นามสกุล | Username | Password | Role | หมายเหตุ |
|----|--------------|----------|----------|------|----------|
| `user-009` | พุทธจักษ์ วงค์พันธ์ | `puttajak.w` | `puttajak.w123` | **Tier3** | Senior Dev |
| `user-010` | วีระกร เยือกเย็น | `wirakorn.y` | `wirakorn.y123` | **Tier3** | DevOps / DBA |

### **Admin (System Administrator)**
จัดการผู้ใช้, ตั้งค่าระบบ (ไม่ได้รับเคส)

| ID | ชื่อ-นามสกุล | Username | Password | Role | หมายเหตุ |
|----|--------------|----------|----------|------|----------|
| `user-011` | ประอรรัตน์ กีรติผจญ | `pra-onrat.k` | `pra-onrat.k123` | **Admin** | System Admin |

### **Staff (General Staff / Call Center)**
บันทึกเคสแทนลูกค้าเท่านั้น

| ID | ชื่อ-นามสกุล | Username | Password | Role | หมายเหตุ |
|----|--------------|----------|----------|------|----------|
| `staff-001` | สมชาย ใจดี | `staff` | `staff123` | **Staff** | Call Center |

---

## 👥 **2. External Users (ลูกค้า)**

### **Customer (ผู้แจ้งปัญหา)**

| ID | ชื่อ-นามสกุล | Username | Password | Role | หน่วยงาน |
|----|--------------|----------|----------|------|----------|
| `test-001` | ศิริพร อารีมิตร | `customer1` | `customer1123` | **Customer** | MRTA (รฟม.) |
| `test-002` | วิชัย มั่นคง | `customer2` | `customer2123` | **Customer** | DOT (กรมการขนส่ง) |

---

## 📊 **3. สรุปจำนวนผู้ใช้งาน**

| Role | จำนวน |
|------|-------|
| Admin + Tier1 | 2 |
| Tier1 | 3 |
| Tier2 | 2 |
| Tier2 + Tier3 | 1 |
| Tier3 | 2 |
| Admin (Pure) | 1 |
| Staff | 1 |
| Customer | 2 |
| **รวมทั้งหมด** | **14 คน** |

---

## 🔐 **4. หมายเหตุเรื่องสิทธิ์ (Permissions)**

1. **Admin + Tier1:** มีสิทธิ์สูงสุด ทำได้ทุกอย่าง (จัดการระบบ + รับ/ปิดเคส)
2. **Tier1:** รับเรื่อง, ส่งต่อ, และ **ปิดเคส** ได้
3. **Tier2/3:** รับเรื่อง, แก้ไข, ส่งต่อ แต่ **ปิดเคสไม่ได้** (ต้องส่งกลับ Tier1)
4. **Admin (Pure):** จัดการระบบเท่านั้น **ไม่เห็นเมนูรับเคส**
5. **Staff:** บันทึกเคสแทนลูกค้าเท่านั้น (ไม่เห็นเคสคนอื่น)
6. **Customer:** แจ้งและติดตามเคสของตัวเองเท่านั้น

---

**สร้างโดย:** HR / IT Department  
**อัปเดตล่าสุด:** 17 มกราคม 2026
