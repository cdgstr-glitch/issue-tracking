# ชื่อทีมสำหรับเคสที่ยังไม่มีผู้รับผิดชอบ

เอกสารนี้บันทึกกฎการแสดงชื่อทีมเมื่อเคสยังไม่มีผู้รับผิดชอบในระบบ CDGS Issue Tracking Platform

---

## 📋 กฎการแสดงชื่อทีม

เมื่อเคสถูกส่งต่อแต่ยังไม่มีใครรับผิดชอบ (`assignedTo = undefined`) ระบบจะแสดง**ชื่อทีม**ตามสถานะ (status) ของเคส:

| สถานะ (Status) | ชื่อทีมที่แสดง | คำอธิบาย |
|---------------|---------------|----------|
| `new`, `tier1`, `in_progress`, `waiting` | **ทีม Service** | เคสที่อยู่ในความรับผิดชอบของ Tier 1 |
| `tier2` | **ทีม App** | เคสที่ส่งต่อไปยัง Tier 2 |
| `tier3` | **ทีม Special** | เคสที่ส่งต่อไปยัง Tier 3 (ทีมพิเศษ) |
| อื่นๆ | **ไม่มีผู้รับผิดชอบ** | สถานะอื่นๆ ที่ไม่ตรงกับเงื่อนไขข้างต้น |

---

## 💡 ตรรกะการทำงาน

### 1. **มีผู้รับผิดชอบแล้ว** (`assignedTo` มีค่า)
```
แสดงชื่อเต็มของผู้รับผิดชอบ
เช่น: "ยุทธนา", "ประกาศิต", "วรรณภา"
```

### 2. **ยังไม่มีผู้รับผิดชอบ** (`assignedTo = undefined`)
```
แสดงชื่อทีมตามสถานะ
- status = 'tier1' → "ทีม Service"
- status = 'tier2' → "ทีม App"
- status = 'tier3' → "ทีม Special"
```

---

## 🔧 ฟังก์ชันที่ใช้งาน

ฟังก์ชันหลักที่จัดการการแสดงชื่อผู้รับผิดชอบ:

### `getTeamNameByStatus(status: string): string`
คืนชื่อทีมตามสถานะของเคส

```typescript
export function getTeamNameByStatus(status: string): string {
  switch (status) {
    case 'new':
    case 'tier1':
    case 'in_progress':
    case 'waiting':
      return 'ทีม Service';
    case 'tier2':
      return 'ทีม App';
    case 'tier3':
      return 'ทีม Special';
    default:
      return 'ไม่มีผู้รับผิดชอบ';
  }
}
```

### `getAssigneeDisplayName(ticket: { assignedTo?: string; status: string }): string`
คืนชื่อผู้รับผิดชอบหรือชื่อทีม

```typescript
export function getAssigneeDisplayName(ticket: { assignedTo?: string; status: string }): string {
  if (ticket.assignedTo) {
    const user = getUserById(ticket.assignedTo);
    return user?.fullName || ticket.assignedTo;
  }
  
  // If no assignee, return team name based on status
  return getTeamNameByStatus(ticket.status);
}
```

**ไฟล์:** `/lib/mockDataCSVUsers.ts`

---

## 📝 การใช้งานใน Components

### ตัวอย่างการใช้งาน

#### 1. ตารางเคส (`TicketTable.tsx`)
```tsx
import { getAssigneeDisplayName } from '../lib/mockDataCSVUsers';

<td className="px-4 py-3">
  <div className="flex items-center gap-2">
    <User className="h-4 w-4 text-gray-400" />
    <span className="text-sm">{getAssigneeDisplayName(ticket)}</span>
  </div>
</td>
```

#### 2. หน้ารายละเอียดเคส (`TicketDetailPage.tsx`)
```tsx
import { getAssigneeDisplayName } from '../lib/mockDataCSVUsers';

<div className="flex items-start gap-3">
  <User className="mt-0.5 h-4 w-4 text-gray-400" />
  <div className="flex-1">
    <p className="text-xs text-gray-600">มอบหมายให้</p>
    <p className="text-sm">{getAssigneeDisplayName(ticket)}</p>
  </div>
</div>
```

---

## 📌 Components ที่ต้องแก้ไข

### ✅ แก้ไขแล้ว (2 ไฟล์)
1. `/lib/mockDataCSVUsers.ts` - เพิ่มฟังก์ชัน `getTeamNameByStatus()` และ `getAssigneeDisplayName()` + User ID Mapping
2. `/components/TicketTable.tsx` - ใช้ `getAssigneeDisplayName(ticket)`
3. `/components/TicketDetailPage.tsx` - ใช้ `getAssigneeDisplayName(ticket)`
4. `/components/TrackTicketDetailPage.tsx` - ใช้ `getAssigneeDisplayName(ticket)`
5. `/components/StaffTicketDetailPage.tsx` - ใช้ `getAssigneeDisplayName(ticket)`

### ⏳ รอแก้ไข
1. `/components/reports/DashboardReport.tsx` - Dashboard report table
2. `/components/TicketListPage.tsx` - Export CSV

---

## 🎯 ตัวอย่างผลลัพธ์

### เคส Tier 1 (ยังไม่มีผู้รับผิดชอบ)
```
Status: tier1
assignedTo: undefined
→ แสดง: "ทีม Service"
```

### เคส Tier 2 (ยังไม่มีผู้รับผิดชอบ)
```
Status: tier2
assignedTo: undefined
→ แสดง: "ทีม App"
```

### เคส Tier 2 (มีผู้รับผิดชอบแล้ว)
```
Status: tier2
assignedTo: "user-tier2-001" (ยุทธนา)
→ แสดง: "ยุทธนา"
```

### เคส Tier 3 (ยังไม่มีผู้รับผิดชอบ)
```
Status: tier3
assignedTo: undefined
→ แสดง: "ทีม Special"
```

### User ID Mapping
```typescript
// Admin/Staff
'user-001' → 'user-tier1-004' (ธิราภรณ์)

// Tier 1
'user-002' → 'user-tier1-001' (สาริน)
'user-003' → 'user-tier1-003' (วรรณภา)
'user-004' → 'user-tier1-004' (ธิราภรณ์)
'user-005' → 'user-tier1-002' (ธัญญาพร)
'user-012' → 'user-tier1-001' (สาริน - fallback)

// Tier 2
'user-006' → 'user-tier2-001' (ยุทธนา)
'user-007' → 'user-tier2-002' (ประกาศิต)
'user-008' → 'user-tier2-002' (ประกาศิต - fallback)

// Tier 3
'user-009' → 'user-tier3-001' (ทีม App)
'user-010' → 'user-tier3-001' (ทีม App - fallback)
```

---

## 🚨 หมายเหตุสำคัญ

1. **การส่งต่อเคส:** ทุกการส่งต่อต้องระบุผู้รับ แต่ผู้รับต้องกด "รับเคส" ก่อนถึงจะเปลี่ยน status เป็น `in_progress`
2. **กฎการแสดงชื่อ:** ชื่อทีมจะแสดงเฉพาะเมื่อ `assignedTo = undefined` เท่านั้น
3. **ความสม่ำเสมอ:** ต้องใช้ `getAssigneeDisplayName()` ในทุก Component ที่แสดงผู้รับผิดชอบ เพื่อความสม่ำเสมอ

---

**อัพเดตล่าสุด:** 15 มกราคม 2026  
**ผู้ดูแล:** CDGS Development Team  
**สถานะ:** 🚧 กำลังแก้ไข Components ที่เหลือ