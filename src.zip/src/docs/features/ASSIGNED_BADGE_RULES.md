# 🏷️ AssignedBadge Display Rules (กฎการแสดง Badge ผู้รับผิดชอบ)

> **กฎการแสดง AssignedBadge และ AssignmentInfoCard ในระบบ CDGS Issue Tracking Platform**  
> อัพเดตล่าสุด: 15 มกราคม 2026

---

## 📋 สรุปกฎการแสดง AssignedBadge

### **AssignedBadge จะไม่แสดงเมื่อ:**

1. ✅ **เคสปิดแล้ว** (`status = 'closed'` หรือ `status = 'resolved'`)
   - เหตุผล: เคสจบการดำเนินการแล้ว ไม่จำเป็นต้องแสดงผู้รับผิดชอบ

2. ✅ **ผู้ดูคือเจ้าของเคส** (`ticket.assignedTo === user?.id`)
   - เหตุผล: ไม่ต้องบอกตัวเองว่าเป็นผู้รับผิดชอบ (ซ้ำซ้อน)

### **AssignedBadge จะแสดงเมื่อ:**

1. ✅ เคสยังไม่ปิด (`status ≠ 'closed'` และ `status ≠ 'resolved'`)
2. ✅ ผู้ดูไม่ใช่เจ้าของเคส (`ticket.assignedTo !== user?.id`)
3. ✅ เคสมีผู้รับผิดชอบ (`ticket.assignedTo` มีค่า)

---

## 📊 ตารางสรุปเงื่อนไข

| Status | assignedTo | ผู้ดู | AssignedBadge | AssignmentInfoCard | หมายเหตุ |
|--------|-----------|-------|---------------|-------------------|----------|
| **closed** | user-001 | user-002 | ❌ ไม่แสดง | ❌ ไม่แสดง | เคสปิดแล้ว |
| **resolved** | user-001 | user-002 | ❌ ไม่แสดง | ❌ ไม่แสดง | เคสแก้ไขแล้ว |
| **in_progress** | user-001 | **user-001** | ❌ ไม่แสดง | ✅ แสดง | ตัวเองเป็นเจ้าของ |
| **in_progress** | user-001 | user-002 | ✅ แสดง | ✅ แสดง | คนอื่นดูเคส |
| **waiting** | user-001 | user-002 | ✅ แสดง | ✅ แสดง | หยุดชั่วคราว |
| **tier1** | user-001 | user-002 | ✅ แสดง | ✅ แสดง | รอรับเคส Tier1 |
| **tier2** | user-001 | user-002 | ✅ แสดง | ✅ แสดง | รอรับเคส Tier2 |
| **tier3** | user-001 | user-002 | ✅ แสดง | ✅ แสดง | รอรับเคส Tier3 |
| **new** | null | user-002 | ❌ ไม่แสดง | ❌ ไม่แสดง | ยังไม่มอบหมาย |

---

## 🔧 Implementation Details

### **1. AssignedBadge (Ticket List)**

**ไฟล์:** `/components/TicketListPage.tsx`

```tsx
{/* AssignedBadge - แสดงคนที่ถูกมอบหมาย (ซ่อนถ้าเคสปิดแล้ว) */}
{ticket.assignedTo && 
 ticket.assignedTo !== user?.id && 
 ticket.status !== 'closed' && 
 ticket.status !== 'resolved' && 
 (() => {
  const assignee = getUserById(ticket.assignedTo);
  return assignee ? (
    <AssignedBadge
      key="assigned"
      assigneeName={assignee.name}
      assigneeRole={assignee.role}
      size="sm"
    />
  ) : null;
})()}
```

**เงื่อนไข:**
- ✅ `ticket.assignedTo` มีค่า (มีผู้รับผิดชอบ)
- ✅ `ticket.assignedTo !== user?.id` (ไม่ใช่ตัวเอง)
- ✅ `ticket.status !== 'closed'` (ไม่ปิดแล้ว)
- ✅ `ticket.status !== 'resolved'` (ไม่แก้ไขแล้ว)

---

### **2. AssignmentInfoCard (Ticket Detail)**

**ไฟล์:** `/components/AssignmentInfoCard.tsx`

```tsx
export function AssignmentInfoCard({ ticket }: AssignmentInfoCardProps) {
  // ✅ ซ่อนเมื่อเคสปิดแล้วหรือแก้ไขแล้ว
  const isClosedOrResolved = ticket.status === 'closed' || ticket.status === 'resolved';
  if (isClosedOrResolved) return null;

  // Only show if ticket has been assigned
  if (!ticket.assignedTo && !ticket.assignedBy) return null;
  
  // ... rest of component
}
```

**เงื่อนไข:**
- ✅ `ticket.status !== 'closed'` และ `ticket.status !== 'resolved'`
- ✅ `ticket.assignedTo` หรือ `ticket.assignedBy` มีค่า

---

## 💡 Use Cases & Examples

### **Use Case 1: เจ้าหน้าที่ Tier2 ดูเคสของ Tier2 คนอื่น**

**สถานการณ์:**
- เคส: CDGS-2024-ST001
- Status: `in_progress`
- AssignedTo: `user-007` (อนันต์ วงศ์ใหญ่ - Tier2)
- ผู้ดู: `user-008` (ประวิช จินทนากร - Tier2)

**ผลลัพธ์:**
- ✅ แสดง **AssignedBadge**: "อนันต์ วงศ์ใหญ่ (Tier2)"
- ✅ แสดง **AssignmentInfoCard**

---

### **Use Case 2: เจ้าของเคสดูเคสของตัวเอง**

**สถานการณ์:**
- เคส: CDGS-2024-ST001
- Status: `in_progress`
- AssignedTo: `user-007` (อนันต์ วงศ์ใหญ่)
- ผู้ดู: `user-007` (อนันต์ วงศ์ใหญ่)

**ผลลัพธ์:**
- ❌ **ไม่แสดง AssignedBadge** (เพราะตัวเองเป็นเจ้าของ)
- ✅ แสดง **AssignmentInfoCard** (แสดงข้อมูลการมอบหมาย)

---

### **Use Case 3: Admin ดูเคสที่ปิดแล้ว**

**สถานการณ์:**
- เคส: CDGS-2024-CL002
- Status: `closed`
- AssignedTo: `user-003` (นิธิวดี พรหมมา)
- ผู้ดู: `user-001` (ธิราภรณ์ - Admin)

**ผลลัพธ์:**
- ❌ **ไม่แสดง AssignedBadge** (เคสปิดแล้ว)
- ❌ **ไม่แสดง AssignmentInfoCard** (เคสปิดแล้ว)

---

### **Use Case 4: Tier1 ดูเคสใหม่ที่ยังไม่มอบหมาย**

**สถานการณ์:**
- เคส: CDGS-2024-CU003
- Status: `new`
- AssignedTo: `null` (ยังไม่มอบหมาย)
- ผู้ดู: `user-003` (นิธิวดี - Tier1)

**ผลลัพธ์:**
- ❌ **ไม่แสดง AssignedBadge** (ยังไม่มีผู้รับผิดชอบ)
- ❌ **ไม่แสดง AssignmentInfoCard** (ยังไม่มีการมอบหมาย)

---

### **Use Case 5: เคสที่แก้ไขแล้ว รอ Tier1 ปิด**

**สถานการณ์:**
- เคส: CDGS-2024-ST005
- Status: `resolved`
- ResolvedBy: `user-007` (Tier2)
- AssignedTo: `user-003` (Tier1 - รอปิดเคส)
- ผู้ดู: `user-001` (Admin)

**ผลลัพธ์:**
- ❌ **ไม่แสดง AssignedBadge** (เคสแก้ไขแล้ว)
- ❌ **ไม่แสดง AssignmentInfoCard** (เคสแก้ไขแล้ว)

---

## 🎯 Business Logic Summary

### **1. เคสที่ปิดแล้ว/แก้ไขแล้ว**
- เหตุผล: **การดำเนินการเสร็จสิ้นแล้ว**
- การแสดงผล: ไม่แสดง Assignment Badges/Cards
- Status: `closed`, `resolved`

### **2. เจ้าของเคสดูเคสตัวเอง**
- เหตุผล: **ไม่ต้องบอกตัวเองว่าเป็นผู้รับผิดชอบ**
- การแสดงผล: 
  - ❌ ไม่แสดง AssignedBadge (รายการเคส)
  - ✅ แสดง AssignmentInfoCard (หน้ารายละเอียดเคส - เพื่อดูข้อมูลการมอบหมาย)

### **3. คนอื่นดูเคสที่กำลังดำเนินการ**
- เหตุผล: **ต้องบอกว่าใครเป็นผู้รับผิดชอบ**
- การแสดงผล: แสดง AssignedBadge และ AssignmentInfoCard
- Status: `in_progress`, `waiting`, `tier1`, `tier2`, `tier3`

---

## 🔍 Related Components

| Component | Path | Description |
|-----------|------|-------------|
| **AssignedBadge** | `/components/AssignedBadge.tsx` | Badge สีเหลือง แสดงชื่อผู้รับผิดชอบ |
| **AssignmentInfoCard** | `/components/AssignmentInfoCard.tsx` | Card แสดงข้อมูลการมอบหมาย |
| **ReadOnlyModeBanner** | `/components/ReadOnlyModeBanner.tsx` | Banner แจ้งเตือนโหมดอ่านอย่างเดียว |
| **TicketListPage** | `/components/TicketListPage.tsx` | หน้ารายการเคส (ใช้ AssignedBadge) |
| **TicketDetailPage** | `/components/TicketDetailPage.tsx` | หน้ารายละเอียดเคส (ใช้ AssignmentInfoCard) |
| **ViewerBadge** | `/components/ViewerBadge.tsx` | Badge สีน้ำเงิน แสดงคนที่กำลังดู (Read-only) |

---

## 🔔 ReadOnlyModeBanner Display Rules

### **ReadOnlyModeBanner จะไม่แสดงเมื่อ:**

1. ✅ **เคสปิดแล้ว** (`status = 'closed'` หรือ `status = 'resolved'`)
   - เหตุผล: เคสจบการดำเนินการแล้ว ทุกคนอ่านได้เหมือนกัน ไม่ต้องบอก read-only

2. ✅ **ผู้ดูคือเจ้าของเคส** (`ticket.assignedTo === user?.id`)
   - เหตุผล: เป็นผู้รับผิดชอบ มีสิทธิ์แก้ไขได้

### **ReadOnlyModeBanner จะแสดงเมื่อ:**

1. ✅ เคสยังไม่ปิด (`status ≠ 'closed'` และ `status ≠ 'resolved'`)
2. ✅ ผู้ดูไม่ใช่เจ้าของเคส (`ticket.assignedTo !== user?.id`)
3. ✅ เคสมีผู้รับผิดชอบ (`ticket.assignedTo` มีค่า)

**Implementation:**

```tsx
// /components/ReadOnlyModeBanner.tsx
export function ReadOnlyModeBanner({ ticketAssignedTo, currentUserId, ticketStatus, onTakeover }) {
  // ✅ เคสที่ปิดแล้วหรือแก้ไขแล้ว → ไม่แสดง Banner เลย
  const isClosedOrResolved = ticketStatus === 'closed' || ticketStatus === 'resolved';
  if (isClosedOrResolved) return null;
  
  // ✅ ถ้าผู้ดูคือเจ้าของเคส → ไม่แสดง Banner เลย
  if (ticketAssignedTo === currentUserId) return null;
  
  // ... rest of component
}
```

---

## 📝 Testing Checklist

### **ทดสอบ AssignedBadge (Ticket List)**

- [ ] เคส `closed` → ไม่แสดง Badge
- [ ] เคส `resolved` → ไม่แสดง Badge
- [ ] เจ้าของเคสดูเคสตัวเอง → ไม่แสดง Badge
- [ ] คนอื่นดูเคส `in_progress` → แสดง Badge
- [ ] คนอื่นดูเคส `waiting` → แสดง Badge
- [ ] คนอื่นดูเคส `tier1/tier2/tier3` → แสดง Badge

### **ทดสอบ AssignmentInfoCard (Ticket Detail)**

- [ ] เคส `closed` → ไม่แสดง Card
- [ ] เคส `resolved` → ไม่แสดง Card
- [ ] เคส `in_progress` → แสดง Card
- [ ] เคส `waiting` → แสดง Card
- [ ] เคส `new` ที่ยังไม่มอบหมาย → ไม่แสดง Card

### **ทดสอบ ReadOnlyModeBanner (Ticket Detail)**

- [ ] เคส `closed` → ไม่แสดง Banner
- [ ] เคส `resolved` → ไม่แสดง Banner
- [ ] เจ้าของเคสดูเคสตัวเอง (in_progress) → ไม่แสดง Banner
- [ ] คนอื่นดูเคส `in_progress` → แสดง Banner พร้อมปุ่ม Takeover
- [ ] Pure Admin ดูเคสคนอื่น → แสดง Banner แบบ Monitor Mode (ไม่มีปุ่ม Takeover)

---

## 🛠️ Maintenance Notes

### **เมื่อต้องเพิ่ม Status ใหม่:**

1. ตรวจสอบว่า Status ใหม่เป็น "เคสที่จบแล้ว" หรือไม่
2. ถ้าใช่: เพิ่มเข้าไปในเงื่อนไข `isClosedOrResolved`
3. ถ้าไม่: ปล่อยให้แสดงปกติ

**ตัวอย่าง:**
```tsx
// ถ้ามี status ใหม่ เช่น 'archived'
const isClosedOrResolved = 
  ticket.status === 'closed' || 
  ticket.status === 'resolved' ||
  ticket.status === 'archived'; // เพิ่มใหม่
```

---

## 🎨 Visual Examples

### **AssignedBadge แสดง:**
```
🟡 [👤 อนันต์ วงศ์ใหญ่ (Tier2)]
```

### **AssignedBadge ไม่แสดง:**
```
(ไม่มี Badge)
```

### **AssignmentInfoCard แสดง:**
```
┌────────────────────────────────────┐
│ 📋 ข้อมูลการมอบหมาย               │
├────────────────────────────────────┤
│ ผู้รับผิดชอบ: อนันต์ วงศ์ใหญ่     │
│ ตำแหน่ง: Tier 2                   │
│ มอบหมายเมื่อ: 14 ม.ค. 2026 14:30 │
└────────────────────────────────────┘
```

---

## ✅ Changelog

| วันที่ | การเปลี่ยนแปลง | ผู้แก้ไข |
|--------|----------------|----------|
| 15 ม.ค. 2026 | เพิ่มเงื่อนไข: ซ่อน Badge เมื่อเคส closed/resolved | Development Team |
| 15 ม.ค. 2026 | เพิ่มเงื่อนไข: ซ่อน Badge เมื่อเจ้าของดูเคสตัวเอง | Development Team |
| 15 ม.ค. 2026 | เพิ่มเงื่อนไข: ซ่อน AssignmentInfoCard เมื่อเคส closed/resolved | Development Team |
| 15 ม.ค. 2026 | เพิ่มเงื่อนไข: ซ่อน ReadOnlyModeBanner เมื่อเคส closed/resolved | Development Team |
| 15 ม.ค. 2026 | สร้างเอกสาร ASSIGNED_BADGE_RULES.md | Development Team |

---

**จัดทำโดย:** CDGS Issue Tracking Development Team  
**อัพเดตล่าสุด:** 15 มกราคม 2026