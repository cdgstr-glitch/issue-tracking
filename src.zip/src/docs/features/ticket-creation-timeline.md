# 📝 ระบบ Timeline การสร้างเคส (Ticket Creation Timeline)

## 📋 ภาพรวม

ระบบ Timeline การสร้างเคสแสดงข้อมูลการสร้างเคสแบบสองรูปแบบ ขึ้นอยู่กับว่าใครเป็นผู้สร้างเคส:

### 1️⃣ **ลูกค้าสร้างเคสเอง** (Customer Self-Service)
- ลูกค้าเข้ามาในระบบและสร้างเคสด้วยตัวเอง
- แสดงข้อความ: **"เคสของคุณ {ชื่อลูกค้า} ถูกสร้างเรียบร้อยแล้ว"**
- แสดงผู้สร้าง: **"by {ชื่อลูกค้า}"**

### 2️⃣ **เจ้าหน้าที่สร้างเคสแทนลูกค้า** (Staff On-Behalf)
- เจ้าหน้าที่ (Staff) รับเรื่องจากลูกค้าผ่านช่องทาง phone, email, line
- บันทึกเป็นเคสในระบบแทนลูกค้า
- แสดงข้อความ: **"เคสของคุณ {ชื่อลูกค้า} ถูกสร้างเรียบร้อยแล้ว"**
- แสดงผู้สร้าง: **"by {ชื่อเจ้าหน้าที่}"**

---

## 🏗️ โครงสร้างข้อมูล

### Ticket Fields

```typescript
interface Ticket {
  // ... fields อื่นๆ
  
  // ข้อมูลลูกค้า
  customerName: string;           // ชื่อลูกค้าที่แจ้งปัญหา
  customerEmail: string;          // อีเมลลูกค้า
  customerPhone: string;          // เบอร์โทรลูกค้า
  
  // ข้อมูลผู้สร้างเคส
  createdBy?: string;             // userId ของผู้สร้างเคส (customer-xxx หรือ staff-xxx)
  createdByName?: string;         // ชื่อผู้สร้างเคส
  createdByType?: CreatedByType;  // 'customer_self' | 'staff_on_behalf'
  createdByStaffName?: string;    // ชื่อ Staff ที่สร้างแทนลูกค้า (ถ้า createdByType = 'staff_on_behalf')
  
  // ช่องทางการติดต่อ
  channel: TicketChannel;         // 'web' | 'email' | 'line' | 'phone'
}

type CreatedByType = 'customer_self' | 'staff_on_behalf';
```

### TimelineEvent Fields

```typescript
interface TimelineEvent {
  id: string;
  timestamp: Date;
  type: 'created' | 'status_change' | 'comment' | 'escalation' | 'assignment' | ...;
  action?: string;                // 'created' สำหรับการสร้างเคส
  description: string;            // คำอธิบาย event
  user?: string;                  // ชื่อผู้กระทำ (ผู้สร้าง, ผู้ส่งต่อ, ฯลฯ)
  userName?: string;              // Alternative field สำหรับชื่อผู้กระทำ
  userId?: string;                // userId ของผู้กระทำ
}
```

---

## 🔍 การตรวจสอบประเภทการสร้างเคส

### วิธีที่ 1: ใช้ `createdByType` (Recommended)

```typescript
// ✅ วิธีที่แม่นยำที่สุด
if (ticket.createdByType === 'customer_self') {
  // ลูกค้าสร้างเอง
  displayText = `เคสของคุณ ${ticket.customerName} ถูกสร้างเรียบร้อยแล้ว`;
  createdBy = ticket.customerName;
} else if (ticket.createdByType === 'staff_on_behalf') {
  // Staff สร้างแทน
  displayText = `เคสของคุณ ${ticket.customerName} ถูกสร้างเรียบร้อยแล้ว`;
  createdBy = ticket.createdByStaffName || ticket.createdByName || 'เจ้าหน้าที่';
}
```

### วิธีที่ 2: ใช้ `channel` (Fallback)

```typescript
// ✅ ใช้เมื่อไม่มี createdByType
const staffChannels = ['phone', 'email', 'line']; // ช่องทางที่ Staff รับเรื่อง
const isStaffCreated = staffChannels.includes(ticket.channel);

if (isStaffCreated) {
  // Staff สร้างแทน
  createdBy = ticket.createdByStaffName || ticket.createdByName || 'เจ้าหน้าที่';
} else {
  // ลูกค้าสร้างเอง (channel = 'web')
  createdBy = ticket.customerName;
}
```

---

## 🎨 UI Component: TicketTimeline

### การแสดงผลใน Timeline

```tsx
// ✅ Logic การแสดงผล
const isCreatedEvent = event.type === 'created' || event.action === 'created';
const isCustomerSelfCreated = ticket.createdByType === 'customer_self';
const isStaffCreated = ticket.createdByType === 'staff_on_behalf';

if (isCreatedEvent) {
  // กรณีลูกค้าสร้างเอง
  if (isCustomerSelfCreated) {
    description = `เคสของคุณ ${ticket.customerName} ถูกสร้างเรียบร้อยแล้ว`;
    createdBy = ticket.customerName;
  }
  
  // กรณี Staff สร้างแทน
  if (isStaffCreated) {
    description = `เคสของคุณ ${ticket.customerName} ถูกสร้างเรียบร้อยแล้ว`;
    createdBy = ticket.createdByStaffName || ticket.createdByName || 'เจ้าหน้าที่';
  }
  
  // แสดงผล
  return (
    <div>
      <p>{description}</p>
      <p className="text-xs text-gray-600">
        by <span className="font-medium">{createdBy}</span>
      </p>
    </div>
  );
}
```

---

## 📊 ตัวอย่างข้อมูล Mock Data

### ตัวอย่าง 1: ลูกค้าสร้างเคสเอง (Web Channel)

```typescript
{
  id: 'ticket-001',
  ticketNumber: 'CDGS-2024-W001',
  customerName: 'ศิริพร อารีมิตร',
  customerEmail: 'siriporn@example.com',
  channel: 'web',                           // ✅ ลูกค้าสร้างผ่าน web
  createdBy: 'customer-demo-001',           // ✅ customer userId
  createdByName: 'ศิริพร อารีมิตร',
  createdByType: 'customer_self',           // ✅ ลูกค้าสร้างเอง
  timeline: [
    {
      id: 'event-001',
      type: 'created',
      action: 'created',
      description: 'เคสของคุณ ศิริพร อารีมิตร ถูกสร้างเรียบร้อยแล้ว',
      user: 'ศิริพร อารีมิตร',              // ✅ ชื่อลูกค้า
      timestamp: new Date('2024-11-27T09:00:00')
    }
  ]
}
```

**Timeline แสดง:**
```
✅ เคสของคุณ ศิริพร อารีมิตร ถูกสร้างเรียบร้อยแล้ว
   by ศิริพร อารีมิตร
```

---

### ตัวอย่าง 2: Staff สร้างเคสแทนลูกค้า (Phone Channel)

```typescript
{
  id: 'ticket-002',
  ticketNumber: 'CDGS-2024-P001',
  customerName: 'สมชาย กล้าหาญ',
  customerEmail: 'somchai@example.com',
  channel: 'phone',                         // ✅ ลูกค้าโทรมาแจ้ง
  createdBy: 'staff-001',                   // ✅ staff userId
  createdByName: 'สมชาย ใจดี',
  createdByType: 'staff_on_behalf',         // ✅ Staff สร้างแทน
  createdByStaffName: 'สมชาย ใจดี',        // ✅ ชื่อ Staff ที่บันทึก
  timeline: [
    {
      id: 'event-001',
      type: 'created',
      action: 'created',
      description: 'เคสของคุณ สมชาย กล้าหาญ ถูกสร้างเรียบร้อยแล้ว',
      user: 'สมชาย ใจดี',                   // ✅ ชื่อ Staff
      timestamp: new Date('2024-11-27T10:30:00')
    }
  ]
}
```

**Timeline แสดง:**
```
✅ เคสของคุณ สมชาย กล้าหาญ ถูกสร้างเรียบร้อยแล้ว
   by สมชาย ใจดี
```

---

## 🔄 Workflow การสร้างเคส

### 1️⃣ Customer Self-Service (Web)

```
┌──────────────┐
│  ลูกค้า      │
│  ศิริพร      │
└──────┬───────┘
       │ เข้าเว็บสร้างเคส
       ↓
┌──────────────────────────────┐
│ System สร้างเคส              │
│ - createdBy: customer-xxx    │
│ - createdByType: customer_self│
│ - createdByName: ศิริพร      │
│ - channel: web               │
└──────┬───────────────────────┘
       │
       ↓
┌──────────────────────────────┐
│ Timeline:                    │
│ ✅ เคสของคุณ ศิริพร          │
│    ถูกสร้างเรียบร้อยแล้ว    │
│    by ศิริพร อารีมิตร        │
└──────────────────────────────┘
```

### 2️⃣ Staff On-Behalf (Phone/Email/Line)

```
┌──────────────┐
│  ลูกค้า      │
│  สมชาย       │
└──────┬───────┘
       │ โทรแจ้งปัญหา
       ↓
┌──────────────┐
│  Staff       │
│  สมชาย ใจดี  │
└──────┬───────┘
       │ บันทึกเคสในระบบ
       ↓
┌──────────────────────────────────┐
│ System สร้างเคส                  │
│ - customerName: สมชาย กล้าหาญ    │
│ - createdBy: staff-001           │
│ - createdByType: staff_on_behalf │
│ - createdByStaffName: สมชาย ใจดี │
│ - channel: phone                 │
└──────┬───────────────────────────┘
       │
       ↓
┌──────────────────────────────┐
│ Timeline:                    │
│ ✅ เคสของคุณ สมชาย กล้าหาญ   │
│    ถูกสร้างเรียบร้อยแล้ว    │
│    by สมชาย ใจดี             │
└──────────────────────────────┘
```

---

## ✅ Checklist การ Implement

### Frontend (Component)

- [x] สร้างเอกสาร `ticket-creation-timeline.md`
- [ ] อัพเดท `TicketTimeline.tsx` ให้ตรวจสอบ `createdByType`
- [ ] แสดงข้อความ "เคสของคุณ {customerName} ถูกสร้างเรียบร้อยแล้ว"
- [ ] แสดง "by {createdBy}" ตามประเภทการสร้าง
- [ ] เพิ่ม Fallback logic ถ้าไม่มี `createdByType`

### Backend (Mock Data)

- [ ] เพิ่ม `createdByType` ให้ทุก ticket
- [ ] เพิ่ม `createdByStaffName` ให้ ticket ที่ Staff สร้าง
- [ ] อัพเดท timeline events ให้ครบถ้วน

### Testing

- [ ] ทดสอบแสดงผลลูกค้าสร้างเอง (Web)
- [ ] ทดสอบแสดงผล Staff สร้างแทน (Phone/Email/Line)
- [ ] ทดสอบ Fallback logic

---

## 🎯 Business Rules

### กฎการกำหนด createdByType

| Channel | createdByType | createdBy | หมายเหตุ |
|---------|---------------|-----------|----------|
| **web** | `customer_self` | customer-xxx | ลูกค้าสร้างเอง |
| **phone** | `staff_on_behalf` | staff-xxx | Staff รับสายแล้วบันทึก |
| **email** | `staff_on_behalf` | staff-xxx | Staff รับอีเมลแล้วบันทึก |
| **line** | `staff_on_behalf` | staff-xxx | Staff รับใน Line แล้วบันทึก |

### ข้อยกเว้น

- ถ้าระบบรองรับ Magic Link Authentication ผ่าน Email/Line ในอนาคต อาจมีกรณีที่ลูกค้าสร้างเคสผ่าน Email/Line ได้เอง → ต้องตรวจสอบจาก `createdBy` ว่าเป็น customer หรือ staff

---

## 📝 สรุป

ระบบ Timeline การสร้างเคสแยกแยะระหว่าง:

1. **ลูกค้าสร้างเอง** → แสดง "by {ชื่อลูกค้า}"
2. **Staff สร้างแทน** → แสดง "by {ชื่อ Staff}"

โดยใช้ `createdByType` เป็นตัวกำหนดหลัก และ `channel` เป็น Fallback

---

**เอกสารนี้อัพเดทล่าสุด:** 27 ตุลาคม 2567
