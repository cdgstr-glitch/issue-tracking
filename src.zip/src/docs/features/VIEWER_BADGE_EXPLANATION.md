# 👁️ ViewerBadge - Real-time Viewer Indicator

**วันที่สร้าง:** 15 มกราคม 2026  
**Feature:** แสดง Badge ผู้ที่กำลังดูเคสแบบ Real-time

---

## 🎯 ความหมาย

### Badge: **"👁️ เฝ้าดู แซ่ด้ง (เทียร์ 1)"**

- **ไอคอน:** 👁️ (Eye) = กำลังดูอยู่
- **ชื่อ:** แซ่ด้ง (วรรณภา แซ่ด่าง)
- **บทบาท:** เทียร์ 1 (Tier 1)
- **สี:** ม่วง (Purple) = bg-purple-100, text-purple-700

---

## 📖 คำอธิบาย

**ViewerBadge** แสดงว่า:
> **"มีคนกำลังดูเคสนี้อยู่ในขณะนี้"**

### 🔍 Use Case:

1. **Real-time Awareness:** รู้ว่ามีใครกำลังดูเคสเดียวกันอยู่
2. **Collision Prevention:** ป้องกันการรับเคสซ้ำซ้อน
3. **Collaboration:** เห็นว่าใครกำลังทำงานเคสนั้นอยู่

---

## 🎨 UI Design

### Badge Layout:
```
┌──────────────────────────────────┐
│ 👁️ เฝ้าดู แซ่ด้ง (เทียร์ 1)    │
└──────────────────────────────────┘
  ↑     ↑       ↑          ↑
  │     │       │          └─ Role (เทียร์ 1)
  │     │       └──────────── Name (แซ่ด้ง)
  │     └──────────────────── Action (เฝ้าดู)
  └────────────────────────── Icon (Eye)
```

### Color:
- **Background:** bg-purple-100 (สีม่วงอ่อน)
- **Text:** text-purple-700 (สีม่วงเข้ม)
- **Style:** rounded-full (มุมโค้งมน)

---

## 💻 Component Code

### Location: `/components/ViewerBadge.tsx`

```tsx
import { Eye } from 'lucide-react';

interface ViewerBadgeProps {
  viewerName: string;     // ชื่อผู้ดู
  viewerRole?: string;    // บทบาท (optional)
  size?: 'sm' | 'md';     // ขนาด badge
}

export function ViewerBadge({ viewerName, viewerRole, size = 'sm' }: ViewerBadgeProps) {
  const roleDisplayName = viewerRole ? getRoleDisplayName(viewerRole) : '';
  
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-purple-100 text-purple-700 px-2 py-0.5 text-xs">
      <Eye className="h-3 w-3" />
      <span className="font-medium">{viewerName}</span>
      {roleDisplayName && (
        <span className="text-purple-600/80">({roleDisplayName})</span>
      )}
    </span>
  );
}
```

---

## 🔄 Data Structure

### Ticket Type:
```typescript
interface Ticket {
  // ... other fields
  currentViewers?: {
    userId: string;
    name: string;
    role: string;
    viewedAt: Date;
  }[];
}
```

### Example:
```typescript
const ticket = {
  id: 'ticket-001',
  ticketNumber: 'CDGS-2024-001',
  title: 'ปัญหาระบบ...',
  currentViewers: [
    {
      userId: 'user-003',
      name: 'วรรณภา แซ่ด่าง',
      role: 'tier1',
      viewedAt: new Date()
    }
  ]
};
```

---

## 📍 ใช้งานที่ไหน?

### 1. `/components/TicketListPage.tsx`

**Desktop View:**
```tsx
{ticket.currentViewers && ticket.currentViewers.length > 0 && (
  <div className="flex items-center gap-1.5 flex-wrap">
    {ticket.currentViewers
      .filter(viewer => viewer.userId !== user?.id) // ไม่แสดงตัวเอง
      .map((viewer, idx) => (
        <ViewerBadge
          key={idx}
          viewerName={viewer.name}
          viewerRole={viewer.role}
          size="sm"
        />
      ))}
  </div>
)}
```

**Mobile View:**
```tsx
{ticket.currentViewers && ticket.currentViewers.length > 0 && (
  <div className="mb-3 flex items-center gap-1.5 flex-wrap">
    {ticket.currentViewers
      .filter(viewer => viewer.userId !== user?.id)
      .map((viewer, idx) => (
        <ViewerBadge
          key={idx}
          viewerName={viewer.name}
          viewerRole={viewer.role}
          size="sm"
        />
      ))}
  </div>
)}
```

---

## 🎯 Business Logic

### 1. **กรองตัวเอง:**
```typescript
.filter(viewer => viewer.userId !== user?.id)
```
→ ไม่แสดง Badge ของตัวเองที่กำลังดู

### 2. **แสดงหลายคน:**
```typescript
{ticket.currentViewers.map((viewer, idx) => (
  <ViewerBadge key={idx} ... />
))}
```
→ ถ้ามีหลายคนดูพร้อมกัน จะแสดงหลาย Badge

### 3. **Real-time Update:**
- เมื่อมีคนเปิดดูเคส → เพิ่ม `currentViewers`
- เมื่อออกจากหน้า → ลบ `currentViewers`

---

## 🆚 เปรียบเทียบกับ Badge อื่น

| Badge Type | Icon | ความหมาย | สี |
|------------|------|----------|-----|
| **ViewerBadge** | 👁️ Eye | **กำลังดูอยู่** | Purple |
| **StatusBadge** | - | สถานะเคส (เทียร์ 1/2/3) | Blue/Yellow/Red |
| **PriorityBadge** | ⚡ | ความสำคัญ (สูง/ด่วน) | Orange/Red |
| **EscalationBadge** | 🔄 | ประวัติการส่งต่อ | Various |

---

## ✅ ตัวอย่างการใช้งาน

### Scenario 1: คนเดียวกำลังดูเคส
```
┌─────────────────────────────────────────┐
│ CDGS-2024-001 | ปัญหาระบบ Login         │
│ 👁️ เฝ้าดู แซ่ด้ง (เทียร์ 1)           │
└─────────────────────────────────────────┘
```

### Scenario 2: หลายคนกำลังดูเคส
```
┌─────────────────────────────────────────────────────────┐
│ CDGS-2024-001 | ปัญหาระบบ Login                        │
│ 👁️ เฝ้าดู แซ่ด้ง (เทียร์ 1)                           │
│ 👁️ เฝ้าดู ยุทธนา (เทียร์ 2)                           │
└─────────────────────────────────────────────────────────┘
```

### Scenario 3: ไม่มีใครดู
```
┌─────────────────────────────────────────┐
│ CDGS-2024-001 | ปัญหาระบบ Login         │
│ (ไม่แสดง ViewerBadge)                   │
└─────────────────────────────────────────┘
```

---

## 🚀 Future Enhancements

### Possible Features:
1. **Tooltip:** Hover แสดง "กำลังดูมาแล้ว 5 นาที"
2. **Blink Effect:** Badge กระพริบเมื่อมีคนดูใหม่
3. **Count Badge:** แสดง "👁️ 3 คนกำลังดู" แทนแสดงทีละคน
4. **Online Status:** แสดงจุดสีเขียวว่า Online อยู่

---

## 📌 Key Points

### ✅ สิ่งที่ ViewerBadge ทำ:
- แสดงว่า**ใครกำลังดูเคสนี้อยู่**
- **Real-time awareness** (รู้ว่ามีคนอื่นดูอยู่)
- **Collaboration indicator** (สื่อสารระหว่างทีม)

### ❌ สิ่งที่ ViewerBadge ไม่ใช่:
- ❌ **ไม่ใช่ Status Badge** (ไม่ใช่สถานะเคส)
- ❌ **ไม่ใช่ Assignee Badge** (ไม่ใช่ผู้รับผิดชอบเคส)
- ❌ **ไม่ใช่ Escalation Badge** (ไม่ใช่ประวัติการส่งต่อ)

---

## 🎓 สรุป

**ViewerBadge "👁️ เฝ้าดู แซ่ด้ง (เทียร์ 1)"** แสดงว่า:

> **"วรรณภา แซ่ด่าง (Tier 1) กำลังดูเคสนี้อยู่ในขณะนี้"**

**Purpose:**
- 🔍 **Awareness:** เห็นว่าใครกำลังทำงานเคสนี้
- 🤝 **Collaboration:** ประสานงานกับทีมได้ดีขึ้น
- ⚠️ **Prevention:** ป้องกันการรับเคสซ้ำซ้อน

---

**Status:** ✅ **เสร็จสมบูรณ์**  
**ผู้สร้างเอกสาร:** AI Assistant  
**วันที่:** 15 มกราคม 2026
