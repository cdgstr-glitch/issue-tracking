# 🎯 ระบบบทบาท (Role System) และ Active Role Switching

> **⚠️ กฎเหล็ก - เอกสารสำคัญ**  
> เอกสารนี้อธิบายระบบบทบาทและการสลับบทบาทของระบบ CDGS Issue Tracking Platform  
> **ห้าม** แก้ไขหรือเปลี่ยนแปลงโดยไม่ได้รับการอนุมัติ

---

## 📋 สารบัญ

1. [ภาพรวมระบบ](#1-ภาพรวมระบบ)
2. [โครงสร้างข้อมูล User](#2-โครงสร้างข้อมูล-user)
3. [Role Array vs Single Role](#3-role-array-vs-single-role)
4. [Active Role Switching](#4-active-role-switching)
5. [รายชื่อผู้ใช้งานแยกตาม Role](#5-รายชื่อผู้ใช้งานแยกตาม-role)
6. [Permission: บันทึกเคสแทนลูกค้า](#6-permission-บันทึกเคสแทนลูกค้า)
7. [ฟังก์ชันสนับสนุน](#7-ฟังก์ชันสนับสนุน)
8. [ตัวอย่างโค้ด](#8-ตัวอย่างโค้ด)

---

## 1. ภาพรวมระบบ

### 🎯 หลักการทำงาน

ระบบใช้ **Single Role + Role Array** แบบผสม:

- **User ส่วนใหญ่** = Single Role (มี role เดียว)
- **User ที่มี Multi-role** = Role Array (มีหลาย role และสามารถสลับได้)

### ⚠️ กฎเหล็ก

1. **Role Array ใช้เฉพาะ Tier2-3 เท่านั้น**
   - มีเพียง **1 คน** คือ **ประกาศิต ประคองเพ็ชร** (`roles: ['tier2', 'tier3']`)
   
2. **Active Role Switching ใช้กับ Tier2-3 เท่านั้น**
   - Tier1, Admin, Staff ไม่มีการสลับบทบาท

3. **Admin + Tier1 ไม่ใช่ Multi-role แบบสลับได้**
   - มี roles array แต่ใช้ `primaryRole: 'admin'` เป็นหลัก
   - ไม่มี UI สำหรับสลับ

4. **Tier1 ≠ Staff**
   - Tier1 ไม่มี `staff` role ใน array
   - Staff เป็น role แยกต่างหาก

---

## 2. โครงสร้างข้อมูล User

### 📦 Type Definition

```typescript
type UserRole = 'admin' | 'staff' | 'tier1' | 'tier2' | 'tier3' | 'customer';

interface User {
  id: string;
  username: string;
  fullName: string;
  
  // Role fields
  role: UserRole;              // ✅ Single role (backward compatibility)
  roles?: UserRole[];          // ✅ Role array (optional - สำหรับ multi-role)
  primaryRole: UserRole;       // ✅ Role หลักที่ใช้งาน
  
  email: string;
  phone?: string;
  department?: string;
  tier?: 1 | 2 | 3;
  projectIds?: string[];
  managerId?: string;
  managerEmail?: string;
}
```

### 🆕 AuthContext

```typescript
interface AuthContextType {
  user: User | null;
  customer: CustomerUser | null;
  activeRole: UserRole;                    // 🆕 บทบาทที่กำลังใช้งาน
  setActiveRole: (role: UserRole) => void; // 🆕 ฟังก์ชันสลับบทบาท
  login: (username: string, password: string) => Promise<boolean>;
  loginWithMagicLink: (token: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  isCustomer: boolean;
  isLoading: boolean;
}
```

### 🔑 Session Storage

```typescript
// บันทึก 3 ค่า
sessionStorage.setItem('cdgs_user', JSON.stringify(user));
sessionStorage.setItem('cdgs_customer', JSON.stringify(customer));
sessionStorage.setItem('cdgs_active_role', activeRole); // 🆕 บันทึกบทบาทที่กำลังใช้
```

---

## 3. Role Array vs Single Role

### 📊 สรุปการใช้งาน

| User | role | roles | primaryRole | สลับ Role ได้? |
|------|------|-------|-------------|---------------|
| **Admin (Pure)** | `admin` | `['admin']` | `admin` | ❌ ไม่ได้ |
| **Admin + Tier1** | `admin` | `['admin', 'tier1']` | `admin` | ❌ ไม่ได้ |
| **Tier1** | `tier1` | `['tier1']` | `tier1` | ❌ ไม่ได้ |
| **Tier2** | `tier2` | `['tier2']` | `tier2` | ❌ ไม่ได้ |
| **Tier2 + Tier3** | `tier2` | `['tier2', 'tier3']` | `tier2` | ✅ **สลับได้** |
| **Tier3** | `tier3` | `['tier3']` | `tier3` | ❌ ไม่ได้ |
| **Staff** | `staff` | `['staff']` | `staff` | ❌ ไม่ได้ |
| **Customer** | `customer` | `['customer']` | `customer` | ❌ ไม่ได้ |

---

## 4. Active Role Switching

### 🔄 การทำงาน

**Active Role Switching** = ระบบสลับบทบาทแบบ Dynamic

**ใช้ได้เฉพาะ:**
- User ที่มี `roles.length > 1` และมี role ใน `['tier2', 'tier3']` เท่านั้น

### 👤 User ที่สามารถสลับ Role

**มีเพียง 1 คนเท่านั้น:**

| # | ชื่อ | Username | roles | primaryRole | activeRole (เริ่มต้น) |
|---|------|----------|-------|-------------|---------------------|
| 1 | **ประกาศิต ประคองเพ็ชร** | `prakasit.p` | `['tier2', 'tier3']` | `tier2` | `tier2` |

### 🎛️ UI Role Selector

**เงื่อนไข:** แสดง Role Selector ก็ต่อเมื่อ `needsRoleSelector(user) === true`

```typescript
function needsRoleSelector(user: User): boolean {
  const tierRoles = getTierRoles(user); // ['tier2', 'tier3']
  return tierRoles.length > 1; // true
}
```

**ตัวอย่าง UI:**

```
┌─────────────────────────────────┐
│ สลับบทบาท                       │
├─────────────────────────────────┤
│ ⦿ Tier 2 Support               │ ← activeRole: 'tier2'
│ ○ Tier 3 Support               │
└─────────────────────────────────┘
```

เมื่อคลิก "Tier 3 Support":
```typescript
setActiveRole('tier3'); // เปลี่ยนเป็น activeRole: 'tier3'
// ✅ บันทึกใน sessionStorage
sessionStorage.setItem('cdgs_active_role', 'tier3');
```

### 🔄 Flow ของ Active Role

```mermaid
graph LR
    A[Login] --> B{มี roles > 1?}
    B -->|Yes| C[ใช้ primaryRole เป็น activeRole]
    B -->|No| C
    C --> D[แสดง Dashboard ตาม activeRole]
    D --> E{User สลับ Role?}
    E -->|Yes| F[setActiveRole ใหม่]
    F --> G[บันทึกใน sessionStorage]
    G --> D
    E -->|No| D
```

### 📝 ตัวอย่างการทำงาน

```typescript
// 1. Login
login('prakasit.p', 'prakasit.p123')

// 2. ระบบตั้งค่า activeRole = primaryRole
activeRole = user.primaryRole; // 'tier2'

// 3. User เห็น Role Selector (เพราะ needsRoleSelector(user) === true)
// 4. User คลิก "Tier 3 Support"
setActiveRole('tier3');

// 5. ระบบเปลี่ยน activeRole และ redirect
activeRole = 'tier3';
navigate('/'); // Redirect ไปยัง Dashboard ใหม่

// 6. Dashboard แสดงตาม activeRole = 'tier3'
// - เห็นเฉพาะเคส status = 'tier3'
// - เมนู "รอดำเนินการ" แสดงเฉพาะคิว Tier3
```

---

## 5. รายชื่อผู้ใช้งานแยกตาม Role

### 👥 10 CDGS Team Members

#### 🔴 Admin (1 คน)

| # | ชื่อ | Username | roles | primaryRole |
|---|------|----------|-------|-------------|
| 1 | ประอรรัตน์ กีรติผจญ | `pra-onrat.k` | `['admin']` | `admin` |

#### 🔵 Admin + Tier1 (2 คน)

| # | ชื่อ | Username | roles | primaryRole | หมายเหตุ |
|---|------|----------|-------|-------------|----------|
| 1 | ธิราภรณ์ รุ่งวิรัตน์กุล | `thiraporn.r` | `['admin', 'tier1']` | `admin` | หัวหน้าทีม Tier1 |
| 2 | สาริน ช่อพะยอม | `sarin.c` | `['admin', 'tier1']` | `admin` | |

#### 🟢 Tier1 (3 คน)

| # | ชื่อ | Username | roles | primaryRole |
|---|------|----------|-------|-------------|
| 1 | วรรณภา แซ่ด่าง | `wannapa.s` | `['tier1']` | `tier1` |
| 2 | เขมิกา แซ่ตั้ง | `khemika.s` | `['tier1']` | `tier1` |
| 3 | ธัญญาพร ทองแก้ว | `thanyaporn.t` | `['tier1']` | `tier1` |

#### 🟡 Tier2 (2 คน)

| # | ชื่อ | Username | roles | primaryRole | หมายเหตุ |
|---|------|----------|-------|-------------|----------|
| 1 | ยุทธนา คณามิ่งมงคล | `yuttana.k` | `['tier2']` | `tier2` | หัวหน้าทีม Tier2 |
| 2 | ประวิช จินทนากร | `pravich.j` | `['tier2']` | `tier2` | |

#### 🟠 Tier2 + Tier3 (1 คน) - มี Active Role Switching

| # | ชื่อ | Username | roles | primaryRole | **สลับ Role ได้** |
|---|------|----------|-------|-------------|------------------|
| 1 | **ประกาศิต ประคองเพ็ชร** | `prakasit.p` | `['tier2', 'tier3']` | `tier2` | ✅ **สลับได้ tier2 ↔ tier3** |

#### 🟣 Tier3 (2 คน)

| # | ชื่อ | Username | roles | primaryRole |
|---|------|----------|-------|-------------|
| 1 | พุทธจักษ์ วงค์พันธ์ | `puttajak.w` | `['tier3']` | `tier3` |
| 2 | วีระกร เยือกเย็น | `wirakorn.y` | `['tier3']` | `tier3` |

---

### 🧪 Test Accounts (2 บัญชี)

#### 📞 Staff (2 คน)

| # | ชื่อ | Username | roles | primaryRole | หมายเหตุ |
|---|------|----------|-------|-------------|----------|
| 1 | สมชาย ใจดี | `staff` | `['staff']` | `staff` | เจ้าหน้าที่รับแจ้งเคสแทนลูกค้า |
| 2 | เอกชัย เบ็นเจ๊ะอาหวัง | `eakkachai.b` | `['staff']` | `staff` | Digital & SaaS Project Support |

#### 👤 Customer (3 คน - Magic Link)

| # | ชื่อ | Email | หมายเหตุ |
|---|------|-------|----------|
| 1 | ศิริพร อารีมิตร | `siriporn@example.com` | Login ผ่าน Magic Link |
| 2 | สมชาย กล้าหาญ | `somchai@example.com` | Login ผ่าน Magic Link |
| 3 | ณัฐยา สุขสันต์ | `nattaya@example.com` | Login ผ่าน Magic Link |

---

## 6. Permission: บันทึกเคสแทนลูกค้า

### 🎯 ผู้ที่มี Permission "บันทึกเคสแทนลูกค้า"

**กฎ:** ทุกคนที่มี **Tier1** role หรือ **Staff** role สามารถบันทึกเคสแทนลูกค้าได้

#### 📋 รายชื่อ (7 คน)

| # | ชื่อ-นามสกุล | Username | Role | User ID | เหตุผล |
|---|-------------|----------|------|---------|---------|
| 1 | **สมชาย ใจดี** | `staff` | **Staff** | `staff-001` | มี role `staff` |
| 2 | **เอกชัย เบ็นเจ๊ะอาหวัง** | `eakkachai.b` | **Staff** | `staff-002` | มี role `staff` |
| 3 | **ธิราภรณ์ รุ่งวิรัตน์กุล** | `thiraporn.r` | Admin + Tier1 | `user-001` | มี `tier1` ใน roles |
| 4 | **สาริน ช่อพะยอม** | `sarin.c` | Admin + Tier1 | `user-002` | มี `tier1` ใน roles |
| 5 | **วรรณภา แซ่ด่าง** | `wannapa.s` | Tier1 | `user-003` | มี role `tier1` |
| 6 | **เขมิกา แซ่ตั้ง** | `khemika.s` | Tier1 | `user-004` | มี role `tier1` |
| 7 | **ธัญญาพร ทองแก้ว** | `thanyaporn.t` | Tier1 | `user-005` | มี role `tier1` |

### ❌ ผู้ที่ **ไม่สามารถ** บันทึกเคสแทนลูกค้า

| ชื่อ-นามสกุล | Role | เหตุผล |
|-------------|------|--------|
| ยุทธนา คณามิ่งมงคล | Tier2 | ไม่มี Tier1 หรือ Staff role |
| ประกาศิต ประคองเพ็ชร | Tier2 + Tier3 | ไม่มี Tier1 หรือ Staff role |
| ประวิช จินทนากร | Tier2 | ไม่มี Tier1 หรือ Staff role |
| พุทธจักษ์ วงค์พันธ์ | Tier3 | ไม่มี Tier1 หรือ Staff role |
| วีระกร เยือกเย็น | Tier3 | ไม่มี Tier1 หรือ Staff role |
| ประอรรัตน์ กีรติผจญ | Admin (Pure) | ไม่มี Tier1 หรือ Staff role |

### 🔒 การตรวจสอบ Permission

```typescript
function canCreateTicketOnBehalf(user: User): boolean {
  const allRoles = user.roles || [user.role];
  return allRoles.includes('tier1') || allRoles.includes('staff');
}

// ตัวอย่าง
canCreateTicketOnBehalf(staff);      // true (มี 'staff')
canCreateTicketOnBehalf(wannapa);    // true (มี 'tier1')
canCreateTicketOnBehalf(thiraporn);  // true (มี 'tier1' ใน roles)
canCreateTicketOnBehalf(yuttana);    // false (ไม่มี 'tier1' หรือ 'staff')
```

---

## 7. ฟังก์ชันสนับสนุน

### 📦 `/lib/utils.ts`

#### 1. `getAllRoles(user)`
```typescript
/**
 * Get all roles of a user (supports multi-role)
 * @param user - User object
 * @returns array of all roles
 */
export function getAllRoles(user: User | null | undefined): UserRole[] {
  if (!user) return [];
  
  // NEW: Use roles array if available
  if (user.roles && user.roles.length > 0) {
    return user.roles;
  }
  
  // FALLBACK: Backward compatibility with single role
  return [user.role];
}

// ตัวอย่าง
getAllRoles(prakasit);   // ['tier2', 'tier3']
getAllRoles(thiraporn);  // ['admin', 'tier1']
getAllRoles(wannapa);    // ['tier1']
```

#### 2. `getTierRoles(user)` - สำหรับ Active Role Switching
```typescript
/**
 * Get user's tier roles only (tier2, tier3) สำหรับสลับบทบาท
 * ⚠️ IMPORTANT: tier1 ไม่มีการสลับบทบาท - ใช้ได้เฉพาะ tier2 และ tier3
 * @param user - User object
 * @returns array of tier roles (tier2, tier3 only)
 */
export function getTierRoles(user: User | null | undefined): UserRole[] {
  const allRoles = getAllRoles(user);
  // ✅ สลับบทบาทได้เฉพาะ tier2 และ tier3 เท่านั้น (ไม่รวม tier1 และ admin)
  return allRoles.filter(role => 
    ['tier2', 'tier3'].includes(role)
  );
}

// ตัวอย่าง
getTierRoles(prakasit);   // ['tier2', 'tier3'] ✅ สลับได้
getTierRoles(thiraporn);  // [] ❌ ไม่สลับ (admin + tier1 ไม่นับ)
getTierRoles(yuttana);    // ['tier2'] ❌ ไม่สลับ (มีแค่ role เดียว)
```

#### 3. `needsRoleSelector(user)`
```typescript
/**
 * Check if user needs role selector (has multiple tier roles)
 * @param user - User object
 * @returns true if user has more than 1 tier role
 */
export function needsRoleSelector(user: User | null | undefined): boolean {
  const tierRoles = getTierRoles(user);
  return tierRoles.length > 1;
}

// ตัวอย่าง
needsRoleSelector(prakasit);   // true ✅ (มี 2 tier roles: tier2, tier3)
needsRoleSelector(thiraporn);  // false ❌
needsRoleSelector(yuttana);    // false ❌
```

---

## 8. ตัวอย่างโค้ด

### 🔐 AuthContext Implementation

```typescript
// /contexts/AuthContext.tsx

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [customer, setCustomer] = useState<CustomerUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeRole, setActiveRoleState] = useState<UserRole>('customer');

  // Check for existing session on mount
  useEffect(() => {
    try {
      const storedUser = sessionStorage.getItem('cdgs_user');
      const storedCustomer = sessionStorage.getItem('cdgs_customer');
      const storedActiveRole = sessionStorage.getItem('cdgs_active_role');
      
      if (storedCustomer) {
        const parsedCustomer = JSON.parse(storedCustomer);
        setCustomer(parsedCustomer);
        setActiveRoleState('customer');
      }
      else if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        
        // กู้คืน activeRole หรือใช้ primaryRole
        if (storedActiveRole && parsedUser.roles?.includes(storedActiveRole as UserRole)) {
          setActiveRoleState(storedActiveRole as UserRole);
        } else {
          setActiveRoleState(parsedUser.primaryRole || 'customer');
        }
      }
    } catch (error) {
      console.warn('sessionStorage not available:', error);
    }
    setIsLoading(false);
  }, []);

  // ฟังก์ชันสลับบทบาท พร้อมตรวจสอบสิทธิ์
  const setActiveRole = (role: UserRole) => {
    if (!user) return;
    
    // ตรวจสอบว่า user มี role นี้หรือไม่
    if (!user.roles?.includes(role)) {
      console.warn(`User does not have role: ${role}`);
      return;
    }
    
    setActiveRoleState(role);
    try {
      sessionStorage.setItem('cdgs_active_role', role);
    } catch (error) {
      console.warn('Cannot save activeRole to sessionStorage:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        customer,
        activeRole,
        setActiveRole,
        login,
        loginWithMagicLink,
        logout,
        isAuthenticated: !!user || !!customer,
        isCustomer: !!customer,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
```

### 🎛️ Role Selector Component (ตัวอย่าง)

```typescript
// Component สำหรับสลับ Role (แสดงเฉพาะ User ที่ needsRoleSelector === true)

import { useAuth } from '../contexts/AuthContext';
import { getTierRoles, needsRoleSelector, getRoleDisplayName } from '../lib/utils';

export function RoleSelector() {
  const { user, activeRole, setActiveRole } = useAuth();
  
  // ไม่แสดงถ้า user ไม่มีหลาย tier roles
  if (!needsRoleSelector(user)) {
    return null;
  }
  
  const tierRoles = getTierRoles(user);
  
  return (
    <div className="role-selector">
      <h3>สลับบทบาท</h3>
      {tierRoles.map(role => (
        <button
          key={role}
          onClick={() => setActiveRole(role)}
          className={activeRole === role ? 'active' : ''}
        >
          {activeRole === role ? '⦿' : '○'} {getRoleDisplayName(role)}
        </button>
      ))}
    </div>
  );
}
```

### 🔄 Auto-redirect when activeRole changes

```typescript
// /App.tsx

function AppContent() {
  const { user, isAuthenticated, activeRole } = useAuth();
  const [currentRoute, setCurrentRoute] = useState<Route>({ path: '/' });

  // 🆕 Auto-redirect when activeRole changes (สำหรับสลับ role)
  useEffect(() => {
    if (isAuthenticated && user && activeRole) {
      // Redirect to appropriate dashboard based on activeRole
      if (activeRole === 'tier2') {
        navigate('/tier2-dashboard');
      } else if (activeRole === 'tier3') {
        navigate('/tier3-dashboard');
      }
      // ... other roles
    }
  }, [activeRole, isAuthenticated, user]);

  // ... rest of component
}
```

---

## 📊 สรุป

### ✅ กฎเหล็ก (ห้ามแก้ไข)

1. **Role Array มีเฉพาะ Tier2-3 เท่านั้น**
   - มีเพียง 1 คน: **ประกาศิต ประคองเพ็ชร** (`roles: ['tier2', 'tier3']`)

2. **Active Role Switching ใช้กับ Tier2-3 เท่านั้น**
   - ใช้ฟังก์ชัน `getTierRoles()` และ `needsRoleSelector()`
   - บันทึกใน `sessionStorage.cdgs_active_role`

3. **Admin + Tier1 ไม่สลับบทบาท**
   - มี `roles: ['admin', 'tier1']` แต่ใช้ `primaryRole: 'admin'`
   - ไม่แสดง Role Selector UI

4. **Tier1 ≠ Staff**
   - Tier1 ไม่มี `'staff'` ใน roles array
   - Staff เป็น role แยกต่างหาก (`roles: ['staff']`)

5. **Permission: บันทึกเคสแทนลูกค้า**
   - มีได้เฉพาะ: User ที่มี `'tier1'` หรือ `'staff'` role
   - รวม 7 คน: 2 Staff + 5 Tier1 (รวม Admin+Tier1)

### 🔗 เอกสารที่เกี่ยวข้อง

- [Team Members](/docs/TEAM_MEMBERS.md) - รายชื่อพนักงานทั้งหมด
- [Permission Matrix](/docs/PERMISSION_MATRIX.md) - สิทธิ์การเข้าถึงแต่ละ Role
- [Staff Role Documentation](/docs/features/STAFF_ROLE_DOCUMENTATION.md) - บทบาท Staff
- [Workflow](/docs/features/WORKFLOW.md) - เวิร์กโฟลว์การส่งต่อเคส

---

**เอกสารนี้สำคัญ** - กรุณาอ้างอิงเอกสารนี้เมื่อต้องทำงานเกี่ยวกับ Role System  
**อัพเดทล่าสุด:** 26 มกราคม 2026
