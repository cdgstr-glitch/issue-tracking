# 📋 Logic: การบันทึกเคสแบบ 2 ช่องทาง

> **วันที่:** 14 มกราคม 2026  
> **หัวข้อ:** Customer vs Staff - การสร้างเคส

---

## 🎯 ความต้องการ

ระบบมี **2 ช่องทาง** ในการสร้างเคส:

### **1. ลูกค้าแจ้งเคสเอง (Customer Self-Service)**
- ✅ ลูกค้า login → ไปหน้า "แจ้งเคสใหม่"
- ✅ **ข้อมูลผู้แจ้ง:** แสดงเป็น **Card** (Auto-filled จาก Profile)
- ✅ **ไม่ต้องกรอกข้อมูลซ้ำ** (ชื่อ, อีเมล, เบอร์, หน่วยงาน)
- ✅ **บันทึกในฐานข้อมูล:** "ลูกค้าเปิดเคสผ่านระบบด้วยตัวเอง"

### **2. เจ้าหน้าที่บันทึกแทนลูกค้า (Staff On-Behalf)**
- ✅ Staff login → ไปหน้า "แจ้งเคสใหม่โดยเจ้าหน้าที่"
- ✅ **ข้อมูลลูกค้า:** แสดงเป็น **Input Fields** (ต้องกรอกทุกช่อง)
- ✅ **กรอกข้อมูลลูกค้า** ที่ติดต่อเข้ามา (ไม่ใช่ข้อมูล staff เอง)
- ✅ **บันทึกในฐานข้อมูล:** "เจ้าหน้าที่ [ชื่อ staff] บันทึกเคสแทนลูกค้า"

---

## 🔄 Flow Diagram

### **Flow 1: Customer Creates Ticket**
```
┌─────────────────────────────────────────┐
│ 1. Customer Login                       │
│    (customer1 / customer1123)           │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 2. Navigate to "แจ้งเคสใหม่"            │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 3. UI: Customer Info Card (Auto-filled) │
│    ┌──────────────────────────┐         │
│    │ 📋 ข้อมูลผู้แจ้ง         │         │
│    │ 👤 สมชาย ใจดี           │         │
│    │ 📧 somchai@example.com  │         │
│    │ 📞 +66-81-234-5678      │         │
│    │ 🏢 ฝ่ายจัดซื้อ          │         │
│    └──────────────────────────┘         │
│    ✅ ไม่ต้องกรอกซ้ำ!                   │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 4. Fill in Issue Details                │
│    - หัวเรื่อง                           │
│    - รายละเอียด                          │
│    - หมวดหมู่                            │
│    - แนบไฟล์ (optional)                  │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 5. Submit → Create Ticket               │
│                                         │
│    Data Saved:                          │
│    {                                    │
│      customerName: "สมชาย ใจดี",        │
│      customerEmail: "somchai@...",      │
│      customerPhone: "+66-81-...",       │
│      customerDepartment: "ฝ่ายจัดซื้อ",  │
│      createdBy: "test-001",             │
│      createdByType: "customer_self",    │
│      createdByName: "สมชาย ใจดี",       │
│      channel: "web",                    │
│      note: "ลูกค้าเปิดเคสผ่านระบบ"     │
│    }                                    │
└─────────────────────────────────────────┘
```

---

### **Flow 2: Staff Creates Ticket On-Behalf**
```
┌─────────────────────────────────────────┐
│ 1. Staff Login                          │
│    (staff / staff123)                   │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 2. Navigate to "แจ้งเคสใหม่โดยเจ้าหน้าที่"│
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 3. UI: Input Fields for Customer        │
│    ┌──────────────────────────┐         │
│    │ ข้อมูลลูกค้า             │         │
│    │ ชื่อ: [_____________] *  │         │
│    │ อีเมล: [___________] *  │         │
│    │ เบอร์: [___________] *  │         │
│    │ หน่วยงาน: [________] *  │         │
│    └──────────────────────────┘         │
│    ❗ ต้องกรอกข้อมูลลูกค้า               │
│       (ไม่ใช่ข้อมูล staff)               │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 4. Select Channel + Fill Details        │
│    - ช่องทาง: Line/Phone/Email          │
│    - Line ID (ถ้าเลือก Line)            │
│    - วันที่เกิดเหตุ (Backdate)           │
│    - หัวเรื่อง                           │
│    - รายละเอียด                          │
└───────────────┬─────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────┐
│ 5. Submit → Create Ticket               │
│                                         │
│    Data Saved:                          │
│    {                                    │
│      customerName: "วิภา ศรีสุข",       │
│      customerEmail: "vipa@...",         │
│      customerPhone: "+66-82-...",       │
│      customerDepartment: "ฝ่ายการเงิน",  │
│      createdBy: "staff-001",            │
│      createdByType: "staff_on_behalf",  │
│      createdByStaffName: "สมชาย ใจดี",  │
│      channel: "phone",                  │
│      note: "เจ้าหน้าที่ สมชาย ใจดี บันทึกเคสแทนลูกค้า" │
│    }                                    │
└─────────────────────────────────────────┘
```

---

## 📊 Database Schema

### **ฟิลด์ที่ต้องบันทึก:**

| ฟิลด์ | Type | คำอธิบาย | Example |
|-------|------|----------|---------|
| `customerName` | string | ชื่อลูกค้า | "สมชาย ใจดี" |
| `customerEmail` | string | อีเมลลูกค้า | "somchai@example.com" |
| `customerPhone` | string | เบอร์โทรลูกค้า | "+66-81-234-5678" |
| `customerDepartment` | string | หน่วยงานลูกค้า | "ฝ่ายจัดซื้อ" |
| `createdBy` | string (User ID) | ผู้สร้างเคส | "test-001" or "staff-001" |
| `createdByType` | enum | ประเภทการสร้าง | "customer_self" or "staff_on_behalf" |
| `createdByStaffName` | string? | ชื่อ staff (ถ้าเป็น staff) | "สมชาย ใจดี" |
| `channel` | enum | ช่องทางการติดต่อ | "web", "phone", "email", "line" |
| `note` | string? | หมายเหตุ | "ลูกค้าเปิดเคสผ่านระบบ" |

---

## 🔍 Logic: createdByType

### **Enum Definition:**
```typescript
type CreatedByType = 
  | "customer_self"      // ลูกค้าแจ้งเคสเอง
  | "staff_on_behalf"    // Staff บันทึกแทนลูกค้า
```

### **การกำหนดค่า:**
```typescript
// 🟢 Case 1: Customer Creates Ticket
if (user.role === 'customer') {
  ticket = {
    customerName: user.name,          // ✅ ดึงจาก user profile
    customerEmail: user.email,        // ✅ ดึงจาก user profile
    customerPhone: user.phone,        // ✅ ดึงจาก user profile
    customerDepartment: user.department, // ✅ ดึงจาก user profile
    createdBy: user.id,               // ✅ customer ID
    createdByType: "customer_self",   // ✅ ลูกค้าแจ้งเอง
    createdByStaffName: null,         // ✅ ไม่มี staff
    channel: "web",                   // ✅ แจ้งผ่าน web
    note: "ลูกค้าเปิดเคสผ่านระบบด้วยตัวเอง"
  };
}

// 🟠 Case 2: Staff Creates Ticket On-Behalf
if (user.role === 'staff') {
  ticket = {
    customerName: formData.customerName,    // ✅ กรอกจาก form
    customerEmail: formData.customerEmail,  // ✅ กรอกจาก form
    customerPhone: formData.customerPhone,  // ✅ กรอกจาก form
    customerDepartment: formData.customerDepartment, // ✅ กรอกจาก form
    createdBy: user.id,                     // ✅ staff ID
    createdByType: "staff_on_behalf",       // ✅ staff บันทึกแทน
    createdByStaffName: user.name,          // ✅ "สมชาย ใจดี"
    channel: formData.channel,              // ✅ "phone", "email", "line"
    note: `เจ้าหน้าที่ ${user.name} บันทึกเคสแทนลูกค้า`
  };
}
```

---

## 📝 UI Display Logic

### **ในหน้า Ticket Detail:**

#### **แสดงผู้สร้างเคส:**
```typescript
function getTicketCreatorDisplay(ticket: Ticket): string {
  if (ticket.createdByType === "customer_self") {
    return `${ticket.customerName} (แจ้งเคสเอง)`;
  } else if (ticket.createdByType === "staff_on_behalf") {
    return `${ticket.customerName} (บันทึกโดย: ${ticket.createdByStaffName})`;
  }
  return ticket.customerName;
}
```

**Example Output:**
```
✅ Customer Self:
   "สมชาย ใจดี (แจ้งเคสเอง)"

✅ Staff On-Behalf:
   "วิภา ศรีสุข (บันทึกโดย: สมชาย ใจดี)"
```

---

## 🎨 UI Comparison

### **Customer View:**
```
┌────────────────────────────────────────┐
│ หน้าแจ้งเคสใหม่                        │
├────────────────────────────────────────┤
│                                        │
│ ┌────────────────────────────────────┐ │
│ │ 📋 ข้อมูลผู้แจ้ง     [แก้ไข]     │ │
│ ├────────────────────────────────────┤ │
│ │ 👤 สมชาย ใจดี                     │ │
│ │ 📧 somchai@example.com            │ │
│ │ 📞 +66-81-234-5678                │ │
│ │ 🏢 ฝ่ายจัดซื้อ                    │ │
│ ├────────────────────────────────────┤ │
│ │ 🟢 ข้อมูลดึงจากโปรไฟล์ของคุณ     │ │
│ └────────────────────────────────────┘ │
│                                        │
│ [รายละเอียดปัญหา...]                  │
│                                        │
└────────────────────────────────────────┘

✨ ข้อดี:
- ไม่ต้องกรอกข้อมูลซ้ำ
- ประหยัดเวลา
- UX ที่ดี
```

### **Staff View:**
```
┌────────────────────────────────────────┐
│ แจ้งเคสใหม่โดยเจ้าหน้าที่ชื่อ สมชาย ใจดี│
├────────────────────────────────────────┤
│                                        │
│ 📋 ข้อมูลลูกค้า                        │
│                                        │
│ ชื่อ-นามสกุลลูกค้า *                    │
│ ┌────────────────────────────────┐     │
│ │ [กรอกชื่อลูกค้า]              │     │
│ └────────────────────────────────┘     │
│ 💡 กรอกชื่อลูกค้าที่ติดต่อเข้ามา       │
│                                        │
│ อีเมลลูกค้า *                          │
│ ┌────────────────────────────────┐     │
│ │ [กรอกอีเมลลูกค้า]             │     │
│ └────────────────────────────────┘     │
│                                        │
│ เบอร์โทรศัพท์ลูกค้า *                  │
│ ┌────────────────────────────────┐     │
│ │ [กรอกเบอร์ลูกค้า]             │     │
│ └────────────────────────────────┘     │
│                                        │
│ หน่วยงาน/สังกัดลูกค้า *                │
│ ┌────────────────────────────────┐     │
│ │ [กรอกหน่วยงานลูกค้า]          │     │
│ └────────────────────────────────┘     │
│                                        │
│ ช่องทางการติดต่อ *                     │
│ ┌────────────────────────────────┐     │
│ │ [Line / Phone / Email]        │     │
│ └────────────────────────────────┘     │
│ ❌ "Web" จะไม่แสดง (เพราะลูกค้าไม่ได้ทำเอง) │
│                                        │
│ [รายละเอียดปัญหา...]                  │
│                                        │
└────────────────────────────────────────┘

✅ ความถูกต้อง:
- กรอกข้อมูล**ลูกค้า** (ไม่ใช่ staff)
- เลือกช่องทางที่ลูกค้าติดต่อเข้ามา
- บันทึกว่า staff ใครเป็นคนบันทึก
```

---

## 🧪 Test Cases

### **Test 1: Customer Creates Ticket**
```
✅ Pre-condition:
   - Login as: customer1 / customer1123
   
✅ Steps:
   1. Go to "แจ้งเคสใหม่"
   2. Verify: เห็น Customer Info Card (auto-filled)
   3. Fill in issue details
   4. Submit
   
✅ Expected Result:
   - Ticket created with:
     * createdBy = "test-001"
     * createdByType = "customer_self"
     * channel = "web"
     * note = "ลูกค้าเปิดเคสผ่านระบบด้วยตัวเอง"
```

### **Test 2: Staff Creates Ticket On-Behalf**
```
✅ Pre-condition:
   - Login as: staff / staff123
   
✅ Steps:
   1. Go to "แจ้งเคสใหม่โดยเจ้าหน้าที่"
   2. Verify: เห็น Input Fields (NOT Card)
   3. Fill in customer info:
      - Name: "วิภา ศรีสุข"
      - Email: "vipa@example.com"
      - Phone: "+66-82-111-2222"
      - Department: "ฝ่ายการเงิน"
   4. Select channel: "phone"
   5. Fill in issue details
   6. Submit
   
✅ Expected Result:
   - Ticket created with:
     * customerName = "วิภา ศรีสุข"
     * createdBy = "staff-001"
     * createdByType = "staff_on_behalf"
     * createdByStaffName = "สมชาย ใจดี"
     * channel = "phone"
     * note = "เจ้าหน้าที่ สมชาย ใจดี บันทึกเคสแทนลูกค้า"
```

---

## 📁 Implementation Status

| Component | Status | Notes |
|-----------|--------|-------|
| `CreateTicketPage.tsx` | ✅ แก้ไขแล้ว | เพิ่มเงื่อนไข: Customer → Card, Staff → Input |
| `CustomerInfoCard.tsx` | ✅ สร้างแล้ว | Component สำหรับ customer เท่านั้น |
| Database Schema | ⏳ รอทำ | ต้องเพิ่มฟิลด์ `createdByType`, `createdByStaffName` |
| API Endpoint | ⏳ รอทำ | `/api/tickets/create` ต้องรองรับ logic นี้ |
| Timeline Display | ⏳ รอทำ | แสดงว่า "บันทึกโดย staff" ใน timeline |

---

## 🚀 Next Steps

### **ควรทำต่อ:**
```
1. ✅ เพิ่มฟิลด์ใน Ticket Type:
   - createdByType: "customer_self" | "staff_on_behalf"
   - createdByStaffName?: string
   
2. ✅ แก้ไข handleSubmit() ใน CreateTicketPage:
   - ตรวจสอบ user.role
   - บันทึก createdByType ให้ถูกต้อง
   
3. ✅ อัพเดต Timeline Event:
   - แสดง "บันทึกโดย: [staff name]"
   
4. ✅ อัพเดต Ticket Detail Page:
   - แสดงผู้สร้างเคสให้ชัดเจน
```

---

## ✅ สรุป

### **สิ่งที่แก้ไขแล้ว:**
- ✅ **Customer:** ใช้ Customer Info Card (Auto-filled)
- ✅ **Staff:** ใช้ Input Fields (กรอกข้อมูลลูกค้า)
- ✅ **Logic:** แยก UI ตาม role อย่างชัดเจน

### **Logic ที่ต้องเพิ่ม:**
- ⏳ บันทึก `createdByType` ลง Database
- ⏳ แสดงผู้สร้างเคสใน Ticket Detail
- ⏳ เพิ่ม Timeline Event สำหรับ staff_on_behalf

---

**สรุป:** แก้ไขเสร็จแล้ว! Customer ใช้ Card, Staff ใช้ Input Fields ✅

**Updated:** 14 มกราคม 2026, 15:30 น.
