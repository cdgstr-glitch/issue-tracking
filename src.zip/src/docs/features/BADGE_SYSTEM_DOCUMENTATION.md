# 📛 CDGS Badge System Documentation

เอกสารนี้อธิบายระบบ Badge ทั้งหมดที่ใช้ในแพลตฟอร์ม CDGS Issue Tracking Platform

---

## 📋 สารบัญ

1. [AssignedBadge](#assignedbadge) 📄 - แสดงคนที่ถูกมอบหมาย
2. [ViewerBadge](#viewerbadge) 👁️ - แสดงคนที่กำลังดูเคส
3. [StatusBadge](#statusbadge) - แสดงสถานะเคส
4. [PriorityBadge](#prioritybadge) - แสดงลำดับความสำคัญ
5. [ChannelBadge](#channelbadge) - แสดงช่องทางการติดต่อ
6. [SLAIndicator](#slaindicator) - แสดงสถานะ SLA

---

## 1. AssignedBadge 📄

### ความหมาย
> **"เคสนี้ถูกมอบหมายให้ [ชื่อ] แล้ว"**

Badge นี้แสดงว่าเคสถูกมอบหมายให้บุคคลใดแล้ว ไม่ว่าเขาจะรับเคสหรือยังไม่รับก็ตาม

### 🎨 ลักษณะ
- **Icon**: 📄 FileText (lucide-react)
- **สี**: สีน้ำเงิน (Blue)
  - Background: `bg-blue-100`
  - Text: `text-blue-700`
- **ตำแหน่ง**: ด้านขวาของหัวเรื่อง (เหนือ ViewerBadge)

### 📊 Data Source
```typescript
ticket.assignedTo  // User ID ของคนที่ถูกมอบหมาย
```

### ✅ เงื่อนไขการแสดง
```typescript
// แสดงเมื่อ:
1. มี assignedTo (ถูกมอบหมายแล้ว)
2. assignedTo !== currentUser.id (ไม่แสดงตัวเอง)

// Logic:
if (ticket.assignedTo && ticket.assignedTo !== user?.id) {
  const assignee = getUserById(ticket.assignedTo);
  return <AssignedBadge assigneeName={assignee.name} assigneeRole={assignee.role} />;
}
```

### 🎯 Use Cases

#### Case 1: เคสถูก Assign แล้วแต่ยังไม่รับ
```
Status: tier1, tier2, tier3, new
assignedTo: "user-123"
→ แสดง: 📄 ประกาศิต ประคองเพ็ชร (เทียร์ 3)
```

#### Case 2: เคสรับแล้วแต่หยุดชั่วคราว
```
Status: waiting
assignedTo: "user-123"
→ แสดง: 📄 ประกาศิต ประคองเพ็ชร (เทียร์ 3)
```

#### Case 3: เคสกำลังดำเนินการ
```
Status: in_progress
assignedTo: "user-123"
→ แสดง: 📄 ประกาศิต ประคองเพ็ชร (เทียร์ 3)
```

#### Case 4: เคสปิดแล้ว
```
Status: closed, resolved
assignedTo: "user-123"
→ แสดง: 📄 ประกาศิต ประคองเพ็ชร (เทียร์ 3)
```

### 🔧 Component Props
```typescript
interface AssignedBadgeProps {
  assigneeName: string;     // ชื่อคนที่ถูกมอบหมาย
  assigneeRole?: string;    // บทบาท (tier1, tier2, tier3)
  size?: 'sm' | 'md';       // ขนาด (default: 'sm')
}
```

### 📍 ไฟล์ที่เกี่ยวข้อง
- Component: `/components/AssignedBadge.tsx`
- ใช้งานใน: `/components/TicketListPage.tsx`

---

## 2. ViewerBadge 👁️

### ความหมาย
> **"[ชื่อ] กำลังดูเคสนี้อยู่"**

Badge นี้แสดงว่ามีคนกำลังเปิดดูเคสนี้อยู่ในขณะนี้ (Real-time)

### 🎨 ลักษณะ
- **Icon**: 👁️ Eye (lucide-react)
- **สี**: สีม่วง (Purple)
  - Background: `bg-purple-100`
  - Text: `text-purple-700`
- **ตำแหน่ง**: ด้านขวาของหัวเรื่อง (ใต้ AssignedBadge)

### 📊 Data Source
```typescript
ticket.currentViewers[]  // Array ของคนที่กำลังดูเคส
```

### ✅ เงื่อนไขการแสดง
```typescript
// แสดงเมื่อ:
1. มี currentViewers และมีคนดูอยู่
2. viewer.userId !== currentUser.id (ไม่แสดงตัวเอง)

// Logic:
if (ticket.currentViewers && ticket.currentViewers.length > 0) {
  ticket.currentViewers
    .filter(viewer => viewer.userId !== user?.id)
    .map(viewer => (
      <ViewerBadge viewerName={viewer.name} viewerRole={viewer.role} />
    ))
}
```

### 🎯 Use Cases

#### Case 1: มี 1 คนกำลังดู
```
currentViewers: [{ userId: "user-456", name: "สาริน ช่อพะยอม", role: "tier1" }]
→ แสดง: 👁️ สาริน ช่อพะยอม (เทียร์ 1)
```

#### Case 2: มีหลายคนกำลังดู
```
currentViewers: [
  { userId: "user-456", name: "สาริน ช่อพะยอม", role: "tier1" },
  { userId: "user-789", name: "ยุทธนา ยุทธการ", role: "tier2" }
]
→ แสดง: 
  👁️ สาริน ช่อพะยอม (เทียร์ 1)
  👁️ ยุทธนา ยุทธการ (เทียร์ 2)
```

#### Case 3: ตัวเองกำลังดูอยู่
```
currentViewers: [{ userId: "current-user", name: "ประวิช", role: "tier2" }]
→ ไม่แสดง (ไม่แสดงตัวเอง)
```

### 🔧 Component Props
```typescript
interface ViewerBadgeProps {
  viewerName: string;       // ชื่อคนที่กำลังดู
  viewerRole?: string;      // บทบาท (tier1, tier2, tier3)
  size?: 'sm' | 'md';       // ขนาด (default: 'sm')
}
```

### 📍 ไฟล์ที่เกี่ยวข้อง
- Component: `/components/ViewerBadge.tsx`
- ใช้งานใน: `/components/TicketListPage.tsx`, `/components/TicketDetailPage.tsx`
- เอกสารเพิ่มเติม: `/VIEWER_BADGE_EXPLANATION.md`

---

## 📊 เปรียบเทียบ AssignedBadge vs ViewerBadge

| Feature | **AssignedBadge** 📄 | **ViewerBadge** 👁️ |
|---------|---------------------|-------------------|
| **ความหมาย** | **ถูกมอบหมายให้** | **กำลังดูอยู่** |
| **Icon** | FileText 📄 | Eye 👁️ |
| **สี** | น้ำเงิน (Blue) | ม่วง (Purple) |
| **Data** | `ticket.assignedTo` | `ticket.currentViewers[]` |
| **จำนวน** | 1 คน (เดี่ยว) | หลายคน (Array) |
| **Real-time** | ❌ ไม่ใช่ | ✅ ใช่ |
| **เงื่อนไข** | มี assignedTo | มีคนเปิดดูเคส |
| **แสดงเมื่อไหร่** | ตลอด (จนกว่าเคสจะจบ) | เมื่อมีคนเปิดดู |
| **แสดงตัวเอง** | ❌ ไม่แสดง | ❌ ไม่แสดง |

---

## 📐 ตำแหน่งการแสดงผล

### Desktop Table View
```
┌──────────────────────────────────────────────────────────┐
│ หัวเรื่อง: Server Memory Leak กำลังทำให้ระบบช้า         │
│                                                          │
│ 📄 ประกาศิต ประคองเพ็ชร (เทียร์ 3)  ← AssignedBadge  │
│ 👁️ สาริน ช่อพะยอม (เทียร์ 1)       ← ViewerBadge    │
└──────────────────────────────────────────────────────────┘
```

### Scenario ตัวอย่าง

**ผู้ใช้งาน: ประวิช (Tier 2)**

เข้าไปดูเคส CDGS-2024-001 และเห็น:
- 📄 **ประกาศิต ประคองเพ็ชร (เทียร์ 3)** → เคสนี้มอบหมายให้ ประกาศิต แล้ว
- 👁️ **สาริน ช่อพะยอม (เทียร์ 1)** → สาริน กำลังเข้าไปดูเคสนี้อยู่

**ความหมาย:**
- เคสนี้ **ถูก assign ให้ Tier 3 (ประกาศิต)** แล้ว แต่เขายังไม่ได้กดรับเคส
- **Tier 1 (สาริน)** กำลังเข้าไปดูเคสนี้อยู่ (อาจจะตรวจสอบหรือติดตาม)
- **ประวิช (Tier 2)** สามารถเข้าไปดูได้เช่นกัน (Read-only mode)

---

## 3. StatusBadge

### ความหมาย
แสดงสถานะปัจจุบันของเคส

### 🎨 สีและสถานะ

| Status | สี | ความหมาย |
|--------|-----|----------|
| `new` | เทา (Gray) | เคสใหม่ |
| `tier1` | น้ำเงิน (Blue) | รอ Tier 1 รับเคส |
| `tier2` | ม่วง (Purple) | รอ Tier 2 รับเคส |
| `tier3` | ชมพู (Pink) | รอ Tier 3 รับเคส |
| `in_progress` | เหลือง (Amber) | กำลังดำเนินการ |
| `waiting` | ส้ม (Orange) | หยุดชั่วคราว |
| `resolved` | เขียว (Green) | แก้ไขแล้ว |
| `closed` | เขียวเข้ม (Dark Green) | ปิดแล้ว |

### 📍 ไฟล์ที่เกี่ยวข้อง
- Component: `/components/StatusBadge.tsx`

---

## 4. PriorityBadge

### ความหมาย
แสดงลำดับความสำคัญของเคส

### 🎨 สีและระดับ

| Priority | สี | Icon | ความหมาย |
|----------|-----|------|----------|
| `critical` | แดง (Red) | 🔴 | วิกฤต |
| `high` | ส้ม (Orange) | 🟠 | สูง |
| `medium` | เหลือง (Yellow) | 🟡 | ปานกลาง |
| `low` | เทา (Gray) | ⚪ | น้อย |

### 📍 ไฟล์ที่เกี่ยวข้อง
- Component: `/components/PriorityBadge.tsx`

---

## 5. ChannelBadge

### ความหมาย
แสดงช่องทางที่ลูกค้าติดต่อมา

### 🎨 ช่องทางและ Icon

| Channel | Icon | ความหมาย |
|---------|------|----------|
| `email` | 📧 Mail | อีเมล |
| `line` | 💬 MessageSquare | LINE |
| `phone` | 📞 Phone | โทรศัพท์ |
| `website` | 🌐 Globe | เว็บไซต์ |

### 📍 ไฟล์ที่เกี่ยวข้อง
- Component: `/components/ChannelBadge.tsx`

---

## 6. SLAIndicator

### ความหมาย
แสดงสถานะ SLA (Service Level Agreement) ว่าเคสใกล้ครบกำหนดหรือเกินกำหนดหรือไม่

### 🎨 สีและสถานะ

| สถานะ | สี | Icon | ความหมาย |
|-------|-----|------|----------|
| ปกติ | เขียว (Green) | ✅ CheckCircle | เหลือเวลามาก |
| ใกล้ครบ | เหลือง (Yellow) | ⚠️ Clock | เหลือเวลา < 25% |
| เกินกำหนด | แดง (Red) | ❌ AlertTriangle | เกินกำหนดแล้ว |

### 📊 Logic การคำนวณ
```typescript
const now = new Date();
const created = new Date(createdAt);
const due = new Date(dueDate);
const totalTime = due.getTime() - created.getTime();
const elapsed = now.getTime() - created.getTime();
const remaining = due.getTime() - now.getTime();

// เกินกำหนด
if (remaining < 0) {
  return 'overdue';
}

// ใกล้ครบกำหนด (เหลือเวลา < 25%)
const percentRemaining = (remaining / totalTime) * 100;
if (percentRemaining < 25) {
  return 'warning';
}

// ปกติ
return 'ok';
```

### 📍 ไฟล์ที่เกี่ยวข้อง
- Component: `/components/SLAIndicator.tsx`

---

## 🎯 Best Practices

### 1. การแสดง Badge พร้อมกัน
```tsx
<div className="flex items-center gap-1.5 flex-wrap">
  {/* AssignedBadge ก่อน */}
  {ticket.assignedTo && <AssignedBadge ... />}
  
  {/* ViewerBadge ทีหลัง */}
  {ticket.currentViewers?.map(viewer => (
    <ViewerBadge ... />
  ))}
</div>
```

### 2. ไม่แสดงตัวเอง
```typescript
// ❌ ผิด - แสดงตัวเอง
<AssignedBadge assigneeName={assignee.name} />

// ✅ ถูก - เช็คก่อนแสดง
{ticket.assignedTo !== user?.id && (
  <AssignedBadge assigneeName={assignee.name} />
)}
```

### 3. การจัดการ Null/Undefined
```typescript
// ✅ ถูก - ตรวจสอบก่อน
{ticket.assignedTo && (() => {
  const assignee = getUserById(ticket.assignedTo);
  return assignee ? <AssignedBadge ... /> : null;
})()}
```

### 4. Responsive Design
```typescript
// Desktop - แสดงข้างหัวเรื่อง
<div className="hidden md:flex items-center gap-1.5">
  <AssignedBadge size="sm" />
  <ViewerBadge size="sm" />
</div>

// Mobile - แสดงแยกบรรทัด
<div className="flex md:hidden flex-col gap-2">
  <AssignedBadge size="md" />
  <ViewerBadge size="md" />
</div>
```

---

## 📝 สรุป

CDGS Badge System มี 6 ประเภทหลัก:

1. **AssignedBadge** 📄 - บอกว่าเคสถูก assign ให้ใคร
2. **ViewerBadge** 👁️ - บอกว่าใครกำลังดูเคสอยู่
3. **StatusBadge** - บอกสถานะเคส
4. **PriorityBadge** - บอกความสำคัญ
5. **ChannelBadge** - บอกช่องทางติดต่อ
6. **SLAIndicator** - บอกสถานะ SLA

**Badge ที่มี Awareness (รับรู้บริบท):**
- ✅ AssignedBadge - ไม่แสดงตัวเอง
- ✅ ViewerBadge - ไม่แสดงตัวเอง, Real-time
- ❌ StatusBadge - แสดงเสมอ
- ❌ PriorityBadge - แสดงเสมอ
- ❌ ChannelBadge - แสดงเสมอ
- ✅ SLAIndicator - คำนวณตามเวลา

---

**เอกสารนี้สร้างเมื่อ:** 15 มกราคม 2026  
**เวอร์ชัน:** 1.0  
**ผู้จัดทำ:** CDGS Development Team
