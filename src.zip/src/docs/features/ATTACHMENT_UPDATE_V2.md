# 📎 Attachment Feature - Update V2

> **อัปเดตเพิ่มรูปตัวอย่าง Error Screens ชุดที่ 2**  
> วันที่: 15 มกราคม 2026  
> สถานะ: ✅ เสร็จสมบูรณ์

---

## 🎯 รายการอัปเดต

เพิ่มรูปตัวอย่าง **Error Screens** อีก 3 รูป เข้าไปในระบบ:

### **รูปภาพใหม่ที่เพิ่ม:**

1. **LINE Error (Green Screen)** 🟢  
   - Asset: `figma:asset/61be7cf584b8e09bf5bed7a2ba18bd45fe2b17b8.png`
   - ชื่อไฟล์: `line-error-green-screen.png`
   - ขนาด: ~380 KB
   - รายละเอียด: Error dialog จาก LINE app พื้นหลังสีเขียว แสดงข้อความ "Error Occurred - Something went wrong. Please try again later." พร้อมปุ่ม OK

2. **Error 404 - Desktop** 💻  
   - Asset: `figma:asset/a06aae9296b5a71bbe6f5cdb4d89894e237c784d.png`
   - ชื่อไฟล์: `error-404-page-not-found.png`
   - ขนาด: ~500 KB
   - รายละเอียด: หน้าจอ Desktop/Monitor แสดง "Error 404 - Page Not Found" พร้อมปุ่ม "Go to Homepage" และ "Try Again"

3. **Mobile Error Screen** 📱  
   - Asset: `figma:asset/2bfeae8f2733b36bddcde9d431b2458affbbf1b5.png`
   - ชื่อไฟล์: `mobile-error-occurred.png`
   - ขนาด: ~290 KB
   - รายละเอียด: หน้าจอมือถือแสดง "Error Occurred - Something went wrong! Please try again later." พร้อมปุ่ม "Retry" และ "Go to Home"

---

## 📦 ไฟล์ที่แก้ไข

### **1. `/lib/mockAttachments.ts`** ✅

#### **เพิ่ม Import:**
```typescript
// ✅ รูปภาพตัวอย่างเพิ่มเติม (ชุดที่สอง - Error screens)
import lineErrorGreen from 'figma:asset/61be7cf584b8e09bf5bed7a2ba18bd45fe2b17b8.png';
import error404Desktop from 'figma:asset/a06aae9296b5a71bbe6f5cdb4d89894e237c784d.png';
import errorMobile from 'figma:asset/2bfeae8f2733b36bddcde9d431b2458affbbf1b5.png';
```

#### **เพิ่ม Mock Data Arrays:**
```typescript
/**
 * ไฟล์แนบสำหรับเคส Error จาก LINE (ชุดใหม่)
 */
export const lineErrorAttachments: Attachment[] = [
  createAttachment(
    'att-009',
    'line-error-green-screen.png',
    'image',
    387654, // ~380 KB
    lineErrorGreen,
    'user-customer-005',
    new Date('2026-01-15T08:20:00')
  ),
];

/**
 * ไฟล์แนบสำหรับเคส Error 404 (Desktop)
 */
export const error404Attachments: Attachment[] = [
  createAttachment(
    'att-010',
    'error-404-page-not-found.png',
    'image',
    512345, // ~500 KB
    error404Desktop,
    'user-customer-006',
    new Date('2026-01-15T09:15:00')
  ),
];

/**
 * ไฟล์แนบสำหรับเคส Error จาก Mobile
 */
export const mobileErrorAttachments: Attachment[] = [
  createAttachment(
    'att-011',
    'mobile-error-occurred.png',
    'image',
    298765, // ~290 KB
    errorMobile,
    'user-customer-007',
    new Date('2026-01-15T10:30:00')
  ),
];
```

#### **อัปเดต getRandomAttachments():**
```typescript
export const getRandomAttachments = (count: number = 0): Attachment[] => {
  if (count === 0) return [];
  
  const allAttachments = [
    ...sarabanAttachments,
    ...systemDownAttachments,
    ...loginIssueAttachments,
    ...miscAttachments,
    ...lineErrorAttachments,      // ✅ เพิ่ม
    ...error404Attachments,        // ✅ เพิ่ม
    ...mobileErrorAttachments,     // ✅ เพิ่ม
  ];
  
  // สุ่มเลือก attachments
  const shuffled = [...allAttachments].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, allAttachments.length));
};
```

---

### **2. `/lib/mockData.ts`** ✅

#### **เพิ่ม Import:**
```typescript
import { 
  sarabanAttachments, 
  systemDownAttachments, 
  loginIssueAttachments, 
  lineErrorAttachments,      // ✅ เพิ่ม
  error404Attachments,        // ✅ เพิ่ม
  mobileErrorAttachments      // ✅ เพิ่ม
} from './mockAttachments';
```

#### **เพิ่มไฟล์แนบในเคสที่มีอยู่:**

| รหัสเคส | หัวเรื่อง | ไฟล์แนบใหม่ | จำนวน |
|---------|-----------|------------|-------|
| **s1** | ลูกค้าโทรแจ้งเครื่องพิมพ์เสีย | `lineErrorAttachments` | 1 ไฟล์ |
| **s2** | อีเมลแจ้งขอเปลี่ยน Domain Email | `error404Attachments` | 1 ไฟล์ |
| **s4** | อีเมลขอติดตั้งซอฟต์แวร์ Adobe | `mobileErrorAttachments` | 1 ไฟล์ |

**ตัวอย่างโค้ด:**
```typescript
{
  id: 's1',
  ticketNumber: 'CDGS-2024-S001',
  title: 'ลูกค้าโทรแจ้งเครื่องพิมพ์เสีย #ด่วน #ฮาร์ดแวร์',
  // ...
  attachments: lineErrorAttachments, // ✅ เพิ่มรูป LINE Error screen
},
{
  id: 's2',
  ticketNumber: 'CDGS-2024-S002',
  title: 'อีเมลแจ้งขอเปลี่ยน Domain Email #คำขอ #อีเมล',
  // ...
  attachments: error404Attachments, // ✅ เพิ่มรูป Error 404 Desktop
},
{
  id: 's4',
  ticketNumber: 'CDGS-2024-S004',
  title: 'อีเมลขอติดตั้งซอฟต์แวร์ Adobe #คำขอ #ซอฟต์แวร์ #ติดตั้ง',
  // ...
  attachments: mobileErrorAttachments, // ✅ เพิ่มรูป Mobile Error screen
}
```

---

## 📊 สรุปข้อมูลไฟล์แนบทั้งหมดในระบบ

### **ก่อนอัปเดต:**
- เคสที่มีไฟล์แนบ: **3 เคส** (s3, s6, s10)
- รูปภาพทั้งหมด: **3 รูป**
- ไฟล์รวม: **6 ไฟล์**

### **หลังอัปเดต:**
- เคสที่มีไฟล์แนบ: **6 เคส** (s1, s2, s3, s4, s6, s10)
- รูปภาพทั้งหมด: **6 รูป**
- ไฟล์รวม: **9 ไฟล์**

---

## 📋 ตารางเคสที่มีไฟล์แนบ (อัปเดตล่าสุด)

| # | รหัสเคส | หัวเรื่อง | จำนวนไฟล์ | ประเภทรูป |
|---|---------|-----------|-----------|-----------|
| 1 | **s1** | ลูกค้าโทรแจ้งเครื่องพิมพ์เสีย | 1 | LINE Error (Green) |
| 2 | **s2** | อีเมลแจ้งขอเปลี่ยน Domain | 1 | Error 404 Desktop |
| 3 | **s3** | Line แจ้งปัญหาเข้าระบบไม่ได้ | 2 | Login Error |
| 4 | **s4** | อีเมลขอติดตั้งซอฟต์แวร์ | 1 | Mobile Error |
| 5 | **s6** | Line แจ้งต้องการเปลี่ยนแพ็กเกจ | 3 | สารบรรณ (3 รูป) |
| 6 | **s10** | Line แจ้งขอเพิ่ม User Account | 1 | System Error |

---

## 🖼️ รายละเอียดรูปภาพทั้งหมด (6 รูป)

### **ชุดที่ 1 - ระบบสารบรรณและ LINE**
1. ✅ `error-upload-doc-false.png` - Error dialog จากระบบสารบรรณ
2. ✅ `วิธีแก้ไข-ตารางประเภทผลพัน.png` - LINE chat มีวงกลมสีแดง
3. ✅ `screenshot-ตารางประเภท.png` - Screenshot หน้าจอคอมพิวเตอร์

### **ชุดที่ 2 - Error Screens (ใหม่!)**
4. ✅ `line-error-green-screen.png` - LINE Error พื้นหลังสีเขียว
5. ✅ `error-404-page-not-found.png` - Error 404 Desktop
6. ✅ `mobile-error-occurred.png` - Mobile Error Screen

---

## 🎨 ตัวอย่างการแสดงผล

### **ตารางรายการเคส (อัปเดต):**
```
┌─────────┬──────────────────┬────────┬─────────┬─────┐
│ รหัสเคส │ หัวเรื่อง          │ สถานะ  │ ความสำคัญ│ 📎  │
├─────────┼──────────────────┼────────┼─────────┼─────┤
│ s1      │ เครื่องพิมพ์เสีย  │ tier1  │ high    │ 📎 1│ ← ใหม่!
│ s2      │ เปลี่ยน Domain    │ resolved│ medium │ 📎 1│ ← ใหม่!
│ s3      │ ปัญหาเข้าระบบ    │ tier3  │ critical│ 📎 2│
│ s4      │ ติดตั้งซอฟต์แวร์  │ resolved│ medium │ 📎 1│ ← ใหม่!
│ s6      │ เปลี่ยนแพ็กเกจ    │ tier1  │ medium  │ 📎 3│
│ s10     │ เพิ่ม User        │ tier1  │ medium  │ 📎 1│
└─────────┴──────────────────┴────────┴─────────┴─────┘
```

### **Gallery ในหน้ารายละเอียด:**
```
┌───────────────────────────────────┐
│ 📎 ไฟล์แนบ (1)                    │
├───────────────────────────────────┤
│ 🖼️ รูปภาพ (1)                    │
│ ┌─────────────────────┐          │
│ │                     │          │
│ │  LINE Error Green   │          │
│ │  (Error Occurred)   │  Click   │
│ │                     │  to Zoom │
│ └─────────────────────┘          │
│ line-error-green-screen.png      │
│ 380 KB                           │
└───────────────────────────────────┘
```

---

## ✨ ความแตกต่างระหว่างรูป Error ทั้ง 3 แบบ

| ประเภท | Platform | ขนาดหน้าจอ | สีพื้นหลัง | ปุ่ม |
|--------|----------|-----------|-----------|------|
| **LINE Error** | Mobile (LINE app) | Portrait | 🟢 เขียว | OK |
| **Error 404** | Desktop | Landscape | ⚪ ขาว | Go to Homepage, Try Again |
| **Mobile Error** | Mobile (Generic) | Portrait | ⚪ ขาว | Retry, Go to Home |

---

## 💡 Use Case ตามประเภทรูป

### **1. LINE Error (Green)** 🟢
- **ใช้สำหรับ:** เคสที่ลูกค้าแจ้งผ่าน LINE Official
- **ตัวอย่าง:** ลูกค้าส่งรูป screenshot error จากแอป LINE
- **เคส:** s1 - ลูกค้าโทรแจ้งเครื่องพิมพ์เสีย

### **2. Error 404 (Desktop)** 💻
- **ใช้สำหรับ:** เคสปัญหาเว็บไซต์/ระบบออนไลน์
- **ตัวอย่าง:** ลูกค้าเข้าเว็บไม่ได้ เจอหน้า 404
- **เคส:** s2 - อีเมลแจ้งขอเปลี่ยน Domain Email

### **3. Mobile Error** 📱
- **ใช้สำหรับ:** เคสปัญหาแอปมือถือทั่วไป
- **ตัวอย่าง:** แอปมือถือล่ม หรือมี error ทั่วไป
- **เคส:** s4 - อีเมลขอติดตั้งซอฟต์แวร์ Adobe

---

## 🔧 การใช้งานรูปใหม่

### **เพิ่มรูปในเคสใหม่:**
```typescript
// ใน /lib/mockData.ts
import { lineErrorAttachments, error404Attachments, mobileErrorAttachments } from './mockAttachments';

{
  id: 'new-case',
  title: 'เคสใหม่',
  // ...
  attachments: lineErrorAttachments, // เลือกรูปที่ต้องการ
}
```

### **สุ่มรูปจากทั้งหมด:**
```typescript
import { getRandomAttachments } from './mockAttachments';

{
  id: 'random-case',
  title: 'เคสสุ่ม',
  // ...
  attachments: getRandomAttachments(2), // สุ่ม 2 รูป
}
```

---

## 📈 สถิติ

### **ไฟล์แนบในระบบ:**
- **Mock Attachment Arrays:** 7 ชุด
- **รูปภาพทั้งหมด:** 6 รูป
- **ไฟล์เอกสาร (Mock):** 2 ไฟล์ (PDF, TXT)
- **เคสที่มีไฟล์แนบ:** 6 เคส
- **ไฟล์แนบรวม:** 9 ไฟล์

### **ขนาดไฟล์:**
| ไฟล์ | ขนาด | ประเภท |
|------|------|--------|
| error-upload-doc-false.png | 240 KB | Image |
| วิธีแก้ไข-ตารางประเภทผลพัน.png | 1.8 MB | Image |
| screenshot-ตารางประเภท.png | 1.2 MB | Image |
| line-error-green-screen.png | 380 KB | Image ✨ |
| error-404-page-not-found.png | 500 KB | Image ✨ |
| mobile-error-occurred.png | 290 KB | Image ✨ |
| คู่มือการใช้งาน.pdf | 2.3 MB | PDF |
| error-log.txt | 12 KB | Text |
| รายงานปัญหา.png | 988 KB | Image |

**รวม:** ~7.7 MB

---

## ✅ Checklist

- [x] เพิ่มรูป 3 รูปใหม่ใน mockAttachments.ts
- [x] สร้าง Mock Data arrays 3 ชุด
- [x] เพิ่ม import ใน mockData.ts
- [x] เพิ่มไฟล์แนบในเคส s1, s2, s4
- [x] อัปเดต getRandomAttachments()
- [x] ทดสอบการแสดงผลในตาราง
- [x] ทดสอบ Gallery ในหน้ารายละเอียด
- [x] ทดสอบ Lightbox
- [x] สร้างเอกสารสรุป

---

## 🎯 สรุป

### **ผลลัพธ์:**
- ✅ เพิ่มรูปตัวอย่าง **Error Screens** อีก 3 รูป
- ✅ เพิ่มเคสที่มีไฟล์แนบจาก **3 เคส** เป็น **6 เคส**
- ✅ รูปภาพในระบบเพิ่มจาก **3 รูป** เป็น **6 รูป**
- ✅ ครอบคลุม Error ทั้ง **Mobile, Desktop, และ LINE app**
- ✅ Mock Data หลากหลายขึ้น เหมาะสำหรับการทดสอบ

### **ความครอบคลุม:**
| ประเภท Error | จำนวนรูป | Platform |
|--------------|---------|----------|
| LINE Error | 2 | Mobile (LINE) |
| Desktop Error | 1 | Desktop/Web |
| Mobile Error | 1 | Mobile (Generic) |
| ระบบสารบรรณ | 2 | Desktop |
| **รวม** | **6** | **ครบทุกแพลตฟอร์ม** ✅ |

---

**สถานะ:** ✅ **เสร็จสมบูรณ์**  
**อัปเดตโดย:** CDGS Issue Tracking Development Team  
**วันที่:** 15 มกราคม 2026  
**เวอร์ชัน:** 2.0.0
