# 📊 สรุป: การมองเห็นเคส & เมนู Dashboard

**อัพเดทล่าสุด:** 14 มกราคม 2026  
**ระบบ:** CDGS Issue Tracking Platform

---

## 🔍 ส่วนที่ 1: Inverted Visibility Model (การมองเห็นเคสของแต่ละ Tier)

### 📌 **หลักการ: "Tier1 เห็นมากสุด → Tier3 เห็นน้อยสุด"**

ระบบใช้ **Inverted Visibility Model** ที่ทำให้:
- **Tier 1** เห็นเคส**มากที่สุด** (เคสทุกระดับ)
- **Tier 2** เห็น**เฉพาะเคสที่เกี่ยวข้อง** (Tier2 ขึ้นไป)
- **Tier 3** เห็น**น้อยที่สุด** (เฉพาะ Tier3)

---

### 🎯 **Tier 1 - เห็นเคสมากสุด**

```
Tier 1 เห็นสถานะ:
✅ new           - เคสใหม่จากลูกค้า/Staff (รอ T1 รับ)
✅ tier1         - เคสที่ T2/T3 ส่งกลับมา (รอ T1 รับ)
✅ tier2         - เคสที่ส่งไป T2 แล้ว (ดูได้แต่ไม่ต้องจัดการ)
✅ tier3         - เคสที่ส่งไป T3 แล้ว (ดูได้แต่ไม่ต้องจัดการ)
✅ in_progress   - เคสกำลังดำเนินการ (ทุก Tier)
✅ waiting       - เคสหยุดชั่วคราว (ทุก Tier)
✅ pending_closure - เคสที่ T2/T3 ส่งกลับมาให้ปิด (T1 ต้องปิดเอง)
✅ resolved      - เคสแก้ไขแล้ว (รอปิด)
✅ closed        - เคสปิดแล้ว (ดูย้อนหลังได้)
```

**เหตุผล:**
- T1 เป็นจุดเริ่มต้นและจุดสิ้นสุดของทุกเคส
- ต้องเห็นภาพรวมว่าเคสไหนอยู่ที่ไหน
- รับผิดชอบปิดเคสทุกเคส (รวม T2/T3 ส่งกลับมา)

---

### 🎯 **Tier 2 - เห็นเฉพาะที่เกี่ยวข้อง**

```
Tier 2 เห็นสถานะ:
❌ new           - ไม่เห็น (T1 จัดการ)
❌ tier1         - ไม่เห็น (T1 จัดการ)
✅ tier2         - เคสที่ส่งมาให้ T2 (รอรับ/กำลังทำ)
✅ tier3         - เคสที่ส่งไป T3 แล้ว (ดูได้)
✅ in_progress   - เคสกำลังดำเนินการ (ของ T2/T3)
✅ waiting       - เคสหยุดชั่วคราว (ของ T2/T3)
✅ pending_closure - เคสที่ T2/T3 ส่งกลับ T1 (ดูได้)
✅ resolved      - เคสแก้ไขแล้ว (ของ T2/T3)
✅ closed        - เคสปิดแล้ว (ของ T2/T3 ที่เคยจัดการ)
```

**เหตุผล:**
- T2 ไม่ต้องเห็นเคสที่ T1 จัดการ (ลดภาระ)
- เห็นเฉพาะเคสที่เกี่ยวข้องกับตัวเอง
- เห็นเคสที่ส่งไป T3 เพื่อ track

---

### 🎯 **Tier 3 - เห็นน้อยสุด**

```
Tier 3 เห็นสถานะ:
❌ new           - ไม่เห็น (T1 จัดการ)
❌ tier1         - ไม่เห็น (T1 จัดการ)
❌ tier2         - ไม่เห็น (T2 จัดการ)
✅ tier3         - เคสที่ส่งมาให้ T3 (รอรับ/กำลังทำ)
✅ in_progress   - เคสกำลังดำเนินการ (ของ T3 เท่านั้น)
✅ waiting       - เคสหยุดชั่วคราว (ของ T3 เท่านั้น)
✅ pending_closure - เคสที่ T3 ส่งกลับ T1 (ดูได้)
✅ resolved      - เคสแก้ไขแล้ว (ของ T3 เท่านั้น)
✅ closed        - เคสปิดแล้ว (ของ T3 ที่เคยจัดการ)
```

**เหตุผล:**
- T3 เป็นทีมผู้เชี่ยวชาญเฉพาะด้าน
- เห็นเฉพาะเคสที่ยากมาก ๆ
- ไม่ต้องเห็นเคสที่ T1/T2 จัดการได้เอง

---

### 🎯 **Admin - Monitor All**

```
Admin เห็นสถานะ:
✅ new           - ทุกเคส
✅ tier1         - ทุกเคส
✅ tier2         - ทุกเคส
✅ tier3         - ทุกเคส
✅ in_progress   - ทุกเคส
✅ waiting       - ทุกเคส
✅ pending_closure - ทุกเคส
✅ resolved      - ทุกเคส
✅ closed        - ทุกเคส
```

**เหตุผล:**
- Admin ดูแลระบบทั้งหมด
- ต้องเห็นภาพรวมทุกอย่าง

**หมายเหตุ:**
- **Pure Admin** (ไม่มี tier role) = Monitor Only (ดูได้, ทำอะไรไม่ได้)
- **Admin + Tier1/2/3** = ทำงานเหมือน Tier นั้น ๆ ทุกอย่าง

---

### 🎯 **Staff - บันทึกเคสเท่านั้น**

```
Staff เห็นสถานะ:
✅ new           - เคสที่ตัวเองบันทึก (ที่ยังไม่มี Tier รับ)
✅ tier1/2/3     - เคสที่ตัวเองบันทึก (ดู status ได้)
✅ in_progress   - เคสที่ตัวเองบันทึก (กำลังดำเนินการ)
✅ waiting       - เคสที่ตัวเองบันทึก (หยุดชั่วคราว)
✅ pending_closure - เคสที่ตัวเองบันทึก (รอปิด)
✅ resolved      - เคสที่ตัวเองบันทึก (แก้ไขแล้ว)
✅ closed        - เคสที่ตัวเองบันทึกและปิด (ปิดแล้ว)
```

**เหตุผล:**
- Staff บันทึกเคสแทนลูกค้า
- เห็นเฉพาะเคสที่ตัวเองบันทึก
- สามารถปิดเคสเล็ก ๆ ได้เอง (แบบ backlog)

---

### 🎯 **Customer - เห็นเฉพาะของตัวเอง**

```
Customer เห็นสถานะ:
✅ new           - เคสของตัวเอง (เพิ่งสร้าง)
✅ tier1/2/3     - เคสของตัวเอง (แสดงเป็น "กำลังดำเนินการ")
✅ in_progress   - เคสของตัวเอง (กำลังดำเนินการ)
✅ waiting       - เคสของตัวเอง (รอข้อมูลเพิ่มเติม)
✅ pending_closure - เคสของตัวเอง (แสดงเป็น "แก้ไขเรียบร้อย" 🟢)
✅ resolved      - เคสของตัวเอง (แสดงเป็น "แก้ไขเรียบร้อย" 🟢)
✅ closed        - เคสของตัวเอง (ปิดเคสแล้ว)
```

**เหตุผล:**
- ลูกค้าเห็นเฉพาะเคสของตัวเอง
- ไม่เห็นคำศัพท์ "Tier" (ดูเป็นมิตร)

---

## 📊 ส่วนที่ 2: เมนู Dashboard และสถานะเคสในแต่ละเมนู

---

## 👨‍💼 **Tier 1 Dashboard**

### เมนู 1: **"รับเคส"** (Accept Queue)
**Path:** `/admin/tickets?view=accept`

```typescript
สถานะที่แสดง:
✅ new           - เคสใหม่ (ยังไม่มีคนรับ)
✅ tier1         - เคสส่งกลับจาก T2/T3 (assigned แต่ยังไม่รับ)

เงื่อนไข:
- status IN ['new', 'tier1']
- assignedTo = null (กรณี new) หรือ assignedTo = currentUserId && ยังไม่รับ
```

**Action:**
- ✅ กดปุ่ม "รับเคส"
- → status เปลี่ยนเป็น `in_progress`

---

### เมนู 2: **"กำลังดำเนินการ"** (In Progress)
**Path:** `/admin/tickets?view=in-progress`

```typescript
สถานะที่แสดง:
✅ in_progress   - เคสกำลังทำ

เงื่อนไข:
- status = 'in_progress'
- assignedTo = currentUserId (เฉพาะงานของตัวเอง)
```

**Action:**
- ✅ ส่งต่อ (Escalate)
- ✅ ปิดเคส (Close)
- ✅ หยุดชั่วคราว (Pause → waiting)

---

### เมนู 3: **"รอดำเนินการ"** (Waiting)
**Path:** `/admin/tickets?view=waiting`

```typescript
สถานะที่แสดง:
✅ waiting       - เคสหยุดชั่วคราว (รอข้อมูลเพิ่มเติมจากลูกค้า)

เงื่อนไข:
- status = 'waiting'
- assignedTo = currentUserId
```

**Action:**
- ✅ กลับมาทำต่อ (Resume → in_progress)
- ✅ ส่งต่อ
- ✅ ปิดเคส

---

### เมนู 4: **"แก้ไขแล้ว"** 🟢 (Resolved/Pending Closure)
**Path:** `/admin/tickets?view=resolved`

```typescript
สถานะที่แสดง:
✅ resolved          - เคสแก้ไขแล้ว (T1 แก้เอง)
✅ pending_closure   - เคส T2/T3 ส่งกลับมาให้ปิด

เงื่อนไข:
- status IN ['resolved', 'pending_closure']
- (Tier1 เห็นทั้ง T1/T2/T3 ที่มี status นี้)
```

**Action:**
- ✅ ปิดเคส (Close) - **เฉพาะ T1 เท่านั้น**

**Notification:**
- 🟢 Badge สีเขียว
- แสดงจำนวนเคสที่รอปิด

---

### เมนู 5: **"ปิดแล้ว"** (Closed)
**Path:** `/admin/tickets?view=closed`

```typescript
สถานะที่แสดง:
✅ closed        - เคสปิดแล้ว

เงื่อนไข:
- status = 'closed'
- closedAt ย้อนหลัง 30 วัน (ปรับได้)
```

**Action:**
- ❌ ดูได้อย่างเดียว (Read-only)

---

### เมนู 6: **"ทั้งหมด"** (All Tickets)
**Path:** `/admin/tickets?view=all`

```typescript
สถานะที่แสดง:
✅ new
✅ tier1
✅ tier2         - ดูได้ (แต่ไม่ต้องจัดการ)
✅ tier3         - ดูได้ (แต่ไม่ต้องจัดการ)
✅ in_progress
✅ waiting
✅ pending_closure
✅ resolved
✅ closed

เงื่อนไข:
- ทุกสถานะ
- Tier1 เห็นเคสทุกระดับ (Inverted Visibility)
```

---

## 👨‍💼 **Tier 2 Dashboard**

### เมนู 1: **"รับเคส"** (Accept Queue)
**Path:** `/admin/tickets?view=accept`

```typescript
สถานะที่แสดง:
✅ tier2         - เคสที่ T1 ส่งมา (assigned แต่ยังไม่รับ)

เงื่อนไข:
- status = 'tier2'
- assignedTo = currentUserId
- ยังไม่ได้กด "รับเคส"
```

**Action:**
- ✅ กดปุ่ม "รับเคส"
- → status เปลี่ยนเป็น `in_progress`

---

### เมนู 2: **"กำลังดำเนินการ"** (In Progress)
**Path:** `/admin/tickets?view=in-progress`

```typescript
สถานะที่แสดง:
✅ in_progress   - เคสกำลังทำ (T2)

เงื่อนไข:
- status = 'in_progress'
- assignedTo = currentUserId
- เคสต้องมาจาก tier2 (ไม่เห็นของ T1/T3)
```

**Action:**
- ✅ ส่งต่อ T3 (Escalate)
- ✅ ส่งกลับ T1 เพื่อปิด (Return for Closure → pending_closure)
- ✅ หยุดชั่วคราว (Pause → waiting)
- ❌ ปิดเคสเอง (ไม่ได้) - ต้องส่งกลับ T1

---

### เมนู 3: **"รอดำเนินการ"** (Waiting)
**Path:** `/admin/tickets?view=waiting`

```typescript
สถานะที่แสดง:
✅ waiting       - เคสหยุดชั่วคราว (T2)

เงื่อนไข:
- status = 'waiting'
- assignedTo = currentUserId
```

---

### เมนู 4: **"แก้ไขแล้ว"** 🟢 (Resolved)
**Path:** `/admin/tickets?view=resolved`

```typescript
สถานะที่แสดง:
✅ resolved          - เคสแก้ไขแล้ว (T2 แก้)
✅ pending_closure   - เคส T2 ส่งกลับ T1 แล้ว

เงื่อนไข:
- status IN ['resolved', 'pending_closure']
- เคสของ T2 (ไม่เห็นของ T1)
```

**Action:**
- ❌ ปิดเคสไม่ได้ (ต้องรอ T1 ปิดให้)
- ✅ ดูได้อย่างเดียว

---

### เมนู 5: **"ปิดแล้ว"** (Closed)
**Path:** `/admin/tickets?view=closed`

```typescript
สถานะที่แสดง:
✅ closed        - เคสปิดแล้ว (ที่ T2 เคยจัดการ)

เงื่อนไข:
- status = 'closed'
- T2 เห็นเฉพาะเคสที่ตัวเองเคยจัดการ
```

---

### เมนู 6: **"ทั้งหมด"** (All Tickets)
**Path:** `/admin/tickets?view=all`

```typescript
สถานะที่แสดง:
❌ new           - ไม่เห็น (T1 จัดการ)
❌ tier1         - ไม่เห็น (T1 จัดการ)
✅ tier2
✅ tier3         - ดูได้ (เคสที่ส่งไป T3)
✅ in_progress
✅ waiting
✅ pending_closure
✅ resolved
✅ closed

เงื่อนไข:
- Tier2 เห็นเฉพาะเคสที่เกี่ยวข้อง (ไม่เห็น T1 Layer)
```

---

## 👨‍💼 **Tier 3 Dashboard**

### เมนู 1: **"รับเคส"** (Accept Queue)
**Path:** `/admin/tickets?view=accept`

```typescript
สถานะที่แสดง:
✅ tier3         - เคสที่ T2 ส่งมา (assigned แต่ยังไม่รับ)

เงื่อนไข:
- status = 'tier3'
- assignedTo = currentUserId
```

---

### เมนู 2: **"กำลังดำเนินการ"** (In Progress)
**Path:** `/admin/tickets?view=in-progress`

```typescript
สถานะที่แสดง:
✅ in_progress   - เคสกำลังทำ (T3)

เงื่อนไข:
- status = 'in_progress'
- assignedTo = currentUserId
- เคสต้องมาจาก tier3
```

**Action:**
- ✅ ส่งกลับ T2 (Escalate Down)
- ✅ ส่งกลับ T1 เพื่อปิด (Return for Closure → pending_closure)
- ✅ หยุดชั่วคราว (Pause → waiting)
- ❌ ปิดเคสเอง (ไม่ได้) - ต้องส่งกลับ T1

---

### เมนู 3: **"รอดำเนินการ"** (Waiting)
**Path:** `/admin/tickets?view=waiting`

```typescript
สถานะที่แสดง:
✅ waiting       - เคสหยุดชั่วคราว (T3)

เงื่อนไข:
- status = 'waiting'
- assignedTo = currentUserId
```

---

### เมนู 4: **"แก้ไขแล้ว"** 🟢 (Resolved)
**Path:** `/admin/tickets?view=resolved`

```typescript
สถานะที่แสดง:
✅ resolved          - เคสแก้ไขแล้ว (T3 แก้)
✅ pending_closure   - เคส T3 ส่งกลับ T1 แล้ว

เงื่อนไข:
- status IN ['resolved', 'pending_closure']
- เคสของ T3 เท่านั้น
```

**Action:**
- ❌ ปิดเคสไม่ได้
- ✅ ดูได้อย่างเดียว

---

### เมนู 5: **"ปิดแล้ว"** (Closed)
**Path:** `/admin/tickets?view=closed`

```typescript
สถานะที่แสดง:
✅ closed        - เคสปิดแล้ว (ที่ T3 เคยจัดการ)

เงื่อนไข:
- status = 'closed'
- T3 เห็นเฉพาะเคสที่ตัวเองเคยจัดการ
```

---

### เมนู 6: **"ทั้งหมด"** (All Tickets)
**Path:** `/admin/tickets?view=all`

```typescript
สถานะที่แสดง:
❌ new           - ไม่เห็น
❌ tier1         - ไม่เห็น
❌ tier2         - ไม่เห็น
✅ tier3
✅ in_progress
✅ waiting
✅ pending_closure
✅ resolved
✅ closed

เงื่อนไข:
- Tier3 เห็นเฉพาะเคสของตัวเอง (น้อยสุด)
```

---

## 👨‍💼 **Staff Dashboard**

### เมนู 1: **"ติดตามเคสลูกค้า"** (Track Tickets)
**Path:** `/track`

```typescript
สถานะที่แสดง:
✅ new           - เคสที่บันทึกแล้ว (รอ Tier รับ)
✅ tier1/2/3     - เคสกำลังดำเนินการ (แสดงเป็น "กำลังดำเนินการ")
✅ in_progress   - เคสกำลังทำ
✅ waiting       - เคสหยุดชั่วคราว (รอข้อมูลเพิ่มเติม)
✅ resolved      - เคสแก้ไขแล้ว (แสดงเป็น "แก้ไขเรียบร้อย" 🟢)
✅ pending_closure - เคสรอปิด (แสดงเป็น "แก้ไขเรียบร้อย" 🟢)
❌ closed        - ไม่แสดง (ต้องไปดูที่เมนู "เคสที่ปิดย้อนหลัง")

เงื่อนไข:
- createdBy = currentUserId (Staff คนนั้น)
- status != 'closed'
```

**หมายเหตุ:**
- Staff ดูได้เฉพาะเคสที่ตัวเองบันทึก
- ไม่เห็นคำว่า "Tier" (ดูเป็นมิตร)

---

### เมนู 2: **"เคสที่ปิดย้อนหลัง"** (Closed/Backlog Tickets)
**Path:** `/closed-tickets`

```typescript
สถานะที่แสดง:
✅ closed        - เคสปิดแล้ว (แบ่งเป็น 2 หมวด)

หมวดที่ 1: "Staff ปิดเอง"
- isBacklogCase = true
- createdBy = currentUserId
- closedBy = currentUserId
- สร้างและปิดโดย Staff คนเดียวกัน

หมวดที่ 2: "Tier ปิดให้"
- createdBy = currentUserId
- closedBy != currentUserId
- Staff บันทึก แต่ Tier ปิดให้

เงื่อนไข:
- createdBy = currentUserId
- status = 'closed'
- Read-only (ดูได้อย่างเดียว)
```

**หมายเหตุ:**
- **ทั้งหมด Read-only** - ไม่สามารถแก้ไข, รับเคส, ส่งต่อได้
- ใช้สำหรับดูประวัติย้อนหลัง

---

## 👨‍💼 **Admin Dashboard**

### เมนู 1-6: **เหมือน Tier 1** (ถ้ามี tier1 role)

```typescript
Admin + Tier1:
- ทำงานเหมือน Tier1 ทุกอย่าง
- เห็นเคสทุกระดับ
- มีปุ่ม Action ครบ

Pure Admin (ไม่มี tier role):
- เห็นเคสทุกระดับ (Monitor All)
- ❌ ไม่มีปุ่ม Action ใด ๆ
- แสดง Banner: "คุณกำลังดูเคส (Admin - Monitor Mode)"
```

---

### เมนู พิเศษ: **"Analytics"** (เฉพาะ Admin)
**Path:** `/admin/analytics`

```typescript
แสดง:
- Dashboard ภาพรวม (ทุก Tier)
- กราฟสถิติ
- ตารางสรุป
- เห็นข้อมูลทุกระดับ
```

---

### เมนู พิเศษ: **"Reports"** (เฉพาะ Admin)
**Path:** `/admin/reports`

```typescript
รายงาน 5 แบบ:
1. สรุปเคสตาม Status
2. Performance Report (SLA)
3. User Activity Report
4. Ticket Volume Trends
5. Category Analysis

เงื่อนไข:
- Export ได้ (Excel/PDF)
- Filter ตามช่วงเวลา, Tier, Project
```

---

## 👨‍💼 **Customer View**

### เมนู: **"ติดตามเคสของฉัน"** (Track My Tickets)
**Path:** `/track`

```typescript
สถานะที่แสดง:
✅ new           - เคสเพิ่งสร้าง (แสดงเป็น "เปิดเคสแล้ว")
✅ tier1/2/3     - กำลังดำเนินการ (ไม่เห็นคำว่า "Tier")
✅ in_progress   - กำลังดำเนินการ
✅ waiting       - รอข้อมูลเพิ่มเติม
✅ resolved      - แก้ไขเรียบร้อย 🟢
✅ pending_closure - แก้ไขเรียบร้อย 🟢
❌ closed        - ไม่แสดง (หรือแสดงในส่วนแยก)

เงื่อนไข:
- customerEmail = currentUserEmail
- status != 'closed' (หรือ closed ใน 7 วันล่าสุด)
```

**หมายเหตุ:**
- Customer ไม่เห็นคำว่า "Tier"
- ดูเป็นมิตร: "กำลังดำเนินการ", "แก้ไขเรียบร้อย"

---

## 📊 สรุป Status ตามเมนู (Quick Reference)

### **Tier 1:**

| เมนู | Status |
|------|--------|
| รับเคส | `new`, `tier1` |
| กำลังดำเนินการ | `in_progress` |
| รอดำเนินการ | `waiting` |
| แก้ไขแล้ว 🟢 | `resolved`, `pending_closure` |
| ปิดแล้ว | `closed` |
| ทั้งหมด | ทุก status |

### **Tier 2:**

| เมนู | Status |
|------|--------|
| รับเคส | `tier2` |
| กำลังดำเนินการ | `in_progress` (T2) |
| รอดำเนินการ | `waiting` (T2) |
| แก้ไขแล้ว 🟢 | `resolved`, `pending_closure` (T2) |
| ปิดแล้ว | `closed` (T2) |
| ทั้งหมด | `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `pending_closure`, `closed` |

### **Tier 3:**

| เมนู | Status |
|------|--------|
| รับเคส | `tier3` |
| กำลังดำเนินการ | `in_progress` (T3) |
| รอดำเนินการ | `waiting` (T3) |
| แก้ไขแล้ว 🟢 | `resolved`, `pending_closure` (T3) |
| ปิดแล้ว | `closed` (T3) |
| ทั้งหมด | `tier3`, `in_progress`, `waiting`, `resolved`, `pending_closure`, `closed` |

### **Staff:**

| เมนู | Status |
|------|--------|
| ติดตามเคสลูกค้า | `new`, `tier1/2/3`, `in_progress`, `waiting`, `resolved`, `pending_closure` |
| เคสที่ปิดย้อนหลัง | `closed` (แบ่ง 2 หมวด: "Staff ปิดเอง", "Tier ปิดให้") |

### **Customer:**

| เมนู | Status |
|------|--------|
| ติดตามเคสของฉัน | `new`, `tier1/2/3`, `in_progress`, `waiting`, `resolved`, `pending_closure` |

---

## 🔑 Key Points

### 1. **Inverted Visibility:**
- Tier1 → เห็นมากสุด (ทุกเคส)
- Tier2 → เห็นปานกลาง (เฉพาะ T2/T3)
- Tier3 → เห็นน้อยสุด (เฉพาะ T3)

### 2. **Status Grouping:**
- **รับเคส** = `new`, `tier1/2/3` (รอรับ)
- **กำลังดำเนินการ** = `in_progress`
- **รอดำเนินการ** = `waiting`
- **แก้ไขแล้ว** 🟢 = `resolved`, `pending_closure`
- **ปิดแล้ว** = `closed`

### 3. **Notification สีเขียว 🟢:**
- แสดงที่เมนู "แก้ไขแล้ว"
- นับเฉพาะ `resolved` + `pending_closure`
- Tier1 เห็นมากสุด (รวมที่ T2/T3 ส่งกลับมา)

### 4. **Symmetric Escalation:**
- T1 ↔ T2 ↔ T3 (ส่งต่อได้ทุกทิศทาง)
- T2/T3 ส่งกลับ T1 เพื่อปิด → `pending_closure`
- **เฉพาะ T1 ปิดเคสได้**

### 5. **Staff Special Cases:**
- บันทึกเคสแทนลูกค้า
- เลือก "แก้ไขและปิดเคส" → `closed` (backlog)
- เลือก "ส่งงาน" → `new` (รอ T1 รับ)
- เคสที่ปิดย้อนหลัง = **Read-only**

---

**สร้างโดย:** AI Assistant  
**วันที่:** 14 มกราคม 2026  
**เวอร์ชัน:** 1.0
