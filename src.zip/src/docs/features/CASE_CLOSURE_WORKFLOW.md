# 📋 CDGS Issue Tracking Platform - Case Closure Workflow

**วันที่:** 14 มกราคม 2026  
**หัวข้อ:** กระบวนการปิดเคสและสถานะที่เกี่ยวข้อง  
**สถานะ:** ✅ **ดำเนินการเสร็จสิ้น - ลบ `pending_closure` ออกจากระบบแล้ว**

---

## 🔐 **กฎการปิดเคส (Case Closure Rules)**

### ✅ **ข้อกำหนดหลัก:**

1. **ลูกค้าไม่สามารถปิดเคสเองได้**
   - Customer ไม่มีปุ่ม "ปิดเคส" ในระบบ
   - Customer สามารถตอบกลับเพื่อยืนยันการแก้ไขได้เท่านั้น

2. **Tier1 เป็นคนปิดเคสเท่านั้น**
   - เฉพาะ Tier1 มีสิทธิ์กดปุ่ม "ปิดเคส"
   - Tier2/Tier3 ไม่สามารถปิดเคสได้ (แต่สามารถแก้ไขเสร็จและส่งกลับ Tier1 ได้)

3. **Tier1 ต้องตรวจสอบและได้รับการยืนยันจากลูกค้าก่อนปิดเคส**
   - Tier1 ต้องอ่านคำตอบของลูกค้าในช่องตอบกลับ (Comments)
   - Tier1 ยืนยันว่าลูกค้าพอใจกับการแก้ไขแล้ว → จึงปิดเคส

4. **ไม่มีสถานะ "รอลูกค้าปิดเคส"**
   - ระบบไม่มีสถานะที่รอให้ลูกค้ากดปิดเคสเอง
   - ทุกเคสต้องผ่าน Tier1 เป็นคนปิดเสมอ

---

## 📊 **Workflow การปิดเคส (ดำเนินการแล้ว)**

### **Workflow ที่ใช้งานจริง:**

```
Tier2/3 แก้ไขเสร็จ → status = 'resolved' (แก้ไขแล้ว รอ T1 ปิด)
                        ↓
Tier1 ตรวจสอบ + อ่านคำยืนยันจากลูกค้า
                        ↓
Tier1 กดปุ่ม "ปิดเคส" → status = 'closed'
```

---

## 📋 **สถานะที่เกี่ยวข้องกับการปิดเคส**

### 1. `resolved` - **แก้ไขแล้ว**

**ความหมาย:**
- Tier2 หรือ Tier3 แก้ไขเคสเสร็จสิ้นแล้ว
- ส่งเคสกลับมาที่ Tier1 เพื่อให้ตรวจสอบและปิดเคส

**ใครทำให้เป็นสถานะนี้:**
- ✅ Tier2: กดปุ่ม "ส่งกลับ T1" (แก้ไขเสร็จแล้ว)
- ✅ Tier3: กดปุ่ม "ส่งกลับ T1" (แก้ไขเสร็จแล้ว)

**ใครเห็นสถานะนี้:**
- ✅ Tier1: เห็นในเมนู "รอดำเนินการ" และ "แก้ไขแล้ว"
- ✅ Tier2/Tier3: เห็นในเมนู "แก้ไขแล้ว" (เฉพาะเคสที่ตัวเองแก้ไข)
- ✅ Customer: เห็นเป็น "แก้ไขเรียบร้อย" (customer-friendly label)

**Badge Label:**
- 🟢 Internal Staff: **"แก้ไขแล้ว"** (สีเขียว)
- 🟢 Customer: **"แก้ไขเรียบร้อย"** (สีเขียว)

**Action ที่ Tier1 ต้องทำ:**
1. อ่านคำตอบของลูกค้าในช่อง Comments
2. ยืนยันว่าลูกค้าพอใจกับการแก้ไข
3. กดปุ่ม **"ปิดเคส"** → เปลี่ยนเป็น `closed`

---

### 2. `closed` - **ปิดแล้ว**

**ความหมาย:**
- เคสถูกปิดโดย Tier1 แล้ว
- ลูกค้าได้รับการแก้ไขและยืนยันความพอใจ

**ใครทำให้เป็นสถานะนี้:**
- ✅ Tier1: กดปุ่ม "ปิดเคส" หลังจากยืนยันกับลูกค้าแล้ว

**Badge Label:**
- ⚫ Internal Staff: **"ปิดแล้ว"** (สีเทา)
- ⚫ Customer: **"ปิดเคสแล้ว"** (สีเทา)

---

## ✅ **สถานะทั้งหมดในระบบ (Final)**

**Workflow สมบูรณ์:**
```
new → tier1 → tier2 → tier3 → in_progress → waiting → resolved → closed
                                   ↓            ↓
                                (กำลังทำงาน) (หยุดชั่วคราว)
```

**สถานะทั้งหมด:**
1. `new` - เคสใหม่
2. `tier1` - รอ Tier1 รับเคส
3. `tier2` - รอ Tier2 รับเคส
4. `tier3` - รอ Tier3 รับเคส
5. `in_progress` - กำลังดำเนินการ
6. `waiting` - หยุดชั่วคราว
7. `resolved` - **แก้ไขแล้ว รอ Tier1 ปิดเคส**
8. `closed` - ปิดเคสแล้ว

**สถานะที่ลบออกแล้ว:**
- ❌ ~~`pending_closure`~~ - ลบออกแล้ว (วันที่ 14 มกราคม 2026)

---

## 📝 **การเปลี่ยนแปลงที่ดำเนินการแล้ว**

### ✅ **Completed:**

1. **TypeScript Types**
   - ✅ ลบ `'pending_closure'` จาก `TicketStatus` type ใน `/types/index.ts`

2. **Utility Functions**
   - ✅ ลบ `pending_closure` จาก `getStatusLabel()` ใน `/lib/utils.ts`
   - ✅ ลบ `pending_closure` จาก `getStatusColor()` ใน `/lib/utils.ts`
   - ✅ ลบ `pending_closure` จาก `getStatusLabelForCustomer()` ใน `/lib/utils.ts`
   - ✅ ลบ `pending_closure` จาก `getStatusColorForCustomer()` ใน `/lib/utils.ts`

3. **UI Components**
   - ✅ อัปเดต `/components/Sidebar.tsx` - ลบ pending_closure จากการนับ badge
   - ✅ อัปเดต `/components/TicketListPage.tsx` - ลบ filter option และ business logic
   - ✅ อัปเดต `/components/TicketDetailPage.tsx` - ลบจาก status action map
   - ✅ อัปเดต `/components/TicketActions.tsx` - เปลี่ยนจาก pending_closure เป็น resolved
   - ✅ อัปเดต `/components/TicketStatusAlert.tsx` - ลบ pending_closure alert
   - ✅ อัปเดต `/components/AssignmentInfoCard.tsx` - ลบ pending_closure label
   - ✅ อัปเดต `/components/EscalatedPage.tsx` - ลบการกรอง pending_closure

4. **Mock Data**
   - ✅ เปลี่ยน `status: 'pending_closure'` → `status: 'resolved'` ใน mockData
   - ✅ เปลี่ยน `status: 'pending_closure'` → `status: 'resolved'` ใน timeline events
   - ✅ ลบ auto-normalization function สำหรับ pending_closure

5. **Documentation**
   - ✅ อัปเดต `/CASE_CLOSURE_WORKFLOW.md` (ไฟล์นี้)
   - ⏳ รออัปเดต `/SYSTEM_ARCHITECTURE.md`

---

## 🎯 **สรุป**

### **ก่อนการเปลี่ยนแปลง:**
```
resolved → pending_closure → closed
  (T2/3)      (T1 ยืนยัน)    (T1 ปิด)
```

### **หลังการเปลี่ยนแปลง:**
```
resolved → closed
  (T2/3)    (T1 ตรวจสอบ+ปิด)
```

### **ข้อดี:**
- ✅ ง่ายและชัดเจนกว่าเดิม
- ✅ ไม่มีสถานะที่สับสน
- ✅ `resolved` = รอ Tier1 ปิด (ครอบคลุมทั้งการตรวจสอบและการปิด)
- ✅ `closed` = ปิดเคสแล้ว

---

**ผู้บันทึก:** AI Assistant  
**วันที่อัปเดตล่าสุด:** 14 มกราคม 2026  
**สถานะ:** ✅ **ดำเนินการเสร็จสิ้น**
