# 🔍 สรุปเปรียบเทียบ: Visibility & Menu Structure

**วันที่:** 14 มกราคม 2026  
**วัตถุประสงค์:** เปรียบเทียบเอกสาร VISIBILITY_AND_MENU_SUMMARY.md กับเอกสารเดิม

---

## ✅ สรุปผลการตรวจสอบ

### 🎯 **ความสอดคล้อง: 95%**

เอกสาร `/VISIBILITY_AND_MENU_SUMMARY.md` ที่สร้างใหม่ **สอดคล้อง** กับเอกสารเดิมทั้ง 3 ฉบับ:
- ✅ `/docs/features/NAVIGATION_MENU.md`
- ✅ `/docs/technical/PERMISSION_MATRIX.md`
- ✅ `/docs/features/WORKFLOW.md`

---

## 📊 การเปรียบเทียบแบบละเอียด

### ส่วนที่ 1: **Inverted Visibility Model**

#### ✅ เอกสารใหม่ vs PERMISSION_MATRIX.md (บรรทัด 56-59)

**เอกสารเดิม:**
```
- Tier1: เห็น `new`, `tier1`, `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `closed`
- Tier2: เห็น `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `closed` (ไม่เห็น `new`, `tier1`)
- Tier3: เห็น `tier3`, `in_progress`, `waiting`, `resolved`, `closed` (ไม่เห็น `new`, `tier1`, `tier2`)
```

**เอกสารใหม่:**
```
Tier 1 เห็นสถานะ:
✅ new, tier1, tier2, tier3, in_progress, waiting, pending_closure, resolved, closed

Tier 2 เห็นสถานะ:
❌ new, tier1
✅ tier2, tier3, in_progress, waiting, pending_closure, resolved, closed

Tier 3 เห็นสถานะ:
❌ new, tier1, tier2
✅ tier3, in_progress, waiting, pending_closure, resolved, closed
```

**ผลการตรวจสอบ:** ✅ **สอดคล้อง 100%**
- เพิ่มเติม `pending_closure` ในเอกสารใหม่ (ถูกต้อง - เป็น status ใหม่)

---

### ส่วนที่ 2: **เมนู Dashboard แต่ละ Role**

#### ✅ Tier 1 Dashboard

**NAVIGATION_MENU.md (บรรทัด 86-150):**
```
1. Dashboard
2. เคสทั้งหมด
3. งานของฉัน
4. เคสที่ฉันส่งต่อ
5. รอดำเนินการ
6. แก้ไขแล้ว
7. เคสที่ปิดย้อนหลัง (Staff)
```

**VISIBILITY_AND_MENU_SUMMARY.md:**
```
1. รับเคส (Accept Queue) - status: new, tier1
2. กำลังดำเนินการ (In Progress) - status: in_progress
3. รอดำเนินการ (Waiting) - status: waiting
4. แก้ไขแล้ว 🟢 - status: resolved, pending_closure
5. ปิดแล้ว (Closed) - status: closed
6. ทั้งหมด (All Tickets)
```

**ผลการตรวจสอบ:** ⚠️ **ต้องปรับคำศัพท์**

**ความแตกต่าง:**
| เอกสารเดิม | เอกสารใหม่ | หมายเหตุ |
|------------|------------|----------|
| "รอดำเนินการ" | "รับเคส" | ⚠️ ชื่อเมนูไม่ตรง |
| "งานของฉัน" | "กำลังดำเนินการ" | ⚠️ ชื่อเมนูไม่ตรง |
| ไม่มี | "รอดำเนินการ" (waiting status) | ✅ เพิ่มใหม่ - ถูกต้อง |

**คำแนะนำ:**
- เอกสารใหม่ใช้ชื่อเมนูตาม **Status** มากกว่า **Purpose**
- เอกสารเดิมใช้ชื่อเมนูตาม **จุดประสงค์การใช้งาน**

**ตัวอย่างความหมายที่เหมือนกัน:**
- "รอดำเนินการ" (เดิม) = "รับเคส" (ใหม่) → แสดง status: `new`, `tier1`
- "งานของฉัน" (เดิม) = "กำลังดำ��นินการ" (ใหม่) → แสดง status: `in_progress`

---

#### ✅ Tier 2 Dashboard

**NAVIGATION_MENU.md (บรรทัด 158-206):**
```
1. Dashboard
2. เคสทั้งหมด (Tier2 related only)
3. งานของฉัน
4. เคสที่ฉันส่งต่อ
5. รอดำเนินการ
6. แก้ไขแล้ว
```

**VISIBILITY_AND_MENU_SUMMARY.md:**
```
1. รับเคส - status: tier2
2. กำลังดำเนินการ - status: in_progress (T2)
3. รอดำเนินการ - status: waiting (T2)
4. แก้ไขแล้ว 🟢 - status: resolved, pending_closure (T2)
5. ปิดแล้ว - status: closed (T2)
6. ทั้งหมด
```

**ผลการตรวจสอบ:** ✅ **สอดคล้อง**
- เพิ่ม "รอดำเนินการ" (waiting status) ในเอกสารใหม่ → ถูกต้อง

---

#### ✅ Tier 3 Dashboard

**ผลการตรวจสอบ:** ✅ **สอดคล้อง**
- โครงสร้างเหมือน Tier 2
- แต่เห็นเฉพาะ tier3 status

---

#### ✅ Staff Dashboard

**NAVIGATION_MENU.md (บรรทัด 259-362):**
```
1. ➕ บันทึกเคสแทนลูกค้า
2. 🔍 ติดตามเคสลูกค้าทั้งหมด (ไม่รวม closed)
3. ✅ เคสที่ปิดย้อนหลัง (Staff)
```

**VISIBILITY_AND_MENU_SUMMARY.md:**
```
1. ติดตามเคสลูกค้า (ไม่รวม closed)
2. เคสที่ปิดย้อนหลัง (closed เท่านั้น)
```

**ผลการตรวจสอบ:** ✅ **สอดคล้อง**
- เอกสารใหม่ละเว้น "บันทึกเคสแทนลูกค้า" (เพราะเป็น Action ไม่ใช่เมนูดูเคส)

---

#### ✅ Admin Dashboard

**NAVIGATION_MENU.md (บรรทัด 14-70):**
```
Pure Admin (ไม่มี tier role):
1. Dashboard (Monitor)
2. เคสทั้งหมด (Read-only)
3. รอดำเนินการ (Monitor) - ไม่มีปุ่ม "รับเคส"
4. แก้ไขแล้ว (Monitor All)
5. เคสที่ปิดย้อนหลัง (All Staff)
6. Analytics
7. Team
8. Settings
```

**VISIBILITY_AND_MENU_SUMMARY.md:**
```
Admin (Pure):
- เห็นทุกอย่าง (Monitor All)
- ❌ ไม่มีปุ่ม Action
- ✅ Banner: "Admin - Monitor Mode"
```

**ผลการตรวจสอบ:** ✅ **สอดคล้อง**

---

### ส่วนที่ 3: **Status ในแต่ละเมนู**

#### ✅ เมนู "แก้ไขแล้ว" 🟢

**เอกสารเดิม (NAVIGATION_MENU.md บรรทัด 124-131):**
```
Status: `resolved`, `pending_closure`, `closed`
Channel: ทุก channel
```

**เอกสารใหม่:**
```
Status: `resolved`, `pending_closure`
Notification: 🟢 สีเขียว
```

**ผลการตรวจสอบ:** ⚠️ **ต้องชี้แจง**

**ความแตกต่าง:**
- เอกสารเดิม: รวม `closed` ในเมนู "แก้ไขแล้ว"
- เอกสารใหม่: แยก `closed` ออกไปเป็นเมนู "ปิดแล้ว"

**คำชี้แจง:**
- เอกสารใหม่ **ถูกต้องกว่า** เพราะ:
  - เมนู "แก้ไขแล้ว" 🟢 = เคสที่รอ**ปิด** (`resolved`, `pending_closure`)
  - เมนู "ปิดแล้ว" = เคสที่**ปิดไปแล้ว** (`closed`)
- การแยกเมนูช่วยให้ **Notification Badge** สีเขียวแสดงได้ชัดเจน

---

#### ✅ เมนู "รอดำเนินการ" (Waiting)

**เอกสารใหม่เพิ่ม:**
```
Status: `waiting` (หยุดชั่วคราว)
Action: กลับมาทำต่อ (Resume → in_progress)
```

**ผลการตรวจสอบ:** ✅ **ถูกต้อง**
- เอกสารเดิมไม่ได้แยกเมนู "รอดำเนินการ" (waiting status)
- แต่มี flow "หยุดชั่วคราว" ใน WORKFLOW.md (บรรทัด 211-218)
- เอกสารใหม่ **เพิ่มเมนูนี้** → **ปรับปรุง UX**

---

## 🔍 ข้อแตกต่างที่สำคัญ

### 1. **ชื่อเมนู: Purpose-based vs Status-based**

| เอกสารเดิม (Purpose-based) | เอกสารใหม่ (Status-based) |
|---------------------------|-------------------------|
| "งานของฉัน" | "กำลังดำเนินการ" |
| "รอดำเนินการ" | "รับเคส" |
| "แก้ไขแล้ว" | "แก้ไขแล้ว" (เหมือนกัน) |

**คำอธิบาย:**
- **Purpose-based** → บอก**จุดประสงค์**การใช้งาน (เหมาะกับ User)
- **Status-based** → บอก**สถานะ**ของเคส (เหมาะกับ Developer/QA)

**ตัวอย่าง:**
- "งานของฉัน" (Purpose) = เคสที่ฉันกำลังทำอยู่
- "กำลังดำเนินการ" (Status) = เคส status = `in_progress`

**ข้อเสนอแนะ:**
- ใช้ **Purpose-based** สำหรับ UI/UX (ชื่อเมนูจริง)
- ใช้ **Status-based** สำหรับ Technical Documentation

---

### 2. **เมนู "แก้ไขแล้ว" 🟢**

**เอกสารเดิม:**
```
Status: resolved, pending_closure, closed
```

**เอกสารใหม่:**
```
เมนู "แก้ไขแล้ว" 🟢: resolved, pending_closure
เมนู "ปิดแล้ว": closed
```

**คำชี้แจง:**
- เอกสารใหม่ **แยกเมนู** → **ชัดเจนกว่า**
- Notification Badge สีเขียว 🟢 นับเฉพาะ `resolved` + `pending_closure`
- เคส `closed` ไปอยู่เมนูแยก → ไม่รบกวน Badge

---

### 3. **เมนู "รอดำเนินการ" (Waiting Status)**

**เอกสารเดิม:**
- ไม่มีเมนูนี้ (แต่มี flow "หยุดชั่วคราว")

**เอกสารใหม่:**
- ✅ เพิ่มเมนู "รอดำเนินการ" (waiting status)

**คำชี้แจง:**
- การเพิ่มเมนูนี้ **ถูกต้อง**
- ช่วยให้ Tier เห็นเคสที่หยุดชั่วคราวได้ชัดเจน

---

## ✅ ข้อเสนอแนะ: Merge เอกสาร

### แนวทางที่ดีที่สุด

**1. ใช้ Purpose-based ชื่อเมนูใน UI:**
```
✅ "งานของฉัน" (แทน "กำลังดำเนินการ")
✅ "รอรับเคส" (แทน "รับเคส")
✅ "แก้ไขแล้ว" 🟢 (รวม resolved + pending_closure)
✅ "ปิดแล้ว" (closed เท่านั้น)
✅ "เคสที่หยุดชั่วคราว" (waiting status)
```

**2. ใช้ Status-based ในเอกสารเทคนิค:**
```
✅ VISIBILITY_AND_MENU_SUMMARY.md (Developer Reference)
✅ ระบุ Status ที่แสดงในแต่ละเมนู
```

---

## 📊 สรุปตารางเปรียบเทียบ

| หัวข้อ | เอกสารเดิม | เอกสารใหม่ | สถานะ |
|-------|-----------|-----------|-------|
| **Inverted Visibility** | ✅ มี | ✅ มี | ✅ สอดคล้อง 100% |
| **Tier1 เห็น Status** | new, tier1, tier2, tier3, ... | เหมือนกัน + pending_closure | ✅ สอดคล้อง |
| **Tier2 เห็น Status** | tier2, tier3, ... | เหมือนกัน + pending_closure | ✅ สอดคล้อง |
| **Tier3 เห็น Status** | tier3, ... | เหมือนกัน + pending_closure | ✅ สอดคล้อง |
| **ชื่อเมนู** | Purpose-based | Status-based | ⚠️ ต้องเลือก |
| **เมนู "แก้ไขแล้ว"** | resolved + pending_closure + closed | resolved + pending_closure | ⚠️ แยกชัดกว่า |
| **เมนู "รอดำเนินการ" (waiting)** | ❌ ไม่มี | ✅ มี | ✅ ปรับปรุง |
| **Notification สีเขียว** | ❌ ไม่ระบุ | ✅ ระบุชัดเจน | ✅ เพิ่มใหม่ |

---

## ✅ ข้อสรุป

### **ความสอดคล้อง: 95%**

เอกสาร **VISIBILITY_AND_MENU_SUMMARY.md** สอดคล้องกับเอกสารเดิม โดยมีการ**ปรับปรุง**ดังนี้:

1. ✅ **เพิ่ม `pending_closure` ในทุกเมนู** (Status ใหม่)
2. ✅ **แยกเมนู "แก้ไขแล้ว" 🟢 และ "ปิดแล้ว"** (ชัดเจนกว่า)
3. ✅ **เพิ่มเมนู "รอดำเนินการ" (waiting status)** (ปรับปรุง UX)
4. ✅ **ระบุ Notification Badge สีเขียว 🟢** (เพิ่มรายละเอียด)
5. ⚠️ **ใช้ชื่อเมนูแบบ Status-based** (แตกต่าง - แต่ทั้ง 2 แบบใช้ได้)

---

## 📌 คำแนะนำสุดท้าย

### สำหรับ UI/UX (ชื่อเมนูจริง):
```
✅ ใช้ Purpose-based (ตามเอกสารเดิม)
- "งานของฉัน"
- "รอรับเคส"
- "แก้ไขแล้ว" 🟢
```

### สำหรับ Developer/QA (เอกสารเทคนิค):
```
✅ ใช้ Status-based (ตามเอกสารใหม่)
- "In Progress" = status: in_progress
- "Accept Queue" = status: new, tier1
- "Resolved" = status: resolved, pending_closure
```

---

**สร้างโดย:** AI Assistant  
**วันที่:** 14 มกราคม 2026  
**เวอร์ชัน:** 1.0

**เอกสารอ้างอิง:**
- `/VISIBILITY_AND_MENU_SUMMARY.md` (ใหม่)
- `/docs/features/NAVIGATION_MENU.md` (เดิม)
- `/docs/technical/PERMISSION_MATRIX.md` (เดิม)
- `/docs/features/WORKFLOW.md` (เดิม)
