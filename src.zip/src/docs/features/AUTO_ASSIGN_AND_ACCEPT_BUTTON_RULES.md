# 🎯 กฎการแสดงปุ่มรับเคสและ Auto-Assign Logic

เอกสารนี้บันทึกกฎการแสดงปุ่ม "รับเคส" และ Logic การมอบหมายอัตโนมัติ (Auto-assign)

---

## 📋 กฎการแสดงปุ่ม "รับเคส"

### **✅ หลักการสำคัญ:**
- ⚠️ **ไม่มี auto-accept** - ทุกคนต้องกด "รับเคส" เองทุกครั้ง
- ✅ ปุ่ม "รับเคส" แสดงเฉพาะเคสที่ **assigned ให้ตัวเอง** (ยกเว้น Tier1 กับเคส "new")
- ✅ **[อัปเดต 21 ม.ค. 2026]** Staff/Tier1+Staff **ต้องเลือกโครงการตั้งแต่ตอนบันทึกเคส** (ไม่ใช่ตอนรับเคส)

---

### **Tier 1:**

```typescript
canAccept = 
  (ticket.status === 'new') || // เคสใหม่ - ทุกคนรับได้
  (ticket.status === 'tier1' && isAssignedToMe) // เคสส่งกลับ - ต้อง assigned ให้ตัวเอง
```

**กรณีพิเศษ:**
- **เคส `new` จาก Staff:** Tier1 ทุกคนเห็นปุ่ม "รับเคส" (ไม่ต้อง assigned)
  - ✅ **ไม่มี Dialog** - Staff เลือกโครงการไว้แล้วตอนบันทึกเคส
  - ✅ กดปุ่ม "รับเคส" ครั้งเดียวจบ - เหมือน Tier2/3
- **เคส `new` จาก Customer:** Tier1 ทุกคนเห็นปุ่ม "รับเคส" + ป้าย "⚠️ ข้อมูลไม่ครบ"
  - ⚠️ **มี Triage Modal** - ต้องเติมข้อมูล: โครงการ, Incident Type, ความสำคัญ (อัพเดต 21 ม.ค. 2026)
  - ✅ กดปุ่ม "รับเคส" → เปิด Modal → กรอกข้อมูล → กด "รับเคสและดำเนินการ"
- **เคส `tier1`:** เฉพาะคนที่ถูก assigned เท่านั้น
  - ✅ **ไม่มี Dialog** - มีข้อมูลครบแล้ว

**Logic ตรวจสอบ Triage:**
```typescript
const needsTriage = (ticket: Ticket) => {
  return (
    ticket.status === 'new' &&              // เคสใหม่
    ticket.channel === 'web' &&             // มาจาก Customer (ไม่ใช่ phone/email/line)
    (!ticket.projectId || !ticket.type)     // ขาดข้อมูลสำคัญ
  );
};

// ใน Component
if (needsTriage(ticket)) {
  showTriageModal(); // แสดง Modal กรอกข้อมูล
} else {
  acceptTicket(); // รับเคสเลย (เหมือนเดิม)
}
```

---

### **Tier 2:**

```typescript
canAccept = 
  ticket.status === 'tier2' && isAssignedToMe // ต้อง assigned ให้ตัวเอง
```

**ตัวอย่าง:**
- Tier1 ส่งต่อเคสไปหา "ประวิช จินทนากร" (user-008)
- Status → `tier2`, AssignedTo → `user-008`
- **ประวิช** login เข้ามา → เห็นปุ่ม "รับเคส" ✅
- **Tier2 คนอื่น** → ไม่เห็นปุ่ม "รับเคส" ❌ (มีแค่ Takeover)

---

### **Tier 3:**

```typescript
canAccept = 
  ticket.status === 'tier3' && isAssignedToMe // ต้อง assigned ให้ตัวเอง
```

---

## 📊 ตารางสรุป: ใครเห็นปุ่ม "รับเคส"

| สถานการณ์ | Status | AssignedTo | Tier1 | Tier2 | Tier3 |
|-----------|--------|------------|-------|-------|-------|
| เคสใหม่จากลูกค้า | `new` | `null` | **ทุกคน** ✅ | ❌ | ❌ |
| Tier1 ส่งไป Tier2 | `tier2` | `user-007` | ❌ | **เฉพาะ user-007** ✅ | ❌ |
| Tier1 ส่งไป Tier3 | `tier3` | `user-009` | ❌ | ❌ | **เฉพาะ user-009** ✅ |
| Tier2 ส่งกลับ Tier1 | `tier1` | `user-002` | **เฉพาะ user-002** ✅ | ❌ | ❌ |
| Tier3 ส่งกลับ Tier2 | `tier2` | `user-007` | ❌ | **เฉพาะ user-007** ✅ | ❌ |

---

## 🤖 Auto-Assign Logic

### **หลักการ:**
เมื่อผู้ใช้เลือก "มอบหมายอัตโนมัติ" ในขณะส่งต่อเคส ระบบจะเลือกผู้รับผิดชอบให้อัตโนมัติตามกฎต่อไปนี้:

### **กฎการเลือก:**

```typescript
/**
 * 🎯 หาผู้ใช้ที่มีงานน้อยที่สุดในระดับ tier ที่กำหนด
 * 
 * กฎการเลือก:
 * 1. นับจำนวนเคสที่ยังไม่ปิด (status !== 'closed' && status !== 'resolved')
 * 2. ถ้าจำนวนงานเท่ากัน → เลือกคนที่เคยทำงานน้อยสุด (ดูจากประวัติทั้งหมด)
 * 3. ถ้ายังเท่ากัน → เลือกคนแรกในรายการ (เรียงตาม id)
 */
```

### **ขั้นตอนการคำนวณ:**

1. **นับเคสที่กำลังทำอยู่ (Active Tickets):**
   ```typescript
   const activeCount = mockTickets.filter(
     ticket => ticket.assignedTo === user.id && 
               ticket.status !== 'closed' && 
               ticket.status !== 'resolved'
   ).length;
   ```

2. **นับประวัติการทำงานทั้งหมด (Historical Tickets):**
   ```typescript
   const totalHistoricalCount = mockTickets.filter(
     ticket => ticket.assignedTo === user.id || 
               ticket.assignedBy === user.id ||
               ticket.createdBy === user.id
   ).length;
   ```

3. **เรียงลำดับตามความสำคัญ:**
   ```typescript
   userStats.sort((a, b) => {
     // 1. จำนวนงานที่กำลังทำน้อยไปมาก
     if (a.activeCount !== b.activeCount) {
       return a.activeCount - b.activeCount;
     }
     // 2. ถ้าเท่ากัน → ประวัติการทำงานน้อยไปมาก
     if (a.totalHistoricalCount !== b.totalHistoricalCount) {
       return a.totalHistoricalCount - b.totalHistoricalCount;
     }
     // 3. ถ้ายังเท่ากัน → เรียงตาม id (คนแรกในรายการ)
     return a.user.id.localeCompare(b.user.id);
   });
   ```

### **ตัวอย่าง:**

**สถานการณ์:** Tier1 ส่งต่อเคสไป Tier2 โดยเลือก "มอบหมายอัตโนมัติ"

| ชื่อ | งานที่กำลังทำ | ประวัติทั้งหมด | ผลลัพธ์ |
|------|----------------|----------------|---------|
| ประวิช จินทนากร | 3 เคส | 45 เคส | ❌ |
| ยุทธนา คณามิ่งมงคล | 2 เคส | 38 เคส | ✅ **ได้รับเคส** |
| ประกาศิต ประคองเพ็ชร | 2 เคส | 42 เคส | ❌ |

**เหตุผล:**
- ยุทธนา มีงานที่กำลังทำ 2 เคส (เท่ากับประกาศิต)
- แต่ยุทธนา มีประวัติทำงาน 38 เคส (น้อยกว่าประกาศิต 42 เคส)
- ดังนั้นระบบเลือก **ยุทธนา** ✅

---

## ⚠️ หมายเหตุสำคัญ

### **Auto-assign ≠ Auto-accept**

```
┌─────────────────────┐
│ Tier1 ส่งต่อเคส     │
│ เลือก "มอบหมาย     │
│ อัตโนมัติ"          │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ ระบบเลือก Tier2     │
│ ที่มีงานน้อยสุด     │
│ → ยุทธนา            │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Status = tier2      │
│ AssignedTo = ยุทธนา │
│ ❌ ยังไม่รับเคส     │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ ยุทธนา login        │
│ เห็นปุ่ม "รับเคส"   │
│ กดรับเคสเอง         │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Status = in_progress│
│ ✅ เริ่มทำงานได้    │
└─────────────────────┘
```

---

## 📂 ไฟล์ที่เกี่ยวข้อง

- `/components/TicketActions.tsx` - Logic การส่งต่อและ Auto-assign
- `/components/AssigneeSelector.tsx` - Dropdown เลือกผู้รับผิดชอบ
- `/PHASE1_TESTING.md` - คู่มือทดสอบ
- `/TAKEOVER_TEST_GUIDE.md` - คู่มือทดสอบ Takeover

---

## 🐛 Bug ที่พบและแก้ไข

### **Bug #1: ปุ่มรับเคสแสดงให้ทุกคน (Fixed)**

**ปัญหา:**
- ก่อนแก้ไข: Tier2 ทุกคนเห็นปุ่ม "รับเคส" ในเคส status = `tier2`
- ทำให้ Tier2 ที่ไม่ได้ assigned ก็เห็นปุ่ม "รับเคส"

**การแก้ไข:**
```typescript
// ❌ ก่อนแก้ไข
canAccept = ticket.status === 'tier2'

// ✅ หลังแก้ไข
canAccept = ticket.status === 'tier2' && isAssignedToMe
```

**ผลลัพธ์:**
- Tier2 ที่ไม่ได้ assigned → ไม่เห็นปุ่ม "รับเคส" (มีแค่ Takeover) ✅

---

### **Bug #2: Auto-assign เลือกคนแรกเสมอ (Fixed)**

**ปัญหา:**
- ก่อนแก้ไข: `assigneeId = users[0]?.id` (เลือกคนแรกในรายการเสมอ)
- ไม่ได้เลือกคนที่มีงานน้อยสุดจริงๆ

**การแก้ไข:**
```typescript
// ✅ หลังแก้ไข
const user = findUserWithLeastTickets(users);
assigneeId = user?.id;
```

**ผลลัพธ์:**
- ระบบเลือกคนที่มีงานน้อยสุดจริงๆ (ตามกฎที่กำหนด) ✅

---

### **Bug #3: Mock Data มี tickets ที่ status = tier2/tier3 แต่ไม่มี assignedTo (Fixed)**

**ปัญหา:**
- พบ 3 เคสที่ status = `tier2` หรือ `tier3` แต่ `assignedTo: undefined`
- ทำให้ Tier2/3 ที่ควรเห็นปุ่ม "รับเคส" กลับไม่เห็น

**เคสที่แก้ไข:**

1. **CDGS-2024-T2-002** (ส่งต่อไป Tier2)
   ```typescript
   // ❌ ก่อนแก้ไข
   assignedTo: undefined
   assignedBy: undefined
   
   // ✅ หลังแก้ไข
   assignedTo: 'user-007' // ประกาศิต ประคองเพ็ชร (Tier2)
   assignedBy: 'user-004' // เขมิกา แซ่ตั้ง (Tier1)
   ```

2. **CDGS-2024-T3-001** (ส่งต่อไป Tier3)
   ```typescript
   // ❌ ก่อนแก้ไข
   assignedTo: undefined
   assignedBy: undefined
   
   // ✅ หลังแก้ไข
   assignedTo: 'user-009' // พุทธจักษ์ วงค์พันธ์ (Tier3)
   assignedBy: 'user-008' // ประวิช จินทนากร (Tier2)
   ```

3. **CDGS-2024-ESC009** (Tier3 ส่งกลับ Tier2)
   ```typescript
   // ❌ ก่อนแก้ไข
   assignedTo: undefined
   assignedBy: undefined
   
   // ✅ หลังแก้ไข
   assignedTo: 'user-008' // ประวิช จินทนากร (Tier2)
   assignedBy: 'user-009' // พุทธจักษ์ วงค์พันธ์ (Tier3)
   ```

**ผลลัพธ์:**
- ✅ Tier2/3 ที่ถูก assigned เห็นปุ่ม "รับเคส" แล้ว
- ✅ ระบบทำงานถูกต้องตามกฎที่กำหนด

---

## 📝 History

| วันที่ | การเปลี่ยนแปลง | ผู้แก้ไข |
|--------|----------------|----------|
| 2025-01-21 | สร้างเอกสาร + แก้ไข Bug #1, #2, #3, #4 | System |

---

### **Bug #4: Multi-Role (Tier2+Tier3) ไม่กรองเคสตาม activeRole (Fixed)**

**ปัญหา:**
- ประกาศิต ประคองเพ็ชร (user-007) มี roles: `['tier2', 'tier3']`
- เมื่อสลับบทบาทเป็น Tier2 แล้ว ยังเห็นเคส Tier3 อยู่
- เพราะระบบใช้ `hasRole(user, 'tier3')` ไม่ได้ดู `activeRole`

**โค้ดก่อนแก้ไข:**
```typescript
// ❌ ไม่ได้ใช้ activeRole
if (hasRole(user, 'tier2')) {
  // กรองเคส Tier2
}
if (hasRole(user, 'tier3')) {
  // กรองเคส Tier3 (ถูกรันทั้งคู่!)
}
```

**ผลลัพธ์:**
- สลับเป็น Tier2 → เห็นทั้ง Tier2 และ Tier3 ❌
- ทำให้เคสที่ควรซ่อน (Tier3) ปรากฏขึ้น

**การแก้ไข:**
```typescript
// ✅ ใช้ activeRole เพื่อกรองตาม role ที่สลับ
const effectiveRole = activeRole || user?.role;

if (effectiveRole === 'tier2' || (hasRole(user, 'tier2') && !hasRole(user, 'tier3'))) {
  // กรองเคส Tier2
}
if (effectiveRole === 'tier3' || (hasRole(user, 'tier3') && !hasRole(user, 'tier2'))) {
  // กรองเคส Tier3
}
```

**ไฟล์ที่แก้ไข:**
- `/components/TicketListPage.tsx` (บรรทัด 388-467 และ 472-495)

**ผลลัพธ์:**
- ✅ สลับเป็น Tier2 → เห็นเฉพาะ Tier2
- ✅ สลับเป็น Tier3 → เห็นเฉพาะ Tier3
- ✅ ระบบกรองเคสตาม activeRole อย่างถูกต้อง

---

**เอกสารนี้อัปเดตล่าสุด:** 21 มกราคม 2025