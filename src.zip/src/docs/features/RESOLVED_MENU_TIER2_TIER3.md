# 📝 เมนู "แก้ไขแล้ว" สำหรับ Tier2-3 - แสดงเคสที่ส่งกลับ Tier1

> **วันที่:** 14 มกราคม 2026  
> **ผู้พัฒนา:** AI Assistant  
> **วัตถุประสงค์:** เพิ่ม logic ให้เมนู "แก้ไขแล้ว" ของ Tier2-3 แสดงเคสที่แก้ไขแล้วและส่งกลับให้ Tier1 เพื่อปิดด้วย

---

## 🚨 กฎการปิดเคส (เข้มงวด)

### **กฎสำคัญ:**
- ✅ **เฉพาะ Tier1 เท่านั้น** ที่สามารถปิดเคสได้
- ❌ **Tier2-3 ไม่สามารถปิดเคสเองได้เลย**
- ✅ Tier2-3 ต้องส่งกลับ Tier1 เพื่อปิดเท่านั้น

### **ผลกระทบ:**
- `closedBy` จะเป็น Tier1 เท่านั้น (ไม่มี Tier2-3)
- Tier2-3 อาจเป็น `resolvedBy` ได้ (แก้ไขปัญหาเสร็จแล้ว)
- Tier2-3 ต้องส่งกลับ Tier1 เพื่อให้ปิดเคส

---

## 🎯 ความต้องการ

### **คำอธิบาย:**
เมนู "แก้ไขแล้ว" ของ Tier2-3 ควรแสดง:
1. ✅ เคสที่ตัวเองแก้ไข (resolvedBy = ตัวเอง) + status = 'resolved' or 'closed'
2. ✅ **เคสที่แก้ไขแล้วและส่งกลับให้ Tier1 เพื่อปิด** (escalationChain: tier2/tier3 → tier1) + **status = 'tier1', 'resolved', or 'closed'**
3. ❌ **ไม่ต้องตรวจสอบ closedBy** เพราะ Tier2-3 ปิดเคสไม่ได้อยู่แล้ว

### **เวิร์กโฟลว์:**
- Tier2-3 แก้ไขเสร็จ → ส่งกลับ Tier1 → `status = 'tier1'` (รอ Tier1 รับเคส)
- Tier1 รับเคส → `status = 'in_progress'` (กำลังทำ)
- Tier1 แก้ไขเสร็จ → `status = 'resolved'` (รอปิด)
- Tier1 ปิดเคส → `status = 'closed'` (เสร็จสิ้น)

### **เหตุผล:**
- Tier2-3 อาจแก้ไขปัญหาแล้ว แต่ต้องส่งกลับให้ Tier1 เพื่อปิดเคส (เช่น ต้อง confirm กับลูกค้า)
- Tier2-3 ควรเห็นเคสเหล่านี้ในเมนู "แก้ไขแล้ว" เพื่อติดตามสถานะ

---

## 🔍 ตัวอย่างเคสในระบบ

### **เคสที่มีการส่งกลับ Tier1:**

#### **1. CDGS-2024-ESC010: Password Reset Request**
```javascript
{
  id: 'esc-010',
  ticketNumber: 'CDGS-2024-ESC010',
  title: 'Password Reset Request - Downgrade to Tier1',
  status: 'closed', // ปิดแล้ว
  escalationChain: [
    {
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-005',
      escalatedByName: 'ธัญญาพร ทองแก้ว',
      reason: 'ลูกค้าร้องขอส่งต่อ (ผิดพลาด)'
    },
    {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-007', // 诰ณิต ประคองเพ็ชร (Tier2)
      escalatedByName: '诰ณิต ประคองเพ็ชร',
      reason: 'ส่งต่อผิดพลาด - ควรเป็นงานของ Tier1'
    },
    {
      fromTier: 'tier3',
      toTier: 'tier1',
      escalatedBy: 'user-010', // วีระกร เยือกเย็น (Tier3)
      escalatedByName: 'วีระกร เยือกเย็น',
      reason: 'งานรีเซ็ตรหัสผ่านธรรมดา - ส่งกลับ Tier1 ดำเนินการ'
    }
  ],
  resolvedAt: new Date(...),
  closedAt: new Date(...),
  closedBy: 'user-004' // Tier1 ปิดเคส
}
```

**ผลลัพธ์:**
- ✅ **user-007 (Tier2)** ควรเห็นเคสนี้ในเมนู "แก้ไขแล้ว" เพราะส่งต่อไป Tier3
- ✅ **user-010 (Tier3)** ควรเห็นเคสนี้ในเมนู "แก้ไขแล้ว" เพราะส่งกลับ Tier1 เพื่อปิด

---

#### **2. CDGS-2024-ESC009: Performance Tuning**
```javascript
{
  id: 'esc-009',
  ticketNumber: 'CDGS-2024-ESC009',
  title: 'Performance Tuning - Downgrade to Tier2',
  status: 'tier2', // ยังไม่ปิด - Tier2 กำลังทำ
  escalationChain: [
    {
      fromTier: 'tier1',
      toTier: 'tier2',
      escalatedBy: 'user-003',
      escalatedByName: 'วรรณภา แซ่ด่าง',
      reason: 'ต้องการปรับแต่ง Database Performance'
    },
    {
      fromTier: 'tier2',
      toTier: 'tier3',
      escalatedBy: 'user-006', // ยุทธนา คณามิ่งมงคล (Tier2)
      escalatedByName: 'ยุทธนา คณามิ่งมงคล',
      reason: 'ขอความเห็นจาก DBA Specialist'
    },
    {
      fromTier: 'tier3',
      toTier: 'tier2',
      escalatedBy: 'user-009', // พุทธจักษ์ วงค์พันธ์ (Tier3)
      escalatedByName: 'พุทธจักษ์ วงค์พันธ์',
      reason: 'ไม่ซับซ้อนมาก Tier2 ดำเนินการต่อได้'
    }
  ]
}
```

**ผลลัพธ์:**
- ❌ **user-006 (Tier2)** ไม่เห็นในเมนู "แก้ไขแล้ว" เพราะยังไม่ปิด
- ❌ **user-009 (Tier3)** ไม่เห็นในเมนู "แก้ไขแล้ว" เพราะยังไม่ปิด
- ✅ แต่ถ้าปิดแล้ว (status = resolved/closed) จะเห็นในเมนู "แก้ไขแล้ว"

---

## ✅ วิธีแก้ไข

### **ไฟล์:** `/components/TicketListPage.tsx`

#### **Logic เดิม (บรรทัด 350-385):**
```typescript
if (currentPath === '/admin/resolved') {
  // ✅ กรองเฉพาะ status: resolved, closed
  if (ticket.status !== 'resolved' && ticket.status !== 'closed') {
    return false;
  }
  
  // ✅ ตรวจสอบว่า user ที่ login เป็นคนแก้ไข (resolvedBy) หรือปิด (closedBy) เคสนี้หรือไม่
  const isResolvedByMe = ticket.resolvedBy === user?.id;
  const isClosedByMe = ticket.closedBy === user?.id;
  const isAssignedToMe = ticket.assignedTo === user?.id;
  
  if (!isResolvedByMe && !isClosedByMe && !isAssignedToMe) {
    return false; // ❌ ไม่แสดง
  }
  
  return true; // ✅ แสดง
}
```

**ปัญหา:** ไม่ตรวจสอบว่า Tier2-3 ส่งกลับ Tier1 หรือไม่

---

#### **Logic ใหม่ (แยก Tier1 และ Tier2-3):**
```typescript
if (currentPath === '/admin/resolved') {
  // ✅ กรองเฉพาะ status: resolved, closed
  if (ticket.status !== 'resolved' && ticket.status !== 'closed') {
    return false;
  }
  
  // ✅ Check if Pure Admin (admin without tier roles)
  const hasTierRole = user?.roles?.some(role => ['tier1', 'tier2', 'tier3'].includes(role)) || false;
  const isPureAdmin = user?.role === 'admin' && !hasTierRole;
  
  if (isPureAdmin) {
    // Pure Admin: Monitor All - แสดงเคสของทุกคน (Tier1/2/3)
    return true;
  }
  
  // ✅ Check if user is Tier1 (can close cases)
  const isTier1 = hasRole(user, 'tier1');
  
  if (isTier1) {
    // Tier1: แสดงเคสที่ตัวเองแก้ไข (resolvedBy) หรือปิด (closedBy)
    const isResolvedByMe = ticket.resolvedBy === user?.id;
    const isClosedByMe = ticket.closedBy === user?.id;
    const isAssignedToMe = ticket.assignedTo === user?.id; // fallback
    
    if (!isResolvedByMe && !isClosedByMe && !isAssignedToMe) {
      return false;
    }
  } else {
    // Tier2-3: ✅ ไม่สามารถปิดเคสเองได้ (closedBy ไม่เคยเป็น Tier2-3)
    // แสดงเฉพาะเคสที่:
    // 1. ตัวเองแก้ไข (resolvedBy = ตัวเอง)
    // 2. ส่งกลับ Tier1 เพื่อปิด (escalationChain: tier2/tier3 → tier1)
    
    const isResolvedByMe = ticket.resolvedBy === user?.id;
    
    // ✅ ตรวจสอบว่า Tier2-3 ส่งกลับไป Tier1 เพื่อปิดหรือไม่
    const hasSentBackToTier1 = ticket.escalationChain?.some(chain => {
      // Tier2 → Tier1 หรือ Tier3 → Tier1
      const isSentBackToTier1 = (chain.fromTier === 'tier2' || chain.fromTier === 'tier3') && 
                                 chain.toTier === 'tier1' && 
                                 chain.escalatedBy === user?.id;
      return isSentBackToTier1;
    });
    
    if (!isResolvedByMe && !hasSentBackToTier1) {
      return false; // ❌ ไม่แสดง
    }
  }
  
  return true; // ✅ แสดง
}
```

**สำคัญ:**
- ✅ Tier1: ตรวจสอบ `resolvedBy`, `closedBy`, `assignedTo`
- ✅ Tier2-3: ตรวจสอบ `resolvedBy` และ `hasSentBackToTier1` เท่านั้น
- ❌ Tier2-3: **ไม่ตรวจสอบ closedBy** เพราะปิดเคสไม่ได้อยู่แล้ว

---

## 📊 ตารางเปรียบเทียบ

| เงื่อนไข | เดิม | ใหม่ |
|---------|------|------|
| **Tier1: resolvedBy = user** | ✅ แสดง | ✅ แสดง |
| **Tier1: closedBy = user** | ✅ แสดง | ✅ แสดง |
| **Tier2-3: resolvedBy = user** | ✅ แสดง | ✅ แสดง |
| **Tier2-3: closedBy = user** | ✅ แสดง | ❌ ไม่แสดง (เพราะปิดไม่ได้) |
| **Tier2-3: ส่งกลับ Tier1** | ❌ ไม่แสดง | ✅ แสดง (status = 'tier1', 'resolved', 'closed') |

### **สถานะที่แสดงในเมนู "แก้ไขแล้ว":**

| Role | Status ที่แสดง |
|------|---------------|
| **Tier1** | `'resolved'`, `'closed'` |
| **Tier2** | `'tier1'` (ถ้าส่งกลับ Tier1), `'resolved'`, `'closed'` |
| **Tier3** | `'tier1'` (ถ้าส่งกลับ Tier1), `'resolved'`, `'closed'` |
| **Admin (Pure)** | `'resolved'`, `'closed'` |

---

## 🧪 การทดสอบ

### **Test Case 1: Tier3 ส่งกลับ Tier1 (เคสปิดแล้ว)**
```bash
1. Login: user-010 (วีระกร เยือกเย็น - Tier3)
2. Navigate: เมนู "แก้ไขแล้ว"
3. ✅ ควรเห็น: CDGS-2024-ESC010 (ส่งกลับ Tier1 และ Tier1 ปิดแล้ว)
4. เคสนี้มี escalationChain:
   - fromTier: 'tier3', toTier: 'tier1', escalatedBy: 'user-010'
5. status: 'closed'
```

**ผลลัพธ์:**
- ✅ **แสดงเคส** เพราะ user-010 ส่งกลับ Tier1 และเคสปิดแล้ว

---

### **Test Case 2: Tier2 ส่งต่อ Tier3 (เคสปิดแล้ว)**
```bash
1. Login: user-007 (诰ณิต ประคองเพ็ชร - Tier2)
2. Navigate: เมนู "แก้ไขแล้ว"
3. ✅ ควรเห็น: CDGS-2024-ESC010 (ส่งต่อ Tier3 และ Tier3 ส่งกลับ Tier1 และ Tier1 ปิดแล้ว)
4. เคสนี้มี escalationChain:
   - fromTier: 'tier2', toTier: 'tier3', escalatedBy: 'user-007'
   - fromTier: 'tier3', toTier: 'tier1', escalatedBy: 'user-010'
5. status: 'closed'
```

**ผลลัพธ์:**
- ❌ **ไม่แสดงเคส** เพราะ user-007 ไม่ได้ส่งกลับ Tier1 (ส่งต่อ Tier3)
- ❓ **อาจต้องเพิ่ม logic** ให้ Tier2 เห็นเคสที่ส่งต่อ Tier3 แล้ว Tier3 ส่งกลับ Tier1

---

### **Test Case 3: Tier3 ส่งกลับ Tier2 (เคสยังไม่ปิด)**
```bash
1. Login: user-009 (พุทธจักษ์ วงค์พันธ์ - Tier3)
2. Navigate: เมนู "แก้ไขแล้ว"
3. ❌ ไม่ควรเห็น: CDGS-2024-ESC009 (ส่งกลับ Tier2 แต่ยังไม่ปิด)
4. เคสนี้มี:
   - status: 'tier2' (ยังไม่ปิด)
   - escalationChain: fromTier: 'tier3', toTier: 'tier2', escalatedBy: 'user-009'
```

**ผลลัพธ์:**
- ❌ **ไม่แสดงเคส** เพราะ status ไม่ใช่ 'resolved' หรือ 'closed'
- ✅ **ถูกต้อง** - เมนู "แก้ไขแล้ว" แสดงเฉพาะเคสที่ปิดแล้ว

---

### **Test Case 4: Tier1 ที่รับเคสกลับมา**
```bash
1. Login: user-004 (เขมิกา แซ่ตั้ง - Tier1)
2. Navigate: เมนู "แก้ไขแล้ว"
3. ✅ ควรเห็น: CDGS-2024-ESC010 (ตัวเองปิดเคส)
4. เคสนี้มี:
   - closedBy: 'user-004'
   - status: 'closed'
```

**ผลลัพธ์:**
- ✅ **แสดงเคส** เพราะ closedBy = user-004

---

## 🎯 สรุปการเปลี่ยนแปลง

### **การแสดงผลในเมนู "แก้ไขแล้ว":**

| Role | เงื่อนไขการแสดง |
|------|----------------|
| **Tier1** | 1. resolvedBy = ตัวเอง<br>2. closedBy = ตัวเอง<br>3. assignedTo = ตัวเอง (fallback) |
| **Tier2** | 1. resolvedBy = ตัวเอง<br>2. **ส่งกลับ Tier1 โดยตัวเอง** (เพิ่มใหม่)<br>3. ❌ ไม่ตรวจสอบ closedBy (ปิดเคสไม่ได้) |
| **Tier3** | 1. resolvedBy = ตัวเอง<br>2. **ส่งกลับ Tier1 โดยตัวเอง** (เพิ่มใหม่)<br>3. ❌ ไม่ตรวจสอบ closedBy (ปิดเคสไม่ได้) |
| **Admin (Pure)** | แสดงทุกเคส (Monitor mode) |

### **หมายเหตุ:**
- ✅ เคสต้องมี status = 'resolved' หรือ 'closed' เท่านั้น
- ✅ Tier2-3 จะเห็นเคสที่ส่งกลับ Tier1 เพื่อให้ติดตามสถานะ
- ❌ ไม่แสดงเคสที่ยังไม่ปิด (status = tier1, tier2, tier3, in_progress, waiting)

---

## 📝 หมายเหตุเพิ่มเติม

### **เกี่ยวกับ Escalation Chain:**
```typescript
interface EscalationChainItem {
  fromTier: 'tier1' | 'tier2' | 'tier3';
  toTier: 'tier1' | 'tier2' | 'tier3';
  escalatedBy: string; // userId
  escalatedByName: string;
  escalatedAt: Date;
  reason?: string;
}
```

### **ตัวอย่างการส่งกลับ Tier1:**
```javascript
// Tier3 → Tier1
{
  fromTier: 'tier3',
  toTier: 'tier1',
  escalatedBy: 'user-010', // Tier3 user ID
  escalatedByName: 'วีระกร เยือกเย็น',
  escalatedAt: new Date(...),
  reason: 'งานรีเซ็ตรหัสผ่านธรรมดา - ส่งกลับ Tier1 ดำเนินการ'
}

// Tier2 → Tier1
{
  fromTier: 'tier2',
  toTier: 'tier1',
  escalatedBy: 'user-007', // Tier2 user ID
  escalatedByName: '诰ณิต ประคองเพ็ชร',
  escalatedAt: new Date(...),
  reason: 'แก้ไขแล้ว ส่งกลับ Tier1 เพื่อปิดเคส'
}
```

---

## 🚀 การพัฒนาในอนาคต (Optional)

### **คำถาม:**
Tier2 ที่ส่งต่อ Tier3 แล้ว Tier3 ส่งกลับ Tier1 - Tier2 ควรเห็นเคสนี้หรือไม่?

**ตัวอย่าง:**
- Tier1 → Tier2 (user-005)
- Tier2 → Tier3 (user-007) ✅ ส่งต่อ
- Tier3 → Tier1 (user-010) ✅ ส่งกลับ
- Tier1 ปิดเคส (user-004)

**คำถาม:** user-007 (Tier2) ควรเห็นเคสนี้ในเมนู "แก้ไขแล้ว" หรือไม่?

**แนวทาง:**
1. **ไม่เห็น** - เพราะ Tier3 เป็นคนส่งกลับ Tier1 ไม่ใช่ Tier2
2. **เห็น** - เพราะ Tier2 มีส่วนร่วมในเคสนี้ (ส่งต่อ Tier3)

**ตัดสินใจ:**
- ✅ **ไม่เห็น** (เป็น default)
- ถ้าต้องการให้เห็น ต้องเพิ่ม logic ตรวจสอบ stakeholders หรือ escalationChain ทั้งหมด

---

**Updated:** 14 มกราคม 2026  
**Status:** ✅ เสร็จสิ้น  
**Note:** เพิ่ม logic `hasSentBackToTier1` เพื่อให้ Tier2-3 เห็นเคสที่ส่งกลับ Tier1 แล้วในเมนู "แก้ไขแล้ว"
