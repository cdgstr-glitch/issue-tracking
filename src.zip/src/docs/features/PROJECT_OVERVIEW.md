# 📋 CDGS Issue Tracking Platform - ภาพรวมโครงการ

## 🎯 วัตถุประสงค์

ระบบ **CDGS Issue Tracking Platform** เป็นแพลตฟอร์มระดับองค์กรสำหรับติดตามและจัดการเคสจากลูกค้า โดยรวมช่องทางการสนับสนุนหลายช่องทาง (Multi-Channel) เข้าเป็นระบบตั๋วเดียวกับเวิร์กโฟลว์การส่งต่อสามระดับ (Tier 1 → Tier 2 → Tier 3)

---

## 🌟 คุณสมบัติหลัก

### 1. **Multi-Channel Support**
- ✅ Web Portal (ลูกค้าสร้างเคสเอง)
- ✅ Phone (Staff บันทึกแทนลูกค้า)
- ✅ Email (Staff บันทึกแทนลูกค้า)
- ✅ Line (Staff บันทึกแทนลูกค้า)

### 2. **Multi-Role System**
- ✅ คนหนึ่งมีได้ **หลาย role** พร้อมกัน
- ✅ ตัวอย่าง: คนเดียวกันสามารถเป็น `admin` + `tier1` + `staff` พร้อมกัน
- ✅ UI ปรับตาม role ที่มี (Sidebar vs Landing Page)

### 3. **3-Tier Escalation Workflow**
```
Customer/Staff สร้างเคส
       ↓
   Tier 1 (รับเคส)
       ↓
   Tier 2 (ปัญหาซับซ้อน)
       ↓
   Tier 3 (ปัญหาซับซ้อนมาก)
```

### 4. **Symmetric Escalation (สมมาตร)**
- ✅ ส่งต่อได้ทุกทิศทาง:
  - Tier1 ⇄ Tier2 ⇄ Tier3
  - Tier1 → Tier2, Tier2 → Tier1
  - Tier2 → Tier3, Tier3 → Tier2
  - Tier1 → Tier3 (ข้ามระดับ)
  - ส่งต่อคนอื่นใน Tier เดียวกัน

### 5. **Inverted Visibility Model**
- ✅ Tier1 เห็นเคสมากสุด (new, tier1, tier2, tier3, in_progress, etc.)
- ✅ Tier2 เห็นน้อยลง (tier2, tier3, in_progress, etc.)
- ✅ Tier3 เห็นน้อยสุด (tier3, in_progress, etc.)
- ✅ วัตถุประสงค์: Tier ที่สูงกว่าไม่ต้องเห็นเคสที่ไม่เกี่ยวข้อง

### 6. **Manual Case Assignment**
- ✅ **ไม่มีการรับเคสอัตโนมัติ**
- ✅ ทุกคนต้องกด **"รับเคส"** เองทุกครั้ง
- ✅ เคสจะอยู่ในสถานะ `new`, `tier1`, `tier2`, `tier3` จนกว่าจะมีคนกดรับ

### 7. **Pause Feature**
- ✅ มีปุ่ม **"หยุดชั่วคราว"**
- ✅ เปลี่ยน status เป็น `waiting`
- ✅ ใช้เมื่อรอข้อมูลจากลูกค้า หรือรอทีมอื่น

### 8. **Multi-Project Support**
- ✅ คนหนึ่งทำงานได้หลายโครงการ
- ✅ แต่ละโครงการมีบทบาทที่แตกต่างกัน
- ✅ ตัวอย่าง: โครงการ A เป็น Tier1, โครงการ B เป็น Admin

---

## 👥 6 บทบาท (Roles)

### 1. **Customer** (ลูกค้า)
- สร้างเคสผ่าน Web Portal
- ติดตามเคสของตัวเอง
- เพิ่มความคิดเห็น

### 2. **Staff** (เจ้าหน้าที่รับเรื่อง)
- บันทึกเคสแทนลูกค้า (Phone/Email/Line)
- เลือกได้: **"แก้ไขและปิดเคส"** หรือ **"ส่งงาน"** ต่อ Tier1
- ไม่ได้อยู่ใน Tier Workflow
- UI: **Landing Page** (ไม่มี Sidebar)

### 3. **Tier1** (Support Level 1)
- รับเคสใหม่ทั้งหมด (new status)
- รับเคสที่ส่งกลับมาจาก Tier2/3
- แก้ไขปัญหาทั่วไป
- ส่งต่อ Tier2/3 ถ้าปัญหาซับซ้อน
- เห็นเคสมากสุด (Inverted Visibility)

### 4. **Tier2** (Support Level 2)
- รับเคสที่ Tier1 ส่งต่อมา
- แก้ไขปัญหาที่ซับซ้อนกว่า
- ส่งต่อ Tier3 หรือส่งกลับ Tier1
- เห็นเคสน้อยกว่า Tier1

### 5. **Tier3** (Support Level 3)
- รับเคสที่ซับซ้อนที่สุด
- Expert level
- ส่งกลับ Tier2 หรือ Tier1
- เห็นเคสน้อยสุด

### 6. **Admin** (ผู้ดูแลระบบ)
- **Pure Admin**: แก้ไขเคสไม่ได้, Monitor อย่างเดียว (Read-only)
- **Admin + Tier1**: แก้ไขเคสได้ + Monitor ได้
- จัดการผู้ใช้, โครงการ, การตั้งค่า
- ดูรายงาน, สถิติ

---

## 🔄 Status Lifecycle

```
new (เคสใหม่)
  ↓ (กด "รับเคส")
in_progress (กำลังดำเนินการ)
  ↓ (กด "หยุดชั่วคราว")
waiting (รอข้อมูล)
  ↓ (กด "ดำเนินการต่อ")
in_progress
  ↓ (กด "แก้ไขเสร็จแล้ว")
resolved (แก้ไขแล้ว - รอลูกค้าตรวจสอบ)
  ↓ (กด "ปิดเคส")
closed (ปิดเคสแล้ว)

หรือ

new → tier1/tier2/tier3 (ส่งต่อ) → in_progress → waiting → resolved → pending_closure → closed
```

---

## 🎨 ดีไซน์และ UX

### 1. **ดีไซน์มาตรฐานองค์กร**
- ✅ คล้าย Microsoft, Atlassian, ServiceNow
- ✅ Professional, Clean, Modern

### 2. **ฟอนต์**
- ✅ ใช้ฟอนต์ **Anuphan** ทั้งระบบ

### 3. **ภาษา**
- ✅ **ภาษาไทย** ทั้งระบบ

### 4. **คำศัพท์**
- ✅ "งาน" → **"เคส"**
- ✅ "หัวข้อ" → **"หัวเรื่อง"**
- ✅ "เคสของฉัน" → **"งานของฉัน"**

### 5. **UI แบบต่าง ๆ**
- **Sidebar Navigation**: Admin, Tier1, Tier2, Tier3
- **Landing Page**: Staff (3 ปุ่มหลัก)
- **Simple Page**: Customer

---

## 🔐 Key Security Features

- ✅ Role-Based Access Control (RBAC)
- ✅ Multi-Project Isolation
- ✅ Permission Matrix สำหรับทุก Role
- ✅ Read-only vs Read/Write permissions

---

## 📊 Core Features

### 1. **Staff Workflow**
```
Staff สร้างเคส → เลือก:
├── "แก้ไขและปิดเคส" (ปิดทันที, ไม่ผ่าน Tier)
└── "ส่งงาน" (ส่งต่อ Tier1)
```

### 2. **Tier Workflow**
```
เคสใหม่ (new) → Tier1 กด "รับเคส"
  → in_progress → แก้ไข
  → เลือก:
     ├── "ปิดเคส" (เสร็จแล้ว)
     ├── "ส่งต่อ Tier2" (ปัญหาซับซ้อน)
     ├── "ส่งต่อ Tier3" (ปัญหาซับซ้อนมาก)
     └── "หยุดชั่วคราว" (รอข้อมูล)
```

### 3. **Customer Workflow**
```
Customer สร้างเคส (web) → Tier1 รับ → แก้ไข → ปิด
```

---

## 📈 การติดตามและรายงาน

### 1. **Staff Performance Tracking**
- ✅ เมนู **"เคสที่ปิดย้อนหลัง"** (Tier1/Admin เห็น)
- ✅ แสดงเคสที่ Staff สร้างและปิด (Phone/Email/Line)
- ✅ แบ่งประเภท: "Staff ปิดเอง" vs "ผ่าน Tier System"
- ✅ กรองตาม Staff แต่ละคน → ระบุ High Performer

### 2. **Team Performance Monitoring**
- ✅ เมนู **"แก้ไขแล้ว (Monitor)"** (Admin เห็น)
- ✅ แสดงเคสที่ทุกคน (Tier1/2/3) resolve/close
- ✅ Monitor performance ทั้งทีม

### 3. **Bottleneck Detection**
- ✅ เมนู **"รอดำเนินการ (Monitor)"** (Admin เห็น)
- ✅ แสดงเคสที่ยังไม่มีคนรับ
- ✅ ระบุจุดคอขวด

---

## 🚀 Technical Stack

- **Frontend**: React + TypeScript
- **Styling**: Tailwind CSS v4.0
- **Font**: Anuphan (ภาษาไทย)
- **Language**: ภาษาไทยทั้งระบบ

---

## 📌 Important Notes

### 1. **Pure Admin vs Admin + Tier**
- **Pure Admin**: มีแค่ role `admin` → ไม่รับเคส, ไม่แก้ไข, Monitor อย่างเดียว
- **Admin + Tier1**: มี role `admin` + `tier1` → รับเคสได้, แก้ไขได้, Monitor ได้

### 2. **Staff ไม่ใช่ Tier**
- Staff ไม่ได้อยู่ในระบบ Tier
- Staff บันทึกเคสแทนลูกค้า → ส่งต่อ Tier1 หรือปิดเลย
- Staff ไม่มีเมนู "งานของฉัน" หรือ "เคสที่ฉันส่งต่อ"

### 3. **เคสที่ปิดแล้ว ไม่ซ้ำซ้อน**
- "ติดตามเคส" (Staff) → ไม่รวม closed
- "เคสที่ปิดย้อนหลัง" (Staff) → เฉพาะ closed
- "งานของฉัน" (Tier) → ไม่รวม closed
- "แก้ไขแล้ว" (Tier) → รวม closed

### 4. **การส่งต่อ (Escalation)**
- ทุก Tier สามารถส่งต่อได้ทุกทิศทาง (Symmetric)
- บันทึกใน "เคสที่ฉันส่งต่อ"
- ติดตามว่าเคสที่ส่งไปเป็นอย่างไร

---

## 📝 Changelog

- **2024-12-25**: สร้างเอกสารฉบับแรก
  - กำหนด 6 Roles
  - Navigation Menu สำหรับทุก Role
  - Permission Matrix
  - Workflow แบบ Symmetric

---

**เอกสารนี้เป็น Single Source of Truth สำหรับโครงการ CDGS Issue Tracking Platform**

อ่านเอกสารอื่น ๆ:
- [Navigation Menu](/docs/features/NAVIGATION_MENU.md)
- [Permission Matrix](/docs/technical/PERMISSION_MATRIX.md)
- [Workflow](/docs/features/WORKFLOW.md)
