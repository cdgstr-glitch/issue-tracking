# 📋 การอัปเดตบทบาท Staff (21 มกราคม 2026)

**สถานะ:** ✅ เสร็จสมบูรณ์  
**วันที่อัปเดต:** 21 มกราคม 2026  
**ผู้ดำเนินการ:** CDGS Development Team

---

## 🎯 ภาพรวมการเปลี่ยนแปลง

จากการประชุมเมื่อวาน ได้มีการตัดสินใจลดขอบเขตบทบาท **Staff** ให้เหลือเพียง:

### ✅ บทบาทใหม่ของ Staff:
**"บันทึกเคสแทนลูกค้าเท่านั้น"**

### ❌ สิ่งที่ลบออก:
1. **ไม่มี action buttons** หลังจากบันทึกเคสแล้ว (เคสเป็น read-only)
2. **ไม่มีเมนู "เคสที่ปิดย้อนหลัง"** (ลบออกจาก Sidebar และ HomePage)
3. **ไม่มีปุ่ม "ดูเคสที่ปิดย้อนหลัง"** ในหน้าต่างๆ

---

## 📝 รายละเอียดการเปลี่ยนแปลง

### **1. บทบาท Staff ใหม่**

| ฟีเจอร์ | ก่อนอัปเดต | หลังอัปเดต |
|---------|-----------|-----------|
| **บันทึกเคสแทนลูกค้า** | ✅ ได้ | ✅ ได้ |
| **ติดตามเคส** | ✅ ได้ | ✅ ได้ (Read-only) |
| **แก้ไข/แสดงความเห็นในเคส** | ✅ ได้ | ❌ **ลบออก** |
| **ปิดเคส** | ✅ ได้ | ❌ **ลบออก** |
| **ดูเคสที่ปิดย้อนหลัง** | ✅ ได้ | ❌ **ลบออก** |

### **2. Workflow ใหม่ของ Staff**

```
ลูกค้าติดต่อมา (Phone/Email/Line)
         ↓
Staff บันทึกเคสในระบบ (/create)
         ↓
   เลือก 1 ใน 2 (Pure Staff):
   ├─ ✅ แก้ไขและปิดเคส → ปิดทันที (closed)
   └─ 📤 ส่งงาน → ส่งต่อ Tier1 (new)
         ↓
Staff ติดตามสถานะ (/track) - Read-only
         ↓
        จบ
```

### **🆕 3. Workflow ใหม่ของ Tier1 + Staff (Multi-role)**

```
ลูกค้าติดต่อมา (Phone/Email/Line)
         ↓
Tier1 + Staff บันทึกเคสในระบบ (/create)
         ↓
   เลือก 1 ใน 3:
   ├─ ✅ แก้ไขและปิดเคส → ปิดทันที (closed)
   ├─ 📤 ส่งงาน → ส่งต่อ Tier1 (new)
   └─ 📥 บันทึกและรับเคส → รับเคสทันที (tier1) ⭐ ใหม่!
         ↓
   (กรณีเลือก "บันทึกและรับเคส")
         ↓
   Auto-redirect → /admin/my-tickets
         ↓
   เริ่มดำเนินการเคสทันที
         ↓
        จบ
```

**ประโยชน์ของ "บันทึกและรับเคส":**
- ✅ ลด workflow จาก **2 ขั้นตอน → 1 ขั้นตอน**
- ✅ ไม่ต้องออกไปเมนู "รอดำเนินการ" อีก
- ✅ ไม่ต้องคลิกเข้าเคสและกด "รับเคส" อีกครั้ง
- ✅ เคสถูก assigned ให้ตัวเองทันที

**ไม่มีขั้นตอน:**
- ❌ ไม่มีการแก้ไขเคสหลังบันทึก
- ❌ ไม่มีการปิดเคสหลังบันทึก
- ❌ ไม่มีการดูเคสที่ปิดย้อนหลัง

---

## 🛠️ ไฟล์ที่แก้ไข

### **1. `/App.tsx`**
**การเปลี่ยนแปลง:**
- ❌ ลบปุ่ม "ดูเคสที่ปิดย้อนหลัง" จาก Demo Menu สำหรับ Staff (บรรทัด 255-261)
- ❌ **ลบ route `/closed-tickets`** ออกจากระบบ (บรรทัด 626-642)

**โค้ดก่อนแก้:**
```typescript
// Staff Closed Tickets route
if (currentRoute.path === '/closed-tickets') {
  if (currentRoute.ticketId) {
    return (
      <ProtectedRoute>
        <StaffClosedTicketDetailPage ticketId={currentRoute.ticketId} onNavigate={navigate} />
      </ProtectedRoute>
    );
  } else {
    return (
      <ProtectedRoute>
        <StaffClosedTicketsPage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
      </ProtectedRoute>
    );
  }
}
```

**โค้ดหลังแก้:**
```typescript
// ❌ ลบ route /closed-tickets - Staff ไม่มีสิทธิ์ดูเคสที่ปิดย้อนหลัง (21 ม.ค. 2026)
```

---

### **2. `/components/StaffHomePage.tsx`**
**การเปลี่ยนแปลง:**
- ❌ ลบปุ่ม "ดูเคสที่ปิดย้อนหลัง" (บรรทัด 75-83)

**โค้ดก่อนแก้:**
```typescript
<Button 
  size="lg" 
  variant="outline" 
  onClick={() => onNavigate('/closed-tickets')} 
  className="text-base border-green-300 text-green-700 hover:bg-green-50"
>
  <CheckCircle className="mr-2 h-5 w-5" />
  ดูเคสที่ปิดย้อนหลัง
</Button>
```

**โค้ดหลังแก้:**
```typescript
{/* ❌ ลบปุ่ม "ดูเคสที่ปิดย้อนหลัง" - Staff บันทึกเคสแทนลูกค้าเท่านั้น (21 ม.ค. 2026) */}
```

---

### **3. `/components/CreateTicketPage.tsx`**
**การเปลี่ยนแปลง:**
- ❌ ลบข้อความ "✓ คุณสามารถดูเคสที่ปิดย้อนหลังได้ทุกเวลา" (บรรทัด 255-257)
- ❌ ลบปุ่ม "📋 เคสที่ปิดย้อนหลัง" (บรรทัด 261-280)
- 🆕 **เพิ่มปุ่ม "📥 บันทึกและรับเคส"** สำหรับ Tier1 + Staff

**โค้ดก่อนแก้:**
```typescript
{/* Submit Button */}
<div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
  <Button type="button" variant="outline" onClick={() => onNavigate('/')}>
    ยกเลิก
  </Button>
  {hasRole(user, 'staff') && (
    <Button onClick={handleSolveAndClose}>
      ✅ แก้ไขและปิดเคส
    </Button>
  )}
  <Button type="submit" size="lg">
    ส่งงาน
  </Button>
</div>
```

**โค้ดหลังแก้:**
```typescript
{/* Submit Buttons */}
<div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
  <Button type="button" variant="outline" onClick={() => onNavigate('/')}>
    ยกเลิก
  </Button>
  
  {/* ปุ่มที่ 1: แก้ไขและปิดเคส - สำหรับ Staff (ทุกคน) */}
  {hasRole(user, 'staff') && (
    <Button onClick={handleSolveAndClose}>
      ✅ แก้ไขและปิดเคส
    </Button>
  )}
  
  {/* ปุ่มที่ 2: ส่งงาน - สำหรับ Staff (ทุกคน) */}
  <Button type="submit" size="lg">
    ส่งงาน
  </Button>
  
  {/* ปุ่มที่ 3: บันทึกและรับเคส - สำหรับ Tier1 + Staff เท่านั้น */}
  {hasRole(user, 'staff') && hasRole(user, 'tier1') && (
    <Button 
      type="button" 
      size="lg"
      className="bg-blue-600 hover:bg-blue-700 text-white"
      onClick={handleSaveAndAccept}
    >
      📥 บันทึกและรับเคส
    </Button>
  )}
</div>
```

**🆕 ฟีเจอร์ใหม่:**
- เพิ่ม state `ticketAccepted` สำหรับ "บันทึกและรับเคส"
- เพิ่มฟังก์ชัน `handleSaveAndAccept()` 
- สร้าง Success Page ที่ auto-redirect ไป `/admin/my-tickets` หลัง 2 วินาที
- เคสจะถูก assigned ให้ตัวเอง และเปลี่ยน status = `tier1`

---

## 📊 สรุปการเปลี่ยนแปลง

| ส่วน | การเปลี่ยนแปลง | ไฟล์ |
|------|----------------|------|
| **Route** | ❌ ลบ route `/closed-tickets` ออกจากระบบ | `/App.tsx` |
| **Demo Menu** | ❌ ลบปุ่ม "ดูเคสที่ปิดย้อนหลัง" สำหรับ Staff | `/App.tsx` |
| **HomePage** | ❌ ลบปุ่ม "ดูเคสที่ปิดย้อนหลัง" | `/components/StaffHomePage.tsx` |
| **Success Page** | ❌ ลบข้อความและปุ่ม "เคสที่ปิดย้อนหลัง" | `/components/CreateTicketPage.tsx` |
| **Create Page** | 🆕 เพิ่มปุ่ม "📥 บันทึกและรับเคส" (Tier1 + Staff) | `/components/CreateTicketPage.tsx` |

**หมายเหตุ:** Staff ไม่มี Sidebar (ใช้ Landing Page แบบเดียวกับ Customer)

---

## 🎯 บทบาท Staff หลังอัปเดต

### ✅ **สิ่งที่ Pure Staff ทำได้:**

1. **บันทึกเคสแทนลูกค้า** (`/create`)
   - กรอกข้อมูลลูกค้า
   - เลือกช่องทาง (Line/Phone/Email)
   - บันทึกประเภทปัญหาและความสำคัญ
   - บันทึกย้อนหลัง (Incident Date)
   - เลือก 1 ใน 2:
     - ✅ แก้ไขและปิดเคส
     - 📤 ส่งงาน (ส่งต่อ Tier1)

2. **ติดตามเคส** (`/track`)
   - ดูเคสที่ตัวเองสร้าง (Read-only)
   - ติดตาม Timeline
   - **ไม่สามารถแก้ไข/แสดงความเห็น**

---

### ✅ **สิ่งที่ Tier1 + Staff (Multi-role) ทำได้:**

1. **บันทึกเคสแทนลูกค้า** (`/create`)
   - กรอกข้อมูลลูกค้า
   - เลือกช่องทาง (Line/Phone/Email)
   - บันทึกประเภทปัญหาและความสำคัญ
   - บันทึกย้อนหลัง (Incident Date)
   - เลือก 1 ใน 3: ⭐ **เพิ่มทางเลือกใหม่!**
     - ✅ แก้ไขและปิดเคส
     - 📤 ส่งงาน (ส่งต่อ Tier1)
     - 📥 **บันทึกและรับเคส** (ใหม่!) → รับเคสทันที และไปหน้า "งานของฉัน"

2. **ติดตามเคส** (`/track`)
   - ดูเคสที่ตัวเองสร้าง (Read-only)
   - ติดตาม Timeline
   - **ไม่สามารถแก้ไข/แสดงความเห็น**

3. **จัดการเคสใน Admin** (`/admin/*`)
   - ดำเนินการเคสที่รับแล้ว
   - ส่งต่อ, ปิดเคส, แสดงความเห็น
   - ดูเคสที่ปิดย้อนหลัง (Admin section)

---

### ❌ **สิ่งที่ Staff ทำไม่ได้ (เปลี่ยนแปลง):**

1. ❌ **ดูเคสที่ปิดย้อนหลัง** - ลบฟีเจอร์นี้ออกแล้ว (ในส่วน Staff Landing Page)
2. ❌ **แก้ไขเคสหลังบันทึก** - เคสเป็น read-only
3. ❌ **ปิดเคสหลังบันทึก** - ไม่มีปุ่ม action
4. ❌ **แสดงความเห็นในเคส** - ไม่มีฟอร์มแสดงความเห็น (ในหน้า `/track`)

---

## 📚 เอกสารที่ต้องอัปเดต

### ✅ **เอกสารที่อัปเดตแล้ว:**
1. `/STAFF_ROLE_UPDATE_2026-01-21.md` - เอกสารนี้
2. `/App.tsx` - ลบ route `/closed-tickets` และปุ่มใน Demo Menu
3. `/components/StaffHomePage.tsx` - ลบปุ่ม
4. `/components/CreateTicketPage.tsx` - ลบข้อความและปุ่ม

**หมายเหตุ:** ไม่ได้แก้ไข `/components/Sidebar.tsx` เพราะ Staff ไม่ใช้ Sidebar

---

## ✅ Testing Checklist

### **1. ทดสอบ Sidebar (Tier1 + Staff)**
- [ ] Login ด้วย Tier1 ที่มี Staff role (เช่น ธิราภรณ์, สาริน)
- [ ] ไปที่ `/admin`
- [ ] ตรวจสอบว่า **ไม่มีเมนู "เคสที่ปิดย้อนหลัง"** ใน Sidebar

### **2. ทดสอบ Demo Menu (Staff)**
- [ ] Login ด้วย Staff (`staff` / `staff123`)
- [ ] ไปที่ Demo Menu
- [ ] ตรวจสอบว่า **ไม่มีปุ่ม "ดูเคสที่ปิดย้อนหลัง"** ใน Card

### **3. ทดสอบ HomePage (Staff)**
- [ ] Login ด้วย Staff
- [ ] ไปที่ `/`
- [ ] ตรวจสอบว่า **ไม่มีปุ่ม "ดูเคสที่ปิดย้อนหลัง"**
- [ ] มีเพียง 2 ปุ่ม:
  - ✅ บันทึกเคสแทนลูกค้า
  - ✅ ติดตามเคสลูกค้าที่แจ้ง

### **4. ทดสอบ CreateTicketPage (Staff)**
- [ ] Login ด้วย Staff
- [ ] ไปที่ `/create`
- [ ] กรอกข้อมูลและกด "แก้ไขและปิดเคส"
- [ ] ตรวจสอบหน้า Success:
  - ✅ ไม่มีข้อความ "✓ คุณสามารถดูเคสที่ปิดย้อนหลังได้ทุกเวลา"
  - ✅ ไม่มีปุ่ม "📋 เคสที่ปิดย้อนหลัง"
  - ✅ มีเพียงปุ่ม "กลับหน้าหลัก" และ "บันทึกเคสใหม่"

### **🆕 4.1 ทดสอบปุ่ม "บันทึกและรับเคส" (Tier1 + Staff)**
- [ ] Login ด้วย Tier1 + Staff (เช่น ธิราภรณ์, สาริน)
- [ ] ไปที่ `/create`
- [ ] ตรวจสอบว่ามี **3 ปุ่ม**:
  - ✅ แก้ไขและปิดเคส (สีเขียว)
  - ✅ ส่งงาน (สีปกติ)
  - ✅ 📥 บันทึกและรับเคส (สีน้ำเงิน) ⭐ ใหม่!
- [ ] กรอกข้อมูลและกด "📥 บันทึกและรับเคส"
- [ ] ตรวจสอบหน้า Success:
  - ✅ แสดงข้อความ "บันทึกและรับเคสสำเร็จ"
  - ✅ แสดงข้อความ "กำลังเปลี่ยนหน้าไปยัง 'งานของฉัน'..."
  - ✅ สถานะเคส: กำลังดำเนินการ (Tier 1)
  - ✅ Auto-redirect ไป `/admin/my-tickets` หลัง 2 วินาที
  - ✅ เคสปรากฏใน "งานของฉัน" และ assigned ให้ตัวเอง

### **4.2 ทดสอบ Pure Staff (ไม่มีบทบาท Tier1)**
- [ ] Login ด้วย Pure Staff (`staff` / `staff123`)
- [ ] ไปที่ `/create`
- [ ] ตรวจสอบว่ามี **2 ปุ่ม** เท่านั้น:
  - ✅ แก้ไขและปิดเคส
  - ✅ ส่งงาน
  - ❌ **ไม่มีปุ่ม** "บันทึกและรับเคส"

### **5. ทดสอบ TrackTicketPage (Staff)**
- [ ] Login ด้วย Staff
- [ ] ไปที่ `/track`
- [ ] คลิกดูเคส
- [ ] ตรวจสอบว่า:
  - ✅ เคสเป็น read-only
  - ✅ ไม่มีปุ่ม action (แก้ไข/ปิด)
  - ✅ ไม่มีฟอร์มแสดงความเห็น

### **6. ทดสอบ Admin (Tier1/2/3/Admin)**
- [ ] Login ด้วย Admin
- [ ] ตรวจสอบว่า **ยังมีเมนู "เคสที่ปิดย้อนหลัง"** ใน Sidebar
- [ ] สามารถเข้าถึง `/admin/staff-closed-tickets` ได้ปกติ

---

## 🔄 ประวัติการอัปเดต

| วันที่ | รายละเอียด | ผู้ดำเนินการ |
|-------|-----------|-------------|
| 21 ม.ค. 2026 | **ลด scope Staff** - ลบฟีเจอร์แก้ไข/ปิดเคสและดูเคสที่ปิดย้อนหลัง | CDGS Development Team |
| 21 ม.ค. 2026 | สร้างเอกสาร STAFF_ROLE_UPDATE_2026-01-21.md | CDGS Development Team |
| 21 ม.ค. 2026 | 🆕 **เพิ่มปุ่ม "บันทึกและรับเคส"** สำหรับ Tier1 + Staff | CDGS Development Team |

---

## 📞 ติดต่อ

หากพบปัญหาหรือมีข้อสงสัย กรุณาติดต่อ:
- Email: support@cdg.co.th
- CDGS Development Team

---

**สถานะเอกสาร:** ✅ เสร็จสมบูรณ์  
**ผู้จัดทำ:** CDGS Development Team  
**อัปเดตล่าสุด:** 21 มกราคม 2026
