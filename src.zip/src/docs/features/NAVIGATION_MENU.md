# 📱 Navigation Menu - ทุก Role

## 📋 สารบัญ
1. [Pure Admin](#1-pure-admin)
2. [Tier1](#2-tier1)
3. [Tier2](#3-tier2)
4. [Tier3](#4-tier3)
5. [Staff](#5-staff)
6. [Customer](#6-customer)
7. [สรุปตาราง](#สรุปตาราง-แต่ละ-role-มีเมนูอะไรบ้าง)

---

## 1. Pure Admin

**Role:** `admin` เท่านั้น (ไม่มี tier1/2/3)

**UI Type:** Sidebar Navigation

**เมนูทั้งหมด:**

### 🏠 Dashboard
- **วัตถุประสงค์:** ภาพรวมระบบ, สถิติ, real-time metrics
- **Permission:** Read-only (Monitor)

### 📋 เคสทั้งหมด
- **แสดง:** เคสทั้งหมดในระบบ (ทุก status)
- **Permission:** Read-only
- **วัตถุประสงค์:** Monitor ภาพรวม
- **คำอธิบาย:** "เคสทั้งหมดในระบบ (Monitoring)"

### ⏳ รอดำเนินการ (Monitor)
- **แสดง:** เคส status = `new`, `tier1`, `tier2`, `tier3` ที่ยังไม่มีคนรับ
- **Permission:** Read-only
- **ไม่มีปุ่ม:** "รับเคส" (เพราะไม่รับเคส)
- **วัตถุประสงค์:** Monitor bottleneck, ติดตามเคสที่ค้างอยู่
- **คำอธิบาย:** "เคสที่ยังรอให้เจ้าหน้าที่กดรับเคส (Monitoring)"

### ✅ แก้ไขแล้ว (Monitor All)
- **แสดง:** เคสของ **ทุกคน** (Tier1/2/3)
- **Status:** `resolved`, `pending_closure`, `closed`
- **Channel:** ทุก channel (web/phone/email/line)
- **Permission:** Read-only
- **วัตถุประสงค์:** Monitor performance ทั้งทีม
- **คำอธิบาย:** "เคสที่ทีมแก้ไขและปิดแล้ว (Monitoring)"

### 📦 เคสที่ปิดย้อนหลัง
- **แสดง:** เคสที่ **Tier 1** สร้างและปิดย้อนหลัง
- **Channel:** `phone`, `email`, `line` (ไม่รวม `web`)
- **Status:** `closed` เท่านั้น
- **Permission:** Read-only
- **วัตถุประสงค์:** Monitor Tier 1 performance ในการจัดการเคสนอกระบบ Web
- **คำอธิบาย:** "เคสที่ Tier 1 บันทึกและปิดงานทันที (Retroactive)"
- **เงื่อนไขสำคัญ:** **Tier 1 เท่านั้น** ที่มีสิทธิ์เปิดและปิดเคสย้อนหลังได้ (Staff ไม่เกี่ยวข้อง)
- **ฟีเจอร์:**
  - แสดงคอลัมน์ "ปิดโดย" (Closed By)
  - กรองตาม Tier 1 แต่ละคน

### 📈 การวิเคราะห์ / Analytics
- **วัตถุประสงค์:** ดูรายงานสถิติ, Performance metrics
- **Permission:** Read/Write

### 👥 ทีม / Team
- **วัตถุประสงค์:** ดูสมาชิกในทีม, จัดการสมาชิก
- **Permission:** Read/Write

### ⚙️ การตั้งค่า / Settings
- **วัตถุประสงค์:** ตั้งค่าระบบ
- **Permission:** Read/Write

---

**ไม่มีเมนูเหล่านี้:**
- ❌ **งานของฉัน** (เพราะไม่รับเคส)
- ❌ **เคสที่ฉันส่งต่อ** (เพราะไม่รับเคส → ไม่ส่งต่อ)

---

## 2. Tier1

**Role:** `tier1` (อาจมี `admin` ด้วย)

**UI Type:** Sidebar Navigation

**เมนูทั้งหมด:**

### 🏠 Dashboard
- **วัตถุประสงค์:** ภาพรวมงาน, เคสที่รับผิดชอบ
- **Permission:** Read/Write

### 📋 เคสทั้งหมด
- **แสดง:** เคสทุก status (Inverted Visibility - เห็นมากสุด)
  - Status: `new`, `tier1`, `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `pending_closure`, `closed`
- **Permission:** Read/Write
- **วัตถุประสงค์:** ดูภาพรวมเคสทั้งหมด

### 👤 งานของฉัน
- **แสดง:** เคสที่ `assignedTo = user.id`
- **Status:** `in_progress`, `waiting`, `resolved`, `pending_closure`
- **ไม่รวม:** `new`, `tier1`, `tier2`, `tier3`, `closed`
- **Permission:** Read/Write
- **วัตถุประสงค์:** ดูเคสที่กำลังดำเนินการอยู่
- **คำอธิบาย:** "เคสที่กำลังดำเนินการอยู่"

### 📤 เคสที่ฉันส่งต่อ
- **แสดง:** เคสที่ตัวเองเคยรับ → แล้วส่งต่อไปคนอื่น
- **ตัวอย่าง:**
  - Tier1 → Tier2
  - Tier1 → Tier3
  - Tier1 → Tier1 อื่น
- **Permission:** Read-only (ดูอย่างเดียว)
- **วัตถุประสงค์:** ติดตามว่าเคสที่ส่งต่อไปเป็นอย่างไร
- **คำอธิบาย:** "เคสที่ส่งต่อให้ทีมอื่น"

### ⏳ รอดำเนินการ
- **แสดง:**
  - Status: `new` (ทุกเคสใหม่ รวม Staff สร้าง + Customer สร้าง)
  - Status: `tier1` (ที่ยังไม่มีคนรับ หรือ assigned ให้ตัวเอง)
- **มีปุ่ม:** "รับเคส"
- **Permission:** Read/Write
- **วัตถุประสงค์:** รับเคสใหม่ที่ต้องดำเนินการ
- **คำอธิบาย:** "เคสที่ถูกมอบหมายมาแล้ว แต่ยังไม่ได้กดรับเคส"

### ✅ แก้ไขแล้ว
- **แสดง:** เคสที่ **ตัวเอง** resolve/close
- **เงื่อนไข:** `resolvedBy = user.id` หรือ `closedBy = user.id`
- **Status:** `resolved`, `pending_closure`, `closed`
- **Channel:** ทุก channel
- **Permission:** Read/Write
- **วัตถุประสงค์:** ดูเคสที่ตัวเองทำเสร็จแล้ว
- **คำอธิบาย:** "เคสที่แก้ไขแล้วและปิดเคสแล้ว"

### 📊 เคสที่ปิดย้อนหลัง
- **แสดง:** เคสที่ปิดย้อนหลังทั้งหมด (รวมถึงที่ Staff ส่งมาให้ปิด)
- **Channel:** `phone`, `email`, `line`
- **Status:** `closed`
- **Permission:** **Read-only (สำหรับ Tier 1 ทุกคน)**
- **วัตถุประสงค์:** ดูประวัติเคสที่ปิดแล้วทั้งหมด
- **เหตุผล:** Staff ไม่สามารถปิดเคสเองได้แล้ว จึงให้ Tier 1 ดูประวัติทั้งหมดได้


### 👥 ทีม / Team (ถ้ามี role admin หรือไม่มี admin ก็เห็นแบบ Read-only)
- **วัตถุประสงค์:** ดูสมาชิกในทีม, จัดการสมาชิก (ถ้ามี admin)
- **Permission:** 
  - **Read/Write** (ถ้ามี role `admin`)
  - **Read-only** (ถ้าไม่มี role `admin`)
- **คำอธิบาย:** "Tier1 ที่มี role admin สามารถจัดการสมาชิกได้"

### 📈 รายงาน / Reports (ถ้ามี role admin)
### 👥 ผู้ใช้ / Users (ถ้ามี role admin)
### 🏢 โครงการ / Projects (ถ้ามี role admin)
### ⚙️ การตั้งค่า / Settings (ถ้ามี role admin)

---

## 3. Tier2

**Role:** `tier2`

**UI Type:** Sidebar Navigation

**เมนูทั้งหมด:**

### 🏠 Dashboard
- **วัตถุประสงค์:** ภาพรวมงาน
- **Permission:** Read/Write

### 📋 เคสทั้งหมด (Tier2 related only)
- **แสดง:** เฉพาะเคสที่เกี่ยวข้องกับ Tier2
- **Status:** `tier2`, `tier3`, `in_progress`, `waiting`, `resolved`, `closed`
- **ไม่เห็น:** `new`, `tier1` (Inverted Visibility)
- **Condition:** `assignedTo = Tier2 users`
- **Permission:** Read/Write
- **วัตถุประสงค์:** ดูเคสที่เกี่ยวข้อง

### 👤 งานของฉัน
- **แสดง:** เคสที่ `assignedTo = user.id`
- **Status:** `in_progress`, `waiting`, `resolved`, `pending_closure`
- **ไม่รวม:** `tier2`, `tier3`, `closed`
- **Permission:** Read/Write

### 📤 เคสที่ฉันส่งต่อ
- **แสดง:** เคสที่ส่งต่อไป:
  - Tier2 → Tier3
  - Tier2 → Tier1 (ส่งกลับ)
  - Tier2 → Tier2 อื่น
- **Permission:** Read-only
- **วัตถุประสงค์:** ติดตามเคสที่ส่งต่อ

### ⏳ รอดำเนินการ
- **แสดง:** Status: `tier2` (ที่ยังไม่มีคนรับ หรือ assigned ให้ตัวเอง)
- **มีปุ่ม:** "รับเคส"
- **Permission:** Read/Write

### ✅ แก้ไขแล้ว
- **แสดง:** เคสที่ **ตัวเอง** resolve/close
- **Status:** `resolved`, `pending_closure`, `closed`
- **Permission:** Read/Write

### 👥 ทีม / Team
- **วัตถุประสงค์:** ดูสมาชิกในทีมและข้อมูลติดต่อ
- **Permission:** **Read-only**
- **คำอธิบาย:** "Tier2 สามารถดูสมาชิกได้ แต่ไม่สามารถจัดการสมาชิก (เพิ่ม/ลบ/แก้ไข) ได้"

---

## 4. Tier3

**Role:** `tier3`

**UI Type:** Sidebar Navigation

**เมนูทั้งหมด:**

### 🏠 Dashboard
- **วัตถุประสงค์:** ภาพรวมงาน
- **Permission:** Read/Write

### 📋 เคสทั้งหมด (Tier3 related only)
- **แสดง:** เฉพาะเคสที่เกี่ยวข้องกับ Tier3
- **Status:** `tier3`, `in_progress`, `waiting`, `resolved`, `closed`
- **ไม่เห็น:** `new`, `tier1`, `tier2` (Inverted Visibility - เห็นน้อยสุด)
- **Condition:** `assignedTo = Tier3 users`
- **Permission:** Read/Write

### 👤 งานของฉัน
- **แสดง:** เคสที่ `assignedTo = user.id`
- **Status:** `in_progress`, `waiting`, `resolved`, `pending_closure`
- **ไม่รวม:** `tier3`, `closed`
- **Permission:** Read/Write

### 📤 เคสที่ฉันส่งต่อ
- **แสดง:** เคสที่ส่งต่อไป:
  - Tier3 → Tier2 (ส่งกลับ)
  - Tier3 → Tier1 (ส่งกลับ)
  - Tier3 → Tier3 อื่น
- **Permission:** Read-only
- **วัตถุประสงค์:** ติดตามเคสที่ส่งต่อ

### ⏳ รอดำเนินการ
- **แสดง:** Status: `tier3` (ที่ยังไม่มีคนรับ หรือ assigned ให้ตัวเอง)
- **มีปุ่ม:** "รับเคส"
- **Permission:** Read/Write

### ✅ แก้ไขแล้ว
- **แสดง:** เคสที่ **ตัวเอง** resolve/close
- **Status:** `resolved`, `pending_closure`, `closed`
- **Permission:** Read/Write

### 👥 ทีม / Team
- **วัตถุประสงค์:** ดูสมาชิกในทีมและข้อมูลติดต่อ
- **Permission:** **Read-only**
- **คำอธิบาย:** "Tier3 สามารถดูสมาชิกได้ แต่ไม่สามารถจัดการสมาชิก (เพิ่ม/ลบ/แก้ไข) ได้"

---

## 5. Staff

**Role:** `staff`

**UI Type:** Landing Page (ไม่มี Sidebar)

**เมนูทั้งหมด:**

### Header
```
[Logo] CDGS    [🔍 ค้นหา]  [🔔 การแจ้งเตือน]  [👤 โปรไฟล์]
```

### 🎯 3 ปุ่มหลัก (Card/Button ใหญ่)

---

#### ➕ บันทึกเคสแทนลูกค้า

**วัตถุประสงค์:** สร้างเคสให้ลูกค้าที่ติดต่อผ่าน Phone/Email/Line

**Channel:** `phone`, `email`, `line` (ไม่รวม `web`)

**ขั้นตอนการทำงาน:**

**Flow:**
```
บันทึกเคส → ส่งต่อ Tier1
- status = 'new'
- createdBy = Staff.id
- assignedTo = null
- ปรากฏใน "รอดำเนินการ" ของ Tier1
```

**หมายเหตุ:** Staff **ไม่มีสิทธิ์ปิดเคสเอง** ต้องส่งต่อให้ Tier 1 ดำเนินการปิดเคสเท่านั้น

**ผลลัพธ์:** Tier 1 ต้องกด "รับเคส" ก่อนจึงจะ assigned และดำเนินการแก้ไขจนปิดเคส

---

#### 🔍 ติดตามเคสลูกค้าทั้งหมด

**แสดง:** เคสที่ **ตัวเอง** สร้าง

**Status:** **ไม่รวม closed**
- แสดง: `new`, `in_progress`, `waiting`, `resolved`, `pending_closure`

**Permission:** Read-only (ดูอย่างเดียว)

**วัตถุประสงค์:** ติดตามเคสที่กำลังดำเนินการ

**คำอธิบาย:** "เคสที่บันทึกแล้วแต่ยังไม่ปิด"

---

#### ✅ เคสที่ปิดย้อนหลัง (Staff)

**แสดง:** เคสที่ **ตัวเอง** สร้าง + ปิดแล้ว

**Channel:** `phone`, `email`, `line`

**Status:** **closed เท่านั้น**

**ประเภท:**
- แสดงเฉพาะเคสที่ **Tier 1 ปิดให้** (เนื่องจาก Staff ไม่มีสิทธิ์ปิดเคสเอง)
- เป็นเคสที่ Staff รับเรื่อง -> ส่งต่อ Tier 1 -> Tier 1 ปิดงาน

**Permission:** Read-only

**วัตถุประสงค์:** ดูประวัติเคสที่ปิดแล้ว

**คำอธิบาย:** "เคสที่บันทึกและปิดแล้ว"

---

**ไม่มีเมนูเหล่านี้:**
- ❌ Sidebar Navigation
- ❌ Dashboard แบบ Tier
- ❌ งานของฉัน (ไม่รับเคสจากระบบ)
- ❌ เคสที่ฉันส่งต่อ (ไม่ได้อยู่ใน Tier workflow)
- ❌ รอดำเนินการ (ไม่รับเคสจากคิว)
- ❌ แก้ไขแล้ว (ไม่มีเมนูนี้)
- ❌ เคสทั้งหมด (ไม่เข้าถึง)
- ❌ ทีม (ไม่เข้าถึง)

---

## 6. Customer

**Role:** `customer`

**UI Type:** Simple Page

**เมนูทั้งหมด:**

### 👤 งานของฉัน

**แสดง:** เคสที่ตัวเองสร้าง (ผ่าน web portal)

**Status:** ทุก status

**Permission:** Read/Write
- ดูเคส
- แก้ไขเคส (เฉพาะรายละเอียด)
- เพิ่มความคิดเห็น
- อัปโหลดไฟล์

**วัตถุประสงค์:** ติดตามเคสของตัวเอง

---

## สรุปตาราง: แต่ละ Role มีเมนูอะไรบ้าง

| เมนู | Pure Admin | Tier1 | Tier2 | Tier3 | Staff | Customer |
|------|-----------|-------|-------|-------|-------|----------|
| **UI Type** | Sidebar | Sidebar | Sidebar | Sidebar | **Landing** | Simple |
| 🏠 Dashboard | ✅ Monitor | ✅ | ✅ | ✅ | ❌ | ❌ |
| 📋 เคสทั้งหมด | ✅ Read-only | ✅ Full | ✅ Limited | ✅ Limited | ❌ | ❌ |
| 👤 งานของฉัน | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ |
| 📤 เคสที่ฉันส่งต่อ | **❌** | **✅** | **✅** | **✅** | **❌** | **❌** |
| ⏳ รอดำเนินการ (Action) | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ |
| ⏳ รอดำเนินการ (Monitor) | ✅ Read-only | - | - | - | ❌ | ❌ |
| ✅ แก้ไขแล้ว (Personal) | ❌ | ✅ Own | ✅ Own | ✅ Own | ❌ | ❌ |
| ✅ แก้ไขแล้ว (Monitor All) | ✅ All Tier | - | - | - | ❌ | ❌ |
| 📊 เคสที่ปิดย้อนหลัง | ✅ Tier 1 Only | ✅ Tier 1 Only | ❌ | ❌ | ❌ | ❌ |
| ➕ บันทึกเคสแทนลูกค้า | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ |
| 🔍 ติดตามเคส | ❌ | ❌ | ❌ | ❌ | ✅ Read-only | ❌ |
| ✅ เคสที่ปิดย้อนหลัง (Staff) | ❌ | ❌ | ❌ | ❌ | ✅ Read-only (Closed) | ❌ |
| 📈 Reports/Users/Settings | ✅ | ✅ (if admin) | ❌ | ❌ | ❌ | ❌ |
| 👥 ทีม / Team | **✅ R/W** | **✅ R/W (admin) / Read-only** | **✅ Read-only** | **✅ Read-only** | **❌** | **❌** |

---

## 💡 Key Differences

### Pure Admin vs Tier1
- **Pure Admin:** Monitor only (Read-only), ไม่มี "งานของฉัน", ไม่มี "เคสที่ฉันส่งต่อ"
- **Tier1:** Full access, รับเคส, ส่งต่อเคส, แก้ไข

### Staff vs Tier
- **Staff:** Landing Page (3 ปุ่ม), บันทึกเคสแทนลูกค้า, Read-only tracking
- **Tier:** Sidebar Navigation, รับเคส, แก้ไข, ส่งต่อ

### "งานของฉัน" vs "ติดตามเคส"
- **งานของฉัน (Tier):** เคสที่รับแล้ว, กำลังทำอยู่, ไม่รวม closed
- **ติดตามเคส (Staff):** เคสที่สร้างแล้ว, ไม่รวม closed, Read-only

### "แก้ไขแล้ว" vs "เคสที่ปิดย้อนหลัง"
- **แก้ไขแล้ว (Tier):** เคสที่ตัวเอง resolve/close, รวม closed
- **เคสที่ปิดย้อนหลัง (Staff):** เคสที่ตัวเองสร้างและปิดแล้ว, เฉพาะ closed, Read-only

### "ทีม" - Permission แบบ Layered
- **Pure Admin:** ✅ Read/Write (เต็มสิทธิ์จัดการสมาชิก)
- **Admin+Tier1/2/3:** ✅ Read/Write (เต็มสิทธิ์จัดการสมาชิก เพราะมี role `admin`)
- **Tier1 (Pure):** ✅ Read-only (ดูสมาชิก, ข้อมูลติดต่อ, ไม่สามารถแก้ไข)
- **Tier2 (Pure):** ✅ Read-only (ดูสมาชิก, ข้อมูลติดต่อ, ไม่สามารถแก้ไข)
- **Tier3 (Pure):** ✅ Read-only (ดูสมาชิก, ข้อมูลติดต่อ, ไม่สามารถแก้ไข)
- **Staff/Customer:** ❌ ไม่มีเมนูนี้

---

**อ่านเอกสารอื่น:**
- [Project Overview](/docs/features/PROJECT_OVERVIEW.md)
- [Permission Matrix](/docs/technical/PERMISSION_MATRIX.md)
- [Workflow](/docs/features/WORKFLOW.md)
