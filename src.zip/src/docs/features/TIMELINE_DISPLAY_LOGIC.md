# ⏱️ Timeline Display Logic

**Last Updated:** 29 มกราคม 2026
**Status:** ✅ Implemented

เอกสารนี้อธิบาย Logic การแสดงผลข้อความใน Timeline โดยเฉพาะ Event แรกสุด ("Created") เพื่อให้เข้าใจง่ายและเป็นมาตรฐานเดียวกัน

---

## 1. กฎการแสดงผล (Display Rules)

เราแบ่งการแสดงผลจุดเริ่มต้น Timeline เป็น 2 กรณี ตามผู้สร้างเคส:

### กรณีที่ 1: ลูกค้าแจ้งเคสด้วยตนเอง (Customer Self-Service)
เมื่อลูกค้า Login เข้ามาและกดแจ้งเคสผ่านหน้า Web Portal:

- **ข้อความที่แสดง (Description):** "ลูกค้าแจ้งเคสเอง"
- **ผู้กระทำ (Actor):** `by [Customer Name]`
- **เงื่อนไข:** `createdByType === 'customer_self'`

### กรณีที่ 2: เจ้าหน้าที่บันทึกแทน (Staff on Behalf)
เมื่อเจ้าหน้าที่ (Staff, PM, หรือ Role อื่นๆ) รับเรื่องจากลูกค้าและมาคีย์เข้าระบบ:

- **ข้อความที่แสดง (Description):** "เจ้าหน้าที่บันทึกเคสแทน ลูกค้าชื่อ [Customer Name]"
- **ผู้กระทำ (Actor):** `by [Staff Name]` (ชื่อเจ้าหน้าที่ผู้บันทึก)
- **เงื่อนไข:** `createdByType === 'staff_on_behalf'`
- **Note:** ชื่อเจ้าหน้าที่ (Staff Name) จะถูกตัด Role ที่อยู่ในวงเล็บออก (เช่น "สมชาย (Staff)" → "สมชาย") เพื่อความเป็นกลาง

---

## 2. ตัวอย่างการแสดงผล (Examples)

### Example 1: Customer แจ้งเอง
> **ลูกค้าแจ้งเคสเอง**
> <small>by ศิริพร อารีมิตร</small>

### Example 2: Staff บันทึกให้
> **เจ้าหน้าที่บันทึกเคสแทนลูกค้าชื่อ สมชาย เข็มกลัด**
> <small>by เอกชัย เอ็นเจ๊ะอาหวัง</small>

---

## 3. Implementation Details

Logic นี้ถูก implement อยู่ในไฟล์ `/components/TicketTimeline.tsx` โดยใช้การตรวจสอบ `ticket.createdByType` และทำการ Override `displayDescription` ในฝั่ง Frontend (Runtime) โดยไม่ได้แก้ไขข้อมูลใน Database จริง เพื่อให้ยืดหยุ่นต่อการเปลี่ยนแปลง

```typescript
// Pseudo-code logic
if (isCreatedEvent) {
  if (isStaffOnBehalf) {
    displayDescription = "เจ้าหน้าที่บันทึกเคสแทนลูกค้าชื่อ " + ticket.customerName;
  } else {
    displayDescription = "ลูกค้าแจ้งเคสเอง";
  }
}
```
