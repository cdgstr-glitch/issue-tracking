# 🎭 นโยบายการแสดงปุ่ม "รับเคส" สำหรับ Multi-Role Users

**เอกสารนี้อธิบายกลไกการแสดงปุ่ม "รับเคส" สำหรับผู้ใช้ที่มีหลาย Role (Multi-Role Users)**

> 📌 **[← กลับไปหน้าแรก](../INDEX.md)**

---

## 📋 สรุปความเข้าใจ

### ✅ **เงื่อนไขการแสดงปุ่ม "รับเคส" (3 เงื่อนไขต้องเป็นจริงพร้อมกัน)**

1. **`activeRole` ต้องตรงกับ `ticket.status`**
   - ถ้า `ticket.status = 'tier3'` → `activeRole` ต้องเป็น `'tier3'`
   - ถ้า `ticket.status = 'tier2'` → `activeRole` ต้องเป็น `'tier2'`
   - ถ้า `ticket.status = 'tier1'` → `activeRole` ต้องเป็น `'tier1'`

2. **`user.roles[]` ต้องมี role นั้นอยู่จริง**
   - ถ้า `ticket.status = 'tier3'` → `user.roles` ต้องมี `'tier3'`
   - ตรวจสอบด้วย `userRoles.includes('tier3')`

3. **`ticket.assignedTo` ต้องตรงกับ `user.id`**
   - เคสต้อง assign ให้ user คนนี้
   - ตรวจสอบด้วย `ticket.assignedTo === user.id`

---

## 🎯 ตัวอย่างการทำงาน

### **ตัวอย่างที่ 1: แสดงปุ่ม ✅**

**สถานการณ์:**
- **User:** 诰ลักษณ์ ประคองเพ็ชร
  - `id: 'user-007'`
  - `roles: ['tier2', 'tier3']` ← มี tier3 ใน array
  - `activeRole: 'tier3'` ← สลับเป็น Tier3 อยู่
- **Ticket:** CDGS-2024-T307
  - `status: 'tier3'` ← เคสส่งมา Tier3
  - `assignedTo: 'user-007'` ← assign ให้诰ลักษณ์

**การตรวจสอบ:**
```typescript
const hasTier3 = userRoles.includes('tier3'); // ✅ true
const effectiveRole = activeRole; // ✅ 'tier3'
const isAssignedToMe = ticket.assignedTo === user.id; // ✅ true

const canAccept = hasTier3 && effectiveRole === 'tier3' && ticket.status === 'tier3' && isAssignedToMe;
// ✅ true && true && true && true = true
```

**ผลลัพธ์:** **แสดงปุ่ม "รับเคส"** ✅

---

### **ตัวอย่างที่ 2: ไม่แสดงปุ่ม ❌**

**สถานการณ์:**
- **User:** 诰ลักษณ์ ประคองเพ็ชร
  - `id: 'user-007'`
  - `roles: ['tier2', 'tier3']` ← มี tier3 อยู่ใน array
  - `activeRole: 'tier2'` ← **สลับเป็น Tier2 อยู่**
- **Ticket:** CDGS-2024-T307
  - `status: 'tier3'` ← เคสส่งมา Tier3
  - `assignedTo: 'user-007'` ← assign ให้诰ลักษณ์

**การตรวจสอบ:**
```typescript
const hasTier3 = userRoles.includes('tier3'); // ✅ true (มี tier3 ใน array)
const effectiveRole = activeRole; // ✅ 'tier2' (แต่สลับเป็น tier2)
const isAssignedToMe = ticket.assignedTo === user.id; // ✅ true

const canAccept = hasTier3 && effectiveRole === 'tier3' && ticket.status === 'tier3' && isAssignedToMe;
// ✅ true && ❌ false && true && true = false
//              ↑ effectiveRole ('tier2') ≠ 'tier3'
```

**ผลลัพธ์:** **ไม่แสดงปุ่ม "รับเคส"** ❌

**เหตุผล:** แม้ว่า诰ลักษณ์จะมี `'tier3'` ใน `roles[]` แต่ `activeRole` ปัจจุบันคือ `'tier2'` ซึ่ง**ไม่ตรงกับ** `ticket.status = 'tier3'`

---

## 💻 Implementation

### Logic ใน `TicketActions.tsx`

```typescript
import { useAuth } from '../contexts/AuthContext';

export function TicketActions({ ticket, userRole, userId, onUpdate }: TicketActionsProps) {
  const { activeRole } = useAuth(); // ✅ ดึง activeRole จาก AuthContext
  
  // Get current user
  const currentUser = getUserById(userId);
  
  // ✅ ตรวจสอบว่า user มี roles อะไรบ้าง
  const userRoles = currentUser?.roles || [userRole];
  const hasTier1 = userRoles.includes('tier1');
  const hasTier2 = userRoles.includes('tier2');
  const hasTier3 = userRoles.includes('tier3');
  
  // ✅ ใช้ activeRole สำหรับ multi-role users
  const effectiveRole = currentUser?.roles && currentUser.roles.length > 1 
    ? activeRole  // Multi-role: ใช้ activeRole ที่สลับอยู่
    : userRole;   // Single-role: ใช้ primary role
  
  // ✅ ตรวจสอบว่าเคส assign ให้ตัวเองหรือไม่
  const isAssignedToMe = ticket.assignedTo === userId;
  
  // ✅ เงื่อนไขการแสดงปุ่ม "รับเคส"
  const canAccept = 
    // Tier1: รับเคส "new" หรือ "tier1" ที่ assigned ให้ตัวเอง
    // ✅ ต้องมี tier1 ใน roles และ activeRole ต้องเป็น tier1
    (hasTier1 && effectiveRole === 'tier1' && (ticket.status === 'new' || (ticket.status === 'tier1' && isAssignedToMe))) ||
    
    // Tier2: รับเคส "tier2" ที่ assigned ให้ตัวเอง
    // ✅ ต้องมี tier2 ใน roles และ activeRole ต้องเป็น tier2
    (hasTier2 && effectiveRole === 'tier2' && ticket.status === 'tier2' && isAssignedToMe) ||
    
    // Tier3: รับเคส "tier3" ที่ assigned ให้ตัวเอง
    // ✅ ต้องมี tier3 ใน roles และ activeRole ต้องเป็น tier3
    (hasTier3 && effectiveRole === 'tier3' && ticket.status === 'tier3' && isAssignedToMe);
  
  return (
    <div className="flex flex-wrap gap-2">
      {canAccept && (
        <Button onClick={handleAccept} className="gap-2 bg-blue-600 hover:bg-blue-700">
          <UserCheck className="h-4 w-4" />
          รับเคส
        </Button>
      )}
    </div>
  );
}
```

---

## 🔍 Console Debug

เมื่อเปิดเคส Console จะแสดง:

```javascript
🔍 TicketActions Debug: {
  userRole: 'tier2',
  userId: 'user-007',
  ticketStatus: 'tier3',
  assignedTo: 'user-007',
  isAssignedToMe: true,
  userRoles: ['tier2', 'tier3'],
  activeRole: 'tier2',        // ✅ Role ที่สลับอยู่
  effectiveRole: 'tier2',     // ✅ Role ที่ใช้ตรวจสอบ
  hasTier1: false,
  hasTier2: true,
  hasTier3: true,              // ✅ มี tier3 ใน array
  canAccept: false,            // ❌ ไม่แสดงปุ่ม เพราะ effectiveRole ≠ ticketStatus
  hasTier1Role: false
}
```

---

## 📊 ตารางสรุป

| User Roles | activeRole | ticket.status | assignedTo Match | แสดงปุ่ม "รับเคส" |
|-----------|-----------|---------------|------------------|------------------|
| `['tier2', 'tier3']` | `tier3` | `tier3` | ✅ Yes | ✅ **แสดง** |
| `['tier2', 'tier3']` | `tier2` | `tier3` | ✅ Yes | ❌ **ไม่แสดง** (activeRole ≠ status) |
| `['tier2', 'tier3']` | `tier3` | `tier2` | ✅ Yes | ❌ **ไม่แสดง** (activeRole ≠ status) |
| `['tier2', 'tier3']` | `tier3` | `tier3` | ❌ No | ❌ **ไม่แสดง** (ไม่ได้ assign ให้) |
| `['tier2']` | `tier2` | `tier3` | ✅ Yes | ❌ **ไม่แสดง** (ไม่มี tier3 ใน roles) |

---

## 🎯 Use Case: 诰ลักษณ์ (Tier2+Tier3)

### **Scenario A: 诰ลักษณ์ สลับเป็น Tier3 ✅**

1. **Login:** 诰ลักษณ์ login เข้าระบบ
2. **สลับบทบาท:** คลิกสลับเป็น "Tier 3 (Specialist)"
3. **เปิดเคส:** CDGS-2024-T307 (status = 'tier3', assignedTo = 'user-007')
4. **ผลลัพธ์:** **เห็นปุ่ม "รับเคส"** ✅

---

### **Scenario B: 诰ลักษณ์ สลับเป็น Tier2 ❌**

1. **Login:** 诰ลักษณ์ login เข้าระบบ
2. **สลับบทบาท:** คลิกสลับเป็น "Tier 2 (SA)"
3. **เปิดเคส:** CDGS-2024-T307 (status = 'tier3', assignedTo = 'user-007')
4. **ผลลัพธ์:** **ไม่เห็นปุ่ม "รับเคส"** ❌
   - เพราะ `activeRole = 'tier2'` ≠ `ticket.status = 'tier3'`

---

## 📅 ประวัติการเปลี่ยนแปลง

| วันที่ | การเปลี่ยนแปลง | ผู้แก้ไข |
|-------|---------------|---------|
| 23 ม.ค. 2026 | สร้างเอกสารนโยบาย Multi-Role Accept Button | System |
| 23 ม.ค. 2026 | เพิ่มการตรวจสอบ `activeRole` ใน `canAccept` logic | System |
| 23 ม.ค. 2026 | อัปเดต Console Debug ให้แสดง `activeRole` และ `effectiveRole` | System |

---

**หมายเหตุ:** 
- นโยบายนี้ใช้กับ **ทุก Tier** (Tier1, Tier2, Tier3)
- Multi-Role Users ต้อง**สลับบทบาทให้ตรง**กับเคสก่อนจะเห็นปุ่ม "รับเคส"
- ช่วยให้ user ตระหนักว่า**กำลังทำงานใน role ไหน** (Role Awareness)
