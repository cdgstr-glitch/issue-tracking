# 📋 Customer และ Staff Header Documentation

## 🎯 **สรุป**

**Customer และ Staff ใช้ Header แยกต่างหาก ไม่ได้ใช้ Header component ร่วมกัน**

---

## 📂 **โครงสร้าง Header ในระบบ**

### **1. Header Component (`/components/Header.tsx`)** 
**ใช้สำหรับ:**
- ✅ Tier1, Tier2, Tier3, Admin (Admin routes: `/admin/*`)
- ✅ Customer/Staff ที่เข้าหน้า `/track` (ติดตามเคส)
- ✅ Customer/Staff ที่เข้าหน้า `/track-ticket-detail` (รายละเอียดเคส)
- ✅ Customer/Staff ที่เข้าหน้า `/staff-ticket-detail` (รายละเอียดเคส Staff)
- ✅ Customer/Staff ที่เข้าหน้า `/admin/notifications` (การแจ้งเตือนทั้งหมด)

**Features:**
- มี Sidebar toggle button (สำหรับ Admin routes)
- มี Search bar
- มี Notification dropdown พร้อม onClick handler
- มี User menu พร้อม Role selector (สำหรับ multi-role users)
- มี "แจ้งเคสใหม่" button (สำหรับ Staff และ Tier1)

---

### **2. CustomerHomePage Header (`/components/CustomerHomePage.tsx`)** 
**ใช้สำหรับ:**
- ✅ Customer ที่เข้าหน้าแรก (`/`)
- ✅ ฝังอยู่ในตัว CustomerHomePage component

**Features:**
- แสดง Logo + "Application Support Center"
- มี "ติดตามเคส" button
- มี "แจ้งเคสใหม่" button
- มี Notification dropdown พร้อม onClick handler → Navigate to `/track-ticket-detail/:ticketId`
- มี User menu พร้อม Logout

**Notifications:**
```tsx
const notifications = [
  { id: '1', title: 'เคสของคุณได้รับการตอบกลับ', ticketId: 'c1' },
  { id: '2', title: 'เคสถูกส่งต่อไปยังทีมเทคนิค', ticketId: 'c2' },
  { id: '3', title: 'เคสปิดเรียบร้อย', ticketId: 'c3' },
];
```

---

### **3. StaffHomePage Header (`/components/StaffHomePage.tsx`)** 
**ใช้สำหรับ:**
- ✅ Staff ที่เข้าหน้าแรก (`/`)
- ✅ ฝังอยู่ในตัว StaffHomePage component

**Features:**
- แสดง Logo + "CDGS Issue Tracking"
- มี "ติดตามเคส" button
- มี "บันทึกเคสแทนลูกค้า" button
- มี Notification dropdown พร้อม onClick handler → Navigate to `/staff-ticket-detail/:ticketId`
- มี User menu พร้อม Logout

**Notifications:**
```tsx
const notifications = [
  { id: '1', title: 'เคสใหม่จากลูกค้า', ticketId: 's1' },
  { id: '2', title: 'ทีมสนับสนุนตอบกลับแล้ว', ticketId: 's2' },
  { id: '3', title: 'ลูกค้าโทรสอบถาม', ticketId: 's3' },
];
```

---

## 🔍 **การแก้ไข Notification Dropdown**

### **ปัญหา:**
- ❌ คลิก notification แล้วไม่วิ่งไปหน้าเคส
- ❌ ไม่มี `ticketId` ใน notification object
- ❌ ไม่มี `onClick` handler ใน `DropdownMenuItem`

---

### **วิธีแก้:**

#### **1. เพิ่ม `ticketId` ใน notification object**

**Before:**
```tsx
const notifications = [
  { id: '1', title: 'เคสของคุณได้รับการตอบกลับ', time: '10 นาทีที่แล้ว', isNew: true },
];
```

**After:**
```tsx
const notifications = [
  { id: '1', title: 'เคสของคุณได้รับการตอบกลับ', time: '10 นาทีที่แล้ว', isNew: true, ticketId: 'c1' },
];
```

---

#### **2. เพิ่ม `onClick` handler ใน `DropdownMenuItem`**

**Before:**
```tsx
<DropdownMenuItem 
  key={notification.id}
  className="flex flex-col items-start p-4 cursor-pointer hover:bg-gray-50"
>
  {/* notification content */}
</DropdownMenuItem>
```

**After (CustomerHomePage):**
```tsx
<DropdownMenuItem 
  key={notification.id}
  className="flex flex-col items-start p-4 cursor-pointer hover:bg-gray-50"
  onClick={() => {
    setNotificationOpen(false);
    if (notification.ticketId) {
      onNavigate('/track-ticket-detail', notification.ticketId);
    }
  }}
>
  {/* notification content */}
</DropdownMenuItem>
```

**After (StaffHomePage):**
```tsx
<DropdownMenuItem 
  key={notification.id}
  className="flex flex-col items-start p-4 cursor-pointer hover:bg-gray-50"
  onClick={() => {
    setNotificationOpen(false);
    if (notification.ticketId) {
      onNavigate('/staff-ticket-detail', notification.ticketId);
    }
  }}
>
  {/* notification content */}
</DropdownMenuItem>
```

---

#### **3. Update Interface เพื่อรองรับ `ticketId` parameter**

**Before:**
```tsx
interface CustomerHomePageProps {
  onNavigate: (path: string) => void;
  onBackToMenu?: () => void;
}
```

**After:**
```tsx
interface CustomerHomePageProps {
  onNavigate: (path: string, ticketId?: string) => void;
  onBackToMenu?: () => void;
}
```

---

## 📊 **Navigation Logic สำหรับ Notifications**

| **Component** | **Notification คลิก** | **Navigate ไป** |
|--------------|---------------------|----------------|
| CustomerHomePage | เคสของคุณได้รับการตอบกลับ (ticketId: 'c1') | `/track-ticket-detail/c1` |
| CustomerHomePage | เคสถูกส่งต่อไปยังทีมเทคนิค (ticketId: 'c2') | `/track-ticket-detail/c2` |
| CustomerHomePage | เคสปิดเรียบร้อย (ticketId: 'c3') | `/track-ticket-detail/c3` |
| StaffHomePage | เคสใหม่จากลูกค้า (ticketId: 's1') | `/staff-ticket-detail/s1` |
| StaffHomePage | ทีมสนับสนุนตอบกลับแล้ว (ticketId: 's2') | `/staff-ticket-detail/s2` |
| StaffHomePage | ลูกค้าโทรสอบถาม (ticketId: 's3') | `/staff-ticket-detail/s3` |
| Header Component | Tier1 notification (ticketId: '1') | `/admin/ticket/1` |
| Header Component | Tier2 notification (ticketId: '2') | `/admin/ticket/2` |
| Header Component | Tier3 notification (ticketId: '3') | `/admin/ticket/3` |

---

## 📁 **ไฟล์ที่แก้ไข**

```
✅ /components/CustomerHomePage.tsx
   - เพิ่ม ticketId ใน notifications array
   - เพิ่ม onClick handler ใน DropdownMenuItem
   - Update interface: onNavigate(path: string, ticketId?: string)

✅ /components/StaffHomePage.tsx
   - เพิ่ม ticketId ใน notifications array
   - เพิ่ม onClick handler ใน DropdownMenuItem
   - Update interface: onNavigate(path: string, ticketId?: string)

✅ /components/Header.tsx
   - มี onClick handler อยู่แล้ว
   - รองรับทั้ง Customer, Staff, Tier1-3

✅ /App.tsx
   - เพิ่ม Header wrapper สำหรับ /staff-ticket-detail route
```

---

## ✅ **สรุปการทำงาน**

### **Customer:**
1. Login เป็น `customer@mail.com`
2. หน้าแรก (`/`) → ใช้ **CustomerHomePage** (มี Header ฝังอยู่)
3. คลิกกระดิ่ง 🔔 → เห็น 3 notifications
4. คลิก notification → Navigate to `/track-ticket-detail/c1`
5. หน้ารายละเอียดเคส → ใช้ **Header component** (ที่เพิ่มใน App.tsx)

---

### **Staff:**
1. Login เป็น `staff@mail.com`
2. หน้าแรก (`/`) → ใช้ **StaffHomePage** (มี Header ฝังอยู่)
3. คลิกกระดิ่ง 🔔 → เห็น 3 notifications
4. คลิก notification → Navigate to `/staff-ticket-detail/s1`
5. หน้ารายละเอียดเคส → ใช้ **Header component** (ที่เพิ่มใน App.tsx)

---

### **Tier1-3:**
1. Login เป็น `tier1@mail.com`
2. หน้าแรก (`/admin`) → ใช้ **Header component**
3. คลิกกระดิ่ง 🔔 → เห็น 5 notifications
4. คลิก notification → Navigate to `/admin/ticket/1`
5. หน้ารายละเอียดเคส → ใช้ **Header component** เหมือนเดิม

---

## 🎊 **สรุปความแตกต่าง**

| **Feature** | **CustomerHomePage Header** | **StaffHomePage Header** | **Header Component** |
|------------|---------------------------|------------------------|---------------------|
| **ใช้กับ** | Customer (หน้าแรก) | Staff (หน้าแรก) | Tier1-3, Admin, Customer/Staff (หน้าอื่น) |
| **Logo Text** | Application Support Center | CDGS Issue Tracking | CDGS Issue Tracking |
| **Search Bar** | ❌ ไม่มี | ❌ ไม่มี | ✅ มี |
| **Sidebar Toggle** | ❌ ไม่มี | ❌ ไม่มี | ✅ มี (Admin routes) |
| **Role Selector** | ❌ ไม่มี | ❌ ไม่มี | ✅ มี (Multi-role users) |
| **Notification Navigate** | `/track-ticket-detail/:id` | `/staff-ticket-detail/:id` | ตาม role |
| **ตำแหน่ง** | ฝังใน CustomerHomePage | ฝังใน StaffHomePage | Component แยก |

---

## 📝 **หมายเหตุสำคัญ**

1. **Customer และ Staff ใช้ Header แยกกัน** เพราะหน้าแรกของพวกเขามีดีไซน์และฟีเจอร์ต่างกัน
2. **Header component** ใช้สำหรับหน้าอื่นๆ ที่ต้องการ UI เดียวกัน (ติดตามเคส, รายละเอียดเคส, การแจ้งเตือน)
3. **ทุก notification dropdown ต้องมี onClick handler** เพื่อ navigate ไปหน้าเคสที่ถูกต้อง
4. **ticketId ต้องตรงกับ mock data** เพื่อให้ navigate ไปหน้าเคสที่ถูกต้อง

---

## 🔧 **วิธีแก้ไขในอนาคต**

หากต้องการแก้ไข notification dropdown:

### **สำหรับ Customer:**
```bash
แก้ไขไฟล์: /components/CustomerHomePage.tsx
ตำแหน่ง: line 33-38 (notifications array)
ตำแหน่ง: line 95-119 (DropdownMenuItem)
```

### **สำหรับ Staff:**
```bash
แก้ไขไฟล์: /components/StaffHomePage.tsx
ตำแหน่ง: line 33-38 (notifications array)
ตำแหน่ง: line 95-119 (DropdownMenuItem)
```

### **สำหรับ Tier1-3, Admin:**
```bash
แก้ไขไฟล์: /components/Header.tsx
ตำแหน่ง: line 59-184 (getNotifications function)
ตำแหน่ง: line 277-315 (DropdownMenuItem)
```

---

## ⚠️ **สำคัญ: Interface ของ onNavigate**

**ทุก component ที่มี `onNavigate` prop ต้องใช้ interface เดียวกัน:**

```tsx
onNavigate: (path: string, ticketId?: string) => void
```

### **✅ Components ที่แก้ไขแล้ว:**

```
✅ /components/CustomerHomePage.tsx
✅ /components/StaffHomePage.tsx
✅ /components/StaffTicketDetailPage.tsx
✅ /components/StaffClosedTicketDetailPage.tsx
✅ /components/TrackTicketDetailPage.tsx
✅ /components/TicketDetailPage.tsx
✅ /components/Sidebar.tsx
✅ /components/Header.tsx
✅ /components/CreateTicketPage.tsx (⭐ สำคัญสำหรับ Staff!)
✅ /components/CustomerFAQPage.tsx
✅ /components/CustomerTrackTicketPage.tsx
✅ /components/StaffTrackTicketPage.tsx
```

---

**เอกสารนี้บันทึกเมื่อ:** Saturday, January 17, 2026  
**สถานะ:** ✅ ทุกอย่างทำงานสมบูรณ์แล้ว - แก้ไข interface ครบทุก component ที่จำเป็น
