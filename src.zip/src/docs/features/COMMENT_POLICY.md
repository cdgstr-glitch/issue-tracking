# 📝 นโยบายการแสดงความคิดเห็น (Comment Policy)

**เอกสารนี้อธิบายนโยบายการแสดงความคิดเห็นในระบบ CDGS Issue Tracking Platform**

---

## 🎯 หลักการพื้นฐาน

### ✅ กฎทั่วไป
1. **ลูกค้าเห็นเฉพาะ Public Comments** - ลูกค้าไม่เห็น Internal Notes
2. **เจ้าหน้าที่เห็นทั้ง Public และ Internal** - Staff, Tier1-3, Admin เห็นทุก comment
3. **เคสที่ปิดแล้วไม่สามารถ comment ได้** - ใช้กับทุกบทบาท (Customer, Staff, Tier1-3, Admin)

---

## 📋 กฎการ Comment ตามสถานะเคส

| สถานะเคส (Status) | Customer | Staff | Tier1 | Tier2 | Tier3 | Admin | หมายเหตุ |
|------------------|----------|-------|-------|-------|-------|-------|----------|
| **new** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ❌ ไม่เห็นเคส | ❌ ไม่เห็นเคส | ✅ ได้ | เคสใหม่ |
| **tier1** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ❌ ไม่เห็นเคส | ❌ ไม่เห็นเคส | ✅ ได้ | Tier1 รับเคสแล้ว |
| **tier2** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ❌ ไม่เห็นเคส | ✅ ได้ | ส่งต่อ Tier2 |
| **tier3** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ส่งต่อ Tier3 |
| **in_progress** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | กำลังดำเนินการ |
| **waiting** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | หยุดชั่วคราว |
| **resolved** | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | ✅ ได้ | แก้ไขเสร็จแล้ว (รอปิด) |
| **closed** | ❌ **ไม่ได้** | ❌ **ไม่ได้** | ❌ **ไม่ได้** | ❌ **ไม่ได้** | ❌ **ไม่ได้** | ❌ **ไม่ได้** | **ปิดแล้ว - ไม่สามารถ comment ได้** |

---

## 🔒 กฎพิเศษ: เคสที่ปิดแล้ว (Closed Tickets)

### ❌ **ไม่แสดงกล่อง Comment Section เลย**
- **ทุกบทบาท** (Customer, Staff, Tier1-3, Admin) **จะไม่เห็นกล่อง "ความคิดเห็นและกิจกรรม"**
- Component `<CommentSection />` จะ **ถูกซ่อนทั้งหมด** เมื่อ `status === 'closed'`
- UI จะ **ไม่แสดงกล่องนี้เลย** (ใช้ conditional rendering `{ticket.status !== 'closed' && <CommentSection />}`)

### ✅ **หมายเหตุ**
- เคสที่ปิดแล้วจะ **อ่านอย่างเดียว (Read-only)** ทั้งหมด
- Comments เดิมจะ **ไม่แสดง** เพราะกล่องทั้งหมดถูกซ่อน
- ถ้าต้องการดู comments เดิม ให้ดูใน **Timeline** แทน

---

## 🎨 UI Behavior

### 1. **เคสที่ยังไม่ปิด** (status ≠ 'closed')
- ✅ แสดงฟอร์ม comment
- ✅ แสดงปุ่ม "เพิ่มความคิดเห็น"
- ✅ เจ้าหน้าที่เห็น toggle "ความคิดเห็นสาธารณะ / หมายเหตุภายใน"

### 2. **เคสที่ปิดแล้ว** (status = 'closed')
- ❌ **ซ่อนฟอร์ม comment ทั้งหมด**
- ❌ **ไม่แสดงปุ่ม "เพิ่มความคิดเห็น"**
- ✅ แสดง comments เดิมที่มีอยู่แล้ว (Read-only)
- 🔔 แสดงข้อความ Banner: **"เคสนี้ถูกปิดแล้ว"**

---

## 💻 Implementation

### Component: `CommentSection.tsx`

```typescript
interface CommentSectionProps {
  comments: Comment[];
  onAddComment: (comment: string, isInternal: boolean, attachments?: File[]) => void;
  formatDate: (date: Date) => string;
  currentUserName: string;
  currentUserRole: string;
  showInternalToggle?: boolean;
  readOnly?: boolean; // ✅ ใช้สำหรับปิด comment
  title?: string;
  placeholder?: string;
  submitButtonText?: string;
}
```

### Usage Example

```typescript
<CommentSection
  comments={ticket.comments}
  onAddComment={handleAddComment}
  formatDate={formatDate}
  currentUserName={user?.fullName || ''}
  currentUserRole={user?.role || 'staff'}
  showInternalToggle={user?.role !== 'customer'}
  readOnly={ticket.status === 'closed'} // ✅ ปิด comment เมื่อเคสปิดแล้ว
/>
```

---

## 📌 สรุป

| เงื่อนไข | Action |
|---------|--------|
| `status = 'closed'` | `readOnly = true` → ซ่อนฟอร์ม comment |
| `status ≠ 'closed'` | `readOnly = false` → แสดงฟอร์ม comment |
| `userRole = 'customer'` | `showInternalToggle = false` → ไม่เห็น toggle |
| `userRole = 'staff/tier/admin'` | `showInternalToggle = true` → เห็น toggle |

---

## 👨‍💼 กฎพิเศษสำหรับ Staff

### **Staff สามารถ Comment ได้ในเคส Active เท่านั้น**

#### **✅ Staff สามารถ Comment ได้:**
- เคสที่ **ตัวเองสร้าง** (onBehalfOf = Staff)
- เคสที่มีสถานะ **Active** (new, tier1, tier2, tier3, in_progress, waiting, resolved)
- สามารถเลือกได้ว่าจะส่งแบบ **Public** หรือ **Internal**

#### **❌ Staff ไม่สามารถ Comment ได้:**
- เคสที่สถานะ **closed** (ปิดแล้ว)
- เคสที่ **ไม่ได้สร้างเอง** (ไม่เห็นเคสนั้นในระบบ)

#### **📝 Use Cases:**
1. **ลูกค้าโทรกลับเพิ่มข้อมูล** → Staff เพิ่ม public comment
2. **Tier ถามข้อมูลเพิ่มเติม** → Staff ตอบใน public comment
3. **ลูกค้าถามสถานะ** → Staff ดูเคสและแจ้งกลับลูกค้า (ไม่จำเป็นต้อง comment)
4. **บันทึกข้อมูลภายใน** → Staff เพิ่ม internal note

#### **🎯 หน้าที่ Staff ใช้งาน:**
- `/track` - ดูเคสที่ตัวเองสร้าง (Active tickets) + เพิ่ม comment ได้
- `/staff-ticket-detail/:id` - รายละเอียดเคส + เพิ่ม comment ได้
- `/closed-tickets` - ดูเคสที่ปิดแล้ว (Read-only เท่านั้น, **ไม่สามารถ comment**)

---

## 📅 ประวัติการเปลี่ยนแปลง

| วันที่ | การเปลี่ยนแปลง | ผู้แก้ไข |
|-------|---------------|------------|
| 23 ม.ค. 2026 | สร้างเอกสารนโยบาย Comment | System |
| 23 ม.ค. 2026 | เพิ่มกฎ: เคสปิดแล้วไม่สามารถ comment ได้ (ทุกบทบาท) | System |
| 26 ม.ค. 2026 | เพิ่มกฎพิเศษสำหรับ Staff: สามารถ comment ในเคส Active (แยก Internal/Public) | System |

---

**หมายเหตุ:** นโยบายนี้ใช้กับทุกหน้าที่มี Comment Section รวมถึง:
- `/admin/tickets/:id` (TicketDetailPage)
- `/track/:ticketNumber` (TrackTicketDetailPage - สำหรับลูกค้า)
