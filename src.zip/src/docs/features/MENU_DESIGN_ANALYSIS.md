# 🎯 วิเคราะห์: Menu Design & Status Mapping

**วันที่:** 14 มกราคม 2026  
**วัตถุประสงค์:** วิเคราะห์การออกแบบเมนูและเปรียบเทียบกับระบบ Enterprise

---

## 📊 สรุป: เมนูปัจจุบันของระบบ CDGS

### 🔵 **เมนู 1: รอดำเนินการ** (Pending/Queue)

**แสดงสถานะ:**
```
Tier 1:
✅ new           - เคสใหม่ (ยังไม่มีคนรับ)
✅ tier1         - เคสส่งกลับมา (assigned แต่ยังไม่รับ)

Tier 2:
✅ tier2         - เคสที่ส่งมา (assigned แต่ยังไม่รับ)

Tier 3:
✅ tier3         - เคสที่ส่งมา (assigned แต่ยังไม่รับ)
```

**จุดประสงค์:**
- เคสที่**รอให้ฉันรับ** (Assigned to me but not accepted yet)
- มีปุ่ม **"รับเคส"**

---

### 🟢 **เมนู 2: งานของฉัน** (My Work/In Progress)

**แสดงสถานะ:**
```
✅ in_progress      - กำลังทำอยู่
✅ waiting          - หยุดชั่วคราว (รอข้อมูลลูกค้า)
✅ resolved         - แก้ไขเสร็จแล้ว (บางระบบ)
✅ pending_closure  - รอปิด (บางระบบ)

❌ ไม่รวม:
- new, tier1/2/3 (ยังไม่ได้รับ)
- closed (ปิดไปแล้ว)
```

**จุดประสงค์:**
- เคสที่**ฉันรับแล้วและกำลังทำอยู่**
- Working queue ของฉัน

---

### 📤 **เมนู 3: เคสที่ฉันส่งต่อ** (Escalated/Delegated)

**แสดงสถานะ:**
```
✅ tier1/2/3     - เคสที่ส่งต่อให้คนอื่น
✅ in_progress   - เคสที่คนอื่นกำลังทำ
✅ waiting       - เคสที่คนอื่นหยุดชั่วคราว
✅ resolved      - เคสที่คนอื่นแก้ไขเสร็จ
✅ closed        - เคสที่คนอื่นปิดแล้ว

เงื่อนไข:
- escalatedBy = me (ฉันส่งต่อ)
- assignedTo ≠ me (ไม่ใช่ฉันแล้ว)
```

**จุดประสงค์:**
- **ติดตามเคสที่ฉันส่งต่อไป** (Read-only)
- ดูว่าคน���ื่นทำถึงไหนแล้ว

---

### ✅ **เมนู 4: แก้ไขแล้ว** (Resolved/Completed)

**❓ ปัญหา: ควรแสดงสถานะอะไร?**

**ตัวเลือก A: แสดงเฉพาะ resolved + pending_closure**
```
✅ resolved         - แก้ไขเสร็จแล้ว
✅ pending_closure  - รอปิด

❌ ไม่รวม closed
```
**ข้อดี:**
- แสดงเฉพาะเคสที่**รอปิด** (Actionable)
- Notification Badge 🟢 นับได้ถูกต้อง
- ชัดเจนว่ามี Action ที่ต้องทำ (กดปิดเคส)

**ข้อเสีย:**
- ต้องมีเมนู "ปิดแล้ว" แยก

---

**ตัวเลือก B: แสดงทั้งหมด resolved + pending_closure + closed**
```
✅ resolved         - แก้ไขเสร็จแล้ว
✅ pending_closure  - รอปิด
✅ closed          - ปิดแล้ว
```
**ข้อดี:**
- ดูเคสที่ตัวเองแก้ไขได้ทั้งหมด (ย้อนหลัง 30 วัน)
- ไม่ต้องมีเมนูแยก

**ข้อเสีย:**
- Notification Badge 🟢 นับยาก (ต้องนับเฉพาะ resolved + pending_closure)
- ปะปนระหว่าง "รอปิด" กับ "ปิดไปแล้ว"

---

## 🔍 เปรียบเทียบกับระบบ Enterprise จริง

### 1️⃣ **Jira Service Management** (Atlassian)

**เมนูหลัก:**
```
📋 Queues (คิว)
├── Open               → status: Open, Waiting for support
├── In progress        → status: In progress
├── Waiting for customer → status: Waiting for customer
├── Resolved           → status: Resolved (รอลูกค้ายืนยัน)
└── All open issues    → ทุก status ยกเว้น Closed

📤 Raised by me        → เคสที่ฉันสร้าง (ไม่ว่า status ไหน)
✅ Resolved recently   → เคส Resolved ย้อนหลัง 7 วัน
📊 Reports            → รายงาน
```

**สังเกต:**
- ✅ แยก "Resolved" กับ "Closed" **ชัดเจน**
- ✅ "Resolved recently" เห็นแค่ 7 วัน (ไม่ใช่ถาวร)
- ❌ **ไม่มีเมนู "Closed"** ใน Sidebar (ต้องไป Reports หรือ Search)

---

### 2️⃣ **ServiceNow ITSM**

**เมนูหลัก:**
```
📋 Self-Service
├── My Incidents       → status: New, In Progress, On Hold
├── My Requests        → status: Open, Work in Progress
├── My Items          → Asset ที่ฉันใช้งาน

👤 Agent View
├── Incidents         
│   ├── Open          → status: New, In Progress, On Hold
│   ├── Assigned to me → assignedTo = me, ไม่รวม Closed
│   ├── Pending       → status: Pending (รออะไรสักอย่าง)
│   ├── Resolved      → status: Resolved (รอปิด)
│   └── Closed        → status: Closed (แยกเมนู)
```

**สังเกต:**
- ✅ แยก "Resolved" กับ "Closed" **เป็นเมนูคนละอัน**
- ✅ "Assigned to me" ไม่รวม Closed
- ✅ มีเมนู "Pending" แยก (On Hold/Waiting)

---

### 3️⃣ **Zendesk Support**

**เมนูหลัก:**
```
📋 Views (มุมมอง)
├── Unassigned        → status: New, Open (ยังไม่มีคนรับ)
├── Your tickets      → assignedTo = me, status: Open, Pending, On-hold
├── All unsolved      → status: New, Open, Pending, On-hold (ไม่รวม Solved/Closed)
├── Recently updated  → เคสที่อัปเดตล่าสุด
├── Recently solved   → status: Solved ย้อนหลัง 30 วัน
└── Suspended tickets → เคส Spam

📤 Reporting          → Dashboard, รายงาน
```

**สังเกต:**
- ✅ "Recently solved" เห็นแค่ 30 วัน
- ❌ **ไม่มีเมนู "Closed"** ใน Sidebar
- ✅ "Your tickets" รวม Pending และ On-hold

---

### 4️⃣ **Freshdesk**

**เมนูหลัก:**
```
📋 Tickets
├── New & My open     → status: Open, Pending, ไม่รวม Closed
├── Unassigned        → status: Open (ยังไม่มีคนรับ)
├── Due today         → เคสใกล้ครบกำหนด
├── Overdue           → เคสเกิน SLA
├── Unresolved        → status: Open, Pending, On Hold
└── Spam              → เคส Spam

📊 Analytics          → Dashboard, รายงาน
```

**สังเกต:**
- ✅ "New & My open" รวม Pending
- ❌ **ไม่มีเมนู "Resolved"** หรือ "Closed" แยก
- ✅ เน้น SLA (Due today, Overdue)

---

### 5️⃣ **Linear** (Modern Issue Tracker)

**เมนูหลัก:**
```
📋 Views
├── Inbox             → เคสที่มอบหมายให้ฉัน (Triage)
├── My issues         → assignedTo = me, status: Todo, In Progress, In Review
├── Active            → status: In Progress (ไม่รวม Backlog/Done)
├── Backlog           → status: Backlog
├── Completed         → status: Done ย้อนหลัง 14 วัน
└── All issues        → ทุก status

🗂️ Projects           → จัดกลุ่มตาม Project
```

**สังเกต:**
- ✅ "Completed" เห็นแค่ 14 วัน
- ✅ "Active" ไม่รวม Done
- ✅ เน้น Workflow: Inbox → My issues → Active → Completed

---

## 📊 สรุปการออกแบบเมนูของระบบ Enterprise

### 🎯 **หลักการออกแบบ (Best Practices):**

| หลักการ | Jira | ServiceNow | Zendesk | Freshdesk | Linear | CDGS |
|---------|------|-----------|---------|-----------|--------|------|
| **แยก "Resolved" กับ "Closed"** | ✅ | ✅ | ✅ | ❌ | ✅ | ❓ |
| **เมนู "Closed" ใน Sidebar** | ❌ | ✅ | ❌ | ❌ | ✅ | ❓ |
| **จำกัดเวลา Resolved/Closed** | 7 วัน | ไม่จำกัด | 30 วัน | N/A | 14 วัน | 30 วัน |
| **เมนู "Pending/Waiting" แยก** | ✅ | ✅ | ❌ (รวมใน Your tickets) | ❌ | ❌ | ❓ |
| **"My Work" รวม Resolved** | ❌ | ❌ | ✅ | ✅ | ❌ | ❓ |

---

## 💡 คำแนะนำ: การออกแบบเมนูสำหรับระบบ CDGS

### 🎯 **แนวทาง A: Enterprise Standard (แนะนำ)**

**เหมาะกับ:** องค์กรขนาดใหญ่, ทีมหลายคน, SLA เข้มงวด

```
📋 Sidebar Menu (Tier1/2/3)
├── 📥 รอรับเคส (Accept Queue)
│   └── status: new, tier1/2/3 (assigned to me)
│   └── Action: กดปุ่ม "รับเคส"
│
├── 💼 งานของฉัน (My Work)
│   └── status: in_progress, waiting
│   └── เคสที่กำลังทำอยู่ (ไม่รวม resolved)
│
├── ⏸️ หยุดชั่วคราว (On Hold) - เมนูแยก
│   └── status: waiting
│   └── เคสที่รอข้อมูลลูกค้า
│
├── ✅ แก้ไขแล้ว (Resolved) 🟢
│   └── status: resolved, pending_closure
│   └── เคสที่รอปิด (Actionable)
│   └── Notification Badge นับเคสที่รอ
│
├── 📤 เคสที่ฉันส่งต่อ (Escalated)
│   └── Read-only, ติดตามเคสที่ส่งต่อ
│
├── 📂 ปิดแล้ว (Closed)
│   └── status: closed
│   └── ย้อนหลัง 30 วัน (หรือไม่จำกัด)
│
└── 📋 ทั้งหมด (All Tickets)
    └── ทุก status
```

**ข้อดี:**
- ✅ แยก "แก้ไขแล้ว" กับ "ปิดแล้ว" ชัดเจน (ตาม ServiceNow, Linear)
- ✅ Notification Badge 🟢 นับได้ถูกต้อง
- ✅ "งานของฉัน" ไม่รวม resolved → เน้น Active Work
- ✅ มีเมนู "หยุดชั่วคราว" แยก → Tier เห็นเคสที่รอชัดเจน

**ข้อเสีย:**
- ❌ เมนูเยอะ (7 เมนู)

---

### 🎯 **แนวทาง B: Simplified (เหมาะกับทีมเล็ก)**

**เหมาะกับ:** ทีมเล็ก, ไม่ซับซ้อน, ไม่มี SLA เข้มงวด

```
📋 Sidebar Menu (Tier1/2/3)
├── 📥 รอรับเคส
│   └── status: new, tier1/2/3
│
├── 💼 งานของฉัน (My Open Work)
│   └── status: in_progress, waiting, resolved, pending_closure
│   └── รวมทุกอย่างที่ยังไม่ปิด
│
├── 📤 เคสที่ฉันส่งต่อ
│   └── Read-only
│
└── 📋 ทั้งหมด (All)
    └── ทุก status (รวม closed)
```

**ข้อดี:**
- ✅ เมนูน้อย (4 เมนู)
- ✅ ง่ายต่อการใช้งาน

**ข้อเสีย:**
- ❌ "งานของฉัน" รวม resolved → ไม่ชัดว่ารอปิดหรือกำลังทำ
- ❌ Notification Badge 🟢 ยาก
- ❌ ไม่เห็นเคส "หยุดชั่วคราว" ชัดเจน

---

### 🎯 **แนวทาง C: Hybrid (แนะนำที่สุดสำหรับ CDGS)**

**เหมาะกับ:** Enterprise แต่ไม่ซับซ้อนเกินไป, UX ดี, Notification ชัดเจน

```
📋 Sidebar Menu (Tier1/2/3)
├── 📥 รอรับเคส (Accept Queue)
│   └── status: new, tier1/2/3
│   └── Badge: นับเคสที่รอรับ
│
├── 💼 งานของฉัน (My Active Work)
│   └── status: in_progress, waiting
│   └── แสดงเคสที่กำลังทำจริงๆ
│   └── Badge: นับเคสที่กำลังทำ
│
├── ✅ แก้ไขแล้ว (Awaiting Closure) 🟢
│   └── status: resolved, pending_closure
│   └── เคสที่รอปิด (Tier1 ปิดเอง หรือรอลูกค้ายืนยัน)
│   └── Badge สีเขียว: นับเคสที่รอปิด
│
├── 📤 เคสที่ฉันส่งต่อ (Delegated)
│   └── Read-only
│
└── 📋 ทั้งหมด (All Tickets)
    └── ทุก status (รวม closed ย้อนหลัง 30 วัน)
    └── มี Filter: Active / Closed
```

**ข้อดี:**
- ✅ เมนูพอดี (5 เมนู)
- ✅ แยก "แก้ไขแล้ว" ชัดเจน (Actionable)
- ✅ Notification Badge 3 แห่ง:
  - 📥 รอรับเคส (ฟ้า)
  - 💼 งานของฉัน (เทา)
  - ✅ แก้ไขแล้ว (เขียว 🟢)
- ✅ "งานของฉัน" ไม่รวม resolved → เน้น Active
- ✅ "ทั้งหมด" มี Filter แสดง Closed

**ข้อเสีย:**
- ❌ "หยุดชั่วคราว" (waiting) รวมใน "งานของฉัน" (แต่ใช้ Badge แยกได้)

---

## 📊 สรุปคำแนะนำ: แนวทาง C (Hybrid)

### ✅ **เมนูแต่ละอันแสดงอะไร:**

| เมนู | Status | จุดประสงค์ | Notification Badge |
|------|--------|-----------|-------------------|
| **📥 รอรับเคส** | `new`, `tier1/2/3` | เคสที่มอบหมายให้ฉัน (ยังไม่รับ) | 🔵 นับเคส |
| **💼 งานของฉัน** | `in_progress`, `waiting` | เคสที่ฉันกำลังทำ | 🔵 นับเคส |
| **✅ แก้ไขแล้ว** | `resolved`, `pending_closure` | เคสที่รอปิด | 🟢 นับเคส |
| **📤 ส่งต่อแล้ว** | ทุก status (escalatedBy = me) | ติดตามเคสที่ส่งต่อ | ❌ ไม่มี |
| **📋 ทั้งหมด** | ทุก status (+ closed 30 วัน) | ดูภาพรวมทั้งหมด | ❌ ไม่มี |

---

### 🎨 **UI/UX Design:**

```
┌─────────────────────────────────────────────────────┐
│  Sidebar                                            │
├─────────────────────────────────────────────────────┤
│  📥 รอรับเคส               [12]  🔵                 │
│  💼 งานของฉัน               [5]  🔵                 │
│     └─ in_progress (3)                              │
│     └─ waiting (2)         ⏸️                      │
│  ✅ แก้ไขแล้ว               [8]  🟢                 │
│  📤 เคสที่ฉันส่งต่อ                                 │
│  📋 ทั้งหมด                                         │
│     └─ Filter: [Active ▼] [Closed]                 │
└─────────────────────────────────────────────────────┘
```

**Notification Badge:**
- 🔵 **สีฟ้า** (รอรับเคส, งานของฉัน) → Needs Action
- 🟢 **สีเขียว** (แก้ไขแล้ว) → Awaiting Closure
- ⏸️ **ไอคอนเล็ก** (waiting) → Sub-status

---

### 🔑 **Key Decisions:**

1. **"งานของฉัน" ไม่รวม `resolved`**
   - เหตุผล: resolved คือ "แก้ไขเสร็จแล้ว" ไม่ใช่ "กำลังทำอยู่"
   - ตาม: ServiceNow, Jira, Linear

2. **"แก้ไขแล้ว" แสดง `resolved` + `pending_closure`**
   - เหตุผล: เคสที่รอปิด (Actionable) → Tier1 ต้องปิด
   - Notification Badge 🟢 นับได้ถูกต้อง

3. **"ทั้งหมด" แสดง closed ย้อนหลัง 30 วัน**
   - เหตุผล: ไม่ให้ List ยาวเกินไป
   - ตาม: Zendesk (30 วัน)

4. **ไม่มีเมนู "ปิดแล้ว" แยก**
   - เหตุผล: ดูใน "ทั้งหมด" + Filter "Closed" ได้
   - ประหยัดเมนู (ตาม Jira, Zendesk)

---

### 📌 **Implementation:**

**ไฟล์ที่ต้องแก้:**
1. `/components/Sidebar.tsx`
   - เปลี่ยนชื่อเมนู "รอดำเนินการ" → "รอรับเคส"
   - เปลี่ยนชื่อเมนู "งานของฉัน" → "งานของฉัน" (เหมือนเดิม OK)
   - เมนู "งานของฉัน" ไม่แสดง `resolved`, `pending_closure`

2. `/components/TicketListPage.tsx`
   - เพิ่ม Filter: Active / Closed ในเมนู "ทั้งหมด"
   - แสดง closed ย้อนหลัง 30 วัน

3. `/components/Header.tsx`
   - เพิ่ม Notification Badge:
     - 🔵 รอรับเคส
     - 🔵 งานของฉัน (in_progress + waiting)
     - 🟢 แก้ไขแล้ว (resolved + pending_closure)

---

## 🎯 สรุป: คำตอบคำถามของคุณ

### ❓ **เมนู "รอดำเนินการ" แสดงสถานะอะไร?**

**คำตอบ:** `new`, `tier1`, `tier2`, `tier3` (ตาม Tier)
- เคสที่**มอบหมายให้ฉันแล้ว แต่ยังไม่ได้รับ**
- มีปุ่ม "รับเคส"

---

### ❓ **เมนู "งานของฉัน" แสดงสถานะอะไร?**

**คำตอบแนะนำ:** `in_progress`, `waiting` (ไม่รวม resolved)

**เหตุผล:**
- ✅ **ตามระบบ Enterprise:** ServiceNow, Jira, Linear แยก resolved ออก
- ✅ **UX ดีกว่า:** ชัดเจนว่าเคสไหนกำลังทำ vs แก้ไขเสร็จแล้ว
- ✅ **Notification Badge:** นับได้ถูกต้อง

---

### ❓ **เมนู "แก้ไขแล้ว" แสดงสถานะอะไร?**

**คำตอบแนะนำ:** `resolved`, `pending_closure` (ไม่รวม closed)

**เหตุผล:**
- ✅ **ตามระบบ Enterprise:** ServiceNow, Jira แยก Resolved กับ Closed
- ✅ **Actionable:** เคสที่รอ**ปิด** (Tier1 ต้องทำ Action)
- ✅ **Notification Badge 🟢:** นับได้ชัดเจน

**Closed ดูที่ไหน?**
- ดูในเมนู "ทั้งหมด" + Filter "Closed"
- ไม่ต้องมีเมนู "ปิดแล้ว" แยก (ตาม Jira, Zendesk)

---

## 📌 สรุปสุดท้าย

**แนะนำ: แนวทาง C (Hybrid)**

```
✅ งานของฉัน = in_progress + waiting (ไม่รวม resolved)
✅ แก้ไขแล้ว 🟢 = resolved + pending_closure (ไม่รวม closed)
✅ ทั้งหมด = ทุก status + Filter: Active/Closed
✅ Notification Badge 3 อัน: 🔵 รอรับเคส | 🔵 งานของฉัน | 🟢 แก้ไขแล้ว
```

**เหตุผล:**
- ✅ ตามมาตรฐาน Enterprise (ServiceNow, Jira, Linear)
- ✅ UX ดี → ชัดเจนว่าเคสไหนต้อง Action
- ✅ Notification Badge ชัดเจน
- ✅ ไม่มีเมนูเยอะเกินไป

---

**ผู้วิเคราะห์:** AI Assistant  
**อ้างอิง:** Jira, ServiceNow, Zendesk, Freshdesk, Linear  
**วันที่:** 14 มกราคม 2026
