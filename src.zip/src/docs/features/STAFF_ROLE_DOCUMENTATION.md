# 👨‍💼 Staff Role - เอกสารฉบับสมบูรณ์

**Last Updated:** 26 มกราคม 2026  
**Version:** 2.1  
**Status:** ✅ เพิ่มฟีเจอร์ Comment สำหรับ Staff

---

## 📋 สารบัญ

1. [ภาพรวม Staff Role](#ภาพรวม-staff-role)
2. [ความแตกต่างระหว่าง Staff vs Tier Workers](#ความแตกต่างระหว่าง-staff-vs-tier-workers)
3. [ฟีเจอร์ทั้งหมดของ Staff](#ฟีเจอร์ทั้งหมดของ-staff)
4. [CreateTicketPage - บันทึกเคสแทนลูกค้า](#createticketpage---บันทึกเคสแทนลูกค้า)
5. [TrackTicketPage - ติดตามเคส](#trackticketpage---ติดตามเคส)
6. [StaffTicketDetailPage - ดูรายละเอียดและเพิ่ม Comment](#staffticketdetailpage---ดูรายละเอียดและเพิ่ม-comment)
7. [StaffClosedTicketsPage - ดูเคสที่ปิดแล้ว](#staffclosedticketspage---ดูเคสที่ปิดแล้ว)
8. [Staff Journey - คู่มือการใช้งาน](#staff-journey---คู่มือการใช้งาน)
9. [Code Reference](#code-reference)
10. [Testing Checklist](#testing-checklist)

---

## 🎯 ภาพรวม Staff Role

### **Staff คือใคร?**
- **เจ้าหน้าที่รับแจ้ง (Staff)** - สมชาย ใจดี
- **ช่องทาง:** รับเรื่องจากลูกค้าผ่าน Phone, Email, Line Official
- **บทบาท:** บันทึกเคสในระบบและแก้ไขปัญหาเบื้องต้น

**👤 Staff Account ในระบบ:**
- ชื่อ: **สมชาย ใจดี** (Staff)
- Username: `staff`
- Password: `staff123`
- Email: `staff@cdg.co.th`
- บทบาท: เจ้าหน้าที่รับแจ้ง (Staff) - บันทึกเคสแทนลูกค้าจากช่องทางอื่น

**👤 Customer Account ในระบบ:**
- ชื่อ: **ศิริพร อารีมิตร** (Customer)
- Username: `customer1`
- Password: `customer1123`
- Email: `siriporn.a@example.com`
- บทบาท: ลูกค้า - แจ้งเคสผ่าน Web Portal

**⚠️ สำคัญ:** ห้ามใช้ชื่อ "สมชาย ใจดี" เป็นชื่อลูกค้า เพราะเป็นชื่อ Staff

### **Staff ทำอะไร?**

#### **Staff Workflow:**
```
1. 📞 รับเรื่องจากลูกค้า (Phone, Email, Line)
   ↓
2. 📝 บันทึกเคสในระบบ (/create)
   ⚠️ **จำเป็นต้องเลือกโครงการ (Required)**
   ↓
3. 📤 ส่งงาน → ส่งต่อ Tier1 (new)
   ↓
4. 👁️ ติดตามสถานะ (/track) - Read-only เท่านั้น
   ↓
   จบ
```

**หมายเหตุ:** 
- Staff มีเพียงปุ่ม "ส่งงาน" เท่านั้น
- ฟีเจอร์ "แก้ไขและปิดเคส" และ "บันทึกและรับเคส" เป็นฟีเจอร์เฉพาะ Tier1 เท่านั้น
- หากผู้ใช้มี Permission ทั้ง Staff และ Tier1 จะเห็นปุ่มทั้ง 3 แบบ (ส่งงาน, แก้ไขและปิดเคส, บันทึกและรับเคส)

### **Staff ไม่ได้ทำอะไร?**
- ❌ **ไม่รับเคสจากระบบ** - ไม่มีปุ่ม "รับเคส"
- ❌ **ไม่ปิดเคสทันที** - ไม่มีปุ่ม "แก้ไขและปิดเคส" (เฉพาะ Tier1 เท่านั้น)
- ❌ **ไม่มี Dashboard** - ไม่ต้องการ Metrics/SLA
- ❌ **ไม่มี Sidebar** - ใช้ HomePage แทน
- ❌ **ไม่มี "งานของฉัน"** - ไม่ถูก assigned
- ❌ **ไม่ส่งต่อเคส** - แค่ส่งตอนสร้างเท่านั้น

---

## 🔄 ความแตกต่างระหว่าง Staff vs Tier Workers

| ลักษณะ | Staff | Tier1/2/3 |
|--------|-------|-----------|
| **บทบาท** | 📞 Middleman | 👨‍💼 Worker |
| **Workflow** | รับ → บันทึก → ส่ง | รับ → แก้ → ส่งต่อ |
| **Dashboard** | ❌ ไม่มี | ✅ มี |
| **Sidebar** | ❌ ไม่มี | ✅ มี |
| **รับเคส** | ❌ ไม่รับ | ✅ กด "รับเคส" |
| **งานของฉัน** | ❌ ไม่มี | ✅ มี |
| **รอดำเนินการ** | ❌ ไม่มี | ✅ มี Queue |
| **ส่งต่อ** | ❌ ส่งแค่ตอนสร้าง | ✅ ส่งได้ตลอด |
| **บันทึกเคส** | ✅ ✅ ✅ | ✅ |
| **ติดตาม** | ✅ Read-only | ✅ Read/Write |
| **ปิดเคสทันที** | ❌ ต้องรับก่อน | ✅ ได้ |
| **บันทึกย้อนหลัง** | ✅ ได้ | ❌ ไม่ได้ |

---

## 🎯 ฟีเจอร์ทั้งหมดของ Staff

### **1. หน้าแรก (HomePage)**
- **Path:** `/`
- **Component:** `/components/HomePage.tsx`
- **ฟีเจอร์:**
  - Quick Actions: แจ้งเคสใหม่, ติดตามเคส, ดูเคสของฉัน
  - สถิติรวมง่ายๆ
  - แจ้งเตือน
- **UI:** Simple & Clean (ไม่ซับซ้อน)

### **2. บันทึกเคสแทนลูกค้า**
- **Path:** `/create`
- **Component:** `/components/CreateTicketPage.tsx`
- **ฟีเจอร์:**
  - ✅ บันทึกข้อมูลลูกค้า
  - ✅ เลือกช่องทางการติดต่อ (Line/Phone/Email)
  - ✅ กรอก Line ID (ถ้าเลือก Line)
  - ✅ เลือกประเภทปัญหา + ความสำคัญ
  - ✅ บันทึกย้อนหลัง (Incident Date)
  - ✅ ส่งงานต่อ Tier1
- **ทางเลือก:**
  - **ส่งงาน**: `status = new`, ส่งต่อ Tier1

### **3. ติดตามเคส**
- **Path:** `/track`
- **Component:** `/components/TrackTicketPage.tsx`
- **ฟีเจอร์:**
  - ✅ ดูเคสที่ตัวเองสร้าง (ไม่รวม `closed`)
  - ✅ กรอง/เรียงลำดับ
  - ✅ Timeline แบบ Read-only
- **Permission:** Read-only

### **4. ดูรายละเอียดและเพิ่ม Comment**
- **Path:** `/ticket-detail/:id`
- **Component:** `/components/StaffTicketDetailPage.tsx`
- **ฟีเจอร์:**
  - ✅ ดูรายละเอียดเคส
  - ✅ เพิ่ม Comment
- **Permission:** Read-only

### **5. ดูเคสที่ปิดแล้ว**
- **Path:** `/closed-tickets`
- **Component:** `/components/StaffClosedTicketsPage.tsx`
- **ฟีเจอร์:**
  - ✅ ดูเคสที่ตัวเองสร้าง (status = `closed`)
  - ✅ แสดงเคสที่ Tier ปิดให้
  - ✅ แสดงคอลัมน์ "ปิดโดย"
- **Permission:** Read-only
- **หมายเหตุ:** Staff ไม่สามารถปิดเคสเองได้ (ไม่มีปุ่ม "แก้ไขและปิดเคส") จะเห็นเฉพาะเคสที่ Tier1/2/3 ปิดให้เท่านั้น

### **6. คู่มือการใช้งาน**
- **Path:** `/staff-journey`
- **Component:** `/components/StaffJourneyPage.tsx`
- **ฟีเจอร์:**
  - ✅ อธิบายขั้นตอนการทำงาน
  - ✅ ช่องทางที่รองรับ
  - ✅ CTA: "เริ่มบันทึกเคส"
- **Purpose:** Onboarding สำหรับ Staff ใหม่

---

## 📝 CreateTicketPage - บันทึกเคสแทนลูกค้า

### **ไฟล์:** `/components/CreateTicketPage.tsx`

### **ฟิลด์พิเศษที่ Staff มี (เท่านั้น):**

#### **1. ช่องทางการติดต่อ (Channel Selection)** ⭐ Required
```tsx
// บรรทัด 212-230
{hasRole(user, 'staff') && (
  <div className="space-y-2">
    <Label htmlFor="channel">ช่องทางการติดต่อ *</Label>
    <Select required onValueChange={setSelectedChannel}>
      <SelectContent>
        <SelectItem value="line">Line</SelectItem>
        <SelectItem value="phone">โทรศัพท์</SelectItem>
        <SelectItem value="email">Email</SelectItem>
      </SelectContent>
    </Select>
  </div>
)}
```

**ตัวเลือก:**
- ✅ `line` - Line Official Account
- ✅ `phone` - โทรศัพท์
- ✅ `email` - อีเมล

**Purpose:** เลือกช่องทางที่ลูกค้าติดต่อเข้ามา

---

#### **2. Line ID** (Conditional) ⭐ Required ถ้าเลือก Line
```tsx
// บรรทัด 232-245
{selectedChannel === 'line' && (
  <div className="space-y-2">
    <Label htmlFor="lineId">Line ID *</Label>
    <Input 
      id="lineId" 
      required 
      placeholder="เช่น @example หรือ user123" 
    />
    <p className="text-xs text-gray-500">
      กรอก Line ID ของลูกค้าที่ติดต่อเข้ามา
    </p>
  </div>
)}
```

**แสดงเมื่อ:** `selectedChannel === 'line'`

**Format:** `@example` หรือ `user123`

---

#### **3. ประเภทปัญหา (Issue Type)** ⭐ Required
```tsx
// บรรทัด 290-309
{hasRole(user, 'staff') && (
  <div className="space-y-2">
    <Label htmlFor="type">ประเภทปัญหา *</Label>
    <Select required onValueChange={setSelectedType}>
      <SelectContent>
        <SelectItem value="incident">Incident</SelectItem>
        <SelectItem value="service_request">Service Request</SelectItem>
        <SelectItem value="security_incident">
          <span className="flex items-center gap-2">
            🔒 Security Incident
          </span>
        </SelectItem>
      </SelectContent>
    </Select>
  </div>
)}
```

**ตัวเลือก:**
- ✅ `incident` - Incident (ปัญหาทั่วไป)
- ✅ `service_request` - Service Request (คำขอบริการ)
- ✅ `security_incident` - 🔒 Security Incident (เหตุการณ์ด้านความปลอดภัย)

---

#### **4. ความสำคัญ (Priority)** ⭐ Required
```tsx
// บรรทัด 311-324
{hasRole(user, 'staff') && (
  <div className="space-y-2">
    <Label htmlFor="priority">ความสำคัญ *</Label>
    <Select required>
      <SelectContent>
        <SelectItem value="low">น้อย - รอได้</SelectItem>
        <SelectItem value="medium">ปานกลาง - ความสำคัญปกติ</SelectItem>
        <SelectItem value="high">สูง - ส่งผลกระทบต่อการทำงาน</SelectItem>
        <SelectItem value="critical">วิกฤติ - ระบบหยุดการทำงาน</SelectItem>
      </SelectContent>
    </Select>
  </div>
)}
```

**ตัวเลือก:**
- ✅ `low` - น้อย - รอได้
- ✅ `medium` - ปานกลาง - ความสำคัญปกติ
- ✅ `high` - สูง - ส่งผลกระทบต่อการทำงาน
- ✅ `critical` - วิกฤติ - ระบบหยุดการทำงาน

---

#### **5. วันที่เกิดเหตุ (Incident Date)** - บันทึกย้อนหลัง
```tsx
// บรรทัด 354-368
{hasRole(user, 'staff') && (
  <div className="mt-6 space-y-2">
    <Label htmlFor="incidentDate">วันที่เกิดเหตุ</Label>
    <Input 
      id="incidentDate" 
      type="datetime-local"
      value={incidentDate}
      onChange={(e) => setIncidentDate(e.target.value)}
    />
    <p className="text-xs text-gray-500">
      💡 ระบุวันที่และเวลาที่เกิดปัญหาจริง (ถ้าไม่ระบุจะใช้วันเวลาปัจจุบัน)
    </p>
  </div>
)}
```

**Type:** `datetime-local`

**Default:** วันเวลาปัจจุบัน (Auto-fill จาก useEffect บรรทัด 40-51)

**Purpose:** บันทึกเคสย้อนหลังเพื่อเก็บประวัติ

**Use Cases:**
- ลูกค้าโทรมาเมื่อเช้า แต่ Staff บันทึกตอนบ่าย → ตั้งเวลาเป็นเช้า
- บันทึกเคสจากอีเมลที่ส่งมาเมื่อวานซืน
- เก็บประวัติเคสโทรศัพท์ที่แก้ไขไปแล้ว

---

#### **6. Security Incident Warning**
```tsx
// บรรทัด 327-350
{selectedType === 'security_incident' && (
  <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
    <div className="flex gap-3">
      <span className="text-red-600 text-xl flex-shrink-0">⚠️</span>
      <div className="space-y-1">
        <h4 className="text-red-900">Security Incident - การแจ้งเตือนพิเศษ</h4>
        <p className="text-sm text-red-800">
          เคสนี้เป็นเหตุการณ์ด้านความปลอดภัย จะถูกส่งต่อไปยังทีมความปลอดภัยทันที
        </p>
        <ul className="text-sm text-red-800 list-disc list-inside mt-2">
          <li>• เคสนี้จะมี Priority สูงกว่าปกติ</li>
          <li>• จะแจ้งเตือนทีม Security ผ่านหลายช่องทาง</li>
          <li>• อาจมีการติดตามและรายงานเพิ่มเติมตามนโยบายองค์กร</li>
        </ul>
        <p className="text-sm text-red-800 mt-3">
          <strong>ตัวอย่างเคส Security Incident:</strong> 
          การเข้าถึงที่ไม่ได้รับอนุญาต, การรั่วไหลของข้อมูล, 
          มัลแวร์/ไวรัส, การโจมตีทางไซเบอร์, ช่องโหว่ด้านความปลอดภัย
        </p>
      </div>
    </div>
  </div>
)}
```

**แสดงเมื่อ:** `selectedType === 'security_incident'`

**ฟีเจอร์:**
- ⚠️ แสดงคำเตือนสีแดง
- 📢 แจ้งว่าจะส่งต่อทีมความปลอดภัยทันที
- 📋 แสดงตัวอย่างเคส Security Incident

---

### **ปุ่มทางเลือกสำหรับ Staff:**

```tsx
<div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
  <Button type="button" variant="outline" onClick={() => onNavigate('/')}>
    ยกเลิก
  </Button>
  
  {/* ปุ่ม: ส่งงาน */}
  <Button type="submit" size="lg">
    ส่งงาน
  </Button>
</div>
```

**หมายเหตุ:** Staff มีเพียงปุ่ม "ส่งงาน" เท่านั้น (ไม่มีปุ่ม "แก้ไขและปิดเคส" - เป็นฟีเจอร์เฉพาะ Tier1)

---

### **การทำงานของปุ่ม:**

| ปุ่ม | Function | Status | assignedTo | ส่งต่อ? |
|------|----------|--------|------------|---------|
| **📤 ส่งงาน** | `handleSubmit()` | `new` | `null` | ✅ ส่ง Tier1 |

---

### **Use Cases:**

#### **ส่งงาน (Submit)**
**เหมาะกับ:**
- ✅ ทุกประเภทปัญหา (Incident, Service Request, Security Incident)
- ✅ ปัญหาซับซ้อน
- ✅ ต้องการ Technical Team แก้ไข
- ✅ ต้องการตรวจสอบจาก Tier1/2/3
- ✅ ต้องใช้เวลาในการแก้ไข

**Flow:**
```
ลูกค้าโทรมา → Staff บันทึกเคส 
→ กด "ส่งงาน" 
→ บันทึกเคส 
→ Status = new, assignedTo = null 
→ Tier1 เห็นเคสใน "รอดำเนินการ" 
→ Tier1 กด "รับเคส"
```

---

#### **บันทึกย้อนหลัง (Backdate)**
**เหมาะกับ:**
- ✅ เก็บประวัติเคสโทรศัพท์ที่แก้ไขไปแล้ว
- ✅ บันทึกเคสจากอีเมลที่ส่งมาเมื่อก่อน
- ✅ เก็บ Log การแก้ไข

**Flow:**
```
ลูกค้าโทรมาเมื่อเช้า (09:00) → Staff บันทึกตอนบ่าย (14:00)
→ ตั้ง Incident Date = 09:00 (ย้อนหลัง)
→ กด "ส่งงาน"
→ เก็บประวัติไว้ว่าเกิดเมื่อเช้า แก้ไขเมื่อบ่าย
```

---

## 👁️ TrackTicketPage - ติดตามเคส

### **ไฟล์:** `/components/TrackTicketPage.tsx`

### **ฟีเจอร์:**
- ✅ ดูเคสที่ตัวเองสร้าง (ไม่รวม `closed`)
- ✅ กรองตาม Status, Priority
- ✅ เรียงลำดับ
- ✅ Timeline แบบ Read-only

### **Permission:** Read-only

### **Status ที่แสดง:**
- ✅ `new`, `tier1`, `tier2`, `tier3`
- ✅ `in_progress`, `waiting`, `resolved`, `pending_closure`
- ❌ `closed` (ไปอยู่ `/closed-tickets`)

---

## 📝 StaffTicketDetailPage - ดูรายละเอียดและเพิ่ม Comment

### **ไฟล์:** `/components/StaffTicketDetailPage.tsx`

### **ฟีเจอร์:**
- ✅ ดูรายละเอียดเคสที่ตัวเองสร้าง
- ✅ แสดง Timeline
- ✅ **เพิ่ม Comment ได้** (เฉพาะเคส Active)
- ✅ แยก **Public Comment** และ **Internal Note**
- ❌ ไม่สามารถแก้ไขเคส
- ❌ ไม่สามารถ comment ในเคส closed

### **Permission:** 
- **Read-only** สำหรับข้อมูลเคส
- **Write** สำหรับ Comment (เฉพาะ Active tickets)

### **Comment Types:**

#### **1. Public Comment (ความคิดเห็นสาธารณะ)**
- ✅ ลูกค้าเห็นได้
- ✅ ส่งถึงลูกค้าทางอีเมล/Line
- ✅ แสดงใน Timeline
- **Use Cases:**
  - ลูกค้าโทรกลับเพิ่มข้อมูล
  - Tier ถามข้อมูลเพิ่มเติม
  - แจ้งสถานะให้ลูกค้าทราบ

#### **2. Internal Note (หมายเหตุภายใน)**
- ✅ เห็นเฉพาะเจ้าหน้าที่ (Staff, Tier, Admin)
- ❌ ลูกค้าไม่เห็น
- ✅ แสดงใน Timeline (เฉพาะเจ้าหน้าที่)
- **Use Cases:**
  - บันทึกข้อมูลภายใน
  - บันทึกการโทรศัพท์
  - ข้อมูลที่ไม่ควรให้ลูกค้าเห็น

### **กฎการ Comment:**

| สถานะเคส | Staff สามารถ Comment? | หมายเหตุ |
|---------|----------------------|----------|
| **new** | ✅ ได้ | เคสใหม่ |
| **tier1** | ✅ ได้ | Tier1 รับเคสแล้ว |
| **tier2** | ✅ ได้ | ส่งต่อ Tier2 |
| **tier3** | ✅ ได้ | ส่งต่อ Tier3 |
| **in_progress** | ✅ ได้ | กำลังดำเนินการ |
| **waiting** | ✅ ได้ | หยุดชั่วคราว |
| **resolved** | ✅ ได้ | แก้ไขเสร็จแล้ว (รอปิด) |
| **closed** | ❌ **ไม่ได้** | **ปิดแล้ว - ไม่สามารถ comment ได้** |

### **UI:**

```
┌─────────────────────────────────────────────┐
│  ดูรายละเอียดเคสลูกค้า                       │
│  #TKT-2024-001234                           │
├─────────────────────────────────────────────┤
│  📋 รายละเอียดเคส                           │
│  - หัวเรื่อง: ...                           │
│  - สถานะ: [กำลังดำเนินการ]                  │
│  - ช่องทาง: [Line]                          │
│                                             │
│  ⏱️ Timeline                                 │
│  - เคสถูกสร้างโดย สมชาย ใจดี (Staff)         │
│  - ส่งต่อ Tier1                             │
│  - Tier1 รับเคส                             │
│                                             │
│  💬 ความคิดเห็นและการตอบกลับ                │
│  ┌─────────────────────────────────────┐   │
│  │ Toggle: [ความคิดเห็นสาธารณะ ▼]       │   │
│  │         [หมายเหตุภายใน]              │   │
│  │                                     │   │
│  │ พิมพ์ข้อความของคุณที่นี่...          │   │
│  │                                     │   │
│  │ [ส่งการตอบกลับ]                     │   │
│  └─────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
```

---

## 📁 StaffClosedTicketsPage - ดูเคสที่ปิดแล้ว

### **ไฟล์:** `/components/StaffClosedTicketsPage.tsx`

### **ฟีเจอร์:**
- ✅ ดูเคสที่ตัวเองสร้าง (status = `closed`)
- ✅ แสดงเคสที่ Tier ปิดให้
- ✅ แสดงคอลัมน์ "ปิดโดย"
- ✅ กรองตามช่วงเวลา
- ❌ **ไม่สามารถ comment** (Read-only ทั้งหมด)

### **Permission:** Read-only

### **Channel ที่แสดง:**
- ✅ `phone`, `email`, `line`

---

## 📖 Staff Journey - คู่มือการใช้งาน

### **ไฟล์:** `/components/StaffJourneyPage.tsx`

### **ฟีเจอร์:**
- ✅ อธิบายบทบาท Staff
- ✅ ช่องทางที่รองรับ (Line, Email, โทรศัพท์)
- ✅ ขั้นตอนการทำงาน 5 ขั้นตอน
- ✅ CTA ชัดเจน: "เริ่มบันทึกเคส"

### **UI:**
```
┌─────────────────────────────────────────────┐
│  คู่มือการบันทึกเคสสำหรับเจ้าหน้าที่         │
├─────────────────────────────────────────────┤
│  📱 รองรับช่องทาง:                          │
│  [Line] [Email] [โทรศัพท์]                 │
│                                             │
│  ⭐ [เริ่มบันทึกเคส] ← ปุ่มใหญ่ CTA        │
│                                             │
│  📋 ขั้นตอนการทำงาน (5 ขั้นตอน):           │
│  1️⃣ รับเรื่องจากลูกค้า                     │
│  2️⃣ บันทึกข้อมูลในระบบ                     │
│  3️⃣ เลือกวิธีการ (แก้ไขทันที / ส่งต่อ)     │
│  4️⃣ ติดตามสถานะ                           │
│  5️⃣ แจ้งผลลูกค้า                           │
└─────────────────────────────────────────────┘
```

---

## 💻 Code Reference

### **State สำหรับ Staff Features**

```typescript
// /components/CreateTicketPage.tsx

// State ทั่วไป
const [submitted, setSubmitted] = useState(false);
const [ticketNumber, setTicketNumber] = useState('');
const [description, setDescription] = useState('');
const [tags, setTags] = useState<string[]>([]);
const [attachments, setAttachments] = useState<Attachment[]>([]);

// State สำหรับ Staff only
const [selectedChannel, setSelectedChannel] = useState(''); // Line/Phone/Email
const [selectedType, setSelectedType] = useState(''); // Incident/Service Request/Security Incident
const [incidentDate, setIncidentDate] = useState(''); // Incident Date (backdate)
```

---

### **Auto-fill Incident Date**

```typescript
// บรรทัด 40-51
useEffect(() => {
  if (hasRole(user, 'staff')) {
    const now = new Date();
    // Format as YYYY-MM-DDTHH:mm for datetime-local input
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    setIncidentDate(`${year}-${month}-${day}T${hours}:${minutes}`);
  }
}, [user]);
```

---

### **Permission Check**

```typescript
import { hasRole } from '../lib/utils';

// ตรวจสอบว่าเป็น Staff หรือไม่
{hasRole(user, 'staff') && (
  // แสดงฟิลด์/ปุ่มพิเศษ
)}
```

---

## ✅ Testing Checklist

### **1. CreateTicketPage - บันทึกเคสแทนลูกค้า**

**Test Case 1.1: แสดงฟิลด์ Staff only**
- [ ] Login ด้วย Staff
- [ ] ไป `/create`
- [ ] ต้องเห็น: ช่องทางการติดต่อ, ประเภทปัญหา, ความสำคัญ, วันที่เกิดเหตุ
- [ ] ต้องเห็นปุ่ม: "ส่งงาน"

**Test Case 1.2: Channel Selection**
- [ ] เลือก Channel = "Line"
- [ ] ต้องแสดงฟิลด์ "Line ID"
- [ ] กรอก Line ID ต้อง Required
- [ ] เลือก Channel = "โทรศัพท์" หรือ "Email"
- [ ] ต้องไม่แสดงฟิลด์ "Line ID"

**Test Case 1.3: Security Incident Warning**
- [ ] เลือก Issue Type = "Security Incident"
- [ ] ต้องแสดงคำเตือนสีแดง
- [ ] แสดงข้อความ: "เคสนี้เป็นเหตุการณ์ด้านความปลอดภัย..."

**Test Case 1.4: Incident Date (Backdate)**
- [ ] ฟิลด์ Incident Date ต้อง Auto-fill วันเวลาปัจจุบัน
- [ ] สามารถเปลี่ยนเป็นวันที่ย้อนหลังได้
- [ ] สามารถเปลี่ยนเวลาได้

**Test Case 1.5: ส่งงาน**
- [ ] กด "ส่งงาน"
- [ ] ไม่แสดง Modal
- [ ] แสดงหน้าสำเร็จ พร้อม Ticket Number

---

### **2. TrackTicketPage - ติดตามเคส**

**Test Case 2.1: แสดงเคสของตัวเอง**
- [ ] Login ด้วย Staff
- [ ] ไป `/track`
- [ ] แสดงเฉพาะเคสที่ตัวเองสร้าง
- [ ] ไม่แสดงเคส Status = `closed`

**Test Case 2.2: กรอง/เรียงลำดับ**
- [ ] สามารถกรองตาม Status
- [ ] สามารถกรองตาม Priority
- [ ] สามารถเรียงลำดับได้

**Test Case 2.3: ดูรายละเอียด**
- [ ] คลิกเคส
- [ ] แสดงรายละเอียดเคส
- [ ] แสดง Timeline แบบ Read-only
- [ ] ไม่มีปุ่มแก้ไข

---

### **3. StaffClosedTicketsPage - ดูเคสที่ปิดแล้ว**

**Test Case 3.1: แสดงเคสปิดแล้ว**
- [ ] Login ด้วย Staff
- [ ] ไป `/closed-tickets`
- [ ] แสดงเฉพาะเคส Status = `closed`
- [ ] แสดงเฉพาะเคสที่ตัวเองสร้าง

**Test Case 3.2: แสดงเคสที่ Tier ปิดให้**
- [ ] แสดงเคสที่ Tier1/2/3 ปิดให้

**Test Case 3.3: แสดงคอลัมน์**
- [ ] แสดงคอลัมน์ "ปิดโดย"
- [ ] แสดงชื่อผู้ปิดเคส
- [ ] แสดงวันที่ปิด

---

### **4. StaffJourneyPage - คู่มือการใช้งาน**

**Test Case 4.1: แสดงคู่มือ**
- [ ] Login ด้วย Staff
- [ ] ไป `/staff-journey`
- [ ] แสดงช่องทางที่รองรับ (Line, Email, โทรศัพท์)
- [ ] แสดงขั้นตอนการทำงาน 5 ขั้นตอน
- [ ] แสดงปุ่ม CTA "เริ่มบันทึกเคส"

**Test Case 4.2: CTA**
- [ ] คลิก "เริ่มบันทึกเคส"
- [ ] นำทางไปที่ `/create`

---

### **5. HomePage - หน้าแรก**

**Test Case 5.1: Quick Actions**
- [ ] Login ด้วย Staff
- [ ] ไป `/`
- [ ] แสดง Quick Actions:
  - [ ] แจ้งเคสใหม่
  - [ ] ติดตามเคส
  - [ ] ดูเคสของฉัน
- [ ] แสดงสถิติรวมง่ายๆ

**Test Case 5.2: Navigation**
- [ ] คลิก "แจ้งเคสใหม่" → ไป `/create`
- [ ] คลิก "ติดตามเคส" → ไป `/track`
- [ ] คลิก "ดูเคสของฉัน" → ไป `/closed-tickets`

---

## 📊 สรุป

### **Staff Features Matrix**

| ฟีเจอร์ | Path | Component | Permission | Status |
|---------|------|-----------|------------|--------|
| **หน้าแรก** | `/` | HomePage | - | ✅ Done |
| **บันทึกเคส** | `/create` | CreateTicketPage | Create | ✅ Done |
| **ติดตามเคส** | `/track` | TrackTicketPage | Read-only | ✅ Done |
| **ดูรายละเอียดและเพิ่ม Comment** | `/ticket-detail/:id` | StaffTicketDetailPage | Read-only | ✅ Done |
| **เคสปิดแล้ว** | `/closed-tickets` | StaffClosedTicketsPage | Read-only | ✅ Done |
| **คู่มือ** | `/staff-journey` | StaffJourneyPage | - | ✅ Done |

---

### **ฟิลด์พิเศษของ Staff**

| ฟิลด์ | Required | Type | Purpose |
|------|----------|------|---------|
| **ช่องทางการติดต่อ** | ✅ | Select | เลือก Line/Phone/Email |
| **Line ID** | ✅ (ถ้าเลือก Line) | Input | กรอก Line ID |
| **ประเภทปัญหา** | ✅ | Select | Incident/Service Request/Security |
| **ความสำคัญ** | ✅ | Select | Low/Medium/High/Critical |
| **วันที่เกิดเหตุ** | ❌ | datetime-local | บันทึกย้อนหลัง |

---

### **2 ทางเลือกของ Staff**

| ทางเลือก | Status | assignedTo | ส่งต่อ? |
|----------|--------|------------|---------|
| **📤 ส่งงาน** | `new` | `null` | ✅ Tier1 |

---

## 📚 เอกสารอ้างอิง

- [PERMISSION_MATRIX.md](/docs/PERMISSION_MATRIX.md) - ตาราง Permission ทั้งหมด
- [PROJECT_OVERVIEW.md](/docs/PROJECT_OVERVIEW.md) - ภาพรวมโปรเจค
- [WORKFLOW.md](/docs/WORKFLOW.md) - เวิร์กโฟลว์ทั้งหมด
- [NAVIGATION_MENU.md](/docs/NAVIGATION_MENU.md) - โครงสร้างเมนู

---

**เอกสารนี้อัพเดทล่าสุด:** 26 มกราคม 2026  
**สถานะ:** ✅ เสร็จสมบูรณ์และทดสอบแล้ว  
**Version:** 2.1 - เพิ่มฟีเจอร์ Comment สำหรับ Staff
