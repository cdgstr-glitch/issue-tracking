# 📋 ฟีเจอร์การเลือกโครงการ (Project Selection Features)

## 📅 วันที่อัปเดต
24 มกราคม 2026

---

## 🎯 ภาพรวม

ระบบ CDGS Issue Tracking Platform มีฟีเจอร์การเลือกโครงการ 3 จุดหลัก:

1. **Modal เลือกโครงการในปุ่ม "แก้ไขและปิดเคส"** - สำหรับ Staff
2. **Modal เลือกโครงการในปุ่ม "รับเคส"** - สำหรับ Tier1 (เคสจาก Web)
3. **Dropdown เลือกโครงการในหน้าบันทึกเคส** - สำหรับ Staff

**📖 เอกสารเพิ่มเติม:**
- 🏢 [Organization Selector Component](/docs/components/ORGANIZATION_SELECTOR.md) - รายละเอียดการทำงานของ Step 1 (เลือกหน่วยงาน)

---

## 🆕 2️⃣ Modal เลือกโครงการในปุ่ม "รับเคส" (Tier1 - เคสจาก Web)

### 📍 ตำแหน่ง
- **ไฟล์:** `/components/TicketActions.tsx`
- **อัปเดต:** 24 มกราคม 2026

### 👤 ผู้ใ���้งาน
- **Tier1** - เจ้าหน้าที่รับเคสลำดับแรก

### 🎯 วัตถุประสงค์
เมื่อลูกค้าแจ้งเคสผ่าน Web โดยตรง เคสจะไม่มีข้อมูล `projectId` เนื่องจากลูกค้าไม่ทราบว่าเคสของตนอยู่ในโครงการใด ดังนั้น Tier1 จำเป็นต้อง**เลือกโครงการก่อนรับเคส**เพื่อให้เคสมีข้อมูลโครงการครบถ้วน

### ✅ กรณีการใช้งาน

#### กรณีที่ 1: เคสจาก Web (ไม่มี projectId)
```
ลูกค้าแจ้งเคสผ่าน Web
  ↓
Tier1 กดปุ่ม "รับเคส"
  ↓
📌 แสดง Modal เลือกโครงการ
  ↓
เลือก Organization → เลือก Project
  ↓
กดปุ่ม "รับเคส"
  ↓
✅ บันทึก projectId, projectCode, projectName, organizationName
✅ เปลี่ยนสถานะเป็น 'in_progress'
```

#### กรณีที่ 2: เคสจาก Staff (มี projectId แล้ว)
```
Staff บันทึกเคส + เลือกโครงการแล้ว
  ↓
Tier1 กดปุ่ม "รับเคส"
  ↓
✅ รับเคสได้เลย (ไม่มี Modal)
```

### 🔧 Logic การทำงาน

```typescript
// เช็คว่าเคสต้องเลือกโครงการก่อนรับหรือไม่
const needsProjectSelection = !ticket.projectId && ticket.status === 'new' && hasTier1;

// ถ้าต้องเลือก → แสดง Dialog
// ถ้าไม่ต้อง → รับเคสได้เลย
{canAccept && (
  needsProjectSelection ? (
    <Dialog> {/* เลือกโครงการก่อน */} </Dialog>
  ) : (
    <Button onClick={handleAccept}>รับเคส</Button>
  )
)}
```

### 📊 UI Modal

```
┌────────────────────────────────────────┐
│ เลือกโครงการก่อนรับเคส                │
├────────────────────────────────────────┤
│ เคสนี้ยังไม่มีข้อมูลโครงการ           │
│ กรุณาเลือกหน่วยงานและโครงการ         │
│                                        │
│ หน่วยงาน:                              │
│ ┌────────────────────────────────────┐ │
│ │ [DGA] สำนักงานพัฒนารัฐบาลดิจิทัล  │ │
│ └────────────────────────────────────┘ │
│                                        │
│ โครงการ:                               │
│ ┌────────────────────────────────────┐ │
│ │ D26-0011 - โครงการหลัก - สำนักงาน│ │
│ └────────────────────────────────────┘ │
│                                        │
│            [ยกเลิก]  [✓ รับเคส]       │
└────────────────────────────────────────┘
```

### 💾 ข้อมูลที่บันทึก

เมื่อเลือกโครงการและกด "รับเคส" ระบบจะบันทึก:

```typescript
{
  status: 'in_progress',
  assignedTo: userId,
  assignedBy: userId,
  assignedAt: new Date(),
  projectId: 'proj-xxx',           // ✅ เพิ่ม
  projectCode: 'D26-0011',         // ✅ เพิ่ม
  projectName: 'โครงการหลัก...',   // ✅ เพิ่ม
  organizationName: 'สำนักงาน...'  // ✅ เพิ่ม
}
```

### 🐛 Bug ที่แก้ไข

**ปัญหาเดิม:**
- เคสจาก Web (ไม่มี projectId) สามารถรับเคสได้ทันที
- ทำให้เคสไม่มีข้อมูลโครงการ → ไม่สามารถ track ได้

**แก้ไข:**
- ✅ เพิ่ม logic เช็ค `!ticket.projectId`
- ✅ แสดง modal เลือกโครงการก่อนรับเคส
- ✅ บันทึกข้อมูลโครงการครบถ้วน

### 🧪 Test Cases

| Test Case | Input | Expected Output |
|-----------|-------|-----------------|
| TC1: เคสจาก Web ไม่มี projectId | กดปุ่ม "รับเคส" | แสดง modal เลือกโครงการ |
| TC2: เลือก Organization | เลือก DGA | แสดง dropdown โครงการของ DGA |
| TC3: เลือก Project และรับเคส | เลือกโครงการ D26-0011 | บันทึกข้อมูลโครงการ + รับเคส |
| TC4: เคสจาก Staff มี projectId | กดปุ่ม "รับเคส" | รับเคสได้เลย ไม่มี modal |

---

## 1️⃣ Modal เลือกโครงการในปุ่ม "แก้ไขและปิดเคส" (Staff)

### 📍 ตำแหน่ง
- **ไฟล์:** `/components/CreateTicketPage.tsx`
- **บรรทัด:** 36-180 (States), 988-1120 (Modal UI)

### 👤 ผู้ใช้งาน
- **Staff** (เพียวๆ) - บุคลากรที่บันทึกเคสแทนลูกค้า

### 🎯 วัตถุประสงค์
เมื่อ Staff บันทึกเคสแทนลูกค้าผ่านช่องทางต่างๆ (โทรศัพท์, อีเมล, ไลน์) และต้องการปิดเคสทันที (กรณีเคสเล็กน้อย) Staff จำเป็นต้องระบุโครงการที่เคสนี้เกี่ยวข้องเพื่อใช้ในการรายงานและสถิติ

### ✨ ฟีเจอร์

#### 🔍 การค้นหาโครงการ
- ค้นหาด้วย **ชื่อย่อ** (เช่น ERC, SMIT, DOH)
- ค้นหาด้วย **รหัสโครงการ** (เช่น PRJ-2024-001)
- ค้นหาด้วย **ชื่อเต็มโครงการ** (เช่น ระบบบริหารจัดการ)
- Real-time search (ค้นหาทันทีขณะพิมพ์)
- ปุ่มล้างการค้นหา (X)

#### 📊 การแสดงผลรายการโครงการ
```
┌─────────────────────────────────────────────┐
│ [Badge: ชื่อย่อ]  รหัสโครงการ              │
│ ชื่อเต็มโครงการ                             │
│ แผนก / Department                           │
└─────────────────────────────────────────────┘
```

**ตัวอย่าง:**
```
┌─────────────────────────────────────────────┐
│ [ERC]  PRJ-2024-001                         │
│ ระบบบริหารจัดการศูนย์ฉุกเฉิน               │
│ แผนก IT & Infrastructure                   │
└─────────────────────────────────────────────┘
```

#### ✅ Validation
- **ต้องเลือกโครงการ** ก่อนปิดเคส
- แสดง Alert หากไม่ได้เลือกโครงการ

#### 💾 ข้อมูลที่บันทึก
เมื่อเลือกโครงการและปิดเคส ระบบจะบันทึก:
```javascript
{
  projectId: "proj-001",           // ✅ ID ของโครงการ
  projectCode: "PRJ-2024-001",     // ✅ รหัสโครงการ
  projectName: "ระบบบริหารจัดการ", // ✅ ชื่อเต็ม
  projectShortName: "ERC",         // ✅ ชื่อย่อ
  status: "closed",                // ✅ เปลี่ยนสถานะเป็นปิด
  closedAt: new Date(),            // ✅ วันเวลาที่ปิด
  closedBy: userId                 // ✅ ผู้ปิดเคส
}
```

### 🔄 Flow การทำงาน
```
Staff กรอกฟอร์มบันทึกเคสแทนลูกค้า
↓
กดปุ่ม "แก้ไขและปิดเคส"
↓
Validate ฟอร์มหลัก (หัวเรื่อง, คำอธิบาย, ฯลฯ)
↓
✅ ผ่าน → แสดง Modal "แก้ไขและปิดเคส"
↓
Staff กรอก:
  - วิธีแก้ไข (Solution) *
  - หมายเหตุการปิด (Closure Notes)
  - ⭐ เลือกโครงการ *
↓
Validate:
  - ต้องกรอกวิธีแก้ไข
  - ต้องเลือกโครงการ
↓
✅ ผ่าน → บันทึกเคสและปิด
↓
แสดงหน้าสำเร็จ พร้อมหมายเลขเคส
↓
Staff เลือก:
  - "เคสที่ปิดย้อนหลัง" → ดูเคสที่ปิดทั้งหมด
  - "กลับหน้าหลัก" → กลับไปหน้า Dashboard
```

### 📸 UI Components
- **Search Box**: Input with Search Icon + Clear Button
- **Dropdown List**: Scrollable, Height: 300px max
- **Project Card**: Badge (ชื่อย่อ) + รหัส + ชื่อเต็ม + แผนก
- **Selected State**: Highlight with Checkmark Icon

---

## 3️⃣ Dropdown เลือกโครงการในหน้าบันทึกเคส (Staff)

### 📍 ตำแหน่ง
- **ไฟล์:** `/components/CreateTicketPage.tsx`
- **บรรทัด:** 36-180 (States), 988-1120 (Modal UI)

### 👤 ผู้ใช้งาน
- **Staff** (เพียวๆ) - บุคลากรที่บันทึกเคสแทนลูกค้า

### 🎯 วัตถุประสงค์
เมื่อ Staff บันทึกเคสแทนลูกค้าผ่านช่องทางต่างๆ (โทรศัพท์, อีเมล, ไลน์) และต้องการปิดเคสทันที (กรณีเคสเล็กน้อย) Staff จำเป็นต้องระบุโครงการที่เคสนี้เกี่ยวข้องเพื่อใช้ในการรายงานและสถิติ

### ✨ ฟีเจอร์

#### 🔍 การค้นหาโครงการ
- ค้นหาด้วย **ชื่อย่อ** (เช่น ERC, SMIT, DOH)
- ค้นหาด้วย **รหัสโครงการ** (เช่น PRJ-2024-001)
- ค้นหาด้วย **ชื่อเต็มโครงการ** (เช่น ระบบบริหารจัดการ)
- Real-time search (ค้นหาทันทีขณะพิมพ์)
- ปุ่มล้างการค้นหา (X)

#### 📊 การแสดงผลรายการโครงการ
```
┌─────────────────────────────────────────────┐
│ [Badge: ชื่อย่อ]  รหัสโครงการ              │
│ ชื่อเต็มโครงการ                             │
│ แผนก / Department                           │
└─────────────────────────────────────────────┘
```

**ตัวอย่าง:**
```
┌─────────────────────────────────────────────┐
│ [ERC]  PRJ-2024-001                         │
│ ระบบบริหารจัดการศูนย์ฉุกเฉิน               │
│ แผนก IT & Infrastructure                   │
└─────────────────────────────────────────────┘
```

#### ✅ Validation
- **ต้องเลือกโครงการ** ก่อนปิดเคส
- แสดง Alert หากไม่ได้เลือกโครงการ

#### 💾 ข้อมูลที่บันทึก
เมื่อเลือกโครงการและปิดเคส ระบบจะบันทึก:
```javascript
{
  projectId: "proj-001",           // ✅ ID ของโครงการ
  projectCode: "PRJ-2024-001",     // ✅ รหัสโครงการ
  projectName: "ระบบบริหารจัดการ", // ✅ ชื่อเต็ม
  projectShortName: "ERC",         // ✅ ชื่อย่อ
  status: "closed",                // ✅ เปลี่ยนสถานะเป็นปิด
  closedAt: new Date(),            // ✅ วันเวลาที่ปิด
  closedBy: userId                 // ✅ ผู้ปิดเคส
}
```

### 🔄 Flow การทำงาน
```
Staff กรอกฟอร์มบันทึกเคสแทนลูกค้า
↓
กดปุ่ม "แก้ไขและปิดเคส"
↓
Validate ฟอร์มหลัก (หัวเรื่อง, คำอธิบาย, ฯลฯ)
↓
✅ ผ่าน → แสดง Modal "แก้ไขและปิดเคส"
↓
Staff กรอก:
  - วิธีแก้ไข (Solution) *
  - หมายเหตุการปิด (Closure Notes)
  - ⭐ เลือกโครงการ *
↓
Validate:
  - ต้องกรอกวิธีแก้ไข
  - ต้องเลือกโครงการ
↓
✅ ผ่าน → บันทึกเคสและปิด
↓
แสดงหน้าสำเร็จ พร้อมหมายเลขเคส
↓
Staff เลือก:
  - "เคสที่ปิดย้อนหลัง" → ดูเคสที่ปิดทั้งหมด
  - "กลับหน้าหลัก" → กลับไปหน้า Dashboard
```

### 📸 UI Components
- **Search Box**: Input with Search Icon + Clear Button
- **Dropdown List**: Scrollable, Height: 300px max
- **Project Card**: Badge (ชื่อย่อ) + รหัส + ชื่อเต็ม + แผนก
- **Selected State**: Highlight with Checkmark Icon

---

## 🔐 สิทธิ์การเข้าถึง

### Staff
- ✅ ใช้ Modal เลือกโครงการในปุ่ม "แก้ไขและปิดเคส"
- ❌ **ไม่มีปุ่ม "รับเคส"** (Staff ไม่สามารถรับเคสได้)

### Tier1 (เพียวๆ)
- ✅ ใช้ Modal เลือกโครงการในปุ่ม "รับเคส" (เคสใหม่ที่ไม่มีโครงการ)
- ✅ รับเคสตามปกติ (เคสที่มีโครงการแล้ว)

### Tier1 + Staff
- ✅ ใช้ Modal เลือกโครงการในปุ่ม "แก้ไขและปิดเคส" (เมื่อใช้งานในฐานะ Staff)
- ✅ ใช้ Modal เลือกโครงการในปุ่ม "รับเคส" (เมื่อใช้งานในฐานะ Tier1)

### Tier1 + Admin
- ✅ ใช้ Modal เลือกโครงการในปุ่ม "รับเคส" (เคสใหม่ที่ไม่มีโครงการ)
- ✅ รับเคสตามปกติ (เคสที่มีโครงการแล้ว)

### Tier1 + Admin + Staff
- ✅ ใช้ Modal ทั้ง 2 แบบ (ขึ้นอยู่กับบริบทการใช้งาน)

### Tier2 / Tier3
- ❌ ไม่มี Modal เลือกโครงการ
- ✅ รับเคสตามปกติ (projectId ถูกกำหนดโดย Tier1 แล้ว)

### Admin (ไม่มี tier)
- ❌ ไม่มีปุ่ม "รับเคส" (Read-only mode)

---

## 🧪 การทดสอบ

### Test Case 1: Staff บันทึกและปิดเคส
```
Given: Staff เข้าหน้า "บันทึกเคสแทนลูกค้า"
When: กรอกข้อมูลและกดปุ่ม "แก้ไขและปิดเคส"
Then: แสดง Modal เลือกโครงการ
When: ไม่เลือกโครงการและกด "บันทึกและปิด"
Then: แสดง Alert "กรุณาเลือกโครงการ"
When: เลือกโครงการและกด "บันทึกและปิด"
Then: บันทึกเคสสำเร็จพร้อม projectId
```

### Test Case 2: Tier1 รับเคสใหม่ (ไม่มี projectId)
```
Given: Tier1 เข้าดูเคสที่ status='new' และ projectId=null
When: กดปุ่ม "รับเคส"
Then: แสดง Modal "แจ้งข้อมูลของเคสเพิ่มเติม"
When: ไม่เลือกโครงการและกด "รับเคสและเริ่มงาน"
Then: แสดง Toast "กรุณาเลือกโครงการ"
When: เลือกโครงการและกด "รับเคสและเริ่มงาน"
Then: 
  - รับเคสสำเร็จ
  - status: new → in_progress
  - บันทึก projectId, category, type, priority
  - แสดง Toast "รับเคสและระบุโครงการสำเร็จ"
```

### Test Case 3: Tier1 รับเคสที่มี projectId แล้ว
```
Given: Tier1 เข้าดูเคสที่ status='new' และ projectId='proj-001'
When: กดปุ่ม "รับเคส"
Then: รับเคสทันที (ไม่แสดง Modal)
```

### Test Case 4: Tier1 รับเคสที่ส่งกลับมา
```
Given: Tier1 เข้าดูเคสที่ status='tier1' และ projectId='proj-001'
When: กดปุ่ม "รับเคส"
Then: รับเคสทันที (ไม่แสดง Modal)
```

### Test Case 5: Tier1+Staff บันทึกเคสแทนลูกค้า
```
Given: User มี role tier1+staff
When: เข้าหน้า "บันทึกเคสแทนลูกค้า" และกดปุ่ม "แก้ไขและปิดเคส"
Then: แสดง Modal เลือกโครงการ (Staff)
When: เลือกโครงการและบันทึก
Then: บันทึกเคสสำเร็จพร้อม projectId
```

### Test Case 6: Tier2 รับเคส
```
Given: Tier2 เข้าดูเคสที่ status='tier2'
When: กดปุ่ม "รับเคส"
Then: รับเคสทันที (ไม่แสดง Modal)
Note: projectId ถูกกำหนดโดย Tier1 แล้ว
```

### Test Case 7: ค้นหาโครงการ
```
Given: เปิด Modal เลือกโครงการ
When: พิมพ์ "ERC" ในช่องค้นหา
Then: แสดงเฉพาะโครงการที่มี "ERC" ในชื่อย่อ, รหัส, หรือชื่อเต็ม
```

### Test Case 8: Pinned Projects
```
Given: เปิด Modal เลือกโครงการ (Tab "ทั้งหมด")
When: ดูรายการโครงการ
Then: โครงการที่ปักหมุดแสดงด้านบนพร้อมไอคอน ⭐
And: มีเส้นคั่นระหว่างโครงการปักหมุดและโครงการทั่วไป
```

### Test Case 9: Recent Projects
```
Given: เปิด Modal เลือกโครงการ
When: คลิก Tab "ใช้งานล่าสุด"
Then: แสดง 10 โครงการล่าสุดที่เคยเลือก
```

### Test Case 10: Pagination
```
Given: เปิด Modal เลือกโครงการ (Tab "ทั้งหมด")
And: มีโครงการมากกว่า 10 รายการ
Then: แสดงปุ่ม Pagination
When: กดปุ่ม "ถัดไป"
Then: แสดงโครงการหน้าถัดไป (11-20)
```

---

## 📊 ข้อมูลที่บันทึกในระบบ

### Ticket Schema (ส่วนที่เกี่ยวข้องกับโครงการ)
```typescript
interface Ticket {
  // ... ฟิลด์อื่นๆ
  
  // ✅ ข้อมูลโครงการ (บันทึกโดย Tier1 หรือ Staff)
  projectId?: string;           // ID ของโครงการ
  projectCode?: string;         // รหัสโครงการ (เช่น PRJ-2024-001)
  projectName?: string;         // ชื่อเต็มโครงการ
  projectShortName?: string;    // ชื่อย่อ (เช่น ERC, SMIT)
  
  // ✅ ข้อมูลเพิ่มเติม (บันทึกโดย Tier1)
  category?: string;            // หมวดหมู่
  type?: 'incident' | 'service_request'; // ประเภท
  priority?: 'low' | 'medium' | 'high' | 'critical'; // ความสำคัญ
}
```

### localStorage
```javascript
// ⭐ Pinned Projects
{
  key: 'pinnedProjects',
  value: ['proj-001', 'proj-005', 'proj-010']
}

// 🕐 Recent Projects (จำกัดไม่เกิน 10 รายการ)
{
  key: 'recentProjects',
  value: ['proj-010', 'proj-001', 'proj-003', ...]
}
```

---

## 🎨 UI/UX Considerations

### การค้นหา
- ✅ Real-time search (ไม่ต้องกดปุ่มค้นหา)
- ✅ ค้นหาได้หลายฟิลด์ (ชื่อย่อ, รหัส, ชื่อเต็ม)
- ✅ ปุ่มล้างการค้นหา (X) แสดงเมื่อมีข้อความ
- ✅ แสดงจำนวนผลลัพธ์ "💡 พบ X โครงการจาก "คำค้น""

### Tabs
- ✅ Active state ชัดเจน (สีน้ำเงิน + ขีดเส้นใต้)
- ✅ Icon ประกอบในแต่ละ Tab
- ✅ Reset pagination เมื่อสลับ Tab

### รายการโครงการ
- ✅ Hover effect (พื้นหลังเปลี่ยนสี)
- ✅ Selected state (พื้นหลังสีน้ำเงินอ่อน + ขีดเส้นซ้าย + Checkmark)
- ✅ Badge สีน้ำเงินสำหรับชื่อย่อ
- ✅ ไอคอน ⭐ สำหรับโครงการปักหมุด (ใน Tab "ทั้งหมด")
- ✅ เส้นคั่นระหว่างโครงการปักหมุดและโครงการทั่วไป

### Pagination
- ✅ Smart Pagination: 1 ... 5 6 7 ... 20
- ✅ ปุ่ม Disabled เมื่อถึงหน้าแรก/สุดท้าย
- ✅ แสดงเฉพาะใน Tab "ทั้งหมด"

### Modal
- ✅ Responsive: Max Width: 580px
- ✅ Scrollable: Max Height: 90vh
- ✅ ปิดได้ด้วย ESC หรือ Click Outside
- ✅ ปุ่ม "ยกเลิก" / "รับเคสและเริ่มงาน"
- ✅ ปุ่ม "รับเคสและเริ่มงาน" Disabled เมื่อไม่เลือกโครงการ

### Toast Notifications
- ✅ Success: "รับเคสและระบุโครงการสำเร็จ"
- ❌ Error: "กรุณาเลือกโครงการ"

---

## 🔧 Technical Implementation

### Files
- `/components/CreateTicketPage.tsx` - Modal สำหรับ Staff
- `/components/TicketActions.tsx` - Modal สำหรับ Tier1
- `/lib/mockData.ts` - ข้อมูล mockProjects

### Key Functions

#### CreateTicketPage.tsx
```typescript
// States
const [selectedProjectId, setSelectedProjectId] = useState('');
const [projectSearchQuery, setProjectSearchQuery] = useState('');
const [showProjectDropdown, setShowProjectDropdown] = useState(false);

// Filter projects
const filteredProjects = mockProjects.filter(project => {
  const query = projectSearchQuery.toLowerCase().trim();
  return (
    project.shortName.toLowerCase().includes(query) ||
    project.code.toLowerCase().includes(query) ||
    project.name.toLowerCase().includes(query)
  );
});

// Handle selection
const handleProjectSelect = (projectId: string) => {
  setSelectedProjectId(projectId);
  const project = mockProjects.find(p => p.id === projectId);
  if (project) {
    setProjectSearchQuery(`${project.shortName} - ${project.code}`);
  }
  setShowProjectDropdown(false);
};
```

#### TicketActions.tsx
```typescript
// Check if needs project selection
const needsProjectSelection = ticket.status === 'new' && !ticket.projectId;

// Check if has tier1 role
const hasTier1Role = currentUser?.roles?.includes('tier1') || false;

// Handle accept with project
const handleAcceptWithProject = () => {
  if (!selectedProjectId) {
    toast.error('กรุณาเลือกโครงการ');
    return;
  }

  const project = mockProjects.find(p => p.id === selectedProjectId);
  
  // บันทึก Recent Projects
  const recentProjects = JSON.parse(localStorage.getItem('recentProjects') || '[]');
  const updatedRecent = [
    selectedProjectId,
    ...recentProjects.filter((id: string) => id !== selectedProjectId)
  ].slice(0, 10);
  localStorage.setItem('recentProjects', JSON.stringify(updatedRecent));

  onUpdate({
    status: 'in_progress',
    assignedTo: userId,
    projectId: project.id,
    projectCode: project.code,
    projectName: project.name,
    projectShortName: project.shortName,
    category: selectedCategory,
    type: selectedType,
    priority: selectedPriority,
  });
};
```

---

## 🚀 Future Enhancements

### Phase 1 (ปัจจุบัน)
- ✅ Modal เลือกโครงการสำหรับ Staff
- ✅ Modal เลือกโครงการสำหรับ Tier1
- ✅ การค้นหาโครงการ
- ✅ Tabs (Pinned / All / Recent)
- ✅ Pagination
- ✅ localStorage สำหรับ Pinned และ Recent

### Phase 2 (อนาคต)
- 🔄 ปุ่มปักหมุด (Pin/Unpin) ในรายการโครงการ
- 🔄 Sorting (เรียงตาม ชื่อ / รหัส / แผนก)
- 🔄 Filter ตามแผนก (Department)
- 🔄 แสดงสถิติโครงการ (จำนวนเคสในแต่ละโครงการ)
- 🔄 Auto-suggest ตามประวัติการใช้งานของ User
- 🔄 Keyboard navigation (Arrow keys, Enter, ESC)

### Phase 3 (อนาคต)
- 🔄 แสดงข้อมูล Recent 10 Items จากระบบจริง (ไม่ใช่ localStorage)
- 🔄 Sync Pinned Projects กับ Backend
- 🔄 แสดงข้อมูลโครงการแบบ Real-time
- 🔄 Export ข้อมูลโครงการเป็น Excel/CSV

---

## 📝 Notes

- ✅ ทั้ง 2 Modal ใช้ `mockProjects` จาก `/lib/mockData.ts`
- ✅ localStorage ใช้สำหรับเก็บ Pinned และ Recent Projects (ชั่วคราว)
- ✅ ในระบบจริงควรเก็บข้อมูลนี้ใน Backend Database
- ✅ Validation ครบถ้วน: ต้องเลือกโครงการก่อนดำเนินการ
- ✅ UI ออกแบบให้ใช้งานง่าย รองรับ Mobile/Tablet/Desktop
- ✅ Toast notifications แสดงผลชัดเจน
- ⚠️ Multi-role (tier1+staff, tier1+admin) ต้องแก้ไข logic ให้รองรับ

---

## 📞 Contact

หากพบปัญหาหรือต้องการปรับปรุงฟีเจอร์ กรุณาติดต่อทีมพัฒนา:
- **Email:** dev@cdgs.co.th
- **Line:** @cdgs-support

---

**เอกสารนี้อัปเดตล่าสุด:** 24 มกราคม 2026  
**เวอร์ชัน:** 1.0.0  
**ผู้จัดทำ:** CDGS Development Team
