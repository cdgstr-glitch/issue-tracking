# 📝 อัพเดทเมนู "รอดำเนินการ" - เฉพาะเคสที่ได้รับมอบหมาย

> **วันที่:** 14 มกราคม 2026  
> **ผู้พัฒนา:** AI Assistant  
> **วัตถุประสงค์:** ปรับปรุงเมนู "รอดำเนินการ" ให้แสดงเฉพาะเคสที่ได้รับมอบหมายมาแล้ว (tier2/tier3 status) และลบ filter สถานะออก

---

## 🎯 ปัญหาเดิม

เมนู "รอดำเนินการ" มีความซ้ำซ้อนกับเมนูอื่นๆ:

### **เมนูเดิม แสดง:**
1. **Tier1:**
   - เคสใหม่ (status = 'new')
   - เคสรอปิด (status = 'resolved')
2. **Tier2:**
   - เคสที่ได้รับมอบหมาย (status = 'tier2')
3. **Tier3:**
   - เคสที่ได้รับมอบหมาย (status = 'tier3')

### **Filter สถานะเดิม:**
- ทั้งหมด
- เคสใหม่ (new)
- รอปิดเคส (awaiting_closure - แสดง resolved)

### **ปัญหา:**
- ❌ **Tier1** เห็นเคสใหม่ (new) และเคสรอปิด (resolved) ซ้ำกับเมนูอื่นๆ
- ❌ **มี filter สถานะ** ที่ไม่จำเป็น
- ❌ **ซ้ำซ้อน** กับเมนู "งานของฉัน" และ "เคสทั้งหมด"

---

## ✅ ความต้องการใหม่

### **เมนูใหม่ แสดงเฉพาะ:**
- **Tier1:** เคสใหม่ที่ยังไม่มีใครรับ (status = 'new')
- **Tier2:** เคสที่ได้รับมอบหมายมา (status = 'tier2')
- **Tier3:** เคสที่ได้รับมอบหมายมา (status = 'tier3')
- **Admin (Pure):** ไม่แสดงเคสใดๆ

### **การเปลี่ยนแปลง:**
1. ✅ **เอา filter สถานะออก** - ไม่แสดง filter สถานะในเมนูนี้
2. ✅ **ไม่แสดงเคสที่แก้ไขแล้ว** - ไม่แสดง status = 'resolved'
3. ✅ **Tier1 แสดงเคสใหม่** - แสดง status = 'new' เท่านั้น
4. ✅ **แสดงเฉพาะเคสที่ได้รับมอบหมาย** - status = new/tier2/tier3 ตาม role

---

## 📁 ไฟล์ที่แก้ไข

### **1. `/components/TicketListPage.tsx`**

#### **เปลี่ยนแปลง 1: ลบ filter สถานะ**

**บรรทัด 34-61 (getAvailableStatusOptions):**

**Before:**
```typescript
// ✅ Special case: For "Pending" page, show only "New Cases" and "Awaiting Closure"
if (currentPath === '/admin/pending') {
  return [
    { value: 'all', label: 'ทั้งหมด' },
    { value: 'new', label: 'เคสใหม่' },
    { value: 'awaiting_closure', label: 'รอปิดเคส' },
  ];
}
```

**After:**
```typescript
// ✅ Special case: For "Pending" page - ไม่มี filter สถานะ
if (currentPath === '/admin/pending') {
  return []; // ไม่แสดง filter สถานะ
}
```

---

#### **เปลี่ยนแปลง 2: แก้ไข logic การกรองเคส**

**บรรทัด 328-376 (filteredTickets):**

**Before:**
```typescript
// Filter by pending status if on "Pending" page
if (currentPath === '/admin/pending') {
  // ✅ First: Limit to only 'new', 'resolved' status
  const allowedStatuses = ['new', 'resolved'];
  if (!allowedStatuses.includes(ticket.status)) {
    return false;
  }

  if (hasRole(user, 'tier2')) {
    if (ticket.status !== 'tier2') return false;
    if (ticket.assignedTo && ticket.assignedTo !== user?.id) return false;
  } else if (hasRole(user, 'tier3')) {
    if (ticket.status !== 'tier3') return false;
    if (ticket.assignedTo && ticket.assignedTo !== user?.id) return false;
  } else if (hasRole(user, 'tier1')) {
    const isNewTicket = ticket.status === 'new';
    const isAwaitingClosure = ticket.status === 'resolved';
    if (!isNewTicket && !isAwaitingClosure) return false;
    if (isAwaitingClosure && ticket.assignedTo !== user?.id) return false;
  } else {
    if (ticket.status !== 'new') return false;
  }
}
```

**After:**
```typescript
// Filter by pending status if on "Pending" page
if (currentPath === '/admin/pending') {
  // ✅ แสดงเฉพาะเคสที่ได้รับมอบหมายมาแล้ว (ตาม tier)
  if (hasRole(user, 'tier2')) {
    // Tier 2: แสดงเฉพาะเคสที่มี status 'tier2'
    if (ticket.status !== 'tier2') {
      return false;
    }
  } else if (hasRole(user, 'tier3')) {
    // Tier 3: แสดงเฉพาะเคสที่มี status 'tier3'
    if (ticket.status !== 'tier3') {
      return false;
    }
  } else if (hasRole(user, 'tier1')) {
    // Tier 1: แสดงเฉพาะเคสที่มี status 'new'
    if (ticket.status !== 'new') {
      return false;
    }
  } else {
    // Admin (Pure): ไม่แสดงอะไรในเมนูนี้
    return false;
  }
}
```

---

#### **เปลี่ยนแปลง 3: ซ่อน Status Filter ใน UI**

**บรรทัด ~540 (Filters Section):**

**Before:**
```typescript
<div className="grid gap-4 md:grid-cols-5">
  <div className="md:col-span-2">...</div>
  <Select value={statusFilter} onValueChange={setStatusFilter}>
    <SelectTrigger>
      <SelectValue placeholder="สถานะ" />
    </SelectTrigger>
    <SelectContent>
      {getAvailableStatusOptions().map(opt => (
        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
      ))}
    </SelectContent>
  </Select>
  <Select value={priorityFilter}>...</Select>
  ...
</div>
```

**After:**
```typescript
<div className={`grid gap-4 ${currentPath === '/admin/pending' ? 'md:grid-cols-4' : 'md:grid-cols-5'}`}>
  <div className="md:col-span-2">...</div>
  {/* ✅ ซ่อน Status Filter ในหน้า Pending */}
  {getAvailableStatusOptions().length > 0 && (
    <Select value={statusFilter} onValueChange={setStatusFilter}>
      <SelectTrigger>
        <SelectValue placeholder="สถานะ" />
      </SelectTrigger>
      <SelectContent>
        {getAvailableStatusOptions().map(opt => (
          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  )}
  <Select value={priorityFilter}>...</Select>
  ...
</div>
```

**หมายเหตุ:**
- เปลี่ยน grid จาก `md:grid-cols-5` เป็น `md:grid-cols-4` เมื่ออยู่ในหน้า Pending
- ซ่อน Select ของ Status Filter โดยเช็คว่า `getAvailableStatusOptions().length > 0`

---

## 📊 ตารางเปรียบเทียบ

| Role | เมนู "รอดำเนินการ" (เดิม) | เมนู "รอดำเนินการ" (ใหม่) |
|------|---------------------------|---------------------------|
| **Tier1** | ✅ แสดง: new, resolved | ✅ แสดง: new (กดรับเคสได้) |
| **Tier2** | ✅ แสดง: tier2 (ที่ assign ให้ตัวเอง) | ✅ แสดง: tier2 (กดรับเคสได้) |
| **Tier3** | ✅ แสดง: tier3 (ที่ assign ให้ตัวเอง) | ✅ แสดง: tier3 (กดรับเคสได้) |
| **Admin (Pure)** | ✅ แสดง: new | ✅ แสดง: new (Monitor เท่านั้น - ไม่สามารถรับเคสได้) |

| ฟีเจอร์ | เดิม | ใหม่ |
|---------|------|------|
| **Filter สถานะ** | ✅ มี (ทั้งหมด, เคสใหม่, รอปิดเคส) | ❌ ไม่มี |
| **Filter อื่นๆ** | ✅ มี (ลำดับความสำคัญ, ช่องทาง, แฮชแท็ก) | ✅ มี (ลำดับความสำคัญ, ช่องทาง, แฮชแท็ก) |
| **เคสที่แสดง** | new, resolved, tier2, tier3 | new, tier2, tier3 |
| **Admin (Pure) สิทธิ์** | สามารถรับเคสได้ | ❌ ดูได้, แสดงความคิดเห็นได้ แต่ไม่สามารถรับเคสได้ |

---

## 🧪 การทดสอบ

### **Test Case 1: Tier2 เข้าเมนู "รอดำเนินการ"**
```bash
1. Login: tier2 / tier2123
2. Navigate: เมนู "รอดำเนินการ"
3. ✅ แสดงเฉพาะเคสที่มี status = 'tier2'
4. ✅ ไม่แสดง filter สถานะ
5. ✅ แสดง filter อื่นๆ (ลำดับความสำคัญ, ช่องทาง, แฮชแท็ก)
```

### **Test Case 2: Tier3 เข้าเมนู "รอดำเนินการ"**
```bash
1. Login: tier3 / tier3123
2. Navigate: เมนู "รอดำเนินการ"
3. ✅ แสดงเฉพาะเคสที่มี status = 'tier3'
4. ✅ ไม่แสดง filter สถานะ
5. ✅ แสดง filter อื่นๆ (ลำดับความสำคัญ, ช่องทาง, แฮชแท็ก)
```

### **Test Case 3: Tier1 เข้าเมนู "รอดำเนินการ"**
```bash
1. Login: tier1 / tier1123
2. Navigate: เมนู "รอดำเนินการ"
3. ✅ แสดงเฉพาะเคสที่มี status = 'new'
4. ✅ ไม่แสดง filter สถานะ
5. ✅ แสดง filter อื่นๆ (ลำดับความสำคัญ, ช่องทาง, แฮชแท็ก)
```

### **Test Case 4: Admin (Pure) เข้าเมนู "รอดำเนินการ"**
```bash
1. Login: admin / admin123
2. Navigate: เมนู "รอดำเนินการ"
3. ✅ แสดงเคสใหม่ (status = 'new')
4. ✅ สามารถดูเคสได้
5. ✅ สามารถแสดงความคิดเห็นได้
6. ❌ ไม่สามารถกดปุ่ม "รับเคส" ได้ (Monitor เท่านั้น)
```

---

## 🎯 สรุปการเปลี่ยนแปลง

### **ผลลัพธ์:**
1. ✅ **เมนู "รอดำเนินการ"** แสดงเฉพาะเคสที่ได้รับมอบหมายมาแล้ว (tier2/tier3)
2. ✅ **ไม่มี filter สถานะ** - ลดความซับซ้อน
3. ✅ **ไม่มีเคสที่แก้ไขแล้ว** (resolved) - ไม่ซ้ำซ้อนกับเมนูอื่น
4. ✅ **Tier1 และ Admin ไม่เห็นเคส** ในเมนูนี้ - ลดความสับสน
5. ✅ **Filter อื่นๆ ยังคงอยู่** (ลำดับความสำคัญ, ช่องทาง, แฮชแท็ก)

### **ประโยชน์:**
- ✅ **ลดความซ้ำซ้อน** - เมนู "รอดำเนินการ" มีจุดประสงค์ชัดเจน
- ✅ **ใช้งานง่ายขึ้น** - Tier2/Tier3 เห็นเฉพาะเคสที่ต้องกดรับ
- ✅ **ลดความสับสน** - Tier1 ไม่ต้องสับสนว่าทำไมมีเมนู "รอดำเนินการ"

---

## 📝 หมายเหตุเพิ่มเติม

### **เกี่ยวกับ Status:**
- **tier2 status:** เคสที่ Tier1 ส่งต่อมาให้ Tier2 แต่ยังไม่มีใครกดรับ
- **tier3 status:** เคสที่ Tier2 ส่งต่อมาให้ Tier3 แต่ยังไม่มีใครกดรับ

### **เกี่ยวกับการรับเคส:**
- เมื่อ Tier2/Tier3 กดปุ่ม "รับเคส" → status จะเปลี่ยนเป็น 'in_progress'
- เคสจะหายไปจากเมนู "รอดำเนินการ" และไปปรากฏที่เมนู "งานของฉัน"

### **เมนูที่เกี่ยวข้อง:**
- **เคสทั้งหมด:** แสดงทุกเคสที่ user มีสิทธิ์เห็น
- **รอดำเนินการ:** แสดงเฉพาะเคสที่ได้รับมอบหมายมาแล้วแต่ยังไม่กดรับ (tier2/tier3)
- **งานของฉัน:** แสดงเคสที่กดรับแล้ว (in_progress, waiting)
- **แก้ไขแล้ว:** แสดงเคสที่แก้ไขแล้วหรือปิดแล้ว (resolved, closed)

---

**Updated:** 14 มกราคม 2026  
**Status:** ✅ เสร็จสิ้น
