# Step 1: การแก้ไข CreateTicketPage.tsx

**วันที่:** 22 มกราคม 2025  
**Component:** `/components/CreateTicketPage.tsx`

---

## 🎯 เป้าหมาย

แก้ไขให้ใช้กฎใหม่: **Tier1 = มีทั้ง 'tier1' และ 'staff'**

---

## 📝 การเปลี่ยนแปลง

### **เพิ่ม: ตัวแปร Role Definitions (หลัง Line 51)**

```typescript
// เพิ่มหลังบรรทัดนี้:
const currentUser = customer || user;

// เพิ่มโค้ดนี้:
// ✅ กฎใหม่: Role Definitions (22 ม.ค. 2025)
// Tier1 ใหม่ = มีทั้ง 'tier1' และ 'staff' ใน roles array
const isTier1 = hasRole(currentUser, 'tier1') && hasRole(currentUser, 'staff');
const isPureStaff = hasRole(currentUser, 'staff') && !hasRole(currentUser, 'tier1');
const isCustomer = hasRole(currentUser, 'customer');
```

---

## ✅ จุดที่ไม่ต้องแก้ (ถูกต้องอยู่แล้ว)

### **1. Line 56 - Incident Date (ถูกต้องแล้ว)**
```typescript
// ✅ ใช้ hasRole(currentUser, 'staff') - ครอบคลุมทั้ง Tier1 และ Pure Staff
if (hasRole(currentUser, 'staff')) {
  // Set default incident date
}
```
**เหตุผล:** Tier1 และ Pure Staff ต้องมี staff อยู่แล้ว

---

### **2. Line 72 - Validate Project (ถูกต้องแล้ว)**
```typescript
// ✅ ใช้ hasRole(currentUser, 'staff') - ครอบคลุมทั้ง Tier1 และ Pure Staff
if (hasRole(currentUser, 'staff') && !selectedProjectId) {
  alert('กรุณาเลือกโครงการก่อนบันทึกเคส');
}
```
**เหตุผล:** ทั้ง Tier1 และ Pure Staff ต้องเลือกโครงการ

---

### **3. Line 373, 378, 388, 392 - UI Display (ถูกต้องแล้ว)**
```typescript
// ✅ ใช้ hasRole(currentUser, 'staff') เพื่อแสดง UI สำหรับ Staff
{hasRole(currentUser, 'staff')
  ? `แจ้งเคสใหม่โดยเจ้าหน้าที่ชื่อ ${currentUser?.fullName || 'เจ้าหน้าที่'}`
  : 'แจ้งเคสใหม่'
}
```
**เหตุผล:** แสดงฟอร์ม Staff สำหรับทั้ง Tier1 และ Pure Staff

---

### **4. Line 699 - ปุ่ม Pure Staff (ถูกต้องแล้ว)**
```typescript
// ✅ Pure Staff = มี staff แต่ไม่มี tier1
{hasRole(currentUser, 'staff') && !hasRole(currentUser, 'tier1') && (
  <Button type="submit" size="lg">
    ส่งงาน
  </Button>
)}
```
**เหตุผล:** ตรงตามกฎใหม่แล้ว

---

### **5. Line 706 - ปุ่ม Tier1 (ถูกต้องแล้ว)**
```typescript
// ✅ Tier1 = มีทั้ง staff และ tier1
{hasRole(currentUser, 'staff') && hasRole(currentUser, 'tier1') && (
  <>
    <Button onClick={handleSolveAndClose}>✅ แก้ไขและปิดเคส</Button>
    <Button type="submit">ส่งงาน</Button>
    <Button onClick={handleSaveAndAccept}>📥 บันทึกและรับเคส</Button>
  </>
)}
```
**เหตุผล:** ตรงตามกฎใหม่แล้ว

---

## 🔄 จุดที่ควรปรับปรุง (Optional - เพื่อความชัดเจน)

### **แทนที่การเช็คซ้ำๆ ด้วยตัวแปร**

**Before:**
```typescript
{hasRole(currentUser, 'staff') && !hasRole(currentUser, 'tier1') && (
  <Button>ส่งงาน</Button>
)}

{hasRole(currentUser, 'staff') && hasRole(currentUser, 'tier1') && (
  <Button>บันทึกและรับเคส</Button>
)}
```

**After:**
```typescript
{isPureStaff && (
  <Button>ส่งงาน</Button>
)}

{isTier1 && (
  <Button>บันทึกและรับเคส</Button>
)}
```

**ข้อดี:**
- อ่านง่ายขึ้น
- ไม่ต้องเช็คซ้ำๆ
- แก้ไขที่เดียว ใช้ได้ทุกที่

---

## 📊 สรุป

| จุด | สถานะ | หมายเหตุ |
|-----|-------|----------|
| Line 56 - Incident Date | ✅ ถูกต้องแล้ว | ไม่ต้องแก้ |
| Line 72 - Validate Project | ✅ ถูกต้องแล้ว | ไม่ต้องแก้ |
| Line 373-392 - UI Display | ✅ ถูกต้องแล้ว | ไม่ต้องแก้ |
| Line 699 - Pure Staff Button | ✅ ถูกต้องแล้ว | ไม่ต้องแก้ |
| Line 706 - Tier1 Buttons | ✅ ถูกต้องแล้ว | ไม่ต้องแก้ |
| **เพิ่มตัวแปร** | ⚠️ Optional | เพื่อความชัดเจน |

---

## ✅ ข้อสรุป

**CreateTicketPage.tsx โค้ดปัจจุบันถูกต้องตามกฎใหม่แล้ว!** 🎉

ไม่จำเป็นต้องแก้ไขอะไรเลย เพราะ:
- ใช้ `hasRole(currentUser, 'staff')` สำหรับ features ที่ต้องการ staff
- ใช้ `hasRole(currentUser, 'staff') && hasRole(currentUser, 'tier1')` สำหรับ Tier1
- ใช้ `hasRole(currentUser, 'staff') && !hasRole(currentUser, 'tier1')` สำหรับ Pure Staff

---

## 🎯 ตัวเลือกถัดไป

**Option 1: ไม่ต้องแก้ (แนะนำ)**
- โค้ดถูกต้องแล้ว ไม่ต้องทำอะไร

**Option 2: เพิ่มตัวแปรเพื่อความชัดเจน (Optional)**
- เพิ่ม `isTier1`, `isPureStaff`, `isCustomer`
- แทนที่การเช็คซ้ำๆ ด้วยตัวแปร

คุณต้องการให้ผมทำ Option ไหนครับ?
