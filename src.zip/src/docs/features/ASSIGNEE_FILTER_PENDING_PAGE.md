# 📊 Assignee Filter - หน้ารอดำเนินการ (Pending Page)

**วันที่สร้าง:** 17 มกราคม 2026  
**หน้า:** `/admin/pending` (รอดำเนินการ)  
**เมนู:** Tier2, Tier3  
**ปัญหาที่แก้:** Assignee Filter ถูกข้ามโดย Visibility Logic

---

## 📋 **สารบัญ**

1. [ภาพรวมฟีเจอร์](#ภาพรวมฟีเจอร์)
2. [ปัญหาที่พบและวิธีแก้](#ปัญหาที่พบ)
3. [Logic Flow ที่ถูกต้อง](#logic-flow)
4. [Test Cases](#test-cases)
5. [Code Implementation](#code-implementation)

---

<a name="ภาพรวมฟีเจอร์"></a>
## 🎯 **ภาพรวมฟีเจอร์**

### **Assignee Filter (ตัวกรองผู้รับผิดชอบ)**

**ตำแหน่ง:** หน้า `/admin/pending` (รอดำเนินการ)  
**Component:** `<TicketListPage currentPath="/admin/pending" />`  
**ไฟล์:** `/components/TicketListPage.tsx`

**วัตถุประสงค์:**
- กรองเคสตามผู้รับผิดชอบ (assignedTo)
- แยกเคสที่ **ยังไม่มีคนรับ** vs **มีผู้รับแล้ว**
- สนับสนุน Takeover workflow (เจ้าหน้าที่รับเคสที่ไม่ได้ assign ให้ตัวเอง)

---

### **Filter Options:**

| Option | Value | เงื่อนไข | ใช้งานเมื่อ |
|--------|-------|---------|-----------|
| **ทุกคน** | `all` | ไม่กรอง | ดูเคสทั้งหมด |
| **ยังไม่ได้รับผิดชอบ** | `unassigned` | `assignedTo === undefined` | หาเคสที่ยังไม่มีคนรับ (Takeover) |
| **มีผู้รับผิดชอบแล้ว** | `assigned` | `assignedTo !== undefined` | ดูเคสที่มีคนรับแล้ว |
| **ฉัน** | `me` | `assignedTo === user.id` | ดูเคสของตัวเอง |

---

<a name="ปัญหาที่พบ"></a>
## 🐛 **ปัญหาที่พบและวิธีแก้**

### **ปัญหา: Visibility Logic ข้าม Assignee Filter**

**วันที่พบ:** 17 มกราคม 2026  
**ผู้รายงาน:** ผู้ใช้ Login เป็น "ประวิช" (Tier2)

---

### **Scenario:**

```
ผู้ใช้: ประวิช จินทนากร (Tier2, user-008)
หน้า: /admin/pending
Filter: ผู้รับผิดชอบ = "ยังไม่ได้รับผิดชอบ"

เคสทดสอบ: CDGS-2024-ESC005
- status: 'tier2'
- assignedTo: 'user-006' (ยุทธนา คณามิ่งมงคล)

❌ ผลลัพธ์ที่ผิด: แสดงเคส (ไม่ควรแสดง)
✅ ผลลัพธ์ที่ถูก: ซ่อนเคส (เพราะ assignedTo !== undefined)
```

---

### **Root Cause (สาเหตุหลัก):**

**ไฟล์:** `/components/TicketListPage.tsx` (บรรทัด 354-357)

```typescript
// ❌ Logic เดิม (ผิด)
// ✅ สำหรับ tier2 status: แสดงทุกเคส (เพื่อให้ takeover ได้)
if (ticket.status === 'tier2') {
  return true; // ❌ ปัญหาตรงนี้! RETURN ทันทีโดยไม่ผ่าน Assignee Filter
}

// ✅ สำหรับ status อื่น: ต้อง assigned ให้ Tier2 users
const isAssignedToMe = ticket.assignedTo === user?.id;
const isAssignedToOtherTier2 = ticket.assignedTo && tier2UserIds.includes(ticket.assignedTo);

if (!isAssignedToMe && !isAssignedToOtherTier2) {
  return false;
}

// ... ข้างล่างนี้ Assignee Filter (บรรทัด 441-459)
// แต่ไม่ทำงานเพราะ return true ไปก่อนแล้ว!
if (assigneeFilter !== 'all') {
  if (assigneeFilter === 'unassigned' && ticket.assignedTo) {
    return false; // ❌ ไม่เคยถึงบรรทัดนี้!
  }
}
```

**อธิบาย:**
1. เคส `CDGS-2024-ESC005` มี `status='tier2'`
2. เข้า condition `if (ticket.status === 'tier2')`
3. **Return true ทันที** → ข้ามไปทุก Filter ที่เหลือ
4. Assignee Filter (บรรทัด 441-459) **ไม่ทำงาน**
5. ผลลัพธ์: แสดงเคสแม้ว่า `assignedTo !== undefined`

---

### **วิธีแก้ไข:**

**ลบ `return true` ออก → ให้เช็คต่อไปจนถึง Assignee Filter**

```typescript
// ✅ Logic ใหม่ (ถูกต้อง)
// ✅ สำหรับ tier2 status: แสดงทุกเคส (เพื่อให้ takeover ได้)
// ❌ ห้าม return true ทันที - ต้องให้ผ่าน Assignee Filter ด้วย
if (ticket.status !== 'tier2') {
  // ✅ สำหรับ status อื่น: ต้อง assigned ให้ Tier2 users (ตัวเองหรือคนอื่น)
  const isAssignedToMe = ticket.assignedTo === user?.id;
  const isAssignedToOtherTier2 = ticket.assignedTo && tier2UserIds.includes(ticket.assignedTo);
  
  if (!isAssignedToMe && !isAssignedToOtherTier2) {
    return false;
  }
}

// ✅ ตอนนี้จะไปเช็ค Assignee Filter ต่อได้แล้ว (บรรทัด 441-459)
if (currentPath === '/admin/pending') {
  // ... status check ...
  
  // ✅ Assignee Filter ทำงานได้แล้ว!
  if (assigneeFilter !== 'all') {
    if (assigneeFilter === 'unassigned' && ticket.assignedTo) {
      return false; // ✅ ทำงานได้แล้ว!
    }
    if (assigneeFilter === 'assigned' && !ticket.assignedTo) {
      return false;
    }
    if (assigneeFilter === 'me' && ticket.assignedTo !== user?.id) {
      return false;
    }
  }
}
```

---

<a name="logic-flow"></a>
## 🔄 **Logic Flow ที่ถูกต้อง**

### **Filter Pipeline (ลำดับการกรอง)**

```
📥 Input: All Tickets
    │
    ▼
┌─────────────────────────────────────────────┐
│ 1. Visibility Filter (Tier-based)          │
│    - Tier2: บล็อก 'new', 'tier1'           │
│    - Tier3: บล็อก 'new', 'tier1', 'tier2'  │
└─────────────────┬───────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────┐
│ 2. Assignment Check (ถ้าไม่ใช่ tier2/tier3)│
│    - tier2 status: ผ่านไปเลย               │
│    - status อื่น: ต้อง assigned ให้ Tier   │
└─────────────────┬───────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────┐
│ 3. Menu-Specific Filter (Pending)          │
│    - Tier2: status === 'tier2'              │
│    - Tier3: status === 'tier3'              │
└─────────────────┬───────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────┐
│ 4. Assignee Filter (Dropdown) ⭐ ตรงนี้!   │
│    - ทุกคน (all)                            │
│    - ยังไม่ได้รับผิดชอบ (unassigned)        │
│    - มีผู้รับผิดชอบแล้ว (assigned)          │
│    - ฉัน (me)                               │
└─────────────────┬───────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────┐
│ 5. Other Filters                           │
│    - Search, Status, Priority, Channel, ... │
└─────────────────┬───────────────────────────┘
                  │
                  ▼
              📤 Output
```

**Key Points:**
- ✅ **ห้าม `return true` ก่อนขั้นตอน 4** (Assignee Filter)
- ✅ ถ้า `status === 'tier2'` ให้ **ข้ามขั้นตอน 2** แต่**ไม่ข้ามขั้นตอน 3-5**
- ✅ ทุก Filter ต้องทำงานตามลำดับ

---

<a name="test-cases"></a>
## 🧪 **Test Cases**

### **Test Case 1: Filter "ทุกคน" (all)**

**Setup:**
```typescript
currentPath = '/admin/pending'
assigneeFilter = 'all'
user = ประวิช (user-008, Tier2)
```

**Tickets:**
```typescript
[
  { id: 'T1', status: 'tier2', assignedTo: undefined },      // ยังไม่มีคนรับ
  { id: 'T2', status: 'tier2', assignedTo: 'user-006' },    // ยุทธนารับแล้ว
  { id: 'T3', status: 'tier2', assignedTo: 'user-008' },    // ประวิชรับแล้ว
]
```

**Expected Result:**
```typescript
✅ แสดงทั้ง 3 เคส (T1, T2, T3)
```

**Actual Result (หลังแก้):**
```typescript
✅ แสดงทั้ง 3 เคส ✓
```

---

### **Test Case 2: Filter "ยังไม่ได้รับผิดชอบ" (unassigned)**

**Setup:**
```typescript
currentPath = '/admin/pending'
assigneeFilter = 'unassigned'
user = ประวิช (user-008, Tier2)
```

**Tickets:**
```typescript
[
  { id: 'T1', status: 'tier2', assignedTo: undefined },      // ยังไม่มีคนรับ
  { id: 'T2', status: 'tier2', assignedTo: 'user-006' },    // ยุทธนารับแล้ว
  { id: 'T3', status: 'tier2', assignedTo: 'user-008' },    // ประวิชรับแล้ว
]
```

**Expected Result:**
```typescript
✅ แสดงแค่ T1 (assignedTo === undefined)
❌ ไม่แสดง T2, T3
```

**Actual Result (ก่อนแก้):**
```typescript
❌ แสดงทั้ง 3 เคส (T1, T2, T3) ← ผิด! เพราะ return true ที่บรรทัด 356
```

**Actual Result (หลังแก้):**
```typescript
✅ แสดงแค่ T1 ✓
```

---

### **Test Case 3: Filter "มีผู้รับผิดชอบแล้ว" (assigned)**

**Setup:**
```typescript
currentPath = '/admin/pending'
assigneeFilter = 'assigned'
user = ประวิช (user-008, Tier2)
```

**Tickets:**
```typescript
[
  { id: 'T1', status: 'tier2', assignedTo: undefined },      // ยังไม่มีคนรับ
  { id: 'T2', status: 'tier2', assignedTo: 'user-006' },    // ยุทธนารับแล้ว
  { id: 'T3', status: 'tier2', assignedTo: 'user-008' },    // ประวิชรับแล้ว
]
```

**Expected Result:**
```typescript
✅ แสดง T2, T3 (assignedTo !== undefined)
❌ ไม่แสดง T1
```

**Actual Result (หลังแก้):**
```typescript
✅ แสดง T2, T3 ✓
```

---

### **Test Case 4: Filter "ฉัน" (me)**

**Setup:**
```typescript
currentPath = '/admin/pending'
assigneeFilter = 'me'
user = ประวิช (user-008, Tier2)
```

**Tickets:**
```typescript
[
  { id: 'T1', status: 'tier2', assignedTo: undefined },      // ยังไม่มีคนรับ
  { id: 'T2', status: 'tier2', assignedTo: 'user-006' },    // ยุทธนารับแล้ว
  { id: 'T3', status: 'tier2', assignedTo: 'user-008' },    // ประวิชรับแล้ว
]
```

**Expected Result:**
```typescript
✅ แสดงแค่ T3 (assignedTo === user.id)
❌ ไม่แสดง T1, T2
```

**Actual Result (หลังแก้):**
```typescript
✅ แสดงแค่ T3 ✓
```

---

### **Test Case 5: เคสจริง CDGS-2024-ESC005**

**Setup:**
```typescript
currentPath = '/admin/pending'
assigneeFilter = 'unassigned'
user = ประวิช (user-008, Tier2)
```

**Ticket:**
```typescript
{
  id: 'esc-005',
  ticketNumber: 'CDGS-2024-ESC005',
  title: 'Application Server Down - 500 Internal Server Error',
  status: 'tier2',
  assignedTo: 'user-006', // ยุทธนา คณามิ่งมงคล
  assignedBy: 'user-005', // ธัญญาพร ทองแก้ว
}
```

**Expected Result:**
```typescript
❌ ไม่แสดง (เพราะ assignedTo = 'user-006' !== undefined)
```

**Actual Result (ก่อนแก้):**
```typescript
❌ แสดง ← ผิด!
```

**Actual Result (หลังแก้):**
```typescript
✅ ไม่แสดง ✓
```

---

<a name="code-implementation"></a>
## 💻 **Code Implementation**

### **ไฟล์:** `/components/TicketListPage.tsx`

**บรรทัด:** 334-459 (Visibility Filter + Menu Filter + Assignee Filter)

---

### **1. Visibility Filter (Tier2)**

```typescript
// Role-based filtering for Tier 2
if (hasRole(user, 'tier2')) {
  // ❌ บล็อก status ที่ Tier2 ไม่ควรเห็น (Inverted Visibility Model)
  const blockedStatuses = ['new', 'tier1'];
  
  if (blockedStatuses.includes(ticket.status)) {
    console.log('❌ Tier2 - Blocked status:', ticket.ticketNumber, 'status:', ticket.status);
    return false;
  }
  
  // ✅ Tier 2 should see:
  // 1. ALL tickets with status 'tier2' (รอรับเคส - for takeover capability)
  // 2. Tickets with status 'tier3', 'in_progress', 'waiting', etc. ที่ assigned ให้ Tier2 users
  const allowedStatuses = ['tier2', 'tier3', 'in_progress', 'waiting', 'resolved', 'closed'];
  
  if (!allowedStatuses.includes(ticket.status)) {
    console.log('❌ Tier2 - Status not allowed:', ticket.ticketNumber, 'status:', ticket.status);
    return false;
  }
  
  // ✅ สำหรับ tier2 status: แสดงทุกเคส (เพื่อให้ takeover ได้)
  // ❌ ห้าม return true ทันที - ต้องให้ผ่าน Assignee Filter ด้วย
  if (ticket.status !== 'tier2') {
    // ✅ สำหรับ status อื่น: ต้อง assigned ให้ Tier2 users (ตัวเองหรือคนอื่น)
    const isAssignedToMe = ticket.assignedTo === user?.id;
    const isAssignedToOtherTier2 = ticket.assignedTo && tier2UserIds.includes(ticket.assignedTo);
    
    if (!isAssignedToMe && !isAssignedToOtherTier2) {
      console.log('❌ Tier2 filter - Excluding:', ticket.ticketNumber, 'status:', ticket.status, 'assignedTo:', ticket.assignedTo, 'userId:', user?.id);
      return false;
    }
  }
  
  console.log('✅ Tier2 filter - Including:', ticket.ticketNumber);
}
```

---

### **2. Menu Filter (Pending)**

```typescript
// Filter by pending status if on "Pending" page
if (currentPath === '/admin/pending') {
  // ✅ แสดงเฉพาะเคสที่ได้รับมอบหมายมาแล้ว (ตาม tier)
  if (hasRole(user, 'tier2')) {
    // Tier 2: แสดงเฉพาะเคสที่มี status 'tier2'
    if (ticket.status !== 'tier2') {
      return false;
    }
  } else if (hasRole(user, 'tier3')) {
    // Tier 3: แสดงเฉพาะเคสที่มี status 'tier3'
    if (ticket.status !== 'tier3') {
      return false;
    }
  } else if (hasRole(user, 'tier1')) {
    // Tier 1: แสดงเฉพาะเคสใหม่ (status = 'new')
    if (ticket.status !== 'new') {
      return false;
    }
  } else {
    // Admin (Pure): แสดงเคสใหม่ (status = 'new') - Monitor เท่านั้น ไม่สามารถรับเคสได้
    if (ticket.status !== 'new') {
      return false;
    }
  }
  
  // ... ดูขั้นตอนที่ 3 (Assignee Filter)
}
```

---

### **3. Assignee Filter (Dropdown) ⭐**

```typescript
// ✅ Assignee filter for Pending page - ใส่หลัง status check
if (assigneeFilter !== 'all') {
  console.log('🔍 Assignee Filter Active (Pending):', assigneeFilter, 'Ticket:', ticket.ticketNumber, 'assignedTo:', ticket.assignedTo, 'userId:', user?.id);
  
  // ✅ "ยังไม่ได้รับผิดชอบ" - แสดงเฉพาะเคสที่ assignedTo === undefined
  if (assigneeFilter === 'unassigned' && ticket.assignedTo) {
    console.log('❌ Hiding assigned ticket:', ticket.ticketNumber);
    return false;
  }
  
  // ✅ "มีผู้รับผิดชอบแล้ว" - แสดงเฉพาะเคสที่ assignedTo !== undefined
  if (assigneeFilter === 'assigned' && !ticket.assignedTo) {
    console.log('❌ Hiding unassigned ticket:', ticket.ticketNumber);
    return false;
  }
  
  // ✅ "ฉัน" - แสดงเฉพาะเคสที่ assignedTo === user.id
  if (assigneeFilter === 'me' && ticket.assignedTo !== user?.id) {
    console.log('❌ Hiding ticket not assigned to me:', ticket.ticketNumber);
    return false;
  }
  
  console.log('✅ Assignee filter passed (Pending):', ticket.ticketNumber);
}
```

---

### **4. UI Component (Dropdown)**

```typescript
{/* Assignee Filter - ✅ แสดงเฉพาะในหน้า Pending */}
{currentPath === '/admin/pending' && (
  <div>
    <Label>ผู้รับผิดชอบ</Label>
    <Select
      value={assigneeFilter}
      onValueChange={(value) => {
        setAssigneeFilter(value);
        resetPagination(); // ✅ กลับไป Page 1 เมื่อเปลี่ยน Filter
      }}
    >
      <SelectTrigger>
        <SelectValue placeholder="ผู้รับผิดชอบ" /> {/* ✅ เพิ่ม placeholder */}
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">ทุกคน</SelectItem>
        <SelectItem value="unassigned">ยังไม่ได้รับผิดชอบ</SelectItem>
        <SelectItem value="assigned">มีผู้รับผิดชอบแล้ว</SelectItem>
        <SelectItem value="me">ฉัน</SelectItem>
      </SelectContent>
    </Select>
  </div>
)}
```

---

## 📊 **ตารางสรุป Assignee Filter**

| Filter Option | Value | Condition | Tier2 Example | Tier3 Example |
|--------------|-------|-----------|--------------|--------------|
| **ทุกคน** | `all` | ไม่กรอง | ดูเคส tier2 ทั้งหมด | ดูเคส tier3 ทั้งหมด |
| **ยังไม่ได้รับผิดชอบ** | `unassigned` | `assignedTo === undefined` | เคส tier2 ที่ยังไม่มีคนรับ | เคส tier3 ที่ยังไม่มีคนรับ |
| **มีผู้รับผิดชอบแล้ว** | `assigned` | `assignedTo !== undefined` | เคส tier2 ที่มีคนรับแล้ว | เคส tier3 ที่มีคนรับแล้ว |
| **ฉัน** | `me` | `assignedTo === user.id` | เคส tier2 ที่ประวิชรับ | เคส tier3 ที่ผู้ใช้รับ |

---

## 🎯 **Best Practices**

### ✅ **DO:**

1. **ใช้ Placeholder:**
   ```typescript
   <SelectValue placeholder="ผู้รับผิดชอบ" />
   ```

2. **Reset Pagination:**
   ```typescript
   onValueChange={(value) => {
     setAssigneeFilter(value);
     resetPagination(); // ← สำคัญ!
   }}
   ```

3. **Log Debug:**
   ```typescript
   console.log('🔍 Assignee Filter Active:', assigneeFilter, 'Ticket:', ticket.ticketNumber);
   ```

4. **ไม่ `return true` ก่อน Assignee Filter:**
   ```typescript
   // ❌ ห้ามทำ:
   if (ticket.status === 'tier2') {
     return true; // ← ห้าม!
   }
   
   // ✅ ทำแบบนี้:
   if (ticket.status !== 'tier2') {
     // เช็ค assignment
   }
   // ให้ผ่านไปเช็ค Assignee Filter ต่อ
   ```

---

### ❌ **DON'T:**

1. **ไม่ Reset Pagination:**
   ```typescript
   // ❌ ผู้ใช้เปลี่ยน Filter แต่ยังอยู่ Page 5 (ไม่มีเคส)
   onValueChange={(value) => setAssigneeFilter(value)}
   ```

2. **ไม่มี Placeholder:**
   ```typescript
   <SelectValue /> {/* ❌ แสดง default value แทน placeholder */}
   ```

3. **Return true ก่อน Assignee Filter:**
   ```typescript
   if (ticket.status === 'tier2') {
     return true; // ❌ ข้าม Assignee Filter!
   }
   ```

---

## 📝 **Changelog**

### **v1.0 (17 มกราคม 2026)**
- ✅ เพิ่ม Assignee Filter สำหรับหน้า Pending
- ✅ เพิ่ม placeholder "ผู้รับผิดชอบ"
- ✅ เพิ่ม resetPagination() ให้ทุก Filter
- ✅ แก้ไข Visibility Logic (ลบ `return true` ทันที)

---

## 🔗 **เอกสารที่เกี่ยวข้อง**

- [FILTER_ISSUE_REPORT.md](../FILTER_ISSUE_REPORT.md) - รายงานปัญหา Filter และ Visibility
- [ASSIGNEE_FILTER_FEATURE.md](./ASSIGNEE_FILTER_FEATURE.md) - ฟีเจอร์ Assignee Filter ทั่วไป
- [PENDING_MENU_UPDATE.md](../PENDING_MENU_UPDATE.md) - การอัพเดทเมนูรอดำเนินการ

---

**ผู้สร้าง:** AI Assistant  
**วันที่:** 17 มกราคม 2026  
**เวอร์ชัน:** 1.0  
**Status:** ✅ แก้ไขเรียบร้อยแล้ว
