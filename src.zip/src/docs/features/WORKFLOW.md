# 🔄 Workflow - Flow การทำงาน

## 📋 สารบัญ
1. [Staff Workflow](#1-staff-workflow)
2. [Customer Workflow](#2-customer-workflow)
3. [Tier Workflow](#3-tier-workflow)
4. [Escalation Flow](#4-escalation-flow)
5. [Status Lifecycle](#5-status-lifecycle)
6. [ตัวอย่าง Flow จริง](#6-ตัวอย่าง-flow-จริง)

---

## 1. Staff Workflow

### กรณีที่ 1: Staff ส่งต่อ Tier1 (Flow มาตรฐาน)

```
📧 ลูกค้าติดต่อมา (โทรศัพท์/อีเมล/Line)
  ↓
Staff A login → Landing Page
  ↓
กด "➕ บันทึกเคสแทนลูกค้า"
  ↓
กรอก Form:
  - หัวเรื่อง: "..."
  - รายละเอียด: "..."
  - ข้อมูลลูกค้า (ชื่อ, อีเมล/เบอร์โทร)
  - Channel: เลือกช่องทางที่ติดต่อมา
  - Priority: ระบุความสำคัญ
  - Incident Date: ระบุวันที่เกิดเหตุ (กรณีบันทึกย้อนหลัง)
  - โครงการ: เลือกโครงการ (Required)
  ↓
กด "📤 ส่งงาน" (บันทึกและส่งต่อ)
  ↓
ระบบสร้างเคส CDGS-101:
  - status = 'new'
  - createdBy = Staff A
  - assignedTo = null (เข้า Pool ส่วนกลาง)
  - needsTriage = true (รอ Tier 1 คัดกรองและรับงาน)
  ↓
เคส CDGS-101 ปรากฏใน:
  ✅ "รอดำเนินการ" (Tier1 เห็น - พร้อมปุ่ม "รับเคส")
  ✅ "ติดตามเคส" (Staff A เห็น - status = new, Read-only)
  ↓
Tier1 B เข้ามาดูเมนู "รอดำเนินการ"
  ↓
Tier1 B กด "รับเคส" ที่ CDGS-101
  ↓
ระบบอัปเดตเคส CDGS-101:
  - status = 'in_progress'
  - assignedTo = Tier1 B
  ↓
Tier1 B แก้ไขปัญหาเสร็จ → กด "ปิดเคส"
  ↓
ระบบอัปเดตเคส CDGS-101:
  - status = 'closed'
  - closedBy = Tier1 B
  ↓
เคส CDGS-101 ปรากฏใน:
  ✅ "ดูเคสที่ปิดแล้ว" (Staff A - Read-only)
  ✅ "แก้ไขแล้ว" (Tier1 B)
  ↓
✅ เสร็จสิ้น
```

---

### หมายเหตุสำคัญ (กฎเหล็ก):
1. **Staff ปิดเคสเองไม่ได้:** Staff ทำหน้าที่เป็น Middleman รับเรื่องและบันทึกเท่านั้น การปิดเคสต้องทำโดย Tier 1 เสมอ
2. **การบันทึกย้อนหลัง:** Staff สามารถระบุ `Incident Date` ย้อนหลังได้ แต่ขั้นตอนในระบบยังเหมือนเดิมคือ "บันทึก -> ส่งต่อ -> Tier 1 รับและปิด" (แม้จะทำต่อเนื่องกันทันทีก็ตาม)

---

## 2. Customer Workflow

### กรณีที่ 1: Customer ลงทะเบียนและแจ้งเคสครั้งแรก (อัพเดต 21 ม.ค. 2026)

```
💻 Customer เข้า Landing Page
  ↓
กด "ลงทะเบียนและแจ้งเคส"
  ↓
Quick Registration Dialog เปิดขึ้น:
  - ชื่อ-นามสกุล: "ศิริพร อารีมิตร"
  - อีเมล: "siriporn@example.com"
  ↓
กด "ดำเนินการต่อ"
  ↓
ระบบสร้าง Customer Account:
  - role = 'customer'
  - fullName = "ศิริพร อารีมิตร"
  - email = "siriporn@example.com"
  - Auto-login (ไม่ต้องรหัสผ่าน)
  ↓
Redirect → หน้าแจ้งเคส (CreateTicketPage)
  ↓
กรอก Form:
  - หัวเรื่อง: "ไม่สามารถดาวน์โหลดไฟล์ได้"
  - รายละเอียด: "..."
  - หมวดหมู่: "ระบบขัดข้อง" (Required)
  - ผลิตภัณฑ์: "Asset Management" (Optional)
  - แนบไฟล์ (Optional)
  
  ── ข้อมูลเพิ่มเติม (ไม่บังคับ) ──
  - เบอร์โทรศัพท์: "081-xxx-xxxx"
  - หน่วยงาน: "ฝ่ายบัญชี"
  ↓
กด "แจ้งเคส"
  ↓
ระบบสร้างเคส CDGS-103:
  - status = 'new'
  - createdBy = Customer (siriporn)
  - createdByType = 'customer_self'
  - channel = 'web'
  - assignedTo = null
  - projectId = null ⚠️ (ยังไม่มี - Tier1 จะเติมทีหลัง)
  - type = null ⚠️ (ยังไม่มี - Tier1 จะเติมทีหลัง)
  - priority = null ⚠️ (ยังไม่มี - Tier1 จะเติมทีหลัง)
  - needsTriage = true
  ↓
ส่งอีเมลแจ้ง Customer:
  - "เคส #CDGS-103 ถูกสร้างแล้ว"
  - "เราได้ส่งรายละเอียดไปที่ siriporn@example.com"
  - มี Magic Link เข้าหน้าติดตามเคส
  ↓
แสดง Success Page:
  - ✅ แจ้งเคสสำเร็จ
  - เคส #CDGS-103
  - [ติดตามเคสของฉัน] → หน้า Track Tickets
  - [แจ้งเคสใหม่] → สร้างเคสใหม่
  ↓
เคส CDGS-103 ปรากฏใน:
  ✅ "งานของฉัน" (Customer - Read/Write)
  ✅ "รอดำเนินการ" (Tier1 - เห็นป้าย "⚠️ ข้อมูลไม่ครบ")
  ✅ "รอดำเนินการ (Monitor)" (Admin)
  ↓
Tier1 D เข้ามาดูเมนู "รอดำเนินการ"
  ↓
Tier1 D กด "รับเคส" ที่ CDGS-103
  ↓
⚠️ ระบบตรวจสอบ: needsTriage = true
  ↓
แสดง Triage Modal:
  ┌─────────────────────────────────────────┐
  │ รับเคสและกำหนดข้อมูล                    │
  │─────────────────────────────────────────│
  │ 📋 #CDGS-103                            │
  │ ไม่สามารถดาวน์โหลดไฟล์ได้              │
  │ ลูกค้า: ศิริพร อารีมิตร                │
  │ หมวดหมู่: ระบบขัดข้อง                  │
  │                                         │
  │ ── กรุณาเติมข้อมูลเพื่อรับเคส ──        │
  │                                         │
  │ โครงการ: * [Asset Management ▼]        │
  │             (Auto-suggest จาก Product)  │
  │                                         │
  │ ประเภท: * [Incident ▼]                 │
  │           (Default)                     │
  │                                         │
  │ ความสำคัญ: [ปกติ ▼]                    │
  │            (Auto-calculate)             │
  │                                         │
  │ 💡 SLA: 8 ชั่วโมง                       │
  │                                         │
  │ หมายเหตุภายใน:                          │
  │ [ลูกค้าต้องการดาวน์โหลดไฟล์ข้อมูล...] │
  │                                         │
  │      [ยกเลิก]  [รับเคสและดำเนินการ]    │
  └─────────────────────────────────────────┘
  ↓
Tier1 D กด "รับเคสและดำเนินการ"
  ↓
ระบบอัปเดตเคส CDGS-103:
  - status = 'in_progress'
  - assignedTo = Tier1 D
  - assignedAt = now()
  - projectId = 'proj-asset'
  - projectName = 'Asset Management'
  - type = 'incident'
  - priority = 'medium'
  - slaHours = 8
  - slaDueDate = now() + 8 hours
  - needsTriage = false
  - triageCompletedBy = Tier1 D
  - triageCompletedAt = now()
  ↓
ส่งอีเมลแจ้ง Customer:
  - "เคส #CDGS-103 ได้รับการมอบหมายแล้ว"
  - "ผู้รับผิดชอบ: Tier1 D"
  - "โครงการ: Asset Management"
  - "SLA: 8 ชั่วโมง (ครบกำหนด: 21 ม.ค. 2026 22:30)"
  ↓
เคส CDGS-103 ปรากฏใน:
  ✅ "งานของฉัน" (Customer - เห็นว่า assigned to Tier1 D)
  ✅ "งานของฉัน" (Tier1 D - กำลังทำอยู่)
  ❌ "รอดำเนินการ" (ถูกรับแล้ว)
  ↓
Tier1 D แก้ไข → กด "ปิดเคส"
  ↓
ระบบอัปเดต:
  - status = 'closed'
  - closedBy = Tier1 D
  - closedAt = now()
  ↓
ส่งอีเมลแจ้ง Customer:
  - "เคส #CDGS-103 ถูกปิดแล้ว"
  - "ผู้ปิดเคส: Tier1 D"
  - มี Magic Link ดูรายละเอียด
  ↓
✅ เสร็จสิ้น
```

---

### กรณีที่ 2: Customer กลับมาใช้งานอีกครั้ง (Magic Link Login)

```
💻 Customer เข้า Landing Page (หลังผ่านไปหลายวัน)
  ↓
กด "เข้าสู่ระบบด้วยอีเมล"
  ↓
Dialog เปิดขึ้น:
  - อีเมล: "siriporn@example.com"
  ↓
กด "ส่งลิงค์"
  ↓
ระบบสร้าง Magic Link Token:
  - token = crypto.randomUUID()
  - expiry = now() + 30 minutes
  - save to database
  ↓
ส่งอีเมลให้ Customer:
  - หัวข้อ: "เข้าสู่ระบบ CDGS Support"
  - [เข้าสู่ระบบ] ← Magic Link
  - https://support.cdgs.co.th/auth/magic?token=abc123
  ↓
Customer คลิกลิงค์จากอีเมล
  ↓
ระบบตรวจสอบ Token:
  - ✅ Valid & Not Expired → Auto-login
  - ❌ Invalid/Expired → แสดงข้อความ "ลิงค์หมดอายุ"
  ↓
✅ Auto-login สำเร็จ
  ↓
Redirect → หน้า Track Tickets
  - แสดงเคสทั้งหมดของ Customer
  - มีปุ่ม "+ แจ้งเคสใหม่"
  ↓
Customer สามารถ:
  - ดูรายละเอียดเคส
  - เพิ่มความคิดเห็น
  - แจ้งเคสใหม่
  - ออกจากระบบ
```

---

### กรณีทั่วไป: Customer สร้างเคส

```
💻 Customer login → Web Portal
  ↓
กด "สร้างเคสใหม่"
  ↓
กรอก Form:
  - หัวเรื่อง: "ไม่สามารถดาวน์โหลดไฟล์ได้"
  - รายละเอียด: "..."
  - Priority: medium
  - อัปโหลดไฟล์แนบ (ถ้ามี)
  ↓
กด "สร้างเคส"
  ↓
ระบบสร้างเคส CDGS-103:
  - status = 'new'
  - createdBy = Customer C
  - channel = 'web'
  - assignedTo = null
  ↓
เคส CDGS-103 ปรากฏใน:
  ✅ "งานของฉัน" (Customer C - Read/Write)
  ✅ "รอดำเนินการ" (Tier1 เห็น - พร้อมปุ่ม "รับเคส")
  ✅ "รอดำเนินการ (Monitor)" (Admin เห็น - Monitor)
  ↓
Tier1 D กด "รับเคส"
  ↓
ระบบอัปเดต:
  - status = 'in_progress'
  - assignedTo = Tier1 D
  ↓
เคส CDGS-103 ปราก��ใน:
  ✅ "งานของฉัน" (Customer C - เห็นว่า assigned to Tier1 D)
  ✅ "งานของฉัน" (Tier1 D - กำลังทำอยู่)
  ↓
Tier1 D แก้ไข → กด "แก้ไขเสร็จแล้ว"
  ↓
ระบบอัปเดต:
  - status = 'resolved'
  - resolvedBy = Tier1 D
  - resolvedAt = now()
  ↓
Customer C ได้รับการแจ้งเตือน → เข้าดูเคส → ยืนยัน "ปิดเคส"
  ↓
ระบบอัปเดต:
  - status = 'closed'
  - closedAt = now()
  ↓
✅ เสร็จสิ้น
```

---

## 3. Tier Workflow

### 3.1 Tier1 รับเคสและแก้ไข

```
Tier1 E login → Dashboard
  ↓
เปิดเมนู "รอดำเนินการ"
  ↓
เห็นเคส CDGS-104 (status = new)
  ↓
กด "รับเคส"
  ↓
ระบบอัปเดต:
  - status = 'in_progress'
  - assignedTo = Tier1 E
  ↓
เคส CDGS-104 ย้ายไป "งานของฉัน"
  ↓
Tier1 E แก้ไข → เลือก:
  │
  ├── ✅ กด "ปิดเคส" (แก้ไขเสร็จ)
  │     ↓
  │   status = 'closed'
  │   closedBy = Tier1 E
  │   ✅ เสร็จสิ้น
  │
  ├── 📤 กด "ส่งต่อ Tier2" (ปัญหาซับซ้อน)
  │     ↓
  │   status = 'tier2'
  │   assignedTo = null
  │   escalatedBy = Tier1 E
  │   ↓
  │   ปรากฏใน "รอดำเนินการ" (Tier2)
  │   ปรากฏใน "เคสที่ฉันส่งต่อ" (Tier1 E)
  │
  ├── ⏸️ กด "หยุดชั่วคราว" (รอข้อมูลจากลูกค้า)
  │     ↓
  │   status = 'waiting'
  │   ยังอยู่ใน "งานของฉัน"
  │   ↓
  │   รอลูกค้าตอบกลับ → กด "ดำเนินการต่อ"
  │   ↓
  │   status = 'in_progress'
  │
  └── 🔄 กด "ส่งต่อ Tier1 อื่น" (Reassign)
        ↓
      assignedTo = null (หรือเลือก Tier1 คนอื่น)
      ปรากฏใน "รอดำเนินการ" (Tier1)
```

---

### 3.2 Tier2 รับเคสจาก Tier1

```
Tier2 F login → Dashboard
  ↓
เปิดเมนู "รอดำเนินการ"
  ↓
เห็นเคส CDGS-105 (status = tier2, escalatedBy = Tier1 E)
  ↓
กด "รับเคส"
  ↓
ระบบอัปเดต:
  - status = 'in_progress'
  - assignedTo = Tier2 F
  ↓
Tier2 F แก้ไข → เลือก:
  │
  ├── ✅ กด "ปิดเคส" (แก้ไขเสร็จ)
  │     ↓
  │   status = 'closed'
  │   closedBy = Tier2 F
  │
  ├── 📤 กด "ส่งต่อ Tier3" (ปัญหาซับซ้อนมาก)
  │     ↓
  │   status = 'tier3'
  │   assignedTo = null
  │   escalatedBy = Tier2 F
  │   ↓
  │   ปรากฏใน "รอดำเนินการ" (Tier3)
  │   ปรากฏใน "เคสที่ฉันส่งต่อ" (Tier2 F)
  │
  └── ◀️ กด "ส่งกลับ Tier1" (Escalate back)
        ↓
      status = 'tier1'
      assignedTo = null (หรือเลือก Tier1 คนเดิม)
      escalatedBy = Tier2 F
      ↓
      ปรากฏใน "รอดำเนินการ" (Tier1)
      ปรากฏใน "เคสที่ฉันส่งต่อ" (Tier2 F)
```

---

### 3.3 Tier3 รับเคสจาก Tier2

```
Tier3 G login → Dashboard
  ↓
เปิดเมนู "รอดำเนินการ"
  ↓
เห็นเคส CDGS-106 (status = tier3, escalatedBy = Tier2 F)
  ↓
กด "รับเคส"
  ↓
ระบบอัปเดต:
  - status = 'in_progress'
  - assignedTo = Tier3 G
  ↓
Tier3 G แก้ไข (Expert level)
  ↓
เลือก:
  │
  ├── ✅ กด "ปิดเคส" (แก้ไขเสร็จ)
  │     ↓
  │   status = 'closed'
  │   closedBy = Tier3 G
  │
  └── ◀️ กด "ส่งกลับ Tier2" (ส่งกลับให้ดำเนินการต่อ)
        ↓
      status = 'tier2'
      assignedTo = null
      escalatedBy = Tier3 G
      ↓
      ปรากฏใน "รอดำเนินการ" (Tier2)
      ปรากฏใน "เคสที่ฉันส่งต่อ" (Tier3 G)
```

---

## 4. Escalation Flow

### 4.1 Symmetric Escalation (สมมาตร)

```
Tier1 ⇄ Tier2 ⇄ Tier3

ทิศทางที่เป็นไปได้:
├── Tier1 → Tier2 (ส่งต่อ)
├── Tier1 → Tier3 (ข้ามระดับ)
├── Tier2 → Tier1 (ส่งกลับ)
├── Tier2 → Tier3 (ส่งต่อ)
├── Tier3 → Tier2 (ส่งกลับ)
├── Tier3 → Tier1 (ส่งกลับ)
├── Tier1 → Tier1 อื่น (Reassign)
├── Tier2 → Tier2 อื่น (Reassign)
└── Tier3 → Tier3 อื่น (Reassign)
```

---

### 4.2 ตัวอย่าง Escalation Chain

```
CDGS-107: "ปัญหาซับซ้อนระดับสูง"

1. Customer สร้างเคส
   status = 'new'
   ↓
2. Tier1 A รับเคส
   status = 'in_progress', assignedTo = Tier1 A
   ↓
3. Tier1 A พบว่าซับซ้อน → ส่งต่อ Tier2
   status = 'tier2', assignedTo = null
   escalatedBy = Tier1 A
   ↓
4. Tier2 B รับเคส
   status = 'in_progress', assignedTo = Tier2 B
   ↓
5. Tier2 B พบว่าซับซ้อนมาก → ส่งต่อ Tier3
   status = 'tier3', assignedTo = null
   escalatedBy = Tier2 B
   ↓
6. Tier3 C รับเคส
   status = 'in_progress', assignedTo = Tier3 C
   ↓
7. Tier3 C แก้ไขเสร็จ → ส่งกลับ Tier2 ให้ดำเนินการต่อ
   status = 'tier2', assignedTo = null
   escalatedBy = Tier3 C
   ↓
8. Tier2 B รับเคสกลับมา
   status = 'in_progress', assignedTo = Tier2 B
   ↓
9. Tier2 B ดำเนินการต่อ → ปิดเคส
   status = 'closed', closedBy = Tier2 B
   ↓
✅ เสร็จสิ้น

Escalation History:
  Customer → Tier1 A → Tier2 B → Tier3 C → Tier2 B → Closed
```

---

## 5. Status Lifecycle

### 5.1 Status ทั้งหมด

```
new               เคสใหม่ (รอ Tier1 รับ)
tier1             ส่งต่อให้ Tier1 (รอรับ)
tier2             ส่งต่อให้ Tier2 (รอรับ)
tier3             ส่งต่อให้ Tier3 (รอรับ)
in_progress       กำลังดำเนินการ
waiting           หยุดชั่วคราว (รอข้อมูล)
resolved          แก้ไขเสร็จแล้ว (รอลูกค้าตรวจสอบ)
pending_closure   รอปิด
closed            ปิดเคสแล้ว
```

---

### 5.2 Status Flow

```
new (เคสใหม่)
  ↓ [Tier1 กด "รับเคส"]
in_progress (กำลังทำ)
  ↓
  ├── [กด "หยุดชั่วคราว"]
  │   ↓
  │ waiting (รอข้อมูล)
  │   ↓ [กด "ดำเนินการต่อ"]
  │ in_progress
  │
  ├── [กด "ส่งต่อ Tier2"]
  │   ↓
  │ tier2 (รอ Tier2 รับ)
  │   ↓ [Tier2 กด "รับเคส"]
  │ in_progress (Tier2 ทำอยู่)
  │
  └── [กด "แก้ไขเสร็จแล้ว"]
      ↓
    resolved (รอลูกค้าตรวจสอบ)
      ↓ [Customer/Tier กด "ปิดเคส"]
    closed (ปิดแล้ว)
```

---

### 5.3 Status Transitions Matrix

| จาก \ ไป | new | tier1 | tier2 | tier3 | in_progress | waiting | resolved | pending_closure | closed |
|---------|-----|-------|-------|-------|------------|---------|----------|----------------|--------|
| **new** | - | ✅ | ✅ | ✅ | ✅ (รับเคส) | ❌ | ❌ | ❌ | ✅ (Staff ปิดเลย) |
| **tier1** | ❌ | - | ✅ | ✅ | ✅ (รับเคส) | ❌ | ❌ | ❌ | ❌ |
| **tier2** | ❌ | ✅ (ส่งกลับ) | - | ✅ | ✅ (รับเคส) | ❌ | ❌ | ❌ | ❌ |
| **tier3** | ❌ | ✅ (ส่งกลับ) | ✅ (ส่งกลับ) | - | ✅ (รับเคส) | ❌ | ❌ | ❌ | ❌ |
| **in_progress** | ❌ | ✅ | ✅ | ✅ | - | ✅ | ✅ | ✅ | ✅ |
| **waiting** | ❌ | ✅ | ✅ | ✅ | ✅ | - | ✅ | ❌ | ✅ |
| **resolved** | ❌ | ❌ | ❌ | ❌ | ✅ (Re-open) | ❌ | - | ✅ | ✅ |
| **pending_closure** | ❌ | ❌ | ❌ | ❌ | ✅ (Re-open) | ❌ | ❌ | - | ✅ |
| **closed** | ❌ | ❌ | ❌ | ❌ | ✅ (Re-open) | ❌ | ❌ | ❌ | - |

---

## 6. ตัวอย่าง Flow จริง

### ตัวอย่างที่ 1: เคสง่าย (Tier1 แก้ไขเลย)

```
Day 1, 09:00 - Customer A สร้างเคส CDGS-201
  - หัวเรื่อง: "ลืมรหัสผ่าน"
  - status = 'new'
  - createdBy = Customer A
  
Day 1, 09:15 - Tier1 B รับเคส
  - status = 'in_progress'
  - assignedTo = Tier1 B
  
Day 1, 09:20 - Tier1 B reset รหัสผ่าน → ปิดเคส
  - status = 'closed'
  - closedBy = Tier1 B
  - SLA: 20 นาที ✅

Escalation History:
  Customer A → Tier1 B → Closed
```

---

### ตัวอย่างที่ 2: เคสซับซ้อน (Tier1 → Tier2)

```
Day 1, 10:00 - Customer C สร้างเคส CDGS-202
  - หัวเรื่อง: "Database connection error"
  - status = 'new'
  
Day 1, 10:10 - Tier1 D รับเคส
  - status = 'in_progress'
  - assignedTo = Tier1 D
  
Day 1, 10:30 - Tier1 D พบว่าเป็นปัญหา Database → ส่งต่อ Tier2
  - status = 'tier2'
  - assignedTo = null
  - escalatedBy = Tier1 D
  
Day 1, 11:00 - Tier2 E รับเคส
  - status = 'in_progress'
  - assignedTo = Tier2 E
  
Day 1, 14:00 - Tier2 E แก้ไขเสร็จ → ปิดเคส
  - status = 'closed'
  - closedBy = Tier2 E
  - SLA: 4 ชั่วโมง ✅

Escalation History:
  Customer C → Tier1 D → Tier2 E → Closed
```

---

### ตัวอย่างที่ 3: เคสซับซ้อนมาก (Tier1 → Tier2 → Tier3 → Tier2)

```
Day 1, 14:00 - Customer F สร้างเคส CDGS-203
  - หัวเรื่อง: "Production server down"
  - Priority: Critical
  - status = 'new'
  
Day 1, 14:05 - Tier1 G รับเคส
  - status = 'in_progress'
  
Day 1, 14:10 - Tier1 G ส่งต่อ Tier2 (Critical issue)
  - status = 'tier2'
  - escalatedBy = Tier1 G
  
Day 1, 14:15 - Tier2 H รับเคส
  - status = 'in_progress'
  
Day 1, 14:30 - Tier2 H ส่งต่อ Tier3 (ต้องการ Expert)
  - status = 'tier3'
  - escalatedBy = Tier2 H
  
Day 1, 14:40 - Tier3 I รับเคส
  - status = 'in_progress'
  
Day 1, 15:00 - Tier3 I ระบุสาเหตุ → ส่งกลับ Tier2 ให้แก้ไข
  - status = 'tier2'
  - assignedTo = null
  - escalatedBy = Tier3 I
  - Comment: "สาเหตุคือ... ให้ Tier2 ดำเนินการ..."
  
Day 1, 15:10 - Tier2 H รับเคสกลับม��
  - status = 'in_progress'
  - assignedTo = Tier2 H
  
Day 1, 16:00 - Tier2 H แก้ไขเสร็จ → ปิดเคส
  - status = 'closed'
  - closedBy = Tier2 H
  - SLA: 2 ชั่วโมง ✅

Escalation History:
  Customer F → Tier1 G → Tier2 H → Tier3 I → Tier2 H → Closed

Timeline:
  14:00 - Created
  14:05 - Tier1 assigned (5 min)
  14:10 - Escalate to Tier2 (5 min)
  14:15 - Tier2 assigned (5 min)
  14:30 - Escalate to Tier3 (15 min)
  14:40 - Tier3 assigned (10 min)
  15:00 - Escalate back to Tier2 (20 min)
  15:10 - Tier2 assigned (10 min)
  16:00 - Closed (50 min)
  Total: 2 hours
```

---

### ตัวอย่างที่ 4: Staff บันทึกและส่งต่อ (เคสย้อนหลัง)

```
Day 2, 09:00 - ลูกค้าโทรมาที่ Call Center
  - ลูกค้า: "ขอทราบสถานะการจัดส่ง"
Day 2, 09:02 - Staff J รับสายและตอบลูกค้าทันที (จบการสนทนา)

Day 2, 09:05 - Staff J login เพื่อบันทึกข้อมูล
  ↓
Staff J กด "บันทึกเคสแทนลูกค้า"
  ↓
กรอก Form:
  - หัวเรื่อง: "สอบถามสถานะการจัดส่ง"
  - ชื่อลูกค้า: "นาย ค."
  - Incident Date: 09:00 (ย้อนหลัง)
  - โครงการ: เลือกโครงการ A
  ↓
กด "📤 ส่งงาน"
  ↓
ระบบสร้างเคส CDGS-204: status='new', assignedTo=null
  ↓
Tier1 M เข้ามาเห็นเคสใน "รอดำเนินการ"
  ↓
Tier1 M กด "รับเคส" -> status='in_progress'
  ↓
Tier1 M บันทึกผลการแก้ไข (ว่า Staff ตอบไปแล้ว) -> กด "ปิดเคส"
  ↓
ระบบสร้างเคส CDGS-204: status='closed', closedBy=Tier1 M
  ↓
✅ เสร็จสิ้น
```

---

### ตัวอย่างที่ 5: Staff บันทึกและส่งต่อ Tier1

```
Day 2, 10:00 - ลูกค้าส่งอีเมลแจ้งปัญหา
  - "ระบบแสดง error code 500"
  
Day 2, 10:30 - Staff K อ่านอีเมล
  ↓
Staff K login → กด "บันทึกเคสแทนลูกค้า"
  ↓
กรอก Form:
  - หัวเรื่อง: "Error code 500 ตอนใช้งาน"
  - ชื่อลูกค้า: "บริษัท XYZ"
  - อีเมล: "contact@xyz.com"
  - Channel: email
  - Priority: high
  - แนบไฟล์: error-screenshot.png
  ↓
กด "📤 ส่งงาน"
  ↓
ระบบสร้างเคส CDGS-205:
  - status = 'new'
  - createdBy = Staff K
  - channel = email
  ↓
Day 2, 10:45 - Tier1 L รับเคส
  - status = 'in_progress'
  - assignedTo = Tier1 L
  ↓
Day 2, 11:00 - Tier1 L กด "หยุดชั่วคราว" (รอ log file จากลูกค้า)
  - status = 'waiting'
  ↓
Day 2, 14:00 - ลูกค้าส่ง log file มา
  ↓
Tier1 L กด "ดำเนินการต่อ"
  - status = 'in_progress'
  ↓
Day 2, 15:00 - Tier1 L แก้ไขเสร็จ → ปิดเคส
  - status = 'closed'
  - closedBy = Tier1 L
  - SLA: 5 ชั่วโมง ✅

Escalation History:
  Staff K → Tier1 L → Closed

Timeline:
  10:30 - Staff K สร้างเคส
  10:45 - Tier1 L รับเคส (15 min)
  11:00 - หยุดชั่วคราว (15 min)
  14:00 - ดำเนินการต่อ (3 hours waiting)
  15:00 - ปิดเคส (1 hour)
  Total: 5 hours (รวมเวลารอลูกค้า)
```

---

## 📊 สรุป Flow ทั้งหมด

### เคสที่ Staff สร้าง

| สถานการณ์ | Flow | Status | ใครปิด |
|----------|------|--------|--------|
| **แก้ไขทันที** | Staff → ปิดเลย | closed | Staff |
| **ส่งต่อ Tier1** | Staff → Tier1 → ... → ปิด | new → in_progress → closed | Tier1/2/3 |

### เคสที่ Customer สร้าง

| สถานการณ์ | Flow | Status | ใครปิด |
|----------|------|--------|--------|
| **ง่าย** | Customer → Tier1 → ปิด | new → in_progress → closed | Tier1 |
| **ปานกลาง** | Customer → Tier1 → Tier2 → ปิด | new → tier2 → in_progress → closed | Tier2 |
| **ซับซ้อน** | Customer → Tier1 → Tier2 → Tier3 → ... → ปิด | new → tier2 → tier3 → ... → closed | Tier2/3 |

### เคสที่หยุดชั่วคราว

| สถานการณ์ | Flow | Status |
|----------|------|--------|
| **รอข้อมูล** | in_progress → waiting → in_progress → closed | waiting |
| **รอทีมอื่น** | in_progress → waiting → in_progress → closed | waiting |

---

**อ่านเอกสารอื่น:**
- [Project Overview](/docs/features/PROJECT_OVERVIEW.md)
- [Navigation Menu](/docs/features/NAVIGATION_MENU.md)
- [Permission Matrix](/docs/technical/PERMISSION_MATRIX.md)
