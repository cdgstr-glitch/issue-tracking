# 🎯 Product Filtering by Project

> **Feature:** Dynamic Product Selection based on Project's Purchased Products  
> **Version:** 1.0  
> **Last Updated:** 2026-01-23  
> **Status:** ✅ Active

---

## 📋 **Overview**

ระบบจะแสดงเฉพาะผลิตภัณฑ์ที่โครงการซื้อไว้ใน dropdown "ผลิตภัณฑ์ที่ใช้งาน" เพื่อช่วยให้ Staff และ Tier1 สามารถตัดสินใจเลือกผลิตภัณฑ์ที่ถูกต้องได้ง่ายขึ้น

---

## 🎯 **Problem Statement**

### **ก่อนหน้านี้:**
- ❌ Staff/Tier1 เห็นผลิตภัณฑ์ทั้งหมด 9 ตัว ในทุกเคส
- ❌ ไม่ทราบว่าโครงการนั้นซื้อผลิตภัณฑ์อะไรบ้าง
- ❌ อาจเลือกผลิตภัณฑ์ผิดเพราะไม่มีข้อมูล
- ❌ ต้องจำหรือตรวจสอบว่าลูกค้าซื้ออะไร

### **ตอนนี้:**
- ✅ **Filter ตามโครงการ:** แสดงเฉพาะผลิตภัณฑ์ที่โครงการซื้อ
- ✅ **Auto-select ถ้ามี 1 ตัว:** เลือกอัตโนมัติและ disable dropdown
- ✅ **แสดงข้อมูลช่วยเหลือ:** บอกจำนวนและรายชื่อผลิตภัณฑ์
- ✅ **ลดโอกาสเลือกผิด:** มองเห็นได้ชัดเจน

---

## 📐 **Data Structure**

### **Project Interface (Updated)**

```typescript
export interface Project {
  id: string;                        // 'proj-001'
  organizationId: string;            // 'org-001'
  projectCode: string;               // 'D26-0001'
  projectName: string;               // 'โครงการจัดทำบัตรสวัสดิการของรัฐ'
  projectStatus: ProjectStatus;      // 'active' | 'completed' | 'cancelled' | 'on_hold'
  
  // 🆕 ผลิตภัณฑ์ที่โครงการซื้อ
  purchasedProducts?: string[];      // ['e-payslip', 'e-maintenance']
  
  // ... existing fields
  createdAt: Date;
  updatedAt: Date;
}
```

### **Product Interface**

```typescript
export interface ProductInfo {
  value: string;        // 'e-payslip'
  label: string;        // 'e-Payslip'
  description: string;  // 'ระบบสลิปเงินเดือนออนไลน์'
  category: 'document' | 'asset' | 'hr' | 'facility' | 'project';
}
```

---

## 🔄 **Logic Flow**

### **1. Customer (ลูกค้าแจ้งเคสเอง)**

```
Customer แจ้งเคส
    ↓
ไม่มีโครงการ (projectId = null)
    ↓
แสดงผลิตภัณฑ์ทั้งหมด (9 ตัว)
    ↓
Customer เลือกเองตามที่เห็นว่าเหมาะสม
```

**Logic:**
```typescript
if (!canCreateForCustomer) {
  return ALL_PRODUCTS; // แสดงทั้งหมด
}
```

---

### **2. Staff/Tier1 (บันทึกแทนลูกค้า)**

#### **Step 1: ยังไม่เลือกโครงการ**

```
Staff เข้าฟอร์ม
    ↓
ยังไม่ได้เลือกโครงการ
    ↓
แสดงผลิตภัณฑ์ทั้งหมด (9 ตัว)
    ↓
⚠️ เตือน: ต้องเลือกโครงการก่อน
```

**Logic:**
```typescript
if (!selectedProject) {
  return ALL_PRODUCTS; // Fallback: แสดงทั้งหมด
}
```

---

#### **Step 2: เลือกโครงการแล้ว**

##### **Case A: โครงการมี purchasedProducts (ตั้งค่าแล้ว)**

```
Staff เลือกโครงการ "D26-0009"
    ↓
อ่าน: purchasedProducts = ['e-payslip', 'e-maintenance']
    ↓
Filter dropdown → แสดงแค่ 2 ตัวนี้
    ↓
💡 แสดงข้อความ: "โครงการนี้ใช้งาน 2 ผลิตภัณฑ์ (e-Payslip, e-Maintenance)"
```

**Logic:**
```typescript
if (selectedProject.purchasedProducts && selectedProject.purchasedProducts.length > 0) {
  return ALL_PRODUCTS.filter(p => 
    selectedProject.purchasedProducts!.includes(p.value)
  );
}
```

---

##### **Case B: โครงการมี 1 ผลิตภัณฑ์ (Auto-select)**

```
Staff เลือกโครงการ "D26-0003"
    ↓
อ่าน: purchasedProducts = ['e-saraban']
    ↓
✅ Auto-select: selectedProduct = 'e-saraban'
    ↓
🔒 Disable dropdown (ไม่ให้เปลี่ยน)
    ↓
💡 แสดงข้อความ: "โครงการนี้ใช้งาน 1 ผลิตภัณฑ์ (e-Saraban)"
                "✅ ผลิตภัณฑ์ถูกเลือกอัตโนมัติเนื่องจากมีเพียงตัวเดียว"
```

**Logic:**
```typescript
// Auto-select
useEffect(() => {
  if (canCreateForCustomer && selectedProject && availableProducts.length === 1) {
    setSelectedProduct(availableProducts[0].value);
  }
}, [selectedProject, availableProducts, canCreateForCustomer]);

// Disable dropdown
<Select 
  disabled={canCreateForCustomer && selectedProject && availableProducts.length === 1}
>
```

---

##### **Case C: โครงการไม่มี purchasedProducts (ยังไม่ตั้งค่า)**

```
Staff เลือกโครงการที่ยังไม่ตั้งค่า
    ↓
purchasedProducts = undefined หรือ []
    ↓
Fallback: แสดงผลิตภัณฑ์ทั้งหมด (9 ตัว)
    ↓
Staff เลือกเองตามข้อมูลที่ได้จากลูกค้า
```

**Logic:**
```typescript
// Fallback: แสดงทั้งหมด
return ALL_PRODUCTS;
```

---

## 🎨 **UI/UX Design**

### **Dropdown Product Selector**

#### **State 1: ยังไม่เลือกโครงการ (Customer หรือ Staff)**

```
┌─────────────────────────────────────┐
│ ผลิตภัณฑ์ที่ใช้งาน *                │
│ [เลือกผลิตภัณฑ์ ▼]                  │
│                                     │
│ 💬 เลือกผลิตภัณฑ์ที่เกี่ยวข้องกับ   │
│    ปัญหาของคุณ                      │
└─────────────────────────────────────┘

Dropdown แสดง: 9 ผลิตภัณฑ์ทั้งหมด
```

---

#### **State 2: เลือกโครงการแล้ว (มี 2-3 ผลิตภัณฑ์)**

```
┌─────────────────────────────────────┐
│ ผลิตภัณฑ์ที่ใช้งาน *                │
│ [เลือกผลิตภัณฑ์ ▼]                  │
│                                     │
│ 💡 โครงการนี้ใช้งาน 2 ผลิตภัณฑ์    │
│    (e-Payslip, e-Maintenance)       │
└─────────────────────────────────────┘

Dropdown แสดง:
  • e-Payslip
  • e-Maintenance
```

**CSS:**
- ข้อความสีน้ำเงิน (`text-blue-600`)
- แสดงรายชื่อถ้า ≤ 3 ตัว

---

#### **State 3: เลือกโครงการแล้ว (มี 1 ผลิตภัณฑ์ - Auto-selected)**

```
┌─────────────────────────────────────┐
│ ผลิตภัณฑ์ที่ใช้งาน *                │
│ [e-Saraban ▼] 🔒                    │ ← Disabled, สีเทา
│                                     │
│ 💡 โครงการนี้ใช้งาน 1 ผลิตภัณฑ์    │
│    (e-Saraban)                      │
│ ✅ ผลิตภัณฑ์ถูกเลือกอัตโนมัติ       │
│    เนื่องจากมีเพียงตัวเดียว         │
└─────────────────────────────────────┘

Dropdown: Disabled (ไม่สามารถเปลี่ยนได้)
```

**CSS:**
- Dropdown disabled
- ข้อความเพิ่มเติม (`text-gray-500`)

---

#### **State 4: เลือกโครงการแล้ว (มี 4+ ผลิตภัณฑ์)**

```
┌─────────────────────────────────────┐
│ ผลิตภัณฑ์ที่ใช้งาน *                │
│ [เลือกผลิตภัณฑ์ ▼]                  │
│                                     │
│ 💡 โครงการนี้ใช้งาน 5 ผลิตภัณฑ์    │ ← ไม่แสดงรายชื่อ (มากเกินไป)
└─────────────────────────────────────┘

Dropdown แสดง: 5 ผลิตภัณฑ์ที่โครงการซื้อ
```

---

## 📊 **Mock Data Examples**

### **Example 1: โครงการพัฒนาบุคลากร (2 ผลิตภัณฑ์)**

```typescript
{
  id: 'proj-csv-008',
  projectCode: 'D26-0009',
  projectName: 'โครงการจัดจ้างสร้างระบบปรับปรุงระบบงานพัฒนาบุคลากร',
  purchasedProducts: ['e-payslip', 'e-maintenance']
}
```

**ผลลัพธ์:**
- Dropdown แสดง: `e-Payslip`, `e-Maintenance` เท่านั้น
- Helper text: "โครงการนี้ใช้งาน 2 ผลิตภัณฑ์ (e-Payslip, e-Maintenance)"

---

### **Example 2: โครงการ e-Saraban (1 ผลิตภัณฑ์)**

```typescript
{
  id: 'proj-csv-003',
  projectCode: 'D26-0003',
  projectName: 'โครงการพัฒนาระบบสารบรรณอิเล็กทรอนิกส์',
  purchasedProducts: ['e-saraban']
}
```

**ผลลัพธ์:**
- ✅ Auto-select: `e-Saraban`
- 🔒 Dropdown disabled
- Helper text: "โครงการนี้ใช้งาน 1 ผลิตภัณฑ์ (e-Saraban)"
- Additional text: "✅ ผลิตภัณฑ์ถูกเลือกอัตโนมัติเนื่องจากมีเพียงตัวเดียว"

---

### **Example 3: โครงการเทคโนโลยีราชมงคล (Full Suite - 9 ผลิตภัณฑ์)**

```typescript
{
  id: 'proj-csv-002',
  projectCode: 'D26-0002',
  projectName: 'โครงการหลัก - มหาวิทยาลัยเทคโนโลยีราชมงคลพระนคร',
  purchasedProducts: COMMON_BUNDLES.FULL_SUITE // ครบทั้ง 9 ตัว
}
```

**ผลลัพธ์:**
- Dropdown แสดง: ทั้ง 9 ผลิตภัณฑ์
- Helper text: "โครงการนี้ใช้งาน 9 ผลิตภัณฑ์" (ไม่แสดงรายชื่อ)

---

### **Example 4: โครงการยังไม่ตั้งค่า**

```typescript
{
  id: 'proj-legacy-001',
  projectCode: 'PRJ-MRTA-2024-001',
  projectName: 'โครงการหลัก - MRTA',
  purchasedProducts: undefined // ยังไม่มีข้อมูล
}
```

**ผลลัพธ์:**
- Fallback: แสดงทั้ง 9 ผลิตภัณฑ์
- ไม่มี helper text เพิ่มเติม

---

## 🔄 **Workflow Diagram**

```
┌─────────────────────────────────────────────────────────────┐
│                    Staff เข้าฟอร์ม                          │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ↓
            ┌─────────────────────┐
            │ เลือกโครงการ?       │
            └─────────┬───────────┘
                      │
        ┌─────────────┼─────────────┐
        │ NO          │             │ YES
        ↓             ↓             ↓
  ┌──────────┐   ┌──────────┐   ┌──────────────────┐
  │ แสดง     │   │ Fallback:│   │ อ่าน             │
  │ ทั้งหมด  │   │ แสดง     │   │ purchasedProducts│
  │ 9 ตัว    │   │ ทั้งหมด  │   └────────┬─────────┘
  └──────────┘   └──────────┘            │
                                          │
                      ┌───────────────────┼───────────────────┐
                      │                   │                   │
                      ↓                   ↓                   ↓
              ┌───────────────┐   ┌───────────────┐   ┌───────────────┐
              │ undefined      │   │ length = 1    │   │ length >= 2   │
              │ หรือ []        │   └───────┬───────┘   └───────┬───────┘
              └───────┬───────┘           │                   │
                      │                   │                   │
                      ↓                   ↓                   ↓
              ┌───────────────┐   ┌───────────────┐   ┌───────────────┐
              │ แสดงทั้งหมด  │   │ Auto-select   │   │ Filter dropdown│
              │ 9 ตัว         │   │ + Disable     │   │ แค่ที่ซื้อ    │
              └───────────────┘   └───────────────┘   └───────────────┘
```

---

## 🧪 **Test Cases**

### **Test Case 1: Customer แจ้งเคส (ไม่มีโครงการ)**

**Given:**
- User = Customer
- canCreateForCustomer = false

**Expected:**
- ✅ แสดงผลิตภัณฑ์ทั้งหมด 9 ตัว
- ✅ Dropdown enabled
- ✅ Helper text: "เลือกผลิตภัณฑ์ที่เกี่ยวข้องกับปัญหาของคุณ"

---

### **Test Case 2: Staff ยังไม่เลือกโครงการ**

**Given:**
- User = Staff
- canCreateForCustomer = true
- selectedProject = null

**Expected:**
- ✅ แสดงผลิตภัณฑ์ทั้งหมด 9 ตัว
- ✅ Dropdown enabled
- ✅ ไม่มี helper text พิเศษ

---

### **Test Case 3: Staff เลือกโครงการที่มี 2 ผลิตภัณฑ์**

**Given:**
- User = Staff
- selectedProject = D26-0009
- purchasedProducts = ['e-payslip', 'e-maintenance']

**Expected:**
- ✅ แสดงเฉพาะ 2 ตัว
- ✅ Dropdown enabled
- ✅ Helper text: "โครงการนี้ใช้งาน 2 ผลิตภัณฑ์ (e-Payslip, e-Maintenance)"

---

### **Test Case 4: Staff เลือกโครงการที่มี 1 ผลิตภัณฑ์**

**Given:**
- User = Tier1
- selectedProject = D26-0003
- purchasedProducts = ['e-saraban']

**Expected:**
- ✅ Auto-select: selectedProduct = 'e-saraban'
- ✅ Dropdown **disabled**
- ✅ Helper text: 
  - "โครงการนี้ใช้งาน 1 ผลิตภัณฑ์ (e-Saraban)"
  - "✅ ผลิตภัณฑ์ถูกเลือกอัตโนมัติเนื่องจากมีเพียงตัวเดียว"

---

### **Test Case 5: Staff เลือกโครงการที่ยังไม่ตั้งค่า**

**Given:**
- User = Staff
- selectedProject = PRJ-MRTA-2024-001
- purchasedProducts = undefined

**Expected:**
- ✅ Fallback: แสดงทั้งหมด 9 ตัว
- ✅ Dropdown enabled
- ✅ ไม่มี helper text พิเศษ

---

## 💾 **Implementation Files**

### **1. Type Definitions**

**File:** `/types/index.ts`

```typescript
export interface Project {
  // ... existing fields
  purchasedProducts?: string[]; // 🆕 รายการผลิตภัณฑ์ที่ซื้อ
}
```

---

### **2. Mock Data**

**File:** `/lib/mockData/projects.ts`

```typescript
import { COMMON_BUNDLES, randomProducts } from './products';

export const csvProjects: Project[] = [
  {
    id: 'proj-csv-003',
    projectCode: 'D26-0003',
    purchasedProducts: ['e-saraban'] // 1 ตัว → auto-select
  },
  {
    id: 'proj-csv-008',
    projectCode: 'D26-0009',
    purchasedProducts: ['e-payslip', 'e-maintenance'] // 2 ตัว
  },
  {
    id: 'proj-csv-002',
    projectCode: 'D26-0002',
    purchasedProducts: COMMON_BUNDLES.FULL_SUITE // 9 ตัว
  },
  {
    id: 'proj-csv-005',
    projectCode: 'D26-0006',
    purchasedProducts: randomProducts(2, 4) // สุ่ม 2-4 ตัว
  }
];
```

---

### **3. Product Helpers**

**File:** `/lib/mockData/products.ts`

```typescript
// ผลิตภัณฑ์ทั้งหมด
export const ALL_PRODUCTS: ProductInfo[] = [
  { value: 'asset-management', label: 'Asset Management', ... },
  { value: 'e-booking', label: 'e-Booking', ... },
  // ... 7 ตัวอื่น
];

// ชุดผลิตภัณฑ์พร้อมใช้
export const COMMON_BUNDLES = {
  FULL_SUITE: ['e-saraban', 'e-dms', ...], // 9 ตัว
  HR_PACKAGE: ['e-payslip', 'e-meeting', 'e-form'],
  DOCUMENT_PACKAGE: ['e-saraban', 'e-dms', 'e-form'],
  FACILITY_PACKAGE: ['e-booking', 'e-maintenance', 'asset-management'],
  STARTER_PACKAGE: ['e-saraban', 'e-dms']
};

// สุ่มผลิตภัณฑ์
export function randomProducts(min: number, max: number): string[];
```

---

### **4. Component Logic**

**File:** `/components/CreateTicketPage.tsx`

```typescript
// 🎯 Dynamic Product List
const availableProducts = (() => {
  // Customer: แสดงทั้งหมด
  if (!canCreateForCustomer) return ALL_PRODUCTS;
  
  // Staff: ยังไม่เลือกโครงการ
  if (!selectedProject) return ALL_PRODUCTS;
  
  // Filter ตามที่โครงการซื้อ
  if (selectedProject.purchasedProducts?.length > 0) {
    return ALL_PRODUCTS.filter(p => 
      selectedProject.purchasedProducts!.includes(p.value)
    );
  }
  
  // Fallback
  return ALL_PRODUCTS;
})();

// 🎯 Auto-select ถ้ามี 1 ตัว
useEffect(() => {
  if (canCreateForCustomer && selectedProject && availableProducts.length === 1) {
    setSelectedProduct(availableProducts[0].value);
  }
}, [selectedProject, availableProducts, canCreateForCustomer]);
```

---

## 🔮 **Future Enhancements (Phase 4 - Admin Settings)**

### **Admin UI สำหรับจัดการผลิตภัณฑ์**

```
┌─────────────────────────────────────────┐
│ 🔧 จัดการโครงการ: D26-0009             │
├─────────────────────────────────────────┤
│ โครงการ: ระบบพัฒนาบุคลากร               │
│                                         │
│ ✅ ผลิตภัณฑ์ที่โครงการซื้อ:            │
│ ☑ e-Payslip                            │
│ ☑ e-Maintenance                        │
│ ☐ e-DMS                                │
│ ☐ e-Form                               │
│ ☐ e-Meeting                            │
│ ☐ e-Saraban                            │
│ ☐ Asset Management                     │
│ ☐ e-Booking                            │
│ ☐ Project Tracking                     │
│                                         │
│ [บันทึก] [ยกเลิก]                      │
└─────────────────────────────────────────┘
```

**Features:**
- ✅ Checkbox เลือกผลิตภัณฑ์ที่ซื้อ
- ✅ บันทึกลง Database/Mock Data
- ✅ แก้ไขได้ภายหลัง

**Note:** ยังไม่ implement ในเวอร์ชันนี้ (ใช้ mock data ก่อน)

---

## 📌 **Key Benefits**

| ประเด็น | ก่อนหน้า | ตอนนี้ |
|---------|----------|--------|
| **จำนวนตัวเลือก** | 9 ตัว ทุกเคส | 1-9 ตัว ตามโครงการ |
| **ความแม่นยำ** | ❌ อาจเลือกผิด | ✅ เลือกได้แม่นยำ |
| **UX** | ❌ ต้องจำ/ตรวจสอบ | ✅ มีข้อมูลช่วย |
| **Auto-select** | ❌ ไม่มี | ✅ มี (ถ้า 1 ตัว) |
| **Helper Text** | ❌ ไม่มี | ✅ มี (แสดงรายชื่อ) |

---

## 🚨 **Important Notes**

1. **Customer ไม่ได้รับผลกระทบ:**
   - ลูกค้าแจ้งเคสเองยังแสดงทั้งหมด 9 ตัว (เพราะไม่มีโครงการ)

2. **Fallback Strategy:**
   - ถ้าโครงการไม่มีข้อมูล → แสดงทั้งหมด (ไม่ block การทำงาน)

3. **Auto-select Behavior:**
   - ใช้ `useEffect` เพื่อ auto-select เมื่อเปลี่ยนโครงการ
   - Disable dropdown เพื่อป้องกันการเปลี่ยนค่าโดยไม่ตั้งใจ

4. **Performance:**
   - ใช้ `useMemo` หรือ function ธรรมดา (ไม่มี heavy calculation)
   - Filter ทำครั้งเดียวเมื่อเปลี่ยนโครงการ

---

## 📚 **Related Documentation**

- [PROJECT_SELECTION_FEATURES.md](/docs/PROJECT_SELECTION_FEATURES.md) - โครงสร้างโครงการและองค์กร
- [CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md](/docs/CUSTOMER_REGISTRATION_AND_TIER1_TRIAGE_WORKFLOW.md) - Workflow การแจ้งเคส
- [COMMON_COMPONENTS_GUIDE.md](/docs/COMMON_COMPONENTS_GUIDE.md) - Component ที่ใช้ร่วมกัน

---

## 📝 **Changelog**

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-23 | Initial release: Product filtering + auto-select + helper text |

---

**End of Document**
