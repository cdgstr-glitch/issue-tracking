# 🎨 อัพเดตชื่อแบรนด์: Application Support Center

> **วันที่:** 14 มกราคม 2026  
> **การเปลี่ยนแปลง:** เปลี่ยนชื่อจาก "Issue Tracking" เป็น "Application Support Center" ในส่วนที่ลูกค้าเห็น  
> **หลักการ:** ส่วน Customer-facing ใช้ชื่อใหม่, ส่วน Internal (Staff/Tier/Admin) คงชื่อเดิม

---

## 🎯 หลักการเปลี่ยนแปลง

### **ส่วนที่เปลี่ยน (Customer-facing):**
- ✅ หน้า Login
- ✅ หน้า Register  
- ✅ หน้า Forgot Password
- ✅ หน้า Customer Home
- ✅ หน้า Customer FAQ
- ✅ **อีเมลที่ส่งให้ลูกค้า** (Customer Email)
- ✅ Footer หน้าลูกค้า

### **ส่วนที่ไม่เปลี่ยน (Internal):**
- ❌ Header/Sidebar Admin/Staff
- ❌ Staff Home Page
- ❌ **อีเมลภายใน** (Tier1/Staff/Admin Email)
- ❌ Figma Imports (ไม่แก้ไขไฟล์ import)

---

## 📋 รายการไฟล์ที่แก้ไข

### **1. อีเมลส่งถึงลูกค้า**

#### **File:** `/components/CreateTicketPage.tsx`

**Line 918** - Customer Email Header:
```typescript
// ❌ Before
<h2 className="text-blue-600">CDGS Issue Tracking Platform</h2>

// ✅ After
<h2 className="text-blue-600">CDGS Application Support Center</h2>
```

**Line 1013** - Customer Email Footer:
```typescript
// ❌ Before
<p className="mt-1">© 2024 CDGS Issue Tracking Platform. All rights reserved.</p>

// ✅ After
<p className="mt-1">© 2024 CDGS Application Support Center. All rights reserved.</p>
```

**หมายเหตุ:**  
- ✅ อีเมล Customer (**Line 918, 1013**) → เปลี่ยนแล้ว
- ❌ อีเมล Tier1 (**Line 1051, 1188**) → ไม่เปลี่ยน (Internal)
- ❌ อีเมล Staff (**Line 1227, 1360**) → ไม่เปลี่ยน (Internal)

---

### **2. EmailPreviewModal**

#### **File:** `/components/EmailPreviewModal.tsx`

**Line 100** - Customer Email Preview Footer:
```typescript
// ❌ Before
<p className="mt-1">© 2024 CDGS Issue Tracking Platform. All rights reserved.</p>

// ✅ After
<p className="mt-1">© 2024 CDGS Application Support Center. All rights reserved.</p>
```

**หมายเหตุ:**  
- ✅ Type: 'customer' (**Line 100**) → เปลี่ยนแล้ว
- ❌ Type: 'staff' (**Line 199**) → ไม่เปลี่ยน (Internal)
- ❌ Type: 'assignment' (**Line 299**) → ไม่เปลี่ยน (Internal)
- ❌ Type: 'reminder' (**Line 399**) → ไม่เปลี่ยน (Internal)

---

### **3. หน้า Customer**

#### **File:** `/components/CustomerHomePage.tsx`

**Line 269** - Footer:
```typescript
// ❌ Before
<p>© 2024 CDGS Issue Tracking Platform. สงวนลิขสิทธิ์</p>

// ✅ After
<p>© 2024 CDGS Application Support Center. สงวนลิขสิทธิ์</p>
```

---

#### **File:** `/components/CustomerFAQPage.tsx`

**Line 514** - Footer:
```typescript
// ❌ Before
<p>© 2024 CDGS Issue Tracking Platform. สงวนลิขสิทธิ์</p>

// ✅ After
<p>© 2024 CDGS Application Support Center. สงวนลิขสิทธิ์</p>
```

---

### **4. หน้า Authentication**

#### **File:** `/components/LoginPage.tsx`

**Line 337** - Footer Subtitle:
```typescript
// ❌ Before
<p className="text-sm text-[#6a7282]">Enterprise Issue Tracking & Support System</p>

// ✅ After
<p className="text-sm text-[#6a7282]">Application Support Center</p>
```

---

#### **File:** `/components/ForgotPasswordPage.tsx`

**Line 240** - Footer Subtitle:
```typescript
// ❌ Before
<p className="text-sm text-[#6a7282]">Enterprise Issue Tracking & Support System</p>

// ✅ After
<p className="text-sm text-[#6a7282]">Application Support Center</p>
```

---

#### **File:** `/components/RegisterPage.tsx`

**Line 460** - Footer Subtitle:
```typescript
// ❌ Before
<p className="text-sm text-[#6a7282]">Enterprise Issue Tracking & Support System</p>

// ✅ After
<p className="text-sm text-[#6a7282]">Application Support Center</p>
```

---

## 📊 สรุปการเปลี่ยนแปลง

| # | ไฟล์ | บรรทัด | ส่วน | การเปลี่ยนแปลง | สถานะ |
|---|------|--------|------|----------------|-------|
| 1 | CreateTicketPage.tsx | 918 | Customer Email Header | "Application Support Center" | ✅ |
| 2 | CreateTicketPage.tsx | 1013 | Customer Email Footer | "Application Support Center" | ✅ |
| 3 | EmailPreviewModal.tsx | 100 | Customer Email Preview | "Application Support Center" | ✅ |
| 4 | CustomerHomePage.tsx | 269 | Footer | "Application Support Center" | ✅ |
| 5 | CustomerFAQPage.tsx | 514 | Footer | "Application Support Center" | ✅ |
| 6 | LoginPage.tsx | 337 | Footer Subtitle | "Application Support Center" | ✅ |
| 7 | ForgotPasswordPage.tsx | 240 | Footer Subtitle | "Application Support Center" | ✅ |
| 8 | RegisterPage.tsx | 460 | Footer Subtitle | "Application Support Center" | ✅ |
| **รวม** | **6 ไฟล์** | **8 ตำแหน่ง** | **Customer-facing** | **ทั้งหมด** | **✅** |

---

## ❌ ส่วนที่ไม่เปลี่ยน (Internal - ยังคงใช้ "Issue Tracking")

| ไฟล์ | บรรทัด | ส่วน | เหตุผล |
|------|--------|------|--------|
| CreateTicketPage.tsx | 1051 | Tier1 Email Header | Internal - ส่งให้ Tier1 |
| CreateTicketPage.tsx | 1188 | Tier1 Email Footer | Internal - ส่งให้ Tier1 |
| CreateTicketPage.tsx | 1227 | Staff Email Header | Internal - ส่งให้ Staff |
| CreateTicketPage.tsx | 1360 | Staff Email Footer | Internal - ส่งให้ Staff |
| EmailPreviewModal.tsx | 199 | Staff Email Preview | Internal - Staff เห็น |
| EmailPreviewModal.tsx | 299 | Assignment Email | Internal - Staff เห็น |
| EmailPreviewModal.tsx | 399 | Reminder Email | Internal - Staff เห็น |
| Header.tsx | 212 | Admin Header | Internal - Admin เห็น |
| Sidebar.tsx | 205 | Admin Sidebar | Internal - Admin เห็น |
| StaffHomePage.tsx | 41, 157, 292 | Staff Pages | Internal - Staff เห็น |
| imports/CdgsHelpDeskPlatformUiUxDesign.tsx | 258, 276 | Figma Import | ไม่แก้ไขไฟล์ import |

---

## 🧪 การทดสอบ

### **Test 1: หน้า Login**
```bash
1. เปิดหน้า Login
2. ตรวจสอบ Footer

Expected:
- Line 1: "© 2025 CDGS. All rights reserved."
- Line 2: "Application Support Center" ✅
```

---

### **Test 2: อีเมลลูกค้า (CreateTicketPage)**
```bash
1. Login: customer1 / customer1123
2. Navigate: /create
3. Submit Form → กดดูตัวอย่างอีเมลส่งหาลูกค้า

Expected:
- Header: "CDGS Application Support Center" ✅
- Footer: "© 2024 CDGS Application Support Center. All rights reserved." ✅
```

---

### **Test 3: อีเมล Tier1 (Internal - ไม่เปลี่ยน)**
```bash
1. Login: staff / staff123
2. Navigate: /create
3. กดดูตัวอย่างอีเมลส่งหา Tier 1

Expected:
- Header: "CDGS Issue Tracking Platform" ✅ (ไม่เปลี่ยน)
- Footer: "© 2024 CDGS. Internal Use Only." ✅
```

---

### **Test 4: EmailPreviewModal (Customer)**
```bash
1. Login: customer1 / customer1123
2. Navigate: /track/CDGS-2024-001
3. Reply to ticket → กด "ตัวอย่างอีเมลแจ้งลูกค้า"

Expected:
- Footer: "© 2024 CDGS Application Support Center. All rights reserved." ✅
```

---

### **Test 5: EmailPreviewModal (Staff - ไม่เปลี่ยน)**
```bash
1. Login: customer1 / customer1123
2. Navigate: /track/CDGS-2024-001
3. Reply to ticket → กด "ตัวอย่างอีเมลแจ้งเจ้าหน้าที่"

Expected:
- Footer: "อีเมลแจ้งเตือนอัตโนมัติจากระบบ CDGS Issue Tracking Platform" ✅ (ไม่เปลี่ยน)
```

---

### **Test 6: Customer Home Page**
```bash
1. Login: customer1 / customer1123
2. Navigate: /
3. Scroll to Footer

Expected:
- Footer: "© 2024 CDGS Application Support Center. สงวนลิขสิทธิ์" ✅
```

---

### **Test 7: Customer FAQ Page**
```bash
1. Login: customer1 / customer1123
2. Navigate: /faq
3. Scroll to Footer

Expected:
- Footer: "© 2024 CDGS Application Support Center. สงวนลิขสิทธิ์" ✅
```

---

## 📝 หมายเหตุสำหรับนักพัฒนา

### **กฎการตั้งชื่อ:**

#### **Customer-facing:**
```typescript
// ✅ ใช้ชื่อใหม่
"CDGS Application Support Center"
"Application Support Center"
```

#### **Internal (Staff/Tier/Admin):**
```typescript
// ❌ ยังคงใช้ชื่อเดิม
"CDGS Issue Tracking Platform"
"CDGS Issue Tracking"
```

---

### **การเพิ่มฟีเจอร์ใหม่:**

#### **อีเมลใหม่ (Customer-facing):**
```typescript
// ✅ ใช้ชื่อใหม่
<h2 className="text-blue-600">CDGS Application Support Center</h2>
<p className="mt-1">© 2024 CDGS Application Support Center. All rights reserved.</p>
```

#### **อีเมลใหม่ (Internal):**
```typescript
// ❌ ใช้ชื่อเดิม
<h2 className="text-blue-600">CDGS Issue Tracking Platform</h2>
<p className="mt-1">© 2024 CDGS Issue Tracking Platform. Internal Use Only.</p>
```

---

### **หน้าใหม่ (Customer):**
```typescript
// ✅ Footer
<p>© 2024 CDGS Application Support Center. สงวนลิขสิทธิ์</p>
```

---

## 🎨 ตัวอย่างการใช้งาน

### **Customer Email Template:**
```typescript
// ✅ ถูกต้อง
<div className="border-b pb-4">
  <h2 className="text-blue-600">CDGS Application Support Center</h2>
</div>

// ... content ...

<div className="border-t pt-4 text-xs text-gray-500 text-center">
  <p>อีเมลนี้ถูกส่งอัตโนมัติ กรุณาอย่าตอบกลับที่อีเมลนี้</p>
  <p className="mt-1">© 2024 CDGS Application Support Center. All rights reserved.</p>
</div>
```

---

### **Internal Email Template:**
```typescript
// ❌ ใช้ชื่อเดิม (ไม่เปลี่ยน)
<div className="border-b pb-4">
  <h2 className="text-blue-600">CDGS Issue Tracking Platform</h2>
  <p className="text-sm text-gray-600 mt-1">Internal Notification - Tier 1 Support Team</p>
</div>

// ... content ...

<div className="border-t pt-4 text-center text-xs text-gray-500">
  <p>This is an automated notification from CDGS Issue Tracking Platform</p>
  <p className="mt-1">© 2024 CDGS. Internal Use Only.</p>
</div>
```

---

## 🚨 ข้อควรระวัง

### **อีเมล:**
1. ✅ อีเมล**ส่งให้ลูกค้า** → ใช้ "Application Support Center"
2. ❌ อีเมล**ส่งให้ Tier1/Staff** → ใช้ "Issue Tracking Platform" (ไม่เปลี่ยน)

### **หน้าเว็บ:**
1. ✅ หน้า**ลูกค้า** (Login, Register, FAQ, Home) → ใช้ "Application Support Center"
2. ❌ หน้า**Staff/Admin** (Dashboard, Sidebar, Header) → ใช้ "Issue Tracking" (ไม่เปลี่ยน)

### **Figma Imports:**
- ❌ **ห้าม**แก้ไขไฟล์ `/imports/*.tsx`
- เหตุผล: เป็นไฟล์ที่ import จาก Figma โดยตรง

---

## ✅ Checklist

### **Customer-facing:**
- ✅ LoginPage - Footer
- ✅ RegisterPage - Footer
- ✅ ForgotPasswordPage - Footer
- ✅ CustomerHomePage - Footer
- ✅ CustomerFAQPage - Footer
- ✅ CreateTicketPage - Customer Email
- ✅ EmailPreviewModal - Customer Type

### **Internal (ไม่เปลี่ยน):**
- ✅ CreateTicketPage - Tier1 Email (ยังคง "Issue Tracking")
- ✅ CreateTicketPage - Staff Email (ยังคง "Issue Tracking")
- ✅ EmailPreviewModal - Staff Type (ยังคง "Issue Tracking")
- ✅ Header/Sidebar - Admin (ยังคง "Issue Tracking")
- ✅ StaffHomePage (ยังคง "Issue Tracking")

---

## 🎯 สรุป

### **Before:**
| ส่วน | ชื่อเดิม |
|------|----------|
| Customer-facing | "Issue Tracking Platform" ❌ |
| Internal | "Issue Tracking Platform" ✅ |

### **After:**
| ส่วน | ชื่อใหม่ |
|------|----------|
| Customer-facing | "Application Support Center" ✅ |
| Internal | "Issue Tracking Platform" ✅ (ไม่เปลี่ยน) |

---

## 📚 เอกสารอ้างอิง

| เอกสาร | เนื้อหา |
|--------|---------|
| `/EMAIL_MOCK_DATA_FIX.md` | การแก้ไข Mock Data อีเมล |
| `/EMAIL_VALIDATION_COMPLETE.md` | ยืนยันอีเมล Mock Data |
| `/BRANDING_UPDATE_APPLICATION_SUPPORT_CENTER.md` | เอกสารนี้ - การเปลี่ยนแบรนด์ |

---

**Updated:** 14 มกราคม 2026, 19:00 น.  
**Status:** ✅ **เปลี่ยนแบรนด์สำเร็จ (Customer-facing Only)**

---

## 💡 Tips for Developers

### **ตรวจสอบว่าเป็น Customer-facing หรือ Internal:**

```typescript
// Customer-facing = ลูกค้าเห็น
// - หน้า Login/Register/FAQ/Home (Customer)
// - อีเมลส่งให้ลูกค้า
// → ใช้ "Application Support Center"

// Internal = Staff/Tier/Admin เห็น
// - หน้า Dashboard/Sidebar/Header
// - อีเมลส่งให้ Tier1/Staff/Admin
// → ใช้ "Issue Tracking Platform"
```

---

**Completed:** 14 มกราคม 2026, 19:00 น.
