# 🎫 Customer Registration & Tier1 Triage Workflow

**วันที่อัพเดท:** 21 มกราคม 2026  
**สถานะ:** 📋 เอกสารออกแบบ (รอการพัฒนา)  
**แนวทาง:** Option A - Quick Registration + Magic Link Authentication

---

## 📋 สารบัญ

1. [ภาพรวมระบบ](#ภาพรวมระบบ)
2. [Customer Authentication Flow](#customer-authentication-flow)
3. [Tier1 Triage Workflow](#tier1-triage-workflow)
4. [Data Model](#data-model)
5. [Email Notification System](#email-notification-system)
6. [UI/UX Specifications](#uiux-specifications)

---

## 🎯 ภาพรวมระบบ

### **ปัญหาที่แก้ไข:**

**ปัจจุบัน:**
- ❌ Customer ต้องลงทะเบียนด้วยข้อมูลเยอะ (ชื่อ, อีเมล, รหัสผ่าน, เบอร์โทร, หน่วยงาน, ...)
- ❌ UX ซับซ้อน ทำให้ลูกค้าไม่อยากแจ้งเคส
- ❌ ไม่ตรงมาตรฐานสากล (Zendesk, Freshdesk, Jira Service Desk)

**หลังอัพเดท:**
- ✅ **Quick Registration:** กรอกแค่ชื่อ + อีเมล (2 ฟิลด์)
- ✅ **Passwordless Authentication:** ใช้ Magic Link (ไม่ต้องจำรหัสผ่าน)
- ✅ **Progressive Profiling:** กรอกข้อมูลเพิ่มเติมทีหลังได้
- ✅ **Tier1 Triage:** Tier1 กรอกข้อมูลที่จำเป็น (โครงการ, Incident Type, ความสำคัญ) ตอนรับเคส

---

## 🔐 Customer Authentication Flow

### **SCENARIO A: ลูกค้าใหม่ (แจ้งเคสครั้งแรก)**

```
┌─ STEP 1: Landing Page (LoginPage) ─────────────────┐
│                                                    │
│  Application Support Center                       │
│                                                    │
│  👥 สำหรับลูกค้า                                   │
│  ┌──────────────────────────────────────────────┐  │
│  │ [📝 ลงทะเบียนและแจ้งเคส]                     │  │
│  │ → กรอกแค่ชื่อ + อีเมล แล้วแจ้งเคสเลย          │  │
│  │                                              │  │
│  │ [🔑 เข้าสู่ระบบด้วยอีเมล]                    │  │
│  │ → ส่ง Magic Link เข้าหน้าติดตามเคส           │  │
│  └──────────────────────────────────────────────┘  │
│                                                    │
│  👨‍💼 สำหรับเจ้าหน้าที่                             │
│  ┌──────────────────────────────────────────────┐  │
│  │ Username: [_______________]                  │  │
│  │ Password: [_______________]                  │  │
│  │          [เข้าสู่ระบบ]                       │  │
│  │ [ดูบัญชีทดสอบ]                               │  │
│  └──────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────┘

┌─ STEP 2: Quick Registration Dialog ───────────────┐
│ คลิก "ลงทะเบียนและแจ้งเคส"                        │
│                                                    │
│ ┌────────────────────────────────────────────┐     │
│ │ 📝 ลงทะเบียนและแจ้งเคส                     │     │
│ │────────────────────────────────────────────│     │
│ │                                            │     │
│ │ ชื่อ-นามสกุล: * [_______________________] │     │
│ │ อีเมล:        * [_______________________] │     │
│ │                                            │     │
│ │ เราจะส่งหมายเลขเคสและอัพเดทสถานะ           │     │
│ │ ไปที่อีเมลของคุณ                           │     │
│ │                                            │     │
│ │      [ยกเลิก]  [ดำเนินการต่อ]             │     │
│ └────────────────────────────────────────────┘     │
└────────────────────────────────────────────────────┘

┌─ STEP 3: Create Ticket Form ──────────────────────┐
│ Header: 👤 สวัสดี, ศิริพร อารีมิตร                │
│                                                    │
│ แจ้งปัญหา                                          │
│                                                    │
│ หัวเรื่อง: * [________________________________]   │
│                                                    │
│ รายละเอียด: *                                      │
│ [_______________________________________________]  │
│ [_______________________________________________]  │
│                                                    │
│ หมวดหมู่: * [เลือกหมวดหมู่ ▼]                     │
│            - บัญชีและการเข้าระบบ                  │
│            - ระบบขัดข้อง                           │
│            - คำถามการใช้งาน                        │
│            - ฟีเจอร์ใหม่                           │
│            - อื่นๆ                                 │
│                                                    │
│ ผลิตภัณฑ์/บริการ: [เลือกผลิตภัณฑ์ ▼] (ไม่บังคับ)  │
│                                                    │
│ แนบไฟล์: [📎 เลือกไฟล์] (ไม่บังคับ)               │
│                                                    │
│ ── ข้อมูลเพิ่มเติม (ไม่บังคับ) ──                  │
│                                                    │
│ เบอร์โทรศัพท์: [_____________________________]    │
│ หน่วยงาน:      [_____________________________]    │
│                                                    │
│           [แจ้งเคส]                                │
└────────────────────────────────────────────────────┘

┌─ STEP 4: Success Page ────────────────────────────┐
│              ✅ แจ้งเคสสำเร็จ                      │
│                                                    │
│  เคส #TK-240121-0001 ถูกสร้างแล้ว                 │
│                                                    │
│  เราได้ส่งรายละเอียดไปที่:                         │
│  siriporn@example.com                              │
│                                                    │
│  คุณสามารถติดตามสถานะได้ที่อีเมลของคุณ            │
│  หรือคลิกปุ่มด้านล่าง                              │
│                                                    │
│    [ติดตามเคสของฉัน]  [แจ้งเคสใหม่]                │
└────────────────────────────────────────────────────┘

┌─ STEP 5: Track Tickets Page ──────────────────────┐
│ Header: 👤 ศิริพร อารีมิตร [ออกจากระบบ]          │
│                                                    │
│ เคสของฉัน (1)                   [+ แจ้งเคสใหม่]   │
│                                                    │
│ ┌────────────────────────────────────────────┐     │
│ │ #TK-240121-0001  [🔵 รอดำเนินการ]         │     │
│ │ ปัญหาระบบ Login ไม่ได้                    │     │
│ │ สร้างเมื่อ: 21 ม.ค. 2026 14:30            │     │
│ │                                            │     │
│ │          [ดูรายละเอียด]                    │     │
│ └────────────────────────────────────────────┘     │
└────────────────────────────────────────────────────┘
```

---

### **SCENARIO B: ลูกค้าเก่า (กลับมาหลายวันผ่านไป)**

```
┌─ METHOD 1: Magic Link Login ──────────────────────┐
│ Landing Page → คลิก "เข้าสู่ระบบด้วยอีเมล"        │
│                                                    │
│ ┌────────────────────────────────────────────┐     │
│ │ 🔑 เข้าสู่ระบบด้วยอีเมล                    │     │
│ │────────────────────────────────────────────│     │
│ │                                            │     │
│ │ อีเมล: * [___________________________]    │     │
│ │                                            │     │
│ │ เราจะส่งลิงก์เข้าระบบไปที่อีเมลของคุณ      │     │
│ │                                            │     │
│ │      [ยกเลิก]  [ส่งลิงก์]                  │     │
│ └────────────────────────────────────────────┘     │
│                                                    │
│ ↓ ส่งอีเมล                                         │
│                                                    │
│ ┌────────────────────────────────────────────┐     │
│ │ หัวข้อ: เข้าสู่ระบบ CDGS Support          │     │
│ │                                            │     │
│ │ สวัสดี คุณศิริพร อารีมิตร                  │     │
│ │                                            │     │
│ │ [เข้าสู่ระบบ] ← คลิกที่นี่                 │     │
│ │                                            │     │
│ │ หรือคัดลอกลิงก์:                           │     │
│ │ https://support.cdgs.co.th/magic/abc123    │     │
│ │                                            │     │
│ │ (ลิงก์จะหมดอายุใน 30 นาที)                │     │
│ └────────────────────────────────────────────┘     │
│                                                    │
│ ↓ คลิกลิงก์                                        │
│                                                    │
│ → เข้าหน้า Track Tickets Page (Auto-login) ✅     │
└────────────────────────────────────────────────────┘

┌─ METHOD 2: Email Notification Link ───────────────┐
│ อีเมลแจ้งเตือนเมื่อมีอัพเดท:                      │
│                                                    │
│ ┌────────────────────────────────────────────┐     │
│ │ หัวข้อ: [CDGS] มีการอัพเดทเคส #TK-xxx     │     │
│ │                                            │     │
│ │ 💬 ความคิดเห็นใหม่จาก วรรณภา แซ่ด่าง      │     │
│ │ "เราได้ตรวจสอบปัญหาแล้ว..."               │     │
│ │                                            │     │
│ │ [ดูรายละเอียดเคส] ← Magic Link             │     │
│ └────────────────────────────────────────────┘     │
│                                                    │
│ ↓ คลิกลิงก์                                        │
│                                                    │
│ → เข้าหน้ารายละเอียดเคสเลย (Auto-login) ✅        │
└────────────────────────────────────────────────────┘
```

---

## ⚙️ Tier1 Triage Workflow

### **ปัญหาที่พบ:**

เมื่อ Customer แจ้งเคสผ่านระบบโดยตรง จะขาดข้อมูลสำคัญที่จำเป็นสำหรับการดำเนินงาน:

| ฟิลด์ | Customer กรอก | Staff กรอก | Tier1 ต้องเติม |
|------|--------------|-----------|---------------|
| **โครงการ (Project)** | ❌ ไม่มีให้เลือก | ✅ Required | ✅ **ต้องเติม** |
| **Incident Type** | ❌ ไม่มีให้เลือก | ✅ เลือก/Auto | ✅ **ต้องเติม** |
| **ความสำคัญ (Priority)** | ❌ ไม่รู้เรื่อง | ✅ เลือก | ✅ **ต้องตรวจสอบ/ปรับ** |
| **SLA** | ❌ N/A | ✅ Auto-calculate | ✅ **Auto-calculate หลังเติมข้อมูล** |

---

### **การแก้ไข: Tier1 Triage Modal**

```
┌─ Tier1 Dashboard > รอดำเนินการ ──────────────────┐
│                                                  │
│ เคสรอดำเนินการ (5)                               │
│                                                  │
│ ┌──────────────────────────────────────────┐     │
│ │ #TK-240121-0001  [🔵 new]               │     │
│ │ ปัญหาระบบ Login ไม่ได้                  │     │
│ │ ลูกค้า: ศิริพร อารีมิตร                 │     │
│ │ ⚠️ ข้อมูลไม่ครบ: ต้องกรอกโครงการ        │     │
│ │                                          │     │
│ │          [รับเคส]                        │     │
│ └──────────────────────────────────────────┘     │
└──────────────────────────────────────────────────┘

↓ คลิก [รับเคส]

┌─ Triage Modal (เฉพาะเคสจาก Customer) ───────────┐
│                                                  │
│ รับเคสและกำหนดข้อมูล                             │
│                                                  │
│ 📋 #TK-240121-0001                               │
│ ปัญหาระบบ Login ไม่ได้                          │
│ ลูกค้า: ศิริพร อารีมิตร (siriporn@example.com)  │
│ หมวดหมู่: บัญชีและการเข้าระบบ                   │
│                                                  │
│ ── กรุณาเติมข้อมูลเพื่อรับเคส ──                 │
│                                                  │
│ โครงการ: * [เลือกโครงการ ▼]                     │
│             ┌────────────────────────────────┐   │
│             │ HRMS System                    │   │
│             │ ERP System                     │   │
│             │ CRM Platform                   │   │
│             │ Asset Management               │   │
│             │ e-Booking System               │   │
│             │ General Support                │   │
│             └────────────────────────────────┘   │
│                                                  │
│ ประเภท Incident: * [Auto: Incident ▼]           │
│                     ┌────────────────────────┐   │
│                     │ Incident               │   │
│                     │ Service Request        │   │
│                     │ Security Incident      │   │
│                     └────────────────────────┘   │
│                                                  │
│ ความสำคัญ: [Auto: ปกติ ▼] (ปรับได้)             │
│             ┌────────────────────────────────┐   │
│             │ 🔴 ด่วนมาก (Critical)          │   │
│             │ 🟠 ด่วน (High)                │   │
│             │ 🟡 ปกติ (Medium) ✓            │   │
│             │ 🟢 น้อย (Low)                 │   │
│             └────────────────────────────────┘   │
│                                                  │
│ 💡 SLA: 4 ชั่วโมง (คำนวณจาก Priority + Type)    │
│                                                  │
│ หมายเหตุภายใน: (ไม่บังคับ)                       │
│ [_____________________________________________]  │
│ [_____________________________________________]  │
│                                                  │
│        [ยกเลิก]  [รับเคสและดำเนินการ]           │
└──────────────────────────────────────────────────┘

↓ กดปุ่ม [รับเคสและดำเนินการ]

┌─ Result ─────────────────────────────────────────┐
│ ✅ รับเคสสำเร็จ                                   │
│                                                  │
│ Ticket Updated:                                  │
│ • status: new → in_progress                      │
│ • assignedTo: วรรณภา แซ่ด่าง (user-002)         │
│ • projectId: "proj-hrms"                         │
│ • projectName: "HRMS System"                     │
│ • type: "incident"                               │
│ • priority: "medium"                             │
│ • sla: 4 hours                                   │
│ • dueDate: 21 ม.ค. 2026 18:30                    │
│                                                  │
│ Email Sent to Customer:                          │
│ • "เคสของคุณได้รับการมอบหมายแล้ว"                │
│ • "ผู้รับผิดชอบ: วรรณภา แซ่ด่าง"                 │
│                                                  │
│ → Redirect to Ticket Detail Page                │
└──────────────────────────────────────────────────┘
```

---

### **กฎการแสดง Triage Modal:**

| สถานการณ์ | Triage Modal | เหตุผล |
|----------|--------------|--------|
| **Customer แจ้งเคส (channel=web)** | ✅ **แสดง** | ขาดข้อมูล: Project, Type, SLA |
| **Staff ส่งงาน (channel=phone/email/line)** | ❌ **ไม่แสดง** | Staff เลือก Project ไว้แล้ว (Required) |
| **Tier1 ส่งกลับมา (status=tier1)** | ❌ **ไม่แสดง** | มีข้อมูลครบแล้ว |
| **Tier2 ส่งกลับมา (status=tier1)** | ❌ **ไม่แสดง** | มีข้อมูลครบแล้ว |

**Logic:**

```typescript
const needsTriage = (ticket: Ticket) => {
  return (
    ticket.status === 'new' &&              // เคสใหม่
    ticket.channel === 'web' &&             // มาจาก Customer
    (!ticket.projectId || !ticket.type)     // ขาดข้อมูล
  );
};
```

---

### **Smart Defaults (Auto-Suggest):**

```typescript
// 1. Auto-suggest Project จาก Category
const suggestProjectFromCategory = (category: string) => {
  const mapping = {
    'บัญชีและการเข้าระบบ': 'HRMS System',
    'ระบบขัดข้อง': 'General Support',
    'คำถามการใช้งาน': 'General Support',
    'ฟีเจอร์ใหม่': 'CRM Platform',
    // ...
  };
  return mapping[category] || null;
};

// 2. Auto-calculate Priority จาก Keywords
const calculatePriority = (title: string, description: string) => {
  const text = `${title} ${description}`.toLowerCase();
  
  if (text.includes('ด่วนมาก') || text.includes('critical') || text.includes('down')) {
    return 'critical';
  }
  if (text.includes('ด่วน') || text.includes('urgent') || text.includes('error')) {
    return 'high';
  }
  if (text.includes('ช้า') || text.includes('slow') || text.includes('minor')) {
    return 'low';
  }
  return 'medium'; // Default
};

// 3. Auto-set Type (Default: Incident)
const defaultType = 'incident';

// 4. Auto-calculate SLA
const calculateSLA = (priority: TicketPriority, type: TicketType) => {
  const slaMatrix = {
    critical: { incident: 1, service_request: 2, security_incident: 0.5 },
    high: { incident: 4, service_request: 8, security_incident: 2 },
    medium: { incident: 8, service_request: 24, security_incident: 4 },
    low: { incident: 24, service_request: 72, security_incident: 8 },
  };
  return slaMatrix[priority][type]; // hours
};
```

---

## 📊 Data Model

### **CustomerUser (ใหม่)**

```typescript
interface CustomerUser {
  id: string;
  fullName: string;          // Required (จาก Quick Registration)
  email: string;             // Required (unique)
  phone?: string;            // Optional (กรอกตอนแจ้งเคสหรือทีหลัง)
  department?: string;       // Optional (กรอกตอนแจ้งเคสหรือทีหลัง)
  role: 'customer';
  createdAt: Date;
  lastLoginAt?: Date;
  magicLinkToken?: string;   // Token สำหรับ Magic Link
  magicLinkExpiry?: Date;    // Token หมดอายุเมื่อไร
}
```

### **Ticket (อัพเดท)**

```typescript
interface Ticket {
  // ... existing fields
  
  // ✅ เพิ่ม: กรณี Customer แจ้งเคส
  needsTriage?: boolean;      // ต้องเติมข้อมูลตอน Tier1 รับเคสไหม
  triageCompletedBy?: string; // Tier1 คนที่เติมข้อมูล
  triageCompletedAt?: Date;   // เมื่อไร
  
  // ✅ เพิ่ม: SLA Tracking
  slaHours?: number;          // จำนวนชั่วโมงที่ต้องแก้ไข
  slaDueDate?: Date;          // วันที่ครบกำหนด SLA
  slaStatus?: 'on_track' | 'at_risk' | 'breached'; // สถานะ SLA
}
```

---

## 📧 Email Notification System

### **อีเมลที่ส่งให้ Customer:**

#### **1. Welcome Email (หลัง Quick Registration)**

```
Subject: ยินดีต้อนรับสู่ CDGS Application Support Center

สวัสดี คุณศิริพร อารีมิตร

ขอบคุณที่ลงทะเบียนกับ CDGS Application Support Center

คุณสามารถติดตามเคสของคุณได้ทุกเมื่อผ่านอีเมลนี้
หรือเข้าสู่ระบบผ่านลิงก์ด้านล่าง:

[เข้าสู่ระบบ]

---
CDGS Issue Tracking Platform
```

#### **2. Ticket Created Email**

```
Subject: [CDGS] เคส #TK-240121-0001 ถูกสร้างแล้ว

สวัสดี คุณศิริพร อารีมิตร

เคสของคุณถูกสร้างเรียบร้อยแล้ว

หมายเลขเคส: #TK-240121-0001
หัวเรื่อง: ปัญหาระบบ Login ไม่ได้
สถานะ: รอดำเนินการ

เราจะแจ้งให้คุณทราบเมื่อมีการอัพเดท

[ดูรายละเอียดเคส] ← Magic Link

---
CDGS Issue Tracking Platform
```

#### **3. Ticket Assigned Email**

```
Subject: [CDGS] เคส #TK-240121-0001 ได้รับการมอบหมายแล้ว

สวัสดี คุณศิริพร อารีมิตร

เคสของคุณได้รับการมอบหมายแล้ว

หมายเลขเคส: #TK-240121-0001
ผู้รับผิดชอบ: วรรณภา แซ่ด่าง
โครงการ: HRMS System
SLA: 4 ชั่วโมง (ครบกำหนด: 21 ม.ค. 2026 18:30)

[ดูรายละเอียดเคส] ← Magic Link

---
CDGS Issue Tracking Platform
```

#### **4. Comment Notification Email**

```
Subject: [CDGS] มีความคิดเห็นใหม่ในเคส #TK-240121-0001

สวัสดี คุณศิริพร อารีมิตร

💬 ความคิดเห็นใหม่จาก วรรณภา แซ่ด่าง:

"เราได้ตรวจสอบปัญหาแล้ว พบว่าเป็นปัญหาจาก
Session Timeout กรุณาลองเคลียร์ Cache แล้ว
Login ใหม่อีกครั้งครับ"

[ดูรายละเอียดเคส] ← Magic Link
[ตอบกลับ] ← Magic Link to Comment Form

---
CDGS Issue Tracking Platform
```

#### **5. Magic Link Email**

```
Subject: เข้าสู่ระบบ CDGS Support

สวัสดี คุณศิริพร อารีมิตร

คุณได้ขอลิงก์เข้าสู่ระบบ

[เข้าสู่ระบบ] ← Magic Link

หรือคัดลอกลิงก์:
https://support.cdgs.co.th/auth/magic?token=abc123&email=siriporn@example.com

⚠️ ลิงก์นี้จะหมดอายุใน 30 นาที

หากคุณไม่ได้ขอลิงก์นี้ กรุณาละเว้นอีเมลนี้

---
CDGS Issue Tracking Platform
```

---

## 🎨 UI/UX Specifications

### **Landing Page Updates:**

```tsx
// Before (เดิม)
<LoginPage>
  <StaffLoginForm />
</LoginPage>

// After (ใหม่)
<LoginPage>
  <CustomerSection>
    <QuickRegistrationButton />
    <MagicLinkLoginButton />
  </CustomerSection>
  
  <Separator />
  
  <StaffSection>
    <StaffLoginForm />
  </StaffSection>
</LoginPage>
```

### **Header Component (Customer):**

```tsx
// เมื่อ Customer login แล้ว
<Header>
  <Logo>Application Support Center</Logo>
  <UserMenu>
    <Avatar>ศิ</Avatar>
    <Dropdown>
      <DropdownItem>ศิริพร อารีมิตร</DropdownItem>
      <DropdownItem>siriporn@example.com</DropdownItem>
      <DropdownSeparator />
      <DropdownItem icon={Settings}>ตั้งค่า</DropdownItem>
      <DropdownItem icon={LogOut}>ออกจากระบบ</DropdownItem>
    </Dropdown>
  </UserMenu>
</Header>
```

### **Triage Modal Component:**

```tsx
<Dialog open={showTriageModal}>
  <DialogContent className="max-w-2xl">
    <DialogHeader>
      <DialogTitle>รับเคสและกำหนดข้อมูล</DialogTitle>
    </DialogHeader>
    
    <TicketSummary ticket={ticket} />
    
    <form onSubmit={handleTriage}>
      <Label>โครงการ *</Label>
      <Select 
        value={selectedProject}
        defaultValue={suggestedProject}
        required
      >
        {projects.map(p => <Option>{p.name}</Option>)}
      </Select>
      
      <Label>ประเภท Incident *</Label>
      <Select 
        value={incidentType}
        defaultValue="incident"
        required
      >
        <Option>Incident</Option>
        <Option>Service Request</Option>
        <Option>Security Incident</Option>
      </Select>
      
      <Label>ความสำคัญ</Label>
      <Select 
        value={priority}
        defaultValue={suggestedPriority}
      >
        <Option>ด่วนมาก (Critical)</Option>
        <Option>ด่วน (High)</Option>
        <Option>ปกติ (Medium)</Option>
        <Option>น้อย (Low)</Option>
      </Select>
      
      <Alert>
        💡 SLA: {calculatedSLA} ชั่วโมง
      </Alert>
      
      <Label>หมายเหตุภายใน</Label>
      <Textarea placeholder="(ไม่บังคับ)" />
      
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          ยกเลิก
        </Button>
        <Button type="submit">
          รับเคสและดำเนินการ
        </Button>
      </DialogFooter>
    </form>
  </DialogContent>
</Dialog>
```

---

## 🔄 Workflow Comparison

### **ก่อนอัพเดท:**

```
Customer → ❌ ลงทะเบียนซับซ้อน (7+ ฟิลด์)
        → ❌ ต้องจำรหัสผ่าน
        → แจ้งเคส (ไม่มี Project)
        → Tier1 รับเคส (ไม่มี Dialog)
        → ⚠️ ขาดข้อมูล Project → Report ไม่ถูกต้อง
```

### **หลังอัพเดท:**

```
Customer → ✅ Quick Registration (2 ฟิลด์)
        → ✅ Passwordless (Magic Link)
        → แจ้งเคส (ไม่มี Project)
        → Tier1 รับเคส → ✅ Triage Modal (กรอก Project + Type + Priority)
        → ✅ ข้อมูลครบถ้วน → Report ถูกต้อง
```

---

## 📂 ไฟล์ที่ต้องสร้าง/แก้ไข

### **สร้างใหม่:**

1. `/components/CustomerQuickRegistrationDialog.tsx`
2. `/components/CustomerMagicLinkLoginDialog.tsx`
3. `/components/CustomerTrackTicketsPage.tsx`
4. `/components/Tier1TriageModal.tsx`
5. `/lib/magicLink.ts` - Logic สร้าง/ตรวจสอบ Magic Link Token
6. `/lib/emailTemplates.ts` - Template อีเมลทั้งหมด
7. `/lib/slaCalculator.ts` - คำนวณ SLA

### **แก้ไข:**

1. `/components/LoginPage.tsx` - แยก Customer vs Staff Section
2. `/components/CreateTicketPage.tsx` - รองรับ Customer (ไม่มี Project Selector)
3. `/components/Header.tsx` - แสดงชื่อ Customer
4. `/components/TicketActions.tsx` - เพิ่ม Triage Modal Logic
5. `/contexts/AuthContext.tsx` - รองรับ Customer Authentication
6. `/types/index.ts` - เพิ่ม CustomerUser type

---

## ✅ Testing Checklist

### **Customer Flow:**

- [ ] Quick Registration ด้วยชื่อ + อีเมล
- [ ] Auto-login หลัง Registration
- [ ] สร้างเคสได้ (ไม่มี Project Selector)
- [ ] ได้รับอีเมลยืนยัน (Mock)
- [ ] ดูเคสในหน้า Track Tickets
- [ ] Logout และ Login ด้วย Magic Link
- [ ] คลิกลิงก์จากอีเมล (Auto-login)

### **Tier1 Triage:**

- [ ] เคสจาก Customer แสดง "⚠️ ข้อมูลไม่ครบ"
- [ ] คลิก "รับเคส" → เปิด Triage Modal
- [ ] Smart Defaults ทำงาน (Project, Priority)
- [ ] กรอกข้อมูลครบ → รับเคสสำเร็จ
- [ ] SLA คำนวณถูกต้อง
- [ ] ส่งอีเมลแจ้ง Customer (Mock)

### **Edge Cases:**

- [ ] Magic Link หมดอายุ
- [ ] อีเมลซ้ำ (ลงทะเบียนซ้ำ)
- [ ] Customer กรอกข้อมูลไม่ครบ
- [ ] Tier1 ยกเลิก Triage Modal

---

**เอกสารนี้อัพเดทล่าสุด:** 21 มกราคม 2026
