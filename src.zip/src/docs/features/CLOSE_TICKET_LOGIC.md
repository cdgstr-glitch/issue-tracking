# 🔐 Logic การปิดเคส (Close Ticket Logic)

> **วันที่:** 14 มกราคม 2026, 20:00 น.  
> **ปัญหา:** Tier1 เพียวๆ (อภิญญา) ไม่เห็นปุ่ม "ปิดเคส" สำหรับเคส status = 'resolved'  
> **สาเหตุ:** Code มี bug ที่ hide ปุ่มทั้งหมดเมื่อ status = 'resolved'  
> **การแก้ไข:** แก้ไข Line 82-84 ใน TicketActions.tsx

---

## 📋 สรุป Logic การปิดเคส

### **กฎทองสำหรับการปิดเคส:**

```
1️⃣ Staff แจ้งแล้วปิดเองได้เล็กๆ น้อยๆ
   ✅ เคสที่ Staff สร้างเอง (createdBy = staff.id)
   ✅ เคส status = 'new' (ยังไม่ถูกส่งให้ Tier)
   ✅ เลือก "แก้ไขและปิดเคส" ตั้งแต่ตอนสร้าง

2️⃣ Tier1 เพียวๆ = แกนหลักในการปิดเคส
   ✅ สามารถปิดเคสใดๆ ที่ status = 'pending_closure'
   ✅ สามารถปิดเคสใดๆ ที่ status = 'resolved'
   ❌ ไม่ต้องเช็คว่า assigned ให้ตัวเองหรือไม่

3️⃣ Tier1 + บทบาทอื่น = แกนหลักในการปิดเคส
   ✅ ถ้ามี 'tier1' ใน roles array → ปิดได้เหมือน Tier1 เพียวๆ
   ✅ เช่น: Admin + Tier1, Staff + Tier1, Tier1 + Tier2
   ✅ สามารถปิดเคส 'pending_closure' และ 'resolved'
```

---

## 🔧 การแก้ไข Bug

### **ปัญหาเดิม (Before Fix):**

**File:** `/components/TicketActions.tsx` (Line 82-84)

```typescript
// ❌ Bug: Hide ปุ่มทั้งหมดเมื่อ status = 'closed' หรือ 'resolved'
if (ticket.status === 'closed' || ticket.status === 'resolved') {
  return null; // ไม่แสดงปุ่ม Action เลย
}
```

**ผลกระทบ:**
- ❌ เคส status = 'resolved' ไม่แสดงปุ่มใดๆ เลย
- ❌ Tier1 ไม่สามารถปิดเคสที่แก้ไขเสร็จแล้ว (resolved)

---

### **การแก้ไข (After Fix):**

**File:** `/components/TicketActions.tsx` (Line 82-84)

```typescript
// ✅ Fixed: Hide ปุ่มเฉพาะ status = 'closed' เท่านั้น
if (ticket.status === 'closed') {
  return null; // ไม่แสดงปุ่ม Action เลย
}
```

**ผลลัพธ์:**
- ✅ เคส status = 'closed' → ไม่แสดงปุ่มใดๆ (ถูกต้อง)
- ✅ เคส status = 'resolved' → แสดงปุ่ม "ปิดเคส" (Tier1 ปิดได้)

---

## 🎯 Logic การปิดเคสแบบเต็ม

### **Code Logic:**

**File:** `/components/TicketActions.tsx` (Line 120-127)

```typescript
// ✅ Staff can close tickets they created when status = 'new' (เคสเล็กๆ น้อยๆ)
const canStaffClose = userRole === 'staff' && 
                      ticket.createdBy === userId && 
                      ticket.status === 'new';

// Only users with 'tier1' in their roles array can close tickets
// (Admin without tier1 cannot close)
const canClose = (hasTier1Role && (isPendingClosure || isResolved)) || canStaffClose;
```

---

### **เงื่อนไข `canClose`:**

```typescript
canClose = (hasTier1Role && (isPendingClosure || isResolved)) || canStaffClose
```

**แปลเป็นภาษาไทย:**
```
ปิดเคสได้ ถ้า:
  (มี tier1 role ใน roles array 
   AND (status = 'pending_closure' OR status = 'resolved'))
  OR (เป็น staff AND สร้างเคสเอง AND status = 'new')
```

---

### **ตัวอย่างการใช้งาน:**

#### **Case 1: Tier1 เพียวๆ (อภิญญา)**

```typescript
User: {
  id: 'user-012',
  name: 'อภิญญา ทองชัย',
  roles: ['tier1'],  // ✅ มี tier1
  tier: 1
}

Ticket 1: {
  status: 'pending_closure',
  assignedTo: 'user-003'  // ไม่ใช่ user-012
}
```

**ผลลัพธ์:**
```
hasTier1Role = true  // ✅ มี 'tier1' ใน roles
isPendingClosure = true
canClose = (true && true) || false = true  // ✅ ปิดได้!
```

---

```typescript
Ticket 2: {
  status: 'resolved',
  assignedTo: 'user-005'  // ไม่ใช่ user-012
}
```

**ผลลัพธ์:**
```
hasTier1Role = true  // ✅ มี 'tier1' ใน roles
isResolved = true
canClose = (true && true) || false = true  // ✅ ปิดได้!
```

---

#### **Case 2: Tier2 เพียวๆ (ไม่มี tier1)**

```typescript
User: {
  id: 'user-007',
  name: 'ประกาษิต สุขสันต์',
  roles: ['tier2'],  // ❌ ไม่มี tier1
  tier: 2
}

Ticket: {
  status: 'pending_closure',
  assignedTo: 'user-007'
}
```

**ผลลัพธ์:**
```
hasTier1Role = false  // ❌ ไม่มี 'tier1' ใน roles
isPendingClosure = true
canClose = (false && true) || false = false  // ❌ ปิดไม่ได้!
```

**สิ่งที่ Tier2 เห็น:**
- ✅ ปุ่ม "แก้ไขแล้วส่ง → T1 เพื่อปิด" (canReturnToT1 = true)
- ❌ ไม่เห็นปุ่ม "ปิดเคส" (canClose = false)

---

#### **Case 3: Admin + Tier1**

```typescript
User: {
  id: 'user-001',
  name: 'ธีรพร ระมิงค์วงศ์',
  roles: ['admin', 'tier1'],  // ✅ มี tier1
  tier: 1
}

Ticket: {
  status: 'resolved',
  assignedTo: 'user-003'
}
```

**ผลลัพธ์:**
```
hasTier1Role = true  // ✅ มี 'tier1' ใน roles
isResolved = true
canClose = (true && true) || false = true  // ✅ ปิดได้!
```

---

#### **Case 4: Admin เพียวๆ (ไม่มี tier)**

```typescript
User: {
  id: 'user-011',
  name: 'ประอรรัตน์ กีรติผจญ',
  roles: ['admin'],  // ❌ ไม่มี tier ใดๆ
  tier: undefined
}

Ticket: {
  status: 'pending_closure',
  assignedTo: 'user-003'
}
```

**ผลลัพธ์:**
```
hasTier1Role = false  // ❌ ไม่มี 'tier1' ใน roles
isPureAdmin = true  // ✅ Admin เพียวๆ

// ❌ ไม่แสดงปุ่มใดๆ เลย (Monitor Only)
return null;
```

---

#### **Case 5: Staff ปิดเคสเล็กๆ**

```typescript
User: {
  id: 'staff-001',
  name: 'สมชาย ใจดี',
  roles: ['staff'],
  tier: undefined
}

Ticket: {
  id: 'c-101',
  status: 'new',
  createdBy: 'staff-001',  // ✅ สร้างโดย Staff เอง
  assignedTo: undefined
}
```

**ผลลัพธ์:**
```
canStaffClose = true  // ✅ Staff && สร้างเอง && status = 'new'
canClose = false || true = true  // ✅ ปิดได้!
```

---

## 📊 สรุปเปรียบเทียบ

| Role | Status | assignedTo | canClose | หมายเหตุ |
|------|--------|------------|----------|----------|
| **Tier1 เพียวๆ** | pending_closure | ใครก็ได้ | ✅ | แกนหลักปิดเคส |
| **Tier1 เพียวๆ** | resolved | ใครก็ได้ | ✅ | แกนหลักปิดเคส |
| **Tier1 เพียวๆ** | in_progress | ตัวเอง | ❌ | ต้องกด "แก้ไขเสร็จแล้ว" ก่อน |
| **Tier2 เพียวๆ** | pending_closure | ตัวเอง | ❌ | ต้องส่ง → T1 เพื่อปิด |
| **Tier2 เพียวๆ** | resolved | ตัวเอง | ❌ | ต้องส่ง → T1 เพื่อปิด |
| **Tier3 เพียวๆ** | pending_closure | ตัวเอง | ❌ | ต้องส่ง → T1 เพื่อปิด |
| **Admin + Tier1** | pending_closure | ใครก็ได้ | ✅ | มี tier1 role |
| **Admin + Tier1** | resolved | ใครก็ได้ | ✅ | มี tier1 role |
| **Admin เพียวๆ** | ทุก status | ใครก็ได้ | ❌ | Monitor Only |
| **Staff** | new | ตัวเอง (สร้างเอง) | ✅ | เคสเล็กๆ |
| **Staff** | new | คนอื่นสร้าง | ❌ | - |
| **Staff** | in_progress | ตัวเอง | ❌ | - |

---

## 🧪 การทดสอบ

### **Test 1: Tier1 เพียวๆ ปิดเคส pending_closure**

```bash
1. Login: apinya.t / apinya.t123 (อภิญญา - Tier1 เพียวๆ)
2. Navigate: /admin/dashboard
3. Filter: status = "รอปิด (5)"
4. เปิดเคสใดๆ ที่ status = 'pending_closure'

Expected:
✅ แสดงปุ่ม "ปิดเคส" (สีน้ำเงิน)
✅ กดปุ่ม → แสดง Dialog "ปิดเคส"
✅ กด "ยืนยันการปิดเคส" → status = 'closed'
```

---

### **Test 2: Tier1 เพียวๆ ปิดเคส resolved**

```bash
1. Login: apinya.t / apinya.t123 (อภิญญา - Tier1 เพียวๆ)
2. Navigate: /admin/dashboard
3. Filter: status = "แก้ไขเสร็จแล้ว (12)"
4. เปิดเคสใดๆ ที่ status = 'resolved'

Expected:
✅ แสดงปุ่ม "ปิดเคส" (สีน้ำเงิน)
✅ กดปุ่ม → แสดง Dialog "ปิดเคส"
✅ กด "ยืนยันการปิดเคส" → status = 'closed'

❌ Before Fix:
ไม่แสดงปุ่มใดๆ เลย (Bug!)
```

---

### **Test 3: Tier1 + Staff ปิดเคส**

```bash
1. Login: user ที่มี roles: ['tier1', 'staff']
2. Navigate: /admin/dashboard
3. เปิดเคส status = 'pending_closure'

Expected:
✅ แสดงปุ่ม "ปิดเคส" (เพราะมี tier1 role)
```

---

### **Test 4: Tier2 เพียวๆ ไม่สามารถปิดเคส**

```bash
1. Login: prakadit.s / prakadit.s123 (ประกาษิต - Tier2 เพียวๆ)
2. Navigate: /admin/escalated
3. รับเคสใดๆ → status = 'in_progress'
4. แก้ไขเสร็จ

Expected:
❌ ไม่แสดงปุ่ม "ปิดเคส"
✅ แสดงปุ่ม "แก้ไขแล้วส่ง → T1 เพื่อปิด" (สีเขียว)
```

---

### **Test 5: Admin เพียวๆ ไม่เห็นปุ่มใดๆ**

```bash
1. Login: pra-onrat.k / pra-onrat.k123 (ประอรรัตน์ - Admin เพียวๆ)
2. Navigate: /admin/dashboard
3. เปิดเคสใดๆ

Expected:
❌ ไม่แสดงปุ่ม Action ใดๆ เลย
✅ แสดง Banner: "คุณอยู่ในโหมดดูอย่างเดียว (Monitor Only)"
```

---

### **Test 6: Staff ปิดเคสเล็กๆ**

```bash
1. Login: staff / staff123
2. Navigate: /create
3. กรอกข้อมูลครบ
4. กดปุ่ม "✅ แก้ไขและปิดเคส"

Expected:
✅ สร้างเคส status = 'closed'
✅ closedBy = Staff user ID
✅ ปรากฏใน /closed-tickets ส่วน "Staff ปิดเอง"
```

---

## 🔍 Debug Tips

### **ตรวจสอบ hasTier1Role:**

```typescript
console.log('🔍 hasTier1Role:', hasTier1Role);
console.log('🔍 currentUser?.roles:', currentUser?.roles);
console.log('🔍 ticket.status:', ticket.status);
```

**Output สำหรับ Tier1 เพียวๆ:**
```
🔍 hasTier1Role: true
🔍 currentUser?.roles: ['tier1']
🔍 ticket.status: 'pending_closure'
```

**Output สำหรับ Tier2 เพียวๆ:**
```
🔍 hasTier1Role: false
🔍 currentUser?.roles: ['tier2']
🔍 ticket.status: 'pending_closure'
```

---

### **ตรวจสอบ canClose:**

```typescript
console.log('🔍 canClose:', canClose);
console.log('🔍 isPendingClosure:', isPendingClosure);
console.log('🔍 isResolved:', isResolved);
console.log('🔍 canStaffClose:', canStaffClose);
```

---

## 📚 เอกสารอ้างอิง

| เอกสาร | เนื้อหา |
|--------|---------|
| `/docs/PERMISSION_MATRIX.md` | Permission Logic ทั้งหมด |
| `/docs/WORKFLOW.md` | Workflow การปิดเคส |
| `/PHASE1_TESTING.md` | Test Cases การปิดเคส |
| `/CLOSE_TICKET_LOGIC.md` | เอกสารนี้ - Logic การปิดเคส |

---

## 💡 Best Practices

### **เมื่อเพิ่ม Logic ใหม่:**

1. ✅ ตรวจสอบว่า `hasTier1Role` คำนวณถูกต้อง
2. ✅ ใช้ `currentUser?.roles?.includes('tier1')` แทนการเช็ค `userRole === 'tier1'`
3. ✅ อย่าเช็ค `assignedTo === userId` สำหรับ Tier1 ที่ปิดเคส
4. ✅ ให้ Tier2/3 ส่งกลับ T1 เพื่อปิดเท่านั้น

---

### **กฎทอง:**

```
1. Tier1 = แกนหลักปิดเคส (ไม่ต้องเช็ค assignedTo)
2. Tier2/3 = ต้องส่งกลับ T1 เพื่อปิด
3. Staff = ปิดได้เฉพาะเคสเล็กๆ ที่สร้างเอง (status = 'new')
4. Admin เพียวๆ = Monitor Only (ไม่มีสิทธิ์ทำ Action)
5. Admin + Tier1 = ปิดได้เหมือน Tier1 เพียวๆ
```

---

## ✅ สรุป

### **ปัญหา:**
- ❌ เคส status = 'resolved' ไม่แสดงปุ่มใดๆ
- ❌ Tier1 ไม่สามารถปิดเคส 'resolved'

### **การแก้ไข:**
```typescript
// Before (Bug):
if (ticket.status === 'closed' || ticket.status === 'resolved') {
  return null;
}

// After (Fixed):
if (ticket.status === 'closed') {
  return null;
}
```

### **ผลลัพธ์:**
- ✅ Tier1 เห็นปุ่ม "ปิดเคส" สำหรับ 'resolved'
- ✅ Tier1 เห็นปุ่ม "ปิดเคส" สำหรับ 'pending_closure'
- ✅ Logic ตรงตามความต้องการ 100%

---

**Completed:** 14 มกราคม 2026, 20:00 น.  
**Status:** ✅ **Bug Fixed & Documented**  
**Tested By:** Tier1 เพียวๆ (อภิญญา ทองชัย)

---

## 🎓 สรุปสำหรับนักพัฒนา

### **ถ้าคุณเป็น Tier1:**
```
✅ คุณคือแกนหลักในการปิดเคส
✅ คุณสามารถปิดเคสใดๆ ที่ status = 'pending_closure' หรือ 'resolved'
✅ ไม่ต้องเป็นคนรับเคส (assignedTo) ก็ปิดได้
✅ เพื่อนร่วมทีมปิดให้ได้
```

### **ถ้าคุณเป็น Tier2/3:**
```
❌ คุณไม่สามารถปิดเคสได้โดยตรง
✅ คุณต้องส่งกลับไปหา Tier1 เพื่อปิด
✅ ใช้ปุ่ม "แก้ไขแล้วส่ง → T1 เพื่อปิด"
```

### **ถ้าคุณเป็น Staff:**
```
✅ คุณสามารถปิดเคสเล็กๆ ที่สร้างเองได้
✅ เลือก "แก้ไขและปิดเคส" ตั้งแต่ตอนสร้าง
✅ เคสจะถูกปิดทันที (status = 'closed')
```

---

**Happy Closing! 🎉**
