# 🔍 Filter Display Policy - นโยบายการแสดงผลตัวกรอง

**เอกสารฉบับนี้:** นโยบายการแสดงผลตัวกรองในหน้าเคสต่าง ๆ  
**Version:** 1.0  
**Last Updated:** 2025-01-22  
**Status:** ✅ Active

---

## 📋 สารบัญ

1. [ภาพรวม](#ภาพรวม)
2. [นโยบายหลัก](#นโยบายหลัก)
3. [หน้าที่ได้รับผลกระทบ](#หน้าที่ได้รับผลกระทบ)
4. [เหตุผล](#เหตุผล)
5. [Implementation](#implementation)
6. [Related Documents](#related-documents)

---

## 🎯 ภาพรวม

**ปัญหา:**  
เดิมตัวกรอง (Filters) จะซ่อนอยู่เป็น default ผู้ใช้ต้องกดปุ่ม "ตัวกรอง" ทุกครั้งเพื่อแสดงตัวกรอง ทำให้ใช้งานไม่สะดวก

**วิธีแก้:**  
**ตัวกรองแสดงโดย default** (เปิดอยู่) เพื่อให้ผู้ใช้เข้าถึงได้ทันที

---

## 📖 นโยบายหลัก

### ✅ **Filter Display = Default Show**

```
เมื่อผู้ใช้เข้าหน้าเคสใด ๆ ที่มีตัวกรอง:
  → ตัวกรองจะแสดงผลทันที (Expanded State)
  → ผู้ใช้สามารถใช้งานได้เลยโดยไม่ต้องกดปุ่มเพิ่มเติม
```

### 🎨 **User Experience:**

| สถานการณ์ | พฤติกรรม | เหตุผล |
|-----------|----------|--------|
| **เข้าหน้าใหม่** | ✅ Filters เปิดอยู่ | ให้ผู้ใช้เห็นตัวเลือกทันที |
| **กดปุ่มซ่อน** | ✅ Filters ปิดได้ | ให้ผู้ใช้ปรับแต่งได้ตามต้องการ |
| **Refresh หน้า** | ✅ Filters เปิดอยู่ | รักษา default behavior |
| **มือถือ** | ✅ Filters เปิดอยู่ | เพื่อความสะดวกในการใช้งาน |

---

## 📱 หน้าที่ได้รับผลกระทบ

### 1. **หน้าเคสทั้งหมด** (`/admin/tickets`)
- ✅ ตัวกรอง: Status, Tier, Priority, Channel, Hashtag
- ✅ Default: **เปิดอยู่**

### 2. **หน้างานของฉัน** (`/admin/my-tickets`)
- ✅ ตัวกรอง: Status, Priority, Channel
- ✅ Default: **เปิดอยู่**

### 3. **หน้าที่ฉันส่งต่อ** (`/admin/escalated`)
- ✅ ตัวกรอง: Status, Priority, Tier ที่ส่งต่อ
- ✅ Default: **เปิดอยู่**

### 4. **หน้าที่รอการประมวลผล** (`/admin/pending`)
- ✅ ตัวกรอง: Priority, Assignee
- ✅ Default: **เปิดอยู่**

### 5. **หน้าลูกค้า - ติดตามเคส** (`/track-ticket`)
- ✅ ตัวกรอง: Status, Priority
- ✅ Default: **เปิดอยู่**

### 6. **หน้า Staff - ติดตามเคส** (`/staff/tickets`)
- ✅ ตัวกรอง: Status, Priority, Channel
- ✅ Default: **เปิดอยู่**

---

## 💡 เหตุผล

### ✅ **ประสบการณ์ผู้ใช้ดีขึ้น:**
1. **ลดขั้นตอนการใช้งาน** - ไม่ต้องกดปุ่ม "ตัวกรอง" ทุกครั้ง
2. **มองเห็นตัวเลือกทันที** - ผู้ใช้เห็นว่ามีตัวกรองอะไรบ้าง
3. **เร็วขึ้น** - สามารถกรองข้อมูลได้ทันทีเมื่อเข้าหน้า

### ✅ **ยืดหยุ่น:**
- ผู้ใช้ยังสามารถ**ซ่อนตัวกรอง**ได้ตามต้องการ
- State ของตัวกรองไม่ถูก persist (ไม่บันทึกลง localStorage)

### ✅ **Consistency:**
- ทุกหน้าที่มีตัวกรองจะใช้นโยบายเดียวกัน
- ลดความสับสนในการใช้งาน

---

## 🛠️ Implementation

### 📝 **Code Example:**

```typescript
// components/TicketListPage.tsx

// ❌ OLD: Default ซ่อน (false)
const [showFilters, setShowFilters] = useState(false);

// ✅ NEW: Default แสดง (true)
const [showFilters, setShowFilters] = useState(true);
```

### 🎨 **UI Behavior:**

```
┌─────────────────────────────────────────┐
│  🔍 ตัวกรอง                    [▼ ซ่อน]  │ ← แสดงเสมอ
├─────────────────────────────────────────┤
│  Status:   [All ▼]                      │
│  Priority: [All ▼]                      │
│  Channel:  [All ▼]                      │
└─────────────────────────────────────────┘

กดปุ่ม "ซ่อน":

┌─────────────────────────────────────────┐
│  🔍 ตัวกรอง                    [▶ แสดง]  │ ← ซ่อนได้
└─────────────────────────────────────────┘
```

---

## 🔗 Implementation Checklist

### ✅ **Phase 1: Core Pages**
- [x] `/components/TicketListPage.tsx` - เคสทั้งหมด
- [ ] `/components/MyTicketsPage.tsx` - งานของฉัน (ถ้ามี)
- [ ] `/components/EscalatedPage.tsx` - เคสที่ส่งต่อ
- [ ] `/components/PendingPage.tsx` - รอการประมวลผล (ถ้ามี)

### ✅ **Phase 2: Customer/Staff Pages**
- [ ] `/components/CustomerTrackTicketPage.tsx` - ลูกค้า
- [ ] `/components/StaffTrackTicketPage.tsx` - Staff

---

## 📊 Metrics (อนาคต)

เมื่อเชื่อม Analytics:

| Metric | Before | After | Target |
|--------|--------|-------|--------|
| Filter Usage Rate | ? | ? | +30% |
| Avg. Time to Filter | ? | ? | -50% |
| User Satisfaction | ? | ? | +20% |

---

## 🔗 Related Documents

- [🏠 กลับหน้าแรก](../INDEX.md)
- 📋 [Manual Accept Policy](MANUAL_ACCEPT_POLICY.md)
- 💬 [Comment Policy](COMMENT_POLICY.md)
- 🎭 [Multi-Role Accept Button Policy](MULTI_ROLE_ACCEPT_BUTTON_POLICY.md)
- 📊 [Permission Matrix](../technical/PERMISSION_MATRIX.md)
- 🔄 [Workflow Documentation](WORKFLOW.md)

---

## 📝 Change Log

| Date | Version | Change | Author |
|------|---------|--------|--------|
| 2025-01-22 | 1.0 | 📄 Initial document | System |

---

## ❓ FAQ

### Q: ทำไมไม่ persist state ของตัวกรอง?
**A:** เพื่อให้ผู้ใช้เริ่มต้นด้วย default view ทุกครั้ง ไม่มีความสับสนจากการตั้งค่าครั้งก่อน

### Q: มือถือจะไม่แคบเกินไปหรือ?
**A:** ตัวกรองถูกออกแบบให้ responsive ยุบได้ตามขนาดหน้าจอ

### Q: ถ้าต้องการ persist state ล่ะ?
**A:** สามารถใช้ localStorage ได้ในอนาคต แต่ต้องมีปุ่ม "Reset Filters" ด้วย

---

**หมายเหตุ:** เอกสารนี้เป็���ส่วนหนึ่งของ CDGS Issue Tracking Platform Documentation System
