# 📊 ระบบรายงานและสิทธิ์การเข้าถึง (Reports Access Control)

## 🎯 ภาพรวม

ระบบรายงาน (Reports) ใน **CDGS Issue Tracking Platform** ถูกออกแบบให้แสดงข้อมูลสถิติและการวิเคราะห์ระบบทั้งหมด โดยมีการควบคุมสิทธิ์การเข้าถึงตามบทบาท (Role-Based Access Control)

---

## 🔐 สิทธิ์การเข้าถึงระบบรายงาน

### ✅ ผู้ที่สามารถเข้าถึงได้

#### 1. **Admin (ผู้ดูแลระบบ)**
- **เงื่อนไข:** `user.role === 'admin'`
- **สิทธิ์:** เข้าถึง**รายงานทั้งหมด 5 Tabs**
  1. 📊 **ภาพรวม** (Dashboard) - สถิติรวมระบบทั้งหมด
  2. 🏢 **ตามหน่วยงาน** (Organization) - แบ่งตาม Organization/Department
  3. 💬 **ตามช่องทาง** (Channel) - แบ่งตาม Channel (Web/Email/Phone/Line)
  4. 👥 **ตามเจ้าหน้าที่** (Staff) - Performance ของแต่ละ Staff/Tier
  5. ⏱️ **ประสิทธิภาพ SLA** (SLA Performance) - SLA compliance metrics
- **เมนูใน Sidebar:** ✅ มีเมนู "รายงาน"

#### 2. **Multi-Role ที่มี Admin อยู่ด้วย**
- **เงื่อนไข:** ผู้ใช้ที่มีหลายบทบาท และบทบาทหนึ่งคือ `admin`
- **สิทธิ์:** เข้าถึง**รายงานทั้งหมด 5 Tabs** (เหมือน Admin)
- **เมนูใน Sidebar:** ✅ มีเมนู "รายงาน"
- **ตัวอย่าง:**
  - User ที่มี roles: `['admin', 'tier3']` → เห็นรายงานทั้งหมด ✅
  - User ที่มี roles: `['admin', 'staff', 'tier1']` → เห็นรายงานทั้งหมด ✅

---

### ❌ ผู้ที่**ไม่สามารถ**เข้าถึงได้

#### 1. **Tier (Tier1/Tier2/Tier3) ที่ไม่มี Admin**
- **เงื่อนไข:** `user.role` เป็น `tier1`, `tier2`, หรือ `tier3` **แต่ไม่มี** `admin` role
- **สิทธิ์:** ❌ **ไม่สามารถเข้าถึงระบบรายงานได้**
- **เมนูใน Sidebar:** ❌ **ไม่มี**เมนู "รายงาน" (ถูกลบออกแล้ว)
- **หมายเหตุ:** 
  - ก่อนหน้านี้ Tier มีเมนู "รายงาน" และสามารถเข้าถึง Tab "ภาพรวม" ได้
  - **อัพเดทล่าสุด:** ลบเมนูออกเพื่อป้องกันความสับสน
  - Tier ที่ต้องการดูสถิติสามารถใช้เมนู "การวิเคราะห์" แทน

#### 2. **Staff**
- **เงื่อนไข:** `user.role === 'staff'`
- **สิทธิ์:** ❌ **ไม่สามารถเข้าถึงระบบรายงานได้**
- **เมนูใน Sidebar:** ❌ **ไม่มี**เมนู "รายงาน"
- **หมายเหตุ:** Staff ใช้เมนู "การวิเคราะห์" สำหรับดูสถิติการทำงาน

#### 3. **Customer (ลูกค้า)**
- **เงื่อนไข:** `user.role === 'customer'`
- **สิทธิ์:** ❌ **ไม่สามารถเข้าถึงระบบรายงานได้**
- **ผลลัพธ์:** แสดงหน้า "ไม่มีสิทธิ์เข้าถึง" (Access Denied)
- **ข้อความ:**
  ```
  🛡️ ไม่มีสิทธิ์เข้าถึง
  คุณไม่มีสิทธิ์ในการดูรายงาน ระบบรายงานสำหรับผู้ดูแลระบบและเจ้าหน้าที่เท่านั้น
  ```

---

## 💻 โค้ดการตรวจสอบสิทธิ์

### ไฟล์: `/components/ReportsPage.tsx`

```typescript
// Role-based access control
const canViewReports = ['admin'].includes(user?.role || '');
const canViewOwnStats = ['staff', 'tier1', 'tier2', 'tier3'].includes(user?.role || '');

if (!canViewReports && !canViewOwnStats) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <Card className="max-w-2xl mx-auto p-8 text-center">
        <Shield className="h-16 w-16 mx-auto text-slate-400 mb-4" />
        <h2 className="text-2xl font-semibold text-slate-900 mb-2">
          ไม่มีสิทธิ์เข้าถึง
        </h2>
        <p className="text-slate-600">
          คุณไม่มีสิทธิ์ในการดูรายงาน ระบบรายงานสำหรับผู้ดูแลระบบและเจ้าหน้าที่เท่านั้น
        </p>
      </Card>
    </div>
  );
}
```

---

## 📋 สรุปตารางสิทธิ์การเข้าถึง

| บทบาท (Role) | เข้าถึงรายงานได้? | Tabs ที่เห็น | หมายเหตุ |
|--------------|------------------|--------------|----------|
| **Admin** | ✅ ใช่ | ทั้งหมด 5 Tabs | สิทธิ์เต็ม |
| **Multi-Role (มี Admin)** | ✅ ใช่ | ทั้งหมด 5 Tabs | เช่น `['admin', 'tier3']` |
| **Staff** | ❌ ไม่ได้ | - | ใช้เมนู "การวิเคราะห์" แทน |
| **Tier1** | ❌ ไม่ได้ | - | ใช้เมนู "การวิเคราะห์" แทน |
| **Tier2** | ❌ ไม่ได้ | - | ใช้เมนู "การวิเคราะห์" แทน |
| **Tier3** | ❌ ไม่ได้ | - | ใช้เมนู "การวิเคราะห์" แทน |
| **Customer** | ❌ ไม่ได้ | - | แสดงหน้า Access Denied |

---

## 🔄 ความแตกต่างระหว่าง "รายงาน" และ "การวิเคราะห์"

### 📊 **รายงาน (Reports)**
- **ไฟล์:** `/components/ReportsPage.tsx`
- **วัตถุประสงค์:** แสดงรายงานสถิติภาพรวมแบบแบ่งหมวดหมู่ตาม Tab
- **5 Tabs:**
  1. ภาพรวม - สถิติรวมระบบทั้งหมด
  2. ตามหน่วยงาน - แบ่งตาม Organization/Department
  3. ตามช่องทาง - แบ่งตาม Channel (Web/Email/Phone/Line)
  4. ตามเจ้าหน้าที่ - Performance ของแต่ละ Staff/Tier
  5. ประสิทธิภาพ SLA - SLA compliance metrics
- **UI Style:** Tab-based navigation, gradient background (slate-50 to slate-100)
- **Access:** Admin (ทั้งหมด) + Staff/Tier (เฉพาะ Dashboard)

### 📈 **การวิเคราะห์ (Analytics)**
- **ไฟล์:** `/components/AnalyticsDashboard.tsx`
- **วัตถุประสงค์:** วิเคราะห์เชิงลึก - Escalation times, Performance metrics, Trends
- **ฟีเจอร์:**
  - ตัวกรอง: เลือก Project และ Date Range (7/30/90 วัน)
  - Key Metrics:
    - เวลาส่งต่อเฉลี่ย (T1→T2, T2→T3)
    - เวลาแก้ไขเฉลี่ย
    - SLA compliance rate
  - Charts:
    - Escalation time distribution
    - Resolution time trends
    - Priority breakdown
  - ส่งออกรายงาน: Export button
- **UI Style:** Single page with filters, gray background
- **Access:** Admin only

---

## 📝 หมายเหตุสำคัญ

1. **Multi-Role Support:**
   - ระบบรองรับผู้ใช้ที่มีหลายบทบาท (Multi-Role)
   - หากมีบทบาท `admin` อยู่ในรายการ → จะได้สิทธิ์ Admin เต็ม

2. **Staff/Tier Access:**
   - เจ้าหน้าที่ระดับ Staff และ Tier สามารถดูรายงานภาพรวมได้
   - แต่ไม่สามารถดูรายงานแบบละเอียด (ตามหน่วยงาน, ช่องทาง, เจ้าหน้าที่, SLA)

3. **Customer Restriction:**
   - ลูกค้าไม่สามารถเข้าถึงระบบรายงานได้เลย
   - ลูกค้ามีเฉพาะการติดตามเคสของตัวเอง

---

## 🗓️ อัพเดทล่าสุด

- **วันที่:** 12 มกราคม 2026
- **เวอร์ชัน:** 2.0
- **แก้ไขโดย:** System Documentation
- **การเปลี่ยนแปลง:**
  - ✅ แก้ไข padding structure ของ ReportsPage ให้มี padding ซ้าย-ขวาเหมือน AnalyticsDashboard
  - ✅ ย้าย `p-6` ไปที่ container wrapper เพื่อให้สอดคล้องกับ AnalyticsDashboard
  - ✅ **ลบเมนู "รายงาน" ออกจาก Sidebar ของ Tier1, Tier2, Tier3** (เพื่อป้องกันความสับสน)
  - ✅ เก็บเมนู "รายงาน" ไว้เฉพาะบทบาท Admin และ Multi-Role ที่มี Admin เท่านั้น
  - ✅ อัพเดทตารางสิทธิ์การเข้าถึงให้สะท้อนการเปลี่ยนแปลง
  - ✅ เพิ่มเอกสารบันทึกสิทธิ์การเข้าถึงระบบรายงาน
