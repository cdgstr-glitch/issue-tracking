# 🆕 Tier1 + Staff Multi-Role Feature

**วันที่:** 21 มกราคม 2026  
**สถานะ:** ✅ เสร็จสมบูรณ์

---

## 🎯 ภาพรวม

เพิ่มปุ่ม **"📥 บันทึกและรับเคส"** สำหรับผู้ใช้ที่มี **Tier1 + Staff role** (Multi-role)

---

## 🚨 ปัญหาที่พบ

ทีมงานที่มี **Tier1 + Staff role** (เช่น ธิราภรณ์, สาริน) บ่นว่า:

```
บันทึกเคสแทนลูกค้า → กด "ส่งงาน" 
→ ออกไปหน้า "รอดำเนินการ" 
→ คลิกเข้าเคสอีกครั้ง → กด "รับเคส"
→ เสียเวลา 2 ขั้นตอน!
```

---

## ✅ วิธีแก้

เพิ่มปุ่มที่ 3: **"📥 บันทึกและรับเคส"**

### **Pure Staff (เจ้าหน้าที่อย่างเดียว):**
มี **2 ปุ่ม:**
1. ✅ แก้ไขและปิดเคส
2. 📤 ส่งงาน

### **🆕 Tier1 + Staff (Multi-role):**
มี **3 ปุ่ม:**
1. ✅ แก้ไขและปิดเคส
2. 📤 ส่งงาน
3. 📥 **บันทึกและรับเคส** ⭐ ใหม่!

---

## 📊 ตารางเปรียบเทียบ

| ปุ่ม | Use Case | Status | Assigned | Navigate to |
|------|----------|--------|----------|-------------|
| **✅ แก้ไขและปิดเคส** | เคสย้อนหลังที่แก้ไขแล้ว | `closed` | `null` | `/admin` |
| **📤 ส่งงาน** | ให้ Tier1 คนอื่นแก้ไข | `new` | `null` | `/admin/tickets` |
| **📥 บันทึกและรับเคส** | รับเคสเลย แก้ไขเอง | `tier1` | `user.id` | `/admin/my-tickets` ⭐ |

---

## 🔧 การทำงาน

### **ปุ่ม "บันทึกและรับเคส":**

1. **Validate** ฟิลด์ required ทั้งหมด
2. **สร้างเคส** ในระบบ
3. **Assign ให้ตัวเอง** (`assignedTo = user.id`)
4. **เปลี่ยน Status** = `tier1` (รับเคสแล้ว)
5. **แสดง Success Page** พร้อมข้อความ:
   - ✅ "บันทึกและรับเคสสำเร็จ!"
   - ✅ "กำลังเปลี่ยนหน้าไปยัง 'งานของฉัน'..."
6. **Auto-redirect** ไป `/admin/my-tickets` หลัง 2 วินาที

---

## 💡 ประโยชน์

| ก่อน | หลัง |
|------|------|
| 📝 บันทึกเคส<br>→ กด "ส่งงาน"<br>→ ไปหน้า "รอดำเนินการ"<br>→ คลิกเข้าเคส<br>→ กด "รับเคส"<br>= **5 ขั้นตอน** | 📝 บันทึกเคส<br>→ กด "บันทึกและรับเคส"<br>→ ไปหน้า "งานของฉัน" ทันที<br>= **2 ขั้นตอน** ⚡ |

**ลด workflow จาก 5 ขั้นตอน → 2 ขั้นตอน (ลด 60%!)**

---

## 🛠️ Implementation

### **ไฟล์:** `/components/CreateTicketPage.tsx`

#### **1. เพิ่ม State:**
```typescript
const [ticketAccepted, setTicketAccepted] = useState(false);
```

#### **2. เพิ่ม Function:**
```typescript
const handleSaveAndAccept = (e: React.FormEvent) => {
  e.preventDefault();
  
  // Validate
  const formElement = document.querySelector('form');
  if (formElement && !formElement.checkValidity()) {
    formElement.reportValidity();
    return;
  }
  
  // สร้าง Ticket Number
  const newTicketNumber = `CDGS-2024-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`;
  setTicketNumber(newTicketNumber);
  
  // Log (ในระบบจริงจะบันทึกลง Database)
  console.log('✅ Ticket Saved and Accepted:', {
    ticketNumber: newTicketNumber,
    status: 'tier1',
    assignedTo: user?.id,
    assignedName: user?.fullName,
    acceptedAt: new Date().toISOString()
  });
  
  setTicketAccepted(true);
};
```

#### **3. เพิ่ม Success Page:**
```typescript
if (ticketAccepted) {
  // Auto-redirect หลัง 2 วินาที
  useEffect(() => {
    const timer = setTimeout(() => {
      onNavigate('/admin/my-tickets');
    }, 2000);
    return () => clearTimeout(timer);
  }, [onNavigate]);

  return (
    <Card className="border-blue-200 bg-blue-50">
      <h2>✅ บันทึกและรับเคสสำเร็จ!</h2>
      <p>กำลังเปลี่ยนหน้าไปยัง "งานของฉัน"...</p>
      <div>
        <p>หมายเลขเคส: {ticketNumber}</p>
        <p>✓ เคสได้รับ Assigned ให้คุณแล้ว</p>
        <p>✓ สถานะเคส: กำลังดำเนินการ (Tier 1)</p>
      </div>
      <Button onClick={() => onNavigate('/admin/my-tickets')}>
        📥 ไปยังงานของฉัน
      </Button>
    </Card>
  );
}
```

#### **4. เพิ่มปุ่ม:**
```typescript
<div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
  <Button type="button" variant="outline" onClick={() => onNavigate('/')}>
    ยกเลิก
  </Button>
  
  {/* ปุ่มที่ 1: แก้ไขและปิดเคส */}
  {hasRole(user, 'staff') && (
    <Button 
      type="button" 
      size="lg"
      className="bg-green-600 hover:bg-green-700 text-white"
      onClick={handleSolveAndClose}
    >
      ✅ แก้ไขและปิดเคส
    </Button>
  )}
  
  {/* ปุ่มที่ 2: ส่งงาน */}
  <Button type="submit" size="lg">
    ส่งงาน
  </Button>
  
  {/* ปุ่มที่ 3: บันทึกและรับเคส - Tier1 + Staff เท่านั้น */}
  {hasRole(user, 'staff') && hasRole(user, 'tier1') && (
    <Button 
      type="button" 
      size="lg"
      className="bg-blue-600 hover:bg-blue-700 text-white"
      onClick={handleSaveAndAccept}
    >
      📥 บันทึกและรับเคส
    </Button>
  )}
</div>
```

---

## ✅ Testing Checklist

### **Test 1: Pure Staff (ไม่มี Tier1 role)**
- [ ] Login ด้วย Pure Staff (`staff` / `staff123`)
- [ ] ไปที่ `/create`
- [ ] ตรวจสอบว่ามี **2 ปุ่ม** เท่านั้น:
  - ✅ แก้ไขและปิดเคส
  - ✅ ส่งงาน
- [ ] **ไม่มีปุ่ม** "บันทึกและรับเคส"

### **Test 2: Tier1 + Staff (Multi-role)**
- [ ] Login ด้วย Tier1 + Staff (เช่น `thiraporn` / `thiraporn123`)
- [ ] ไปที่ `/create`
- [ ] ตรวจสอบว่ามี **3 ปุ่ม**:
  - ✅ แก้ไขและปิดเคส (สีเขียว)
  - ✅ ส่งงาน (สีปกติ)
  - ✅ **📥 บันทึกและรับเคส** (สีน้ำเงิน) ⭐

### **Test 3: ทดสอบปุ่ม "บันทึกและรับเคส"**
- [ ] Login ด้วย Tier1 + Staff
- [ ] ไปที่ `/create`
- [ ] กรอกข้อมูลครบ
- [ ] กด "📥 บันทึกและรับเคส"
- [ ] ตรวจสอบ Success Page:
  - ✅ แสดงข้อความ "บันทึกและรับเคสสำเร็จ!"
  - ✅ แสดง Ticket Number
  - ✅ แสดงข้อความ "กำลังเปลี่ยนหน้า..."
  - ✅ Auto-redirect ไป `/admin/my-tickets` หลัง 2 วินาที
- [ ] ตรวจสอบหน้า "งานของฉัน":
  - ✅ เคสปรากฏใน "งานของฉัน"
  - ✅ Status = `tier1`
  - ✅ Assigned = ตัวเอง

### **Test 4: Validation**
- [ ] Login ด้วย Tier1 + Staff
- [ ] ไปที่ `/create`
- [ ] **ไม่กรอกข้อมูล** (เว้นว่าง)
- [ ] กด "📥 บันทึกและรับเคส"
- [ ] ตรวจสอบว่า:
  - ✅ แสดงข้อความ Validation
  - ✅ ไม่ให้ส่งฟอร์ม
  - ✅ ไม่ redirect

---

## 🔄 ประวัติการอัปเดต

| วันที่ | รายละเอียด | ผู้ดำเนินการ |
|-------|-----------|-------------|
| 21 ม.ค. 2026 | 🆕 เพิ่มปุ่ม "บันทึกและรับเคส" สำหรับ Tier1 + Staff | CDGS Development Team |

---

## 📚 เอกสารอ้างอิง

- `/STAFF_ROLE_UPDATE_2026-01-21.md` - การอัปเดตบทบาท Staff
- `/docs/features/STAFF_ROLE_DOCUMENTATION.md` - เอกสาร Staff Role ฉบับสมบูรณ์
- `/docs/technical/PERMISSION_MATRIX.md` - ตาราง Permission

---

**สถานะเอกสาร:** ✅ เสร็จสมบูรณ์  
**ผู้จัดทำ:** CDGS Development Team  
**อัปเดตล่าสุด:** 21 มกราคม 2026
