# 📧 Email Templates - CDGS Issue Tracking Platform

**Last Updated:** 2025-01-22  
**Version:** 1.0

---

## 📋 สารบัญ

1. [ภาพรวม](#ภาพรวม)
2. [Email Templates ทั้งหมด](#email-templates-ทั้งหมด)
3. [Component Files](#component-files)
4. [การใช้งาน](#การใช้งาน)

---

## ภาพรวม

ระบบมี **Email Templates ทั้งหมด 6 ฉบับ** แบ่งเป็น 2 กลุ่มหลัก:

### กลุ่ม 1: Magic Link Emails (Authentication)
- **Component:** `EmailPreview.tsx`
- **จำนวน:** 2 เทมเพลต
- **ใช้สำหรับ:** ลงทะเบียน + Login

### กลุ่ม 2: Ticket Notification Emails
- **Component:** `EmailPreviewModal.tsx`
- **จำนวน:** 4 เทมเพลต
- **ใช้สำหรับ:** แจ้งเตือนเคส + มอบหมายงาน

---

## Email Templates ทั้งหมด

### 📁 กลุ่ม 1: Magic Link Emails

#### 1️⃣ Register Email (ลงทะเบียนใหม่)

**ชื่อ:** `register-magic-link`  
**Component:** `/components/customer/EmailPreview.tsx`  
**Mode:** `mode="register"`

**เนื้อหา:**
```
หัวเรื่อง: 🔐 ลิงก์เข้าสู่ระบบของคุณพร้อมแล้ว

สวัสดีคุณ [ชื่อลูกค้า]

ยินดีต้อนรับสู่ Application Support Center

คลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบและเริ่มแจ้งปัญหา
หรือติดตามสถานะเคสของคุณ

[ปุ่ม: 🚀 เข้าสู่ระบบและแจ้งเคส]

⏰ หมายเหตุ: ลิงก์นี้จะหมดอายุใน 30 นาที
```

**Destination:** `/create` (หน้าแจ้งเคส)

**ใช้เมื่อ:**
- ลูกค้าลงทะเบียนใหม่ผ่านหน้า Register
- กรอกชื่อ-นามสกุล + อีเมล

---

#### 2️⃣ Login Email (ขอลิงก์เข้าระบบ)

**ชื่อ:** `login-magic-link`  
**Component:** `/components/customer/EmailPreview.tsx`  
**Mode:** `mode="login"`

**เนื้อหา:**
```
หัวเรื่อง: 🔐 ลิงก์เข้าสู่ระบบของคุณพร้อมแล้ว

สวัสดีคุณ [ชื่อลูกค้า]

คุณได้ขอลิงก์เข้าสู่ระบบ Application Support Center

คลิกปุ่มด้านล่างเพื่อเข้าสู่ระบบและติดตามสถานะเคสของคุณ

[ปุ่ม: 🔐 เข้าสู่ระบบ]

⏰ หมายเหตุ: ลิงก์นี้จะหมดอายุใน 30 นาที
```

**Destination:** `/track` (หน้าติดตามเคส)

**ใช้เมื่อ:**
- ลูกค้าที่เคยลงทะเบียนแล้ว ขอลิงก์เข้าระบบใหม่
- กรอกแค่อีเมล (ไม่ต้องกรอกชื่อ)

---

### 📁 กลุ่ม 2: Ticket Notification Emails

#### 3️⃣ Customer Reply Email (แจ้งลูกค้า)

**ชื่อ:** `customer-ticket-reply`  
**Component:** `/components/EmailPreviewModal.tsx`  
**Type:** `type="customer"`

**เนื้อหา:**
```
หัวเรื่อง: ✅ เคสของคุณได้รับการตอบกลับ

สวัสดีคุณ [ชื่อลูกค้า]

เคส [เลขที่เคส]
หัวเรื่อง: [หัวเรื่องเคส]

เจ้าหน้าที่ได้ส่งข้อความตอบกลับ:
[ข้อความตอบกลับ]

[ปุ่ม: ดูรายละเอียดเคส]
```

**Destination:** `/track-ticket-detail/[ticketId]`

**ใช้เมื่อ:**
- เจ้าหน้าที่ตอบกลับเคสของลูกค้า (Public Comment)
- ทีม Tier1-3 อัพเดทสถานะเคส

---

#### 4️⃣ Staff Notification Email (แจ้งเจ้าหน้าที่)

**ชื่อ:** `staff-ticket-notification`  
**Component:** `/components/EmailPreviewModal.tsx`  
**Type:** `type="staff"`

**เนื้อหา:**
```
หัวเรื่อง: 📬 ลูกค้าส่งข้อความตอบกลับเคส

เคส [เลขที่เคส]
หัวเรื่อง: [หัวเรื่องเคส]

ลูกค้า [ชื่อลูกค้า] ได้ส่งข้อความตอบกลับ:
[ข้อความจากลูกค้า]

[ปุ่ม: ดูและตอบกลับเคส]
```

**Destination:** `/admin/tickets/[ticketId]` หรือ `/staff-ticket-detail/[ticketId]`

**ใช้เมื่อ:**
- ลูกค้าตอบกลับเคส (Comment)
- ลูกค้าเพิ่มไฟล์แนบ

---

#### 5️⃣ Assignment Email (มอบหมายงาน)

**ชื่อ:** `ticket-assignment`  
**Component:** `/components/EmailPreviewModal.tsx`  
**Type:** `type="assignment"`

**เนื้อหา:**
```
หัวเรื่อง: 🎯 คุณได้รับมอบหมายเคสใหม่

เคส [เลขที่เคส]
หัวเรื่อง: [หัวเรื่องเคส]

มอบหมายโดย: [ชื่อผู้มอบหมาย]
ระดับความสำคัญ: [ระดับ]
กำหนดเสร็จ: [วันที่]

รายละเอียด:
[รายละเอียดเคส]

[ปุ่ม: รับเคส]
```

**Destination:** `/admin/tickets/[ticketId]`

**ใช้เมื่อ:**
- Tier1 มอบหมายเคสให้ Tier2/Tier3
- Tier2 ส่งต่อเคสให้ Tier3
- Admin มอบหมายเคสให้ทีม

---

#### 6️⃣ Reminder Email (เตือนเคสค้าง)

**ชื่อ:** `ticket-reminder`  
**Component:** `/components/EmailPreviewModal.tsx`  
**Type:** `type="reminder"`

**เนื้อหา:**
```
หัวเรื่อง: ⏰ แจ้งเตือน: เคสใกล้ครบกำหนด

เคส [เลขที่เคส]
หัวเรื่อง: [หัวเรื่องเคส]

⚠️ เคสนี้จะครบกำหนดใน 24 ชั่วโมง

กำหนดเสร็จ: [วันที่]
สถานะปัจจุบัน: [สถานะ]

กรุณาตรวจสอบและดำเนินการ

[ปุ่ม: ดูเคส]
```

**Destination:** `/admin/tickets/[ticketId]`

**ใช้เมื่อ:**
- เคสใกล้ครบกำหนด (24 ชม.)
- เคสค้างนานเกินไป (SLA Alert)
- ระบบส่งอัตโนมัติ (Scheduled)

---

## Component Files

### 📄 `/components/customer/EmailPreview.tsx`

**ใช้สำหรับ:** Magic Link Emails (Register + Login)

**Props:**
```typescript
interface EmailPreviewProps {
  customerName: string;       // ชื่อลูกค้า
  customerEmail: string;      // อีเมลลูกค้า
  magicLinkURL: string;       // URL ของ Magic Link
  mode?: 'register' | 'login'; // ประเภทอีเมล
  onNavigate?: (path: string) => void;
}
```

**Features:**
- ✅ แสดงตัวอย่างอีเมล Magic Link
- ✅ มีปุ่มคลิกทดลองเข้าระบบได้เลย
- ✅ Auto-login ด้วย Magic Token
- ✅ แยกเนื้อหาและปุ่มตาม mode

---

### 📄 `/components/EmailPreviewModal.tsx`

**ใช้สำหรับ:** Ticket Notification Emails

**Props:**
```typescript
interface EmailPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'customer' | 'staff' | 'assignment' | 'reminder';
  ticket: Ticket;
  assignedBy?: User;    // สำหรับ assignment
  assignedTo?: User;    // สำหรับ assignment
}
```

**Features:**
- ✅ แสดงตัวอย่างอีเมลแจ้งเตือนเคส
- ✅ รองรับ 4 ประเภท (customer, staff, assignment, reminder)
- ✅ ดึงข้อมูลจาก Ticket object
- ✅ แสดงข้อความตัวอย่าง

---

## การใช้งาน

### ตัวอย่าง 1: แสดง Magic Link Email (Register)

```tsx
import { EmailPreview } from './customer/EmailPreview';

<EmailPreview
  customerName="นาย สมชาย ใจดี"
  customerEmail="somchai@example.com"
  magicLinkURL="https://app.cdgs.co.th/auth/verify?token=abc123"
  mode="register"
  onNavigate={navigate}
/>
```

### ตัวอย่าง 2: แสดง Magic Link Email (Login)

```tsx
<EmailPreview
  customerName="นาย สมชาย ใจดี"
  customerEmail="somchai@example.com"
  magicLinkURL="https://app.cdgs.co.th/auth/verify?token=xyz789"
  mode="login"
  onNavigate={navigate}
/>
```

### ตัวอย่าง 3: แสดงอีเมลแจ้งลูกค้า

```tsx
import { EmailPreviewModal } from './EmailPreviewModal';

<EmailPreviewModal
  isOpen={open}
  onClose={() => setOpen(false)}
  type="customer"
  ticket={currentTicket}
/>
```

### ตัวอย่าง 4: แสดงอีเมลมอบหมายงาน

```tsx
<EmailPreviewModal
  isOpen={open}
  onClose={() => setOpen(false)}
  type="assignment"
  ticket={currentTicket}
  assignedBy={currentUser}
  assignedTo={targetUser}
/>
```

---

## 🎨 Design Guidelines

### Email Header
- **จาก:** Application Support Center <noreply@cdgs.co.th>
- **ถึง:** [customer-email]
- **หัวเรื่อง:** มี emoji + ข้อความสั้นๆ

### Email Body
- **Greeting:** สวัสดีคุณ [ชื่อลูกค้า]
- **เนื้อหา:** ชัดเจน กระชับ ใช้ภาษาไทย
- **CTA Button:** ใหญ่ สีสดใส มี emoji
- **Footer:** ข้อมูลบริษัท + หมายเหตุ

### Colors
- **Primary:** Blue (#3B82F6)
- **Success:** Green (#10B981)
- **Warning:** Yellow (#F59E0B)
- **Danger:** Red (#EF4444)

---

## 🔧 TODO: Production Setup

เมื่อเชื่อม Backend จริง:

1. **สร้าง Email Service**
   - ใช้ Laravel Mail + Queue
   - Template Engine: Blade
   - SMTP: Gmail / SendGrid

2. **Magic Link Security**
   - Token expiry: 30 minutes
   - One-time use only
   - HTTPS required

3. **Email Queue**
   - Background job processing
   - Retry mechanism
   - Failed job monitoring

4. **Tracking**
   - Email open rate
   - Click-through rate
   - Bounce handling

---

## 📊 Email Summary Table

| # | ชื่อ | Component | Type/Mode | Destination | ใช้เมื่อ |
|---|------|-----------|-----------|-------------|----------|
| 1 | Register Magic Link | EmailPreview | mode="register" | /create | ลงทะเบียนใหม่ |
| 2 | Login Magic Link | EmailPreview | mode="login" | /track | ขอลิงก์เข้าระบบ |
| 3 | Customer Reply | EmailPreviewModal | type="customer" | /track-ticket-detail | เจ้าหน้าที่ตอบกลับ |
| 4 | Staff Notification | EmailPreviewModal | type="staff" | /admin/tickets | ลูกค้าตอบกลับ |
| 5 | Assignment | EmailPreviewModal | type="assignment" | /admin/tickets | มอบหมายเคส |
| 6 | Reminder | EmailPreviewModal | type="reminder" | /admin/tickets | เตือนเคสค้าง |

---

## 📝 Changelog

| Date | Version | Changes |
|------|---------|---------|
| 2025-01-22 | 1.0 | สร้างเอกสารรวม Email Templates ทั้ง 6 ฉบับ |

---

**Created by:** Development Team  
**Last Review:** 2025-01-22
