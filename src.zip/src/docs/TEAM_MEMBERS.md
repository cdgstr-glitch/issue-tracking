# 👥 รายชื่อพนักงาน CDGS Issue Tracking Platform

> **⚠️ หมายเหตุสำคัญ:** เอกสารนี้อัพเดทให้ตรงกับ Role System ปัจจุบัน  
> **กฎเหล็ก:** Tier1 ≠ Staff (ไม่มี staff role ใน tier1 array แล้ว)  
> **อ่านเพิ่มเติม:** [Role System & Active Role Switching](/docs/ROLE_SYSTEM_ACTIVE_ROLE_SWITCHING.md)

## 📋 สารบัญ
1. [สรุปตาราง](#สรุปตารางทั้งหมด-11-คน)
2. [Pure Admin](#1-pure-admin-1-คน)
3. [Admin + Tier1](#2-admin--tier1-2-คน)
4. [Tier1 Only](#3-tier1-only-3-คน)
5. [Tier2 Only](#4-tier2-only-2-คน)
6. [Tier2 + Tier3](#5-tier2--tier3-1-คน)
7. [Tier3 Only](#6-tier3-only-2-คน)
8. [บัญชีทดสอบ](#7-บัญชีทดสอบ-2-บัญชี)

---

## สรุปตารางทั้งหมด (11 คน)

| # | ชื่อ | Username | Role | เข้าถึงเมนู "ทีม" | Permission | หัวหน้าทีม |
|---|------|----------|------|------------------|-----------|-----------| 
| **1** | ประอรรัตน์ กีรติผจญ | `pra-onrat.k` | **Pure Admin** | ✅ | **R/W** | - |
| **2** | ธิราภรณ์ รุ่งวิรัตน์กุล | `thiraporn.r` | **Admin + Tier1** | ✅ | **R/W** | ✅ หัวหน้าทีม Tier1 |
| **3** | สาริน ช่อพะยอม | `sarin.c` | **Admin + Tier1** | ✅ | **R/W** | - |
| **4** | วรรณภา แซ่ด่าง | `wannapa.s` | **Tier1** | ✅ | Read-only | - |
| **5** | เขมิกา แซ่ตั้ง | `khemika.s` | **Tier1** | ✅ | Read-only | - |
| **6** | ธัญญาพร ทองแก้ว | `thanyaporn.t` | **Tier1** | ✅ | Read-only | - |
| **7** | ยุทธนา คณามิ่งมงคล | `yuttana.k` | Tier2 | ✅ | Read-only | ✅ หัวหน้าทีม Tier2 |
| **8** | ประวิช จินทนากร | `pravich.j` | Tier2 | ✅ | Read-only | - |
| **9** | ประกาศิต ประคองเพ็ชร | `prakasit.p` | **Tier2 + Tier3** 🔄 | ✅ | Read-only | - |
| **10** | พุทธจักษ์ วงค์พันธ์ | `puttajak.w` | Tier3 | ✅ | Read-only | - |
| **11** | วีระกร เยือกเย็น | `wirakorn.y` | Tier3 | ✅ | Read-only | - |

**หมายเหตุ:** 🔄 = สามารถสลับบทบาท (Active Role Switching)

---

## 1. Pure Admin (1 คน)

### 👤 ประอรรัตน์ กีรติผจญ (ผู้จัดการแผนก)

**Username:** `pra-onrat.k`  
**Password:** `pra-onrat.k123`

**บทบาท:**
- `admin` (Pure Admin เท่านั้น ไม่มี Tier)
- `roles: ['admin']`
- `primaryRole: 'admin'`

**สิทธิ์:**
- ✅ **Read/Write** ทุกอย่าง
- ✅ จัดการเมนู "ทีม" ได้
- ✅ Dashboard แบบ Monitor (Read-only)
- ✅ ดูเคสทั้งหมด (Read-only)
- ❌ **ไม่สามารถรับเคส** (ไม่มีเมนู "รอดำเนินการ" แบบ Action)
- ❌ **ไม่สามารถบันทึกเคสแทนลูกค้า** (ไม่มี tier1 หรือ staff role)

**Email:** `pra-onrat.k@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-002`, `proj-003`

---

## 2. Admin + Tier1 (2 คน)

### 👤 ธิราภรณ์ รุ่งวิรัตน์กุล (หัวหน้าทีม)

**Username:** `thiraporn.r`  
**Password:** `thiraporn.r123`

**บทบาท:**
- `roles: ['admin', 'tier1']` (Multi-role - ไม่สลับบทบาท)
- `primaryRole: 'admin'`

**สิทธิ์:**
- ✅ **Read/Write** ทุกอย่าง
- ✅ จัดการเมนู "ทีม" ได้
- ✅ รับเคส, ส่งต่อเคส, ปิดเคส
- ✅ **บันทึกเคสแทนลูกค้า** (มี tier1 role)
- ✅ Dashboard แบบ Tier1
- ✅ ดูเคสทั้งหมด (Full Access)

**Email:** `thiraporn.r@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- **ทุกโครงการ** (Admin รับผิดชอบทุกโครงการ)

**หัวหน้าทีม:**
- ✅ **หัวหน้าทีม Tier1**

---

### 👤 สาริน ช่อพะยอม

**Username:** `sarin.c`  
**Password:** `sarin.c123`

**บทบาท:**
- `roles: ['admin', 'tier1']` (Multi-role - ไม่สลับบทบาท)
- `primaryRole: 'admin'`

**สิทธิ์:**
- ✅ **Read/Write** ทุกอย่าง
- ✅ จัดการเมนู "ทีม" ได้
- ✅ รับเคส, ส่งต่อเคส, ปิดเคส
- ✅ **บันทึกเคสแทนลูกค้า** (มี tier1 role)
- ✅ Dashboard แบบ Tier1

**Email:** `sarin.c@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- **ทุกโครงการ** (Admin รับผิดชอบทุกโครงการ)

---

## 3. Tier1 Only (3 คน)

### 👤 วรรณภา แซ่ด่าง

**Username:** `wannapa.s`  
**Password:** `wannapa.s123`

**บทบาท:**
- `roles: ['tier1']`
- `primaryRole: 'tier1'`

**สิทธิ์:**
- ✅ รับเคส, ส่งต่อเคส, ปิดเคส
- ✅ **บันทึกเคสแทนลูกค้า** (มี tier1 role)
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้

**Email:** `wannapa.s@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-002`, `proj-003`, `proj-004`, `proj-005`, `proj-006`, `proj-007`, `proj-008`, `proj-009`

**หัวหน้า:**
- 👤 ธิราภรณ์ รุ่งวิรัตน์กุล (`thiraporn.r@cdg.co.th`)

---

### 👤 เขมิกา แซ่ตั้ง

**Username:** `khemika.s`  
**Password:** `khemika.s123`

**บทบาท:**
- `roles: ['tier1']`
- `primaryRole: 'tier1'`

**สิทธิ์:**
- ✅ รับเคส, ส่งต่อเคส, ปิดเคส
- ✅ **บันทึกเคสแทนลูกค้า** (มี tier1 role)
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้

**Email:** `khemika.s@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-003`, `proj-004`, `proj-005`, `proj-008`

**หัวหน้า:**
- 👤 ธิราภรณ์ รุ่งวิรัตน์กุล (`thiraporn.r@cdg.co.th`)

---

### 👤 ธัญญาพร ทองแก้ว

**Username:** `thanyaporn.t`  
**Password:** `thanyaporn.t123`

**บทบาท:**
- `roles: ['tier1']`
- `primaryRole: 'tier1'`

**สิทธิ์:**
- ✅ รับเคส, ส่งต่อเคส, ปิดเคส
- ✅ **บันทึกเคสแทนลูกค้า** (มี tier1 role)
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้

**Email:** `thanyaporn.t@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-002`, `proj-003`, `proj-006`, `proj-007`, `proj-010`

**หัวหน้า:**
- 👤 ธิราภรณ์ รุ่งวิรัตน์กุล (`thiraporn.r@cdg.co.th`)

---

## 4. Tier2 Only (2 คน)

### 👤 ยุทธนา คณามิ่งมงคล (หัวหน้าทีม Tier2)

**Username:** `yuttana.k`  
**Password:** `yuttana.k123`

**บทบาท:**
- `tier2`
- Primary Role: `tier2`

**สิทธิ์:**
- ✅ รับเคส (Tier2 เท่านั้น)
- ✅ ส่งต่อเคส (Tier3, Tier1, Tier2 อื่น)
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้
- ❌ ไม่เห็นเคส status `new`, `tier1`

**Email:** `yuttana.k@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- **ทุกโครงการ** (หัวหน้าทีม Tier2 รับผิดชอบทุกโครงการ)

**หัวหน้าทีม:**
- ✅ **หัวหน้าทีม Tier2**

**หัวหน้า:**
- 👤 ธิราภรณ์ รุ่งวิรัตน์กุล (`thiraporn.r@cdg.co.th`)

---

### 👤 ประวิช จินทนากร

**Username:** `pravich.j`  
**Password:** `pravich.j123`

**บทบาท:**
- `tier2`
- Primary Role: `tier2`

**สิทธิ์:**
- ✅ รับเคส (Tier2 เท่านั้น)
- ✅ ส่งต่อเคส
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้

**Email:** `pravich.j@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-002`, `proj-003`, `proj-006`, `proj-007`, `proj-008`

**หัวหน้า:**
- 👤 ยุทธนา คณามิ่งมงคล (`yuttana.k@cdg.co.th`)

---

## 5. Tier2 + Tier3 (1 คน)

### 👤 ประกาศิต ประคองเพ็ชร

**Username:** `prakasit.p`  
**Password:** `prakasit.p123`

**บทบาท:**
- `tier2`, `tier3` (Multi-role)
- Primary Role: `tier2`

**สิทธิ์:**
- ✅ รับเคส (Tier2 + Tier3)
- ✅ ส่งต่อเคส
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้

**Email:** `prakasit.p@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- **ทุกโครงการ** (Tier2+3 รับผิดชอบทุกโครงการ)

**หัวหน้า:**
- 👤 ยุทธนา คณามิ่งมงคล (`yuttana.k@cdg.co.th`)

---

## 6. Tier3 Only (2 คน)

### 👤 พุทธจักษ์ วงค์พันธ์

**Username:** `puttajak.w`  
**Password:** `puttajak.w123`

**บทบาท:**
- `tier3`
- Primary Role: `tier3`

**สิทธิ์:**
- ✅ รับเคส (Tier3 เท่านั้น)
- ✅ ส่งต่อเคส (Tier2, Tier1, Tier3 อื่น)
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้
- ❌ ไม่เห็นเคส status `new`, `tier1`, `tier2` (Inverted Visibility)

**Email:** `puttajak.w@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-003`, `proj-004`, `proj-005`, `proj-009`, `proj-010`

**หัวหน้า:**
- 👤 ยุทธนา คณามิ่งมงคล (`yuttana.k@cdg.co.th`)

---

### 👤 วีระกร เยือกเย็น

**Username:** `wirakorn.y`  
**Password:** `wirakorn.y123`

**บทบาท:**
- `tier3`
- Primary Role: `tier3`

**สิทธิ์:**
- ✅ รับเคส (Tier3 เท่านั้น)
- ✅ ส่งต่อเคส
- ✅ ดูเมนู "ทีม" (**Read-only**)
- ❌ ไม่สามารถจัดการสมาชิกได้

**Email:** `wirakorn.y@cdg.co.th`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-002`, `proj-006`, `proj-007`, `proj-008`

**หัวหน้า:**
- 👤 ยุทธนา คณามิ่งมงคล (`yuttana.k@cdg.co.th`)

---

## 7. บัญชีทดสอบ (2 บัญชี)

### 👤 สมชาย ใจดี (Staff #1)

**Username:** `staff`  
**Password:** `staff123`

**บทบาท:**
- `staff`
- Primary Role: `staff`

**สิทธิ์:**
- ✅ บันทึกเคสแทนลูกค้า (Phone/Email/Line)
- ✅ ปิดเคสย้อนหลัง
- ✅ ติดตามเคสที่สร้างแล้ว (Read-only)
- ❌ ไม่เห็นเมนู "ทีม"
- ❌ ไม่สามารถรับเคสจากคิว

**Email:** `staff@cdg.co.th`  
**เบอร์โทร:** `+66-82-345-6789`  
**หน่วยงาน:** `ฝ่ายบริการลูกค้า`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-002`, `proj-003`

---

### 👤 เอกชัย เบ็นเจ๊ะอาหวัง (Staff/PM #2)

**Username:** `eakkachai.b`  
**Password:** `eakkachai.b123`

**บทบาท:**
- `staff`
- Primary Role: `staff`

**สิทธิ์:**
- ✅ บันทึกเคสแทนลูกค้า (Phone/Email/Line)
- ✅ ปิดเคสย้อนหลัง
- ✅ ติดตามเคสที่สร้างแล้ว (Read-only)
- ❌ ไม่เห็นเมนู "ทีม"
- ❌ ไม่สามารถรับเคสจากคิว

**Email:** `eakkachai.b@cdg.co.th`  
**เบอร์โทร:** `+66-82-456-7890`  
**หน่วยงาน:** `Digital & SaaS Project Support`

**โครงการที่รับผิดชอบ:**
- `proj-001`, `proj-002`, `proj-003`, `proj-004`, `proj-005`

---

### 👤 ศิริพร อารีมิตร (Customer)

**Username:** `customer1`  
**Password:** `customer1123`

**บทบาท:**
- `customer`
- Primary Role: `customer`

**สิทธิ์:**
- ✅ สร้างเคสผ่าน Web Portal
- ✅ ติดตามเคสของตัวเอง
- ✅ เพิ่มความคิดเห็น
- ❌ ไม่เห็นเมนู "ทีม"

**Email:** `siriporn.a@example.com`
**เบอร์โทร:** `+66-81-234-5678`
**หน่วยงาน:** `ฝ่ายจัดซื้อ`

---

## 📊 สรุป Permission "ทีม"

| กลุ่ม | จำนวน | Permission | ตัวอย่าง |
|-------|-------|-----------|----------|
| **Pure Admin** | 1 | **Read/Write** | pra-onrat.k |
| **Admin + Tier1/2/3** | 2 | **Read/Write** | thiraporn.r, sarin.c |
| **Tier1 (Pure)** | 3 | **Read-only** | wannapa.s, khemika.s, thanyaporn.t |
| **Tier2 (Pure)** | 2 | **Read-only** | yuttana.k, pravich.j |
| **Tier2+3** | 1 | **Read-only** | prakasit.p |
| **Tier3 (Pure)** | 2 | **Read-only** | puttajak.w, wirakorn.y |
| **Staff/Customer** | 3 | **ไม่เข้าถึง** | staff, eakkachai.b, customer1 |

---

## 🎯 วิธีทดสอบ Permission "ทีม"

### ✅ **Read/Write (3 คน):**
```bash
# Pure Admin
Username: pra-onrat.k
Password: pra-onrat.k123

# Admin + Tier1
Username: thiraporn.r
Password: thiraporn.r123

# Admin + Tier1
Username: sarin.c
Password: sarin.c123
```

**ตรวจสอบ:**
- ✅ เห็นปุ่ม "+ เพิ่มสมาชิกทีม"
- ✅ ไม่มีกล่องเหลือง (Read-only Banner)

---

### 🔒 **Read-only (9 คน):**
```bash
# Tier1
wannapa.s / wannapa.s123
khemika.s / khemika.s123
thanyaporn.t / thanyaporn.t123

# Tier2
yuttana.k / yuttana.k123
pravich.j / pravich.j123
prakasit.p / prakasit.p123

# Tier3
puttajak.w / puttajak.w123
wirakorn.y / wirakorn.y123
```

**ตรวจสอบ:**
- ❌ **ไม่มี**ปุ่ม "+ เพิ่มสมาชิกทีม"
- ✅ มีกล่องเหลือง 🔒 "โหมดดูอย่างเดียว"

---

**อ่านเอกสารอื่น:**
- [Navigation Menu](/docs/NAVIGATION_MENU.md)
- [Permission Matrix](/docs/PERMISSION_MATRIX.md)
- [Project Overview](/docs/PROJECT_OVERVIEW.md)