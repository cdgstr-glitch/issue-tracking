import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import { ProtectedRoute } from './components/ProtectedRoute';
import CustomerHomePage from './pages/CustomerHomePage';
import StaffHomePage from './pages/StaffHomePage';
import CreateTicketPage from './pages/CreateTicketPage';
import CustomerTrackTicketPage from './pages/CustomerTrackTicketPage';
import StaffTrackTicketPage from './pages/StaffTrackTicketPage';
import TrackTicketDetailPage from './pages/TrackTicketDetailPage';
import StaffTicketDetailPage from './pages/StaffTicketDetailPage';
import RetroactiveClosedTicketsPage from './pages/RetroactiveClosedTicketsPage';
import RetroactiveClosedTicketDetailPage from './pages/RetroactiveClosedTicketDetailPage';
import CustomerJourneyPage from './pages/CustomerJourneyPage';
import CustomerFAQPage from './pages/CustomerFAQPage';
import StaffJourneyPage from './pages/StaffJourneyPage';
import Tier1JourneyPage from './pages/Tier1JourneyPage';
import Tier2JourneyPage from './pages/Tier2JourneyPage';
import Tier3JourneyPage from './pages/Tier3JourneyPage';
import AdminDashboard from './pages/AdminDashboard';
import { TicketListPage } from './pages/TicketListPage';
import TicketDetailPage from './pages/TicketDetailPage';
import SADashboard from './pages/SADashboard';
import SpecialistDashboard from './pages/SpecialistDashboard';
import EscalatedPage from './pages/EscalatedPage';
import AnalyticsDashboard from './pages/AnalyticsDashboard';
import { UserJourneyDiagram } from './components/UserJourneyDiagram';
import ReportsPage from './pages/ReportsPage';
import TeamManagementPage from './pages/TeamManagementPage';
import SettingsPage from './pages/SettingsPage';
import SystemSettingsPage from './pages/admin/SystemSettingsPage';
import ProjectSettingsPage from './pages/ProjectSettingsPage';
import ProductManagementPage from './pages/ProductManagementPage';
import SlaSettingsPage from './pages/SlaSettingsPage';
import NotificationsPage from './pages/NotificationsPage';
import { MagicLinkVerification } from './components/customer/MagicLinkVerification';
import ProfilePage from './pages/ProfilePage';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { BookOpen } from 'lucide-react';
import { Toaster } from 'sonner@2.0.3';
import { hasAnyRole, getPrimaryRole } from './lib/utils';
import { can, CAPABILITIES, isTier1, isPureStaff, isCustomer } from './lib/permissions';

type Route = {
  path: string;
  ticketId?: string;
  sourcePath?: string; // ✅ เก็บ path ที่มาจาก (เช่น /admin/tickets, /admin/pending)
  magicToken?: string; // ✅ Step 7: Magic Link token
};

function AppContent() {
  const { user, isAuthenticated, isLoading, activeRole } = useAuth();
  const [currentRoute, setCurrentRoute] = useState<Route>({ path: '/' });
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showDemoMenu, setShowDemoMenu] = useState(false);
  const [authPage, setAuthPage] = useState<'customer-landing' | 'staff-login' | 'register' | 'forgot-password'>('customer-landing'); // ✅ Step 7: เปลี่ยน default เป็น customer-landing
  const [headerSearchQuery, setHeaderSearchQuery] = useState(''); // ✅ เพิ่ม state สำหรับ search จาก Header
  
  // ✅ Step 7: Check for Magic Link in URL on mount
  // ⚠️ [COMMENTED OUT FOR DEMO] - Magic Link flow ปิดชั่วคราว
  /*
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('token');
      
      console.log('🔍 [App.tsx] Checking for magic token in URL');
      console.log('📍 URL:', window.location.href);
      console.log('🎫 Token from URL:', token);
      
      if (token) {
        console.log('✅ Token found! Navigating to /auth/magic');
        // Navigate to magic link verification
        navigate('/auth/magic', undefined, undefined, token);
      } else {
        console.log('❌ No token found in URL');
      }
    }
  }, []);
  */

  const navigate = (path: string, ticketId?: string, sourcePath?: string, magicToken?: string) => {
    console.log('🚀 App.tsx navigate called');
    console.log('   - path:', path);
    console.log('   - ticketId:', ticketId);
    console.log('   - sourcePath:', sourcePath);
    console.log('   - magicToken:', magicToken);
    console.log('📍 Current route before:', currentRoute);
    
    setCurrentRoute({ path, ticketId, sourcePath, magicToken });
    setSidebarOpen(false);
    setShowDemoMenu(false);
    
    // ✅ เคลียร์ search query เมื่อเปลี่ยนหน้า (ยกเว้นการไปหน้า /admin/tickets เพื่อให้ search ทำงานต่อได้)
    if (path !== '/admin/tickets') {
      setHeaderSearchQuery('');
    }
    
    // Scroll to top - scroll both window and main container
    setTimeout(() => {
      // Scroll window
      window.scrollTo({ top: 0, behavior: 'instant' });
      
      // Scroll main container (for admin routes)
      const mainContainer = document.querySelector('main.overflow-y-auto');
      if (mainContainer) {
        mainContainer.scrollTo({ top: 0, behavior: 'instant' });
      }
    }, 0);
    
    console.log('📍 Route updated to:', { path, ticketId, sourcePath, magicToken });
  };

  // Phase 1: Reset route เมื่อ logout/user เปลี่ยน
  useEffect(() => {
    if (!isAuthenticated) {
      // Reset route to home when logged out
      setCurrentRoute({ path: '/' });
      setSidebarOpen(false);
      setShowDemoMenu(false);
    }
  }, [isAuthenticated]);

  // 🆕 Auto-redirect when activeRole changes (สำหรับสลับ role)
  useEffect(() => {
    if (isAuthenticated && user && activeRole) {
      // Don't auto-redirect if on journey pages
      const isJourneyPage = currentRoute.path === '/tier1-journey' || 
                           currentRoute.path === '/tier2-journey' || 
                           currentRoute.path === '/tier3-journey' || 
                           currentRoute.path === '/docs/journey' ||
                           currentRoute.path === '/customer-journey' ||
                           currentRoute.path === '/staff-journey';
      
      if (isJourneyPage) {
        return;
      }

      // 🛡️ Safety: If at root and Tier User, Force Redirect
      if (currentRoute.path === '/') {
        if (activeRole === 'tier1' || activeRole === 'supervisor') { navigate('/admin'); return; }
        if (activeRole === 'tier2') { navigate('/admin/sa'); return; }
        if (activeRole === 'tier3') { navigate('/admin/specialist'); return; }
        if (activeRole === 'admin') { navigate('/admin'); return; }
      }

      // Redirect to appropriate dashboard based on activeRole
      if (activeRole === 'customer' || activeRole === 'staff') {
        // Allow customer/staff to access /admin/notifications and /admin/profile
        if (currentRoute.path.startsWith('/admin') && 
            currentRoute.path !== '/admin/notifications' &&
            currentRoute.path !== '/admin/profile') {
          navigate('/');
        }
      } else if (activeRole === 'tier1' || activeRole === 'supervisor') {
        // Redirect to tier1 dashboard if not already on admin routes
        if (!currentRoute.path.startsWith('/admin')) {
          navigate('/admin');
        }
      } else if (activeRole === 'tier2') {
        // Redirect Tier2 to default dashboard ONLY when outside /admin or exactly on /admin
        const isOnAdmin = currentRoute.path.startsWith('/admin');
        const isAdminRoot = currentRoute.path === '/admin';
        if (!isOnAdmin || isAdminRoot) {
          navigate('/admin/sa');
        }
      } else if (activeRole === 'tier3') {
        // Redirect Tier3 to default dashboard ONLY when outside /admin or exactly on /admin
        const isOnAdmin = currentRoute.path.startsWith('/admin');
        const isAdminRoot = currentRoute.path === '/admin';
        if (!isOnAdmin || isAdminRoot) {
          navigate('/admin/specialist');
        }
      } else if (activeRole === 'admin') {
        if (!currentRoute.path.startsWith('/admin')) {
          navigate('/admin');
        }
      }
    }
  }, [activeRole, isAuthenticated, user, currentRoute.path]); // 🔥 Added currentRoute.path to dependency to ensure it runs on route change if stuck

  // Show loading
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">กำลังโหลด...</p>
        </div>
      </div>
    );
  }

  // Phase 2: Render Login Pages (Unauthenticated)
  if (!isAuthenticated) {
    console.log('🔓 User not authenticated');
    console.log('📍 Current route:', currentRoute);
    
    // ⚠️ [COMMENTED OUT FOR DEMO] Magic Link Verification
    /*
    console.log('🔑 Checking magic link condition:');
    console.log('   - currentRoute.path:', currentRoute.path);
    console.log('   - currentRoute.magicToken:', currentRoute.magicToken);
    console.log('   - Condition result:', currentRoute.path === '/auth/magic' && currentRoute.magicToken);
    
    // ✅ Magic Link Verification
    if (currentRoute.path === '/auth/magic' && currentRoute.magicToken) {
      console.log('✅ Rendering MagicLinkVerification component');
      return (
        <MagicLinkVerification
          token={currentRoute.magicToken}
          onSuccess={() => navigate('/admin/create')}
          onError={() => {
            setAuthPage('customer-landing');
            navigate('/');
          }}
        />
      );
    }
    */

    // Staff Login
    if (authPage === 'staff-login') {
      return (
        <LoginPage 
          onLoginSuccess={() => navigate('/')}
          onNavigateToForgotPassword={() => setAuthPage('forgot-password')}
          onNavigate={navigate}
        />
      );
    }
    
    // ✅ Unified Login Page (all modes in one)
    return (
      <LoginPage 
        onLoginSuccess={() => {
          // ✅ ไม่ต้อง navigate('/') ที่นี่ ให้ useEffect จัดการ redirect ตาม role แทน
          // เพื่อป้องกัน race condition ที่อาจทำให้ redirect ผิดหน้า
          console.log('Login success - waiting for auto-redirect');
        }} 
        onNavigateToForgotPassword={() => setAuthPage('forgot-password')}
        onNavigate={navigate} // 🆕 Pass navigate for EmailPreview
      />
    );
  }

  const isAdminRoute = currentRoute.path.startsWith('/admin');

  // Demo menu overlay
  if (showDemoMenu) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 to-purple-700 p-4 md:p-8">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-8 text-center text-white">
            <h1 className="mb-3 text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-[Anuphan]">CDGS Issue Tracking</h1>
            <p className="text-base sm:text-lg md:text-xl opacity-90 font-[Anuphan]">
              ระบบติดตามปัญหาและงานบริการแบบครบวงจรระดับองค์กร
            </p>
            <p className="mt-2 text-xs sm:text-sm opacity-75 font-[Anuphan]">
              รองรับทุกอุปกรณ์ • เดสก์ท็อป • แท็บเล็ต • มือถือ
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Customer Journeys */}
            {isCustomer(user) && (
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 text-white">
                <h2 className="m-0">ลูกค้าภายนอก/ภายใน</h2>
                <p className="mt-1 text-sm opacity-90">หน้าสำหรับผู้ใช้งาน</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/')}
                >
                  หน้าแรก
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/create')}
                >
                  บันทึกเคสใหม่
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/track')}
                >
                  ติดตามเคส
                </Button>
              </CardContent>
            </Card>
            )}

            {/* Staff Journeys */}
            {isPureStaff(user) && (
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 text-white">
                <h2 className="m-0">เจ้าหน้าที่ (Staff)</h2>
                <p className="mt-1 text-sm opacity-90">รับเคสจากช่องทางต่างๆ</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/')}
                >
                  หน้าแรก
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/create')}
                >
                  บันทึกเคสใหม่
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/track')}
                >
                  ติดตามเคส
                </Button>
                {/* ❌ ลบปุ่ม "ดูเคสที่ปิดย้อนหลัง" - Staff บันทึกเคสแทนลูกค้าเท่านั้น (21 ม.ค. 2026) */}
              </CardContent>
            </Card>
            )}

            {/* Tier 1 Admin */}
            {isTier1(user) && (
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-6 text-white">
                <h2 className="m-0">Tier 1 - ผู้ดูแลระดับแรก</h2>
                <p className="mt-1 text-sm opacity-90">ทีมตอบสนองระดับแรก</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin')}
                >
                  แดชบอร์ด
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/tickets')}
                >
                  เคสทั้งหมด
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/ticket', '1')}
                >
                  รายละเอียดเคส
                </Button>
              </CardContent>
            </Card>
            )}

            {/* Tier 2 SA */}
            {user?.roles?.includes('tier2') && (
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 p-6 text-white">
                <h2 className="m-0">Tier 2 - ทีม SA</h2>
                <p className="mt-1 text-sm opacity-90">สนับสนุนด้านเทคนิค</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/sa')}
                >
                  แดชบอร์ด SA
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/tickets')}
                >
                  งานด้านเทคนิค
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/ticket', '2')}
                >
                  ดูงาน SA
                </Button>
              </CardContent>
            </Card>
            )}

            {/* Tier 3 Specialist */}
            {user?.roles?.includes('tier3') && (
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-red-500 to-red-600 p-6 text-white">
                <h2 className="m-0">Tier 3 - ผู้เชี่ยวชาญ</h2>
                <p className="mt-1 text-sm opacity-90">เหตุการณ์วิกฤติ</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/specialist')}
                >
                  แดชบอร์ดผู้เชี่ยวชาญ
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => navigate('/admin/ticket', '3')}
                >
                  เหตุการณ์วิกฤติ
                </Button>
              </CardContent>
            </Card>
            )}

            {/* Documentation - Show for all authenticated users */}
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 text-white">
                <h2 className="m-0">เอกสาร</h2>
                <p className="mt-1 text-sm opacity-90">ขั้นตอนและคู่มือผู้ใช้</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => {
                    // Route based on user primary role
                    const primaryRole = getPrimaryRole(user);
                    console.log('Button clicked! User primary role:', primaryRole);
                    if (isTier1(user)) {
                      console.log('Navigating to /tier1-journey');
                      navigate('/tier1-journey');
                    } else if (user?.roles?.includes('tier2')) {
                      console.log('Navigating to /tier2-journey');
                      navigate('/tier2-journey');
                    } else if (user?.roles?.includes('tier3')) {
                      console.log('Navigating to /tier3-journey');
                      navigate('/tier3-journey');
                    } else if (isPureStaff(user)) {
                      console.log('Navigating to /staff-journey');
                      navigate('/staff-journey');
                    } else if (can(user, CAPABILITIES.MANAGE_USERS)) {
                      console.log('Navigating to /docs/journey');
                      navigate('/docs/journey');
                    } else {
                      console.log('Default: Navigating to /docs/journey');
                      navigate('/docs/journey');
                    }
                  }}
                >
                  <BookOpen className="mr-2 h-4 w-4" />
                  {hasAnyRole(user, ['staff', 'tier1', 'tier2', 'tier3'])
                    ? 'แผนผังเส้นทางผู้ใช้ของเจ้าหน้าที่' 
                    : 'แผนผังเส้นทางผู้ใช้'}
                </Button>
              </CardContent>
            </Card>

            {/* Component Library - Show only for admin */}
            {can(user, CAPABILITIES.MANAGE_USERS) && (
            <Card className="overflow-hidden">
              <div className="bg-gradient-to-r from-gray-700 to-gray-800 p-6 text-white">
                <h2 className="m-0">ระบบออกแบบ</h2>
                <p className="mt-1 text-sm opacity-90">คอมโพเนนต์และโทเค็น</p>
              </div>
              <CardContent className="space-y-3 p-6">
                <div className="text-sm text-gray-600">
                  <p>✓ ป้ายสถานะ</p>
                  <p>✓ ตัวบ่งชี้ความสำคัญ</p>
                  <p>✓ ติดตาม SLA</p>
                  <p>✓ ตารางตอบสนอง</p>
                  <p>✓ คอมโพเนนต์ไทม์ไลน์</p>
                </div>
              </CardContent>
            </Card>
            )}
          </div>

          <div className="mt-8 text-center">
            <p className="text-sm text-white opacity-75">
              ลองปรับขนาดหน้าอพื่อดูการตอบสนอง • เดสก์ท็อป (1440px)  แท็เล็ต (1024px) • มืถือ (375px)
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Documentation route
  if (currentRoute.path === '/docs/journey') {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="border-b bg-white shadow-sm">
          <div className="container mx-auto flex h-16 items-center justify-between px-4">
            <h1 className="m-0 text-lg">เอกสารเส้นทางผู้ใช้</h1>
            <Button variant="outline" onClick={() => setShowDemoMenu(true)}>
              กลับไปเมนู
            </Button>
          </div>
        </header>
        <div className="container mx-auto max-w-6xl px-4 py-8">
          <UserJourneyDiagram />
        </div>
      </div>
    );
  }

  // Public routes (Customer portal)
  if (currentRoute.path === '/') {
    // ✅ Tier 1/2/3/Admin should NOT see Customer/Staff Home
    // Redirect logic handled by useEffect, but prevent rendering wrong page during transition
    const isTierUser = ['tier1', 'tier2', 'tier3', 'admin'].includes(activeRole);
    // ⚠️ hasTierRole check removed to prevent deadlock if activeRole is 'customer'
    
    if (isTierUser) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 flex-col gap-4">
           <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
           <p className="text-gray-600">กำลังเข้าสู่ระบบ...</p>
        </div>
      );
    }

    return (
      <ProtectedRoute>
        {isPureStaff(user) ? (
          <StaffHomePage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
        ) : (
          <CustomerHomePage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
        )}
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/create') {
    // ✅ Tier1/2/3/Admin → ใช้ admin layout (Sidebar + Header)
    const userRoles = user?.roles || [];
    if (isTier1(user) || userRoles.includes('tier2') || userRoles.includes('tier3') || can(user, CAPABILITIES.MANAGE_USERS)) {
      return (
        <ProtectedRoute allowedRoles={['tier1', 'tier2', 'tier3', 'admin', 'supervisor', 'staff', 'customer']}>
          <div key={user?.id} className="flex h-screen overflow-hidden bg-gray-50">
            <Sidebar
              currentPath={currentRoute.path}
              sourcePath={currentRoute.sourcePath}
              onNavigate={navigate}
              isOpen={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
            />
            
            <div className="flex flex-1 flex-col overflow-hidden">
              <Header
                onMenuClick={() => setSidebarOpen(!sidebarOpen)}
                user={{
                  fullName: user?.fullName || 'User',
                  role: user?.role || 'Unknown'
                }}
                onInformationClick={() => setShowDemoMenu(true)}
                onNavigate={navigate}
                currentPath={currentRoute.path}
                showSearch={false}
              />
              
              <main className="flex-1 overflow-y-auto bg-gray-50">
                <CreateTicketPage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
              </main>
            </div>
          </div>
        </ProtectedRoute>
      );
    }
    
    // ✅ Customer/Staff → simple layout (Header only)
    return (
      <ProtectedRoute allowedRoles={['customer', 'staff']}>
        <div className="min-h-screen bg-gray-50">
          <Header
            user={{
              fullName: user?.fullName || 'User',
              role: user?.role || 'Unknown'
            }}
            onInformationClick={() => setShowDemoMenu(true)}
            onNavigate={navigate}
            currentPath={currentRoute.path}
            showSearch={false}
          />
          <CreateTicketPage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
        </div>
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/track') {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-gray-50">
          <Header
            user={{
              fullName: user?.fullName || 'User',
              role: user?.role || 'Unknown'
            }}
            onInformationClick={() => setShowDemoMenu(true)}
            onNavigate={navigate}
            currentPath={currentRoute.path}
            showSearch={false}
          />
          {isPureStaff(user) ? (
            <StaffTrackTicketPage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
          ) : (
            <CustomerTrackTicketPage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
          )}
        </div>
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/track-ticket-detail') {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-gray-50">
          <Header
            user={{
              fullName: user?.fullName || 'User',
              role: user?.role || 'Unknown'
            }}
            onInformationClick={() => setShowDemoMenu(true)}
            onNavigate={navigate}
            currentPath={currentRoute.path}
            showSearch={false}
          />
          <TrackTicketDetailPage ticketId={currentRoute.ticketId || ''} onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
        </div>
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/staff-ticket-detail') {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-gray-50">
          <Header
            user={{
              fullName: user?.fullName || 'User',
              role: user?.role || 'Unknown'
            }}
            onInformationClick={() => setShowDemoMenu(true)}
            onNavigate={navigate}
            currentPath={currentRoute.path}
            showSearch={false}
          />
          <StaffTicketDetailPage ticketId={currentRoute.ticketId || ''} onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
        </div>
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/customer-journey') {
    return (
      <ProtectedRoute>
        <CustomerJourneyPage onNavigate={navigate} />
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/faq') {
    return (
      <ProtectedRoute>
        <CustomerFAQPage onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
      </ProtectedRoute>
    );
  }

  // ⭐ Profile moved to /admin/profile (special case above)

  if (currentRoute.path === '/staff-journey') {
    return (
      <ProtectedRoute>
        <StaffJourneyPage username={user?.fullName || 'Staff'} onNavigate={navigate} onLogout={() => navigate('/')} />
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/tier1-journey') {
    return (
      <ProtectedRoute>
        <Tier1JourneyPage onNavigate={navigate} />
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/tier2-journey') {
    return (
      <ProtectedRoute>
        <Tier2JourneyPage onNavigate={navigate} />
      </ProtectedRoute>
    );
  }

  if (currentRoute.path === '/tier3-journey') {
    return (
      <ProtectedRoute>
        <Tier3JourneyPage onNavigate={navigate} />
      </ProtectedRoute>
    );
  }

  // Admin routes
  if (isAdminRoute) {
    // Special case: /admin/notifications
    if (currentRoute.path === '/admin/notifications') {
      // Customer และ Staff → Full page (ไม่มี Sidebar)
      if (user?.role === 'customer' || user?.role === 'staff') {
        return (
          <ProtectedRoute>
            <div className="min-h-screen bg-gray-50">
              <Header
                user={{
                  fullName: user?.fullName || 'User',
                  role: user?.role || 'Unknown'
                }}
                onInformationClick={() => setShowDemoMenu(true)}
                onNavigate={navigate}
                currentPath={currentRoute.path}
                showSearch={false}
              />
              <NotificationsPage 
                key={user?.id} 
                recipientId={user?.id}
                userRole={activeRole} 
                userRoles={user?.roles || []}
                onNavigate={navigate} 
              />
            </div>
          </ProtectedRoute>
        );
      }
      
      // Tier1-3 และ Admin → Dashboard layout (มี Sidebar)
      return (
        <ProtectedRoute allowedRoles={['tier1', 'tier2', 'tier3', 'admin', 'supervisor']}>
          <div key={user?.id} className="flex h-screen overflow-hidden bg-gray-50">
            <Sidebar
              currentPath={currentRoute.path}
              sourcePath={currentRoute.sourcePath}
              onNavigate={navigate}
              isOpen={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
            />
            
            <div className="flex flex-1 flex-col overflow-hidden">
              <Header
                onMenuClick={() => setSidebarOpen(!sidebarOpen)}
                user={{
                  fullName: user?.fullName || 'User',
                  role: user?.role || 'Unknown'
                }}
                onInformationClick={() => setShowDemoMenu(true)}
                onNavigate={navigate}
                currentPath={currentRoute.path}
                searchQuery={headerSearchQuery}
                onSearch={setHeaderSearchQuery}
              />
              
              <main className="flex-1 overflow-y-auto">
                <NotificationsPage 
                  key={user?.id} 
                  recipientId={user?.id}
                  userRole={activeRole} 
                  userRoles={user?.roles || []}
                  onNavigate={navigate} 
                />
              </main>
            </div>
          </div>
        </ProtectedRoute>
      );
    }
    
    // ⭐ Special case: /admin/profile - Allow ALL authenticated users
    if (currentRoute.path === '/admin/profile') {
      return (
        <ProtectedRoute>
          <div className="min-h-screen bg-gray-50">
            <Header
              user={{
                fullName: user?.fullName || 'User',
                role: user?.role || 'Unknown'
              }}
              onInformationClick={() => setShowDemoMenu(true)}
              onNavigate={navigate}
              currentPath={currentRoute.path}
              showSearch={false}
            />
            <ProfilePage key={user?.id} onNavigate={navigate} />
          </div>
        </ProtectedRoute>
      );
    }
    
    // Regular admin routes (tier1, tier2, tier3, admin only)
    return (
      <ProtectedRoute allowedRoles={['tier1', 'tier2', 'tier3', 'admin', 'supervisor']}>
      {/* Phase 1: เพิ่ม key={user?.id} เพื่อบังคับ remount เมื่อ user เปลี่ยน */}
      <div key={user?.id} className="flex h-screen overflow-hidden bg-gray-50">
        <Sidebar
          currentPath={currentRoute.path}
          sourcePath={currentRoute.sourcePath}
          onNavigate={navigate}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        
        <div className="flex flex-1 flex-col overflow-hidden">
          <Header
            onMenuClick={() => setSidebarOpen(!sidebarOpen)}
            user={{
              fullName: user?.fullName || 'User', // ✅ เปลี่ยนจาก name เป็น fullName
              role: user?.role || 'Unknown'
            }}
            onInformationClick={() => setShowDemoMenu(true)}
            onNavigate={navigate}
            currentPath={currentRoute.path}
            searchQuery={headerSearchQuery}
            onSearch={setHeaderSearchQuery}
          />
          
          {/* Remove the "Back to Demo Menu" button from sidebar - now in avatar dropdown */}
          
          <main className="flex-1 overflow-y-auto">
            {currentRoute.path === '/admin' && (
              <AdminDashboard 
                key={user?.id} 
                onNavigate={navigate} 
                searchQuery={headerSearchQuery}
              />
            )}
            
            {currentRoute.path === '/admin/sa' && (
              <SADashboard 
                key={user?.id} 
                onNavigate={navigate} 
                searchQuery={headerSearchQuery}
              />
            )}
            
            {currentRoute.path === '/admin/specialist' && (
              <SpecialistDashboard 
                key={user?.id} 
                onNavigate={navigate} 
                searchQuery={headerSearchQuery}
              />
            )}
            
            {currentRoute.path === '/admin/tickets' && (
              <TicketListPage 
                key={user?.id} 
                onNavigate={navigate} 
                currentPath="/admin/tickets" 
                searchQuery={headerSearchQuery}
                onSearchChange={setHeaderSearchQuery}
              />
            )}
            
            {currentRoute.path === '/admin/my-tickets' && (
              <TicketListPage 
                key={user?.id} 
                onNavigate={navigate} 
                currentPath="/admin/my-tickets" 
                searchQuery={headerSearchQuery}
                onSearchChange={setHeaderSearchQuery}
              />
            )}
            
            {currentRoute.path === '/admin/pending' && (
              <TicketListPage 
                key={user?.id} 
                onNavigate={navigate} 
                currentPath="/admin/pending" 
                searchQuery={headerSearchQuery}
                onSearchChange={setHeaderSearchQuery}
              />
            )}
            
            {currentRoute.path === '/admin/resolved' && (
              <TicketListPage 
                key={user?.id} 
                onNavigate={navigate} 
                currentPath="/admin/resolved" 
                searchQuery={headerSearchQuery}
                onSearchChange={setHeaderSearchQuery}
              />
            )}
            
            {/* ✅ Ticket Detail from "รอดำเนินการ" */}
            {currentRoute.path === '/admin/pending' && currentRoute.ticketId && (
              <TicketDetailPage 
                key={`${user?.id}-${currentRoute.ticketId}`} 
                ticketId={currentRoute.ticketId} 
                onNavigate={navigate}
                sourcePath="/admin/pending" // ✅ มาจากหน้ารอดำเนินการ
              />
            )}
            
            {/* ✅ Ticket Detail (General) */}
            {currentRoute.path === '/admin/ticket' && currentRoute.ticketId && (
              <TicketDetailPage 
                key={`${user?.id}-${currentRoute.ticketId}`} 
                ticketId={currentRoute.ticketId} 
                onNavigate={navigate}
                sourcePath={currentRoute.sourcePath} // ✅ ส่ง sourcePath ไปด้วย
              />
            )}
            
            {currentRoute.path === '/admin/analytics' && (
              <AnalyticsDashboard key={user?.id} onNavigate={navigate} />
            )}
            
            {currentRoute.path === '/admin/reports' && (
              <ReportsPage />
            )}
            
            {currentRoute.path === '/admin/team' && (
              <TeamManagementPage key={user?.id} onNavigate={navigate} />
            )}
            
            {currentRoute.path === '/admin/settings' && (
              <SettingsPage key={user?.id} onNavigate={navigate} />
            )}

            {currentRoute.path === '/admin/settings/system' && (
              <SystemSettingsPage key={user?.id} />
            )}
            
            {currentRoute.path === '/admin/settings/projects' && (
              <ProjectSettingsPage key={user?.id} onNavigate={navigate} />
            )}
            
            {currentRoute.path === '/admin/settings/products' && (
              <ProductManagementPage key={user?.id} onNavigate={navigate} />
            )}

            {currentRoute.path === '/admin/settings/sla' && (
              <SlaSettingsPage key={user?.id} />
            )}
            
            {currentRoute.path === '/admin/create' && (
              <CreateTicketPage key={user?.id} onNavigate={navigate} onBackToMenu={() => setShowDemoMenu(true)} />
            )}
            
            {currentRoute.path === '/admin/escalated' && (
              <EscalatedPage key={user?.id} onNavigate={navigate} />
            )}
            
            {currentRoute.path === '/admin/retroactive-closed-tickets' && !currentRoute.ticketId && (
              <RetroactiveClosedTicketsPage key={user?.id} onNavigate={navigate} isAdminContext={true} />
            )}
            
            {currentRoute.path === '/admin/retroactive-closed-tickets' && currentRoute.ticketId && (
              <RetroactiveClosedTicketDetailPage key={`${user?.id}-${currentRoute.ticketId}`} ticketId={currentRoute.ticketId} onNavigate={navigate} isAdminContext={true} />
            )}
          </main>
        </div>
      </div>
      </ProtectedRoute>
    );
  }

  // 404
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <h1>404 - ไม่พบหน้านี้</h1>
        <button
          onClick={() => navigate('/')}
          className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-white"
        >
          กลับหน้าแรก
        </button>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ErrorBoundary>
        <AppContent />
        <Toaster position="top-right" richColors />
      </ErrorBoundary>
    </AuthProvider>
  );
}