// ============================================
// NORMALIZED TYPES FOR LARAVEL BACKEND (Frontend-safe)
// - Keep existing field names to avoid breaking current UI/data
// - Expand enums to match masterData/permissions + legacy compatibility
// ============================================

// ============================================
// PRIMITIVES (Incremental strict, Laravel-friendly)
// - Keep as string for now to avoid breaking existing mock data/UI
// - Later you can upgrade these to branded types + runtime guards
// ============================================

export type ISODateString = string;

export type UserId = string;
export type CustomerId = string;
export type TicketId = string;
export type TicketNumber = string;
export type ProjectId = string;
export type OrganizationId = string;
export type ProductId = string;
export type TagId = string;

// Operator context role (separate from UserRole)
export type ActiveRole = 'tier1' | 'tier2' | 'tier3' | 'supervisor';

// CBAC (capability-based access control)
export type Capability = string;

// ===== Tickets =====
// masterData/statusCatalog currently uses 'on_hold'
// docs/backend direction uses 'on_hold'
export type TicketStatus =
  | 'new'        // เคสใหม่ จาก Customer/Staff (assignedTo = null)
  | 'pending'    // รอดำเนินการ: มอบหมายแล้ว ยังไม่กดรับ (assignedTo = userId, accepted = false) ห้ามเปลี่ยนชื่อ
  | 'in_progress'
  | 'on_hold'
  | 'resolved'
  | 'closed';

// Optional canonical DB lifecycle type (for Laravel enum / validation)
export type TicketStatusDB = 'new' | 'pending' | 'in_progress' | 'on_hold' | 'resolved' | 'closed';

export type TicketStage = 'tier1' | 'tier2' | 'tier3';

// masterData.ts has incident/service_request/security_incident + ITIL problem/change_request
export type TicketType =
  | 'incident'
  | 'service_request'
  | 'security_incident'
  | 'problem'
  | 'change_request';

// masterData.ts uses line (not line_oa)
export type TicketChannel = 'web' | 'email' | 'line' | 'phone';

// masterData.ts uses critical (not urgent), but keep urgent as legacy safety
export type TicketPriority = 'low' | 'medium' | 'high' | 'critical' | 'urgent';

// ===== Users =====
// permissions.ts uses: customer, staff, tier1, supervisor, tier2, tier3, admin
// (agent is legacy; keep optional to prevent stray old code from breaking build)
export type UserRole =
  | 'customer'
  | 'staff'
  | 'tier1'
  | 'supervisor'
  | 'tier2'
  | 'tier3'
  | 'admin'
  | 'agent';

// ===== Ticket creation / closure meta =====
export type CreatedByType = 'customer_self' | 'staff_on_behalf';
export type ClosedReason = 'resolved' | 'no_response' | 'duplicate' | 'wont_fix' | 'spam';
export type ClosureSource = 'instant_close' | 'handoff_to_tier1_close' | 'normal_close';

// ============================================
// CORE ENTITIES
// ============================================

export interface Ticket {
  id: TicketId;
  ticketNumber: TicketNumber;
  title: string;
  description: string;

  // Status & Stage
  status: TicketStatus;
  stage: TicketStage;
  type: TicketType;
  channel: TicketChannel;
  priority: TicketPriority;
  category?: string;

  // ✅ Foreign Keys (Normalized)
  customerId: CustomerId; // FK → customers
  projectId: ProjectId; // FK → projects
  organizationId: OrganizationId; // FK → organizations

  // ✅ Creator: exactly one must be set (XOR)
  // (some legacy data uses createdByUserId; keep both)
  createdByUserId?: UserId | null; // FK → users (staff_on_behalf)
  createdByCustomerId?: CustomerId | null; // FK → customers (customer_self)
  createdByType: CreatedByType; // kept for convenience / backward compat

  // Assignment
  assignedTo?: UserId | null; // FK → users
  assignedBy?: UserId; // FK → users
  assignedAt?: ISODateString | null;
  accepted?: boolean;

  // Resolution
  resolvedBy?: UserId; // FK → users
  resolvedAt?: ISODateString;
  resolution?: string;

  // Closure
  closedBy?: UserId; // FK → users
  closedAt?: ISODateString;
  closedReason?: ClosedReason;
  closureSource?: ClosureSource;
  closureNotes?: string;

  // Retroactive
  isRetroactive?: boolean;
  retroactiveReason?: string;
  actualIncidentDate?: ISODateString;
  actualClosedAt?: ISODateString;

  // Timestamps
  createdAt: ISODateString;
  updatedAt: ISODateString;
  dueDate?: ISODateString;
}

export interface Customer {
  id: CustomerId;
  fullName: string;
  email: string;
  phone?: string;
  department?: string;
  organizationId: OrganizationId; // FK → organizations
  isActive: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface User {
  id: UserId;
  username: string;
  email: string;
  fullName: string;

  // ✅ make sure supervisor is allowed
  primaryRole: UserRole;
  roles: UserRole[];

  // ✅ CBAC + activeRole (optional for legacy/mock compatibility)
  activeRole?: ActiveRole;
  capabilities?: Capability[];

  tier?: number;
  department?: string;
  position?: string;
  phone?: string;
  managerId?: UserId; // FK → users (self-referencing)
  projectIds?: ProjectId[];
  isActive: boolean;
  lastLoginAt?: ISODateString;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface Organization {
  id: OrganizationId;
  organizationCode: string;
  organizationName: string;
  organizationShortName?: string;
  organizationType: string;
  department?: string;
  description?: string;
  contactPerson?: string;
  address?: string;
  phone?: string;
  email?: string;
  isActive: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface Project {
  id: ProjectId;
  projectCode: string;
  projectName: string;
  organizationId: OrganizationId; // FK → organizations
  projectStatus: string;
  startDate?: ISODateString;
  endDate?: ISODateString;
  description?: string;

  // NOTE: In Laravel DB we’ll move this to project_products pivot.
  // Keep here for now to avoid breaking existing UI/data.
  purchasedProducts?: ProductId[];

  budget?: number;
  projectManager?: string;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface Product {
  id: ProductId;
  productCode: string;
  productName: string;
  description?: string;
  category?: string;
  isActive: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

// ============================================
// JUNCTION TABLES
// ============================================

export interface TicketProduct {
  id: string;
  ticketId: TicketId; // FK → tickets
  productId: ProductId; // FK → products.id
  createdAt: ISODateString;
}

export interface Tag {
  id: TagId;
  tagName: string;
  tagSlug: string;
  usageCount: number;
  createdAt: ISODateString;
}

export interface TicketTag {
  id: string;
  ticketId: TicketId; // FK → tickets
  tagId: TagId; // FK → tags
  createdAt: ISODateString;
}

export interface UserOrganization {
  id: string;
  userId: UserId; // FK → users
  organizationId: OrganizationId; // FK → organizations
  role?: string; // optional: role within this org (e.g. 'primary', 'auditor', 'support')
  isPrimary: boolean; // exactly one must be true per user (default org)
  isActive: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

// ============================================
// RELATED TABLES
// ============================================

export interface TimelineEvent {
  id: string;
  ticketId: TicketId; // FK → tickets
  timestamp: ISODateString;

  // Keep as string for flexibility (legacy variants exist)
  type: string;

  action?: string;

  // ✅ make optional to tolerate legacy events that only have meta/action
  description?: string;

  actorUserId?: UserId | null; // FK → users (staff/tier actions)
  actorCustomerId?: CustomerId | null; // FK → customers (customer actions)

  assignedToUserId?: UserId; // FK → users (agent/tier)
  status?: TicketStatus | string;

  meta?: Record<string, unknown>;
  isInternal?: boolean;
}

export interface Comment {
  id: string;
  ticketId: TicketId; // FK → tickets
  authorUserId?: UserId | null; // FK → users
  authorCustomerId?: CustomerId | null; // FK → customers
  content: string;
  isInternal: boolean;
  createdAt: ISODateString;
  updatedAt?: ISODateString;
}

export interface Attachment {
  id: string;
  ticketId: TicketId; // FK → tickets
  fileName: string;
  fileSize: number;
  fileType: string;
  filePath?: string;
  url?: string; // public URL for download

  // ✅ allow null/optional for legacy safety
  uploadedBy?: UserId | null; // FK → users
  uploadedAt: ISODateString;
}

export interface Escalation {
  id: string;
  ticketId: TicketId; // FK → tickets

  // Make stage strongly typed (data uses tier1/2/3)
  from: TicketStage;
  to: TicketStage;

  escalatedBy: UserId; // FK → users
  escalatedTo?: UserId; // userId who receives (if specified)
  escalatedAt: ISODateString; // ISO timestamp
  reason?: string;
  escalationType?: 'for_closure' | 'for_continuation';
}

export interface Notification {
  id: string;
  userId?: UserId; // FK → users (if targeted)
  ticketId?: TicketId; // FK → tickets
  ticketNumber?: TicketNumber; // display
  type: string; // keep flexible: 'new' | 'sla' | 'escalated' | ...
  title: string;
  message: string;
  time?: string; // human-readable relative time
  priority?: TicketPriority | string;
  isNew?: boolean;
  isRead: boolean;
  readAt?: ISODateString;
  actionUrl?: string;
  role?: UserRole | string;
  createdAt: ISODateString;
}

export interface SatisfactionSurvey {
  id: string;
  ticketId: TicketId; // FK → tickets (UNIQUE)
  rating: number; // 1-5
  comment?: string;
  customerId: CustomerId; // FK → customers
  createdAt: ISODateString;
  updatedAt?: ISODateString;
}

// ============================================
// SUPPORT TABLES
// ============================================

// ✅ SLA (Backend normalized clocks) + ✅ Legacy UI compat fields
export type SLAScope = 'global' | 'organization' | 'project';

export interface SLASetting {
  id: string;
  priority: TicketPriority;

  // New normalized clocks (backend-ready)
  responseTimeHours: number;
  resolutionTimeHours: number;
  escalationTimeHours?: number;

  // Legacy/Current UI compatibility (so SlaSettingsPage.tsx won't break)
  scope?: SLAScope;
  targetId?: string | null; // orgId or projectId
  ticketType?: TicketType;
  hours?: number; // legacy single SLA hours

  isActive: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}


 // ============================================
 // LARAVEL-READY READ MODELS (API Resources)
 // - Storage remains normalized (rows + pivots are Source of Truth)
 // - UI should consume Resource shapes (hydrated relations)
 // ============================================

 // ✅ Storage row (DB table shape). Alias for clarity.
 export type TicketRow = Ticket;

 /**
  * ✅ TicketResource (Laravel API Resource equivalent)
  * Mirrors what you'd get from:
  * TicketResource::make($ticket->load(['comments','products','tags','timeline','attachments','escalations']))
  *
  * Rules:
  * - Relations are ALWAYS arrays (empty array if none) — never undefined
  * - This is safe for UI rendering and matches Eloquent semantics
  */
 export type TicketResource = Ticket & {
   organization?: Organization;
   project?: Project;
   customer?: Customer;
   assignedToUser?: User | null;

   products: Product[];
   tags: Tag[];
   timeline: TimelineEvent[];
   comments: Comment[];
   attachments: Attachment[];
   escalations: Escalation[];

   // Optional convenience fields (legacy UI)
   customerName?: string;
   customerEmail?: string;
   customerPhone?: string;
   department?: string;
   projectName?: string;
   projectCode?: string;
   organizationName?: string;
   assignedToName?: string;
 };
